#import xbmc, os, subprocess, sys
#import xbmc, xbmcgui, xbmcaddon
import xbmc, xbmcgui, xbmcaddon
import subprocess, os, sys
#import datetime, time
from variables import *
from modules2 import *

def setAutoSettings(custom):
	if custom == "0":
		if systemhasaddon_sdarottv:
			'''------------------------------
			---plugin.video.sdarot.tv--------
			------------------------------'''
			addonsettings('SDAROT TV', 'plugin.video.sdarot.tv', 'Account2_Active', 'Account2_Period', 'username','user_password', "", "", "", "")
			addonsettings2('plugin.video.sdarot.tv','DEBUG',"false",'cache',"24",'domain',"http://www.sdarot.wf",'',"",'',"")
		
			if not systemplatformwindows: bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.video.sdarot.tv/sdarot-cookiejar.txt',"plugin.video.sdarot.tv")
			'''---------------------------'''
		else:
			print printfirst + space + "addonsettingall" + space2 + "Addon is missing! - " + "plugin.video.sdarot.tv"
			'''---------------------------'''
		
		try:
			'''------------------------------
			---service.subtitles.subtitle----
			------------------------------'''
			addonsettings2('service.subtitles.subtitle','SUBemail',idstr + "@gmail.com",'SUBpassword',idpstr,'',"",'',"",'',"")
			if not systemplatformwindows: bash('rm -rf /storage/.kodi/userdata/addon_data/service.subtitles.subtitle/cookiejar.txt',"service.subtitles.subtitle")
			'''---------------------------'''
		except:
			print printfirst + space + "addonsettingall" + space2 + "Addon is missing! - " + "service.subtitles.subtitle"
			'''---------------------------'''
				
		try:
			'''------------------------------
			---plugin.video.israelive--------
			------------------------------'''
			addonsettings2('plugin.video.israelive','useIPTV',"false",'useEPG',"true",'StreramProtocol',"1",'forceRemoteDefaults',"true",'StreramsMethod',"0")
			addonsettings2('plugin.video.israelive','catColor',"chartreuse",'useEPG',"true",'chColor',"yellow",'prColor',"floralwhite",'timesColor',"none")
			'''---------------------------'''
		except:
			print printfirst + space + "addonsettingall" + space2 + "Addon is missing! - " + "plugin.video.israelive"
			'''---------------------------'''
			
		try:
			'''------------------------------
			---plugin.video.youtube----------
			------------------------------'''
			addonsettings2('plugin.video.youtube','kodion.view.override',"true",'kodion.video.quality',"4",'kodion.view.default',"50",'kodion.view.episodes',"58",'kodion.search.size',"4")
			addonsettings2('plugin.video.youtube','kodion.setup_wizard',"false",'youtube.folder.disliked_videos.show',"false",'youtube.language',"iw-IL",'kodion.fanart.show',"false",'youtube.folder.sign.in.show',"true")
			if not systemplatformwindows: bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.video.youtube/kodion/cache.sqlite',"plugin.video.youtube")
			'''---------------------------'''
		except:
			print printfirst + space + "addonsettingall" + space2 + "Addon is missing! - " + "plugin.video.youtube"
			'''---------------------------'''
			
		try:
			'''------------------------------
			---service.autosubs--------------
			------------------------------'''
			pass
			#addonsettings2('service.autosubs','check_for_specific',"true",'selected_language',"Hebrew",'debug',"false",'ExcludeTime',"15",'ignore_words',"theme")
			#addonsettings2('service.autosubs','ExcludeHTTP',"false",'ExcludeLiveTV',"true",'',"",'',"",'',"")
			'''---------------------------'''
		except:
			print printfirst + space + "addonsettingall" + space2 + "Addon is missing! - " + "service.autosubs"
			'''---------------------------'''
		
		if systemhasaddon_aob:
			'''------------------------------
			---plugin.video.aob--------------
			------------------------------'''
			addonsettings2('plugin.video.aob','tvshows-view',"58",'default-view',"50",'auto-view',"true",'',"",'',"")
			'''---------------------------'''
		else:
			print printfirst + space + "addonsettingall" + space2 + "Addon is missing! - " + "plugin.video.aob"
			'''---------------------------'''
			
		'''------------------------------
		---script.htpt.homebuttons-------
		------------------------------'''	
		dialogtextviewerW = xbmc.getCondVisibility('Window.IsVisible(DialogTextViewer.xml)')
		while dialogtextviewerW and not xbmc.abortRequested:
			xbmc.sleep(1000)
			dialogtextviewerW = xbmc.getCondVisibility('Window.IsVisible(DialogTextViewer.xml)')
			'''---------------------------'''
		set_accountdate('REALDEBRID','plugin.video.genesis', 'realdedrid_user', 'realdedrid_password', realdedrid_user, realdedrid_password, 'Account1_Active', 'Account1_Period', 'Account1_EndDate', Account1_Active, Account1_Period, Account1_EndDate, "1")
		set_accountdate('SDAROT TV','plugin.video.sdarot.tv', 'username', 'user_password', sdarottv_user, sdarottv_password, 'Account2_Active', 'Account2_Period', 'Account2_EndDate', Account2_Active, Account2_Period, Account2_EndDate, "1")
		'''---------------------------'''
	
	elif custom == "1":
		if not adult2: setSkinSetting("1",'adult',"false")
		if not moviesestartup: setSkinSetting("0",'moviesestartup',"1")
		if not tvshowsestartup: setSkinSetting("0",'tvshowsestartup',"1")
		'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "setAutoSettings" + space + "custom" + space2 + custom
	'''---------------------------'''
	
def replace_word(infile,old_word,new_word):
    if not os.path.isfile(infile):
        print ("Error on replace_word, not a regular file: "+infile)
        sys.exit(1)
        '''---------------------------'''
    f1=open(infile,'r').read()
    f2=open(infile,'w')
    m=f1.replace(old_word,new_word)
    f2.write(m)

def stringtodate(dt_str, dt_func):
	from datetime import datetime
	#dt_str = '9/24/2010 5:03:29 PM'
	#dt_func = '%m/%d/%Y %I:%M:%S %p'
	try:
		dt_obj = datetime.strptime(dt_str, dt_func)
		return dt_obj
	except:
		notification("stringtodate_ERROR!","sys.exit()","",5000)
		sys.exit()

def stringtotime(dt_str, dt_func):
	'''WIP!!!'''
	from datetime import datetime
	import time
	#dt_str = '9/24/2010 5:03:29 PM'
	#dt_func = '%m/%d/%Y %I:%M:%S %p'
	#try:
	dt_obj = datetime.strptime(dt_str, dt_func)
	dt_objS = str(dt_obj)
	if dt_func == '%H':
		#time.struct_time(tm_year=1900, tm_mon=1, tm_mday=1, tm_hour=20, tm_min=0, tm_sec=0, tm_wday=0, tm_yday=1, tm_isdst=-1)
		find = dt_str
		found = find_string(dt_objS, find, "")
		'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "stringtotime" + space + "dt_objS" + space2 + dt_objS + space + "timenow3S" + space2 + timenow3S
	'''---------------------------'''
	
	return dt_obj

def find_string(findin, findwhat, findwhat2):
	findin = str(findin)
	findinL = len(findin)
	findinLS = str(findinL)
	findinLN = int(findinLS)
	findwhat = str(findwhat)
	findwhatL = len(findwhat)
	findwhatLS = str(findwhatL)
	findwhatLN = int(findwhatLS)
	findwhat2 = str(findwhat2)
	findwhat2L = len(findwhat2)
	findwhat2LS = str(findwhat2L)
	findwhat2LN = int(findwhat2LS)
	'''---------------------------'''
	findin_start = findin.find(findwhat, 0, findinL)
	findin_startS = str(findin_start)
	findin_startN = int(findin_startS) + findwhatLN
	findin_startS = str(findin_start)
	'''---------------------------'''
	if findwhat2 == "": findin_end = findin.find(findwhat2, findin_startN, findinL)
	else: findin_end = findin.find(findwhat2, findin_startN, findin_startN + findwhatLN)
	findin_endS = str(findin_end)
	findin_endN = int(findin_endS) + findwhat2LN
	'''---------------------------'''
	findin_startN = int(findin_startS) #SOME KIND OF BUG? BUT WORKING THIS WAY!
	found = findin[findin_startN:findin_endN]
	foundS = str(found)
	'''---------------------------'''
	try:
		foundF = float(foundS)
		found2 = round(foundF)
		found2S = str(found2)
		if ".0" in found2S: found2S = found2S.replace(".0","",1)
	except: pass
	
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "find_string" + space + "findin" + space2 + findin + space + "(" + findinLS + ")" + space + "findwhat" + space2 + findwhat + space + "(" + findwhatLS + ")" + space +  "findin_startS" + space2 + findin_startS + space + "findin_endS" + space2 + findin_endS + space + "foundS" + space2 + foundS + space
	'''---------------------------'''
	return foundS
	
def HelpButton_Video_Pic(name, path2):
	if id10str != "C" and id10str != "": dialogok('[COLOR=Yellow]' + addonString(124) % (id10str) + '[/COLOR]', addonString(125),addonString(126) % (name.decode('utf-8')),"")
	if id10str == "C": dialogok('[COLOR=Yellow]' + addonString(124) % (id10str) + '[/COLOR]', addonString(127),addonString(126) % (name.decode('utf-8')),"")
	if id10str != "C":
		returned = dialogyesno(addonString(134) % (name.decode('utf-8')),addonString(135) % (name.decode('utf-8')))
		if returned == "ok":
			header = '[COLOR=Yellow]' + addonString(129) % (name.decode('utf-8')) + '[/COLOR]'
			message2 = addonString(132) % (name.decode('utf-8'), path2, name.decode('utf-8')) + addonString(128)
			w = TextViewer_Dialog('DialogTextViewer.xml', "", header=header, text=message2)
			w.doModal()
			
			header = '[COLOR=Yellow]' + addonString(136) % (name.decode('utf-8')) + '[/COLOR]'
			message2 = addonString(137) % ("\\\\" + "htpt", path2, name.decode('utf-8'), name.decode('utf-8')) + addonString(128)
			w = TextViewer_Dialog('DialogTextViewer.xml', "", header=header, text=message2)
			w.doModal()
			'''---------------------------'''
			
def topvideoinformation2(admin):
	'''------------------------------
	---Clear ListItem----------------
	------------------------------'''
	containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
	listitemtvshowtitlestr = xbmc.getInfoLabel('Skin.String(ListItemTVShowTitle)')
	'''---------------------------'''
	if not "videodb://tvshows" in containerfolderpath and not "library://video/tvshows" in containerfolderpath:
		setSkinSetting("0",'ListItemGenre',"")
		setSkinSetting("0",'ListItemDuration',"")
		setSkinSetting("0",'ListItemRating',"")
		setSkinSetting("0",'ListItemYear',"")
		setSkinSetting("0",'ListItemTVShowTitle',"")
		if listitemtvshowtitlestr: print printfirst + "topvideoinformation2" + space2 + "Clear ListItem"
		'''---------------------------'''
	
def settingschange(window,systemgetbool,falsetrue,force,string1,string2):
	'''systemgetbool'''
	systemgetbool2 = xbmc.getCondVisibility('System.GetBool('+ systemgetbool +')')
	systemgetbool2str = str(systemgetbool2)
	if systemgetbool2str != falsetrue or force == 'yes':
		if admin: xbmc.executebuiltin('Notification(Admin,settingschange '+ systemgetbool +' ('+ systemgetbool2str +'),10000)')
		xbmc.executebuiltin('ActivateWindow('+ window +')')
		'''Right'''
		systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
		if not string1 in systemcurrentcontrol:
			xbmc.executebuiltin('Action(Right)')
			xbmc.sleep(100)
			systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
			if not string1 in systemcurrentcontrol:
				xbmc.executebuiltin('Action(Right)')
				xbmc.sleep(100)
				systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
				if not string1 in systemcurrentcontrol:
					xbmc.executebuiltin('Action(Right)')
					xbmc.sleep(100)
					systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
					if not string1 in systemcurrentcontrol:
						xbmc.executebuiltin('Action(Right)')
						xbmc.sleep(100)
						systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
		xbmc.sleep(40)
		if string1 in systemcurrentcontrol: xbmc.executebuiltin('Action(Down)')
		
		'''Down'''
		xbmc.sleep(100)
		systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
		if not string2 in systemcurrentcontrol:
			xbmc.executebuiltin('Action(Down)')
			xbmc.sleep(100)
			systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
			if not string2 in systemcurrentcontrol:
				xbmc.executebuiltin('Action(Down)')
				xbmc.sleep(100)
				systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
				if not string2 in systemcurrentcontrol:
					xbmc.executebuiltin('Action(Down)')
					xbmc.sleep(100)
					systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
					if not string2 in systemcurrentcontrol:
						xbmc.executebuiltin('Action(Down)')
						xbmc.sleep(100)
						systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
		xbmc.sleep(40)
		
		'''Select'''
		systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
		if string2 in systemcurrentcontrol:
			xbmc.executebuiltin('Action(Select)')
			xbmc.sleep(100)
			if systemgetbool2 != falsetrue and force == 'yes': xbmc.executebuiltin('Action(Select)')
			systemgetbool2 = xbmc.getCondVisibility('System.GetBool('+ systemgetbool +')')
			if admin: xbmc.sleep(1000)
			if systemgetbool2 != falsetrue and force == 'yes' or force == 'no': xbmc.executebuiltin('Action(Back)')
			if not systemgetbool2: xbmc.executebuiltin('Notification('+ systemcurrentcontrol +',,5000)')

def settingslevelset(custom):
	'''custom: 1 = Basic, 2 = Standard, 3 = Advanced, 4 = Expert'''
	if custom == "1": custom = settingslevelstr1
	elif custom == "2": custom = settingslevelstr2
	elif custom == "3": custom = settingslevelstr3
	elif custom == "4": custom = settingslevelstr4
	else: sys.exit(1)
	'''---------------------------'''
	printpoint = ""
	settingslevel = xbmc.getInfoLabel('Skin.String(SettingsLevel)')
	'''---------------------------'''
	if settingslevel != custom:
		controlhasfocus = findin_controlhasfocus("0","20",40,'Control.SetFocus(20)','')
		count = 0
		while count < 5 and not controlhasfocus and not xbmc.abortRequested:
			if count == 0: printpoint = printpoint + "2"
			controlhasfocus = findin_controlhasfocus("0","20",40,'Control.SetFocus(20)','')
			count += 1
			'''---------------------------'''
		if controlhasfocus:
			printpoint = printpoint + "3"
			count = 0
			while count < 5 and settingslevel != custom and not xbmc.abortRequested:
				if count == 0: printpoint = printpoint + "5"
				count += 1
				systemcurrentcontrol = findin_systemcurrentcontrol("0",custom,10,'Action(Select)','Action(Down)')
				settingslevel = xbmc.getInfoLabel('Skin.String(SettingsLevel)')
				'''---------------------------'''
		else: printpoint = printpoint + "9"
	else:
		printpoint = printpoint + "8"
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "settingslevelset_LV" + printpoint
	'''---------------------------'''
	
def adultbutton2_(admin):
	if systemhasaddon_videodevil: xbmc.executebuiltin('RunAddon(plugin.video.videodevil)')
	else: xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.videodevil)')
	'''---------------------------'''
def gamesbutton_(admin):
	if admin: xbmc.executebuiltin('Notification(Admin,gamesbutton,1000)')
	if not systemhasaddon_htptemu: xbmc.executebuiltin('ActivateWindow(10001,plugin://script.htpt.emu/)')
	if not systemplatformwindows: os.system('sh /storage/.kodi/addons/script.htpt.emu/specials/scripts/launcher.sh')
	xbmc.executebuiltin('RunAddon(plugin.program.advanced.launcher)')
	xbmc.sleep(2000)
	systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
	containernumitems = xbmc.getInfoLabel('Container.NumItems')
	if (systemcurrentcontrol == "[..]" or systemcurrentcontrol == "[Default]") and (containernumitems == "0" or containernumitems == "1"):
		print printfirst + space + "gamesbutton" + space + "Possible Error in file: launcher.xml"
		dialogok(addonString(130).encode('utf-8'),addonString(131).encode('utf-8'),"","")
		if not systemplatformwindows: os.system('sh /storage/.kodi/addons/script.htpt.emu/specials/scripts/copyemu.sh')
		xbmc.executebuiltin('ActivateWindow(Home.xml)')
		xbmc.sleep(2000)
		xbmc.executebuiltin('RunAddon(plugin.program.advanced.launcher)')
		'''---------------------------'''
def backward(run2):
	#viewmode = xbmc.getInfoLabel('Container.Viewmode')
	#if viewmode == 'GeneralPT' : xbmc.executebuiltin('Control.SetFocus(50,0)')
	#if viewmode == 'IconsPT' : xbmc.executebuiltin('Control.SetFocus(58,0)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(Select)')
	xbmc.sleep(2000)

def setGeneral_ScriptON(custom, General_ScriptON):
	'''check if this script is already running'''
	if not validation2:
		if custom == "0":
			'''------------------------------
			---SCRIPT-START------------------
			------------------------------'''
			count = 0
			if General_ScriptON == "true":
				'''------------------------------
				---General_ScriptON-TRUE->FALSE--
				------------------------------'''
				while (General_ScriptON == "true" and count <= 3) and not xbmc.abortRequested:
					if count > 0 and not startup_aW:
						if count == 1: notification(addonString(119) + ".", "", "", 1000)
						elif count == 2: notification(addonString(119) + "..", "", "", 1000)
						#elif count == 3: notification(addonString(119) + "...", "", "", 1000)
						'''---------------------------'''
					xbmc.sleep(500)
					count += 1
					countS = str(count)
					General_ScriptON = getsetting('General_ScriptON')
					systemidle1 = xbmc.getCondVisibility('System.IdleTime(1)')
					if General_ScriptON != "true" and systemidle1:
						setsetting_custom1(addonID,'General_ScriptON',"true")
						if admin: xbmc.executebuiltin('Notification(Admin,homebuttonsrunning2 '+ countS +',1000)')
						count = 5
					else:
						if count == 3 and systemidle1:
							setsetting_custom1(addonID,'General_ScriptON',"false")
							if admin: xbmc.executebuiltin('Notification(Admin,count == 3 and systemidle1 '+ countS +',1000)')
						if count > 1 and not systemidle1:
							if admin: xbmc.executebuiltin('Notification(Admin,count > 1 and not systemidle1 '+ countS +',1000)')
							if not admin: notification_common("11")
							sys.exit()
			else:
				'''------------------------------
				---General_ScriptON-FALSE->-TRUE-
				------------------------------'''
				setsetting_custom1(addonID,'General_ScriptON',"true")
				if admin: xbmc.executebuiltin('Notification(Admin,homebuttonsrunning,1000)')
				'''---------------------------'''
		elif custom == "1":
			'''------------------------------
			---SCRIPT-END--------------------
			------------------------------'''
			count = 0
			while General_ScriptON != "true" and count < 3 and not xbmc.abortRequested:
				xbmc.sleep(500)
				count += 1
				countS = str(count)
				if admin: xbmc.executebuiltin('Notification(Admin,homebuttonsrunning -end '+ countS +',500)')
				General_ScriptON = getsetting('General_ScriptON')
				'''---------------------------'''
			if General_ScriptON == "true":
				setsetting_custom1(addonID,'General_ScriptON',"false")
				if admin: xbmc.executebuiltin('Notification(Admin,homebuttonsrunning -end,1000)')
				sys.exit()
				'''---------------------------'''

def findin_systemcurrentcontrol(custom,what,sleep,action,action2):
	'''action = not found | action2 = when found'''
	'''---------------------------'''
	systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
	
	if custom == "0" and (what != "" and systemcurrentcontrol != what and action != ""): xbmc.executebuiltin(''+ action +'')
	elif custom == "1" and (what != "" and not what in systemcurrentcontrol and action != ""): xbmc.executebuiltin(''+ action +'')
	'''---------------------------'''
	xbmc.sleep(sleep)
	systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
	xbmc.sleep(sleep)
	'''---------------------------'''
	if custom == "0" and (what != "" and systemcurrentcontrol == what and action2 != ""): xbmc.executebuiltin(''+ action2 +'')
	elif custom == "1" and (what != "" and what in systemcurrentcontrol and action2 != ""): xbmc.executebuiltin(''+ action2 +'')
	'''---------------------------'''
	return systemcurrentcontrol

def findin_controlhasfocus(custom,what,sleep,action,action2):
	'''action = not found | action2 = when found'''
	'''---------------------------'''
	what = str(what)
	custom = str(custom)
	if custom == "0": controlhasfocus = xbmc.getCondVisibility('Control.HasFocus('+ what +')')
	else:
		controlhasfocus = xbmc.getCondVisibility('ControlGroup('+ custom +').HasFocus('+ what +')')
	
	if (what != "" and not controlhasfocus and action != ""): xbmc.executebuiltin(''+ action +'')
	'''---------------------------'''
	xbmc.sleep(sleep)
	if custom == "0": controlhasfocus = xbmc.getCondVisibility('Control.HasFocus('+ what +')')
	else: controlhasfocus = xbmc.getCondVisibility('ControlGroup('+ custom +').HasFocus('+ what +')')
	#systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
	xbmc.sleep(sleep)
	'''---------------------------'''
	if (what != "" and controlhasfocus and action2 != ""): xbmc.executebuiltin(''+ action2 +'')
	'''---------------------------'''
	return controlhasfocus
	
def scc(action1, action2, condition1, condition2):
	'''Moving sequences'''
	systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
	if systemcurrentcontrol != condition1 and systemcurrentcontrol != condition2: action1
	systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
	if systemcurrentcontrol == condition1 or systemcurrentcontrol == condition2: action2
	systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
	#xbmc.sleep(500)
	if admin: xbmc.executebuiltin('Notification(Admin,scc,1000)')
	
def scc2(action1, action2, condition1, condition2):
	systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
	#xbmc.executebuiltin('Notification('+ allowjoystickstr1 +',1,1000)')
	if condition2 in condition1: action2
	elif not condition2 in condition1: action1

def resetnetwork(run):
	'''tweak and reload the network adapters'''
	xbmc.executebuiltin('Notification([COLOR Red] $VAR[CurrentMAC][/COLOR] $LOCALIZE[79061],$LOCALIZE[79062],5000)')
	if not systemplatformwindows: os.system('sh /storage/.kodi/addons/skin.htpt/specials/scripts/resetnetwork.sh')
	xbmc.sleep(1000)
	oewindow('run',"resetnetwork")

def oewindow(admin,name):
	xbmc.executebuiltin('RunScript(service.openelec.settings)')
	xbmc.sleep(500)
	'''1-system, 2-network, 3-connections, 4-services, 5-bluetooth, 6-about'''
	openelec1 = xbmc.getInfoLabel('$ADDON[service.openelec.settings 32002]')
	openelec2 = xbmc.getInfoLabel('$ADDON[service.openelec.settings 32000]')
	openelec3 = xbmc.getInfoLabel('$ADDON[service.openelec.settings 32100]')
	openelec4 = xbmc.getInfoLabel('$ADDON[service.openelec.settings 32001]')
	openelec5 = xbmc.getInfoLabel('$ADDON[service.openelec.settings 32331]')
	openelec6 = xbmc.getInfoLabel('$ADDON[service.openelec.settings 32196]')
	'''---------------------------'''
	'''mainwindow'''
	mainwindow = xbmc.getCondVisibility('Window.IsVisible(mainWindow.xml)')
	count = 0
	while count < 10 and not mainwindow and not xbmc.abortRequested:
		xbmc.sleep(100)
		count += 1
		mainwindow = xbmc.getCondVisibility('Window.IsVisible(mainWindow.xml)')
		xbmc.sleep(100)

	'''netsettingsbutton'''
	if name == 'netsettingsbutton' or name == 'resetnetwork':
		countbusy = 0
		while mainwindow and not xbmc.abortRequested:
			xbmc.sleep(200)
			mainwindow = xbmc.getCondVisibility('Window.IsVisible(mainWindow.xml)')
			systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
			dialogbusyW = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
			if not dialogbusyW:
				xbmc.sleep(100)
				dialogbusyW = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
				if not dialogbusyW:
					if systemcurrentcontrol == openelec1 or systemcurrentcontrol == openelec6: xbmc.executebuiltin('Action(Down)')
					elif systemcurrentcontrol == openelec4 or systemcurrentcontrol == openelec5: xbmc.executebuiltin('Action(Up)')
					if countbusy > 0: countbusy += -1
			if dialogbusyW: countbusy += 1
			xbmc.sleep(100)
			systemidle40 = xbmc.getCondVisibility('System.IdleTime(40)')
			if systemidle40 or countbusy >= 15: xbmc.executebuiltin('Action(Close)')
		print printfirst + "netsettingsbutton"
		'''---------------------------'''
	'''statusjoystick'''
	if name == 'statusjoystick':
		if admin: xbmc.executebuiltin('Notification(Admin,statusjoystick,1000)')
		while mainwindow and not xbmc.abortRequested:
			xbmc.sleep(200)
			mainwindow = xbmc.getCondVisibility('Window.IsVisible(mainWindow.xml)')
			systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
			if systemcurrentcontrol == openelec1 or systemcurrentcontrol == openelec2 or systemcurrentcontrol == openelec6: xbmc.executebuiltin('Action(Up)')
			elif systemcurrentcontrol == openelec3 or systemcurrentcontrol == openelec4: xbmc.executebuiltin('Action(Down)')
			elif systemcurrentcontrol == openelec5: xbmc.executebuiltin('Action(Right)')
			xbmc.sleep(100)
			systemidle40 = xbmc.getCondVisibility('System.IdleTime(40)')
			if systemidle40: xbmc.executebuiltin('Action(Close)')
			'''---------------------------'''
		print printfirst + "statusjoystick"

def externalusb(run):
	'''detect connected USB'''
	if not systemplatformwindows and myhtpt2:
		xbmc.sleep(40)
		if picturesbutton or videosbutton or startup_aW:
			os.system('sh /storage/.kodi/addons/skin.htpt/specials/scripts/externalusb.sh')
			#subprocess.call('/storage/.kodi/addons/script.htpt.homebuttons/specials/scripts/externalusb.sh', shell=True)
			xbmc.sleep(500)
		log = open('/storage/externalusb.log', 'r')
		rows = log.readlines()
		rowscountN = len(rows)
		rowscount = str(rowscountN)
		log.close()
		row1 = ""
		row2 = ""
		row3 = ""
		row4 = ""
		row5 = ""
		if rowscountN > 0: row1 = rows[0][:-1]
		if rowscountN > 1: row2 = rows[1][:-1]
		if rowscountN > 2: row3 = rows[2][:-1]
		if rowscountN > 3: row4 = rows[3][:-1]
		if rowscountN > 4: row5 = rows[4][:-1]
		if picturesbutton or videosbutton or startup_aW:
			if usb1str != row1: xbmc.executebuiltin('Skin.SetString(USB1,'+ row1 +')')
			if usb2str != row2: xbmc.executebuiltin('Skin.SetString(USB2,'+ row2 +')')
			if usb3str != row3: xbmc.executebuiltin('Skin.SetString(USB3,'+ row3 +')')
			if usb4str != row4: xbmc.executebuiltin('Skin.SetString(USB4,'+ row4 +')')
			if usb5str != row5: xbmc.executebuiltin('Skin.SetString(USB5,'+ row5 +')')
		if admin and rowscountN > 0: xbmc.executebuiltin('Notification(Admin,'+ rowscount +' '+ row1 +' ,1000)')
		path0 = 'special://userdata/library/'
		path1 = '/var/media/'+ row1 +'/'
		path2 = '/var/media/'+ row2 +'/'
		path3 = '/var/media/'+ row3 +'/'
		path4 = '/var/media/'+ row4 +'/'
		path5 = '/var/media/'+ row5 +'/'
		pathwin = 'special://home/external/'
		if rowscountN == 0 and myhtpt3: xbmc.executebuiltin('Skin.ToggleSetting(myHTPT3)')
		if rowscountN > 0 and not myhtpt3: xbmc.executebuiltin('Skin.ToggleSetting(myHTPT3)')
		xbmc.sleep(200)
		if (myvideonavW or mypicsW) and usbtoggle:
			#xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,)')
			#xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,)')
			if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path0 +')') and rowscountN > 0:
				if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path1 +'videos/,return)')
				if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path1 +'pictures/,return)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,1)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path1 +')')
			if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path1 +')') and rowscountN > 1:
				if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path2 +'videos/,return)')
				if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path2 +'pictures/,return)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,2)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path2 +')')
			if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path2 +')') and rowscountN > 2:
				if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path3 +'videos/,return)')
				if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path3 +'pictures/,return)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,3)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path3 +')')
			if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path3 +')') and rowscountN > 3:
				if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path4 +'videos/,return)')
				if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path4 +'pictures/,return)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,4)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path4 +')')
			if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path4 +')') and rowscountN > 4:
				if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path5 +'videos/,return)')
				if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path5 +'pictures/,return)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,5)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path5 +')')
			if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path1 +')') and rowscountN == 1:
				if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'videos/,return)')
				if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'pictures/,return)')
			if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path2 +')') and rowscountN == 2:
				if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'videos/,return)')
				if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'pictures/,return)')
			if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path3 +')') and rowscountN == 3:
				if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'videos/,return)')
				if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'pictures/,return)')
			if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path4 +')') and rowscountN == 4:
				if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'videos/,return)')
				if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'pictures/,return)')
			if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path5 +')') and rowscountN == 5:
				if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'videos/,return)')
				if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'pictures/,return)')
			xbmc.sleep(20)
			containernumitems = xbmc.getInfoLabel('Container.NumItems')
			if containernumitems == 0: xbmc.executebuiltin('Action(Select)')
			
def mac7(run,macaddress,maccon1,maccon2,maccon10,maccon11):
	'''VALIDATION PROOF'''
	validation2 = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION2)')
	printpoint = ""
	if (not maccon1 and not maccon2) or (not maccon10 and not maccon11):
		xbmc.sleep(200)
		xbmc.executebuiltin('Notification(MAC7,step 1,1000)')
		if (not maccon1 and not maccon2):
			#macaddress = xbmc.getInfoLabel('Network.MacAddress')
			xbmc.executebuiltin('Skin.SetString(MAC,'+ macaddress +')')
			xbmc.sleep(500)
			maccon1 = xbmc.getCondVisibility('StringCompare(Skin.String(MAC),Skin.String(MAC1))')
			maccon2 = xbmc.getCondVisibility('StringCompare(Skin.String(MAC),Skin.String(MAC2))')
			printpoint = printpoint + "1"
		else:
			maccon10 = xbmc.getCondVisibility('StringCompare(Control.GetLabel(700100),NONE)')
			maccon11 = xbmc.getCondVisibility('StringCompare(Control.GetLabel(700100),7000)')
			printpoint = printpoint + "2"
		xbmc.sleep(200)
		if (not maccon1 and not maccon2) or (not maccon10 and not maccon11):
			if validation5 == '0':
				xbmc.executebuiltin('Notification(Admin,MAC7,step 2,1000)')
				if not validation: xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION)')
				if not validation2: xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION2)')
				if not widget: xbmc.executebuiltin('Skin.ToggleSetting(Widget)')
				xbmc.executebuiltin('Notification($LOCALIZE[79080],For Support: [COLOR Yellow]$LOCALIZE[79081][/COLOR],5000,icons/shield.png)')
				if macaddress and not loginscreenW and home_pW: xbmc.executebuiltin('ReplaceWindow(LoginScreen.xml)')
				if validation and playerhasmedia: xbmc.executebuiltin('Action(Stop)')
				
				if not maccon1 and not maccon2 and validation and not macaddress and id9str != 'COPIED':
					xbmc.executebuiltin('Skin.SetString(ID9,COPIED)')
					xbmc.executebuiltin('Notification(COPIED,,5000)')
					xbmc.executebuiltin('ReplaceWindow(LoginScreen.xml)')
				printpoint = printpoint + "3"
			else:
				if validation5 == '3': xbmc.executebuiltin('Skin.SetString(VALIDATION5,2)')
				if validation5 == '2': xbmc.executebuiltin('Skin.SetString(VALIDATION5,1)')
				if validation5 == '1': xbmc.executebuiltin('Skin.SetString(VALIDATION5,0)')
				
				xbmc.executebuiltin('Notification(Admin MAC7:,-validation5 reduced from ('+ validation5 +')')
				printpoint = printpoint + "4"
	else:
		'''UNLOCK'''
		printpoint = printpoint + "5"
		if validation2:
			printpoint = printpoint + "6"
			if hasinternet:
				xbmc.sleep(3000)
				xbmc.executebuiltin('Notification($LOCALIZE[79086],$LOCALIZE[79084],3000,icons/shield.png)')
				xbmc.sleep(1000)
				validation2 = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION2)')
				if validation2: xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION2)')
				printpoint = printpoint + "7"
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + space + "mac7_LV" + printpoint + space3
	'''---------------------------'''

def mac(run,macaddress):
	if validation and (home_aW or startup_aW or startup_pW or loginscreenbutton):
		print printfirst + "mac (1)"
		xbmc.sleep(40)
		if macaddress and macaddress != busystr:
			macaddress = xbmc.getInfoLabel('Network.MacAddress')
			xbmc.executebuiltin('Skin.SetString(MAC,'+ macaddress +')')
			xbmc.sleep(500)
		if not validation2: xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION2)')
		if validation5 == '3':
			xbmc.executebuiltin('Skin.SetString(VALIDATION5,2)')
			xbmc.executebuiltin('AlarmClock(HTPTCHECK: '+ idstr +'*0 | '+ id1str +'*1 | '+ id2str +'*2 | '+ id3str +'*3 | '+ id4str +'*4 | '+ id5str +'*5 | '+ id6str +'*6 | '+ id7str +'*7 | '+ id8str +'*8 | '+ id9str +'*9 | '+ id10str +'*10 | '+ mac1str +'*MAC1 | '+ mac2str +'*MAC2 | '+ mac3str +'*MAC3 | '+ macaddress +'*MAC | '+ systemtotaluptime +'*TOTALUPTIME | '+ verrorstr +'*VERROR | ,Action(Stop),0,silent)')
			if not connected2 and not connected3 and systemuptime5: xbmc.executebuiltin('AlarmClock(loginscreendelay,ReplaceWindow(LoginScreen.xml),00:02,silent)')
		if validation5 == '2':
			xbmc.executebuiltin('Skin.SetString(VALIDATION5,1)')
			if not maccon10 and not maccon11 and home_aW: xbmc.executebuiltin('Notification($LOCALIZE[79080],$LOCALIZE[257]: $VAR[VERROR],5000,icons/shield.png)')
		if validation5 == '1':
			xbmc.executebuiltin('Skin.SetString(VALIDATION5,0)')
			xbmc.executebuiltin('Notification($LOCALIZE[79080],For Support: [COLOR Yellow]$LOCALIZE[79081][/COLOR],5000,icons/shield.png)')
		if validation5 == '0':
			if not loginscreenW: xbmc.executebuiltin('ReplaceWindow(LoginScreen.xml)')
			if loginscreen_aW: xbmc.executebuiltin('Notification($LOCALIZE[79080],For Support: [COLOR Yellow]$LOCALIZE[79081][/COLOR],5000,icons/shield.png)')
		xbmc.sleep(40)
		'''UNLOCK SYSTEM'''
		if (maccon1 or maccon2) and (maccon10 or maccon11):
			xbmc.sleep(40)
			print printfirst + "mac (2)"
			xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION)')
			if not widget: xbmc.executebuiltin('Skin.ToggleSetting(Widget)')
			xbmc.executebuiltin('Skin.SetString(VALIDATION5,3)')
			#xbmc.sleep(500)
			if hasinternet:
				xbmc.sleep(40)
				xbmc.executebuiltin('Notification($LOCALIZE[79083],$LOCALIZE[79082],5000,icons/shield2.png)')
				mac7('run',macaddress,maccon1,maccon2,maccon10,maccon11)
			else:
				xbmc.executebuiltin('Notification($LOCALIZE[79083],$LOCALIZE[24073],5000,icons/shield2.png)')
			#if home_aW:
				#xbmc.executebuiltin('Control.SetFocus('+ container9000pos +')')
				#xbmc.sleep(500)
				#if admin: xbmc.executebuiltin('Notification(Admin, '+ container9000pos +',2000,icons/shield2.png)')
				#xbmc.executebuiltin('Action(Select)')
			if loginscreen_aW:
				#xbmc.executebuiltin('ActivateWindow(0)')
				xbmc.executebuiltin('ReplaceWindow(0)')
				
'''------------------------------
---DEFAULT-----------------------
------------------------------'''
def bash(bashCommand,bashname):
	'''------------------------------
	---RUN-BASH-COMMANDS-------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	if not systemplatformwindows:
		#process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
		process = subprocess.Popen(bashCommand,stdout=subprocess.PIPE,shell=True)
		output = process.communicate()[0]
		'''---------------------------'''
		
		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		if admin: print printfirst + bashname + space2 + output	
		'''---------------------------'''
		return output

def get_daynow(custom):
	daynow = datenow.strftime("%a")
	daynowS = str(daynow)
	return daynowS

def get_timenow(custom):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	customS = str(custom)
	timenow = datetime.datetime.now()
	timenow3 = timenow.strftime("%H")
	timenow3S = str(timenow3)
	timenow3N = int(timenow3)
	'''---------------------------'''
	if timenow3N > 03 and timenow3N < 12: timezone = "A"
	elif timenow3N > 11 and timenow3N < 20: timezone = "B"
	elif timenow3N > 19 or timenow3N < 04: timezone = "C"
	if admin: notification("get_timenow",timenow3S + timezone,"",1000)
	if custom == 1:
		'''------------------------------
		---TIMEZONE----------------------
		------------------------------'''
		return timezone
		'''---------------------------'''
	else:
		return "NONE"
		
def dialogok(heading,line1,line2,line3):
	'''------------------------------
	---DIALOG-OK---------------------
	------------------------------'''
	dialog = xbmcgui.Dialog()
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	if '$LOCALIZE' in line1 or '$ADDON' in line1: line1 = xbmc.getInfoLabel(line1)
	if '$LOCALIZE' in line2 or '$ADDON' in line2: line2 = xbmc.getInfoLabel(line2)
	if '$LOCALIZE' in line3 or '$ADDON' in line3: line3 = xbmc.getInfoLabel(line3)
	try: heading = str(heading.encode('utf-8'))
	except: pass
	try: line1 = str(line1.encode('utf-8'))
	except: pass
	try: line2 = str(line2.encode('utf-8'))
	except: pass
	try: line3 = str(line3.encode('utf-8'))
	except: pass

	dialog.ok(heading,line1,line2,line3)
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + heading + space2 + line1 + space2 + line2 + space2 + line3
	'''---------------------------'''

def dialogprogress(heading,line1,line2,line3): 
	'''------------------------------
	---DIALOG-OK-***BROKEN***--------
	------------------------------'''
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	if '$LOCALIZE' in line1 or '$ADDON' in line1: line1 = xbmc.getInfoLabel(line1)
	if '$LOCALIZE' in line2 or '$ADDON' in line2: line2 = xbmc.getInfoLabel(line2)
	if '$LOCALIZE' in line3 or '$ADDON' in line3: line3 = xbmc.getInfoLabel(line3)
	heading = str(heading.encode('utf-8'))
	line1 = str(line1.encode('utf-8'))
	line2 = str(line2.encode('utf-8'))
	line3 = str(line3.encode('utf-8'))
	
	pDialog = xbmcgui.DialogProgress()
	#pDialog.create(heading,line1,line2,line3)
	pDialog.update(10,line1,line2,line3)
	
	#pDialog = xbmcgui.DialogProgressBG()
	#pDialog.create(heading, line1)
	
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "dialogprogress" + space2 + heading + space2 + line1 + space2 + line2 + space2 + line3
	'''---------------------------'''

def dialogselect(heading, list, autoclose):
	'''------------------------------
	---DIALOG-SELECT-----------------
	------------------------------'''
	'''autoclose = [opt] integer - milliseconds to autoclose dialog. (default=do not autoclose)'''
	dialog = xbmcgui.Dialog()
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	heading = str(heading).decode('utf-8').encode('utf-8')
	#heading = str(heading)
	returned = dialog.select(heading,list,autoclose)
	returned = int(returned)
	
	value = list[returned]
	value = str(value)
	
	#value = value.replace(" ","",1)
	#value = value.decode('utf-8').encode('utf-8')
	#value = str(value).decode('utf-8')
	#value = str(value).decode('utf-8').encode('utf-8')
	#value = value.decode('utf-8').encode('utf-8')
	
	if returned == -1: notification_common("9")

	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	returned = str(returned)
	print printfirst + heading + "( " + returned + " )" + space + "value" + space2 + value
	returned = int(returned)
	return returned, value
	'''---------------------------'''
	
def dialogkeyboard(input, heading, option, custom, addonsetting, addonsetting2):
	''''''
	if '$LOCALIZE' in heading: heading = xbmc.getInfoLabel(heading)
	dialog = xbmcgui.Dialog()
	keyboard = xbmc.Keyboard(input,heading,option)
	keyboard.doModal()
	returned = 'skip'
	if (keyboard.isConfirmed()):
		input2 = keyboard.getText()
		if custom == '1' and input2 != "": returned = 'ok'
		if custom == '2' and input2 == input: returned = 'ok'
		if custom == '3':
			if input2 != input and input2 != "" and option == 0: xbmc.executebuiltin('Notification('+ heading +': '+ input2 +',,4000)')
			if input2 != "": returned = 'ok'
			
		if option == 0: print printfirst + heading + space2 + input2 + " ( " + returned + " )"
		elif option != 0: print printfirst + heading + space2 + "*******" + " ( " + returned + " )"
	if returned == 'ok':
		returned == input2
		if addonsetting2 == "0": setsetting(addonsetting, input2)
		elif 'genesis' in addonsetting2:
			setsetting_genesis          = xbmcaddon.Addon('plugin.video.genesis').setSetting
			setsetting_genesis(addonsetting, input2)
		elif 'sdarot.tv' in addonsetting2:
			setsetting_sdarottv          = xbmcaddon.Addon('plugin.video.sdarot.tv').setSetting
			setsetting_sdarottv(addonsetting, input2)
	return returned

def dialognumeric(type,heading,input,custom,addonsetting):
	'''type: 0 = #, 1 = DD/MM/YYYY, 2 = HH:MM, 3 = #.#.#.#, message2 = heading, message1 = content'''
	if '$LOCALIZE' in heading: heading = xbmc.getInfoLabel(heading)
	try:
		input = int(input)
	except:
		input = 0
	returned = 'skip'
	try:
		if int(input) > 001000000 and int(input) < 9999999999 and input != "": input = str(input)
	except TypeError:
		input = 0
		print printfirst + "dialognumeric " + "except TypeError (1)"
	input = str(input)
	input2 = xbmcgui.Dialog().numeric(type, heading, input)
	try:
		if input2 != "": input2 = int(input2)
	except TypeError:
		xbmc.executebuiltin('Notification($LOCALIZE[257],$LOCALIZE[31406],2000)')
		sys.exit()
	if custom == '0':
		try:
			if input2 > 001000000 and input2 < 9999999999: returned = 'ok'
			elif input2 < 001000000 or input2 > 9999999999: returned = 'skip0'
		except TypeError:
			returned = 'skip'
	if custom == '1':
		if input2 != "": returned = 'ok'
	if custom == '2':
		if input2 == "": input2 = 0
		elif input2 != 0: returned = 'ok'
	#if type == '2' and input == message1: returned = 'ok'
	
	input = str(input)
	input2 = str(input2)
	print printfirst + heading + space2 + input2 + "( " + returned + " )"
	if returned == 'ok':
		if custom != "2":
			returned == input
			setsetting(addonsetting, input2)
		elif custom == "2":
			returned == input
			if returned == "": returned = 0
			setSkinSetting("0", addonsetting, input2)
			#setsetting(addonsetting, input2)
			
	return returned

def dialogyesno(heading,line1):
	'''------------------------------
	---DIALOG-YESNO------------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	if '$LOCALIZE' in line1 or '$ADDON' in line1: line1 = xbmc.getInfoLabel(line1)
	returned = 'skip'
	if dialog.yesno(heading,line1): returned = 'ok'
	
	try: heading = str(heading.encode('utf-8'))
	except: pass
	try: line1 = str(line1.encode('utf-8'))
	except: pass
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "dialogyesno" + space2 + heading + space3 + line1 + "( " + returned + " )"
	'''---------------------------'''
	return returned
	'''---------------------------'''

	
def notification_common(custom):
	if custom == "9": notification('$LOCALIZE[31406]','$LOCALIZE[31412]',"",2000) #HAPEULA BUTLA, LO BUTZHU SINUHIM
	elif custom == "10": notification('$LOCALIZE[79496]','$LOCALIZE[79497]' + "   -   " + '$LOCALIZE[79081]',"",4000) #AFSARUT ZOT NIMZET BEPITHU...
	elif custom == "11": notification('$LOCALIZE[257]', '$LOCALIZE[79078]', "", 1000)   #ERROR | NASE SHENIT KAHET
	elif custom == "12": notification('$LOCALIZE[78959]','$LOCALIZE[31407]',"",7000) #MATKIN HARHAVOT
	elif custom == "13": notification('$LOCALIZE[79072]',"...","",2000) #HAPEULA ISTAIMA BEHATZLAHA!
	elif custom == "100": notification(addonString(46),'[COLOR=Yellow]' + addonString(90) + '[/COLOR]' + space + addonString(2) + space,"",7000) #MVAZEH TIKUN YADANI (script.htpt.fix)
	
	
def notification(heading, message, icon, time):
	'''------------------------------
	---Show a Notification alert.----
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	'''heading : string - dialog heading | message : string - dialog message. | icon : [opt] string - icon to use. (default xbmcgui.NOTIFICATION_INFO/NOTIFICATION_WARNING/NOTIFICATION_ERROR) | time : [opt] integer - time in milliseconds (default 5000) | sound : [opt] bool - play notification sound (default True)'''
	
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	if '$LOCALIZE' in message or '$ADDON' in message: message = xbmc.getInfoLabel(message)
	
	icon = "misc/logo/logo8.png"
	
	dialog.notification(heading, message, icon, time)
	
	#if "addonString" in heading and not "+" in heading: heading = str(heading.encode('utf-8'))
	if "addonString" in heading: heading = str(heading.encode('utf-8'))
	elif '$LOCALIZE' in heading or '$ADDON' in heading: heading = str(heading)
	if "addonString" in message: message = str(message.encode('utf-8'))
	elif '$LOCALIZE' in message or '$ADDON' in message: message = str(message)
	
	time = str(time)
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin:
		try: print printfirst + "notification" + space2 + heading + space3 + message + space + time
		except: print printfirst + "notification" + "..."
		'''---------------------------'''

def addonsettings(name, addon,skinsettingS, skinsetting2S, usernameS, passwordS, set3,opt1,opt2,opt3):
	'''------------------------------
	---SET-USERNAME-AND-PASSWORD-----
	------------------------------'''
	getsetting_custom          = xbmcaddon.Addon(addon).getSetting
	setsetting_custom          = xbmcaddon.Addon(addon).setSetting
	
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	skinsetting = xbmc.getInfoLabel('Skin.HasSetting('+ skinsettingS +')')
	skinsetting2 = xbmc.getInfoLabel('Skin.String('+ skinsetting2S +')')
	#if setting_custom == truestr: setting_custom = "true"
	#else: setting_custom = "false"
	try: skinsetting2N = int(skinsetting2)
	except: skinsetting2N = 0
	username = getsetting_custom(usernameS)
	password = getsetting_custom(passwordS)
	setting3 = getsetting_custom(set3)
	printpoint = ""
	'''---------------------------'''
	if (skinsetting or id9str == trialstr or id2str == datenowS) and usernameS != "" and passwordS != "":
		if admin: notification("test0","","",1000)
		if ('htpt' in username and not "finalmakerr" in idstr) and idstr != username and id9str != trialstr and id2str != datenowS:
			'''------------------------------
			---SET-DEFAULT-------------------
			------------------------------'''
			setsetting_custom(usernameS,idstr)
			setsetting_custom(passwordS,idpstr)
			printpoint = printpoint + "1"
			if admin: notification("test1","","",1000)
			'''---------------------------'''
		elif id9str == trialstr or id2str == datenowS:
			'''------------------------------
			---SET-TRIAL---------------------
			------------------------------'''
			setsetting_custom(usernameS,idtrial)
			setsetting_custom(passwordS,idp2str)
			printpoint = printpoint + "2"
			if admin: notification("test2","","",1000)
			'''---------------------------'''
		elif skinsetting and ((username == "" or password == "") or skinsetting2 == "0"):
			'''------------------------------
			---SET-NONE----------------------
			------------------------------'''
			setsetting_custom(usernameS,"")
			setsetting_custom(passwordS,"")
			printpoint = printpoint + "5"
			if admin: notification("test1.2","","",1000)
			'''---------------------------'''
		elif skinsetting:
			'''------------------------------
			---NO-CHANGES--------------------
			------------------------------'''
			printpoint = printpoint + "6"
			if admin: notification("test1.3","","",1000)
			'''---------------------------'''
	else:
		'''------------------------------
		---NO-ACCOUNT-OR-TRIAL-----------
		------------------------------'''
		daynowS = get_daynow(1)
		timezone = get_timenow(1)
		General_TimeZone = getsetting('General_TimeZone')
		if name == 'REALDEBRID' and (daynowS == opt1 or General_TimeZone != opt2):
			'''------------------------------
			---SET-NONE----------------------
			------------------------------'''
			setsetting_custom(usernameS,"")
			setsetting_custom(passwordS,"")
			printpoint = printpoint + "3"
			'''---------------------------'''
		else:
			'''------------------------------
			---SET-DEFAULT-------------------
			------------------------------'''
			setsetting_custom(usernameS,idstr)
			setsetting_custom(passwordS,idpstr)
			printpoint = printpoint + "4"
			'''---------------------------'''
			
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if printpoint == "0": print printfirst + "addonsettings LV_0" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "?"
	if printpoint == "1": print printfirst + "addonsettings LV_1" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "RESET"
	elif printpoint == "2": print printfirst + "addonsettings LV_2" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "Trial / DATENOW"
	elif printpoint == "3": print printfirst + "addonsettings LV_3" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "NONE" + space + "ID: " + idstr + space + "daynowS" + space2 + daynowS + space + "timenow3S" + space2 + timenow3S + space + "datenowS" + space2 + datenowS + space + "timezone" + space2 + timezone
	elif printpoint == "4": print printfirst + "addonsettings LV_4" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "DEFAULT" + space + "ID: " + idstr + space + "timezone" + space2 + timezone
	elif printpoint == "5": print printfirst + "addonsettings LV_5" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "skinsetting2" + space2 + skinsetting2 + "UNREGISTER"
	elif printpoint == "6": print printfirst + "addonsettings LV_6" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "REGISTERED"
	elif printpoint == "": print printfirst + "addonsettings LV_0-Error?"
	'''---------------------------'''
	
def addonsettings2(addon,set1,set1v,set2,set2v,set3,set3v,set4,set4v,set5,set5v):
	'''------------------------------
	---SET-ADDON-SETTING-5-----------
	------------------------------'''
	getsetting_custom          = xbmcaddon.Addon(addon).getSetting
	setsetting_custom          = xbmcaddon.Addon(addon).setSetting

	setting1 = getsetting_custom(set1)
	setting2 = getsetting_custom(set2)
	setting3 = getsetting_custom(set3)
	setting4 = getsetting_custom(set4)
	setting5 = getsetting_custom(set5)
	
	checkChange = "false"
	'''---------------------------'''
	if set1 != "" and set1v != setting1:
		setsetting_custom(set1,set1v)
		if checkChange != "true": checkChange = "true"
	if set2 != "" and set2v != setting2:
		setsetting_custom(set2,set2v)
		if checkChange != "true": checkChange = "true"
	if set3 != "" and set3v != setting3:
		setsetting_custom(set3,set3v)
		if checkChange != "true": checkChange = "true"
	if set4 != "" and set4v != setting4:
		setsetting_custom(set4,set4v)
		if checkChange != "true": checkChange = "true"
	if set5 != "" and set5v != setting5:
		setsetting_custom(set5,set5v)
		if checkChange != "true": checkChange = "true"
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if checkChange == "true": print printfirst + "addonsettings2 " + addon + space + set1 + space2 + set1v + space + set2 + space2 + set2v + space + set3 + space2 + set3v + space + set4 + space2 + set4v + space + set5 + space2 + set5v + space
	'''---------------------------'''
	
def setsetting_custom1(addon,set1,set1v):
	'''------------------------------
	---SET-ADDON-SETTING-1-----------
	------------------------------'''
	getsetting_custom          = xbmcaddon.Addon(addon).getSetting
	setsetting_custom          = xbmcaddon.Addon(addon).setSetting
	
	set = getsetting_custom(set1)
	'''---------------------------'''
	if set != set1v:
		setsetting_custom(set1,set1v)
		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		print printfirst + "setsetting_custom1" + space2 + addon + space + set1 + space2 + set1v + space3
		'''---------------------------'''
		
def setSkinSetting(custom,set1,set1v):
	'''------------------------------
	---SET-SKIN-SETTING-1------------
	------------------------------'''
	from variables import truestr
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	admin2 = xbmc.getInfoLabel('Skin.HasSetting(Admin2)')

	''' custom: 0 = Skin.String, 1 = Skin.HasSetting'''
	'''---------------------------'''
	if custom == "0":
		setting1 = xbmc.getInfoLabel('Skin.String('+ set1 +')')
		setting2 = ""
		if setting1 != set1v: xbmc.executebuiltin('Skin.SetString('+ set1 +','+ set1v +')')
		'''---------------------------'''
		
	elif custom == "1":
		setting2 = xbmc.getInfoLabel('Skin.HasSetting('+ set1 +')')
		if setting2 == truestr: setting1 = "true"
		else:
			setting1 = "false"
		if setting1 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set1 +')')
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if setting1 != set1v and admin and admin2: print printfirst + "setSkinSetting" + space3 + custom + space + set1 + space2 + setting1 + " - " + set1v + space3 + "( " + "setting2" + space2 + setting2 + " ) "
	'''---------------------------'''

def setSkinSetting5(custom,set1,set1v,set2,set2v,set3,set3v,set4,set4v,set5,set5v):
	'''------------------------------
	---SET-SKIN-SETTING-5------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	''' custom: 0 = Skin.String, 1 = Skin.HasSetting'''
	if custom == "0":
		setting1 = xbmc.getInfoLabel('Skin.String('+ set1 +')')
		setting2 = xbmc.getInfoLabel('Skin.String('+ set2 +')')
		setting3 = xbmc.getInfoLabel('Skin.String('+ set3 +')')
		setting4 = xbmc.getInfoLabel('Skin.String('+ set4 +')')
		setting5 = xbmc.getInfoLabel('Skin.String('+ set5 +')')
	elif custom == "1":
		setting1 = xbmc.getInfoLabel('Skin.HasSetting('+ set1 +')')
		setting2 = xbmc.getInfoLabel('Skin.HasSetting('+ set2 +')')
		setting3 = xbmc.getInfoLabel('Skin.HasSetting('+ set3 +')')
		setting4 = xbmc.getInfoLabel('Skin.HasSetting('+ set4 +')')
		setting5 = xbmc.getInfoLabel('Skin.HasSetting('+ set5 +')')
	'''---------------------------'''
	if custom == "0":
		if setting1 != set1v: xbmc.executebuiltin('Skin.SetString('+ set1 +','+ set1v +')')
		if setting2 != set2v: xbmc.executebuiltin('Skin.SetString('+ set2 +','+ set2v +')')
		if setting3 != set3v: xbmc.executebuiltin('Skin.SetString('+ set3 +','+ set3v +')')
		if setting4 != set4v: xbmc.executebuiltin('Skin.SetString('+ set4 +','+ set4v +')')
		if setting5 != set5v: xbmc.executebuiltin('Skin.SetString('+ set5 +','+ set5v +')')
	elif custom == "1":
		if setting1 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set1 +')')
		if setting2 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set2 +')')
		if setting3 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set3 +')')
		if setting4 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set4 +')')
		if setting5 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set5 +')')
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''	
	if admin and (setting1 != set1v or setting2 != set2v or setting3 != set3v or setting4 != set4v or setting5 != set5v): print printfirst + "setSkinSetting5" + space2 + set1 + space + set2 + space + set3 + space + set4 + space + set5 + space3
	'''---------------------------'''
	
def calculate(addon,set1,custom):
	'''------------------------------
	---RETURN-CALCULATE-NUMBER-------
	------------------------------'''	
	getsetting_custom          = xbmcaddon.Addon(addon).getSetting
	setsetting_custom          = xbmcaddon.Addon(addon).setSetting
	
	set1v = getsetting_custom(set1)
	set1v = int(set1v)
	
	if custom == '1': set1v += 1
	elif custom == '2': set1v += -1
		
	set1v = str(set1v)
	setsetting_custom(set1, set1v)
	
	return set1v
	'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''	
	print printfirst + "calculate" + space + addon + space + set1 + space2 + set1v
	'''---------------------------'''
	
	
	
'''------------------------------
---CUSTOM------------------------
------------------------------'''
def diaogtextviewer(header,message):
	w = TextViewer_Dialog('DialogTextViewer.xml', "", header=header, text=message)
	w.doModal()
	
class TextViewer_Dialog(xbmcgui.WindowXMLDialog):
    ACTION_PREVIOUS_MENU = [9, 92, 10]

    def __init__(self, *args, **kwargs):
        xbmcgui.WindowXMLDialog.__init__(self)
        self.text = kwargs.get('text')
        self.header = kwargs.get('header')

    def onInit(self):
        self.getControl(1).setLabel(self.header)
        self.getControl(5).setText(self.text)

    def onAction(self, action):
        if action in self.ACTION_PREVIOUS_MENU:
            self.close()

    def onClick(self, controlID):
        pass

    def onFocus(self, controlID):
        passs