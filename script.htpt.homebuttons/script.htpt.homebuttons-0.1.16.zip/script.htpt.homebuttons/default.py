import xbmc
import os, sys
import subprocess
import xbmcgui, xbmcaddon

from variables import *
from modules import *
from modules2 import *

def leftmenu(run):
	'''left menu'''
	containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
	if not validation:
		'''searchisraeltv'''
		if myvideonavW and searchisraeltv:
			xbmc.executebuiltin('Action(Right)')
			if containerfolderpath != israeltvhome:
				backward('run2')
				containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
				if containerfolderpath != israeltvhome:
					backward('run2')
					containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
					if containerfolderpath != israeltvhome:
						backward('run2')
						containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
			if containerfolderpath == israeltvhome:
				xbmc.executebuiltin('Action(PageUp)')
				xbmc.executebuiltin('Action(PageUp)')
				xbmc.executebuiltin('Action(PageUp)')
				xbmc.executebuiltin('Action(Down)')
				xbmc.executebuiltin('Action(Select)')
			print printfirst + "searchisraeltv"
		'''deletesearchyoutube'''
		#if myvideonavW and deletesearchyoutube:
			#Z = 'special://userdata/addon_data/plugin.video.youtube/settings.xml'
			#if admin: xbmc.executebuiltin('Notification(Admin,deletesearchyoutube,1000)')
			#A = '"store_searches" value='
			#B = '"[^ ]*"'
			#bash('sed -i "s|a|b|g" z,"deletesearchyoutube")
			#xbmc.executebuiltin('Action(Right)')
		'''statusjoystick'''
		if myprogramsW:
			'''------------------------------
			---MYPROGRAMS.NAV-IS-VISIBLE-----
			------------------------------'''
			if containerfoldername == "Advanced Launcher":
				'''------------------------------
				---EMULATORS---------------------
				------------------------------'''
				if statusjoystick: oewindow(admin,'statusjoystick')
				'''allowjoystick'''
				if myprogramsW and allowjoystick:
					print printfirst + "allowjoystick"
					settingschange('SystemSettings','input.enablejoystick','1','yes',xbmc.getInfoLabel('$LOCALIZE[14094]'),xbmc.getInfoLabel('$LOCALIZE[35100]'))
				if leftmenubutton110:
					'''------------------------------
					---EMULATOR-ADVANCED-SETTINGS----
					------------------------------'''
					if admin: xbmc.executebuiltin('Notification(Admin,EMULATOR-ADVANCED-SETTINGS,1000)')
					if not systemhasaddon_htptemu: xbmc.executebuiltin('ActivateWindow(10001,plugin://script.htpt.emu/)')
					else:
						xbmc.executebuiltin('RunScript(script.htpt.emu)')
		if helpbutton:
			if mypicsW:
				HelpButton_Video_Pic(str1, 'pictures')
			elif (myvideonavW and myvideopath):
				HelpButton_Video_Pic(str3, 'videos')
				
		'''70'''
		if (myvideonavW or mypicsW) and usbtoggle:
			if admin: xbmc.executebuiltin('Notification(Admin,usbtoggle,1000)')
			#videopath0 = xbmc.getCondVisibility('SubString(Container.FolderPath,special://userdata/library/videos/)')
			externalusb('run')
			if systemplatformwindows:
				path0 = 'special://userdata/library/'
				pathwin = 'special://home/external/'
				if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path0 +')'):
					if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ pathwin +'videos/,return)')
					if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ pathwin +'pictures/,return)')
				if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ pathwin +')'):
					if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'videos/,return)')
					if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'pictures/,return)')
			print printfirst + "usbtoggle"
		if myvideonavW and numinumibutton:
			pl=xbmc.PlayList(1)
			pl.clear()
			count = 0
			while count < 7 and not xbmc.abortRequested:
				xbmc.sleep(10)
				count += 1
				listitem = xbmcgui.ListItem(numinumistr,
				thumbnailImage='special://skin/media/icons/kids.png')
				url = 'special://userdata/addon_data/skin.htpt/video/numinumi.mp4'
				xbmc.PlayList(1).add(url, listitem)

			xbmc.Player().play(pl)
			xbmc.executebuiltin('Action(Right)')
			xbmc.executebuiltin('Action(PageUp)')
			xbmc.executebuiltin('Action(FullScreen)')
	else:
		if admin: xbmc.executebuiltin('Notification(Admin,no buttonproceed,1000)')

		
def miscbuttons(admin):

	if smartsearchbutton:
		import json
		dialogkeyboard = xbmc.getCondVisibility('Window.IsVisible(DialogKeyboard.xml)')
		if admin: xbmc.executebuiltin('Notification(Admin,smartsubsearch,1000)')
		isTV = 'false'
		isMovie = 'false'
		input = ""
		playertitle = xbmc.getInfoLabel('Player.Title')
		videoplayertitle = xbmc.getInfoLabel('VideoPlayer.Title')
		tvshowtitle = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
		videoplayervideoresolution = xbmc.getInfoLabel('VideoPlayer.VideoResolution')
		videoplayervideocodec = xbmc.getInfoLabel('VideoPlayer.VideoCodec')
		season = xbmc.getInfoLabel('VideoPlayer.Season')
		episode = xbmc.getInfoLabel('VideoPlayer.Episode')
		title = xbmc.getInfoLabel('VideoPlayer.Title')
		year = xbmc.getInfoLabel('VideoPlayer.Year')
		country = xbmc.getInfoLabel('VideoPlayer.Country')
		tagline = xbmc.getInfoLabel('VideoPlayer.Tagline')
		if tvshowtitle != "" and season != "" and episode != "": isTV = 'true'
		elif title != "" and (year != "" or country != "" or tagline != ""): isMovie = 'true'
		xbmc.sleep(40)
		print printfirst + "dialogsubtitles: " + "tvshowtitle = " + tvshowtitle + " | season = " + season + " | episode = " + episode + " | title = " + title + " | year = " + year + " | videoplayertitle = " + videoplayertitle + space + "playertitle =" + playertitle + space + "VideoCodec" + space2 + videoplayervideocodec + space + "VideoResolution" + space2 + videoplayervideoresolution
		'''tvshow/movie?'''
		if isMovie == 'true': input = title + space + year + space + videoplayervideoresolution + space + videoplayervideocodec
		elif videoplayertitle != "": input = videoplayertitle
		elif isTV == 'true':
			seasonN = int(season)
			episodeN = int(episode)
			if seasonN < 10 and episodeN < 10: input = tvshowtitle + " " + 'S0' + season + 'E0' + episode
			if seasonN > 10 and episodeN > 10: input = tvshowtitle + " " + 'S' + season + 'E' + episode
			if seasonN > 10 and episodeN < 10: input = tvshowtitle + " " + 'S' + season + 'E0' + episode
			if seasonN < 10 and episodeN > 10: input = tvshowtitle + " " + 'S0' + season + 'E' + episode
		
		xbmc.executebuiltin('SendClick(160)')
		xbmc.sleep(1000)
		xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ input +'","done":false}}')
	#else:
		#if admin: xbmc.executebuiltin('Notification(Admin,NO smartsubsearch,1000)')
	if subsliderbutton:
		'''------------------------------
		---subslider---------------------
		------------------------------'''
		if admin: notification("admin: " + "subsliderbutton","","",1000)
		if systemplatformwindows: filepath = "Z:\\addons\\script.htpt.homebuttons\\specials\\scripts\\subslider.py"
		if not systemplatformwindows: filepath = "/storage/.kodi/addons/script.htpt.homebuttons/specials/scripts/subslider.py"
		xbmc.executebuiltin('RunScript('+ filepath +', -10)')
		'''---------------------------'''
		
	if custom1125W:
		import json
		#if admin: xbmc.executebuiltin('Notification(Admin,custom1125,1000)')
		#if (keyboard.isConfirmed()):
		#xel = xbmcgui.Window(xbmcgui.getCurrentWindowId())
		#dialog = xbmcgui.Dialog()        
		keyboard = xbmc.Keyboard()
		input = keyboard.getText()
		xbmc.executebuiltin('Notification(INPUT?,'+ input +',5000)')
		
		print printfirst + "custom1125: " + "input = " + input
		smartkeyboardcopy = xbmc.getCondVisibility('Control.HasFocus(202)')
		smartkeyboardhistory = xbmc.getCondVisibility('Control.HasFocus(201)')
		smartkeyboardpaste = xbmc.getCondVisibility('Control.HasFocus(204)')
		'''copy button'''
		if smartkeyboardcopy:
			'''variable'''
			smartkeyboardPN = xbmc.getInfoLabel('Skin.String(smartkeyboardPN)')
			smartkeyboardC1 = xbmc.getInfoLabel('Skin.String(smartkeyboardC1)')
			smartkeyboardC2 = xbmc.getInfoLabel('Skin.String(smartkeyboardC2)')
			smartkeyboardC3 = xbmc.getInfoLabel('Skin.String(smartkeyboardC3)')
			smartkeyboardC4 = xbmc.getInfoLabel('Skin.String(smartkeyboardC4)')
			smartkeyboardC5 = xbmc.getInfoLabel('Skin.String(smartkeyboardC5)')
			'''execute'''
			#xbmc.executebuiltin('Action(Close)')
			#xbmc.sleep(200)
			if admin: xbmc.executebuiltin('Notification(Admin,smartkeyboardcopy,1000)')
			if smartkeyboardPN == '1': xbmc.executebuiltin('Skin.SetString(smartkeyboardC1,'+ input +')')
			if smartkeyboardPN == '2': xbmc.executebuiltin('Skin.SetString(smartkeyboardC2,'+ input +')')
			if smartkeyboardPN == '3': xbmc.executebuiltin('Skin.SetString(smartkeyboardC3,'+ input +')')
			if smartkeyboardPN == '4': xbmc.executebuiltin('Skin.SetString(smartkeyboardC4,'+ input +')')
			if smartkeyboardPN == '5': xbmc.executebuiltin('Skin.SetString(smartkeyboardC5,'+ input +')')
			xbmc.executebuiltin('SetFocus(3000)')
			
		elif smartkeyboardhistory:
			'''variable'''
			smartkeyboardHN = xbmc.getInfoLabel('Skin.String(smartkeyboardHN)')
			smartkeyboardH1 = xbmc.getInfoLabel('Skin.String(smartkeyboardH1)')
			smartkeyboardH2 = xbmc.getInfoLabel('Skin.String(smartkeyboardH2)')
			smartkeyboardH3 = xbmc.getInfoLabel('Skin.String(smartkeyboardH3)')
			smartkeyboardH4 = xbmc.getInfoLabel('Skin.String(smartkeyboardH4)')
			smartkeyboardH5 = xbmc.getInfoLabel('Skin.String(smartkeyboardH5)')
			'''execute'''
			xbmc.executebuiltin('Action(Close)')
			xbmc.sleep(200)
			#xbmc.executebuiltin('Action(
			if admin: xbmc.executebuiltin('Notification(Admin,smartkeyboardhistory,1000)')
			if smartkeyboardHN == '1': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH1 +'","done":false}}')
			if smartkeyboardHN == '2': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH2 +'","done":false}}')
			if smartkeyboardHN == '3': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH3 +'","done":false}}')
			if smartkeyboardHN == '4': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH4 +'","done":false}}')
			if smartkeyboardHN == '5': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH5 +'","done":false}}')
			xbmc.executebuiltin('SetFocus(3000)')
		elif smartkeyboardpaste:
			'''variable'''
			smartkeyboardPN = xbmc.getInfoLabel('Skin.String(smartkeyboardPN)')
			smartkeyboardC1 = xbmc.getInfoLabel('Skin.String(smartkeyboardC1)')
			smartkeyboardC2 = xbmc.getInfoLabel('Skin.String(smartkeyboardC2)')
			smartkeyboardC3 = xbmc.getInfoLabel('Skin.String(smartkeyboardC3)')
			smartkeyboardC4 = xbmc.getInfoLabel('Skin.String(smartkeyboardC4)')
			smartkeyboardC5 = xbmc.getInfoLabel('Skin.String(smartkeyboardC5)')
			'''execute'''
			xbmc.executebuiltin('Action(Close)')
			xbmc.sleep(200)
			if admin: xbmc.executebuiltin('Notification(Admin,smartkeyboardpaste,1000)')
			if smartkeyboardPN == '1': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC1 +'","done":false}}')
			if smartkeyboardPN == '2': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC2 +'","done":false}}')
			if smartkeyboardPN == '3': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC3 +'","done":false}}')
			if smartkeyboardPN == '4': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC4 +'","done":false}}')
			if smartkeyboardPN == '5': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC5 +'","done":false}}')
			xbmc.executebuiltin('SetFocus(3000)')
		
	if customhomecustomizerW:
		'''------------------------------
		---CustomHomeCustomizer----------
		------------------------------'''
		if button704:
			'''------------------------------
			---Startup-Window----------------
			------------------------------'''
			if container50button320 or container50button321:
			
				if container50button320:
					'''------------------------------
					---MOVIES------------------------
					------------------------------'''
					heading = str512 + space + str342
					list0 = "0. " + str20108 #root
					list1 = "1. " + addonString_genesis(30527).encode('utf-8') #Most Popular
					list2 = "2. " + addonString_genesis(30531).encode('utf-8') #Latest HD Movies
					list3 = "3. " + addonString_genesis(30535).encode('utf-8') #Search
					list4 = "4. " + addonString_genesis(30541).encode('utf-8') #Genres
					returned, value = dialogselect(heading,[list0, list1, list2, list3, list4],0)
					if returned != -1:
						setSkinSetting("0",'moviesestartup',str(returned))
						#setSkinSetting("0",'moviesestartup',value)
						'''---------------------------'''
					
				elif container50button321:
					'''------------------------------
					---TVSHOWS------------------------
					------------------------------'''
					heading = str512 + space + str20343
					list0 = "0. " + str20108 #root
					list1 = "1. " + addonString_genesis(30527).encode('utf-8') #Most Popular
					list2 = "2. " + addonString_genesis(30544).encode('utf-8') #Returning TV Shows
					list3 = "3. " + addonString_genesis(30535).encode('utf-8') #Search
					list4 = "4. " + addonString_genesis(30541).encode('utf-8') #Genres
					returned, value = dialogselect(heading,[list0, list1, list2, list3, list4],0)
					if returned != -1:
						setSkinSetting("0",'tvshowsestartup',str(returned))
						'''---------------------------'''
				
class main:
	setGeneral_ScriptON("0", General_ScriptON)
	mac('run',macaddress)
	if not validation and homeW: homebuttons(admin)
	if skinsettingsW: skinbuttons(admin)
	if custom1170W or loginscreenW: helpbuttons(admin)
	leftmenu('run')
	if netsettingsbutton: oewindow(admin,'netsettingsbutton')
	miscbuttons(admin)
	autoviewoff = xbmc.getInfoLabel('Skin.HasSetting(AutoViewoff)')
	if myvideonavW or mypicsW or mymusicnavW or myprogramsW or settingsW or filemanagerW or myweatherW or dialogfavouritesW:
		if home_pW and validation2: mac7('run',macaddress,maccon1,maccon2,maccon10,maccon11)
	if autoviewoff:
		print printfirst + "autoviewoff"
		xbmc.sleep(2000)
		xbmc.executebuiltin('Skin.ToggleSetting(AutoViewoff)')
	startup(validation)
	topvideoinformation2(admin)
	setGeneral_ScriptON("1", General_ScriptON)