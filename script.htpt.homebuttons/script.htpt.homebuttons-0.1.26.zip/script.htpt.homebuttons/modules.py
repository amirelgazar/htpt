import xbmc, xbmcgui, xbmcaddon
import subprocess, os, sys
from variables import *
from shared_modules import *
#from shared_modules2 import *
#from modules2 import *

def homebuttons(admin):
	'''activate home buttons'''
	if not validation and homeW:
		if moviesbutton:
			libraryhascontentmovies = xbmc.getCondVisibility('Library.HasContent(Movies)')
			if libraryhascontentmovies:
				if admin: xbmc.executebuiltin('Notification(Admin,moviesbutton,1000)')
				xbmc.executebuiltin('ActivateWindow(Videos,MovieTitles,return)')
			else:
				if not autoviewoff: xbmc.executebuiltin('Skin.ToggleSetting(AutoViewoff)')
				xbmc.executebuiltin('ActivateWindow(video,"special://userdata/library/movies/",return)')
				xbmc.executebuiltin('Notification($LOCALIZE[79079] $LOCALIZE[342] $LOCALIZE[79090],$LOCALIZE[79091],4000)')
				'''---------------------------'''
				if scripthtptsmartbuttonsLibraryData_LocalMoviesFiles == "0" or scripthtptsmartbuttonsLibraryData_LocalMoviesFiles == "": xbmc.executebuiltin('RunScript(script.htpt.smartbuttons,,?mode=55)')
				elif libraryisscanningvideo: pass
				else:
					setsetting_custom1('service.htpt.fix','Fix_100',"true")
					xbmc.executebuiltin('RunScript(service.htpt.fix,,?mode=3)')
					xbmc.executebuiltin('ActivateWindow(0)')
					'''---------------------------'''
				
		elif tvshowsbutton:
			libraryhascontenttvshows = xbmc.getCondVisibility('Library.HasContent(TVShows)')
			if libraryhascontenttvshows:
				if admin: xbmc.executebuiltin('Notification(Admin,tvshowsbutton,1000)')
				xbmc.executebuiltin('ActivateWindow(VideoLibrary,TVShowTitles,return)')
			else:
				if not autoviewoff: xbmc.executebuiltin('Skin.ToggleSetting(AutoViewoff)')
				xbmc.executebuiltin('ActivateWindow(video,"special://userdata/library/tvshows/",return)')
				xbmc.executebuiltin('Notification($LOCALIZE[79079] $LOCALIZE[20343] $LOCALIZE[79090],$LOCALIZE[79091],4000)')
				'''---------------------------'''
				if scripthtptsmartbuttonsLibraryData_LocalTvshowsFiles == "0": xbmc.executebuiltin('RunScript(script.htpt.smartbuttons,,?mode=55)')
				elif libraryisscanningvideo: pass
				else:
					setsetting_custom1('service.htpt.fix','Fix_101',"true")
					xbmc.executebuiltin('RunScript(service.htpt.fix,,?mode=3)')
					xbmc.executebuiltin('ActivateWindow(0)')
					'''---------------------------'''
				
		elif gamesbutton:
			'''------------------------------
			---GAMES-BUTTON------------------
			------------------------------'''
			printpoint = ""
			name = str15016.encode('utf-8')

			returned = supportcheck(name, ["A","A?","B","B?"], 200)
			if returned == "ok":
				addon = 'plugin.program.advanced.launcher'
				if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
					printpoint = printpoint + "7"
					'''---------------------------'''
				else:
					installaddon(admin, addon, "")
					'''---------------------------'''
				
				addon = 'script.htpt.emu'
				if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
					printpoint = printpoint + "7"
					'''---------------------------'''
				else:
					installaddon(admin, addon, "")
					'''---------------------------'''
				
				if "77" in printpoint: gamesbutton_(admin)
			
		elif picturesbutton or videosbutton:
			'''------------------------------
			---PICTURE-&-VIDEO-BUTTON--------
			------------------------------'''
			containernumitems = ""
			printpoint = ""
			name = ""
			path = ""
			
			
			returned = supportcheck(name, ["A", "B", "A?", "B?"], totalspace=100, Intel=False, silence=True)
			if returned == "ok": device = "0"
			else: device = "1"

			if picturesbutton:
				name = str1
				path2 = "pictures"
			elif videosbutton:
				name = str3
				path2 = "videos" 
			if device == "0": path = "special://userdata/library/" + path2 + "/"
			else:
				externalusb(device)
				usb1str = xbmc.getInfoLabel('Skin.String(USB1)')
				if usb1str == "" and not systemplatformwindows: printpoint = printpoint + "9"
				'''---------------------------'''
				if usb1str != "": path = varmedia_path + usb1str + '/' + path2
				elif systemplatformwindows: path = 'special://home/external/' + path2
				'''---------------------------'''
			if printpoint == "":
				if not os.path.exists(library_path + path2):
					os.mkdir(library_path + path2) ; xbmc.sleep(500)
					notification("Folder Created:", library_path + path2, "", 2000)
				xbmc.executebuiltin('ActivateWindow('+ path2 +','+ path +',return)')
				#xbmc.executebuiltin('ActivateWindow(Pictures,/var/media/'+ usb1str +',return)')
				#xbmc.executebuiltin('ActivateWindow(Pictures,special://userdata/library/pictures/,return)')
				if not admin and not playerhasmedia: xbmc.executebuiltin('PlayMedia(special://userdata/addon_data/skin.htpt/music/playHTPT.mp3)')
				'''---------------------------'''
				containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
				count = 0
				while count < 10 and containerfolderpath != path and not xbmc.abortRequested:
					'''------------------------------
					---containerfolderpath-----------
					------------------------------'''
					xbmc.sleep(100)
					count += 1
					containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
					xbmc.sleep(100)
					'''---------------------------'''
				containernumitems = xbmc.getInfoLabel('Container.NumItems')
				try: containernumitemsN = int(containernumitems)
				except: containernumitemsN = 0
				if device == "0": externalusb(device)
					
				if containernumitemsN < 2:
					containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
					count = 0
					while count < 10 and containerfolderpath == path and not xbmc.abortRequested:
						'''------------------------------
						---containerfolderpath-----------
						------------------------------'''
						xbmc.sleep(500)
						count += 1
						containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
						if count == 1: notification(addonString(120) % (name), addonString(121), "", 1000)
						elif count == 2: notification(addonString(120) % (name), addonString(121) + ".", "", 1000)
						elif count == 3: notification(addonString(120) % (name), addonString(121) + "..", "", 1000)
						elif count == 4: notification(addonString(120) % (name), addonString(121) + "...", "", 1000)
						if count == 5:
							HelpButton_Video_Pic(name, path2)
							
							
						xbmc.sleep(500)
						'''---------------------------'''
			if printpoint != "":
				if "9" in printpoint: dialogok('[COLOR=Yellow]' + addonString(138) + '[/COLOR]', addonString(124) % (id10str) + '[CR]' + addonString(127), addonString(139), addonString(128))
			if admin: print printfirst + "picturesbutton/videosbutton_LV" + printpoint + space2 + "containernumitems" + space2 + containernumitems + "id10str" + space2 + id10str
			
		elif favouritesbutton:
			if admin: xbmc.executebuiltin('Notification(Admin,favouritesbutton,1000)')
			xbmc.executebuiltin('ActivateWindow(134)')
			'''---------------------------'''
		elif settingsbutton:
			xbmc.executebuiltin('ActivateWindow(Settings.xml)')
			'''---------------------------'''
		elif widgettogglebutton:
			if admin: xbmc.executebuiltin('Notification(Admin,widgettogglebutton,1000)')
			if xbmc.getCondVisibility('Control.IsVisible(311)'):
				xbmc.executebuiltin('Skin.ToggleSetting(MoviesShelfWL)')
				xbmc.executebuiltin('ActivateWindow(Videos,MovieTitles)')
				xbmc.sleep(100)
				xbmc.executebuiltin('ReplaceWindow(0)')
				xbmc.executebuiltin('Control.SetFocus(9090)')
				'''---------------------------'''
			if xbmc.getCondVisibility('Control.IsVisible(312)'):
				xbmc.executebuiltin('Skin.ToggleSetting(TVShelf_Watchlist)')
				xbmc.executebuiltin('ActivateWindow(VideoLibrary,TVShowTitles)')
				xbmc.sleep(100)
				xbmc.executebuiltin('ReplaceWindow(0)')
				xbmc.executebuiltin('Control.SetFocus(9090)')
				'''---------------------------'''
		elif htptchannelbutton:
			#xbmc.executebuiltin('RunScript(script.toolbox,info=textviewer,header='+ message1 +',text='+ message2 +')')
			xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.youtube/channel/UCcYT8oPT83Yuw4_GUZ3mMFg/)')
			
			if os.path.exists(addons_path + 'skin.htpt/changelog.txt'):
				message = log.read()
				log.close()
				diaogtextviewer('[COLOR=Yellow]' + htptskinversion + '[/COLOR]' + addonString(19) + "-", message)
				'''---------------------------'''
			
		elif internetbutton:
			'''------------------------------
			---INTERNET-BUTTON---------------
			------------------------------'''
			name = str443.encode('utf-8')
			printpoint = ""
			returned = supportcheck(name, ["A","B"], 1, Intel=True)
				
			if returned == "ok":
				if connected or connected2 or connected3:
					addon = 'browser.chromium-browser'
					if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
						returned = dialogyesno(str79215,str79216)
						if returned == "ok":
							notification(str79217, str79218, "", 4000)
							settingschange('SystemSettings','input.enablemouse','1','no',xbmc.getInfoLabel('$LOCALIZE[14094]'),xbmc.getInfoLabel('$LOCALIZE[21369]'))
							xbmc.sleep(1000)
							if not systemplatformwindows: xbmc.executebuiltin('RunAddon(browser.chromium-browser)')
							'''---------------------------'''
						else:
							notification_common("8")
							#settingschange('SystemSettings','input.enablemouse','0','no',xbmc.getInfoLabel('$LOCALIZE[14094]'),xbmc.getInfoLabel('$LOCALIZE[21369]'))
							'''---------------------------'''
					else: installaddon(admin, addon, "")
					
				else: notification_common("4")

		elif connected:
			'''------------------------------
			---Require-Internet--------------
			------------------------------'''
			#if admin: print printfirst + space + "homebuttons internet" + space3
			if israeltvbutton:
				printpoint = ""
				if systemhasaddon_sdarottv:
					from shared_modules3 import urlcheck
					printpoint = printpoint + "1"
					returned = urlcheck('http://www.sdarot.wf', ping=False)

					if returned == "ok":
						printpoint = printpoint + "2"
						if admin and not admin2:
							if not systemplatformwindows:
								bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.video.sdarot.tv/sdarot-cookiejar.txt',"plugin.video.sdarot.tv - cookie")
								notification("DELETING COOKIE","","",1000)
								xbmc.sleep(1000)
								'''---------------------------'''
						else:
							addonsettings('SDAROT TV', 'plugin.video.sdarot.tv', 'Account2_Active', 'Account2_Period', 'username','user_password', "", "", "", "")
							addonsettings2('plugin.video.sdarot.tv','DEBUG',"false",'cache',"24",'domain',"http://www.sdarot.wf",'',"",'',"")
							'''---------------------------'''
						
						url = 'plugin://plugin.video.sdarot.tv/?mode=2&module=http%3a%2f%2fwww.sdarot.wf%2fseries%2fgenre%2f20%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99&name=%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99&url=all-heb'
						returned = ActivateWindow("1", 'plugin.video.sdarot.tv', url, 'return0', wait=False)
						if returned == "": ActivateWindow("0", 'plugin.video.sdarot.tv', url, 'return0', wait=False)
						
					else:
						'''------------------------------
						---WEBSITE-DOWN------------------
						------------------------------'''
						notification('[COLOR=Red]' + addonString(90) + '[/COLOR]',addonString(91),"",4000)
						xbmc.executebuiltin('Action(Close)')
						'''---------------------------'''
						
			elif goprobutton:
				if admin: xbmc.executebuiltin('Notification(Admin,goprobutton,1000)')
				if not systemhasaddon_htptgopro: xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.htpt.gopro,return)')
				else:
					returned = ActivateWindow("0", 'plugin.video.htpt.gopro' , 'plugin://plugin.video.htpt.gopro/' , 0, wait=True)
					if returned == 'ok2':
						systemcurrentcontrol = findin_systemcurrentcontrol("0",str73440.encode('utf-8'),40,'Action(Down)','Action(Select)')
						count = 0
						systemidle0 = xbmc.getCondVisibility('System.IdleTime(0)')
						while count < 10 and systemcurrentcontrol != str73440.encode('utf-8') and systemidle0 and not xbmc.abortRequested:
							count += 1
							systemcurrentcontrol = findin_systemcurrentcontrol("0",str73440.encode('utf-8'),40,'Action(Down)','Action(Select)')
							systemidle0 = xbmc.getCondVisibility('System.IdleTime(0)')
						
						if count < 10 and systemidle0: notification_common("14")
							
					#returned = ActivateWindow("1", 'plugin.video.htpt.gopro' , 'plugin://plugin.video.htpt.gopro/?iconimage=https%3a%2f%2fyt3.ggpht.com%2f-sp0YiR_yyR0%2fAAAAAAAAAAI%2fAAAAAAAAAAA%2fkXU4u1ny2T4%2fs100-c-k-no%2fphoto.jpg&mode=9&name=GoPro&num=1&url=GoProCamera' , "", wait=True)
					#returned = ActivateWindow('plugin.video.htpt.gopro', 'plugin://plugin.video.htpt.gopro/?iconimage=https%3a%2f%2fyt3.ggpht.com%2f-sp0YiR_yyR0%2fAAAAAAAAAAI%2fAAAAAAAAAAA%2fkXU4u1ny2T4%2fs100-c-k-no%2fphoto.jpg&mode=9&name=GoPro&num=1&url=GoProCamera', "", wait=True)
					#returned = ActivateWindow("1", 'plugin.video.htpt.gopro' , 'plugin://plugin.video.htpt.gopro/?iconimage=https%3a%2f%2fyt3.ggpht.com%2f-sp0YiR_yyR0%2fAAAAAAAAAAI%2fAAAAAAAAAAA%2fkXU4u1ny2T4%2fs100-c-k-no%2fphoto.jpg&mode=9&name=GoPro&num=1&url=GoProCamera' , 0, wait=True)
					
					#returned = ActivateWindow("1", 'plugin.video.htpt.gopro', 'plugin://plugin.video.htpt.gopro/?iconimage=https%3a%2f%2fyt3.ggpht.com%2f-sp0YiR_yyR0%2fAAAAAAAAAAI%2fAAAAAAAAAAA%2fkXU4u1ny2T4%2fs100-c-k-no%2fphoto.jpg&mode=9&name=GoPro&num=1&url=GoProCamera', "", wait=True)
					#xbmc.sleep(5000)
					#xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.htpt.gopro/?iconimage=https%3a%2f%2fyt3.ggpht.com%2f-sp0YiR_yyR0%2fAAAAAAAAAAI%2fAAAAAAAAAAA%2fkXU4u1ny2T4%2fs100-c-k-no%2fphoto.jpg&mode=9&name=GoPro&num=1&url=GoProCamera,return)')
					#
			elif youtubebutton:
				if admin: xbmc.executebuiltin('Notification(Admin,youtubebutton,1000)')
				xbmc.executebuiltin('RunAddon(plugin.video.youtube)')
				xbmc.sleep(500)
				containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
				count = 0
				while count < 10 and not "plugin://plugin.video.youtube" in containerfolderpath and not xbmc.abortRequested:
					xbmc.sleep(100)
					count += 1
					containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
					xbmc.sleep(100)
				if "plugin://plugin.video.youtube" in containerfolderpath:
					xbmc.executebuiltin('Action(PageUp)')
					xbmc.executebuiltin('Action(Down)')
					
			if moviesebutton or tvshowsebutton or custom1132W:
				if admin: xbmc.executebuiltin('Notification(Admin,moviesebutton/tvshowsebutton,1000)')
				if moviesebutton or custom1132W:
					'''------------------------------
					---MOVIES-SEARCH/ADD-------------
					------------------------------'''
					if moviesep:
						'''------------------------------
						---PLUS--------------------------
						------------------------------'''
						if not custom1132W:
							if admin: notification("test2","","",2000)
							xbmc.executebuiltin('ActivateWindow(1132)')
						else:
							controlhasfocus698 = findin_controlhasfocus("9000","698",20,"","Action(close)")
							controlhasfocus699 = findin_controlhasfocus("9000","699",20,"","Action(close)")
							if controlhasfocus698: xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=root_movies,return)')
							elif controlhasfocus699: xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.pulsar,return)')
							if admin and controlhasfocus699: notification("test","","",2000)
						
					else:
						xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=root_movies,return)') #xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=movies_featured,return)') #xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=root_movies,return)') #xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=movies_popular)')
						'''---------------------------'''
				elif tvshowsebutton:
					xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=root_shows,return)')
				
				if systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow'):
					'''------------------------------
					---GENESIS-PATH-CHANGE-----------
					------------------------------'''
					count = 0
					while count < 10 and systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow') and not xbmc.abortRequested:
						xbmc.sleep(40)
						systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow')
						count += 1
						if count == 10:
							if not autoviewoff: xbmc.executebuiltin('Skin.ToggleSetting(AutoViewoff)')
							xbmc.executebuiltin('RunAddon(plugin.video.genesis)')
							xbmc.sleep(1000)
							containerfolderpath = xbmc.getCondVisibility('StringCompare(Container.FolderPath,plugin://plugin.video.genesis/)')
							if not containerfolderpath:
								xbmc.executebuiltin('Action(PageUp)')
								xbmc.executebuiltin('Action(PageUp)')
								xbmc.executebuiltin('Action(Select)')
								xbmc.sleep(800)
								containerfolderpath = xbmc.getCondVisibility('StringCompare(Container.FolderPath,plugin://plugin.video.genesis/)')
								#xbmc.sleep(1000)
							if containerfolderpath:
								xbmc.executebuiltin('Action(PageUp)')
								xbmc.executebuiltin('Action(Down)')
								if tvshowsebutton: xbmc.executebuiltin('Action(Down)')
								xbmc.executebuiltin('Action(Select)')
									
				if systemcurrentwindow != xbmc.getInfoLabel('System.CurrentWindow'):
					'''------------------------------
					---GENESIS-OK!-------------------
					------------------------------'''
					count = 0
					containernumitems = xbmc.getInfoLabel('Container.NumItems')
					
					while count < 40 and (containernumitems == "0" or containernumitems == "") and not xbmc.abortRequested:
						xbmc.sleep(40)
						containernumitems = xbmc.getInfoLabel('Container.NumItems')
						count += 1
					#if admin: notification("testtttt-",containernumitems,"",3000)
					rootmovies = 'plugin://plugin.video.genesis/?action=root_movies'
					roottv = 'plugin://plugin.video.genesis/?action=root_shows'
					containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
					if containerfolderpath == rootmovies or containerfolderpath == roottv:
						systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
						if containerfolderpath == rootmovies:
							value2 = str342
							xbmc.executebuiltin('Action(PageUp)')
							xbmc.executebuiltin('Action(PageUp)')
							if moviesestartup == "0": value = "" #root
							elif moviesestartup == "1": value = addonString_genesis(30527).encode('utf-8') #Most Popular
							elif moviesestartup == "2": value = addonString_genesis(30531).encode('utf-8') #Latest HD Movies
							elif moviesestartup == "3": value = addonString_genesis(30535).encode('utf-8') #Search
							elif moviesestartup == "4": value = addonString_genesis(30541).encode('utf-8') #Genres
							else: value = ""
							if value != "": value = "[" + value + "]"
							#if admin: notification("value: " + value,"","",1000)
							'''---------------------------'''
							count = 0
							while count < 17 and containerfolderpath == rootmovies and value != "" and not xbmc.abortRequested:
								if not xbmc.Player().isPlayingVideo():
									if moviesestartup == "3": systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Up)','')
									elif moviesestartup == "2": systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Up)','Action(Select)')
									else: systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Down)','Action(Select)')
								else:
									if moviesestartup == "3": systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Down)','')
									else: systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Down)','Action(Select)')
								
								if systemcurrentcontrol == value: count = 40
								containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
								count += 1
								'''---------------------------'''
							
						elif containerfolderpath == roottv:
							value2 = str20343 #str20343.decode('utf-8').encode('utf-8')
							xbmc.executebuiltin('Action(PageUp)')
							xbmc.executebuiltin('Action(PageUp)')
							if tvshowsestartup == "0": value = "" #root
							elif tvshowsestartup == "1": value = addonString_genesis(30527).encode('utf-8') #Most Popular
							elif tvshowsestartup == "2": value = addonString_genesis(30544).encode('utf-8') #Returning TV Shows
							elif tvshowsestartup == "3": value = addonString_genesis(30535).encode('utf-8') #Search
							elif tvshowsestartup == "4": value = addonString_genesis(30541).encode('utf-8') #Genres
							else: value = ""
							if value != "": value = "[" + value + "]"
							'''---------------------------'''
							count = 0
							while count < 17 and containerfolderpath == roottv and value != "" and not xbmc.abortRequested:
								if tvshowsestartup == "3" and not xbmc.Player().isPlayingVideo(): systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Up)','')
								elif tvshowsestartup == "3": systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Down)','')
								else: systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Down)','Action(Select)')
								
								if systemcurrentcontrol == value: count = 40
								containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
								count += 1
								'''---------------------------'''
						
						if value != "":
							'''------------------------------
							---STARTUP-WINDOW-NOTIFICATION---
							------------------------------'''
							xbmc.sleep(3000)
							containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
							if containerfolderpath == rootmovies or containerfolderpath == roottv:
								if moviesestartup != "3" and tvshowsestartup != "3": notification('[COLOR=Yellow]' + value.decode('utf-8') + '[/COLOR]' + str512 + space2, addonString(151), "", 4000)
							elif moviesestartup == "3" or tvshowsestartup == "3": notification('[COLOR=Yellow]' + value.decode('utf-8') + '[/COLOR]' + str512 + space2, addonString(151), "", 4000)
					elif admin: notification("containerfolderpath_Error","","",1000)
					
			if weatherbutton:
				
				addon = 'weather.yahoo'
				if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
					'''------------------------------
					---weather.yahoo-----------------
					------------------------------'''
					if weatheryahoo_location1 == "" and weatheryahoo_location1id == "":
						setsetting_custom1(addon,'Location1',"Tel Aviv (IL)")
						setsetting_custom1(addon,'Location1id',"1968212")
					elif weatheryahoo_location2 == "" and weatheryahoo_location2id == "":
						setsetting_custom1(addon,'Location2',"Haifa (IL)")
						setsetting_custom1(addon,'Location2id',"2345794")
					elif weatheryahoo_location3 == "" and weatheryahoo_location3id == "":
						setsetting_custom1(addon,'Location3',"")
						setsetting_custom1(addon,'Location3id',"")

					xbmc.executebuiltin('ActivateWindow(MyWeather)')
					xbmc.sleep(200)
					xbmc.executebuiltin('Weather.Refresh')
					addon = 'weather.yahoo'
					'''---------------------------'''
				else:
					installaddon(admin, addon, "")
					'''---------------------------'''
			
			if trailers2button:
				if admin: xbmc.executebuiltin('Notification(Admin,trailers2button,1000)')
				xbmc.executebuiltin('RunAddon(screensaver.randomtrailers)')
			
			if musicbutton or custom1124W:
				'''------------------------------
				---MUSIC-BUTTON------------------
				------------------------------'''
				printpoint = ""
				if admin: xbmc.executebuiltin('Notification(Admin,musicbutton,1000)')
				if not custom1124W: xbmc.executebuiltin('ActivateWindow(1124,return)')
				else:
					xbmc.executebuiltin('dialog.close(1124)')
					if button101:
						'''------------------------------
						---LOCAL-MUSIC-------------------
						------------------------------'''
						name = str75004.encode('utf-8')
						if libraryhascontentmusic:
							if musiclinkstr == "": xbmc.executebuiltin('ActivateWindow(502,return)')
							else: xbmc.executebuiltin('ActivateWindow(502,'+ musiclinkstr +',return)')
						else:
							xbmc.executebuiltin('ActivateWindow(501,root),return)')
							dialogok('[COLOR=Yellow]' + addonString(120) % (name.decode('utf-8')) + '[/COLOR]', addonString(147) % (name.decode('utf-8')), addonString(148), '')
							'''---------------------------'''
							returned = supportcheck(name, ["A", "B", "A?", "B?"], totalspace=40, Intel=False, silence=False)
							if returned != 'ok': pass
							
							
					elif button99:
						'''------------------------------
						---HTPT-MUSIC--------------------
						------------------------------'''
						addon = 'plugin.video.htpt.music'
						if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
							xbmc.executebuiltin('RunAddon('+ addon +',,)')
							'''---------------------------'''
						else: installaddon(admin, addon, "")
					
					elif button102:
						'''------------------------------
						---RADIO-------------------------
						------------------------------'''
						addon = 'plugin.video.israelive'
						if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
							#xbmc.executebuiltin('RunAddon('+ addon +',,)')
							if xbmc.getCondVisibility('!System.GetBool(pvrmanager.enabled)'): xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.israelive/?categoryid=9999&description&displayname=10000&iconimage=http%3a%2f%2fmdmorrope.gob.pe%2fportalweb%2fimagenes%2fradioss.png&mode=2&name=%5bCOLOR%20chartreuse%5d%5bB%5d%5b%d7%a8%d7%93%d7%99%d7%95%5d%5b%2fB%5d%5b%2fCOLOR%5d&url,return)')
							else: xbmc.executebuiltin('ActivateWindow(MyPVRChannels.xml)')
							'''---------------------------'''
						else: installaddon(admin, addon, "")
			
			elif custom1134W:
				'''------------------------------
				---SOAP-OPERA--------------------
				------------------------------'''
				name = 'SOAP-OPERA'
				xbmc.executebuiltin('dialog.close(1134)')
				if button101:
					addon = 'plugin.video.wallaNew.video'
					returned = ActivateWindow("1", addon, "plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%98%d7%9c%d7%a0%d7%95%d7%91%d7%9c%d7%95%d7%aa%20(18)&url=genre%3dtvshows%26genreId%3d6280", 0, wait=True)
					'''---------------------------'''
				elif button102:
					addon = 'plugin.video.sdarot.tv'
					returned = ActivateWindow("1", addon, "plugin://plugin.video.sdarot.tv/?mode=2&module=http%3a%2f%2fwww.sdarot.wf%2fseries%2fgenre%2f13%d7%98%d7%9c%d7%a0%d7%95%d7%91%d7%9c%d7%94&name=%d7%98%d7%9c%d7%a0%d7%95%d7%91%d7%9c%d7%94&url=all-heb", 0, wait=True)
					'''---------------------------'''
				elif button103:
					pass
					'''---------------------------'''
			
			elif custom1135W:
				'''------------------------------
				---DOCU--------------------------
				------------------------------'''
				name = 'DOCU'
				xbmc.executebuiltin('dialog.close(1135)')
				if button101:
					addon = 'plugin.video.movixws'
					returned = ActivateWindow("1", addon, "plugin://plugin.video.movixws/?iconimage=http%3a%2f%2ficons.iconarchive.com%2ficons%2faaron-sinuhe%2ftv-movie-folder%2f512%2fDocumentaries-National-Geographic-icon.png&mode=2&name=Documentary%20-%20%d7%93%d7%95%d7%a7%d7%95%d7%9e%d7%a0%d7%98%d7%a8%d7%99&url=http%3a%2f%2fwww.movix.me%2fgenres%2fDocumentary", 0, wait=True)
					'''---------------------------'''
				elif button102:
					pass
					'''---------------------------'''
				elif button103:
					pass
					'''---------------------------'''
					
			elif custom1136W:
				'''------------------------------
				---ISRAELI-MOVIES----------------
				------------------------------'''
				name = 'ISRAELI-MOVIES'
				xbmc.executebuiltin('dialog.close(1136)')
				if button101:
					addon = 'plugin.video.wallaNew.video'
					#xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99%20(113)&url=genre%3dmovies%26genreId%3d6260,return)')
					returned = ActivateWindow("1", addon, "plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99%20(98)&url=genre%3dmovies%26genreId%3d6260", 0, wait=True)
					'''---------------------------'''
				elif button102:
					addon = 'plugin.video.movixws'
					returned = ActivateWindow("1", addon, "plugin://plugin.video.movixws/?iconimage=http%3a%2f%2fupload.wikimedia.org%2fwikipedia%2fcommons%2fthumb%2fd%2fd4%2fFlag_of_Israel.svg%2f250px-Flag_of_Israel.svg.png&mode=2&name=Israeli%20-%20%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99&url=http%3a%2f%2fwww.movix.me%2fgenres%2fisraeli", 0, wait=True)
					'''---------------------------'''
				elif button103:
					addon = 'plugin.video.10qtv'
					returned = ActivateWindow("1", addon, "plugin://plugin.video.10qtv/?mode=6&name=%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99&url=http%3a%2f%2fwww.10q.tv%2fboard%2ffilmy%2fishrali%2f11", 0, wait=True)
					'''---------------------------'''
				#else: notification("12","","",1000)
					
					
			elif morebutton or custom1133W:
				'''------------------------------
				---MORE--------------------------
				------------------------------'''
				if not custom1133W: xbmc.executebuiltin('ActivateWindow(1133)')
				else:
					xbmc.executebuiltin('dialog.close(1133)')
					if button99:
						'''------------------------------
						---HTPT-MUSIC--------------------
						------------------------------'''
						addon = 'plugin.video.htpt.music'
						if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
							xbmc.executebuiltin('RunAddon('+ addon +',,)')
							'''---------------------------'''
						else: installaddon(admin, addon, "")
					
					elif button101:
						'''------------------------------
						---GAMER-TV----------------------
						------------------------------'''
						addon = 'plugin.video.g4tv'
						if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
							xbmc.executebuiltin('RunAddon('+ addon +')')
							'''---------------------------'''
						else: installaddon(admin, addon, "")
						
					elif button102:
						'''------------------------------
						---GUITAR------------------------
						------------------------------'''
						addon = 'plugin.video.ultimateguitar'
						if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
							xbmc.executebuiltin('RunAddon('+ addon +')')
							'''---------------------------'''
						else: installaddon(admin, addon, "")
					
					elif button103:
						'''------------------------------
						---QUIZ--------------------------
						------------------------------'''
						addon = 'script.moviequiz'
						if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
							xbmc.executebuiltin('RunAddon('+ addon +')')
							'''---------------------------'''
						else: installaddon(admin, addon, "")
					
					elif button104:
						'''------------------------------
						---?--------------------------
						------------------------------'''
						addon = 'plugin.video.ultimateguitar'
						if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
							xbmc.executebuiltin('RunAddon('+ addon +')')
							'''---------------------------'''
						else: installaddon(admin, addon, "")
					
				
			if kidsbutton:
				'''------------------------------
				---KIDS-BUTTON-------------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,kidsbutton,1000)')
				#kidssettings("run")
				xbmc.sleep(200)
				#xbmc.executebuiltin('RunAddon(plugin.video.KIDSIL)')
				if systemhasaddon_htptkids: xbmc.executebuiltin('RunAddon(plugin.video.htpt.kids)')
				else:
					xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.htpt.kids,return)')
					if admin: notification("Admin","Addon is missing!","",1000)
				'''---------------------------'''
				
			if mov3dsbutton:
				'''------------------------------
				---3D-MOVIES-BUTTON--------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,mov3dsbutton,1000)')
				#xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.movie25/?fanart;genre;iconimage=https%3a%2f%2fraw.github.com%2fmash2k3%2fMashupArtwork%2fmaster%2fskins%2fvector%2f3d.png;mode=223;name=3D%20Movies;plot;url=3D,return)')
				notification_common("10")
				'''---------------------------'''
			elif gadgetbutton:
				'''------------------------------
				---GADGET-BUTTON-----------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,gadgetbutton,1000)')
				#if not systemplatformwindows: xbmc.executebuiltin('RunAddon(plugin.video.engadget)')
				notification_common("10")
				'''---------------------------'''
			elif karaokebutton:
				'''------------------------------
				---KARAOKE-BUTTON----------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,karaokebutton,1000)')
				xbmc.executebuiltin('RunAddon(plugin.video.MikeysKaraoke)')
				'''---------------------------'''
			elif gametrailersbutton:
				'''------------------------------
				---GAMERS-BUTTON-----------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,gametrailersbutton,1000)')
				xbmc.executebuiltin('RunAddon(plugin.video.g4tv)')
				'''---------------------------'''
			elif guitarbutton:
				'''------------------------------
				---GAMERS-BUTTON-----------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,guitarbutton,1000)')
				xbmc.executebuiltin('RunAddon(plugin.video.ultimateguitar)')
				'''---------------------------'''
			elif adultbutton2:
				'''------------------------------
				---ADULT-MOVIE-BUTTON------------
				------------------------------'''
				adultbutton2_(admin)
				'''---------------------------'''
						
			if radiobutton:
				'''------------------------------
				---RADIO-BUTTON------------------
				------------------------------'''
				print printfirst + "radiobutton"
				xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.israelive/?categoryid=9999&description&displayname=10000&iconimage=http%3a%2f%2fmdmorrope.gob.pe%2fportalweb%2fimagenes%2fradioss.png&mode=2&name=%5bCOLOR%20chartreuse%5d%5bB%5d%5b%d7%a8%d7%93%d7%99%d7%95%5d%5b%2fB%5d%5b%2fCOLOR%5d&url,return)')
				xbmc.sleep(700)
				containernumitems = xbmc.getInfoLabel('Container.NumItems')
				if systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow') or containernumitems == '0':
					xbmc.executebuiltin('RunAddon(plugin.video.israelive)')
					xbmc.sleep(700)
					if xbmc.getInfoLabel('Container.FolderPath') == 'plugin://plugin.video.israelive/':
						xbmc.executebuiltin('Action(PageUp)')
						xbmc.executebuiltin('Action(Down)')
						xbmc.executebuiltin('Action(Down)')
						xbmc.executebuiltin('Action(Select)')
		elif vhomecon1:
			notification_common("5")
			'''---------------------------'''

def helpbuttons(admin):
	if custom1170W or loginscreenW:
		'''------------------------------
		---HELP-/-LOGINSCREEN-WINDOWS----
		------------------------------'''
		xbmc.sleep(40)
		#if admin: xbmc.executebuiltin('Notification(Admin,custom1170,1000)')
		#sgbserviceszeroconf = xbmc.getCondVisibility('System.GetBool(services.zeroconf)')
		from variables import sgbserviceszeroconf, sgbservicesairplay
		if airplaybutton:
			'''------------------------------
			---AIRPLAY-BUTTON----------------
			------------------------------'''
			printpoint = ""
			xbmc.executebuiltin('ActivateWindow(servicesettings)')
			settingscategoryW = xbmc.getCondVisibility('Window.IsVisible(SettingsCategory.xml)')
			count = 0
			while count < 10 and not settingscategoryW and not xbmc.abortRequested:
				if count == 0: printpoint = printpoint + "0"
				xbmc.sleep(40)
				settingscategoryW = xbmc.getCondVisibility('Window.IsVisible(SettingsCategory.xml)')
				count += 1
			settingslevelset("2")
			'''---------------------------'''
			if not sgbserviceszeroconf:
				printpoint = printpoint + "1"
				count = 0
				systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
				while count < 5 and systemcurrentcontrol != str1259 and not xbmc.abortRequested:
					'''Zeroconf'''
					if count == 0: printpoint = printpoint + "2"
					systemcurrentcontrol = findin_systemcurrentcontrol("0",str1259,40,'Action(Left)','Action(Down)')
					count += 1
					'''---------------------------'''
				count = 0
				while count < 5 and not str1260 in systemcurrentcontrol and not xbmc.abortRequested:
					'''Announce these services to other systems via Zeroconf'''
					if count == 0:
						printpoint = printpoint + "3"
						systemcurrentcontrol = findin_systemcurrentcontrol("1",str1260,40,'','Action(Select)')
					else: systemcurrentcontrol = findin_systemcurrentcontrol("1",str1260,40,'Action(Down)','Action(Select)')
					count += 1
					'''---------------------------'''
				count = 0
				while count < 5 and systemcurrentcontrol != str1259 and not xbmc.abortRequested:
					'''Zeroconf'''
					if count == 0: printpoint = printpoint + "2"
					systemcurrentcontrol = findin_systemcurrentcontrol("0",str1259,40,'Action(Up)','Action(Right)')
					count += 1
					'''---------------------------'''
				sgbserviceszeroconf = xbmc.getCondVisibility('System.GetBool(services.zeroconf)')
				
			if sgbserviceszeroconf:
				printpoint = printpoint + "4"
				'''---------------------------'''
				systemcurrentcontrol = findin_systemcurrentcontrol("0",str1273,40,'Action(Left)','Action(Down)')
				count = 0
				while count < 5 and systemcurrentcontrol != str1273 and not xbmc.abortRequested:
					'''AirPlay'''
					if count == 0: printpoint = printpoint + "5"
					systemcurrentcontrol = findin_systemcurrentcontrol("0",str1273,40,'Action(Left)','Action(Down)')
					count += 1
					'''---------------------------'''
				
				systemcurrentcontrol = findin_systemcurrentcontrol("1",str1273,40,'Action(Down)','')
				count = 0
				while count < 5 and not str1273 in systemcurrentcontrol and not xbmc.abortRequested:
					'''if Allow to receive AirPlay content'''
					if count == 0: printpoint = printpoint + "6"
					systemcurrentcontrol = findin_systemcurrentcontrol("1",str1273,40,'Action(Down)','')
					count += 1
					'''---------------------------'''
				if count < 5:
					printpoint = printpoint + "8"
					systemcurrentcontrol = findin_systemcurrentcontrol("1",str1273,40,'','Action(Select)')
					xbmc.sleep(500)
					if sgbservicesairplay: systemcurrentcontrol = findin_systemcurrentcontrol("1",str1273,40,'','Action(Select)')
					'''---------------------------'''
				
				xbmc.executebuiltin('Action(Back)')
				xbmc.sleep(1000)
				xbmc.executebuiltin('Action(Down)')
				sgbservicesairplay = xbmc.getCondVisibility('System.GetBool(services.airplay)')
				sgbserviceszeroconf = xbmc.getCondVisibility('System.GetBool(services.zeroconf)')
				xbmc.sleep(500)
				if sgbserviceszeroconf and sgbservicesairplay:
					printpoint = printpoint + "7"
					notification_common("13")
					dialogok('[COLOR=Yellow]' + addonString(114) + '[/COLOR]', addonString(115), addonString(116), "")
					returned = dialogyesno(addonString(117), addonString(118))
					if returned != "ok":
						'''Extra Help with AirPlay'''
						dialogok('[COLOR=Yellow]' + addonString(140) + '[/COLOR]', addonString(141) + space2, addonString(142), "")
					#xbmc.executebuiltin('Notification($LOCALIZE[79063],$LOCALIZE[79064],5000)')
					
				elif not sgbserviceszeroconf: notification('$LOCALIZE[257]','$LOCALIZE[34302]',"",4000)
				else:
					printpoint = printpoint + "9"
					#if not systemplatformwindows: os.system('sh /storage/.kodi/addons/skin.htpt/specials/scripts/resetnetwork.sh')
			
			'''------------------------------
			---PRINT-END---------------------
			------------------------------'''
			if admin: print printfirst + "airplaybutton_LV" + printpoint
			'''---------------------------'''
			
		if resetnetworkbutton:
			'''------------------------------
			---RESET-NETWORK-BUTTON----------
			------------------------------'''
			resetnetwork('run')
		'''buttons which require internet'''
		if connected:
			if messagebutton:
				notification_common("10")
				if systemplatformwindows:
					xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.programm.htptmail/mailbox/INBOX/,return)')
					'''---------------------------'''
			if debugbutton:
				if not systemhasaddon_htptdebug: xbmc.executebuiltin('ActivateWindow(10001,plugin://script.htpt.debug/)')
				else: xbmc.executebuiltin('RunAddon(script.htpt.debug,,?mode=1)')
				'''---------------------------'''
		elif vhomecon1: xbmc.executebuiltin('Notification($LOCALIZE[79512],$LOCALIZE[21451],5000)')		
			
def skinbuttons(admin):
	if skinsettingsW:
		if adultbutton:
			'''------------------------------
			---ADULT-GAMES-------------------
			------------------------------'''
			print printfirst + space + "adultbutton"
			xbmc.executebuiltin('Skin.ToggleSetting(Adult)')
			if not systemplatformwindows:
				xbmc.sleep(1000)
				os.system('sh /storage/.kodi/addons/script.htpt.emu/specials/scripts/copyemu.sh')
			if not adult:
				'''------------------------------
				---ADULT-BUTTON-OFF->ON----------
				------------------------------'''
				returned = dialogyesno(addonString(97).encode('utf-8'),addonString(98).encode('utf-8'))
				if returned == "ok":
					'''------------------------------
					---ADULT-ALWAYS-ON---------------
					------------------------------'''
					setSkinSetting("1",'Adult2',"true")
					'''---------------------------'''
				else:
					'''------------------------------
					---ADULT-ALWAYS-OFF--------------
					------------------------------'''
					setSkinSetting("1",'Adult2',"false")
					'''---------------------------'''
				setSkinSetting("1",'Admin2',"false")
				'''---------------------------'''
				list0 = xbmc.getInfoLabel('$LOCALIZE[75003]')
				list1 = xbmc.getInfoLabel('$LOCALIZE[15016]')
				returned, value = dialogselect(addonString(99).encode('utf-8'),[list0, list1],0)
				if returned == -1:
					dialogok(addonString(95).encode('utf-8'),addonString(96).encode('utf-8'),"","")
				else:
					xbmc.executebuiltin('ActivateWindow(Home.xml)')
					xbmc.sleep(200)
					'''---------------------------'''
					if returned == 0: adultbutton2_(admin)
					elif returned == 1:
						gamesbutton_(admin)
						xbmc.sleep(1000)
						xbmc.executebuiltin('Action(PageDown)')
			else: setSkinSetting("1",'Adult2',"false")
		
		elif paymentmethodbutton:
			'''------------------------------
			---PAYMENT-TERMS-----------------
			------------------------------'''
			list0 = xbmc.getInfoLabel('$LOCALIZE[70014]')
			list1 = xbmc.getInfoLabel('$LOCALIZE[70015]')
			list2 = xbmc.getInfoLabel('$LOCALIZE[70016]')
			returned, value = dialogselect('$LOCALIZE[70012]',[list0, list1, list2],0)
			returned = int(returned)
			returnedS = str(returned)
			returned2 = "list" + returnedS
			if returned == -1: pass
			else: setSkinSetting("0",'ID6',value)
			
def startup(validation):
	
	validation = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION)')
	if (startup_aW or loginscreen_aW) and not validation:
		if admin: print printfirst + "startup (1)"
		xbmc.executebuiltin('ReplaceWindow(Home)')
		mac7('run',macaddress,maccon1,maccon2,maccon10,maccon11)
		'''---------------------------'''
		xbmc.executebuiltin('RunScript(script.htpt.smartbuttons,,?mode=100)')
		'''---------------------------'''
		externalusb("")
	
def HelpButton_Video_Pic(name, path2):
	returned = supportcheck(name, ["A", "B", "A?", "B?"], totalspace=100, Intel=False, silence=True)
	if returned == 'ok': device = "0"
	else: device = "1"
	containernumitems = xbmc.getInfoLabel('Container.NumItems')
	try: containernumitemsN = int(containernumitems)
	except: containernumitemsN = 0
	
	if containernumitemsN < 2: dialogok('[COLOR=Yellow]' + addonString(120) % (name) + '[/COLOR]', addonString(123) % (name) + addonString(133),"","")
	usb1str = xbmc.getInfoLabel('Skin.String(USB1)')
	
	'''---------------------------'''
	if name != str2:
		if device == "0": dialogok('[COLOR=Yellow]' + addonString(124) % (id10str) + '[/COLOR]', addonString(125) % (servicehtptfix_Purchase_TotalSpace),addonString(126) % (name),"")
		elif device == "1": dialogok('[COLOR=Yellow]' + addonString(124) % (id10str) + '[/COLOR]', addonString(127),addonString(155) % (usb1str),"")
		'''---------------------------'''
	if device == "0":
		returned = dialogyesno(addonString(134) % (name),addonString(135) % (name, addonString(46)))
		if returned == "ok":
			header = space + "(" + addonString(46) + ")" + space + '[COLOR=Yellow]' + addonString(129) % (name) + '[/COLOR]'+ space
			if name == str1 or name == str3: message2 = addonString(132) % (name, path2, name) + addonString(128)
			elif name == str2: message2 = addonString(172) % (name) + addonString(128)
			w = TextViewer_Dialog('DialogTextViewer.xml', "", header=header, text=message2)
			w.doModal()
			
			header = space + "(" + addonString(46) + ")" + space + '[COLOR=Yellow]' + addonString(136) % (name) + '[/COLOR]' + space
			if name == str1 or name == str3: message2 = addonString(137) % ("\\\\" + "htpt", path2, name, name) + addonString(128)
			elif name == str2: message2 = addonString(173) % ("\\\\" + "htpt", path2, name, name, name) + addonString(128)
			w = TextViewer_Dialog('DialogTextViewer.xml', "", header=header, text=message2)
			w.doModal()
			'''---------------------------'''
	
	elif device == "1":
		returned = dialogyesno(addonString(134) % (name),addonString(135) % (name, addonString(47)))
		if returned == "ok":
			header = space + "(" + addonString(47) + ")" + space + '[COLOR=Yellow]' + addonString(129) % (name) + '[/COLOR]' + space
			message2 = addonString(155) % (usb1str) + '[CR]' + addonString(156) % (path2) + '[CR]' + addonString(157) % (path2, name) + addonString(128)
			w = TextViewer_Dialog('DialogTextViewer.xml', "", header=header, text=message2)
			w.doModal()
			
			header = space + "(" + addonString(47) + ")" + space + '[COLOR=Yellow]' + addonString(136) % (name) + '[/COLOR]' + space
			message2 = addonString(137) % ("\\\\" + "htpt", str79498 + " -> " + usb1str + " -> " + path2 , name, name) + addonString(128)
			w = TextViewer_Dialog('DialogTextViewer.xml', "", header=header, text=message2)
			w.doModal()
			'''---------------------------'''
			
def topvideoinformation2(admin):
	'''------------------------------
	---Clear ListItem----------------
	------------------------------'''
	containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
	listitemtvshowtitlestr = xbmc.getInfoLabel('Skin.String(ListItemTVShowTitle)')
	'''---------------------------'''
	if not "videodb://tvshows" in containerfolderpath and not "library://video/tvshows" in containerfolderpath:
		setSkinSetting("0",'ListItemGenre',"")
		setSkinSetting("0",'ListItemDuration',"")
		setSkinSetting("0",'ListItemRating',"")
		setSkinSetting("0",'ListItemYear',"")
		setSkinSetting("0",'ListItemTVShowTitle',"")
		if listitemtvshowtitlestr: print printfirst + "topvideoinformation2" + space2 + "Clear ListItem"
		'''---------------------------'''

def settingslevelset(custom):
	'''custom: 1 = Basic, 2 = Standard, 3 = Advanced, 4 = Expert'''
	if custom == "1": custom = settingslevelstr1
	elif custom == "2": custom = settingslevelstr2
	elif custom == "3": custom = settingslevelstr3
	elif custom == "4": custom = settingslevelstr4
	else: sys.exit(1)
	'''---------------------------'''
	printpoint = ""
	settingslevel = xbmc.getInfoLabel('Skin.String(SettingsLevel)')
	'''---------------------------'''
	if settingslevel != custom:
		controlhasfocus = findin_controlhasfocus("0","20",40,'Control.SetFocus(20)','')
		count = 0
		while count < 5 and not controlhasfocus and not xbmc.abortRequested:
			if count == 0: printpoint = printpoint + "2"
			controlhasfocus = findin_controlhasfocus("0","20",40,'Control.SetFocus(20)','')
			count += 1
			'''---------------------------'''
		if controlhasfocus:
			printpoint = printpoint + "3"
			count = 0
			while count < 5 and settingslevel != custom and not xbmc.abortRequested:
				if count == 0: printpoint = printpoint + "5"
				count += 1
				systemcurrentcontrol = findin_systemcurrentcontrol("0",custom,10,'Action(Select)','Action(Down)')
				settingslevel = xbmc.getInfoLabel('Skin.String(SettingsLevel)')
				'''---------------------------'''
		else: printpoint = printpoint + "9"
	else:
		printpoint = printpoint + "8"
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "settingslevelset_LV" + printpoint
	'''---------------------------'''
	
def adultbutton2_(admin):
	if systemhasaddon_videodevil: xbmc.executebuiltin('RunAddon(plugin.video.videodevil)')
	else: xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.videodevil)')
	'''---------------------------'''
	
def gamesbutton_(admin):
	if not systemplatformwindows: os.system('sh /storage/.kodi/addons/script.htpt.emu/specials/scripts/launcher.sh')
	xbmc.executebuiltin('RunAddon(plugin.program.advanced.launcher)')
	xbmc.sleep(2000)
	systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
	containernumitems = xbmc.getInfoLabel('Container.NumItems')
	'''---------------------------'''
	if (systemcurrentcontrol == "[..]" or systemcurrentcontrol == "[Default]") and (containernumitems == "0" or containernumitems == "1"):
		'''------------------------------
		---FIX-CONFIGURATION-FILE--------
		------------------------------'''
		print printfirst + space + "gamesbutton" + space + "Possible Error in file: launcher.xml"
		dialogok(addonString(130).encode('utf-8'),addonString(131).encode('utf-8'),"","")
		if not systemplatformwindows: os.system('sh /storage/.kodi/addons/script.htpt.emu/specials/scripts/copyemu.sh')
		xbmc.executebuiltin('ActivateWindow(Home.xml)')
		xbmc.sleep(2000)
		xbmc.executebuiltin('RunAddon(plugin.program.advanced.launcher)')
		'''---------------------------'''

def resetnetwork(run):
	'''tweak and reload the network adapters'''
	xbmc.executebuiltin('Notification([COLOR Red] $VAR[CurrentMAC][/COLOR] $LOCALIZE[79061],$LOCALIZE[79062],5000)')
	if not systemplatformwindows: os.system('sh /storage/.kodi/addons/skin.htpt/specials/scripts/resetnetwork.sh')
	xbmc.sleep(1000)
	oewindow("Network")

def externalusb(device):
	'''detect connected USB'''
	name = 'externalusb' ; printpoint = ""
	if device == "":
		printpoint = printpoint + "1"
		returned = supportcheck(name, ["A", "B", "A?", "B?"], totalspace=100, Intel=False, silence=True)
		if returned == 'ok': device = "0"
		else: device = "1"
		
	if not systemplatformwindows and myhtpt2:
		printpoint = printpoint + "2"
		if picturesbutton or videosbutton or startup_aW:
			os.system('sh /storage/.kodi/addons/skin.htpt/specials/scripts/externalusb.sh')
			printpoint = printpoint + "3"
			#xbmc.sleep(500)
		log = open('/storage/externalusb.log', 'r')
		rows = log.readlines()
		rowscountN = len(rows)
		rowscount = str(rowscountN)
		log.close()
		row1 = ""
		row2 = ""
		row3 = ""
		row4 = ""
		row5 = ""
		if rowscountN > 0: row1 = rows[0][:-1]
		if rowscountN > 1: row2 = rows[1][:-1]
		if rowscountN > 2: row3 = rows[2][:-1]
		if rowscountN > 3: row4 = rows[3][:-1]
		if rowscountN > 4: row5 = rows[4][:-1]
		if picturesbutton or videosbutton or startup_aW:
			printpoint = printpoint + "4"
			if usb1str != row1: xbmc.executebuiltin('Skin.SetString(USB1,'+ row1 +')')
			if usb2str != row2: xbmc.executebuiltin('Skin.SetString(USB2,'+ row2 +')')
			if usb3str != row3: xbmc.executebuiltin('Skin.SetString(USB3,'+ row3 +')')
			if usb4str != row4: xbmc.executebuiltin('Skin.SetString(USB4,'+ row4 +')')
			if usb5str != row5: xbmc.executebuiltin('Skin.SetString(USB5,'+ row5 +')')
			'''---------------------------'''
		if admin and rowscountN > 0: xbmc.executebuiltin('Notification(Admin,'+ rowscount +' '+ row1 +' ,1000)')
		path0 = 'special://userdata/library/'
		path1 = os.path.join(varmedia_path, row1)
		path2 = os.path.join(varmedia_path, row2)
		path3 = os.path.join(varmedia_path, row3)
		path4 = os.path.join(varmedia_path, row4)
		path5 = os.path.join(varmedia_path, row5)
		pathwin = 'special://home/external/'
		if rowscountN == 0 and myhtpt3: xbmc.executebuiltin('Skin.ToggleSetting(myHTPT3)')
		if rowscountN > 0 and not myhtpt3: xbmc.executebuiltin('Skin.ToggleSetting(myHTPT3)')
		'''---------------------------'''
		#myvideonavW = xbmc.getCondVisibility('Window.IsVisible(MyVideoNav.xml)')
		#mypicsW = xbmc.getCondVisibility('Window.IsVisible(MyPics.xml)')
		containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
		
		if (myvideonavW or mypicsW) and usbtoggle:
			printpoint = printpoint + "5"
			#xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,)')
			#xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,)')
			if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path0 +')') and rowscountN > 0:
				if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path1 +'/videos/,return)')
				if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path1 +'/pictures/,return)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,1)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path1 +')')
			elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path1 +')') and rowscountN > 1:
				if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path2 +'/videos/,return)')
				if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path2 +'/pictures/,return)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,2)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path2 +')')
			elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path2 +')') and rowscountN > 2:
				if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path3 +'/videos/,return)')
				if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path3 +'/pictures/,return)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,3)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path3 +')')
			elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path3 +')') and rowscountN > 3:
				if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path4 +'/videos/,return)')
				if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path4 +'/pictures/,return)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,4)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path4 +')')
				'''---------------------------'''
			elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path4 +')') and rowscountN > 4:
				if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path5 +'/videos/,return)')
				if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path5 +'/pictures/,return)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,5)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path5 +')')
				'''---------------------------'''
				
			if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path1 +')') and rowscountN == 1:
				printpoint = printpoint + "A"
				if device == "1":
					notification('$LOCALIZE[74546]', '$LOCALIZE[74547]', '', 2000)
					if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path1 +'/videos/,return)')
					elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path1 +'/pictures/,return)')
					'''---------------------------'''
				elif myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'/videos/,return)')
				elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'/pictures/,return)')
			elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path2 +')') and rowscountN == 2:
				if device == "1":
					if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path1 +'/videos/,return)')
					elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path1 +'/pictures/,return)')
					'''---------------------------'''
				elif myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'/videos/,return)')
				elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'/pictures/,return)')
			elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path3 +')') and rowscountN == 3:
				if device == "1":
					if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path1 +'/videos/,return)')
					elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path1 +'/pictures/,return)')
					'''---------------------------'''
				elif myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'/videos/,return)')
				elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'/pictures/,return)')
			elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path4 +')') and rowscountN == 4:
				if device == "1":
					if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path1 +'/videos/,return)')
					elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path1 +'/pictures/,return)')
					'''---------------------------'''
				elif myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'/videos/,return)')
				elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'/pictures/,return)')
			elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path5 +')') and rowscountN == 5:
				if device == "1":
					if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path1 +'/videos/,return)')
					elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path1 +'/pictures/,return)')
					'''---------------------------'''
				elif myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'/videos/,return)')
				elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'/pictures/,return)')
				'''---------------------------'''
			xbmc.sleep(20)
			containernumitems = xbmc.getInfoLabel('Container.NumItems')
			if containernumitems == 0: xbmc.executebuiltin('Action(Select)')
		elif device == "1":
			printpoint = printpoint + "8" ; extra = ""
			if videosbutton: extra = '/videos/'
			elif picturesbutton: extra = '/pictures/'
			xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,1)')
			xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path1 +' '+ extra +')')
			
		if admin: print printfirst + name + "_LV" + printpoint + space + "mypicsW" + space2 + str(mypicsW) + space + "myvideonavW" + space2 + str(myvideonavW) + space + "containerfolderpath" + space2 + str(containerfolderpath) + space + "device" + space2 + str(device) + newline + "path1" + space2 + path1 + space + "rowscountN" + space2 + str(rowscountN) + newline + space
		
def mac7(run,macaddress,maccon1,maccon2,maccon10,maccon11):
	'''VALIDATION PROOF'''
	validation2 = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION2)')
	printpoint = ""
	if ((not maccon1 and not maccon2) or (not maccon10 and not maccon11)) and not id40str:
		xbmc.sleep(200)
		xbmc.executebuiltin('Notification(MAC7,step 1,1000)')
		if (not maccon1 and not maccon2):
			#macaddress = xbmc.getInfoLabel('Network.MacAddress')
			xbmc.executebuiltin('Skin.SetString(MAC,'+ macaddress +')')
			xbmc.sleep(500)
			maccon1 = xbmc.getCondVisibility('StringCompare(Skin.String(MAC),Skin.String(MAC1))')
			maccon2 = xbmc.getCondVisibility('StringCompare(Skin.String(MAC),Skin.String(MAC2))')
			printpoint = printpoint + "1"
		else:
			maccon10 = xbmc.getCondVisibility('StringCompare(Control.GetLabel(700100),NONE)')
			maccon11 = xbmc.getCondVisibility('StringCompare(Control.GetLabel(700100),7000)')
			printpoint = printpoint + "2"
		xbmc.sleep(200)
		if (not maccon1 and not maccon2) or (not maccon10 and not maccon11) and not id40str:
			if validation5 == '0':
				xbmc.executebuiltin('Notification(Admin,MAC7,step 2,1000)')
				if not validation: xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION)')
				if not validation2: xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION2)')
				if not widget: xbmc.executebuiltin('Skin.ToggleSetting(Widget)')
				xbmc.executebuiltin('Notification($LOCALIZE[79080],For Support: [COLOR Yellow]$LOCALIZE[79081][/COLOR],5000,icons/shield.png)')
				if macaddress and not loginscreenW and home_pW: xbmc.executebuiltin('ReplaceWindow(LoginScreen.xml)')
				if validation and playerhasmedia: xbmc.executebuiltin('Action(Stop)')
				
				if not maccon1 and not maccon2 and validation and not macaddress and id9str != 'COPIED':
					xbmc.executebuiltin('Skin.SetString(ID9,COPIED)')
					xbmc.executebuiltin('Notification(COPIED,,5000)')
					xbmc.executebuiltin('ReplaceWindow(LoginScreen.xml)')
				printpoint = printpoint + "3"
			else:
				if validation5 == '3': xbmc.executebuiltin('Skin.SetString(VALIDATION5,2)')
				if validation5 == '2': xbmc.executebuiltin('Skin.SetString(VALIDATION5,1)')
				if validation5 == '1': xbmc.executebuiltin('Skin.SetString(VALIDATION5,0)')
				
				xbmc.executebuiltin('Notification(Admin MAC7:,-validation5 reduced from ('+ validation5 +')')
				printpoint = printpoint + "4"
	else:
		'''UNLOCK'''
		printpoint = printpoint + "5"
		if validation2:
			printpoint = printpoint + "6"
			if connected:
				xbmc.sleep(3000)
				xbmc.executebuiltin('Notification($LOCALIZE[79086],$LOCALIZE[79084],3000,icons/shield.png)')
				xbmc.sleep(1000)
				validation2 = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION2)')
				if validation2: xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION2)')
				printpoint = printpoint + "7"
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + space + "mac7_LV" + printpoint + space3
	'''---------------------------'''

def mac(run,macaddress):
	if validation and (home_aW or startup_aW or startup_pW or loginscreenbutton):
		print printfirst + "mac (1)"
		xbmc.sleep(40)
		if macaddress and macaddress != str503:
			macaddress = xbmc.getInfoLabel('Network.MacAddress')
			xbmc.executebuiltin('Skin.SetString(MAC,'+ macaddress +')')
			xbmc.sleep(500)
		if not validation2: xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION2)')
		if validation5 == '3':
			xbmc.executebuiltin('Skin.SetString(VALIDATION5,2)')
			xbmc.executebuiltin('AlarmClock(HTPTCHECK: '+ idstr +'*0 | '+ id1str +'*1 | '+ id2str +'*2 | '+ id3str +'*3 | '+ id4str +'*4 | '+ id5str +'*5 | '+ id6str +'*6 | '+ id7str +'*7 | '+ id8str +'*8 | '+ id9str +'*9 | '+ id10str +'*10 | '+ mac1str +'*MAC1 | '+ mac2str +'*MAC2 | '+ mac3str +'*MAC3 | '+ macaddress +'*MAC | '+ systemtotaluptime +'*TOTALUPTIME | '+ verrorstr +'*VERROR | ,Action(Stop),0,silent)')
			if not connected2 and not connected3:
				if startup_aW: xbmc.executebuiltin('AlarmClock(loginscreendelay,ReplaceWindow(LoginScreen.xml),00:02,silent)')
				elif systemuptime5:
					if id40str: pass
					else: xbmc.executebuiltin('AlarmClock(loginscreendelay,ReplaceWindow(LoginScreen.xml),00:02,silent)')
		elif validation5 == '2':
			xbmc.executebuiltin('Skin.SetString(VALIDATION5,1)')
			if not maccon10 and not maccon11 and home_aW: xbmc.executebuiltin('Notification($LOCALIZE[79080],$LOCALIZE[257]: $VAR[VERROR],5000,icons/shield.png)')
		elif validation5 == '1':
			xbmc.executebuiltin('Skin.SetString(VALIDATION5,0)')
			xbmc.executebuiltin('Notification($LOCALIZE[79080],For Support: [COLOR Yellow]$LOCALIZE[79081][/COLOR],5000,icons/shield.png)')
		elif validation5 == '0':
			if not loginscreenW: xbmc.executebuiltin('ReplaceWindow(LoginScreen.xml)')
			if loginscreen_aW: xbmc.executebuiltin('Notification($LOCALIZE[79080],For Support: [COLOR Yellow]$LOCALIZE[79081][/COLOR],5000,icons/shield.png)')
		xbmc.sleep(40)
		'''UNLOCK SYSTEM'''
		if (maccon1 or maccon2) and (maccon10 or maccon11) or id40str:
			xbmc.sleep(40)
			print printfirst + "mac (2)"
			xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION)')
			if not widget: xbmc.executebuiltin('Skin.ToggleSetting(Widget)')
			xbmc.executebuiltin('Skin.SetString(VALIDATION5,3)')
			#xbmc.sleep(500)
			if connected:
				xbmc.sleep(40)
				xbmc.executebuiltin('Notification($LOCALIZE[79083],$LOCALIZE[79082],5000,icons/shield2.png)')
				mac7('run',macaddress,maccon1,maccon2,maccon10,maccon11)
			else:
				xbmc.executebuiltin('Notification($LOCALIZE[79083],$LOCALIZE[24073],5000,icons/shield2.png)')
			#if home_aW:
				#xbmc.executebuiltin('Control.SetFocus('+ container9000pos +')')
				#xbmc.sleep(500)
				#if admin: xbmc.executebuiltin('Notification(Admin, '+ container9000pos +',2000,icons/shield2.png)')
				#xbmc.executebuiltin('Action(Select)')
			if loginscreen_aW:
				#xbmc.executebuiltin('ActivateWindow(0)')
				xbmc.executebuiltin('ReplaceWindow(0)')
				
