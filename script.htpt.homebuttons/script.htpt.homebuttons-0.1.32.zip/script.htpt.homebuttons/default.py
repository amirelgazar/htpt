import xbmc
import os, sys
import subprocess
import xbmcgui, xbmcaddon

from variables import *
from modules import *

def leftmenu(run):
	'''left menu'''
	containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
	if not validation:
		'''searchisraeltv'''
		if myvideonavW and searchisraeltv:
			xbmc.executebuiltin('Control.SetFocus(50)')
			url = 'plugin://plugin.video.sdarot.tv/?mode=6&name=%5bCOLOR%20red%5d%20%d7%97%d7%a4%d7%a9%20%20%5b%2fCOLOR%5d&url=http%3a%2f%2fwww.sdarot.wf%2fsearch'
			ActivateWindow("1", 'plugin.video.sdarot.tv', url, 'return0', wait=False)

		if helpbutton:
			if mypicsW:
				HelpButton_Video_Pic(str1, 'pictures')
			elif mymusicnavW:
				HelpButton_Video_Pic(str2, 'music')
			elif (myvideonavW and myvideopath):
				HelpButton_Video_Pic(str3, 'videos')
				
		'''70'''
		if (myvideonavW or mypicsW) and usbtoggle:
			if admin: xbmc.executebuiltin('Notification(Admin,usbtoggle,1000)')
			#videopath0 = xbmc.getCondVisibility('SubString(Container.FolderPath,special://userdata/library/videos/)')
			externalusb("")
			if systemplatformwindows:
				path0 = 'special://userdata/library/'
				pathwin = 'special://home/external/'
				if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path0 +')'):
					if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ pathwin +'videos/,return)')
					if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ pathwin +'pictures/,return)')
				if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ pathwin +')'):
					if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'videos/,return)')
					if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'pictures/,return)')
			print printfirst + "usbtoggle"
		if myvideonavW and numinumibutton:
			pl=xbmc.PlayList(1)
			pl.clear()
			count = 0
			while count < 7 and not xbmc.abortRequested:
				xbmc.sleep(10)
				count += 1
				listitem = xbmcgui.ListItem(numinumistr,
				thumbnailImage='special://skin/media/icons/kids.png')
				url = 'special://userdata/addon_data/skin.htpt/video/numinumi.mp4'
				xbmc.PlayList(1).add(url, listitem)

			xbmc.Player().play(pl)
			xbmc.executebuiltin('Action(Right)')
			xbmc.executebuiltin('Action(PageUp)')
			xbmc.executebuiltin('Action(FullScreen)')
	else:
		if admin: xbmc.executebuiltin('Notification(Admin,no buttonproceed,1000)')
		
def miscbuttons(admin):

	if subsliderbutton:
		'''------------------------------
		---subslider---------------------
		------------------------------'''
		if admin: notification("admin: " + "subsliderbutton","","",1000)
		if systemplatformwindows: filepath = "Z:\\addons\\script.htpt.homebuttons\\specials\\scripts\\subslider.py"
		if not systemplatformwindows: filepath = "/storage/.kodi/addons/script.htpt.homebuttons/specials/scripts/subslider.py"
		xbmc.executebuiltin('RunScript('+ filepath +', -10)')
		'''---------------------------'''
		
	if customhomecustomizerW:
		'''------------------------------
		---CustomHomeCustomizer----------
		------------------------------'''
		if button704:
			'''------------------------------
			---Startup-Window----------------
			------------------------------'''
			if container50button320 or container50button321:
			
				if container50button320:
					'''------------------------------
					---MOVIES------------------------
					------------------------------'''
					heading = str512 + space + str342
					list0 = "0. " + str20108 #root
					list1 = "1. " + addonString_genesis(30527).encode('utf-8') #Most Popular
					list2 = "2. " + addonString_genesis(30531).encode('utf-8') #Latest HD Movies
					list3 = "3. " + addonString_genesis(30535).encode('utf-8') #Search
					list4 = "4. " + addonString_genesis(30541).encode('utf-8') #Genres
					returned, value = dialogselect(heading,[list0, list1, list2, list3, list4],0)
					if returned != -1:
						setSkinSetting("0",'moviesestartup',str(returned))
						#setSkinSetting("0",'moviesestartup',value)
						'''---------------------------'''
					
				elif container50button321:
					'''------------------------------
					---TVSHOWS------------------------
					------------------------------'''
					heading = str512 + space + str20343
					list0 = "0. " + str20108 #root
					list1 = "1. " + addonString_genesis(30527).encode('utf-8') #Most Popular
					list2 = "2. " + addonString_genesis(30544).encode('utf-8') #Returning TV Shows
					list3 = "3. " + addonString_genesis(30535).encode('utf-8') #Search
					list4 = "4. " + addonString_genesis(30541).encode('utf-8') #Genres
					returned, value = dialogselect(heading,[list0, list1, list2, list3, list4],0)
					if returned != -1:
						setSkinSetting("0",'tvshowsestartup',str(returned))
						'''---------------------------'''

	if stabilitytestbutton:
		'''------------------------------
		---MODEL C - Stability Test------
		------------------------------'''
		if not systemplatformwindows: os.system('sh /storage/.kodi/addons/skin.htpt/specials/scripts/stabilitytest.sh')
		'''---------------------------'''

class main:
	setGeneral_ScriptON("0", General_ScriptON, "")
	mac('run',macaddress)
	'''activate home buttons'''
	if not validation and homeW:
		if moviesbutton:
			libraryhascontentmovies = xbmc.getCondVisibility('Library.HasContent(Movies)')
			if libraryhascontentmovies:
				if admin: xbmc.executebuiltin('Notification(Admin,moviesbutton,1000)')
				xbmc.executebuiltin('ActivateWindow(Videos,MovieTitles,return)')
				if not autoview:
					xbmc.sleep(2000)
					if xbmc.getCondVisibility('System.IdleTime(2)'): notification(localize(98) + space + localize(1223), localize(79534), "", 4000)
			else:
				if not autoviewoff: xbmc.executebuiltin('Skin.ToggleSetting(AutoViewoff)')
				#xbmc.executebuiltin('ActivateWindow(video,"special://userdata/library/movies/",return)')
				url = "special://userdata/library/movies/"
				returned = ActivateWindow("1", url, url, 0, wait=True)
				if returned != "":
					try:
						containernumitems = xbmc.getInfoLabel('Container.NumItems')
						if int(containernumitems) < 3: xbmc.executebuiltin('Notification($LOCALIZE[79079] $LOCALIZE[342] $LOCALIZE[79090],$LOCALIZE[79091],4000)')
						'''---------------------------'''
					except: pass
				if scripthtptsmartbuttonsLibraryData_LocalMoviesFiles == "0": xbmc.executebuiltin('RunScript(script.htpt.smartbuttons,,?mode=55)')
				else:
					if libraryisscanningvideo and not libraryhascontentmovies: xbmc.sleep(4000) ; xbmc.executebuiltin('UpdateLibrary(video)')
					else:
						setsetting_custom1('service.htpt.fix','Fix_100',"true")
						if scripthtptinstall_Skin_FirstBoot == "true": dialogok("Reboot Required!", "Please reboot in order to finish the first installation", "", "")
						else: xbmc.executebuiltin('RunScript(service.htpt.fix,,?mode=3)')
						xbmc.executebuiltin('ActivateWindow(0)')
						'''---------------------------'''
				
		elif tvshowsbutton:
			libraryhascontenttvshows = xbmc.getCondVisibility('Library.HasContent(TVShows)')
			if libraryhascontenttvshows:
				if admin: xbmc.executebuiltin('Notification(Admin,tvshowsbutton,1000)')
				xbmc.executebuiltin('ActivateWindow(VideoLibrary,TVShowTitles,return)')
				if not autoview:
					xbmc.sleep(2000)
					if xbmc.getCondVisibility('System.IdleTime(2)'): notification(localize(98) + space + localize(1223), localize(79534), "", 4000)
			else:
				if not autoviewoff: xbmc.executebuiltin('Skin.ToggleSetting(AutoViewoff)')
				#xbmc.executebuiltin('ActivateWindow(video,"special://userdata/library/tvshows/",return)')
				url = "special://userdata/library/tvshows/"
				returned = ActivateWindow("1", url, url, 0, wait=True)
				if returned != "":
					try:
						containernumitems = xbmc.getInfoLabel('Container.NumItems')
						if int(containernumitems) < 3: xbmc.executebuiltin('Notification($LOCALIZE[79079] $LOCALIZE[20343] $LOCALIZE[79090],$LOCALIZE[79091],4000)')
					except: pass
					'''---------------------------'''
				if scripthtptsmartbuttonsLibraryData_LocalTvshowsFiles == "0": xbmc.executebuiltin('RunScript(script.htpt.smartbuttons,,?mode=55)')
				else:
					if libraryisscanningvideo: xbmc.sleep(4000) ; xbmc.executebuiltin('UpdateLibrary(video)')
					else:
						setsetting_custom1('service.htpt.fix','Fix_101',"true")
						if scripthtptinstall_Skin_FirstBoot == "true": dialogok("Reboot Required!", "Please reboot in order to finish the first installation", "", "")
						else: xbmc.executebuiltin('RunScript(service.htpt.fix,,?mode=3)')
						xbmc.executebuiltin('ActivateWindow(0)')
						'''---------------------------'''
				
		elif gamesbutton:
			'''------------------------------
			---GAMES-BUTTON------------------
			------------------------------'''
			printpoint = ""
			name = str15016.encode('utf-8')

			returned = supportcheck(name, ["A","A?","B","B?"], 200, platform="13456")
			if returned == "ok":
				addon = 'plugin.program.advanced.launcher'
				if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
					printpoint = printpoint + "7"
					'''---------------------------'''
				else:
					installaddon(admin, addon, "")
					'''---------------------------'''
				
				addon = 'script.htpt.emu'
				if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
					printpoint = printpoint + "7"
					'''---------------------------'''
				else:
					installaddon(admin, addon, "")
					'''---------------------------'''
				
				if "77" in printpoint:
					if not os.path.exists(os.path.join(addons_path,'emulator.retroarch')) and not admin3:
						file = "emu_htpt.zip"
						fileID = getfileID(file)
						DownloadFile("https://www.dropbox.com/s/"+fileID+"/emu_htpt.zip?dl=1", file, temp_path, addons_path)
						if os.path.exists(os.path.join(addons_path,'emulator.retroarch')): dialogok("Reboot required", "In order to start playing games, you should reboot your device", "", "")
					else:
						gamesbutton_(admin)
			
		elif picturesbutton or videosbutton:
			'''------------------------------
			---PICTURE-&-VIDEO-BUTTON--------
			------------------------------'''
			containernumitems = ""
			printpoint = ""
			name = "" ; path = "" ; device = ""
			
			
			returned = supportcheck(name, ["A", "B", "A?", "B?"], totalspace=100, Intel=False, silence=True)
			if returned == "ok": device = "0"
			elif scripthtptinstall_Skin_Installed == "true" or scripthtptinstall_Skin_FirstBoot == "true": printpoint = printpoint + "8"
			else: device = "1"

			if picturesbutton:
				name = str1
				path2 = "pictures"
			elif videosbutton:
				name = str3
				path2 = "videos" 
			if device == "0": path = "special://userdata/library/" + path2 + "/"
			else:
				externalusb(device)
				usb1str = xbmc.getInfoLabel('Skin.String(USB1)')
				if usb1str == "" and not systemplatformwindows: printpoint = printpoint + "9"
				'''---------------------------'''
				if usb1str != "": path = varmedia_path + usb1str + '/' + path2
				elif systemplatformwindows: path = 'special://home/external/' + path2
				'''---------------------------'''
			if printpoint == "":
				if not os.path.exists(library_path + path2):
					os.mkdir(library_path + path2) ; xbmc.sleep(500)
					notification("Folder Created:", library_path + path2, "", 2000)
				xbmc.executebuiltin('ActivateWindow('+ path2 +','+ path +',return)')
				#xbmc.executebuiltin('ActivateWindow(Pictures,/var/media/'+ usb1str +',return)')
				#xbmc.executebuiltin('ActivateWindow(Pictures,special://userdata/library/pictures/,return)')
				if not admin and not playerhasmedia: xbmc.executebuiltin('PlayMedia(special://userdata/addon_data/skin.htpt/music/playHTPT.mp3)')
				'''---------------------------'''
				containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
				count = 0
				while count < 10 and containerfolderpath != path and not xbmc.abortRequested:
					'''------------------------------
					---containerfolderpath-----------
					------------------------------'''
					xbmc.sleep(100)
					count += 1
					containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
					xbmc.sleep(100)
					'''---------------------------'''
				containernumitems = xbmc.getInfoLabel('Container.NumItems')
				try: containernumitemsN = int(containernumitems)
				except: containernumitemsN = 0
				if device == "0": externalusb(device)
					
				if containernumitemsN < 2:
					containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
					count = 0
					while count < 10 and containerfolderpath == path and not xbmc.abortRequested:
						'''------------------------------
						---containerfolderpath-----------
						------------------------------'''
						xbmc.sleep(500)
						count += 1
						containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
						if count == 1: notification(addonString(120) % (name), localize(75786), "", 1000)
						elif count == 2: notification(addonString(120) % (name), localize(75786) + ".", "", 1000)
						elif count == 3: notification(addonString(120) % (name), localize(75786) + "..", "", 1000)
						elif count == 4: notification(addonString(120) % (name), localize(75786) + "...", "", 1000)
						if count == 5:
							HelpButton_Video_Pic(name, path2)
							
							
						xbmc.sleep(500)
						'''---------------------------'''
			if printpoint != "":
				if "9" in printpoint: dialogok('[COLOR=Yellow]' + localize(75798) + '[/COLOR]', addonString(124) % (id10str) + '[CR]' + localize(74541), localize(75799), localize(74542))
				elif "8" in printpoint: dialogok("Reboot Required!", "Please reboot in order to finish the first installation", "", "")
			if admin: print printfirst + "picturesbutton/videosbutton_LV" + printpoint + space2 + "containernumitems" + space2 + containernumitems + "id10str" + space2 + id10str
			
		elif favouritesbutton:
			if admin: xbmc.executebuiltin('Notification(Admin,favouritesbutton,1000)')
			xbmc.executebuiltin('ActivateWindow(134)')
			'''---------------------------'''
		elif settingsbutton:
			xbmc.executebuiltin('ActivateWindow(Settings.xml)')
			'''---------------------------'''
		elif widgettogglebutton:
			if admin: xbmc.executebuiltin('Notification(Admin,widgettogglebutton,1000)')
			if xbmc.getCondVisibility('Control.IsVisible(311)'):
				xbmc.executebuiltin('Skin.ToggleSetting(MoviesShelfWL)')
				xbmc.executebuiltin('ActivateWindow(Videos,MovieTitles)')
				xbmc.sleep(100)
				xbmc.executebuiltin('ReplaceWindow(0)')
				xbmc.executebuiltin('Control.SetFocus(9090)')
				'''---------------------------'''
			if xbmc.getCondVisibility('Control.IsVisible(312)'):
				xbmc.executebuiltin('Skin.ToggleSetting(TVShelf_Watchlist)')
				xbmc.executebuiltin('ActivateWindow(VideoLibrary,TVShowTitles)')
				xbmc.sleep(100)
				xbmc.executebuiltin('ReplaceWindow(0)')
				xbmc.executebuiltin('Control.SetFocus(9090)')
				'''---------------------------'''
		elif htptchannelbutton:
			#xbmc.executebuiltin('RunScript(script.toolbox,info=textviewer,header='+ message1 +',text='+ message2 +')')
			xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.youtube/channel/UCcYT8oPT83Yuw4_GUZ3mMFg/)')
			
			if os.path.exists(addons_path + 'skin.htpt/changelog.txt'):
				message = log.read()
				log.close()
				diaogtextviewer('[COLOR=Yellow]' + htptskinversion + '[/COLOR]' + addonString(19) + "-", message)
				'''---------------------------'''
			
		elif internetbutton:
			'''------------------------------
			---INTERNET-BUTTON---------------
			------------------------------'''
			name = str443.encode('utf-8')
			printpoint = ""
			if systemplatformwindows: cmd('start /max www.google.co.il','')
			else:
				returned = supportcheck(name, ["A","B"], 1, Intel=True, platform="456")
				if returned == "ok":
					if connected or connected2 or connected3:
						returned = dialogyesno(str79215,str79216)
						if returned == "ok":
							addon = 'browser.chromium-browser'
							if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
								notification(str79217, str79218, "", 4000)
								settingschange('SystemSettings','input.enablemouse','1','no',xbmc.getInfoLabel('$LOCALIZE[14094]'),xbmc.getInfoLabel('$LOCALIZE[21369]'))
								xbmc.sleep(1000)
								if not systemplatformwindows: xbmc.executebuiltin('RunAddon(browser.chromium-browser)')
								'''---------------------------'''
							else: installaddon(admin, addon, "")
						else:
							notification_common("8")
							#settingschange('SystemSettings','input.enablemouse','0','no',xbmc.getInfoLabel('$LOCALIZE[14094]'),xbmc.getInfoLabel('$LOCALIZE[21369]'))
							'''---------------------------'''
						
						
						
					else: notification_common("4")
			
		elif connected:
			'''------------------------------
			---Require-Internet--------------
			------------------------------'''
			#if admin: print printfirst + space + "homebuttons internet" + space3
			if israeltvbutton:
				printpoint = ""
				addon = 'plugin.video.sdarot.tv'
				if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
					printpoint = printpoint + "1"
					if admin and not admin2:
						path = os.path.join(addondata_path, 'plugin.video.sdarot.tv', 'sdarot-cookiejar.txt')
						removefiles(path)
						notification("DELETING COOKIE","","",1000)
						xbmc.sleep(1000)
						'''---------------------------'''
					else:
						addonsettings('SDAROT TV', 'plugin.video.sdarot.tv', 'Account2_Active', 'Account2_Period', 'username','user_password', "", "", "", "")
						addonsettings2('plugin.video.sdarot.tv','DEBUG',"false",'cache',"24",'domain',"http://www.sdarot.wf",'',"",'',"")
						'''---------------------------'''
						
					url = 'plugin://plugin.video.sdarot.tv/?mode=2&module=http%3a%2f%2fwww.sdarot.wf%2fseries%2fgenre%2f20%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99&name=%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99&url=all-heb'
					returned = ActivateWindow("1", 'plugin.video.sdarot.tv', url, 'return0', wait=True)
					if returned == "": returned = ActivateWindow("0", 'plugin.video.sdarot.tv', url, 'return0', wait=True) ; printpoint = printpoint + "3"
					if returned == "":
						from shared_modules3 import urlcheck
						printpoint = printpoint + "4"
						returned = urlcheck('http://www.sdarot.wf', ping=False)
						if returned == "ok":
							printpoint = printpoint + "6"
						else:
							'''------------------------------
							---WEBSITE-DOWN------------------
							------------------------------'''
							notification('[COLOR=Red]' + localize(75787) + '[/COLOR]', localize(75788),"",4000)
							xbmc.executebuiltin('Action(Close)')
							'''---------------------------'''
				else: installaddon(admin, addon, "")
			elif goprobutton:
				if admin: xbmc.executebuiltin('Notification(Admin,goprobutton,1000)')
				addon = 'plugin.video.youtube'
				if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
					returned = ActivateWindow("0", 'plugin.video.htpt.gopro' , 'plugin://plugin.video.htpt.gopro/' , 0, wait=True)
					if returned == 'ok2':
						systemcurrentcontrol = findin_systemcurrentcontrol("0",str73440.encode('utf-8'),40,'Action(Down)','Action(Select)')
						count = 0
						systemidle0 = xbmc.getCondVisibility('System.IdleTime(0)')
						while count < 10 and systemcurrentcontrol != str73440.encode('utf-8') and systemidle0 and not xbmc.abortRequested:
							count += 1
							systemcurrentcontrol = findin_systemcurrentcontrol("0",str73440.encode('utf-8'),40,'Action(Down)','Action(Select)')
							systemidle0 = xbmc.getCondVisibility('System.IdleTime(0)')
							xbmc.sleep(200)
						if count < 10 and systemidle0: notification_common("14")
				else: installaddon(admin, addon, "")
					
							
					#returned = ActivateWindow("1", 'plugin.video.htpt.gopro' , 'plugin://plugin.video.htpt.gopro/?iconimage=https%3a%2f%2fyt3.ggpht.com%2f-sp0YiR_yyR0%2fAAAAAAAAAAI%2fAAAAAAAAAAA%2fkXU4u1ny2T4%2fs100-c-k-no%2fphoto.jpg&mode=9&name=GoPro&num=1&url=GoProCamera' , "", wait=True)
					#returned = ActivateWindow('plugin.video.htpt.gopro', 'plugin://plugin.video.htpt.gopro/?iconimage=https%3a%2f%2fyt3.ggpht.com%2f-sp0YiR_yyR0%2fAAAAAAAAAAI%2fAAAAAAAAAAA%2fkXU4u1ny2T4%2fs100-c-k-no%2fphoto.jpg&mode=9&name=GoPro&num=1&url=GoProCamera', "", wait=True)
					#returned = ActivateWindow("1", 'plugin.video.htpt.gopro' , 'plugin://plugin.video.htpt.gopro/?iconimage=https%3a%2f%2fyt3.ggpht.com%2f-sp0YiR_yyR0%2fAAAAAAAAAAI%2fAAAAAAAAAAA%2fkXU4u1ny2T4%2fs100-c-k-no%2fphoto.jpg&mode=9&name=GoPro&num=1&url=GoProCamera' , 0, wait=True)
					
					#returned = ActivateWindow("1", 'plugin.video.htpt.gopro', 'plugin://plugin.video.htpt.gopro/?iconimage=https%3a%2f%2fyt3.ggpht.com%2f-sp0YiR_yyR0%2fAAAAAAAAAAI%2fAAAAAAAAAAA%2fkXU4u1ny2T4%2fs100-c-k-no%2fphoto.jpg&mode=9&name=GoPro&num=1&url=GoProCamera', "", wait=True)
					#xbmc.sleep(5000)
					#xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.htpt.gopro/?iconimage=https%3a%2f%2fyt3.ggpht.com%2f-sp0YiR_yyR0%2fAAAAAAAAAAI%2fAAAAAAAAAAA%2fkXU4u1ny2T4%2fs100-c-k-no%2fphoto.jpg&mode=9&name=GoPro&num=1&url=GoProCamera,return)')
					#
			elif youtubebutton:
				addon = 'plugin.video.youtube'
				if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
					xbmc.executebuiltin('RunAddon(plugin.video.youtube)')
				else: installaddon(admin, addon, "")
					
			if moviesebutton or tvshowsebutton:
				printpoint2 = ""
				if admin: xbmc.executebuiltin('Notification(Admin,moviesebutton/tvshowsebutton,1000)')
				if moviesebutton:
					'''------------------------------
					---MOVIES-SEARCH/ADD-------------
					------------------------------'''
					if moviesep:
						'''------------------------------
						---PLUS--------------------------
						------------------------------'''
						if not controlgroup9001hasfocus: xbmc.executebuiltin('SetFocus(9001)') ; printpoint2 = printpoint2 + "3"
						else:
							controlgroup9001hasfocus101 = xbmc.getCondVisibility('ControlGroup(9001).Hasfocus(101)')
							if controlgroup9001hasfocus101: xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=root_movies,return)') ; printpoint2 = printpoint2 + "5"
							elif controlgroup9001hasfocus102:
								'''------------------------------
								---PULSAR------------------------
								------------------------------'''
								addon = 'plugin.video.pulsar'
								if xbmc.getCondVisibility('System.HasAddon('+ addon +')'): xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.pulsar/movies/,return)')
								else:
									installaddon(admin, addon, "") ; xbmc.sleep(500)
									if not xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
										url = 'https://github.com/steeve/plugin.video.pulsar/releases/download/v0.6.1/plugin.video.pulsar-0.6.1.zip'
										DownloadFile(url, addon+".zip", packages_path, addons_path, silent=False) ; xbmc.executebuiltin("UpdateLocalAddons")			
							else: printpoint2 = printpoint2 + "9"
						
					else:
						xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=root_movies,return)') #xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=movies_featured,return)') #xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=root_movies,return)') #xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=movies_popular)')
						'''---------------------------'''
				elif tvshowsebutton:
					if tvshowsep:
						'''------------------------------
						---PLUS--------------------------
						------------------------------'''
						if not controlgroup9001hasfocus: xbmc.executebuiltin('SetFocus(9001)') ; printpoint2 = printpoint2 + "3"
						else:
							controlgroup9001hasfocus101 = xbmc.getCondVisibility('ControlGroup(9001).Hasfocus(101)')
							if controlgroup9001hasfocus101: xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=root_shows,return)') ; printpoint2 = printpoint2 + "5"
							elif controlgroup9001hasfocus102:
								'''------------------------------
								---PULSAR------------------------
								------------------------------'''
								addon = 'plugin.video.pulsar'
								if xbmc.getCondVisibility('System.HasAddon('+ addon +')'): xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.pulsar/shows/,return)')
								else:
									installaddon(admin, addon, "") ; xbmc.sleep(500)
									if not xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
										url = 'https://github.com/steeve/plugin.video.pulsar/releases/download/v0.6.1/plugin.video.pulsar-0.6.1.zip'
										DownloadFile(url, addon+".zip", packages_path, addons_path, silent=False) ; xbmc.executebuiltin("UpdateLocalAddons")
							else: printpoint2 = printpoint2 + "9"
						
					else: xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=root_shows,return)') ; printpoint2 = printpoint2 + "5"
					
				
				if "5" in printpoint2:
					addon = 'plugin.video.genesis'
					if systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow') and xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
						'''------------------------------
						---GENESIS-PATH-CHANGE-----------
						------------------------------'''
						count = 0
						while count < 10 and systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow') and not xbmc.abortRequested:
							xbmc.sleep(40)
							systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow')
							count += 1
							if count == 10:
								if not autoviewoff: xbmc.executebuiltin('Skin.ToggleSetting(AutoViewoff)')
								xbmc.executebuiltin('RunAddon(plugin.video.genesis)')
								xbmc.sleep(1000)
								containerfolderpath = xbmc.getCondVisibility('StringCompare(Container.FolderPath,plugin://plugin.video.genesis/)')
								if not containerfolderpath:
									xbmc.executebuiltin('Action(PageUp)')
									xbmc.executebuiltin('Action(PageUp)')
									xbmc.executebuiltin('Action(Select)')
									xbmc.sleep(800)
									containerfolderpath = xbmc.getCondVisibility('StringCompare(Container.FolderPath,plugin://plugin.video.genesis/)')
									#xbmc.sleep(1000)
								if containerfolderpath:
									xbmc.executebuiltin('Action(PageUp)')
									xbmc.executebuiltin('Action(Down)')
									if tvshowsebutton: xbmc.executebuiltin('Action(Down)')
									xbmc.executebuiltin('Action(Select)')
										
					if systemcurrentwindow != xbmc.getInfoLabel('System.CurrentWindow'):
						'''------------------------------
						---GENESIS-OK!-------------------
						------------------------------'''
						count = 0
						containernumitems = xbmc.getInfoLabel('Container.NumItems')
						
						while count < 40 and (containernumitems == "0" or containernumitems == "") and not xbmc.abortRequested:
							xbmc.sleep(40)
							containernumitems = xbmc.getInfoLabel('Container.NumItems')
							count += 1
						#if admin: notification("testtttt-",containernumitems,"",3000)
						rootmovies = 'plugin://plugin.video.genesis/?action=root_movies'
						roottv = 'plugin://plugin.video.genesis/?action=root_shows'
						containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
						if containerfolderpath == rootmovies or containerfolderpath == roottv:
							systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
							if containerfolderpath == rootmovies:
								value2 = str342
								xbmc.executebuiltin('Action(PageUp)')
								xbmc.executebuiltin('Action(PageUp)')
								if moviesestartup == "0": value = "" #root
								elif moviesestartup == "1": value = addonString_genesis(30527).encode('utf-8') #Most Popular
								elif moviesestartup == "2": value = addonString_genesis(30531).encode('utf-8') #Latest HD Movies
								elif moviesestartup == "3": value = addonString_genesis(30535).encode('utf-8') #Search
								elif moviesestartup == "4": value = addonString_genesis(30541).encode('utf-8') #Genres
								else: value = ""
								if value != "": value = "[" + value + "]"
								#if admin: notification("value: " + value,"","",1000)
								'''---------------------------'''
								count = 0
								while count < 17 and containerfolderpath == rootmovies and value != "" and not xbmc.abortRequested:
									if not xbmc.Player().isPlayingVideo():
										if moviesestartup == "3": systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Up)','')
										elif moviesestartup == "2": systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Up)','Action(Select)')
										else: systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Down)','Action(Select)')
									else:
										if moviesestartup == "3": systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Down)','')
										else: systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Down)','Action(Select)')
									
									if systemcurrentcontrol == value: count = 40
									containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
									count += 1
									'''---------------------------'''
								
							elif containerfolderpath == roottv:
								value2 = str20343 #str20343.decode('utf-8').encode('utf-8')
								xbmc.executebuiltin('Action(PageUp)')
								xbmc.executebuiltin('Action(PageUp)')
								if tvshowsestartup == "0": value = "" #root
								elif tvshowsestartup == "1": value = addonString_genesis(30527).encode('utf-8') #Most Popular
								elif tvshowsestartup == "2": value = addonString_genesis(30544).encode('utf-8') #Returning TV Shows
								elif tvshowsestartup == "3": value = addonString_genesis(30535).encode('utf-8') #Search
								elif tvshowsestartup == "4": value = addonString_genesis(30541).encode('utf-8') #Genres
								else: value = ""
								if value != "": value = "[" + value + "]"
								'''---------------------------'''
								count = 0
								while count < 17 and containerfolderpath == roottv and value != "" and not xbmc.abortRequested:
									if tvshowsestartup == "3" and not xbmc.Player().isPlayingVideo(): systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Up)','')
									elif tvshowsestartup == "3": systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Down)','')
									else: systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Down)','Action(Select)')
									
									if systemcurrentcontrol == value: count = 40
									containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
									count += 1
									'''---------------------------'''
							
							if value != "":
								'''------------------------------
								---STARTUP-WINDOW-NOTIFICATION---
								------------------------------'''
								xbmc.sleep(3000)
								containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
								if containerfolderpath == rootmovies or containerfolderpath == roottv:
									if moviesestartup != "3" and tvshowsestartup != "3": notification('[COLOR=Yellow]' + value.decode('utf-8') + '[/COLOR]' + str512 + space2, localize(75782), "", 4000)
								elif moviesestartup == "3" or tvshowsestartup == "3": notification('[COLOR=Yellow]' + value.decode('utf-8') + '[/COLOR]' + str512 + space2, localize(75782), "", 4000)
						elif admin: notification("containerfolderpath_Error","","",1000)
						
			if weatherbutton:
				
				addon = 'weather.yahoo'
				if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
					'''------------------------------
					---weather.yahoo-----------------
					------------------------------'''
					if weatheryahoo_location1 == "" and weatheryahoo_location1id == "":
						setsetting_custom1(addon,'Location1',"Tel Aviv (IL)")
						setsetting_custom1(addon,'Location1id',"1968212")
					elif weatheryahoo_location2 == "" and weatheryahoo_location2id == "":
						setsetting_custom1(addon,'Location2',"Haifa (IL)")
						setsetting_custom1(addon,'Location2id',"2345794")
					elif weatheryahoo_location3 == "" and weatheryahoo_location3id == "":
						setsetting_custom1(addon,'Location3',"")
						setsetting_custom1(addon,'Location3id',"")

					xbmc.executebuiltin('ActivateWindow(MyWeather)')
					xbmc.sleep(200)
					xbmc.executebuiltin('Weather.Refresh')
					addon = 'weather.yahoo'
					'''---------------------------'''
				else:
					installaddon(admin, addon, "")
					'''---------------------------'''
			
			if trailers2button:
				if admin: xbmc.executebuiltin('Notification(Admin,trailers2button,1000)')
				xbmc.executebuiltin('RunAddon(screensaver.randomtrailers)')
			
			if musicbutton:
				'''------------------------------
				---MUSIC-BUTTON------------------
				------------------------------'''
				printpoint = ""
				if admin: xbmc.executebuiltin('Notification(Admin,musicbutton,1000)')
				if not controlgroup9001hasfocus and musicsep: xbmc.executebuiltin('SetFocus(9001)')
				else:
					
					if controlgroup9001hasfocus101 or not musicsep:
						'''------------------------------
						---HTPT-MUSIC--------------------
						------------------------------'''
						addon = 'plugin.video.htpt.music'
						if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
							xbmc.executebuiltin('RunAddon('+ addon +',,)')
							'''---------------------------'''
						else: installaddon(admin, addon, "")
						if not musicsep:
							if musicseptip or scripthtptinstall_Skin_FirstBoot == "true":
								notification_common("25")
								if musicseptip: setSkinSetting("1", 'musicseptip', "false")
								
					elif controlgroup9001hasfocus102:
						'''------------------------------
						---NINBORA-MUSIC-----------------
						------------------------------'''
						addon = 'repository.ninbora'
						if not xbmc.getCondVisibility('System.HasAddon('+ addon +')'): installaddon2(admin, addon, update=True) ; xbmc.sleep(1000) ; xbmc.executebuiltin('Action(Back)') ; xbmc.sleep(1000)
						else:
							addon = 'plugin.video.ninbora-music'
							if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
								xbmc.executebuiltin('RunAddon('+ addon +',,)')
								'''---------------------------'''
							else: installaddon(admin, addon, "")
					
					if controlgroup9001hasfocus103:
						'''------------------------------
						---LOCAL-MUSIC-------------------
						------------------------------'''
						name = str75004.encode('utf-8')
						if libraryhascontentmusic:
							if musiclinkstr == "": xbmc.executebuiltin('ActivateWindow(502,return)')
							else: xbmc.executebuiltin('ActivateWindow(502,'+ musiclinkstr +',return)')
						else:
							xbmc.executebuiltin('ActivateWindow(501,root),return)')
							#xbmc.executebuiltin('ActivateWindow(501),return)')
							xbmc.sleep(1000)
							dialogok('[COLOR=Yellow]' + addonString(120) % (name.decode('utf-8')) + '[/COLOR]', addonString(147) % (name.decode('utf-8')), localize(75783), '')
							'''---------------------------'''
							returned = supportcheck(name, ["A", "B", "A?", "B?"], totalspace=40, Intel=False, silence=False)
							if returned != 'ok': pass
					
					elif controlgroup9001hasfocus104:
						'''------------------------------
						---RADIO-------------------------
						------------------------------'''
						addon = 'plugin.video.israelive'
						if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
							#xbmc.executebuiltin('RunAddon('+ addon +',,)')
							if xbmc.getCondVisibility('!System.GetBool(pvrmanager.enabled)'): xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.israelive/?categoryid=9999&description&displayname=10000&iconimage=http%3a%2f%2fmdmorrope.gob.pe%2fportalweb%2fimagenes%2fradioss.png&mode=2&name=%5bCOLOR%20chartreuse%5d%5bB%5d%5b%d7%a8%d7%93%d7%99%d7%95%5d%5b%2fB%5d%5b%2fCOLOR%5d&url,return)')
							else: xbmc.executebuiltin('ActivateWindow(MyPVRChannels.xml)')
							'''---------------------------'''
						else: installaddon(admin, addon, "")
			
			elif custom1134W:
				'''------------------------------
				---SOAP-OPERA--------------------
				------------------------------'''
				name = 'SOAP-OPERA'
				xbmc.executebuiltin('dialog.close(1134)')
				if button101:
					addon = 'plugin.video.wallaNew.video'
					returned = ActivateWindow("1", addon, "plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%98%d7%9c%d7%a0%d7%95%d7%91%d7%9c%d7%95%d7%aa%20(18)&url=genre%3dtvshows%26genreId%3d6280", 0, wait=True)
					'''---------------------------'''
				elif button102:
					addon = 'plugin.video.sdarot.tv'
					returned = ActivateWindow("1", addon, "plugin://plugin.video.sdarot.tv/?mode=2&module=http%3a%2f%2fwww.sdarot.wf%2fseries%2fgenre%2f13%d7%98%d7%9c%d7%a0%d7%95%d7%91%d7%9c%d7%94&name=%d7%98%d7%9c%d7%a0%d7%95%d7%91%d7%9c%d7%94&url=all-heb", 0, wait=True)
					'''---------------------------'''
				elif button103:
					pass
					'''---------------------------'''
			
			elif custom1135W:
				'''------------------------------
				---DOCU--------------------------
				------------------------------'''
				name = 'DOCU'
				xbmc.executebuiltin('dialog.close(1135)')
				if button101:
					addon = 'plugin.video.movixws'
					returned = ActivateWindow("1", addon, "plugin://plugin.video.movixws/?iconimage=http%3a%2f%2ficons.iconarchive.com%2ficons%2faaron-sinuhe%2ftv-movie-folder%2f512%2fDocumentaries-National-Geographic-icon.png&mode=2&name=Documentary%20-%20%d7%93%d7%95%d7%a7%d7%95%d7%9e%d7%a0%d7%98%d7%a8%d7%99&url=http%3a%2f%2fwww.movix.me%2fgenres%2fDocumentary", 0, wait=True)
					'''---------------------------'''
				elif button102:
					addon = 'repository.ninbora'
					if not xbmc.getCondVisibility('System.HasAddon('+ addon +')'): installaddon2(admin, addon, update=True) ; xbmc.sleep(1000) ; xbmc.executebuiltin('Action(Back)') ; xbmc.sleep(1000)
					else:
						addon = 'plugin.video.ninbora-nature'
						if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
							xbmc.executebuiltin('RunAddon('+ addon +',,)')
							'''---------------------------'''
						else: installaddon(admin, addon, "")
				elif button103:
					pass
					'''---------------------------'''
					
			elif custom1136W:
				'''------------------------------
				---ISRAELI-MOVIES----------------
				------------------------------'''
				name = 'ISRAELI-MOVIES'
				xbmc.executebuiltin('dialog.close(1136)')
				if button101:
					addon = 'plugin.video.wallaNew.video'
					#xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99%20(113)&url=genre%3dmovies%26genreId%3d6260,return)')
					returned = ActivateWindow("1", addon, "plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99%20(98)&url=genre%3dmovies%26genreId%3d6260", 0, wait=True)
					'''---------------------------'''
				elif button102:
					addon = 'plugin.video.movixws'
					returned = ActivateWindow("1", addon, "plugin://plugin.video.movixws/?iconimage=http%3a%2f%2fupload.wikimedia.org%2fwikipedia%2fcommons%2fthumb%2fd%2fd4%2fFlag_of_Israel.svg%2f250px-Flag_of_Israel.svg.png&mode=2&name=Israeli%20-%20%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99&url=http%3a%2f%2fwww.movix.me%2fgenres%2fisraeli", 0, wait=True)
					'''---------------------------'''
				elif button103:
					addon = 'plugin.video.10qtv'
					returned = ActivateWindow("1", addon, "plugin://plugin.video.10qtv/?mode=6&name=%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99&url=http%3a%2f%2fwww.10q.tv%2fboard%2ffilmy%2fishrali%2f11", 0, wait=True)
					'''---------------------------'''
				#else: notification("12","","",1000)
					
					
			elif morebutton:
				'''------------------------------
				---MORE--------------------------
				------------------------------'''
				if not controlgroup9001hasfocus: xbmc.executebuiltin('SetFocus(9001)')
				else:					
					if controlgroup9001hasfocus101:
						'''------------------------------
						---GAMER-TV----------------------
						------------------------------'''
						addon = 'plugin.video.g4tv'
						if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
							xbmc.executebuiltin('RunAddon('+ addon +')')
							'''---------------------------'''
						else: installaddon(admin, addon, "")
						
					elif controlgroup9001hasfocus102:
						'''------------------------------
						---GUITAR------------------------
						------------------------------'''
						addon = 'plugin.video.ultimateguitar'
						if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
							xbmc.executebuiltin('RunAddon('+ addon +')')
							'''---------------------------'''
						else: installaddon(admin, addon, "")
					
					elif controlgroup9001hasfocus103:
						'''------------------------------
						---QUIZ--------------------------
						------------------------------'''
						addon = 'script.moviequiz'
						if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
							xbmc.executebuiltin('RunAddon('+ addon +')')
							'''---------------------------'''
						else: installaddon(admin, addon, "")
					
					elif controlgroup9001hasfocus104:
						'''------------------------------
						---?--------------------------
						------------------------------'''
						addon = 'plugin.video.ultimateguitar'
						if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
							xbmc.executebuiltin('RunAddon('+ addon +')')
							'''---------------------------'''
						else: installaddon(admin, addon, "")
					
				
			if kidsbutton:
				'''------------------------------
				---KIDS-BUTTON-------------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,kidsbutton,1000)')
				#kidssettings("run")
				xbmc.sleep(200)
				#xbmc.executebuiltin('RunAddon(plugin.video.KIDSIL)')
				if systemhasaddon_htptkids: xbmc.executebuiltin('RunAddon(plugin.video.htpt.kids)')
				else:
					xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.htpt.kids,return)')
					if admin: notification("Admin","Addon is missing!","",1000)
				'''---------------------------'''
				
			if mov3dsbutton:
				'''------------------------------
				---3D-MOVIES-BUTTON--------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,mov3dsbutton,1000)')
				#xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.movie25/?fanart;genre;iconimage=https%3a%2f%2fraw.github.com%2fmash2k3%2fMashupArtwork%2fmaster%2fskins%2fvector%2f3d.png;mode=223;name=3D%20Movies;plot;url=3D,return)')
				notification_common("10")
				'''---------------------------'''
			elif gadgetbutton:
				'''------------------------------
				---GADGET-BUTTON-----------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,gadgetbutton,1000)')
				#if not systemplatformwindows: xbmc.executebuiltin('RunAddon(plugin.video.engadget)')
				notification_common("10")
				'''---------------------------'''
			elif karaokebutton:
				'''------------------------------
				---KARAOKE-BUTTON----------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,karaokebutton,1000)')
				xbmc.executebuiltin('RunAddon(plugin.video.MikeysKaraoke)')
				'''---------------------------'''
			elif gametrailersbutton:
				'''------------------------------
				---GAMERS-BUTTON-----------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,gametrailersbutton,1000)')
				xbmc.executebuiltin('RunAddon(plugin.video.g4tv)')
				'''---------------------------'''
			elif guitarbutton:
				'''------------------------------
				---GAMERS-BUTTON-----------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,guitarbutton,1000)')
				xbmc.executebuiltin('RunAddon(plugin.video.ultimateguitar)')
				'''---------------------------'''
			elif adultbutton2:
				'''------------------------------
				---ADULT-MOVIE-BUTTON------------
				------------------------------'''
				adultbutton2_(admin)
				'''---------------------------'''
						
			if radiobutton:
				'''------------------------------
				---RADIO-BUTTON------------------
				------------------------------'''
				print printfirst + "radiobutton"
				xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.israelive/?categoryid=9999&description&displayname=10000&iconimage=http%3a%2f%2fmdmorrope.gob.pe%2fportalweb%2fimagenes%2fradioss.png&mode=2&name=%5bCOLOR%20chartreuse%5d%5bB%5d%5b%d7%a8%d7%93%d7%99%d7%95%5d%5b%2fB%5d%5b%2fCOLOR%5d&url,return)')
				xbmc.sleep(700)
				containernumitems = xbmc.getInfoLabel('Container.NumItems')
				if systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow') or containernumitems == '0':
					xbmc.executebuiltin('RunAddon(plugin.video.israelive)')
					xbmc.sleep(700)
					if xbmc.getInfoLabel('Container.FolderPath') == 'plugin://plugin.video.israelive/':
						xbmc.executebuiltin('Action(PageUp)')
						xbmc.executebuiltin('Action(Down)')
						xbmc.executebuiltin('Action(Down)')
						xbmc.executebuiltin('Action(Select)')
		elif vhomecon1:
			notification_common("5")
			'''---------------------------'''

	if skinsettingsW: skinbuttons(admin)
	if custom1170W or loginscreenW: helpbuttons(admin)
	leftmenu('run')
	miscbuttons(admin)
	autoviewoff = xbmc.getInfoLabel('Skin.HasSetting(AutoViewoff)')
	if myvideonavW or mypicsW or mymusicnavW or myprogramsW or settingsW or filemanagerW or myweatherW or dialogfavouritesW:
		if home_pW and validation2: mac7('run',macaddress,maccon1,maccon2,maccon10,maccon11)
	if autoviewoff:
		print printfirst + "autoviewoff"
		xbmc.sleep(2000)
		xbmc.executebuiltin('Skin.ToggleSetting(AutoViewoff)')
	startup(validation)
	topvideoinformation2(admin)
	setGeneral_ScriptON("1", General_ScriptON, "")