import xbmc, xbmcgui, xbmcaddon
import subprocess, os, sys
from variables import *
from shared_modules import *
#from shared_modules2 import *
#from modules2 import *

def helpbuttons(admin):
	if custom1170W or loginscreenW:
		'''------------------------------
		---HELP-/-LOGINSCREEN-WINDOWS----
		------------------------------'''
		xbmc.sleep(40)
		#if admin: xbmc.executebuiltin('Notification(Admin,custom1170,1000)')
		#sgbserviceszeroconf = xbmc.getCondVisibility('System.GetBool(services.zeroconf)')
		from variables import sgbserviceszeroconf, sgbservicesairplay
		if airplaybutton:
			'''------------------------------
			---AIRPLAY-BUTTON----------------
			------------------------------'''
			printpoint = ""
			xbmc.executebuiltin('ActivateWindow(servicesettings)')
			settingscategoryW = xbmc.getCondVisibility('Window.IsVisible(SettingsCategory.xml)')
			count = 0
			while count < 10 and not settingscategoryW and not xbmc.abortRequested:
				if count == 0: printpoint = printpoint + "0"
				xbmc.sleep(40)
				settingscategoryW = xbmc.getCondVisibility('Window.IsVisible(SettingsCategory.xml)')
				count += 1
			settingslevelset("2")
			'''---------------------------'''
			if not sgbserviceszeroconf:
				printpoint = printpoint + "1"
				count = 0
				systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
				while count < 5 and systemcurrentcontrol != str1259 and not xbmc.abortRequested:
					'''Zeroconf'''
					if count == 0: printpoint = printpoint + "2"
					systemcurrentcontrol = findin_systemcurrentcontrol("0",str1259,40,'Action(Left)','Action(Down)')
					count += 1
					'''---------------------------'''
				count = 0
				while count < 5 and not str1260 in systemcurrentcontrol and not xbmc.abortRequested:
					'''Announce these services to other systems via Zeroconf'''
					if count == 0:
						printpoint = printpoint + "3"
						systemcurrentcontrol = findin_systemcurrentcontrol("1",str1260,40,'','Action(Select)')
					else: systemcurrentcontrol = findin_systemcurrentcontrol("1",str1260,40,'Action(Down)','Action(Select)')
					count += 1
					'''---------------------------'''
				count = 0
				while count < 5 and systemcurrentcontrol != str1259 and not xbmc.abortRequested:
					'''Zeroconf'''
					if count == 0: printpoint = printpoint + "2"
					systemcurrentcontrol = findin_systemcurrentcontrol("0",str1259,40,'Action(Up)','Action(Right)')
					count += 1
					'''---------------------------'''
				sgbserviceszeroconf = xbmc.getCondVisibility('System.GetBool(services.zeroconf)')
				
			if sgbserviceszeroconf:
				printpoint = printpoint + "4"
				'''---------------------------'''
				systemcurrentcontrol = findin_systemcurrentcontrol("0",str1273,40,'Action(Left)','Action(Down)')
				count = 0
				while count < 5 and systemcurrentcontrol != str1273 and not xbmc.abortRequested:
					'''AirPlay'''
					if count == 0: printpoint = printpoint + "5"
					systemcurrentcontrol = findin_systemcurrentcontrol("0",str1273,40,'Action(Left)','Action(Down)')
					count += 1
					'''---------------------------'''
				
				systemcurrentcontrol = findin_systemcurrentcontrol("1",str1273,40,'Action(Down)','')
				count = 0
				while count < 5 and not str1273 in systemcurrentcontrol and not xbmc.abortRequested:
					'''if Allow to receive AirPlay content'''
					if count == 0: printpoint = printpoint + "6"
					systemcurrentcontrol = findin_systemcurrentcontrol("1",str1273,40,'Action(Down)','')
					count += 1
					'''---------------------------'''
				if count < 5:
					printpoint = printpoint + "8"
					systemcurrentcontrol = findin_systemcurrentcontrol("1",str1273,40,'','Action(Select)')
					xbmc.sleep(500)
					if sgbservicesairplay: systemcurrentcontrol = findin_systemcurrentcontrol("1",str1273,40,'','Action(Select)')
					'''---------------------------'''
				
				xbmc.executebuiltin('Action(Back)')
				xbmc.sleep(1000)
				xbmc.executebuiltin('Action(Down)')
				sgbservicesairplay = xbmc.getCondVisibility('System.GetBool(services.airplay)')
				sgbserviceszeroconf = xbmc.getCondVisibility('System.GetBool(services.zeroconf)')
				xbmc.sleep(500)
				if sgbserviceszeroconf and sgbservicesairplay:
					printpoint = printpoint + "7"
					notification_common("13")
					dialogok('[COLOR=Yellow]' + localize(75794) + '[/COLOR]', localize(75780), localize(75779), "")
					returned = dialogyesno(localize(75778), localize(75777))
					if returned != "ok":
						'''Extra Help with AirPlay'''
						dialogok('[COLOR=Yellow]' + localize(75778) + '[/COLOR]', localize(75785) + space2, localize(75776), "")
					#xbmc.executebuiltin('Notification($LOCALIZE[79063],$LOCALIZE[79064],5000)')
					
				elif not sgbserviceszeroconf: notification('$LOCALIZE[257]','$LOCALIZE[34302]',"",4000)
				else:
					printpoint = printpoint + "9"
			
			'''------------------------------
			---PRINT-END---------------------
			------------------------------'''
			if admin: print printfirst + "airplaybutton_LV" + printpoint
			'''---------------------------'''

		'''buttons which require internet'''
		if connected:
			if messagebutton:
				notification_common("10")
				if systemplatformwindows:
					xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.programm.htptmail/mailbox/INBOX/,return)')
					'''---------------------------'''
			if debugbutton:
				if not systemhasaddon_htptdebug: xbmc.executebuiltin('ActivateWindow(10001,plugin://script.htpt.debug/)')
				else: xbmc.executebuiltin('RunAddon(script.htpt.debug,,?mode=1)')
				'''---------------------------'''
		elif vhomecon1: xbmc.executebuiltin('Notification($LOCALIZE[79512],$LOCALIZE[21451],5000)')		
			
def skinbuttons(admin):
	if skinsettingsW:
		if adultbutton:
			'''------------------------------
			---ADULT-GAMES-------------------
			------------------------------'''
			print printfirst + space + "adultbutton"
			xbmc.executebuiltin('Skin.ToggleSetting(Adult)')
			if not systemplatformwindows:
				xbmc.sleep(1000)
				os.system('sh /storage/.kodi/addons/script.htpt.emu/specials/scripts/copyemu.sh')
			if not adult:
				'''------------------------------
				---ADULT-BUTTON-OFF->ON----------
				------------------------------'''
				returned = dialogyesno(localize(75791), localize(75792))
				if returned == "ok":
					'''------------------------------
					---ADULT-ALWAYS-ON---------------
					------------------------------'''
					setSkinSetting("1",'Adult2',"true")
					'''---------------------------'''
				else:
					'''------------------------------
					---ADULT-ALWAYS-OFF--------------
					------------------------------'''
					setSkinSetting("1",'Adult2',"false")
					'''---------------------------'''
				setSkinSetting("1",'Admin2',"false")
				'''---------------------------'''
				list0 = xbmc.getInfoLabel('$LOCALIZE[75003]')
				list1 = xbmc.getInfoLabel('$LOCALIZE[15016]')
				returned, value = dialogselect(localize(75793), [list0, list1],0)
				if returned == -1:
					dialogok(localize(75790), localize(75781), "", "") #Quick startup has canceled
				else:
					xbmc.executebuiltin('ActivateWindow(Home.xml)')
					xbmc.sleep(200)
					'''---------------------------'''
					if returned == 0: adultbutton2_(admin)
					elif returned == 1:
						gamesbutton_(admin)
						xbmc.sleep(1000)
						xbmc.executebuiltin('Action(PageDown)')
			else: setSkinSetting("1",'Adult2',"false")
		
		elif paymentmethodbutton:
			'''------------------------------
			---PAYMENT-TERMS-----------------
			------------------------------'''
			list0 = xbmc.getInfoLabel('$LOCALIZE[70014]')
			list1 = xbmc.getInfoLabel('$LOCALIZE[70015]')
			list2 = xbmc.getInfoLabel('$LOCALIZE[70016]')
			returned, value = dialogselect('$LOCALIZE[70012]',[list0, list1, list2],0)
			returned = int(returned)
			returnedS = str(returned)
			returned2 = "list" + returnedS
			if returned == -1: pass
			else: setSkinSetting("0",'ID6',value)
			
def startup(validation):
	
	validation = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION)')
	if (startup_aW or loginscreen_aW) and not validation:
		if admin: print printfirst + "startup (1)"
		xbmc.executebuiltin('ReplaceWindow(Home)')
		mac7('run',macaddress,maccon1,maccon2,maccon10,maccon11)
		'''---------------------------'''
		externalusb("")
	
def HelpButton_Video_Pic(name, path2):
	returned = supportcheck(name, ["A", "B", "A?", "B?"], totalspace=100, Intel=False, silence=True)
	if returned == 'ok': device = "0"
	else: device = "1"
	containernumitems = xbmc.getInfoLabel('Container.NumItems')
	try: containernumitemsN = int(containernumitems)
	except: containernumitemsN = 0
	
	if containernumitemsN < 2: dialogok('[COLOR=Yellow]' + addonString(120) % (name) + '[/COLOR]', addonString(123) % (name),localize(75797),"")
	usb1str = xbmc.getInfoLabel('Skin.String(USB1)')
	
	'''---------------------------'''
	if name != str2:
		if device == "0": dialogok(addonString(124) % (id10str) + '[CR]' + servicehtptfix_Purchase_Model, addonString(125) % (servicehtptfix_Purchase_TotalSpace),addonString(126) % (name),"", line1c="Yellow")
		elif device == "1": dialogok(addonString(124) % (id10str) + '[CR]' + servicehtptfix_Purchase_Model, localize(74541),addonString(155) % (usb1str),"", line1c="Yellow")
		'''---------------------------'''
	if systemplatformwindows:
		returned = dialogyesno(addonString(134) % (name),addonString(135) % (name, localize(74558)))
		if returned == "ok":
			header = space + "(" + localize(74558) + ")" + space + '[COLOR=Yellow]' + addonString(129) % (name) + '[/COLOR]'+ space
			extra = newline + "Your library path: " + pictures_path + newline
			if name == str1 or name == str3: message2 = addonString(132) % (name, path2, name) + extra + localize(74542)
			elif name == str2: message2 = addonString(172) % (name) + extra + localize(74542)
			w = TextViewer_Dialog('DialogTextViewer.xml', "", header=header, text=message2)
			w.doModal()
			'''---------------------------'''
			
	elif device == "0":
		returned = dialogyesno(addonString(134) % (name),addonString(135) % (name, localize(74558)))
		if returned == "ok":
			header = space + "(" + localize(74558) + ")" + space + '[COLOR=Yellow]' + addonString(129) % (name) + '[/COLOR]'+ space
			if name == str1 or name == str3: message2 = addonString(132) % (name, path2, name) + localize(74542)
			elif name == str2: message2 = addonString(172) % (name) + localize(74542)
			w = TextViewer_Dialog('DialogTextViewer.xml', "", header=header, text=message2)
			w.doModal()
			
			header = space + "(" + localize(74558) + ")" + space + '[COLOR=Yellow]' + addonString(136) % (name) + '[/COLOR]' + space
			if name == str1 or name == str3: message2 = addonString(137) % ("\\\\" + "htpt", path2, name, name) +localize(74542)
			elif name == str2: message2 = addonString(173) % ("\\\\" + "htpt", path2, name, name, name) + localize(74542)
			w = TextViewer_Dialog('DialogTextViewer.xml', "", header=header, text=message2)
			w.doModal()
			'''---------------------------'''
	
	elif device == "1":
		returned = dialogyesno(addonString(134) % (name),addonString(135) % (name, localize(74559)))
		if returned == "ok":
			header = space + "(" + localize(74559) + ")" + space + '[COLOR=Yellow]' + addonString(129) % (name) + '[/COLOR]' + space
			message2 = addonString(155) % (usb1str) + '[CR]' + addonString(156) % (path2) + '[CR]' + addonString(157) % (path2, name) + localize(74542)
			w = TextViewer_Dialog('DialogTextViewer.xml', "", header=header, text=message2)
			w.doModal()
			
			header = space + "(" + localize(74559) + ")" + space + '[COLOR=Yellow]' + addonString(136) % (name) + '[/COLOR]' + space
			message2 = addonString(137) % ("\\\\" + "htpt", str79498 + " -> " + usb1str + " -> " + path2 , name, name) + localize(74542)
			w = TextViewer_Dialog('DialogTextViewer.xml', "", header=header, text=message2)
			w.doModal()
			'''---------------------------'''
			
def topvideoinformation2(admin):
	'''------------------------------
	---Clear ListItem----------------
	------------------------------'''
	containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
	listitemtvshowtitlestr = xbmc.getInfoLabel('Skin.String(ListItemTVShowTitle)')
	'''---------------------------'''
	if not "videodb://tvshows" in containerfolderpath and not "library://video/tvshows" in containerfolderpath:
		setSkinSetting("0",'ListItemGenre',"")
		setSkinSetting("0",'ListItemDuration',"")
		setSkinSetting("0",'ListItemRating',"")
		setSkinSetting("0",'ListItemYear',"")
		setSkinSetting("0",'ListItemTVShowTitle',"")
		if listitemtvshowtitlestr: print printfirst + "topvideoinformation2" + space2 + "Clear ListItem"
		'''---------------------------'''

def settingslevelset(custom):
	'''custom: 1 = Basic, 2 = Standard, 3 = Advanced, 4 = Expert'''
	if custom == "1": custom = settingslevelstr1
	elif custom == "2": custom = settingslevelstr2
	elif custom == "3": custom = settingslevelstr3
	elif custom == "4": custom = settingslevelstr4
	else: sys.exit(1)
	'''---------------------------'''
	printpoint = ""
	settingslevel = xbmc.getInfoLabel('Skin.String(SettingsLevel)')
	'''---------------------------'''
	if settingslevel != custom:
		controlhasfocus = findin_controlhasfocus("0","20",40,'Control.SetFocus(20)','')
		count = 0
		while count < 5 and not controlhasfocus and not xbmc.abortRequested:
			if count == 0: printpoint = printpoint + "2"
			controlhasfocus = findin_controlhasfocus("0","20",40,'Control.SetFocus(20)','')
			count += 1
			'''---------------------------'''
		if controlhasfocus:
			printpoint = printpoint + "3"
			count = 0
			while count < 5 and settingslevel != custom and not xbmc.abortRequested:
				if count == 0: printpoint = printpoint + "5"
				count += 1
				systemcurrentcontrol = findin_systemcurrentcontrol("0",custom,10,'Action(Select)','Action(Down)')
				settingslevel = xbmc.getInfoLabel('Skin.String(SettingsLevel)')
				'''---------------------------'''
		else: printpoint = printpoint + "9"
	else:
		printpoint = printpoint + "8"
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "settingslevelset_LV" + printpoint
	'''---------------------------'''
	
def adultbutton2_(admin):
	'''------------------------------
	---?-----------------------------
	------------------------------'''
	addon = 'repository.xbmcadult'
	if not xbmc.getCondVisibility('System.HasAddon('+ addon +')'): installaddon2(admin, addon, update=True) ; xbmc.sleep(1000) ; xbmc.executebuiltin('Action(Back)') ; xbmc.sleep(1000)

	addon = 'plugin.video.videodevil'
	if xbmc.getCondVisibility('System.HasAddon('+ addon +')'): xbmc.executebuiltin('RunAddon(plugin.video.videodevil)')
	else: installaddon(admin, addon, "", update=True)
	'''---------------------------'''
	
def gamesbutton_(admin):
	if not systemplatformwindows: os.system('sh /storage/.kodi/addons/script.htpt.emu/specials/scripts/launcher.sh')
	xbmc.executebuiltin('RunAddon(plugin.program.advanced.launcher)')
	xbmc.sleep(2000)
	systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
	containernumitems = xbmc.getInfoLabel('Container.NumItems')
	'''---------------------------'''
	if (systemcurrentcontrol == "[..]" or systemcurrentcontrol == "[Default]") and (containernumitems == "0" or containernumitems == "1"):
		'''------------------------------
		---FIX-CONFIGURATION-FILE--------
		------------------------------'''
		print printfirst + space + "gamesbutton" + space + "Possible Error in file: launcher.xml"
		dialogok(localize(75795), localize(75796),"","")
		if not systemplatformwindows: os.system('sh /storage/.kodi/addons/script.htpt.emu/specials/scripts/copyemu.sh')
		xbmc.executebuiltin('ActivateWindow(Home.xml)')
		xbmc.sleep(2000)
		xbmc.executebuiltin('RunAddon(plugin.program.advanced.launcher)')
		'''---------------------------'''
	else:
		if not os.path.exists(os.path.join(rom_path,'Sega Master System')) and not os.path.exists(os.path.join(rom_path,'TurboGrafx 16')) and not os.path.exists(os.path.join(rom_path,'Sega Genesis')):
			dialogok("You currently have no games!", "Choose the Advanced Options button (Left Menu), then Choose YES.", "Click once on the Downloading Games button, then Choose Confirm to dow", "")
		elif servicehtptfix_Purchase_Bluetooth == "":
			returned = dialogyesno("Bluetooth support", "Click YES in order to learn how to sync your PS3 controller")
			if returned == 'ok':
				diaogtextviewer("How to sync your PS3 controller", "This guide assume your hardware have a supported bluetooth adapter.[CR]If it's not then note that you maybe able to play with your PS3 cable attached![CR][CR]1. Enable your bluetooth by Choosing the Joystick Status button (left menu) then go up + right into service tab.[CR]Select the Enable Bluetooth option.[CR]2. Plug in your PS3 cable (Use 2.0 usb slot), connect it to the PS3 controller.[CR]Note: If the lights are blinking then your controller is charging.[CR]3. Click the PS button once.[CR]Note: The blinked lights are now off and your 1 player slot should light up.[CR]4. Unplug the PS3 cable.[CR]Note: The lights will blink and the controller should be auto sync in a few seconds.[CR]If that's not occur it's recommend to reboot your device.[CR]5. If the 1P light isn't on but 2-4P, you should unplug your others bluetooth device (one time), disconnect your PS3 controller by using the Josytick Status button, then turn on the PS3 controller by using the PS3 button.[CR][CR]- You can enable up to 4 PS3 controllers at once, they are all able to control your interface and in-game (ofcourse).")

def externalusb(device):
	'''detect connected USB'''
	name = 'externalusb' ; printpoint = ""
	if device == "":
		printpoint = printpoint + "1"
		returned = supportcheck(name, ["A", "B", "A?", "B?"], totalspace=100, Intel=False, silence=True)
		if returned == 'ok': device = "0"
		else: device = "1"
		
	if not systemplatformwindows and myhtpt2:
		printpoint = printpoint + "2"
		if picturesbutton or videosbutton or startup_aW:
			os.system('sh /storage/.kodi/addons/skin.htpt/specials/scripts/externalusb.sh')
			printpoint = printpoint + "3"
			#xbmc.sleep(500)
		if os.path.exists('/storage/externalusb.log'):
			log = open('/storage/externalusb.log', 'r')
			rows = log.readlines()
			rowscountN = len(rows)
			rowscount = str(rowscountN)
			log.close()
			row1 = ""
			row2 = ""
			row3 = ""
			row4 = ""
			row5 = ""
			if rowscountN > 0: row1 = rows[0][:-1]
			if rowscountN > 1: row2 = rows[1][:-1]
			if rowscountN > 2: row3 = rows[2][:-1]
			if rowscountN > 3: row4 = rows[3][:-1]
			if rowscountN > 4: row5 = rows[4][:-1]
			if picturesbutton or videosbutton or startup_aW:
				printpoint = printpoint + "4"
				if usb1str != row1: xbmc.executebuiltin('Skin.SetString(USB1,'+ row1 +')')
				if usb2str != row2: xbmc.executebuiltin('Skin.SetString(USB2,'+ row2 +')')
				if usb3str != row3: xbmc.executebuiltin('Skin.SetString(USB3,'+ row3 +')')
				if usb4str != row4: xbmc.executebuiltin('Skin.SetString(USB4,'+ row4 +')')
				if usb5str != row5: xbmc.executebuiltin('Skin.SetString(USB5,'+ row5 +')')
				'''---------------------------'''
			if admin and rowscountN > 0: xbmc.executebuiltin('Notification(Admin,'+ rowscount +' '+ row1 +' ,1000)')
			path0 = 'special://userdata/library/'
			path1 = os.path.join(varmedia_path, row1)
			path2 = os.path.join(varmedia_path, row2)
			path3 = os.path.join(varmedia_path, row3)
			path4 = os.path.join(varmedia_path, row4)
			path5 = os.path.join(varmedia_path, row5)
			pathwin = 'special://home/external/'
			if rowscountN == 0 and myhtpt3: xbmc.executebuiltin('Skin.ToggleSetting(myHTPT3)')
			if rowscountN > 0 and not myhtpt3: xbmc.executebuiltin('Skin.ToggleSetting(myHTPT3)')
			'''---------------------------'''
			#myvideonavW = xbmc.getCondVisibility('Window.IsVisible(MyVideoNav.xml)')
			#mypicsW = xbmc.getCondVisibility('Window.IsVisible(MyPics.xml)')
			containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
			
			if (myvideonavW or mypicsW) and usbtoggle:
				printpoint = printpoint + "5"
				#xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,)')
				#xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,)')
				if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path0 +')') and rowscountN > 0:
					if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path1 +'/videos/,return)')
					if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path1 +'/pictures/,return)')
					xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,1)')
					xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path1 +')')
				elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path1 +')') and rowscountN > 1:
					if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path2 +'/videos/,return)')
					if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path2 +'/pictures/,return)')
					xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,2)')
					xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path2 +')')
				elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path2 +')') and rowscountN > 2:
					if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path3 +'/videos/,return)')
					if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path3 +'/pictures/,return)')
					xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,3)')
					xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path3 +')')
				elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path3 +')') and rowscountN > 3:
					if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path4 +'/videos/,return)')
					if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path4 +'/pictures/,return)')
					xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,4)')
					xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path4 +')')
					'''---------------------------'''
				elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path4 +')') and rowscountN > 4:
					if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path5 +'/videos/,return)')
					if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path5 +'/pictures/,return)')
					xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,5)')
					xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path5 +')')
					'''---------------------------'''
					
				if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path1 +')') and rowscountN == 1:
					printpoint = printpoint + "A"
					if device == "1":
						notification('$LOCALIZE[74546]', '$LOCALIZE[74547]', '', 2000)
						if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path1 +'/videos/,return)')
						elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path1 +'/pictures/,return)')
						'''---------------------------'''
					elif myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'/videos/,return)')
					elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'/pictures/,return)')
				elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path2 +')') and rowscountN == 2:
					if device == "1":
						if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path1 +'/videos/,return)')
						elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path1 +'/pictures/,return)')
						'''---------------------------'''
					elif myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'/videos/,return)')
					elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'/pictures/,return)')
				elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path3 +')') and rowscountN == 3:
					if device == "1":
						if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path1 +'/videos/,return)')
						elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path1 +'/pictures/,return)')
						'''---------------------------'''
					elif myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'/videos/,return)')
					elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'/pictures/,return)')
				elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path4 +')') and rowscountN == 4:
					if device == "1":
						if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path1 +'/videos/,return)')
						elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path1 +'/pictures/,return)')
						'''---------------------------'''
					elif myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'/videos/,return)')
					elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'/pictures/,return)')
				elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path5 +')') and rowscountN == 5:
					if device == "1":
						if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path1 +'/videos/,return)')
						elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path1 +'/pictures/,return)')
						'''---------------------------'''
					elif myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'/videos/,return)')
					elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'/pictures/,return)')
					'''---------------------------'''
				xbmc.sleep(20)
				containernumitems = xbmc.getInfoLabel('Container.NumItems')
				if containernumitems == 0: xbmc.executebuiltin('Action(Select)')
			elif device == "1":
				printpoint = printpoint + "8" ; extra = ""
				if videosbutton: extra = '/videos/'
				elif picturesbutton: extra = '/pictures/'
				
				if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path0 +')') and rowscountN > 0:
					setSkinSetting("0",'VarCurrentPicVid', "1")
					setSkinSetting("0",'VarCurrentPicVidPath', path1 + extra)
				else:
					setSkinSetting("0",'VarCurrentPicVid', "")
					setSkinSetting("0",'VarCurrentPicVidPath', "")
			if admin: print printfirst + name + "_LV" + printpoint + space + "mypicsW" + space2 + str(mypicsW) + space + "myvideonavW" + space2 + str(myvideonavW) + space + "containerfolderpath" + space2 + str(containerfolderpath) + space + "device" + space2 + str(device) + newline + "path1" + space2 + path1 + space + "rowscountN" + space2 + str(rowscountN) + newline + space
		
def mac7(run,macaddress,maccon1,maccon2,maccon10,maccon11):
	'''VALIDATION PROOF'''
	validation2 = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION2)')
	printpoint = ""
	if ((not maccon1 and not maccon2) or (not maccon10 and not maccon11)) and not id40str:
		xbmc.sleep(200)
		xbmc.executebuiltin('Notification(MAC7,step 1,1000)')
		if (not maccon1 and not maccon2):
			#macaddress = xbmc.getInfoLabel('Network.MacAddress')
			xbmc.executebuiltin('Skin.SetString(MAC,'+ macaddress +')')
			xbmc.sleep(500)
			maccon1 = xbmc.getCondVisibility('StringCompare(Skin.String(MAC),Skin.String(MAC1))')
			maccon2 = xbmc.getCondVisibility('StringCompare(Skin.String(MAC),Skin.String(MAC2))')
			printpoint = printpoint + "1"
		else:
			maccon10 = xbmc.getCondVisibility('StringCompare(Control.GetLabel(700100),NONE)')
			maccon11 = xbmc.getCondVisibility('StringCompare(Control.GetLabel(700100),7000)')
			printpoint = printpoint + "2"
		xbmc.sleep(200)
		if (not maccon1 and not maccon2) or (not maccon10 and not maccon11) and not id40str:
			if validation5 == '0':
				xbmc.executebuiltin('Notification(Admin,MAC7,step 2,1000)')
				if not validation: xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION)')
				if not validation2: xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION2)')
				if not widget: xbmc.executebuiltin('Skin.ToggleSetting(Widget)')
				xbmc.executebuiltin('Notification($LOCALIZE[79080],For Support: [COLOR Yellow]$LOCALIZE[79081][/COLOR],5000,icons/shield.png)')
				if macaddress and not loginscreenW and home_pW: xbmc.executebuiltin('ReplaceWindow(LoginScreen.xml)')
				if validation and playerhasmedia: xbmc.executebuiltin('Action(Stop)')
				
				if not maccon1 and not maccon2 and validation and not macaddress and id9str != 'COPIED':
					xbmc.executebuiltin('Skin.SetString(ID9,COPIED)')
					xbmc.executebuiltin('Notification(COPIED,,5000)')
					xbmc.executebuiltin('ReplaceWindow(LoginScreen.xml)')
				printpoint = printpoint + "3"
			else:
				if validation5 == '3': xbmc.executebuiltin('Skin.SetString(VALIDATION5,2)')
				if validation5 == '2': xbmc.executebuiltin('Skin.SetString(VALIDATION5,1)')
				if validation5 == '1': xbmc.executebuiltin('Skin.SetString(VALIDATION5,0)')
				
				xbmc.executebuiltin('Notification(Admin MAC7:,-validation5 reduced from ('+ validation5 +')')
				printpoint = printpoint + "4"
	else:
		'''UNLOCK'''
		printpoint = printpoint + "5"
		if validation2:
			printpoint = printpoint + "6"
			if connected:
				xbmc.sleep(2000)
				if not id40str: notification(localize(79086),localize(79084) + space + ":)","",3000)
				else: pass
				xbmc.sleep(1000)
				validation2 = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION2)')
				if validation2: xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION2)')
				printpoint = printpoint + "7"
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + space + "mac7_LV" + printpoint + space3
	'''---------------------------'''

def mac(run,macaddress):
	if validation and (home_aW or startup_aW or startup_pW or loginscreenbutton):
		print printfirst + "mac (1)"
		xbmc.sleep(40)
		if macaddress and macaddress != str503:
			macaddress = xbmc.getInfoLabel('Network.MacAddress')
			xbmc.executebuiltin('Skin.SetString(MAC,'+ macaddress +')')
			xbmc.sleep(500)
		if not validation2: xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION2)')
		if validation5 == '3':
			xbmc.executebuiltin('Skin.SetString(VALIDATION5,2)')
			xbmc.executebuiltin('AlarmClock(HTPTCHECK: '+ idstr +'*0 | '+ id1str +'*1 | '+ id2str +'*2 | '+ id3str +'*3 | '+ id4str +'*4 | '+ id5str +'*5 | '+ id6str +'*6 | '+ id7str +'*7 | '+ id8str +'*8 | '+ id9str +'*9 | '+ id10str +'*10 | '+ mac1str +'*MAC1 | '+ mac2str +'*MAC2 | '+ mac3str +'*MAC3 | '+ macaddress +'*MAC | '+ systemtotaluptime +'*TOTALUPTIME | '+ verrorstr +'*VERROR | ,Action(Stop),0,silent)')
			if not connected2 and not connected3:
				if startup_aW: xbmc.executebuiltin('AlarmClock(loginscreendelay,ReplaceWindow(LoginScreen.xml),00:02,silent)')
				elif systemuptime5:
					if id40str: pass
					else: xbmc.executebuiltin('AlarmClock(loginscreendelay,ReplaceWindow(LoginScreen.xml),00:02,silent)')
		elif validation5 == '2':
			xbmc.executebuiltin('Skin.SetString(VALIDATION5,1)')
			if not maccon10 and not maccon11 and home_aW: xbmc.executebuiltin('Notification($LOCALIZE[79080],$LOCALIZE[257]: $VAR[VERROR],5000,icons/shield.png)')
		elif validation5 == '1':
			xbmc.executebuiltin('Skin.SetString(VALIDATION5,0)')
			xbmc.executebuiltin('Notification($LOCALIZE[79080],For Support: [COLOR Yellow]$LOCALIZE[79081][/COLOR],5000,icons/shield.png)')
		elif validation5 == '0':
			if not loginscreenW: xbmc.executebuiltin('ReplaceWindow(LoginScreen.xml)')
			if loginscreen_aW: xbmc.executebuiltin('Notification($LOCALIZE[79080],For Support: [COLOR Yellow]$LOCALIZE[79081][/COLOR],5000,icons/shield.png)')
		xbmc.sleep(40)
		'''UNLOCK SYSTEM'''
		if (maccon1 or maccon2) and (maccon10 or maccon11) or id40str:
			xbmc.sleep(40)
			print printfirst + "mac (2)"
			xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION)')
			if not widget: xbmc.executebuiltin('Skin.ToggleSetting(Widget)')
			xbmc.executebuiltin('Skin.SetString(VALIDATION5,3)')
			#xbmc.sleep(500)
			if connected:
				xbmc.sleep(40)
				if id40str: pass
				else: notification('$LOCALIZE[79083]', '$LOCALIZE[79082]', '', 5000)
				mac7('run',macaddress,maccon1,maccon2,maccon10,maccon11)
			else:
				if id40str: pass
				else:
					if connected2 or connected3: notification_common("5")
					else: notification_common("4")
			#if home_aW:
				#xbmc.executebuiltin('Control.SetFocus('+ container9000pos +')')
				#xbmc.sleep(500)
				#if admin: xbmc.executebuiltin('Notification(Admin, '+ container9000pos +',2000,icons/shield2.png)')
				#xbmc.executebuiltin('Action(Select)')
			if loginscreen_aW:
				#xbmc.executebuiltin('ActivateWindow(0)')
				xbmc.executebuiltin('ReplaceWindow(0)')
				
