import xbmc, xbmcaddon, xbmcgui
#import subprocess, os, sys

from variables import *
from shared_modules import *
#from modules import *

