import xbmc, xbmcgui, xbmcaddon
import subprocess, os, sys
from variables import *
from shared_modules import *
#from shared_modules2 import *
#from modules2 import *

def setAutoSettings(custom):

	if custom == "0":
		
		addon = 'screensaver.picture.slideshow'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			'''------------------------------
			--screensaver.picture.slideshow--
			------------------------------'''
			addonsettings2(addon,'cache',"false",'create',"",'date',"",'effect',"2",'iptc',"false")
			addonsettings2(addon,'label',"0",'level',"100",'music',"false",'scale',"false",'random',"true")
			addonsettings2(addon,'type',"0",'path',"",'',"",'',"",'time',"10")
			'''---------------------------'''
		else:
			installaddon(admin, addon, "")
			'''---------------------------'''
			
		addon = 'script.htpt.debug'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			'''------------------------------
			---script.htpt.debug-------------
			------------------------------'''
			addonsettings2(addon,'',"",'',"",'',"",'',"",'',"")
			'''---------------------------'''
		else:
			installaddon(admin, addon, "")
			'''---------------------------'''
		
		addon = 'script.htpt.refresh'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			'''------------------------------
			---script.htpt.refresh-------------
			------------------------------'''
			addonsettings2(addon,'',"",'',"",'',"",'',"",'',"")
			'''---------------------------'''
		else:
			installaddon(admin, addon, "")
			'''---------------------------'''
		
		addon = 'script.htpt.remote'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			'''------------------------------
			---script.htpt.remote-------------
			------------------------------'''
			addonsettings2(addon,'',"",'',"",'',"",'',"",'',"")
			'''---------------------------'''
		else:
			installaddon(admin, addon, "")
			'''---------------------------'''
			
		addon = 'script.htpt.smartbuttons'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			'''------------------------------
			---script.htpt.smartbuttons------
			------------------------------'''
			addonsettings2(addon,'',"",'',"",'',"",'',"",'',"")
			'''---------------------------'''
		else:
			installaddon(admin, addon, "")
			'''---------------------------'''
		
		addon = 'service.htpt.fix'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			'''------------------------------
			---service.htpt.fix--------------
			------------------------------'''
			addonsettings2(addon,'',"",'',"",'',"",'',"",'',"")
			'''---------------------------'''
		else:
			installaddon(admin, addon, "")
			'''---------------------------'''
				
		addon = 'plugin.video.sdarot.tv'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			'''------------------------------
			---plugin.video.sdarot.tv--------
			------------------------------'''
			addonsettings('SDAROT TV', 'plugin.video.sdarot.tv', 'Account2_Active', 'Account2_Period', 'username','user_password', "", "", "", "")
			addonsettings2(addon,'DEBUG',"false",'cache',"24",'domain',"http://www.sdarot.wf",'',"",'',"")
		
			if not systemplatformwindows: bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.video.sdarot.tv/sdarot-cookiejar.txt',"plugin.video.sdarot.tv")
			'''---------------------------'''
		else:
			installaddon(admin, addon, "")
			'''---------------------------'''
		
		addon = 'metadata.universal'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			'''------------------------------
			---metadata.universal------------
			------------------------------'''
			pass
			'''---------------------------'''
		else:
			installaddon(admin, addon, "")
			'''---------------------------'''
			
		addon = 'service.subtitles.subtitle'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			'''------------------------------
			---service.subtitles.subtitle----
			------------------------------'''
			addonsettings2(addon,'SUBemail',idstr + "@gmail.com",'SUBpassword',idpstr,'',"",'',"",'',"")
			if not systemplatformwindows: bash('rm -rf /storage/.kodi/userdata/addon_data/'+addon+'/cookiejar.txt',"service.subtitles.subtitle")
			if not systemplatformwindows: bash('rm -rf /storage/.kodi/userdata/addon_data/'+addon+'/temp/',addon + space + "Temp Folder")
			'''---------------------------'''
		else:
			installaddon(admin, addon, "")
			'''---------------------------'''
		
		addon = 'service.subtitles.opensubtitles'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			'''------------------------------
			-service.subtitles.opensubtitles-
			------------------------------'''
			addonsettings2(addon,'OSuser',idstr + "@gmail.com",'OSpass',idpstr,'',"",'',"",'',"")
			if not systemplatformwindows: bash('rm -rf /storage/.kodi/userdata/addon_data/'+addon+'/temp/',addon + space + "Temp Folder")
			'''---------------------------'''
		else:
			installaddon(admin, addon, "")
			'''---------------------------'''
		
		addon = 'service.subtitles.subscenter'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			'''------------------------------
			---service.subtitles.subscenter--
			------------------------------'''
			addonsettings2(addon,'',"",'',"",'',"",'',"",'',"")
			if not systemplatformwindows: bash('rm -rf /storage/.kodi/userdata/addon_data/'+addon+'/temp/',addon + space + "Temp Folder")
			'''---------------------------'''
		else:
			installaddon(admin, addon, "")
			'''---------------------------'''
		
		addon = 'service.subtitles.torec'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			'''------------------------------
			---service.subtitles.torec-------
			------------------------------'''
			addonsettings2(addon,'',"",'',"",'',"",'',"",'',"")
			if not systemplatformwindows: bash('rm -rf /storage/.kodi/userdata/addon_data/'+addon+'/temp/',addon + space + "Temp Folder")
			'''---------------------------'''
		else:
			installaddon(admin, addon, "")
			'''---------------------------'''
		
		addon = 'plugin.video.israelive'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			'''------------------------------
			---plugin.video.israelive--------
			------------------------------'''
			if sgbpvrmanagerenabled: addonsettings2(addon,'autoIPTV',"0",'useIPTV',"true",'',"",'',"",'',"")
			else: addonsettings2(addon,'autoIPTV',"1",'useIPTV',"false",'',"",'',"",'',"")
			addonsettings2(addon,'',"",'useEPG',"true",'StreramProtocol',"1",'forceRemoteDefaults',"true",'StreramsMethod',"0")
			addonsettings2(addon,'catColor',"chartreuse",'useEPG',"true",'chColor',"yellow",'prColor',"floralwhite",'timesColor',"none")
			#setsetting_custom1(addon,remoteSettingsUrl,"")
			
			'''---------------------------'''
		else:
			installaddon(admin, addon, "")
			'''---------------------------'''
		
		addon = 'plugin.video.vdubt'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			'''------------------------------
			---plugin.video.vdubt------------
			------------------------------'''
			addonsettings2(addon,'parental',"true",'sort',"false",'auto-view',"true",'default',"50",'movies',"50")
			'''---------------------------'''
		else:
			installaddon(admin, addon, "")
			'''---------------------------'''
		
		addon = 'plugin.video.youtube'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			'''------------------------------
			---plugin.video.youtube----------
			------------------------------'''
			addonsettings2(addon,'kodion.view.override',"true",'kodion.video.quality',"4",'kodion.view.default',"50",'kodion.view.episodes',"58",'kodion.search.size',"4")
			addonsettings2(addon,'kodion.setup_wizard',"false",'youtube.folder.disliked_videos.show',"false",'youtube.language',"iw-IL",'kodion.fanart.show',"false",'youtube.folder.sign.in.show',"true")
			addonsettings2(addon,'kodion.content.max_per_page',"7",'',"",'',"",'',"",'',"")
			#addonsettings2(addon,'',"",'',"",'',"",'',"",'',"")
			if not systemplatformwindows: bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.video.youtube/kodion/cache.sqlite',"plugin.video.youtube")
			'''---------------------------'''
		else:
			installaddon(admin, addon, "")
			'''---------------------------'''
		
		addon = 'service.autosubs'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			'''------------------------------
			---service.autosubs--------------
			------------------------------'''
			pass
			#addonsettings2(addon,'check_for_specific',"true",'selected_language',"Hebrew",'debug',"false",'ExcludeTime',"15",'ignore_words',"theme")
			#addonsettings2(addon,'ExcludeHTTP',"false",'ExcludeLiveTV',"true",'',"",'',"",'',"")
			'''---------------------------'''
		else:
			pass
			'''---------------------------'''
		
		addon = 'plugin.video.aob'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			'''------------------------------
			---plugin.video.aob--------------
			------------------------------'''
			addonsettings2(addon,'tvshows-view',"58",'default-view',"50",'auto-view',"true",'',"",'',"")
			'''---------------------------'''
		else:
			pass
			'''---------------------------'''
		
		if id10str == "A" or id10str == "B":
			addon = 'plugin.video.p2p-streams'
			if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
				'''------------------------------
				---plugin.video.p2p-streams------
				------------------------------'''
				addonsettings2(addon,'ace-debug',"false",'save',"false",'parser_sync',"true",'run_a_python_script',"http://bit.ly/allparsers",'russian_translation',"true")
				addonsettings2(addon,'addon_history',"true",'items_per_page',"20",'autoconfig',"true",'timezone_new',"496",'hide_porn',"true")
				addonsettings2(addon,'',"",'',"",'',"",'',"",'',"")
				addonsettings2(addon,'',"",'',"",'',"",'',"",'',"")
				#if not systemplatformwindows: bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.video.youtube/kodion/cache.sqlite',"plugin.video.youtube")
				'''---------------------------'''
			else:
				installaddon(admin, addon, "")
				'''---------------------------'''
		
			
		'''------------------------------
		---script.htpt.homebuttons-------
		------------------------------'''	
		dialogtextviewerW = xbmc.getCondVisibility('Window.IsVisible(DialogTextViewer.xml)')
		while dialogtextviewerW and not xbmc.abortRequested:
			xbmc.sleep(1000)
			dialogtextviewerW = xbmc.getCondVisibility('Window.IsVisible(DialogTextViewer.xml)')
			'''---------------------------'''
		set_accountdate('REALDEBRID','plugin.video.genesis', 'realdedrid_user', 'realdedrid_password', realdedrid_user, realdedrid_password, 'Account1_Active', 'Account1_Period', 'Account1_EndDate', Account1_Active, Account1_Period, Account1_EndDate, "1")
		set_accountdate('SDAROT TV','plugin.video.sdarot.tv', 'username', 'user_password', sdarottv_user, sdarottv_password, 'Account2_Active', 'Account2_Period', 'Account2_EndDate', Account2_Active, Account2_Period, Account2_EndDate, "1")
		'''---------------------------'''
	
	elif custom == "1":
		if not adult2: setSkinSetting("1",'adult',"false")
		if not moviesestartup: setSkinSetting("0",'moviesestartup',"1")
		if not tvshowsestartup: setSkinSetting("0",'tvshowsestartup',"1")
		'''---------------------------'''
	
	elif custom == "3":
		
		addon = 'service.htpt'
		if not systemhasaddon_servicehtpt: installaddon(admin, addon, "")
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "setAutoSettings" + space + "custom" + space2 + custom
	'''---------------------------'''

def account_button(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, custom):
	getsetting_addon         = xbmcaddon.Addon(addon).getSetting
	printpoint = ""
	'''---------------------------'''
	if skinsetting:
		'''------------------------------
		---DIALOG-YESNO-USER+PASS--------
		------------------------------'''
		returned = dialogyesno(addonString(74).encode('utf-8'),addonString(75).encode('utf-8') + '[CR]' + addonString(73).encode('utf-8') % (username))
		if returned == 'ok':
			'''------------------------------
			---DIALOG-KEYBOARD-USER----------
			------------------------------'''
			printpoint = printpoint + "1"
			if 'htpt' in username: username = ""
			returned = dialogkeyboard(username,'$LOCALIZE[20142]',0,'3',usernameS,addon)
			if returned == 'skip':
				notification('$LOCALIZE[257]',addonString(69).encode('utf-8'),"",2000)
				printpoint = printpoint + "7"
				'''---------------------------'''
			else:
				'''------------------------------
				---DIALOG-KEYBOARD-PASS----------
				------------------------------'''
				printpoint = printpoint + "2"
				returned = dialogkeyboard(password,'$LOCALIZE[15052]',1,'3',passwordS,addon)
				if returned == 'skip':
					notification('$LOCALIZE[257]',addonString(69).encode('utf-8'),"",2000)
					printpoint = printpoint + "7"
				else:
					printpoint = printpoint + "3"
					'''---------------------------'''
		'''------------------------------
		---DIALOG-YES-NO-PERIOD----------
		------------------------------'''
		if not "7" in printpoint and skinsetting2 != "N/A":
			returned = dialogyesno(addonString(70).encode('utf-8'),addonString(71).encode('utf-8') % (skinsetting2))
			if returned == 'ok':
				printpoint = printpoint + "4"
				returned = dialognumeric(0,addonString(68).encode('utf-8'),skinsetting2,'2',skinsetting2S,"")
				if returned == 'skip': notification('$LOCALIZE[257]',addonString(69).encode('utf-8'),"",2000)
				else:
					printpoint = printpoint + "5"
					
		if printpoint == "" or "7" in printpoint:
			'''------------------------------
			---DIALOG-YES-NO-TURNOFF---------
			------------------------------'''
			returned = dialogyesno(addonString(72).encode('utf-8'),addonString(73).encode('utf-8') % (username))
			if returned == 'ok':
				setSkinSetting("1", skinsettingS, "false")
				setSkinSetting("0", skinsetting2S, "")
				setSkinSetting("0", skinsetting3S, "")
				setsetting_genesis(usernameS, "")
				setsetting_genesis(passwordS, "")
				'''---------------------------'''
			else:
				notification(addonString(66).encode('utf-8'),addonString(67).encode('utf-8'),"",4000)
				'''---------------------------'''
				
		if ("1" in printpoint and "3" in printpoint) or ("4" in printpoint and "5" in printpoint):
			'''------------------------------
			---DIALOG-OK-ACCOUNT-EDITED------
			------------------------------'''
			xbmc.sleep(500)
			skinsetting = xbmc.getInfoLabel('Skin.HasSetting('+ skinsettingS +')')
			skinsetting2 = xbmc.getInfoLabel('Skin.String('+ skinsetting2S +')')
			username = getsetting_addon(usernameS)
			password = getsetting_addon(passwordS)
			'''---------------------------'''
			
			if name == "REALDEBRID":
				'''------------------------------
				---REALDEBRID--------------------
				------------------------------'''
				dialogok(addonString(56).encode('utf-8') % ('[COLOR=Yellow]' + name + '[/COLOR]'),addonString(73).encode('utf-8') % (username),addonString(61).encode('utf-8') % (password),addonString(71).encode('utf-8') % (skinsetting2))
				dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + addonString(76).encode('utf-8'),addonString(77).encode('utf-8'),addonString(78).encode('utf-8'),addonString(79).encode('utf-8'))
				set_accountdate(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, "0")
				'''---------------------------'''
				
			elif name == "SDAROT TV":
				'''------------------------------
				---SDAROT-TV---------------------
				------------------------------'''
				dialogok(addonString(56).encode('utf-8') % ('[COLOR=Yellow]' + name + '[/COLOR]'),addonString(73).encode('utf-8') % (username),addonString(61).encode('utf-8') % (password),addonString(71).encode('utf-8') % (skinsetting2))
				dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + addonString(76).encode('utf-8'),addonString(77).encode('utf-8'),addonString(87).encode('utf-8'),addonString(88).encode('utf-8'))
				set_accountdate(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, "0")
				'''---------------------------'''
			
			elif name == "TRAKT TV":
				'''------------------------------
				---TRAKT-TV----------------------
				------------------------------'''
				dialogok(addonString(56).encode('utf-8') % ('[COLOR=Yellow]' + name + '[/COLOR]'),addonString(73).encode('utf-8') % (username),addonString(61).encode('utf-8') % (password),"")
				dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + addonString(76).encode('utf-8'),addonString(77).encode('utf-8'),addonString(85).encode('utf-8'),addonString(86).encode('utf-8'))
				'''---------------------------'''	

	else:
		'''------------------------------
		---DIALOG-YES-NO-HAVE-ACCOUNT?---
		------------------------------'''
		returned = dialogyesno(addonString(57).encode('utf-8') % (name),addonString(65).encode('utf-8'))
		if returned == 'ok':
			'''------------------------------
			---DIALOG-KEYBOARD-USER----------
			------------------------------'''
			if admin or not 'htpt' in username: input = username
			else: input = ""
			returned = dialogkeyboard(input,'$LOCALIZE[20142]',0,'3',usernameS,addon)
			if returned == 'skip': pass
			else:
				'''------------------------------
				---DIALOG-KEYBOARD-PASS----------
				------------------------------'''
				returned = dialogkeyboard(password,'$LOCALIZE[15052]',1,'3',passwordS,addon)
				if returned == 'skip': pass
				else:
					'''------------------------------
					---DIALOG-NUMERIC--PERIOD--------
					------------------------------'''
					if skinsetting2 != "N/A": returned = dialognumeric(0,addonString(68).encode('utf-8'),"30",'2',skinsetting2S,"")
					else: returned = 'ok'
					if returned == 'skip': pass
					else:
						'''------------------------------
						---DIALOG-OK-ACCOUNT-ON-------
						------------------------------'''
						setSkinSetting("1", skinsettingS, "true")
						xbmc.sleep(500)
						skinsetting = xbmc.getInfoLabel('Skin.HasSetting('+ skinsettingS +')')
						skinsetting2 = xbmc.getInfoLabel('Skin.String('+ skinsetting2S +')')
						skinsetting3 = xbmc.getInfoLabel('Skin.String('+ skinsetting3S +')')
						username = getsetting_addon(usernameS)
						password = getsetting_addon(passwordS)
						'''---------------------------'''
						
						if name == "REALDEBRID":
							'''------------------------------
							---REALDEBRID--------------------
							------------------------------'''
							dialogok(addonString(56).encode('utf-8') % ('[COLOR=Yellow]' + name + '[/COLOR]'),addonString(73).encode('utf-8') % (username),addonString(61).encode('utf-8') % (password),addonString(71).encode('utf-8') % (skinsetting2))
							dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + addonString(76).encode('utf-8'),addonString(77).encode('utf-8'),addonString(78).encode('utf-8'),addonString(79).encode('utf-8'))
							set_accountdate(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, "0")
							'''---------------------------'''
							
						elif name == "SDAROT TV":
							'''------------------------------
							---SDAROT-TV---------------------
							------------------------------'''
							dialogok(addonString(56).encode('utf-8') % ('[COLOR=Yellow]' + name + '[/COLOR]'),addonString(73).encode('utf-8') % (username),addonString(61).encode('utf-8') % (password),addonString(71).encode('utf-8') % (skinsetting2))
							dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + addonString(76).encode('utf-8'),addonString(77).encode('utf-8'),addonString(87).encode('utf-8'),addonString(88).encode('utf-8'))
							set_accountdate(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, "0")
							'''---------------------------'''
						
						elif name == "TRAKT TV":
							'''------------------------------
							---TRAKT-TV----------------------
							------------------------------'''
							dialogok(addonString(56).encode('utf-8') % ('[COLOR=Yellow]' + name + '[/COLOR]'),addonString(73).encode('utf-8') % (username),addonString(61).encode('utf-8') % (password),"")
							dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + addonString(76).encode('utf-8'),addonString(77).encode('utf-8'),addonString(85).encode('utf-8'),addonString(86).encode('utf-8'))
							'''---------------------------'''
							
			if returned == 'skip':
				'''------------------------------
				---DIALOG-NOTIFICATION-TURNOFF---
				------------------------------'''
				notification('$LOCALIZE[257]',addonString(69).encode('utf-8'),"",2000)
				setSkinSetting("1", skinsettingS, "false")
				setSkinSetting("0", skinsetting2S, "")
				setSkinSetting("0", skinsetting3S, "")
				setsetting_custom1(addon,usernameS,"")
				setsetting_custom1(addon,passwordS,"")
				'''---------------------------'''
		else:
			'''------------------------------
			---DIALOG-OK-SIGNUP-INFO---------
			------------------------------'''
			if name == "REALDEBRID": dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + 'https://real-debrid.com/',addonString(64).encode('utf-8'),'[CR]' + addonString(80).encode('utf-8'),'[CR]' + addonString(81).encode('utf-8'))
			elif name == "SDAROT TV": dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + 'http://sdarot.wf/',addonString(64).encode('utf-8'),'[CR]' + addonString(83).encode('utf-8'),'[CR]' + addonString(84).encode('utf-8'))
			elif name == "TRAKT TV": dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + 'http://trakt.tv/',addonString(64).encode('utf-8'),'[CR]' + addonString(89).encode('utf-8'),"")
			'''---------------------------'''
	
	if name == "REALDEBRID":
		'''------------------------------
		---urlresolver-------------------
		------------------------------'''
		if systemhasaddon_urlresolver: addonsettings2('script.module.urlresolver','RealDebridResolver_login',"true",'RealDebridResolver_enabled',"true",'RealDebridResolver_priority',"101",'RealDebridResolver_username',username,'RealDebridResolver_password',password)
		'''---------------------------'''
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "account_button LV_" + printpoint + space2 + name + space + addon + space3
	'''---------------------------'''

def set_accountdate(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, custom):
	'''------------------------------
	---CALCULATE-END-DATES-----------
	------------------------------'''
	printpoint = ""
	try: numberN = int(skinsetting2)
	except: numberN = 0
	
	if skinsetting3 != "":
		#notification("test",skinsetting3,"",2000)
		dateleft = stringtodate(skinsetting3,'%Y-%m-%d')
		dateleft2 = str(dateleft)
		dateleft2S = str(dateleft2)
		datenow2 = stringtodate(datenowS,'%Y-%m-%d')
		number2 = dateleft - datenow2
		number2S = str(number2)
		if "day," in number2S: number2S = number2S.replace(" day, 0:00:00","",1)
		elif "days," in number2S: number2S = number2S.replace(" days, 0:00:00","",1)
		else: number2S = "0"
		if admin: notification("number2S:" + number2S,"","",2000)
		number2N = int(number2S)
	else:
		number2S = "0"
		number2N = int(number2S)
	if number2N < 0: 
		number2S = "0"
		number2N = int(number2S)
		'''---------------------------'''
	
	if custom == "0":
		'''------------------------------
		---MANUAL-SET--------------------
		------------------------------'''
		import datetime as dt
		dateafter2 = datenow + dt.timedelta(days=numberN)
		dateafter2S = str(dateafter2)
		#setsetting(skinsetting3, dateafter2S)
		setSkinSetting("0", skinsetting3S, dateafter2S)
		'''---------------------------'''
		
		'''---------------------------'''
	if custom == "1":
		'''------------------------------
		---AUTO-SET----------------------
		------------------------------'''
		
		'''---------------------------'''
		if skinsetting2 != "" or skinsetting3 != "": setSkinSetting("0", skinsetting2S, number2S)
		'''---------------------------'''
		
		if skinsetting and (username == "" or password == ""):
			'''------------------------------
			---NO-USERNAME-OR-PASSWORD-------
			------------------------------'''
			if number2N > 0 and number2N < 7: dialogok(addonString(55).encode('utf-8') + '[CR]' + '[COLOR=Yellow]' + name + '[/COLOR]',"",addonString(73).encode('utf-8') % (username) + '[CR]' + addonString(71).encode('utf-8') % (number2S),"")
			'''---------------------------'''
			
			'''------------------------------
			---DIALOG-YESNO-REMAKE-----------
			------------------------------'''
			returned = dialogyesno(addonString(59).encode('utf-8') + space + name,addonString(50).encode('utf-8') + '[CR]' + addonString(51).encode('utf-8') + '[CR]' + addonString(73).encode('utf-8') % (username))
			if returned == "ok": printpoint = printpoint + "3"
			else: printpoint = printpoint + "4"
			'''---------------------------'''
			
		elif skinsetting and number2N < 7:
			'''------------------------------
			---PERIOD-ABOUT-TO-END-----------
			------------------------------'''
			if number2N > 0 and number2N < 7: dialogok(addonString(63).encode('utf-8') + '[CR]' + '[COLOR=Yellow]' + name + '[/COLOR]',"",addonString(73).encode('utf-8') % (username) + '[CR]' + addonString(71).encode('utf-8') % (number2S),"")
			elif skinsetting and number2N == 0: dialogok(addonString(60).encode('utf-8') + '[CR]' + '[COLOR=Yellow]' + name + '[/COLOR]',"",addonString(73).encode('utf-8') % (username) + '[CR]' + addonString(71).encode('utf-8') % (number2S),"")
			'''---------------------------'''
			
			'''------------------------------
			---DIALOG-YESNO-REMAKE-----------
			------------------------------'''
			returned = dialogyesno(addonString(59).encode('utf-8') + space + name,addonString(58).encode('utf-8') + '[CR]' + addonString(73).encode('utf-8') % (username))
			if returned == "ok": printpoint = printpoint + "5"
			else: printpoint = printpoint + "6"
			'''---------------------------'''
	
		elif not skinsetting and number2N > 0:
			'''------------------------------
			---SETTING-SHOULD-BE-ON?---------
			------------------------------'''
			pass
			
		if "3" in printpoint or "5" in printpoint:
			'''------------------------------
			---USER-SET-SETTINGS-------------
			------------------------------'''
			skinsettingsW = xbmc.getCondVisibility('Window.IsVisible(SkinSettings.xml)')
			if not skinsettingsW: xbmc.executebuiltin('ActivateWindow(SkinSettings.xml)')
			'''---------------------------'''
			count = 0
			while count < 40 and not skinsettingsW and not xbmc.abortRequested:
				'''------------------------------
				---skinsettingsW-PENDING---------
				------------------------------'''
				xbmc.sleep(40)
				count += 1
				skinsettingsW = xbmc.getCondVisibility('Window.IsVisible(SkinSettings.xml)')
				'''---------------------------'''
			if skinsettingsW:
				'''------------------------------
				---skinsettingsW-TRUE------------
				------------------------------'''
				xbmc.executebuiltin('Control.SetFocus(100,4)')
				xbmc.executebuiltin('Control.SetFocus(50,1)')
				xbmc.executebuiltin('Action(PageUp)')
				xbmc.sleep(40)
				'''---------------------------'''
				count = 0
				systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
				while count < 10 and not name in systemcurrentcontrol and not xbmc.abortRequested:
					'''------------------------------
					---systemcurrentcontrol=name-----
					------------------------------'''
					count += 1
					systemcurrentcontrol = findin_systemcurrentcontrol("1",name,40,'Action(Down)',"")
					if admin: print printfirst + space + "set_accountdate" + space2 + "systemcurrentcontrol=name" + space2 + systemcurrentcontrol + " != " + name + space3
					'''---------------------------'''
			
			if name == 'REALDEBRID': account_button(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, custom)
			elif name == 'SDAROT TV': account_button(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, custom)
			'''---------------------------'''
		
		elif skinsetting and (number2N == 0 or "4" in printpoint):
			'''------------------------------
			---SETTING-OFF-------------------
			------------------------------'''
			setSkinSetting("1", skinsettingS, "false")
			setSkinSetting("0", skinsetting2S, "")
			setSkinSetting("0", skinsetting3S, "")
			notification(addonString(57).encode('utf-8') % (name) + space + str79046.encode('utf-8'),"","",4000)
			'''---------------------------'''
			
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin and custom == "1": print printfirst + "set_accountdate" + space + "name" + space2 + name + space + skinsetting + space + skinsetting2 + space + "number2S" + space2 + number2S + space + custom + space3
	'''---------------------------'''

def homebuttons(admin):
	'''activate home buttons'''
	if not validation and homeW:
		if moviesbutton:
			libraryhascontentmovies = xbmc.getCondVisibility('Library.HasContent(Movies)')
			if libraryhascontentmovies:
				if admin: xbmc.executebuiltin('Notification(Admin,moviesbutton,1000)')
				xbmc.executebuiltin('ActivateWindow(Videos,MovieTitles,return)')
			else:
				if not autoviewoff: xbmc.executebuiltin('Skin.ToggleSetting(AutoViewoff)')
				xbmc.executebuiltin('ActivateWindow(video,"special://userdata/library/movies/",return)')
				xbmc.executebuiltin('Notification($LOCALIZE[79079] $LOCALIZE[342] $LOCALIZE[79090],$LOCALIZE[79091],4000)')
				'''---------------------------'''
		elif tvshowsbutton:
			libraryhascontenttvshows = xbmc.getCondVisibility('Library.HasContent(TVShows)')
			if libraryhascontenttvshows:
				if admin: xbmc.executebuiltin('Notification(Admin,tvshowsbutton,1000)')
				xbmc.executebuiltin('ActivateWindow(VideoLibrary,TVShowTitles,return)')
			else:
				if not autoviewoff: xbmc.executebuiltin('Skin.ToggleSetting(AutoViewoff)')
				xbmc.executebuiltin('ActivateWindow(video,"special://userdata/library/tvshows/",return)')
				xbmc.executebuiltin('Notification($LOCALIZE[79079] $LOCALIZE[20343] $LOCALIZE[79090],$LOCALIZE[79091],4000)')
				'''---------------------------'''
		elif gamesbutton:
			'''------------------------------
			---GAMES-BUTTON------------------
			------------------------------'''
			printpoint = ""
			name = str15016
			returned = supportcheck(name, ["A","B","A?","B?"], 200)
			if returned == "ok":
				addon = 'plugin.program.advanced.launcher'
				if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
					printpoint = printpoint + "7"
					'''---------------------------'''
				else:
					installaddon(admin, addon, "")
					'''---------------------------'''
				
				addon = 'script.htpt.emu'
				if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
					printpoint = printpoint + "7"
					'''---------------------------'''
				else:
					installaddon(admin, addon, "")
					'''---------------------------'''
				
				if "77" in printpoint: gamesbutton_(admin)
				
		elif picturesbutton or videosbutton:
			'''------------------------------
			---PICTURE-&-VIDEO-BUTTON--------
			------------------------------'''
			containernumitems = ""
			printpoint = ""
			name = ""
			path = ""
			
			
			returned = supportcheck(name, ["A", "B", "A?", "B?"], totalspace=100, Intel=False, silence=True)
			if returned == "ok": device = "0"
			else: device = "1"

			if picturesbutton:
				name = str1
				path2 = "pictures"
			elif videosbutton:
				name = str3
				path2 = "videos"
			if device == "0": path = 'special://userdata/library/' + path2 + "/"
			else:
				externalusb(device)
				usb1str = xbmc.getInfoLabel('Skin.String(USB1)')
				if usb1str == "" and not systemplatformwindows: printpoint = printpoint + "9"
				'''---------------------------'''
				if usb1str != "": path = '/var/media/' + '+ usb1str +'
				elif systemplatformwindows: path = 'special://home/external/' + path2
				'''---------------------------'''
			if printpoint == "":
				xbmc.executebuiltin('ActivateWindow('+ path2 +','+ path +',return)')
				#xbmc.executebuiltin('ActivateWindow(Pictures,/var/media/'+ usb1str +',return)')
				#xbmc.executebuiltin('ActivateWindow(Pictures,special://userdata/library/pictures/,return)')
				if not admin and not playerhasmedia: xbmc.executebuiltin('PlayMedia(special://userdata/addon_data/skin.htpt/music/playHTPT.mp3)')
				'''---------------------------'''
				containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
				count = 0
				while count < 10 and containerfolderpath != path and not xbmc.abortRequested:
					'''------------------------------
					---containerfolderpath-----------
					------------------------------'''
					xbmc.sleep(100)
					count += 1
					containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
					xbmc.sleep(100)
					'''---------------------------'''
				containernumitems = xbmc.getInfoLabel('Container.NumItems')
				try: containernumitemsN = int(containernumitems)
				except: containernumitemsN = 0
				if device == "0": externalusb(device)
					
				if containernumitemsN < 2:
					containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
					count = 0
					while count < 10 and containerfolderpath == path and not xbmc.abortRequested:
						'''------------------------------
						---containerfolderpath-----------
						------------------------------'''
						xbmc.sleep(500)
						count += 1
						containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
						if count == 1: notification(addonString(120) % (name), addonString(121), "", 1000)
						elif count == 2: notification(addonString(120) % (name), addonString(121) + ".", "", 1000)
						elif count == 3: notification(addonString(120) % (name), addonString(121) + "..", "", 1000)
						elif count == 4: notification(addonString(120) % (name), addonString(121) + "...", "", 1000)
						if count == 5:
							HelpButton_Video_Pic(name, path2)
							
							
						xbmc.sleep(500)
						'''---------------------------'''
			if printpoint != "":
				if "9" in printpoint: dialogok('[COLOR=Yellow]' + addonString(138) + '[/COLOR]', addonString(139), addonString(128), "")
			if admin: print printfirst + "picturesbutton/videosbutton_LV" + printpoint + space2 + "containernumitems" + space2 + containernumitems + "id10str" + space2 + id10str
		elif favouritesbutton:
			if admin: xbmc.executebuiltin('Notification(Admin,favouritesbutton,1000)')
			xbmc.executebuiltin('ActivateWindow(134)')
			'''---------------------------'''
		elif settingsbutton:
			xbmc.executebuiltin('ActivateWindow(Settings.xml)')
			'''---------------------------'''
		elif widgettogglebutton:
			if admin: xbmc.executebuiltin('Notification(Admin,widgettogglebutton,1000)')
			if xbmc.getCondVisibility('Control.IsVisible(311)'):
				xbmc.executebuiltin('Skin.ToggleSetting(MoviesShelfWL)')
				xbmc.executebuiltin('ActivateWindow(Videos,MovieTitles)')
				xbmc.sleep(100)
				xbmc.executebuiltin('ReplaceWindow(0)')
				xbmc.executebuiltin('Control.SetFocus(9090)')
				'''---------------------------'''
			if xbmc.getCondVisibility('Control.IsVisible(312)'):
				xbmc.executebuiltin('Skin.ToggleSetting(TVShelf_Watchlist)')
				xbmc.executebuiltin('ActivateWindow(VideoLibrary,TVShowTitles)')
				xbmc.sleep(100)
				xbmc.executebuiltin('ReplaceWindow(0)')
				xbmc.executebuiltin('Control.SetFocus(9090)')
				'''---------------------------'''
		elif htptchannelbutton:
			#xbmc.executebuiltin('RunScript(script.toolbox,info=textviewer,header='+ message1 +',text='+ message2 +')')
			xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.youtube/channel/UCcYT8oPT83Yuw4_GUZ3mMFg/)')
			
			if not systemplatformwindows: log = open('/storage/.kodi/addons/skin.htpt/changelog.txt', 'r')
			elif systemplatformwindows: log = open('Z:\\addons\\skin.htpt\\changelog.txt', 'r')
			message = log.read()
			log.close()
			diaogtextviewer('[COLOR=Yellow]' + htptskinversion + '[/COLOR]' + addonString(19) + "-", message)
			#w = TextViewer_Dialog('DialogTextViewer.xml', "", header=header, text=message2)
			#w.doModal()
			'''---------------------------'''
		elif test2button:
			'''------------------------------
			---test-2-button-----------------
			------------------------------'''
			#xbmc.executebuiltin('RunScript(script.htpt.refresh,,?mode=3)')
			if 1+ 1 == 3:
				if systemplatformwindows: infile = "Z:/addons/plugin.video.sdarot.tv/sdarottv.py"
				else: infile = "/storage/.kodi/addons/plugin.video.sdarot.tv/sdarottv.py"
				old_word = "finalVideoUrl,VID = getFinalVideoUrl(series_id,season_id,epis,silent=True)"
				new_word = "finalVideoUrl,VID = getFinalVideoUrl(series_id,season_id,epis,silent=False)"
				replace_word(infile,old_word,new_word)
				#xbmc.executebuiltin('ActivateWindow(10025,special://home/addons)')
				#xbmc.executebuiltin('PlayMedia(plugin://plugin.video.youtube/play/?video_id=gnZuo0he5kk)')
			pass
			#notification(xbmc.getInfoLabel('System.ProfileName'),"","",5000)
			xbmc.executebuiltin('Action(PageUp)')
			xbmc.sleep(500)
			#xbmc.executebuiltin('Control.SetFocus(2)')
			xbmc.executebuiltin('SetFocus(341)')
			#ExtractAll("D:\\rom\\Arcade\\_GEAR.rar","C:\\")
			#ExtractAll("C:\\_1P.tar","C:\\")
			#ExtractAll("C:\\_1P.7z","C:\\_1P")
			#Clean_Library("10")
			#xbmc.executebuiltin('RunScript(plugin.video.genesis,,?action=library_imdb_watchlist)')
			#Clean_Library("1")
			

			
			
			#xbmc.executebuiltin('RunScript(service.htpt.fix,,?mode=20)')
			#xbmc.executebuiltin('RunScript(script.htpt.smartbuttons,,?mode=0)')
			#xbmc.executebuiltin('RunScript(screensaver.picture.slideshow)')
			#xbmc.executebuiltin('RunScript(service.htpt.fix,,?mode=12)')

			#from commondownloader import *
			#returned = doDownload("https://docs.google.com/uc?export=download&id=0B3SUm7A8M6ctNTRhQ21jYUw0ZVk", "C:\\test3.zip", "google", "", "", "")
			#from commondownloader import *
			#doDownload("https://www.dropbox.com/s/zz2se5mfpmt5wbn/Sega%20Master%20System.zip?dl=1", "C:\\test2.zip", 'Media', "", "", "")
			#dialogok("download done","","","")
			#import urllib2
			#import urllib, urllib2, os, sys

			###The pydrive package download
			###page='https://pypi.python.org/packages/source/P/PyDrive/PyDrive-1.0.0.tar.gz'
			###request=urllib.urlretrieve(page, "C:\\" + "pydrive.tar.gz") #pydrive.tar.gz
			###if os.path.exists(os.path.join("C:\\","pydrive.tar.gz")): #os.path.dirname
				###print "YUP THE FILE EXISTS"
				###notification("yes!","","",2000)
			###else:
				###print "nope"			#response = urllib2.urlopen('https://drive.google.com/file/d/0B3SUm7A8M6ctNTRhQ21jYUw0ZVk/view?usp=sharing')
			#html = response.read()
			#f=open("1", 'w')
			#f.write(html)
			#f.close()
			#from downloader import *
			#download("https://www.dropbox.com/s/kxwmwbnjf7f040j/skin.htpt.zip?dl=1", "c:\\test.zip", dp = None) #temp_path #https://drive.google.com/file/d/0B3SUm7A8M6ctNTRhQ21jYUw0ZVk/view?usp=sharing
			
			#DownloadFile("https://drive.google.com/uc?export=download&id=0B3SUm7A8M6ctNTRhQ21jYUw0ZVk", "Media", "C:\\", "C:\\1")
			#systemmemorytotal2 = systemmemorytotal.replace("MB","")
			#notification(systemmemorytotal2,"","",10000)
			#content = ReadList('/storage/shutdown.log')
			#print "HERE" + space2 + newline + str(content)
			#returned, value = getRandom("0",percent=10)
			#if returned == "ok": notification("yeyeye","","",4000)
				
			#xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=library_imdb_watchlist,return)')
			#removeaddons(['plugin.program.advanced.launcher', 'script.htpt.emu', 'tools.lm_sensors', 'debug.tools.smem', 'screensaver.randomtrailers'],"12")
			#addon = 'plugin.program.advanced.launcher'
			#output = bash('ls '+addons_path+''+ addon +'/',"script.htpt.emu")
			#output = bash('ls '+addondata_path+''+ addon +'/',"script.htpt.emu")
			#output = bash('rm -rf '+addondata_path+''+ addon +'/',addon)
			#print output
			#dp = dialogprogress("",0,"heading","line1","line2","line3")
			#xbmc.sleep(2000)
			#dp = dialogprogress(dp, 10,"heading","line1","line2","line3")
			#xbmc.sleep(2000)
			#dp = dialogprogress(dp, 100,"heading","line1","line2","line3")
			#xbmc.sleep(2000)
			
			'''---------------------------'''
			#print printfirst + space + "test2button" + space2 + az
			'''---------------------------'''
			
		elif internetbutton:
			'''------------------------------
			---INTERNET-BUTTON---------------
			------------------------------'''
			name = str443.encode('utf-8')
			printpoint = ""
			returned = supportcheck(name, ["A","B"], 1, Intel=True)
				
			if returned == "ok":
				if connected or connected2 or connected3:
					addon = 'browser.chromium-browser'
					if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
						returned = dialogyesno(str79215,str79216)
						if returned == "ok":
							notification(str79217, str79218, "", 4000)
							settingschange('SystemSettings','input.enablemouse','1','no',xbmc.getInfoLabel('$LOCALIZE[14094]'),xbmc.getInfoLabel('$LOCALIZE[21369]'))
							xbmc.sleep(1000)
							if not systemplatformwindows: xbmc.executebuiltin('RunAddon(browser.chromium-browser)')
							'''---------------------------'''
						else:
							notification_common("8")
							#settingschange('SystemSettings','input.enablemouse','0','no',xbmc.getInfoLabel('$LOCALIZE[14094]'),xbmc.getInfoLabel('$LOCALIZE[21369]'))
							'''---------------------------'''
					else: installaddon(admin, addon, "")
					
				else: notification_common("4")

		elif connected:
			'''------------------------------
			---Require-Internet--------------
			------------------------------'''
			#if admin: print printfirst + space + "homebuttons internet" + space3
			if israeltvbutton:
				printpoint = ""
				if systemhasaddon_sdarottv:
					printpoint = printpoint + "1"
					'''ping'''
					ping = ""
					count = 0
					while count < 3 and ping == "" and not xbmc.abortRequested:
						if count == 1: notification(addonString(92),addonString(119),"",2000)
						count += 1
						if systemplatformwindows: output = cmd('ping www.sdarot.wf -n 1',"Connected2")
						else: output = bash('ping -W 1 -w 1 -4 -q www.sdarot.wf',"Connected")
						if (not systemplatformwindows and ("1 packets received" in output or not "100% packet loss" in output)) or (systemplatformwindows and ("Received = 1" in output or not "100% loss" in output)): ping = "true"
						'''---------------------------'''
					if ping == "true":
						printpoint = printpoint + "2"
						if admin and not admin2:
							if not systemplatformwindows: bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.video.sdarot.tv/sdarot-cookiejar.txt',"plugin.video.sdarot.tv - cookie")
							notification("DELETING COOKIE","","",1000)
							xbmc.sleep(1000)
							'''---------------------------'''
						else:
							addonsettings('SDAROT TV', 'plugin.video.sdarot.tv', 'Account2_Active', 'Account2_Period', 'username','user_password', "", "", "", "")
							addonsettings2('plugin.video.sdarot.tv','DEBUG',"false",'cache',"24",'domain',"http://www.sdarot.wf",'',"",'',"")
							'''---------------------------'''

						xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.sdarot.tv/?mode=2&module=http%3a%2f%2fwww.sdarot.wf%2fseries%2fgenre%2f20%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99&name=%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99&url=all-heb,return)')
						xbmc.sleep(1000)
						
						
						returned_Dialog, returned_Header, returned_Message = checkDialog(admin)
						count = 0
						while count < 10 and (returned_Dialog == 'dialogbusyW' or returned_Dialog == 'dialogprogressW') and not xbmc.abortRequested:
							'''------------------------------
							---WAIT-FOR-DIALOG-TO-END--------
							------------------------------'''
							count += 1
							xbmc.sleep(400)
							returned_Dialog, returned_Header, returned_Message = checkDialog(admin)
							'''---------------------------'''
						
						if count < 10:
							printpoint = printpoint + "3"
							containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
							containernumitems = xbmc.getInfoLabel('Container.NumItems')
							count = 0
							while count < 10 and (not 'plugin.video.sdarot.tv' in containerfolderpath or containernumitems == "0") and not xbmc.abortRequested:
								'''------------------------------
								---CHECK-FOR-VALID-SHORTCUT------
								------------------------------'''
								if count == 1: notification(addonString(92),addonString(119),"",3000)
								count += 1
								xbmc.sleep(300)
								containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
								containernumitems = xbmc.getInfoLabel('Container.NumItems')
								'''---------------------------'''
							if count < 10: pass
							else: xbmc.executebuiltin('RunAddon(plugin.video.sdarot.tv)')
							'''---------------------------'''
							
						else: printpoint = printpoint + "6"
							
						
					else:
						'''------------------------------
						---WEBSITE-DOWN------------------
						------------------------------'''
						notification('[COLOR=Red]' + addonString(90) + '[/COLOR]',addonString(91),"",4000)
						xbmc.executebuiltin('Action(Close)')
						'''---------------------------'''
						
			elif goprobutton:
				if admin: xbmc.executebuiltin('Notification(Admin,goprobutton,1000)')
				if not systemhasaddon_htptgopro: xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.htpt.gopro,return)')
				else:
					returned = ActivateWindow("0", 'plugin.video.htpt.gopro' , 'plugin://plugin.video.htpt.gopro/' , 0, wait=True)
					if returned == 'ok2':
						systemcurrentcontrol = findin_systemcurrentcontrol("0",str73440.encode('utf-8'),40,'Action(Down)','Action(Select)')
						count = 0
						systemidle0 = xbmc.getCondVisibility('System.IdleTime(0)')
						while count < 10 and systemcurrentcontrol != str73440.encode('utf-8') and systemidle0 and not xbmc.abortRequested:
							count += 1
							systemcurrentcontrol = findin_systemcurrentcontrol("0",str73440.encode('utf-8'),40,'Action(Down)','Action(Select)')
							systemidle0 = xbmc.getCondVisibility('System.IdleTime(0)')
						
						if count < 10 and systemidle0: notification_common("14")
							
					#returned = ActivateWindow("1", 'plugin.video.htpt.gopro' , 'plugin://plugin.video.htpt.gopro/?iconimage=https%3a%2f%2fyt3.ggpht.com%2f-sp0YiR_yyR0%2fAAAAAAAAAAI%2fAAAAAAAAAAA%2fkXU4u1ny2T4%2fs100-c-k-no%2fphoto.jpg&mode=9&name=GoPro&num=1&url=GoProCamera' , "", wait=True)
					#returned = ActivateWindow('plugin.video.htpt.gopro', 'plugin://plugin.video.htpt.gopro/?iconimage=https%3a%2f%2fyt3.ggpht.com%2f-sp0YiR_yyR0%2fAAAAAAAAAAI%2fAAAAAAAAAAA%2fkXU4u1ny2T4%2fs100-c-k-no%2fphoto.jpg&mode=9&name=GoPro&num=1&url=GoProCamera', "", wait=True)
					#returned = ActivateWindow("1", 'plugin.video.htpt.gopro' , 'plugin://plugin.video.htpt.gopro/?iconimage=https%3a%2f%2fyt3.ggpht.com%2f-sp0YiR_yyR0%2fAAAAAAAAAAI%2fAAAAAAAAAAA%2fkXU4u1ny2T4%2fs100-c-k-no%2fphoto.jpg&mode=9&name=GoPro&num=1&url=GoProCamera' , 0, wait=True)
					
					#returned = ActivateWindow("1", 'plugin.video.htpt.gopro', 'plugin://plugin.video.htpt.gopro/?iconimage=https%3a%2f%2fyt3.ggpht.com%2f-sp0YiR_yyR0%2fAAAAAAAAAAI%2fAAAAAAAAAAA%2fkXU4u1ny2T4%2fs100-c-k-no%2fphoto.jpg&mode=9&name=GoPro&num=1&url=GoProCamera', "", wait=True)
					#xbmc.sleep(5000)
					#xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.htpt.gopro/?iconimage=https%3a%2f%2fyt3.ggpht.com%2f-sp0YiR_yyR0%2fAAAAAAAAAAI%2fAAAAAAAAAAA%2fkXU4u1ny2T4%2fs100-c-k-no%2fphoto.jpg&mode=9&name=GoPro&num=1&url=GoProCamera,return)')
					#
			elif youtubebutton:
				if admin: xbmc.executebuiltin('Notification(Admin,youtubebutton,1000)')
				xbmc.executebuiltin('RunAddon(plugin.video.youtube)')
				xbmc.sleep(500)
				containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
				count = 0
				while count < 10 and not "plugin://plugin.video.youtube" in containerfolderpath and not xbmc.abortRequested:
					xbmc.sleep(100)
					count += 1
					containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
					xbmc.sleep(100)
				if "plugin://plugin.video.youtube" in containerfolderpath:
					xbmc.executebuiltin('Action(PageUp)')
					xbmc.executebuiltin('Action(Down)')							
			if moviesebutton or tvshowsebutton or custom1132W:
				if admin: xbmc.executebuiltin('Notification(Admin,moviesebutton/tvshowsebutton,1000)')
				if moviesebutton or custom1132W:
					'''------------------------------
					---MOVIES-SEARCH/ADD-------------
					------------------------------'''
					if moviesep:
						'''------------------------------
						---PLUS--------------------------
						------------------------------'''
						if not custom1132W:
							if admin: notification("test2","","",2000)
							xbmc.executebuiltin('ActivateWindow(1132)')
						else:
							controlhasfocus698 = findin_controlhasfocus("9000","698",20,"","Action(close)")
							controlhasfocus699 = findin_controlhasfocus("9000","699",20,"","Action(close)")
							if controlhasfocus698: xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=root_movies,return)')
							elif controlhasfocus699: xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.pulsar,return)')
							if admin and controlhasfocus699: notification("test","","",2000)
						
					else:
						xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=root_movies,return)') #xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=movies_featured,return)') #xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=root_movies,return)') #xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=movies_popular)')
						'''---------------------------'''
				elif tvshowsebutton:
					xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=root_shows,return)')
				
				if systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow'):
					'''------------------------------
					---GENESIS-PATH-CHANGE-----------
					------------------------------'''
					count = 0
					while count < 10 and systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow') and not xbmc.abortRequested:
						xbmc.sleep(40)
						systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow')
						count += 1
						if count == 10:
							if not autoviewoff: xbmc.executebuiltin('Skin.ToggleSetting(AutoViewoff)')
							xbmc.executebuiltin('RunAddon(plugin.video.genesis)')
							xbmc.sleep(1000)
							containerfolderpath = xbmc.getCondVisibility('StringCompare(Container.FolderPath,plugin://plugin.video.genesis/)')
							if not containerfolderpath:
								xbmc.executebuiltin('Action(PageUp)')
								xbmc.executebuiltin('Action(PageUp)')
								xbmc.executebuiltin('Action(Select)')
								xbmc.sleep(800)
								containerfolderpath = xbmc.getCondVisibility('StringCompare(Container.FolderPath,plugin://plugin.video.genesis/)')
								#xbmc.sleep(1000)
							if containerfolderpath:
								xbmc.executebuiltin('Action(PageUp)')
								xbmc.executebuiltin('Action(Down)')
								if tvshowsebutton: xbmc.executebuiltin('Action(Down)')
								xbmc.executebuiltin('Action(Select)')
									
				if systemcurrentwindow != xbmc.getInfoLabel('System.CurrentWindow'):
					'''------------------------------
					---GENESIS-OK!-------------------
					------------------------------'''
					count = 0
					containernumitems = xbmc.getInfoLabel('Container.NumItems')
					
					while count < 40 and (containernumitems == "0" or containernumitems == "") and not xbmc.abortRequested:
						xbmc.sleep(40)
						containernumitems = xbmc.getInfoLabel('Container.NumItems')
						count += 1
					#if admin: notification("testtttt-",containernumitems,"",3000)
					rootmovies = 'plugin://plugin.video.genesis/?action=root_movies'
					roottv = 'plugin://plugin.video.genesis/?action=root_shows'
					containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
					if containerfolderpath == rootmovies or containerfolderpath == roottv:
						systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
						if containerfolderpath == rootmovies:
							value2 = str342
							xbmc.executebuiltin('Action(PageUp)')
							xbmc.executebuiltin('Action(PageUp)')
							if moviesestartup == "0": value = "" #root
							elif moviesestartup == "1": value = addonString_genesis(30527).encode('utf-8') #Most Popular
							elif moviesestartup == "2": value = addonString_genesis(30531).encode('utf-8') #Latest HD Movies
							elif moviesestartup == "3": value = addonString_genesis(30535).encode('utf-8') #Search
							elif moviesestartup == "4": value = addonString_genesis(30541).encode('utf-8') #Genres
							else: value = ""
							if value != "": value = "[" + value + "]"
							#if admin: notification("value: " + value,"","",1000)
							'''---------------------------'''
							count = 0
							while count < 17 and containerfolderpath == rootmovies and value != "" and not xbmc.abortRequested:
								if not xbmc.Player().isPlayingVideo():
									if moviesestartup == "3": systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Up)','')
									elif moviesestartup == "2": systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Up)','Action(Select)')
									else: systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Down)','Action(Select)')
								else:
									if moviesestartup == "3": systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Down)','')
									else: systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Down)','Action(Select)')
								
								if systemcurrentcontrol == value: count = 40
								containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
								count += 1
								'''---------------------------'''
							
						elif containerfolderpath == roottv:
							value2 = str20343 #str20343.decode('utf-8').encode('utf-8')
							xbmc.executebuiltin('Action(PageUp)')
							xbmc.executebuiltin('Action(PageUp)')
							if tvshowsestartup == "0": value = "" #root
							elif tvshowsestartup == "1": value = addonString_genesis(30527).encode('utf-8') #Most Popular
							elif tvshowsestartup == "2": value = addonString_genesis(30544).encode('utf-8') #Returning TV Shows
							elif tvshowsestartup == "3": value = addonString_genesis(30535).encode('utf-8') #Search
							elif tvshowsestartup == "4": value = addonString_genesis(30541).encode('utf-8') #Genres
							else: value = ""
							if value != "": value = "[" + value + "]"
							'''---------------------------'''
							count = 0
							while count < 17 and containerfolderpath == roottv and value != "" and not xbmc.abortRequested:
								if tvshowsestartup == "3" and not xbmc.Player().isPlayingVideo(): systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Up)','')
								elif tvshowsestartup == "3": systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Down)','')
								else: systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Down)','Action(Select)')
								
								if systemcurrentcontrol == value: count = 40
								containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
								count += 1
								'''---------------------------'''
						
						if value != "":
							'''------------------------------
							---STARTUP-WINDOW-NOTIFICATION---
							------------------------------'''
							xbmc.sleep(3000)
							containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
							if containerfolderpath == rootmovies or containerfolderpath == roottv:
								if moviesestartup != "3" and tvshowsestartup != "3": notification('[COLOR=Yellow]' + value.decode('utf-8') + '[/COLOR]' + str512 + space2, addonString(151), "", 4000)
							elif moviesestartup == "3" or tvshowsestartup == "3": notification('[COLOR=Yellow]' + value.decode('utf-8') + '[/COLOR]' + str512 + space2, addonString(151), "", 4000)
					elif admin: notification("containerfolderpath_Error","","",1000)
					
			if weatherbutton:
				
				addon = 'weather.yahoo'
				if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
					'''------------------------------
					---weather.yahoo-----------------
					------------------------------'''
					if weatheryahoo_location1 == "" and weatheryahoo_location1id == "":
						setsetting_custom1(addon,'Location1',"Tel Aviv (IL)")
						setsetting_custom1(addon,'Location1id',"1968212")
					elif weatheryahoo_location2 == "" and weatheryahoo_location2id == "":
						setsetting_custom1(addon,'Location2',"Haifa (IL)")
						setsetting_custom1(addon,'Location2id',"2345794")
					elif weatheryahoo_location3 == "" and weatheryahoo_location3id == "":
						setsetting_custom1(addon,'Location3',"")
						setsetting_custom1(addon,'Location3id',"")

					xbmc.executebuiltin('ActivateWindow(MyWeather)')
					xbmc.sleep(200)
					xbmc.executebuiltin('Weather.Refresh')
					addon = 'weather.yahoo'
					'''---------------------------'''
				else:
					installaddon(admin, addon, "")
					'''---------------------------'''
			if trailers2button:
				if admin: xbmc.executebuiltin('Notification(Admin,trailers2button,1000)')
				xbmc.executebuiltin('RunAddon(screensaver.randomtrailers)')
			
			if musicbutton or custom1124W:
				'''------------------------------
				---MUSIC-BUTTON------------------
				------------------------------'''
				printpoint = ""
				if admin: xbmc.executebuiltin('Notification(Admin,musicbutton,1000)')
				if not custom1124W: xbmc.executebuiltin('ActivateWindow(1124,return)')
				else:
					xbmc.executebuiltin('dialog.close(1124)')
					if button101:
						'''------------------------------
						---LOCAL-MUSIC-------------------
						------------------------------'''
						name = str75004
						returned = supportcheck(name, ["A","B","A?","B?"], 100)
						
						if returned == "ok":
							if not libraryhascontentmusic: xbmc.executebuiltin('ActivateWindow(501,root),return)')
							elif musiclinkstr != "": xbmc.executebuiltin('ActivateWindow(502,'+ musiclinkstr +',return)')
							else: xbmc.executebuiltin('ActivateWindow(502,return)')
							'''---------------------------'''
							
					elif button99:
						'''------------------------------
						---HTPT-MUSIC--------------------
						------------------------------'''
						addon = 'plugin.video.htpt.music'
						if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
							xbmc.executebuiltin('RunAddon('+ addon +',,)')
							'''---------------------------'''
						else: installaddon(admin, addon, "")
					
					elif button102:
						'''------------------------------
						---RADIO-------------------------
						------------------------------'''
						addon = 'plugin.video.israelive'
						if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
							#xbmc.executebuiltin('RunAddon('+ addon +',,)')
							if xbmc.getCondVisibility('!System.GetBool(pvrmanager.enabled)'): xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.israelive/?categoryid=9999&description&displayname=10000&iconimage=http%3a%2f%2fmdmorrope.gob.pe%2fportalweb%2fimagenes%2fradioss.png&mode=2&name=%5bCOLOR%20chartreuse%5d%5bB%5d%5b%d7%a8%d7%93%d7%99%d7%95%5d%5b%2fB%5d%5b%2fCOLOR%5d&url,return)')
							else: xbmc.executebuiltin('ActivateWindow(MyPVRChannels.xml)')
							'''---------------------------'''
						else: installaddon(admin, addon, "")
			
			elif custom1134W:
				'''------------------------------
				---SOAP-OPERA--------------------
				------------------------------'''
				name = 'SOAP-OPERA'
				xbmc.executebuiltin('dialog.close(1134)')
				if button101:
					addon = 'plugin.video.wallaNew.video'
					returned = ActivateWindow("1", addon, "plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%98%d7%9c%d7%a0%d7%95%d7%91%d7%9c%d7%95%d7%aa%20(18)&url=genre%3dtvshows%26genreId%3d6280", 0, wait=True)
					'''---------------------------'''
				elif button102:
					pass
					'''---------------------------'''
				elif button103:
					pass
					'''---------------------------'''
			
			elif custom1135W:
				'''------------------------------
				---DOCU--------------------------
				------------------------------'''
				name = 'DOCU'
				xbmc.executebuiltin('dialog.close(1135)')
				if button101:
					addon = 'plugin.video.movixws'
					returned = ActivateWindow("1", addon, "plugin://plugin.video.movixws/?iconimage=http%3a%2f%2ficons.iconarchive.com%2ficons%2faaron-sinuhe%2ftv-movie-folder%2f512%2fDocumentaries-National-Geographic-icon.png&mode=2&name=Documentary%20-%20%d7%93%d7%95%d7%a7%d7%95%d7%9e%d7%a0%d7%98%d7%a8%d7%99&url=http%3a%2f%2fwww.movix.me%2fgenres%2fDocumentary", 0, wait=True)
					'''---------------------------'''
				elif button102:
					pass
					'''---------------------------'''
				elif button103:
					pass
					'''---------------------------'''
					
			elif custom1136W:
				'''------------------------------
				---ISRAELI-MOVIES----------------
				------------------------------'''
				name = 'ISRAELI-MOVIES'
				xbmc.executebuiltin('dialog.close(1136)')
				if button101:
					addon = 'plugin.video.wallaNew.video'
					#xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99%20(113)&url=genre%3dmovies%26genreId%3d6260,return)')
					returned = ActivateWindow("1", addon, "plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99%20(98)&url=genre%3dmovies%26genreId%3d6260", 0, wait=True)
					'''---------------------------'''
				elif button102:
					addon = 'plugin.video.movixws'
					returned = ActivateWindow("1", addon, "plugin://plugin.video.movixws/?iconimage=http%3a%2f%2fupload.wikimedia.org%2fwikipedia%2fcommons%2fthumb%2fd%2fd4%2fFlag_of_Israel.svg%2f250px-Flag_of_Israel.svg.png&mode=2&name=Israeli%20-%20%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99&url=http%3a%2f%2fwww.movix.me%2fgenres%2fisraeli", 0, wait=True)
					'''---------------------------'''
				elif button103:
					addon = 'plugin.video.10qtv'
					returned = ActivateWindow("1", addon, "plugin://plugin.video.10qtv/?mode=6&name=%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99&url=http%3a%2f%2fwww.10q.tv%2fboard%2ffilmy%2fishrali%2f11", 0, wait=True)
					'''---------------------------'''
				#else: notification("12","","",1000)
					
					
			elif morebutton or custom1133W:
				'''------------------------------
				---MORE--------------------------
				------------------------------'''
				if not custom1133W: xbmc.executebuiltin('ActivateWindow(1133)')
				else:
					xbmc.executebuiltin('dialog.close(1133)')
					if button99:
						'''------------------------------
						---HTPT-MUSIC--------------------
						------------------------------'''
						addon = 'plugin.video.htpt.music'
						if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
							xbmc.executebuiltin('RunAddon('+ addon +',,)')
							'''---------------------------'''
						else: installaddon(admin, addon, "")
					
					elif button101:
						'''------------------------------
						---GAMER-TV----------------------
						------------------------------'''
						addon = 'plugin.video.g4tv'
						if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
							xbmc.executebuiltin('RunAddon('+ addon +')')
							'''---------------------------'''
						else: installaddon(admin, addon, "")
						
					elif button102:
						'''------------------------------
						---GUITAR------------------------
						------------------------------'''
						addon = 'plugin.video.ultimateguitar'
						if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
							xbmc.executebuiltin('RunAddon('+ addon +')')
							'''---------------------------'''
						else: installaddon(admin, addon, "")
					
					elif button103:
						'''------------------------------
						---QUIZ--------------------------
						------------------------------'''
						addon = 'script.moviequiz'
						if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
							xbmc.executebuiltin('RunAddon('+ addon +')')
							'''---------------------------'''
						else: installaddon(admin, addon, "")
					
					elif button104:
						'''------------------------------
						---?--------------------------
						------------------------------'''
						addon = 'plugin.video.ultimateguitar'
						if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
							xbmc.executebuiltin('RunAddon('+ addon +')')
							'''---------------------------'''
						else: installaddon(admin, addon, "")
					
				
			if kidsbutton:
				'''------------------------------
				---KIDS-BUTTON-------------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,kidsbutton,1000)')
				#kidssettings("run")
				xbmc.sleep(200)
				#xbmc.executebuiltin('RunAddon(plugin.video.KIDSIL)')
				if systemhasaddon_htptkids: xbmc.executebuiltin('RunAddon(plugin.video.htpt.kids)')
				else:
					xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.htpt.kids,return)')
					if admin: notification("Admin","Addon is missing!","",1000)
				'''---------------------------'''
				
			if mov3dsbutton:
				'''------------------------------
				---3D-MOVIES-BUTTON--------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,mov3dsbutton,1000)')
				#xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.movie25/?fanart;genre;iconimage=https%3a%2f%2fraw.github.com%2fmash2k3%2fMashupArtwork%2fmaster%2fskins%2fvector%2f3d.png;mode=223;name=3D%20Movies;plot;url=3D,return)')
				notification_common("10")
				'''---------------------------'''
			elif gadgetbutton:
				'''------------------------------
				---GADGET-BUTTON-----------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,gadgetbutton,1000)')
				#if not systemplatformwindows: xbmc.executebuiltin('RunAddon(plugin.video.engadget)')
				notification_common("10")
				'''---------------------------'''
			elif karaokebutton:
				'''------------------------------
				---KARAOKE-BUTTON----------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,karaokebutton,1000)')
				xbmc.executebuiltin('RunAddon(plugin.video.MikeysKaraoke)')
				'''---------------------------'''
			elif gametrailersbutton:
				'''------------------------------
				---GAMERS-BUTTON-----------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,gametrailersbutton,1000)')
				xbmc.executebuiltin('RunAddon(plugin.video.g4tv)')
				'''---------------------------'''
			elif guitarbutton:
				'''------------------------------
				---GAMERS-BUTTON-----------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,guitarbutton,1000)')
				xbmc.executebuiltin('RunAddon(plugin.video.ultimateguitar)')
				'''---------------------------'''
			elif adultbutton2:
				'''------------------------------
				---ADULT-MOVIE-BUTTON------------
				------------------------------'''
				adultbutton2_(admin)
				'''---------------------------'''
						
			if radiobutton:
				'''------------------------------
				---RADIO-BUTTON------------------
				------------------------------'''
				print printfirst + "radiobutton"
				xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.israelive/?categoryid=9999&description&displayname=10000&iconimage=http%3a%2f%2fmdmorrope.gob.pe%2fportalweb%2fimagenes%2fradioss.png&mode=2&name=%5bCOLOR%20chartreuse%5d%5bB%5d%5b%d7%a8%d7%93%d7%99%d7%95%5d%5b%2fB%5d%5b%2fCOLOR%5d&url,return)')
				xbmc.sleep(700)
				containernumitems = xbmc.getInfoLabel('Container.NumItems')
				if systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow') or containernumitems == '0':
					xbmc.executebuiltin('RunAddon(plugin.video.israelive)')
					xbmc.sleep(700)
					if xbmc.getInfoLabel('Container.FolderPath') == 'plugin://plugin.video.israelive/':
						xbmc.executebuiltin('Action(PageUp)')
						xbmc.executebuiltin('Action(Down)')
						xbmc.executebuiltin('Action(Down)')
						xbmc.executebuiltin('Action(Select)')
		elif vhomecon1:
			notification_common("5")
			'''---------------------------'''

def helpbuttons(admin):
	if custom1170W or loginscreenW:
		'''------------------------------
		---HELP-/-LOGINSCREEN-WINDOWS----
		------------------------------'''
		xbmc.sleep(40)
		#if admin: xbmc.executebuiltin('Notification(Admin,custom1170,1000)')
		#sgbserviceszeroconf = xbmc.getCondVisibility('System.GetBool(services.zeroconf)')
		from variables import sgbserviceszeroconf, sgbservicesairplay
		if airplaybutton:
			'''------------------------------
			---AIRPLAY-BUTTON----------------
			------------------------------'''
			printpoint = ""
			xbmc.executebuiltin('ActivateWindow(servicesettings)')
			settingscategoryW = xbmc.getCondVisibility('Window.IsVisible(SettingsCategory.xml)')
			count = 0
			while count < 10 and not settingscategoryW and not xbmc.abortRequested:
				if count == 0: printpoint = printpoint + "0"
				xbmc.sleep(40)
				settingscategoryW = xbmc.getCondVisibility('Window.IsVisible(SettingsCategory.xml)')
				count += 1
			settingslevelset("2")
			'''---------------------------'''
			if not sgbserviceszeroconf:
				printpoint = printpoint + "1"
				count = 0
				systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
				while count < 5 and systemcurrentcontrol != str1259 and not xbmc.abortRequested:
					'''Zeroconf'''
					if count == 0: printpoint = printpoint + "2"
					systemcurrentcontrol = findin_systemcurrentcontrol("0",str1259,40,'Action(Left)','Action(Down)')
					count += 1
					'''---------------------------'''
				count = 0
				while count < 5 and not str1260 in systemcurrentcontrol and not xbmc.abortRequested:
					'''Announce these services to other systems via Zeroconf'''
					if count == 0:
						printpoint = printpoint + "3"
						systemcurrentcontrol = findin_systemcurrentcontrol("1",str1260,40,'','Action(Select)')
					else: systemcurrentcontrol = findin_systemcurrentcontrol("1",str1260,40,'Action(Down)','Action(Select)')
					count += 1
					'''---------------------------'''
				count = 0
				while count < 5 and systemcurrentcontrol != str1259 and not xbmc.abortRequested:
					'''Zeroconf'''
					if count == 0: printpoint = printpoint + "2"
					systemcurrentcontrol = findin_systemcurrentcontrol("0",str1259,40,'Action(Up)','Action(Right)')
					count += 1
					'''---------------------------'''
				sgbserviceszeroconf = xbmc.getCondVisibility('System.GetBool(services.zeroconf)')
				
			if sgbserviceszeroconf:
				printpoint = printpoint + "4"
				'''---------------------------'''
				systemcurrentcontrol = findin_systemcurrentcontrol("0",str1273,40,'Action(Left)','Action(Down)')
				count = 0
				while count < 5 and systemcurrentcontrol != str1273 and not xbmc.abortRequested:
					'''AirPlay'''
					if count == 0: printpoint = printpoint + "5"
					systemcurrentcontrol = findin_systemcurrentcontrol("0",str1273,40,'Action(Left)','Action(Down)')
					count += 1
					'''---------------------------'''
				
				systemcurrentcontrol = findin_systemcurrentcontrol("1",str1273,40,'Action(Down)','')
				count = 0
				while count < 5 and not str1273 in systemcurrentcontrol and not xbmc.abortRequested:
					'''if Allow to receive AirPlay content'''
					if count == 0: printpoint = printpoint + "6"
					systemcurrentcontrol = findin_systemcurrentcontrol("1",str1273,40,'Action(Down)','')
					count += 1
					'''---------------------------'''
				if count < 5:
					printpoint = printpoint + "8"
					systemcurrentcontrol = findin_systemcurrentcontrol("1",str1273,40,'','Action(Select)')
					xbmc.sleep(500)
					if sgbservicesairplay: systemcurrentcontrol = findin_systemcurrentcontrol("1",str1273,40,'','Action(Select)')
					'''---------------------------'''
				
				xbmc.executebuiltin('Action(Back)')
				xbmc.sleep(1000)
				xbmc.executebuiltin('Action(Down)')
				sgbservicesairplay = xbmc.getCondVisibility('System.GetBool(services.airplay)')
				sgbserviceszeroconf = xbmc.getCondVisibility('System.GetBool(services.zeroconf)')
				xbmc.sleep(500)
				if sgbserviceszeroconf and sgbservicesairplay:
					printpoint = printpoint + "7"
					notification_common("13")
					dialogok('[COLOR=Yellow]' + addonString(114) + '[/COLOR]', addonString(115), addonString(116), "")
					returned = dialogyesno(addonString(117), addonString(118))
					if returned != "ok":
						'''Extra Help with AirPlay'''
						dialogok('[COLOR=Yellow]' + addonString(140) + '[/COLOR]', addonString(141) + space2, addonString(142), "")
					#xbmc.executebuiltin('Notification($LOCALIZE[79063],$LOCALIZE[79064],5000)')
					
				elif not sgbserviceszeroconf: notification('$LOCALIZE[257]','$LOCALIZE[34302]',"",4000)
				else:
					printpoint = printpoint + "9"
					#if not systemplatformwindows: os.system('sh /storage/.kodi/addons/skin.htpt/specials/scripts/resetnetwork.sh')
			
			'''------------------------------
			---PRINT-END---------------------
			------------------------------'''
			if admin: print printfirst + "airplaybutton_LV" + printpoint
			'''---------------------------'''
			
		if resetnetworkbutton:
			'''------------------------------
			---RESET-NETWORK-BUTTON----------
			------------------------------'''
			resetnetwork('run')
		'''buttons which require internet'''
		if connected:
			if messagebutton:
				notification_common("10")
				if systemplatformwindows:
					xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.programm.htptmail/mailbox/INBOX/,return)')
					'''---------------------------'''
			if debugbutton:
				if not systemhasaddon_htptdebug: xbmc.executebuiltin('ActivateWindow(10001,plugin://script.htpt.debug/)')
				else: xbmc.executebuiltin('RunAddon(script.htpt.debug,,?mode=1)')
				'''---------------------------'''
		elif vhomecon1: xbmc.executebuiltin('Notification($LOCALIZE[79512],$LOCALIZE[21451],5000)')		
			
def skinbuttons(admin):
	if skinsettingsW:
		if adultbutton:
			'''------------------------------
			---ADULT-GAMES-------------------
			------------------------------'''
			print printfirst + space + "adultbutton"
			xbmc.executebuiltin('Skin.ToggleSetting(Adult)')
			if not systemplatformwindows:
				xbmc.sleep(1000)
				os.system('sh /storage/.kodi/addons/script.htpt.emu/specials/scripts/copyemu.sh')
			if not adult:
				'''------------------------------
				---ADULT-BUTTON-OFF->ON----------
				------------------------------'''
				returned = dialogyesno(addonString(97).encode('utf-8'),addonString(98).encode('utf-8'))
				if returned == "ok":
					'''------------------------------
					---ADULT-ALWAYS-ON---------------
					------------------------------'''
					setSkinSetting("1",'Adult2',"true")
					'''---------------------------'''
				else:
					'''------------------------------
					---ADULT-ALWAYS-OFF--------------
					------------------------------'''
					setSkinSetting("1",'Adult2',"false")
					'''---------------------------'''
				setSkinSetting("1",'Admin2',"false")
				'''---------------------------'''
				list0 = xbmc.getInfoLabel('$LOCALIZE[75003]')
				list1 = xbmc.getInfoLabel('$LOCALIZE[15016]')
				returned, value = dialogselect(addonString(99).encode('utf-8'),[list0, list1],0)
				if returned == -1:
					dialogok(addonString(95).encode('utf-8'),addonString(96).encode('utf-8'),"","")
				else:
					xbmc.executebuiltin('ActivateWindow(Home.xml)')
					xbmc.sleep(200)
					'''---------------------------'''
					if returned == 0: adultbutton2_(admin)
					elif returned == 1:
						gamesbutton_(admin)
						xbmc.sleep(1000)
						xbmc.executebuiltin('Action(PageDown)')
			else: setSkinSetting("1",'Adult2',"false")
			
		elif trakttvbutton and systemhasaddon_genesis:
			'''------------------------------
			---TRAKT-TV-BUTTON---------------
			------------------------------'''
			account_button('TRAKT TV','plugin.video.genesis', 'trakt_user', 'trakt_password', trakt_user, trakt_password, 'Account10_Active', '', '', Account10_Active, "N/A", "N/A", "")
			'''---------------------------'''
		elif sdarottvbutton and systemhasaddon_sdarottv:
			'''------------------------------
			---SDAROT-TV-BUTTON--------------
			------------------------------'''
			account_button('SDAROT TV','plugin.video.sdarot.tv', 'username', 'user_password', sdarottv_user, sdarottv_password, 'Account2_Active', 'Account2_Period', 'Account2_EndDate', Account2_Active, Account2_Period, Account2_EndDate, "")
			if not systemplatformwindows: bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.video.sdarot.tv/sdarot-cookiejar.txt',"plugin.video.sdarot.tv")
			'''---------------------------'''
		elif noobroombutton and systemhasaddon_genesis:
			'''------------------------------
			---NOOBROOM-BUTTON---------------
			------------------------------'''
			notification_common("10")
			#account_button('NOOBROOM','plugin.video.genesis', 'noobroom_mail', 'noobroom_password', noobroom_mail, noobroom_password, 'Account5_Active', 'Account5_Period', 'Account5_EndDate', Account5_Active, Account5_Period, Account5_EndDate, "")
			'''---------------------------'''
		elif premiumizebutton and systemhasaddon_genesis:
			'''------------------------------
			---PREMIUMIZE-BUTTON-------------
			------------------------------'''
			notification_common("10")
			#account_button('PREMIUMIZE','plugin.video.genesis', 'premiumize_user', 'premiumize_password', premiumize_user, premiumize_password, 'Account4_Active', 'Account4_Period', 'Account4_EndDate', Account4_Active, Account4_Period, Account4_EndDate, "")
			'''---------------------------'''
		elif movreelbutton and systemhasaddon_genesis:
			'''------------------------------
			---MOVREEL-BUTTON----------------
			------------------------------'''
			notification_common("10")
			#account_button('MOVREEL','plugin.video.genesis', 'movreel_user', 'movreel_password', movreel_user, movreel_password, 'Account3_Active', 'Account3_Period', 'Account3_EndDate', Account3_Active, Account3_Period, Account3_EndDate, "")
			'''---------------------------'''
		elif realdebridbutton and systemhasaddon_genesis:
			'''------------------------------
			---REALDEBRID-BUTTON-------------
			------------------------------'''
			account_button('REALDEBRID','plugin.video.genesis', 'realdedrid_user', 'realdedrid_password', realdedrid_user, realdedrid_password, 'Account1_Active', 'Account1_Period', 'Account1_EndDate', Account1_Active, Account1_Period, Account1_EndDate, "")
			'''---------------------------'''
		
		elif paymentmethodbutton:
			'''------------------------------
			---PAYMENT-TERMS-----------------
			------------------------------'''
			list0 = xbmc.getInfoLabel('$LOCALIZE[70014]')
			list1 = xbmc.getInfoLabel('$LOCALIZE[70015]')
			list2 = xbmc.getInfoLabel('$LOCALIZE[70016]')
			returned, value = dialogselect('$LOCALIZE[70012]',[list0, list1, list2],0)
			returned = int(returned)
			returnedS = str(returned)
			returned2 = "list" + returnedS
			if returned == -1: pass
			else: setSkinSetting("0",'ID6',value)
			
def startup(validation):
	
	validation = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION)')
	if (startup_aW or loginscreen_aW) and not validation:
		if admin: print printfirst + "startup (1)"
		xbmc.executebuiltin('ReplaceWindow(Home)')
		mac7('run',macaddress,maccon1,maccon2,maccon10,maccon11)
		'''---------------------------'''
		setAutoSettings("0")
		setAutoSettings("1")
		'''---------------------------'''
		xbmc.sleep(1000)
		xbmc.executebuiltin('RunScript(service.skin.widgets)')
		externalusb("")
		xbmc.sleep(1000)
		systemidle3 = xbmc.getCondVisibility('System.IdleTime(3)')
		if systemidle3 and not systemplatformwindows: settingschange('SystemSettings','input.enablemouse','0','no',xbmc.getInfoLabel('$LOCALIZE[14094]'),xbmc.getInfoLabel('$LOCALIZE[21369]'))
		'''---------------------------'''
		xbmc.sleep(1000)
		xbmc.executebuiltin('RunScript(script.htpt.remote)')
	
def HelpButton_Video_Pic(name, path2):
	returned = supportcheck(name, ["A", "B", "A?", "B?"], totalspace=100, Intel=False, silence=True)
	if returned == 'ok': device = "0"
	else: device = "1"
	containernumitems = xbmc.getInfoLabel('Container.NumItems')
	try: containernumitemsN = int(containernumitems)
	except: containernumitemsN = 0
	
	if containernumitemsN < 2: dialogok('[COLOR=Yellow]' + addonString(120) % (name) + '[/COLOR]', addonString(123) % (name) + addonString(133),"","")
	usb1str = xbmc.getInfoLabel('Skin.String(USB1)')
	
	'''---------------------------'''
	if name != str2:
		if device == "0": dialogok('[COLOR=Yellow]' + addonString(124) % (id10str) + '[/COLOR]', addonString(125) % (servicehtptfix_Purchase_TotalSpace),addonString(126) % (name),"")
		elif device == "1": dialogok('[COLOR=Yellow]' + addonString(124) % (id10str) + '[/COLOR]', addonString(127),addonString(155) % (usb1str),"")
		'''---------------------------'''
	if device == "0":
		returned = dialogyesno(addonString(134) % (name),addonString(135) % (name, addonString(46)))
		if returned == "ok":
			header = space + "(" + addonString(46) + ")" + space + '[COLOR=Yellow]' + addonString(129) % (name) + '[/COLOR]'+ space
			if name == str1 or name == str3: message2 = addonString(132) % (name, path2, name) + addonString(128)
			elif name == str2: message2 = addonString(172) % (name) + addonString(128)
			w = TextViewer_Dialog('DialogTextViewer.xml', "", header=header, text=message2)
			w.doModal()
			
			header = space + "(" + addonString(46) + ")" + space + '[COLOR=Yellow]' + addonString(136) % (name) + '[/COLOR]' + space
			if name == str1 or name == str3: message2 = addonString(137) % ("\\\\" + "htpt", path2, name, name) + addonString(128)
			elif name == str2: message2 = addonString(173) % ("\\\\" + "htpt", path2, name, name, name) + addonString(128)
			w = TextViewer_Dialog('DialogTextViewer.xml', "", header=header, text=message2)
			w.doModal()
			'''---------------------------'''
	
	elif device == "1":
		returned = dialogyesno(addonString(134) % (name),addonString(135) % (name, addonString(47)))
		if returned == "ok":
			header = space + "(" + addonString(47) + ")" + space + '[COLOR=Yellow]' + addonString(129) % (name) + '[/COLOR]' + space
			message2 = addonString(155) % (usb1str) + '[CR]' + addonString(156) % (path2) + '[CR]' + addonString(157) % (path2, name) + addonString(128)
			w = TextViewer_Dialog('DialogTextViewer.xml', "", header=header, text=message2)
			w.doModal()
			
			header = space + "(" + addonString(47) + ")" + space + '[COLOR=Yellow]' + addonString(136) % (name) + '[/COLOR]' + space
			message2 = addonString(137) % ("\\\\" + "htpt", str79498 + " -> " + usb1str + " -> " + path2 , name, name) + addonString(128)
			w = TextViewer_Dialog('DialogTextViewer.xml', "", header=header, text=message2)
			w.doModal()
			'''---------------------------'''
			
def topvideoinformation2(admin):
	'''------------------------------
	---Clear ListItem----------------
	------------------------------'''
	containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
	listitemtvshowtitlestr = xbmc.getInfoLabel('Skin.String(ListItemTVShowTitle)')
	'''---------------------------'''
	if not "videodb://tvshows" in containerfolderpath and not "library://video/tvshows" in containerfolderpath:
		setSkinSetting("0",'ListItemGenre',"")
		setSkinSetting("0",'ListItemDuration',"")
		setSkinSetting("0",'ListItemRating',"")
		setSkinSetting("0",'ListItemYear',"")
		setSkinSetting("0",'ListItemTVShowTitle',"")
		if listitemtvshowtitlestr: print printfirst + "topvideoinformation2" + space2 + "Clear ListItem"
		'''---------------------------'''

def settingslevelset(custom):
	'''custom: 1 = Basic, 2 = Standard, 3 = Advanced, 4 = Expert'''
	if custom == "1": custom = settingslevelstr1
	elif custom == "2": custom = settingslevelstr2
	elif custom == "3": custom = settingslevelstr3
	elif custom == "4": custom = settingslevelstr4
	else: sys.exit(1)
	'''---------------------------'''
	printpoint = ""
	settingslevel = xbmc.getInfoLabel('Skin.String(SettingsLevel)')
	'''---------------------------'''
	if settingslevel != custom:
		controlhasfocus = findin_controlhasfocus("0","20",40,'Control.SetFocus(20)','')
		count = 0
		while count < 5 and not controlhasfocus and not xbmc.abortRequested:
			if count == 0: printpoint = printpoint + "2"
			controlhasfocus = findin_controlhasfocus("0","20",40,'Control.SetFocus(20)','')
			count += 1
			'''---------------------------'''
		if controlhasfocus:
			printpoint = printpoint + "3"
			count = 0
			while count < 5 and settingslevel != custom and not xbmc.abortRequested:
				if count == 0: printpoint = printpoint + "5"
				count += 1
				systemcurrentcontrol = findin_systemcurrentcontrol("0",custom,10,'Action(Select)','Action(Down)')
				settingslevel = xbmc.getInfoLabel('Skin.String(SettingsLevel)')
				'''---------------------------'''
		else: printpoint = printpoint + "9"
	else:
		printpoint = printpoint + "8"
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "settingslevelset_LV" + printpoint
	'''---------------------------'''
	
def adultbutton2_(admin):
	if systemhasaddon_videodevil: xbmc.executebuiltin('RunAddon(plugin.video.videodevil)')
	else: xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.videodevil)')
	'''---------------------------'''
	
def gamesbutton_(admin):
	if not systemplatformwindows: os.system('sh /storage/.kodi/addons/script.htpt.emu/specials/scripts/launcher.sh')
	xbmc.executebuiltin('RunAddon(plugin.program.advanced.launcher)')
	xbmc.sleep(2000)
	systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
	containernumitems = xbmc.getInfoLabel('Container.NumItems')
	'''---------------------------'''
	if (systemcurrentcontrol == "[..]" or systemcurrentcontrol == "[Default]") and (containernumitems == "0" or containernumitems == "1"):
		'''------------------------------
		---FIX-CONFIGURATION-FILE--------
		------------------------------'''
		print printfirst + space + "gamesbutton" + space + "Possible Error in file: launcher.xml"
		dialogok(addonString(130).encode('utf-8'),addonString(131).encode('utf-8'),"","")
		if not systemplatformwindows: os.system('sh /storage/.kodi/addons/script.htpt.emu/specials/scripts/copyemu.sh')
		xbmc.executebuiltin('ActivateWindow(Home.xml)')
		xbmc.sleep(2000)
		xbmc.executebuiltin('RunAddon(plugin.program.advanced.launcher)')
		'''---------------------------'''

def backward(run2):
	#viewmode = xbmc.getInfoLabel('Container.Viewmode')
	#if viewmode == 'GeneralPT' : xbmc.executebuiltin('Control.SetFocus(50,0)')
	#if viewmode == 'IconsPT' : xbmc.executebuiltin('Control.SetFocus(58,0)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(Select)')
	xbmc.sleep(2000)

def resetnetwork(run):
	'''tweak and reload the network adapters'''
	xbmc.executebuiltin('Notification([COLOR Red] $VAR[CurrentMAC][/COLOR] $LOCALIZE[79061],$LOCALIZE[79062],5000)')
	if not systemplatformwindows: os.system('sh /storage/.kodi/addons/skin.htpt/specials/scripts/resetnetwork.sh')
	xbmc.sleep(1000)
	oewindow("Network")

def externalusb(device):
	'''detect connected USB'''
	name = 'externalusb'
	if device == "": 
		returned = supportcheck(name, ["A", "B", "A?", "B?"], totalspace=100, Intel=False, silence=True)
		if returned == 'ok': device = "0"
		else: device = "1"
		
	if not systemplatformwindows and myhtpt2:
		xbmc.sleep(40)
		if picturesbutton or videosbutton or startup_aW:
			os.system('sh /storage/.kodi/addons/skin.htpt/specials/scripts/externalusb.sh')
			#subprocess.call('/storage/.kodi/addons/script.htpt.homebuttons/specials/scripts/externalusb.sh', shell=True)
			xbmc.sleep(500)
		log = open('/storage/externalusb.log', 'r')
		rows = log.readlines()
		rowscountN = len(rows)
		rowscount = str(rowscountN)
		log.close()
		row1 = ""
		row2 = ""
		row3 = ""
		row4 = ""
		row5 = ""
		if rowscountN > 0: row1 = rows[0][:-1]
		if rowscountN > 1: row2 = rows[1][:-1]
		if rowscountN > 2: row3 = rows[2][:-1]
		if rowscountN > 3: row4 = rows[3][:-1]
		if rowscountN > 4: row5 = rows[4][:-1]
		if picturesbutton or videosbutton or startup_aW:
			if usb1str != row1: xbmc.executebuiltin('Skin.SetString(USB1,'+ row1 +')')
			if usb2str != row2: xbmc.executebuiltin('Skin.SetString(USB2,'+ row2 +')')
			if usb3str != row3: xbmc.executebuiltin('Skin.SetString(USB3,'+ row3 +')')
			if usb4str != row4: xbmc.executebuiltin('Skin.SetString(USB4,'+ row4 +')')
			if usb5str != row5: xbmc.executebuiltin('Skin.SetString(USB5,'+ row5 +')')
			'''---------------------------'''
		if admin and rowscountN > 0: xbmc.executebuiltin('Notification(Admin,'+ rowscount +' '+ row1 +' ,1000)')
		path0 = 'special://userdata/library/'
		path1 = '/var/media/'+ row1 +'/'
		path2 = '/var/media/'+ row2 +'/'
		path3 = '/var/media/'+ row3 +'/'
		path4 = '/var/media/'+ row4 +'/'
		path5 = '/var/media/'+ row5 +'/'
		pathwin = 'special://home/external/'
		if rowscountN == 0 and myhtpt3: xbmc.executebuiltin('Skin.ToggleSetting(myHTPT3)')
		if rowscountN > 0 and not myhtpt3: xbmc.executebuiltin('Skin.ToggleSetting(myHTPT3)')
		xbmc.sleep(200)
		'''---------------------------'''
		if (myvideonavW or mypicsW) and usbtoggle:
			#xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,)')
			#xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,)')
			if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path0 +')') and rowscountN > 0:
				if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path1 +'videos/,return)')
				if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path1 +'pictures/,return)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,1)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path1 +')')
			elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path1 +')') and rowscountN > 1:
				if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path2 +'videos/,return)')
				if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path2 +'pictures/,return)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,2)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path2 +')')
			elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path2 +')') and rowscountN > 2:
				if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path3 +'videos/,return)')
				if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path3 +'pictures/,return)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,3)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path3 +')')
			elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path3 +')') and rowscountN > 3:
				if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path4 +'videos/,return)')
				if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path4 +'pictures/,return)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,4)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path4 +')')
				'''---------------------------'''
			elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path4 +')') and rowscountN > 4:
				if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path5 +'videos/,return)')
				if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path5 +'pictures/,return)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,5)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path5 +')')
				'''---------------------------'''
			if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path1 +')') and rowscountN == 1:
				if device == "1":
					if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path1 +'videos/,return)')
					elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path1 +'pictures/,return)')
					'''---------------------------'''
				elif myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'videos/,return)')
				elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'pictures/,return)')
			elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path2 +')') and rowscountN == 2:
				if device == "1":
					if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path1 +'videos/,return)')
					elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path1 +'pictures/,return)')
					'''---------------------------'''
				elif myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'videos/,return)')
				elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'pictures/,return)')
			elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path3 +')') and rowscountN == 3:
				if device == "1":
					if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path1 +'videos/,return)')
					elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path1 +'pictures/,return)')
					'''---------------------------'''
				elif myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'videos/,return)')
				elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'pictures/,return)')
			elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path4 +')') and rowscountN == 4:
				if device == "1":
					if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path1 +'videos/,return)')
					elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path1 +'pictures/,return)')
					'''---------------------------'''
				elif myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'videos/,return)')
				elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'pictures/,return)')
			elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path5 +')') and rowscountN == 5:
				if device == "1":
					if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path1 +'videos/,return)')
					elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path1 +'pictures/,return)')
					'''---------------------------'''
				elif myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'videos/,return)')
				elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'pictures/,return)')
				'''---------------------------'''
			xbmc.sleep(20)
			containernumitems = xbmc.getInfoLabel('Container.NumItems')
			if containernumitems == 0: xbmc.executebuiltin('Action(Select)')
			
def mac7(run,macaddress,maccon1,maccon2,maccon10,maccon11):
	'''VALIDATION PROOF'''
	validation2 = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION2)')
	printpoint = ""
	if (not maccon1 and not maccon2) or (not maccon10 and not maccon11):
		xbmc.sleep(200)
		xbmc.executebuiltin('Notification(MAC7,step 1,1000)')
		if (not maccon1 and not maccon2):
			#macaddress = xbmc.getInfoLabel('Network.MacAddress')
			xbmc.executebuiltin('Skin.SetString(MAC,'+ macaddress +')')
			xbmc.sleep(500)
			maccon1 = xbmc.getCondVisibility('StringCompare(Skin.String(MAC),Skin.String(MAC1))')
			maccon2 = xbmc.getCondVisibility('StringCompare(Skin.String(MAC),Skin.String(MAC2))')
			printpoint = printpoint + "1"
		else:
			maccon10 = xbmc.getCondVisibility('StringCompare(Control.GetLabel(700100),NONE)')
			maccon11 = xbmc.getCondVisibility('StringCompare(Control.GetLabel(700100),7000)')
			printpoint = printpoint + "2"
		xbmc.sleep(200)
		if (not maccon1 and not maccon2) or (not maccon10 and not maccon11):
			if validation5 == '0':
				xbmc.executebuiltin('Notification(Admin,MAC7,step 2,1000)')
				if not validation: xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION)')
				if not validation2: xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION2)')
				if not widget: xbmc.executebuiltin('Skin.ToggleSetting(Widget)')
				xbmc.executebuiltin('Notification($LOCALIZE[79080],For Support: [COLOR Yellow]$LOCALIZE[79081][/COLOR],5000,icons/shield.png)')
				if macaddress and not loginscreenW and home_pW: xbmc.executebuiltin('ReplaceWindow(LoginScreen.xml)')
				if validation and playerhasmedia: xbmc.executebuiltin('Action(Stop)')
				
				if not maccon1 and not maccon2 and validation and not macaddress and id9str != 'COPIED':
					xbmc.executebuiltin('Skin.SetString(ID9,COPIED)')
					xbmc.executebuiltin('Notification(COPIED,,5000)')
					xbmc.executebuiltin('ReplaceWindow(LoginScreen.xml)')
				printpoint = printpoint + "3"
			else:
				if validation5 == '3': xbmc.executebuiltin('Skin.SetString(VALIDATION5,2)')
				if validation5 == '2': xbmc.executebuiltin('Skin.SetString(VALIDATION5,1)')
				if validation5 == '1': xbmc.executebuiltin('Skin.SetString(VALIDATION5,0)')
				
				xbmc.executebuiltin('Notification(Admin MAC7:,-validation5 reduced from ('+ validation5 +')')
				printpoint = printpoint + "4"
	else:
		'''UNLOCK'''
		printpoint = printpoint + "5"
		if validation2:
			printpoint = printpoint + "6"
			if connected:
				xbmc.sleep(3000)
				xbmc.executebuiltin('Notification($LOCALIZE[79086],$LOCALIZE[79084],3000,icons/shield.png)')
				xbmc.sleep(1000)
				validation2 = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION2)')
				if validation2: xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION2)')
				printpoint = printpoint + "7"
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + space + "mac7_LV" + printpoint + space3
	'''---------------------------'''

def mac(run,macaddress):
	if validation and (home_aW or startup_aW or startup_pW or loginscreenbutton):
		print printfirst + "mac (1)"
		xbmc.sleep(40)
		if macaddress and macaddress != str503:
			macaddress = xbmc.getInfoLabel('Network.MacAddress')
			xbmc.executebuiltin('Skin.SetString(MAC,'+ macaddress +')')
			xbmc.sleep(500)
		if not validation2: xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION2)')
		if validation5 == '3':
			xbmc.executebuiltin('Skin.SetString(VALIDATION5,2)')
			xbmc.executebuiltin('AlarmClock(HTPTCHECK: '+ idstr +'*0 | '+ id1str +'*1 | '+ id2str +'*2 | '+ id3str +'*3 | '+ id4str +'*4 | '+ id5str +'*5 | '+ id6str +'*6 | '+ id7str +'*7 | '+ id8str +'*8 | '+ id9str +'*9 | '+ id10str +'*10 | '+ mac1str +'*MAC1 | '+ mac2str +'*MAC2 | '+ mac3str +'*MAC3 | '+ macaddress +'*MAC | '+ systemtotaluptime +'*TOTALUPTIME | '+ verrorstr +'*VERROR | ,Action(Stop),0,silent)')
			if not connected2 and not connected3 and systemuptime5: xbmc.executebuiltin('AlarmClock(loginscreendelay,ReplaceWindow(LoginScreen.xml),00:02,silent)')
		if validation5 == '2':
			xbmc.executebuiltin('Skin.SetString(VALIDATION5,1)')
			if not maccon10 and not maccon11 and home_aW: xbmc.executebuiltin('Notification($LOCALIZE[79080],$LOCALIZE[257]: $VAR[VERROR],5000,icons/shield.png)')
		if validation5 == '1':
			xbmc.executebuiltin('Skin.SetString(VALIDATION5,0)')
			xbmc.executebuiltin('Notification($LOCALIZE[79080],For Support: [COLOR Yellow]$LOCALIZE[79081][/COLOR],5000,icons/shield.png)')
		if validation5 == '0':
			if not loginscreenW: xbmc.executebuiltin('ReplaceWindow(LoginScreen.xml)')
			if loginscreen_aW: xbmc.executebuiltin('Notification($LOCALIZE[79080],For Support: [COLOR Yellow]$LOCALIZE[79081][/COLOR],5000,icons/shield.png)')
		xbmc.sleep(40)
		'''UNLOCK SYSTEM'''
		if (maccon1 or maccon2) and (maccon10 or maccon11):
			xbmc.sleep(40)
			print printfirst + "mac (2)"
			xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION)')
			if not widget: xbmc.executebuiltin('Skin.ToggleSetting(Widget)')
			xbmc.executebuiltin('Skin.SetString(VALIDATION5,3)')
			#xbmc.sleep(500)
			if connected:
				xbmc.sleep(40)
				xbmc.executebuiltin('Notification($LOCALIZE[79083],$LOCALIZE[79082],5000,icons/shield2.png)')
				mac7('run',macaddress,maccon1,maccon2,maccon10,maccon11)
			else:
				xbmc.executebuiltin('Notification($LOCALIZE[79083],$LOCALIZE[24073],5000,icons/shield2.png)')
			#if home_aW:
				#xbmc.executebuiltin('Control.SetFocus('+ container9000pos +')')
				#xbmc.sleep(500)
				#if admin: xbmc.executebuiltin('Notification(Admin, '+ container9000pos +',2000,icons/shield2.png)')
				#xbmc.executebuiltin('Action(Select)')
			if loginscreen_aW:
				#xbmc.executebuiltin('ActivateWindow(0)')
				xbmc.executebuiltin('ReplaceWindow(0)')
				
