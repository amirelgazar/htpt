#import xbmc, os, subprocess, sys
#import xbmc, xbmcgui, xbmcaddon
import xbmc, xbmcgui, xbmcaddon
import subprocess, os, sys
#import datetime, time
from variables import *
from shared_modules import *
#from shared_modules2 import *
#from modules2 import *

def setAutoSettings(custom):
	if custom == "0":
		
		addon = 'plugin.video.sdarot.tv'
		if systemhasaddon_sdarottv:
			'''------------------------------
			---plugin.video.sdarot.tv--------
			------------------------------'''
			addonsettings('SDAROT TV', 'plugin.video.sdarot.tv', 'Account2_Active', 'Account2_Period', 'username','user_password', "", "", "", "")
			addonsettings2(addon,'DEBUG',"false",'cache',"24",'domain',"http://www.sdarot.wf",'',"",'',"")
		
			if not systemplatformwindows: bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.video.sdarot.tv/sdarot-cookiejar.txt',"plugin.video.sdarot.tv")
			'''---------------------------'''
		else:
			installaddon(admin, addon, "")
			'''---------------------------'''
		
		addon = 'service.subtitles.subtitle'
		if systemhasaddon_servicesubtitlessubtitle:
			'''------------------------------
			---service.subtitles.subtitle----
			------------------------------'''
			addonsettings2('service.subtitles.subtitle','SUBemail',idstr + "@gmail.com",'SUBpassword',idpstr,'',"",'',"",'',"")
			if not systemplatformwindows: bash('rm -rf /storage/.kodi/userdata/addon_data/service.subtitles.subtitle/cookiejar.txt',"service.subtitles.subtitle")
			'''---------------------------'''
		else:
			installaddon(admin, addon, "")
			'''---------------------------'''
		
		addon = 'plugin.video.israelive'
		if systemhasaddon_pluginvideoisraelive:
			'''------------------------------
			---plugin.video.israelive--------
			------------------------------'''
			if sgbpvrmanagerenabled: addonsettings2(addon,'autoIPTV',"0",'useIPTV',"true",'',"",'',"",'',"")
			else: addonsettings2(addon,'autoIPTV',"1",'useIPTV',"false",'',"",'',"",'',"")
			addonsettings2(addon,'',"",'useEPG',"true",'StreramProtocol',"1",'forceRemoteDefaults',"true",'StreramsMethod',"0")
			addonsettings2(addon,'catColor',"chartreuse",'useEPG',"true",'chColor',"yellow",'prColor',"floralwhite",'timesColor',"none")
			#setsetting_custom1(addon,remoteSettingsUrl,"")
			
			'''---------------------------'''
		else:
			installaddon(admin, addon, "")
			'''---------------------------'''
		
		addon = 'plugin.video.youtube'
		if systemhasaddon_pluginvideoyoutube:
			'''------------------------------
			---plugin.video.youtube----------
			------------------------------'''
			addonsettings2(addon,'kodion.view.override',"true",'kodion.video.quality',"4",'kodion.view.default',"50",'kodion.view.episodes',"58",'kodion.search.size',"4")
			addonsettings2(addon,'kodion.setup_wizard',"false",'youtube.folder.disliked_videos.show',"false",'youtube.language',"iw-IL",'kodion.fanart.show',"false",'youtube.folder.sign.in.show',"true")
			if not systemplatformwindows: bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.video.youtube/kodion/cache.sqlite',"plugin.video.youtube")
			'''---------------------------'''
		else:
			installaddon(admin, addon, "")
			'''---------------------------'''
		
		addon = 'service.autosubs'
		if systemhasaddon_serviceautosubs:
			'''------------------------------
			---service.autosubs--------------
			------------------------------'''
			pass
			#addonsettings2(addon,'check_for_specific',"true",'selected_language',"Hebrew",'debug',"false",'ExcludeTime',"15",'ignore_words',"theme")
			#addonsettings2(addon,'ExcludeHTTP',"false",'ExcludeLiveTV',"true",'',"",'',"",'',"")
			'''---------------------------'''
		else:
			pass
			'''---------------------------'''
		
		addon = 'plugin.video.aob'
		if systemhasaddon_aob:
			'''------------------------------
			---plugin.video.aob--------------
			------------------------------'''
			addonsettings2(addon,'tvshows-view',"58",'default-view',"50",'auto-view',"true",'',"",'',"")
			'''---------------------------'''
		else:
			pass
			'''---------------------------'''
		
		#installaddon(admin, 'plugin.video.ynet.video', "") #TESTING MODULE
		
		'''------------------------------
		---script.htpt.homebuttons-------
		------------------------------'''	
		dialogtextviewerW = xbmc.getCondVisibility('Window.IsVisible(DialogTextViewer.xml)')
		while dialogtextviewerW and not xbmc.abortRequested:
			xbmc.sleep(1000)
			dialogtextviewerW = xbmc.getCondVisibility('Window.IsVisible(DialogTextViewer.xml)')
			'''---------------------------'''
		set_accountdate('REALDEBRID','plugin.video.genesis', 'realdedrid_user', 'realdedrid_password', realdedrid_user, realdedrid_password, 'Account1_Active', 'Account1_Period', 'Account1_EndDate', Account1_Active, Account1_Period, Account1_EndDate, "1")
		set_accountdate('SDAROT TV','plugin.video.sdarot.tv', 'username', 'user_password', sdarottv_user, sdarottv_password, 'Account2_Active', 'Account2_Period', 'Account2_EndDate', Account2_Active, Account2_Period, Account2_EndDate, "1")
		'''---------------------------'''
	
	elif custom == "1":
		if not adult2: setSkinSetting("1",'adult',"false")
		if not moviesestartup: setSkinSetting("0",'moviesestartup',"1")
		if not tvshowsestartup: setSkinSetting("0",'tvshowsestartup',"1")
		'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "setAutoSettings" + space + "custom" + space2 + custom
	'''---------------------------'''

def account_button(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, custom):
	getsetting_addon         = xbmcaddon.Addon(addon).getSetting
	printpoint = ""
	'''---------------------------'''
	if skinsetting:
		'''------------------------------
		---DIALOG-YESNO-USER+PASS--------
		------------------------------'''
		returned = dialogyesno(addonString(74).encode('utf-8'),addonString(75).encode('utf-8') + '[CR]' + addonString(73).encode('utf-8') % (username))
		if returned == 'ok':
			'''------------------------------
			---DIALOG-KEYBOARD-USER----------
			------------------------------'''
			printpoint = printpoint + "1"
			if 'htpt' in username: username = ""
			returned = dialogkeyboard(username,'$LOCALIZE[20142]',0,'3',usernameS,addon)
			if returned == 'skip':
				notification('$LOCALIZE[257]',addonString(69).encode('utf-8'),"",2000)
				printpoint = printpoint + "7"
				'''---------------------------'''
			else:
				'''------------------------------
				---DIALOG-KEYBOARD-PASS----------
				------------------------------'''
				printpoint = printpoint + "2"
				returned = dialogkeyboard(password,'$LOCALIZE[15052]',1,'3',passwordS,addon)
				if returned == 'skip':
					notification('$LOCALIZE[257]',addonString(69).encode('utf-8'),"",2000)
					printpoint = printpoint + "7"
				else:
					printpoint = printpoint + "3"
					'''---------------------------'''
		'''------------------------------
		---DIALOG-YES-NO-PERIOD----------
		------------------------------'''
		if not "7" in printpoint and skinsetting2 != "N/A":
			returned = dialogyesno(addonString(70).encode('utf-8'),addonString(71).encode('utf-8') % (skinsetting2))
			if returned == 'ok':
				printpoint = printpoint + "4"
				returned = dialognumeric(0,addonString(68).encode('utf-8'),skinsetting2,'2',skinsetting2S)
				if returned == 'skip': notification('$LOCALIZE[257]',addonString(69).encode('utf-8'),"",2000)
				else:
					printpoint = printpoint + "5"
					
		if printpoint == "" or "7" in printpoint:
			'''------------------------------
			---DIALOG-YES-NO-TURNOFF---------
			------------------------------'''
			returned = dialogyesno(addonString(72).encode('utf-8'),addonString(73).encode('utf-8') % (username))
			if returned == 'ok':
				setSkinSetting("1", skinsettingS, "false")
				setSkinSetting("0", skinsetting2S, "")
				setSkinSetting("0", skinsetting3S, "")
				setsetting_genesis(usernameS, "")
				setsetting_genesis(passwordS, "")
				'''---------------------------'''
			else:
				notification(addonString(66).encode('utf-8'),addonString(67).encode('utf-8'),"",4000)
				'''---------------------------'''
				
		if ("1" in printpoint and "3" in printpoint) or ("4" in printpoint and "5" in printpoint):
			'''------------------------------
			---DIALOG-OK-ACCOUNT-EDITED------
			------------------------------'''
			xbmc.sleep(500)
			skinsetting = xbmc.getInfoLabel('Skin.HasSetting('+ skinsettingS +')')
			skinsetting2 = xbmc.getInfoLabel('Skin.String('+ skinsetting2S +')')
			username = getsetting_addon(usernameS)
			password = getsetting_addon(passwordS)
			'''---------------------------'''
			
			if name == "REALDEBRID":
				'''------------------------------
				---REALDEBRID--------------------
				------------------------------'''
				dialogok(addonString(56).encode('utf-8') % ('[COLOR=Yellow]' + name + '[/COLOR]'),addonString(73).encode('utf-8') % (username),addonString(61).encode('utf-8') % (password),addonString(71).encode('utf-8') % (skinsetting2))
				dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + addonString(76).encode('utf-8'),addonString(77).encode('utf-8'),addonString(78).encode('utf-8'),addonString(79).encode('utf-8'))
				set_accountdate(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, "0")
				'''---------------------------'''
				
			elif name == "SDAROT TV":
				'''------------------------------
				---SDAROT-TV---------------------
				------------------------------'''
				dialogok(addonString(56).encode('utf-8') % ('[COLOR=Yellow]' + name + '[/COLOR]'),addonString(73).encode('utf-8') % (username),addonString(61).encode('utf-8') % (password),addonString(71).encode('utf-8') % (skinsetting2))
				dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + addonString(76).encode('utf-8'),addonString(77).encode('utf-8'),addonString(87).encode('utf-8'),addonString(88).encode('utf-8'))
				set_accountdate(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, "0")
				'''---------------------------'''
			
			elif name == "TRAKT TV":
				'''------------------------------
				---TRAKT-TV----------------------
				------------------------------'''
				dialogok(addonString(56).encode('utf-8') % ('[COLOR=Yellow]' + name + '[/COLOR]'),addonString(73).encode('utf-8') % (username),addonString(61).encode('utf-8') % (password),"")
				dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + addonString(76).encode('utf-8'),addonString(77).encode('utf-8'),addonString(85).encode('utf-8'),addonString(86).encode('utf-8'))
				'''---------------------------'''	

	else:
		'''------------------------------
		---DIALOG-YES-NO-HAVE-ACCOUNT?---
		------------------------------'''
		returned = dialogyesno(addonString(57).encode('utf-8') % (name),addonString(65).encode('utf-8'))
		if returned == 'ok':
			'''------------------------------
			---DIALOG-KEYBOARD-USER----------
			------------------------------'''
			if admin or not 'htpt' in username: input = username
			else: input = ""
			returned = dialogkeyboard(input,'$LOCALIZE[20142]',0,'3',usernameS,addon)
			if returned == 'skip': pass
			else:
				'''------------------------------
				---DIALOG-KEYBOARD-PASS----------
				------------------------------'''
				returned = dialogkeyboard(password,'$LOCALIZE[15052]',1,'3',passwordS,addon)
				if returned == 'skip': pass
				else:
					'''------------------------------
					---DIALOG-NUMERIC--PERIOD--------
					------------------------------'''
					if skinsetting2 != "N/A": returned = dialognumeric(0,addonString(68).encode('utf-8'),"30",'2',skinsetting2S)
					else: returned = 'ok'
					if returned == 'skip': pass
					else:
						'''------------------------------
						---DIALOG-OK-ACCOUNT-ON-------
						------------------------------'''
						setSkinSetting("1", skinsettingS, "true")
						xbmc.sleep(500)
						skinsetting = xbmc.getInfoLabel('Skin.HasSetting('+ skinsettingS +')')
						skinsetting2 = xbmc.getInfoLabel('Skin.String('+ skinsetting2S +')')
						skinsetting3 = xbmc.getInfoLabel('Skin.String('+ skinsetting3S +')')
						username = getsetting_addon(usernameS)
						password = getsetting_addon(passwordS)
						'''---------------------------'''
						
						if name == "REALDEBRID":
							'''------------------------------
							---REALDEBRID--------------------
							------------------------------'''
							dialogok(addonString(56).encode('utf-8') % ('[COLOR=Yellow]' + name + '[/COLOR]'),addonString(73).encode('utf-8') % (username),addonString(61).encode('utf-8') % (password),addonString(71).encode('utf-8') % (skinsetting2))
							dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + addonString(76).encode('utf-8'),addonString(77).encode('utf-8'),addonString(78).encode('utf-8'),addonString(79).encode('utf-8'))
							set_accountdate(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, "0")
							'''---------------------------'''
							
						elif name == "SDAROT TV":
							'''------------------------------
							---SDAROT-TV---------------------
							------------------------------'''
							dialogok(addonString(56).encode('utf-8') % ('[COLOR=Yellow]' + name + '[/COLOR]'),addonString(73).encode('utf-8') % (username),addonString(61).encode('utf-8') % (password),addonString(71).encode('utf-8') % (skinsetting2))
							dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + addonString(76).encode('utf-8'),addonString(77).encode('utf-8'),addonString(87).encode('utf-8'),addonString(88).encode('utf-8'))
							set_accountdate(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, "0")
							'''---------------------------'''
						
						elif name == "TRAKT TV":
							'''------------------------------
							---TRAKT-TV----------------------
							------------------------------'''
							dialogok(addonString(56).encode('utf-8') % ('[COLOR=Yellow]' + name + '[/COLOR]'),addonString(73).encode('utf-8') % (username),addonString(61).encode('utf-8') % (password),"")
							dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + addonString(76).encode('utf-8'),addonString(77).encode('utf-8'),addonString(85).encode('utf-8'),addonString(86).encode('utf-8'))
							'''---------------------------'''
							
			if returned == 'skip':
				'''------------------------------
				---DIALOG-NOTIFICATION-TURNOFF---
				------------------------------'''
				notification('$LOCALIZE[257]',addonString(69).encode('utf-8'),"",2000)
				setSkinSetting("1", skinsettingS, "false")
				setSkinSetting("0", skinsetting2S, "")
				setSkinSetting("0", skinsetting3S, "")
				setsetting_custom1(addon,usernameS,"")
				setsetting_custom1(addon,passwordS,"")
				'''---------------------------'''
		else:
			'''------------------------------
			---DIALOG-OK-SIGNUP-INFO---------
			------------------------------'''
			if name == "REALDEBRID": dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + 'https://real-debrid.com/',addonString(64).encode('utf-8'),'[CR]' + addonString(80).encode('utf-8'),'[CR]' + addonString(81).encode('utf-8'))
			elif name == "SDAROT TV": dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + 'http://sdarot.wf/',addonString(64).encode('utf-8'),'[CR]' + addonString(83).encode('utf-8'),'[CR]' + addonString(84).encode('utf-8'))
			elif name == "TRAKT TV": dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + 'http://trakt.tv/',addonString(64).encode('utf-8'),'[CR]' + addonString(89).encode('utf-8'),"")
			'''---------------------------'''
	
	if name == "REALDEBRID":
		'''------------------------------
		---urlresolver-------------------
		------------------------------'''
		if systemhasaddon_urlresolver: addonsettings2('script.module.urlresolver','RealDebridResolver_login',"true",'RealDebridResolver_enabled',"true",'RealDebridResolver_priority',"101",'RealDebridResolver_username',username,'RealDebridResolver_password',password)
		'''---------------------------'''
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "account_button LV_" + printpoint + space2 + name + space + addon + space3
	'''---------------------------'''

def set_accountdate(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, custom):
	'''------------------------------
	---CALCULATE-END-DATES-----------
	------------------------------'''
	try: numberN = int(skinsetting2)
	except: numberN = 0
	
	if skinsetting3 != "":
		notification("test",skinsetting3,"",2000)
		dateleft = stringtodate(skinsetting3,'%Y-%m-%d')
		dateleft2 = str(dateleft)
		dateleft2S = str(dateleft2)
		datenow2 = stringtodate(datenowS,'%Y-%m-%d')
		number2 = dateleft - datenow2
		number2S = str(number2)
		if "day," in number2S: number2S = number2S.replace(" day, 0:00:00","",1)
		elif "days," in number2S: number2S = number2S.replace(" days, 0:00:00","",1)
		else: number2S = "0"
		if admin: notification("number2S:" + number2S,"","",2000)
		number2N = int(number2S)
	else:
		number2S = "0"
		number2N = int(number2S)
	if number2N < 0: 
		number2S = "0"
		number2N = int(number2S)
		'''---------------------------'''
	
	if custom == "0":
		'''------------------------------
		---MANUAL-SET--------------------
		------------------------------'''
		import datetime as dt
		dateafter2 = datenow + dt.timedelta(days=numberN)
		dateafter2S = str(dateafter2)
		#setsetting(skinsetting3, dateafter2S)
		setSkinSetting("0", skinsetting3S, dateafter2S)
		'''---------------------------'''
		
		'''---------------------------'''
	if custom == "1":
		'''------------------------------
		---AUTO-SET----------------------
		------------------------------'''
		
		'''---------------------------'''
		if skinsetting2 != "" or skinsetting3 != "": setSkinSetting("0", skinsetting2S, number2S)
		'''---------------------------'''
		
		if skinsetting and number2N < 7:
			'''------------------------------
			---PERIOD-ABOUT-TO-END-----------
			------------------------------'''
			if number2N > 0 and number2N < 7: dialogok(addonString(63).encode('utf-8') + '[CR]' + '[COLOR=Yellow]' + name + '[/COLOR]',"",addonString(73).encode('utf-8') % (username) + '[CR]' + addonString(71).encode('utf-8') % (number2S),"")
			elif skinsetting and number2N == 0: dialogok(addonString(60).encode('utf-8') + '[CR]' + '[COLOR=Yellow]' + name + '[/COLOR]',"",addonString(73).encode('utf-8') % (username) + '[CR]' + addonString(71).encode('utf-8') % (number2S),"")
			'''---------------------------'''
			
			'''------------------------------
			---DIALOG-YESNO-REMAKE-----------
			------------------------------'''
			returned = dialogyesno(addonString(59).encode('utf-8') + space + name,addonString(58).encode('utf-8') + '[CR]' + addonString(73).encode('utf-8') % (username))
			if returned == "ok":
				skinsettingsW = xbmc.getCondVisibility('Window.IsVisible(SkinSettings.xml)')
				if not skinsettingsW: xbmc.executebuiltin('ActivateWindow(SkinSettings.xml)')
				'''---------------------------'''
				count = 0
				while count < 40 and not skinsettingsW and not xbmc.abortRequested:
					'''------------------------------
					---skinsettingsW-PENDING---------
					------------------------------'''
					xbmc.sleep(100)
					count += 1
					skinsettingsW = xbmc.getCondVisibility('Window.IsVisible(SkinSettings.xml)')
					'''---------------------------'''
				if skinsettingsW:
					'''------------------------------
					---skinsettingsW-TRUE------------
					------------------------------'''
					xbmc.executebuiltin('Control.SetFocus(100,4)')
					xbmc.executebuiltin('Control.SetFocus(50,1)')
					xbmc.sleep(40)
					count = 0
					'''---------------------------'''
					count = 0
					systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
					while count < 10 and not name in systemcurrentcontrol and not xbmc.abortRequested:
						'''------------------------------
						---systemcurrentcontrol=name-----
						------------------------------'''
						xbmc.executebuiltin('Action(Down)')
						count += 1
						xbmc.sleep(40)
						if admin: print printfirst + space + "set_accountdate" + space2 + "systemcurrentcontrol=name" + space2 + systemcurrentcontrol + " != " + name + space3
						systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
						xbmc.sleep(100)
						
				
				if name == 'REALDEBRID': account_button(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, custom)
				elif name == 'SDAROT TV': account_button(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, custom)
				'''---------------------------'''
			elif number2N == 0:
				'''------------------------------
				---SETTING-OFF-------------------
				------------------------------'''
				setSkinSetting("1", skinsettingS, "false")
				setSkinSetting("0", skinsetting2S, "")
				setSkinSetting("0", skinsetting3S, "")
			'''---------------------------'''
	
		elif not skinsetting and number2N > 0:
			'''------------------------------
			---SETTING-SHOULD-BE-ON?---------
			------------------------------'''
			pass
			
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin and custom == "1": print printfirst + "set_accountdate" + space + "name" + space2 + name + space + skinsetting + space + skinsetting2 + space + "number2S" + space2 + number2S + space + custom + space3
	'''---------------------------'''

def homebuttons(admin):
	'''activate home buttons'''
	if not validation and homeW:
		if moviesbutton:
			libraryhascontentmovies = xbmc.getCondVisibility('Library.HasContent(Movies)')
			if libraryhascontentmovies:
				if admin: xbmc.executebuiltin('Notification(Admin,moviesbutton,1000)')
				xbmc.executebuiltin('ActivateWindow(Videos,MovieTitles,return)')
			else:
				if not autoviewoff: xbmc.executebuiltin('Skin.ToggleSetting(AutoViewoff)')
				xbmc.executebuiltin('ActivateWindow(video,"special://userdata/library/movies/",return)')
				xbmc.executebuiltin('Notification($LOCALIZE[79079] $LOCALIZE[342] $LOCALIZE[79090],$LOCALIZE[79091],4000)')
				'''---------------------------'''
		elif tvshowsbutton:
			libraryhascontenttvshows = xbmc.getCondVisibility('Library.HasContent(TVShows)')
			if libraryhascontenttvshows:
				if admin: xbmc.executebuiltin('Notification(Admin,tvshowsbutton,1000)')
				xbmc.executebuiltin('ActivateWindow(VideoLibrary,TVShowTitles,return)')
			else:
				if not autoviewoff: xbmc.executebuiltin('Skin.ToggleSetting(AutoViewoff)')
				xbmc.executebuiltin('ActivateWindow(video,"special://userdata/library/tvshows/",return)')
				xbmc.executebuiltin('Notification($LOCALIZE[79079] $LOCALIZE[20343] $LOCALIZE[79090],$LOCALIZE[79091],4000)')
				'''---------------------------'''
		elif gamesbutton:
			'''------------------------------
			---GAMES-BUTTON------------------
			------------------------------'''
			gamesbutton_(admin)
			'''---------------------------'''
		elif picturesbutton or videosbutton:
			'''------------------------------
			---PICTURE-&-VIDEO-BUTTON--------
			------------------------------'''
			containernumitems = ""
			printpoint = ""
			name = ""
			path = ""
			if id10str != "C" and id10str != "D" and id10str != "": device = "0"
			else: device = "1"
			if picturesbutton:
				name = str1
				path2 = "pictures"
			elif videosbutton:
				name = str3
				path2 = "videos"
			if device == "0": path = 'special://userdata/library/' + path2 + "/"
			else:
				externalusb('run')
				usb1str = xbmc.getInfoLabel('Skin.String(USB1)')
				if usb1str == "" and not systemplatformwindows: printpoint = printpoint + "9"
				'''---------------------------'''
				if usb1str != "": path = '/var/media/' + '+ usb1str +'
				elif systemplatformwindows: path = 'special://home/external/' + path2
				'''---------------------------'''
			if printpoint == "":
				xbmc.executebuiltin('ActivateWindow('+ path2 +','+ path +',return)')
				#xbmc.executebuiltin('ActivateWindow(Pictures,/var/media/'+ usb1str +',return)')
				#xbmc.executebuiltin('ActivateWindow(Pictures,special://userdata/library/pictures/,return)')
				#if not admin and not playerhasmedia: xbmc.executebuiltin('PlayMedia(special://userdata/addon_data/skin.htpt/music/playHTPT.mp3)')
				'''---------------------------'''
				containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
				count = 0
				while count < 10 and containerfolderpath != path and not xbmc.abortRequested:
					'''------------------------------
					---containerfolderpath-----------
					------------------------------'''
					xbmc.sleep(100)
					count += 1
					containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
					xbmc.sleep(100)
					'''---------------------------'''
				containernumitems = xbmc.getInfoLabel('Container.NumItems')
				try: containernumitemsN = int(containernumitems)
				except: containernumitemsN = 0
				if device == "0": externalusb('run')
					
				if containernumitemsN < 2:
					containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
					count = 0
					while count < 10 and containerfolderpath == path and not xbmc.abortRequested:
						'''------------------------------
						---containerfolderpath-----------
						------------------------------'''
						xbmc.sleep(500)
						count += 1
						containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
						if count == 1: notification(addonString(120) % (name), addonString(121), "", 1000)
						elif count == 2: notification(addonString(120) % (name), addonString(121) + ".", "", 1000)
						elif count == 3: notification(addonString(120) % (name), addonString(121) + "..", "", 1000)
						elif count == 4: notification(addonString(120) % (name), addonString(121) + "...", "", 1000)
						if count == 5:
							HelpButton_Video_Pic(name, path2)
							
							
						xbmc.sleep(500)
						'''---------------------------'''
			if printpoint != "":
				if "9" in printpoint: dialogok('[COLOR=Yellow]' + addonString(138) + '[/COLOR]', addonString(139), addonString(128), "")
			if admin: print printfirst + "picturesbutton/videosbutton_LV" + printpoint + space2 + "containernumitems" + space2 + containernumitems + "id10str" + space2 + id10str

		elif favouritesbutton:
			if admin: xbmc.executebuiltin('Notification(Admin,favouritesbutton,1000)')
			xbmc.executebuiltin('ActivateWindow(134)')
			'''---------------------------'''
		elif settingsbutton:
			if admin: xbmc.executebuiltin('Notification(Admin,settingsbutton,1000)')
			if admin or admin2: xbmc.executebuiltin('ActivateWindow(1120)')
			else: xbmc.executebuiltin('ActivateWindow(Settings.xml)')
			'''---------------------------'''
		elif widgettogglebutton:
			if admin: xbmc.executebuiltin('Notification(Admin,widgettogglebutton,1000)')
			if xbmc.getCondVisibility('Control.IsVisible(311)'):
				xbmc.executebuiltin('Skin.ToggleSetting(MoviesShelfWL)')
				xbmc.executebuiltin('ActivateWindow(Videos,MovieTitles)')
				xbmc.sleep(100)
				xbmc.executebuiltin('ReplaceWindow(0)')
				xbmc.executebuiltin('Control.SetFocus(9090)')
				'''---------------------------'''
			if xbmc.getCondVisibility('Control.IsVisible(312)'):
				xbmc.executebuiltin('Skin.ToggleSetting(TVShelf_Watchlist)')
				xbmc.executebuiltin('ActivateWindow(VideoLibrary,TVShowTitles)')
				xbmc.sleep(100)
				xbmc.executebuiltin('ReplaceWindow(0)')
				xbmc.executebuiltin('Control.SetFocus(9090)')
				'''---------------------------'''
		elif htptchannelbutton:
			#xbmc.executebuiltin('RunScript(script.toolbox,info=textviewer,header='+ message1 +',text='+ message2 +')')
			xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.youtube/channel/UCcYT8oPT83Yuw4_GUZ3mMFg/)')
			
			if not systemplatformwindows: log = open('/storage/.kodi/addons/skin.htpt/changelog.txt', 'r')
			elif systemplatformwindows: log = open('Z:\\addons\\skin.htpt\\changelog.txt', 'r')
			message = log.read()
			log.close()
			diaogtextviewer('[COLOR=Yellow]' + htptskinversion + '[/COLOR]' + addonString(19) + "-", message)
			#w = TextViewer_Dialog('DialogTextViewer.xml', "", header=header, text=message2)
			#w.doModal()
			'''---------------------------'''
		elif test2button:
			'''------------------------------
			---test-2-button-----------------
			------------------------------'''
			#getsetting_refresh          = xbmcaddon.Addon('script.htpt.refresh').getSetting
			#Current_Name = getsetting_refresh('Current_Name')
			#az = Current_Name[-6:]
			'''---------------------------'''
			print printfirst + space + "test2button" + space2 + az
			'''---------------------------'''
		if hasinternet:
			'''------------------------------
			---Require-Internet--------------
			------------------------------'''
			#if admin: print printfirst + space + "homebuttons internet" + space3
			if israeltvbutton:
				if systemhasaddon_sdarottv:
					if admin and not admin2:
						if not systemplatformwindows: bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.video.sdarot.tv/sdarot-cookiejar.txt',"plugin.video.sdarot.tv - cookie")
						notification("DELETING COOKIE","","",1000)
						xbmc.sleep(1000)
					else:
						addonsettings('SDAROT TV', 'plugin.video.sdarot.tv', 'Account2_Active', 'Account2_Period', 'username','user_password', "", "", "", "")
						addonsettings2('plugin.video.sdarot.tv','DEBUG',"false",'cache',"24",'domain',"http://www.sdarot.wf",'',"",'',"")
				if admin: xbmc.executebuiltin('Notification(Admin,israeltvbutton,1000)')
				listitempath = xbmc.getInfoLabel('ListItem.Path')
				israeltvrootpath = 'plugin://plugin.video.sdarot.tv/'
				'''1try'''
				xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.sdarot.tv/?mode=2&module=http%3a%2f%2fwww.sdarot.wf%2fseries%2fgenre%2f20%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99&name=%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99&url=all-heb,return)')
				xbmc.sleep(200)
				'''2'''	
				if systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow'):
					'''------------------------------
					---ISRAEL-TV-PATH-CHANGE---------
					------------------------------'''
					count = 0
					while count < 10 and systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow') and not xbmc.abortRequested:
						xbmc.sleep(40)
						systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow')
						count += 1
						if count == 10:
							xbmc.executebuiltin('RunAddon(plugin.video.sdarot.tv)')
							notification(addonString(92),addonString(119),"",2000)
							xbmc.sleep(1000)
					
				'''------------------------------
				---ISRAEL-TV-TRY-----------------
				------------------------------'''
				count = 0
				containernumitems = xbmc.getInfoLabel('Container.NumItems')

				while count < 40 and containernumitems == "0" and not xbmc.abortRequested:
					xbmc.sleep(40)
					containernumitems = xbmc.getInfoLabel('Container.NumItems')
					count += 1
					if count == 40:
						notification('[COLOR=Red]' + addonString(90) + '[/COLOR]',addonString(91),"",4000)
						xbmc.executebuiltin('Action(Close)')
					
			elif goprobutton:
				if admin: xbmc.executebuiltin('Notification(Admin,goprobutton,1000)')
				#xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.youtube/?folder=true&login=false&path=%2froot%2fsearch&store=searches;,return)')
				if systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow'): xbmc.executebuiltin('RunAddon(plugin.video.GoProCamera)')
			elif youtubebutton:
				if admin: xbmc.executebuiltin('Notification(Admin,youtubebutton,1000)')
				xbmc.executebuiltin('RunAddon(plugin.video.youtube)')
				xbmc.sleep(500)
				containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
				count = 0
				while count < 10 and not "plugin://plugin.video.youtube" in containerfolderpath and not xbmc.abortRequested:
					xbmc.sleep(100)
					count += 1
					containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
					xbmc.sleep(100)
				if "plugin://plugin.video.youtube" in containerfolderpath:
					xbmc.executebuiltin('Action(PageUp)')
					xbmc.executebuiltin('Action(Down)')							
			if moviesebutton or tvshowsebutton or custom1132W:
				if admin: xbmc.executebuiltin('Notification(Admin,moviesebutton/tvshowsebutton,1000)')
				if moviesebutton or custom1132W:
					'''------------------------------
					---MOVIES-SEARCH/ADD-------------
					------------------------------'''
					if moviesep:
						'''------------------------------
						---PLUS--------------------------
						------------------------------'''
						if not custom1132W:
							if admin: notification("test2","","",2000)
							xbmc.executebuiltin('ActivateWindow(1132)')
						else:
							controlhasfocus698 = findin_controlhasfocus("9000","698",20,"","Action(close)")
							controlhasfocus699 = findin_controlhasfocus("9000","699",20,"","Action(close)")
							if controlhasfocus698: xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=root_movies,return)')
							elif controlhasfocus699: xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.pulsar,return)')
							if admin and controlhasfocus699: notification("test","","",2000)
						
					else:
						xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=root_movies,return)') #xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=movies_featured,return)') #xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=root_movies,return)') #xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=movies_popular)')
						'''---------------------------'''
				elif tvshowsebutton:
					xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=root_shows,return)')
				
				if systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow'):
					'''------------------------------
					---GENESIS-PATH-CHANGE-----------
					------------------------------'''
					count = 0
					while count < 10 and systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow') and not xbmc.abortRequested:
						xbmc.sleep(40)
						systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow')
						count += 1
						if count == 10:
							if not autoviewoff: xbmc.executebuiltin('Skin.ToggleSetting(AutoViewoff)')
							xbmc.executebuiltin('RunAddon(plugin.video.genesis)')
							xbmc.sleep(1000)
							containerfolderpath = xbmc.getCondVisibility('StringCompare(Container.FolderPath,plugin://plugin.video.genesis/)')
							if not containerfolderpath:
								xbmc.executebuiltin('Action(PageUp)')
								xbmc.executebuiltin('Action(PageUp)')
								xbmc.executebuiltin('Action(Select)')
								xbmc.sleep(800)
								containerfolderpath = xbmc.getCondVisibility('StringCompare(Container.FolderPath,plugin://plugin.video.genesis/)')
								#xbmc.sleep(1000)
							if containerfolderpath:
								xbmc.executebuiltin('Action(PageUp)')
								xbmc.executebuiltin('Action(Down)')
								if tvshowsebutton: xbmc.executebuiltin('Action(Down)')
								xbmc.executebuiltin('Action(Select)')
									
				if systemcurrentwindow != xbmc.getInfoLabel('System.CurrentWindow'):
					'''------------------------------
					---GENESIS-OK!-------------------
					------------------------------'''
					count = 0
					containernumitems = xbmc.getInfoLabel('Container.NumItems')
					
					while count < 40 and (containernumitems == "0" or containernumitems == "") and not xbmc.abortRequested:
						xbmc.sleep(40)
						containernumitems = xbmc.getInfoLabel('Container.NumItems')
						count += 1
					#if admin: notification("testtttt-",containernumitems,"",3000)
					rootmovies = 'plugin://plugin.video.genesis/?action=root_movies'
					roottv = 'plugin://plugin.video.genesis/?action=root_shows'
					containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
					if containerfolderpath == rootmovies or containerfolderpath == roottv:
						systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
						if containerfolderpath == rootmovies:
							value2 = str342
							xbmc.executebuiltin('Action(PageUp)')
							xbmc.executebuiltin('Action(PageUp)')
							if moviesestartup == "0": value = "" #root
							elif moviesestartup == "1": value = addonString_genesis(30527).encode('utf-8') #Most Popular
							elif moviesestartup == "2": value = addonString_genesis(30531).encode('utf-8') #Latest HD Movies
							elif moviesestartup == "3": value = addonString_genesis(30535).encode('utf-8') #Search
							elif moviesestartup == "4": value = addonString_genesis(30541).encode('utf-8') #Genres
							else: value = ""
							if value != "": value = "[" + value + "]"
							#if admin: notification("value: " + value,"","",1000)
							'''---------------------------'''
							count = 0
							while count < 17 and containerfolderpath == rootmovies and value != "" and not xbmc.abortRequested:
								if not xbmc.Player().isPlayingVideo():
									if moviesestartup == "3": systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Up)','')
									elif moviesestartup == "2": systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Up)','Action(Select)')
								else:
									if moviesestartup == "3": systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Down)','')
									else: systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Down)','Action(Select)')
								
								if systemcurrentcontrol == value: count = 40
								containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
								count += 1
								'''---------------------------'''
							
						elif containerfolderpath == roottv:
							value2 = str20343 #str20343.decode('utf-8').encode('utf-8')
							xbmc.executebuiltin('Action(PageUp)')
							xbmc.executebuiltin('Action(PageUp)')
							if tvshowsestartup == "0": value = "" #root
							elif tvshowsestartup == "1": value = addonString_genesis(30527).encode('utf-8') #Most Popular
							elif tvshowsestartup == "2": value = addonString_genesis(30544).encode('utf-8') #Returning TV Shows
							elif tvshowsestartup == "3": value = addonString_genesis(30535).encode('utf-8') #Search
							elif tvshowsestartup == "4": value = addonString_genesis(30541).encode('utf-8') #Genres
							else: value = ""
							if value != "": value = "[" + value + "]"
							'''---------------------------'''
							count = 0
							while count < 17 and containerfolderpath == roottv and value != "" and not xbmc.abortRequested:
								if tvshowsestartup == "3" and not xbmc.Player().isPlayingVideo(): systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Up)','')
								elif tvshowsestartup == "3": systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Down)','')
								else: systemcurrentcontrol = findin_systemcurrentcontrol("0",value,40,'Action(Down)','Action(Select)')
								
								if systemcurrentcontrol == value: count = 40
								containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
								count += 1
								'''---------------------------'''
						
						if value != "":
							'''------------------------------
							---STARTUP-WINDOW-NOTIFICATION---
							------------------------------'''
							xbmc.sleep(3000)
							containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
							if containerfolderpath == rootmovies or containerfolderpath == roottv:
								if moviesestartup != "3" and tvshowsestartup != "3": notification('[COLOR=Yellow]' + value.decode('utf-8') + '[/COLOR]' + str512 + space2, addonString(151), "", 4000)
							elif moviesestartup == "3" or tvshowsestartup == "3": notification('[COLOR=Yellow]' + value.decode('utf-8') + '[/COLOR]' + str512 + space2, addonString(151), "", 4000)
					elif admin: notification("containerfolderpath_Error","","",1000)
			if weatherbutton:
				if admin: xbmc.executebuiltin('Notification(Admin,weatherbutton,1000)')
				xbmc.executebuiltin('ActivateWindow(MyWeather)')
				xbmc.sleep(200)
				xbmc.executebuiltin('Weather.Refresh')
			if trailers2button:
				if admin: xbmc.executebuiltin('Notification(Admin,trailers2button,1000)')
				xbmc.executebuiltin('RunAddon(screensaver.randomtrailers)')
			if quizbutton:
				if admin: xbmc.executebuiltin('Notification(Admin,quizbutton,1000)')
				#watchedmovies = xbmc.getInfoLabel('Window(Home).Property(Movies.Watched)')
				#watchedtvshows = xbmc.getInfoLabel('Window(Home).Property(TVShows.Watched,)')
				#xbmc.executebuiltin('Notification('+ watchedmovies +','+ watchedtvshows +',1000)')
				#xbmc.sleep(1000)
				xbmc.executebuiltin('RunAddon(script.moviequiz)')
				'''---------------------------'''				
			if musicbutton or custom1124W:
				'''------------------------------
				---MUSIC-BUTTON------------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,musicbutton,1000)')
				if not custom1124W: xbmc.executebuiltin('ActivateWindow(1124,return)')
				else:
					if admin: xbmc.executebuiltin('Notification(Admin,musicbutton2,1000)')
					if button101:
						'''------------------------------
						---LOCAL-MUSIC-------------------
						------------------------------'''
						if not libraryhascontentmusic: xbmc.executebuiltin('ActivateWindow(501,root),return)')
						elif musiclinkstr != "": xbmc.executebuiltin('ActivateWindow(502,'+ musiclinkstr +',return)')
						else: xbmc.executebuiltin('ActivateWindow(502,return)')
						'''---------------------------'''
					elif button102:
						'''------------------------------
						---ISRAELI-MUSIC-----------------
						------------------------------'''
						if admin: xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.htpt.music/?limit&mode=listItunesVideos&type=browse&url=19),return)')
						notification_common("10")
						'''---------------------------'''
					else:
						pass
						
			if kidsbutton:
				'''------------------------------
				---KIDS-BUTTON-------------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,kidsbutton,1000)')
				#kidssettings("run")
				xbmc.sleep(200)
				#xbmc.executebuiltin('RunAddon(plugin.video.KIDSIL)')
				if systemhasaddon_htptkids: xbmc.executebuiltin('RunAddon(plugin.video.htpt.kids)')
				else:
					xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.htpt.kids,return)')
					if admin: notification("Admin","Addon is missing!","",1000)
				'''---------------------------'''
			if mov3dsbutton:
				'''------------------------------
				---3D-MOVIES-BUTTON--------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,mov3dsbutton,1000)')
				#xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.movie25/?fanart;genre;iconimage=https%3a%2f%2fraw.github.com%2fmash2k3%2fMashupArtwork%2fmaster%2fskins%2fvector%2f3d.png;mode=223;name=3D%20Movies;plot;url=3D,return)')
				notification_common("10")
				'''---------------------------'''
			if internetbutton:
				'''------------------------------
				---INTERNET-BUTTON---------------
				------------------------------'''
				Button_Name = str443
				if id10str == "A" or id10str == "B" or id10str == "ADMIN":
					if dialogyesno(str79215,str79216):
						#xbmc.executebuiltin('Notification('+ internetbuttonn1 +','+ internetbuttonn2 +',2000)')
						notification(str79217, str79218, "", 4000)
						settingschange('SystemSettings','input.enablemouse','1','no',xbmc.getInfoLabel('$LOCALIZE[14094]'),xbmc.getInfoLabel('$LOCALIZE[21369]'))
						xbmc.sleep(1000)
						if not systemplatformwindows: xbmc.executebuiltin('RunAddon(browser.chromium-browser)')
						'''---------------------------'''
					else:
						settingschange('SystemSettings','input.enablemouse','0','no',xbmc.getInfoLabel('$LOCALIZE[14094]'),xbmc.getInfoLabel('$LOCALIZE[21369]'))
						'''---------------------------'''
				else:
					'''------------------------------
					---UNSUPPORT-DEVICE--------------
					------------------------------'''
					dialogok('$LOCALIZE[79501]',addonString(124) % (id10str), addonString(145) % (Button_Name) ,addonString(128))
					'''---------------------------'''
			if gadgetbutton:
				'''------------------------------
				---GADGET-BUTTON-----------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,gadgetbutton,1000)')
				#if not systemplatformwindows: xbmc.executebuiltin('RunAddon(plugin.video.engadget)')
				notification_common("10")
				'''---------------------------'''
			if karaokebutton:
				'''------------------------------
				---KARAOKE-BUTTON----------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,karaokebutton,1000)')
				xbmc.executebuiltin('RunAddon(plugin.video.MikeysKaraoke)')
				'''---------------------------'''
			if gametrailersbutton:
				'''------------------------------
				---GAMERS-BUTTON-----------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,gametrailersbutton,1000)')
				xbmc.executebuiltin('RunAddon(plugin.video.g4tv)')
				'''---------------------------'''
			elif guitarbutton:
				'''------------------------------
				---GAMERS-BUTTON-----------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,guitarbutton,1000)')
				xbmc.executebuiltin('RunAddon(plugin.video.ultimateguitar)')
				'''---------------------------'''
			elif adultbutton2:
				'''------------------------------
				---ADULT-MOVIE-BUTTON------------
				------------------------------'''
				adultbutton2_(admin)
				'''---------------------------'''
			if livetvbutton or livetvbutton2:
				'''------------------------------
				---LIVE-TV-BUTTON----------------
				------------------------------'''
				if livetvbutton:
					if admin: xbmc.executebuiltin('Notification(Admin,livetvbutton,1000)')
					xbmc.executebuiltin('RunAddon(plugin.video.israelive)')
					xbmc.sleep(1500)
					containernumitems = xbmc.getInfoLabel('Container.NumItems')
					containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
					systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
					#if "displayname=10000" in containerfolderpath: xbmc.executebuiltin('Action(Back)')
					print printfirst + "livetvbutton " + containernumitems + space + systemcurrentcontrol
					#xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.israelive/?description&displayname=DTT%2b&iconimage=http%3a%2f%2fftp5.bizportal.co.il%2fweb%2fgiflib%2fnews%2fidan_plus_gay.jpg&mode=2&name=%5bCOLOR%20blue%5d%5bB%5d%5bDTT%2b%5d%5b%2fB%5d%5b%2fCOLOR%5d&url,return)')
					#xbmc.sleep(700)
					#containernumitems = xbmc.getInfoLabel('Container.NumItems')
					#if systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow') or containernumitems == '0':
						#xbmc.executebuiltin('RunAddon(plugin.video.israelive)')
						#xbmc.sleep(700)
						#if xbmc.getInfoLabel('Container.FolderPath') == 'plugin://plugin.video.israelive/':
						#	xbmc.executebuiltin('Action(PageUp)')
							#xbmc.executebuiltin('Action(Down)')
							#xbmc.executebuiltin('Action(Down)')
							#xbmc.executebuiltin('Action(Down)')
							#xbmc.executebuiltin('Action(Select)')
				elif livetvbutton2:
					xbmc.executebuiltin('ActivateWindow(TVChannels)')
					xbmc.sleep(1000)
					mypvrchannels = xbmc.getCondVisibility('Window.IsVisible(MyPVRChannels.xml)')
					count = 0
					while count < 10 and not mypvrchannels and not xbmc.abortRequested:
						xbmc.sleep(100)
						count += 1
						mypvrchannels = xbmc.getCondVisibility('Window.IsVisible(MyPVRChannels.xml)')
						xbmc.sleep(100)
					if mypvrchannels:
						containerfoldername = xbmc.getInfoLabel('Container.FolderName')
						containernumitems = xbmc.getInfoLabel('Container.NumItems')
						if containerfoldername != str19287: dialogok('[COLOR=Yellow]' + '$LOCALIZE[19051]' + '[/COLOR]', addonString(160) % (containernumitems), addonString(161), "")
					else:
						xbmc.executebuiltin('RunScript(plugin.video.israelive,,mode=32)') #Update IPTVSimple settings
						xbmc.executebuiltin('RunScript(plugin.video.israelive,,mode=34)') #REFRESH ALL SETTINGS
						
						xbmc.executebuiltin('RunAddon(plugin.video.israelive)')
			if radiobutton:
				'''------------------------------
				---RADIO-BUTTON------------------
				------------------------------'''
				print printfirst + "radiobutton"
				xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.israelive/?categoryid=9999&description&displayname=10000&iconimage=http%3a%2f%2fmdmorrope.gob.pe%2fportalweb%2fimagenes%2fradioss.png&mode=2&name=%5bCOLOR%20chartreuse%5d%5bB%5d%5b%d7%a8%d7%93%d7%99%d7%95%5d%5b%2fB%5d%5b%2fCOLOR%5d&url,return)')
				xbmc.sleep(700)
				containernumitems = xbmc.getInfoLabel('Container.NumItems')
				if systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow') or containernumitems == '0':
					xbmc.executebuiltin('RunAddon(plugin.video.israelive)')
					xbmc.sleep(700)
					if xbmc.getInfoLabel('Container.FolderPath') == 'plugin://plugin.video.israelive/':
						xbmc.executebuiltin('Action(PageUp)')
						xbmc.executebuiltin('Action(Down)')
						xbmc.executebuiltin('Action(Down)')
						xbmc.executebuiltin('Action(Select)')
		elif vhomecon1:
			xbmc.executebuiltin('Notification($LOCALIZE[79512],$LOCALIZE[21451],5000)')
			if admin: print printfirst + space + "homebuttons internet Error" + space3 + "systeminternetstate" + space2 + systeminternetstate + space + "networkipaddress" + space2 +  networkipaddress
			'''---------------------------'''

def helpbuttons(admin):
	if custom1170W or loginscreenW:
		'''------------------------------
		---HELP-/-LOGINSCREEN-WINDOWS----
		------------------------------'''
		xbmc.sleep(40)
		#if admin: xbmc.executebuiltin('Notification(Admin,custom1170,1000)')
		#sgbserviceszeroconf = xbmc.getCondVisibility('System.GetBool(services.zeroconf)')
		from variables import sgbserviceszeroconf, sgbservicesairplay
		if airplaybutton:
			'''------------------------------
			---AIRPLAY-BUTTON----------------
			------------------------------'''
			printpoint = ""
			xbmc.executebuiltin('ActivateWindow(servicesettings)')
			settingscategoryW = xbmc.getCondVisibility('Window.IsVisible(SettingsCategory.xml)')
			count = 0
			while count < 10 and not settingscategoryW and not xbmc.abortRequested:
				if count == 0: printpoint = printpoint + "0"
				xbmc.sleep(40)
				settingscategoryW = xbmc.getCondVisibility('Window.IsVisible(SettingsCategory.xml)')
				count += 1
			settingslevelset("2")
			'''---------------------------'''
			if not sgbserviceszeroconf:
				printpoint = printpoint + "1"
				count = 0
				while count < 5 and systemcurrentcontrol != str1259 and not xbmc.abortRequested:
					'''Zeroconf'''
					if count == 0: printpoint = printpoint + "2"
					systemcurrentcontrol = findin_systemcurrentcontrol("0",str1259,40,'Action(Left)','Action(Down)')
					count += 1
					'''---------------------------'''
				count = 0
				while count < 5 and not str1260 in systemcurrentcontrol and not xbmc.abortRequested:
					'''Announce these services to other systems via Zeroconf'''
					if count == 0:
						printpoint = printpoint + "3"
						systemcurrentcontrol = findin_systemcurrentcontrol("1",str1260,40,'','Action(Select)')
					else: systemcurrentcontrol = findin_systemcurrentcontrol("1",str1260,40,'Action(Down)','Action(Select)')
					count += 1
					'''---------------------------'''
				count = 0
				while count < 5 and systemcurrentcontrol != str1259 and not xbmc.abortRequested:
					'''Zeroconf'''
					if count == 0: printpoint = printpoint + "2"
					systemcurrentcontrol = findin_systemcurrentcontrol("0",str1259,40,'Action(Up)','Action(Right)')
					count += 1
					'''---------------------------'''
				sgbserviceszeroconf = xbmc.getCondVisibility('System.GetBool(services.zeroconf)')
				
			if sgbserviceszeroconf:
				printpoint = printpoint + "4"
				'''---------------------------'''
				systemcurrentcontrol = findin_systemcurrentcontrol("0",str1273,40,'Action(Left)','Action(Down)')
				count = 0
				while count < 5 and systemcurrentcontrol != str1273 and not xbmc.abortRequested:
					'''AirPlay'''
					if count == 0: printpoint = printpoint + "5"
					systemcurrentcontrol = findin_systemcurrentcontrol("0",str1273,40,'Action(Left)','Action(Down)')
					count += 1
					'''---------------------------'''
				
				systemcurrentcontrol = findin_systemcurrentcontrol("1",str1273,40,'Action(Down)','')
				count = 0
				while count < 5 and not str1273 in systemcurrentcontrol and not xbmc.abortRequested:
					'''if Allow to receive AirPlay content'''
					if count == 0: printpoint = printpoint + "6"
					systemcurrentcontrol = findin_systemcurrentcontrol("1",str1273,40,'Action(Down)','')
					count += 1
					'''---------------------------'''
				if count < 5:
					printpoint = printpoint + "8"
					systemcurrentcontrol = findin_systemcurrentcontrol("1",str1273,40,'','Action(Select)')
					xbmc.sleep(500)
					if sgbservicesairplay: systemcurrentcontrol = findin_systemcurrentcontrol("1",str1273,40,'','Action(Select)')
					'''---------------------------'''
				
				xbmc.executebuiltin('Action(Back)')
				xbmc.sleep(1000)
				xbmc.executebuiltin('Action(Down)')
				sgbservicesairplay = xbmc.getCondVisibility('System.GetBool(services.airplay)')
				sgbserviceszeroconf = xbmc.getCondVisibility('System.GetBool(services.zeroconf)')
				xbmc.sleep(500)
				if sgbserviceszeroconf and sgbservicesairplay:
					printpoint = printpoint + "7"
					notification_common("13")
					dialogok('[COLOR=Yellow]' + addonString(114) + '[/COLOR]', addonString(115), addonString(116), "")
					returned = dialogyesno(addonString(117), addonString(118))
					if returned != "ok":
						'''Extra Help with AirPlay'''
						dialogok('[COLOR=Yellow]' + addonString(140) + '[/COLOR]', addonString(141) + space2, addonString(142), "")
					#xbmc.executebuiltin('Notification($LOCALIZE[79063],$LOCALIZE[79064],5000)')
					
				elif not sgbserviceszeroconf: notification('$LOCALIZE[257]','$LOCALIZE[34302]',"",4000)
				else:
					printpoint = printpoint + "9"
					#if not systemplatformwindows: os.system('sh /storage/.kodi/addons/skin.htpt/specials/scripts/resetnetwork.sh')
			
			'''------------------------------
			---PRINT-END---------------------
			------------------------------'''
			if admin: print printfirst + "airplaybutton_LV" + printpoint
			'''---------------------------'''
			
		if resetnetworkbutton:
			'''------------------------------
			---RESET-NETWORK-BUTTON----------
			------------------------------'''
			resetnetwork('run')
		'''buttons which require internet'''
		if hasinternet:
			if messagebutton:
				notification_common("10")
				if systemplatformwindows:
					xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.programm.htptmail/mailbox/INBOX/,return)')
					'''---------------------------'''
			if debugbutton:
				if not systemhasaddon_htptdebug: xbmc.executebuiltin('ActivateWindow(10001,plugin://script.htpt.debug/)')
				else: xbmc.executebuiltin('RunAddon(script.htpt.debug)')
				'''---------------------------'''
		elif vhomecon1: xbmc.executebuiltin('Notification($LOCALIZE[79512],$LOCALIZE[21451],5000)')		
			
def skinbuttons(admin):
	if skinsettingsW:
		if adultbutton:
			'''------------------------------
			---ADULT-GAMES-------------------
			------------------------------'''
			print printfirst + space + "adultbutton"
			xbmc.executebuiltin('Skin.ToggleSetting(Adult)')
			if not systemplatformwindows:
				xbmc.sleep(1000)
				os.system('sh /storage/.kodi/addons/script.htpt.emu/specials/scripts/copyemu.sh')
			if not adult:
				'''------------------------------
				---ADULT-BUTTON-OFF->ON----------
				------------------------------'''
				returned = dialogyesno(addonString(97).encode('utf-8'),addonString(98).encode('utf-8'))
				if returned == "ok":
					'''------------------------------
					---ADULT-ALWAYS-ON---------------
					------------------------------'''
					setSkinSetting("1",'Adult2',"true")
					'''---------------------------'''
				else:
					'''------------------------------
					---ADULT-ALWAYS-OFF--------------
					------------------------------'''
					setSkinSetting("1",'Adult2',"false")
					'''---------------------------'''
				setSkinSetting("1",'Admin2',"false")
				'''---------------------------'''
				list0 = xbmc.getInfoLabel('$LOCALIZE[75003]')
				list1 = xbmc.getInfoLabel('$LOCALIZE[15016]')
				returned, value = dialogselect(addonString(99).encode('utf-8'),[list0, list1],0)
				returned = int(returned)
				if returned == -1:
					dialogok(addonString(95).encode('utf-8'),addonString(96).encode('utf-8'),"","")
				else:
					xbmc.executebuiltin('ActivateWindow(Home.xml)')
					xbmc.sleep(200)
					'''---------------------------'''
					if returned == 0: adultbutton2_(admin)
					elif returned == 1:
						gamesbutton_(admin)
						xbmc.sleep(1000)
						xbmc.executebuiltin('Action(PageDown)')
			else: setSkinSetting("1",'Adult2',"false")
			
		elif trakttvbutton and systemhasaddon_genesis:
			'''------------------------------
			---TRAKT-TV-BUTTON---------------
			------------------------------'''
			account_button('TRAKT TV','plugin.video.genesis', 'trakt_user', 'trakt_password', trakt_user, trakt_password, 'Account10_Active', '', '', Account10_Active, "N/A", "N/A", "")
			'''---------------------------'''
		elif sdarottvbutton and systemhasaddon_sdarottv:
			'''------------------------------
			---SDAROT-TV-BUTTON--------------
			------------------------------'''
			account_button('SDAROT TV','plugin.video.sdarot.tv', 'username', 'user_password', sdarottv_user, sdarottv_password, 'Account2_Active', 'Account2_Period', 'Account2_EndDate', Account2_Active, Account2_Period, Account2_EndDate, "")
			'''---------------------------'''
		elif noobroombutton and systemhasaddon_genesis:
			'''------------------------------
			---NOOBROOM-BUTTON---------------
			------------------------------'''
			notification_common("10")
			#account_button('NOOBROOM','plugin.video.genesis', 'noobroom_mail', 'noobroom_password', noobroom_mail, noobroom_password, 'Account5_Active', 'Account5_Period', 'Account5_EndDate', Account5_Active, Account5_Period, Account5_EndDate, "")
			'''---------------------------'''
		elif premiumizebutton and systemhasaddon_genesis:
			'''------------------------------
			---PREMIUMIZE-BUTTON-------------
			------------------------------'''
			notification_common("10")
			#account_button('PREMIUMIZE','plugin.video.genesis', 'premiumize_user', 'premiumize_password', premiumize_user, premiumize_password, 'Account4_Active', 'Account4_Period', 'Account4_EndDate', Account4_Active, Account4_Period, Account4_EndDate, "")
			'''---------------------------'''
		elif movreelbutton and systemhasaddon_genesis:
			'''------------------------------
			---MOVREEL-BUTTON----------------
			------------------------------'''
			notification_common("10")
			#account_button('MOVREEL','plugin.video.genesis', 'movreel_user', 'movreel_password', movreel_user, movreel_password, 'Account3_Active', 'Account3_Period', 'Account3_EndDate', Account3_Active, Account3_Period, Account3_EndDate, "")
			'''---------------------------'''
		elif realdebridbutton and systemhasaddon_genesis:
			'''------------------------------
			---REALDEBRID-BUTTON-------------
			------------------------------'''
			account_button('REALDEBRID','plugin.video.genesis', 'realdedrid_user', 'realdedrid_password', realdedrid_user, realdedrid_password, 'Account1_Active', 'Account1_Period', 'Account1_EndDate', Account1_Active, Account1_Period, Account1_EndDate, "")
			'''---------------------------'''
		
		elif paymentmethodbutton:
			'''------------------------------
			---PAYMENT-TERMS-----------------
			------------------------------'''
			list0 = xbmc.getInfoLabel('$LOCALIZE[70014]')
			list1 = xbmc.getInfoLabel('$LOCALIZE[70015]')
			list2 = xbmc.getInfoLabel('$LOCALIZE[70016]')
			returned, value = dialogselect('$LOCALIZE[70012]',[list0, list1, list2],0)
			returned = int(returned)
			returnedS = str(returned)
			returned2 = "list" + returnedS
			if returned == -1:
				dialogok('$LOCALIZE[31406]',"","","")
			else:
				if returned == 0: setSkinSetting("0",'ID6',list0)
				elif returned == 1: setSkinSetting("0",'ID6',list1)
				elif returned == 2: setSkinSetting("0",'ID6',list2)
				'''---------------------------'''
			
		elif formatbutton:
			mac5str = xbmc.getInfoLabel('Skin.String(MAC5)')
			returned = dialogyesno('FORMAT YOUR DEVICE TOOL','CHOOSE YES TO PROCEED')
			if returned == 'ok':
				'''asking for a password'''
				xbmc.executebuiltin('Skin.SetNumeric(MAC5)')
				xbmc.sleep(3000)
				dialognumericW = xbmc.getCondVisibility('Window.IsVisible(DialogNumeric.xml)')
				while dialognumericW and not xbmc.abortRequested:
					xbmc.sleep(500)
					dialognumericW = xbmc.getCondVisibility('Window.IsVisible(DialogNumeric.xml)')
					xbmc.sleep(1000)
				mac5str = xbmc.getInfoLabel('Skin.String(MAC5)')
				xbmc.sleep(200)
				if mac5str == var70000 and mac5str != "":
					xbmc.executebuiltin('Notification(FORMAT WILL START IN 10 MIN!,REBOOT ASAP FOR CANCELING THE PROCESS!,10000,icons/shield.png)')
				if mac5str != var70000 and mac5str != "":
					xbmc.executebuiltin('Notification(WRONG PASSWORD!!!,BE SURE YOU KNOW WHAT YOU ARE DOING!!!,10000,icons/shield.png)')
					if admin: xbmc.executebuiltin('Skin.ToggleSetting(Admin)')
					xbmc.executebuiltin('Skin.SetString(ID9,FTOOL)')
					xbmc.executebuiltin('ReplaceWindow(Startup.xml)')
			else:
				if mac5str: xbmc.executebuiltin('Skin.SetString(MAC5,)')
				xbmc.executebuiltin('Notification(FORMAT CANCELED,...,2000,icons/shield.png)')
			if mac5str != var70000: print printfirst + "formatbutton" + space2 + mac5str + " ( " + returned + " ) "
			elif mac5str == var70000: print printfirst + "formatbutton" + space2 + "*******" + " ( " + returned + " ) "
		#if fixip:
		#if id60button:
				
			
		elif userdataresetbutton:
			dialogok('USERDATA DELETED!','[CR]' + 'THERE IS NO WAY BACK NOW...',"","")
			if not systemplatformwindows:
				bash('rm -rf /storage/.kodi/userdata/addon_data/script.htpt.debug',"script.htpt.debug")
				bash('rm -rf /storage/.kodi/userdata/addon_data/script.htpt.homebuttons',"script.htpt.homebuttons")
				bash('rm -rf /storage/.kodi/userdata/addon_data/script.htpt.remote',"script.htpt.remote")
				bash('rm -rf /storage/.kodi/userdata/addon_data/script.htpt.fix',"service.htpt.fix")
				bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.video.genesis',"plugin.video.genesis")
				bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.program.advanced.launcher',"plugin.program.advanced.launcher")
				bash('rm -rf /storage/.kodi/userdata/addon_data/script.htpt.emu',"script.htpt.emu")
				#bash('rm -rf /storage/.kodi/userdata/addon_data/service.htpt',"service.htpt") '''CANT OVERWRITE THE SETTINGS.XML'''
				bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.video.htpt.kids',"plugin.video.htpt.kids")
			print printfirst + "userdataresetbutton"

def startup(validation):
	
	validation = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION)')
	if startup_aW and not validation:
		print printfirst + "startup (1)"
		xbmc.executebuiltin('ReplaceWindow(Home)')
		mac7('run',macaddress,maccon1,maccon2,maccon10,maccon11)
		externalusb('run')
		xbmc.executebuiltin('RunScript(service.skin.widgets)')
		xbmc.sleep(5000)
		xbmc.executebuiltin('RunScript(script.htpt.remote)')
		'''---------------------------'''
		setAutoSettings("0")
		setAutoSettings("1")
		#if not systemplatformwindows: settingschange('SystemSettings','input.enablemouse','0','no',xbmc.getInfoLabel('$LOCALIZE[14094]'),xbmc.getInfoLabel('$LOCALIZE[21369]'))
	
def stringtotime(dt_str, dt_func):
	'''WIP!!!'''
	from datetime import datetime
	import time
	#dt_str = '9/24/2010 5:03:29 PM'
	#dt_func = '%m/%d/%Y %I:%M:%S %p'
	#try:
	dt_obj = datetime.strptime(dt_str, dt_func)
	dt_objS = str(dt_obj)
	if dt_func == '%H':
		#time.struct_time(tm_year=1900, tm_mon=1, tm_mday=1, tm_hour=20, tm_min=0, tm_sec=0, tm_wday=0, tm_yday=1, tm_isdst=-1)
		find = dt_str
		found = find_string(dt_objS, find, "")
		'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "stringtotime" + space + "dt_objS" + space2 + dt_objS + space + "timenow3S" + space2 + timenow3S
	'''---------------------------'''
	
	return dt_obj

def find_string(findin, findwhat, findwhat2):
	findin = str(findin)
	findinL = len(findin)
	findinLS = str(findinL)
	findinLN = int(findinLS)
	findwhat = str(findwhat)
	findwhatL = len(findwhat)
	findwhatLS = str(findwhatL)
	findwhatLN = int(findwhatLS)
	findwhat2 = str(findwhat2)
	findwhat2L = len(findwhat2)
	findwhat2LS = str(findwhat2L)
	findwhat2LN = int(findwhat2LS)
	'''---------------------------'''
	findin_start = findin.find(findwhat, 0, findinL)
	findin_startS = str(findin_start)
	findin_startN = int(findin_startS) + findwhatLN
	findin_startS = str(findin_start)
	'''---------------------------'''
	if findwhat2 == "": findin_end = findin.find(findwhat2, findin_startN, findinL)
	else: findin_end = findin.find(findwhat2, findin_startN, findin_startN + findwhatLN)
	findin_endS = str(findin_end)
	findin_endN = int(findin_endS) + findwhat2LN
	'''---------------------------'''
	findin_startN = int(findin_startS) #SOME KIND OF BUG? BUT WORKING THIS WAY!
	found = findin[findin_startN:findin_endN]
	foundS = str(found)
	'''---------------------------'''
	try:
		foundF = float(foundS)
		found2 = round(foundF)
		found2S = str(found2)
		if ".0" in found2S: found2S = found2S.replace(".0","",1)
	except: pass
	
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "find_string" + space + "findin" + space2 + findin + space + "(" + findinLS + ")" + space + "findwhat" + space2 + findwhat + space + "(" + findwhatLS + ")" + space +  "findin_startS" + space2 + findin_startS + space + "findin_endS" + space2 + findin_endS + space + "foundS" + space2 + foundS + space
	'''---------------------------'''
	return foundS
	
def HelpButton_Video_Pic(name, path2):
	if id10str != "C" and id10str != "D" and id10str != "": device = "0"
	else: device = "1"
	usb1str = xbmc.getInfoLabel('Skin.String(USB1)')
	dialogok('[COLOR=Yellow]' + addonString(120) % (name) + '[/COLOR]', addonString(123) % (name) + addonString(133),"","")
	'''---------------------------'''
	if device == "0": dialogok('[COLOR=Yellow]' + addonString(124) % (id10str) + '[/COLOR]', addonString(125),addonString(126) % (name),"")
	elif device == "1": dialogok('[COLOR=Yellow]' + addonString(124) % (id10str) + '[/COLOR]', addonString(127),addonString(155) % (usb1str),"")
	'''---------------------------'''
	if device == "0":
		returned = dialogyesno(addonString(134) % (name),addonString(135) % (name, addonString(46)))
		if returned == "ok":
			header = space + "(" + addonString(46) + ")" + space + '[COLOR=Yellow]' + addonString(129) % (name) + '[/COLOR]'+ space
			message2 = addonString(132) % (name, path2, name) + addonString(128)
			w = TextViewer_Dialog('DialogTextViewer.xml', "", header=header, text=message2)
			w.doModal()
			
			header = space + "(" + addonString(46) + ")" + space + '[COLOR=Yellow]' + addonString(136) % (name) + '[/COLOR]' + space
			message2 = addonString(137) % ("\\\\" + "htpt", path2, name, name) + addonString(128)
			w = TextViewer_Dialog('DialogTextViewer.xml', "", header=header, text=message2)
			w.doModal()
			'''---------------------------'''
	
	elif device == "1":
		returned = dialogyesno(addonString(134) % (name),addonString(135) % (name, addonString(47)))
		if returned == "ok":
			header = space + "(" + addonString(47) + ")" + space + '[COLOR=Yellow]' + addonString(129) % (name) + '[/COLOR]' + space
			message2 = addonString(155) % (usb1str) + '[CR]' + addonString(156) % (path2) + '[CR]' + addonString(157) % (path2, name) + addonString(128)
			w = TextViewer_Dialog('DialogTextViewer.xml', "", header=header, text=message2)
			w.doModal()
			
			header = space + "(" + addonString(47) + ")" + space + '[COLOR=Yellow]' + addonString(136) % (name) + '[/COLOR]' + space
			message2 = addonString(137) % ("\\\\" + "htpt", str79498 + " -> " + usb1str + " -> " + path2 , name, name) + addonString(128)
			w = TextViewer_Dialog('DialogTextViewer.xml', "", header=header, text=message2)
			w.doModal()
			'''---------------------------'''
			
def topvideoinformation2(admin):
	'''------------------------------
	---Clear ListItem----------------
	------------------------------'''
	containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
	listitemtvshowtitlestr = xbmc.getInfoLabel('Skin.String(ListItemTVShowTitle)')
	'''---------------------------'''
	if not "videodb://tvshows" in containerfolderpath and not "library://video/tvshows" in containerfolderpath:
		setSkinSetting("0",'ListItemGenre',"")
		setSkinSetting("0",'ListItemDuration',"")
		setSkinSetting("0",'ListItemRating',"")
		setSkinSetting("0",'ListItemYear',"")
		setSkinSetting("0",'ListItemTVShowTitle',"")
		if listitemtvshowtitlestr: print printfirst + "topvideoinformation2" + space2 + "Clear ListItem"
		'''---------------------------'''
	
def settingschange(window,systemgetbool,falsetrue,force,string1,string2):
	'''systemgetbool'''
	systemgetbool2 = xbmc.getCondVisibility('System.GetBool('+ systemgetbool +')')
	systemgetbool2str = str(systemgetbool2)
	if systemgetbool2str != falsetrue or force == 'yes':
		if admin: xbmc.executebuiltin('Notification(Admin,settingschange '+ systemgetbool +' ('+ systemgetbool2str +'),10000)')
		xbmc.executebuiltin('ActivateWindow('+ window +')')
		'''Right'''
		systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
		if not string1 in systemcurrentcontrol:
			xbmc.executebuiltin('Action(Right)')
			xbmc.sleep(100)
			systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
			if not string1 in systemcurrentcontrol:
				xbmc.executebuiltin('Action(Right)')
				xbmc.sleep(100)
				systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
				if not string1 in systemcurrentcontrol:
					xbmc.executebuiltin('Action(Right)')
					xbmc.sleep(100)
					systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
					if not string1 in systemcurrentcontrol:
						xbmc.executebuiltin('Action(Right)')
						xbmc.sleep(100)
						systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
		xbmc.sleep(40)
		if string1 in systemcurrentcontrol: xbmc.executebuiltin('Action(Down)')
		
		'''Down'''
		xbmc.sleep(100)
		systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
		if not string2 in systemcurrentcontrol:
			xbmc.executebuiltin('Action(Down)')
			xbmc.sleep(100)
			systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
			if not string2 in systemcurrentcontrol:
				xbmc.executebuiltin('Action(Down)')
				xbmc.sleep(100)
				systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
				if not string2 in systemcurrentcontrol:
					xbmc.executebuiltin('Action(Down)')
					xbmc.sleep(100)
					systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
					if not string2 in systemcurrentcontrol:
						xbmc.executebuiltin('Action(Down)')
						xbmc.sleep(100)
						systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
		xbmc.sleep(40)
		
		'''Select'''
		systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
		if string2 in systemcurrentcontrol:
			xbmc.executebuiltin('Action(Select)')
			xbmc.sleep(100)
			if systemgetbool2 != falsetrue and force == 'yes': xbmc.executebuiltin('Action(Select)')
			systemgetbool2 = xbmc.getCondVisibility('System.GetBool('+ systemgetbool +')')
			if admin: xbmc.sleep(1000)
			if systemgetbool2 != falsetrue and force == 'yes' or force == 'no': xbmc.executebuiltin('Action(Back)')
			if not systemgetbool2: xbmc.executebuiltin('Notification('+ systemcurrentcontrol +',,5000)')

def settingslevelset(custom):
	'''custom: 1 = Basic, 2 = Standard, 3 = Advanced, 4 = Expert'''
	if custom == "1": custom = settingslevelstr1
	elif custom == "2": custom = settingslevelstr2
	elif custom == "3": custom = settingslevelstr3
	elif custom == "4": custom = settingslevelstr4
	else: sys.exit(1)
	'''---------------------------'''
	printpoint = ""
	settingslevel = xbmc.getInfoLabel('Skin.String(SettingsLevel)')
	'''---------------------------'''
	if settingslevel != custom:
		controlhasfocus = findin_controlhasfocus("0","20",40,'Control.SetFocus(20)','')
		count = 0
		while count < 5 and not controlhasfocus and not xbmc.abortRequested:
			if count == 0: printpoint = printpoint + "2"
			controlhasfocus = findin_controlhasfocus("0","20",40,'Control.SetFocus(20)','')
			count += 1
			'''---------------------------'''
		if controlhasfocus:
			printpoint = printpoint + "3"
			count = 0
			while count < 5 and settingslevel != custom and not xbmc.abortRequested:
				if count == 0: printpoint = printpoint + "5"
				count += 1
				systemcurrentcontrol = findin_systemcurrentcontrol("0",custom,10,'Action(Select)','Action(Down)')
				settingslevel = xbmc.getInfoLabel('Skin.String(SettingsLevel)')
				'''---------------------------'''
		else: printpoint = printpoint + "9"
	else:
		printpoint = printpoint + "8"
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "settingslevelset_LV" + printpoint
	'''---------------------------'''
	
def adultbutton2_(admin):
	if systemhasaddon_videodevil: xbmc.executebuiltin('RunAddon(plugin.video.videodevil)')
	else: xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.videodevil)')
	'''---------------------------'''
def gamesbutton_(admin):
	Button_Name = str15016
	if admin: notification("Button_Name" + space2 + Button_Name,"","",1000)
	if not systemhasaddon_htptemu: xbmc.executebuiltin('ActivateWindow(10001,plugin://script.htpt.emu/)')
	if not systemplatformwindows: os.system('sh /storage/.kodi/addons/script.htpt.emu/specials/scripts/launcher.sh')
	xbmc.executebuiltin('RunAddon(plugin.program.advanced.launcher)')
	xbmc.sleep(2000)
	systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
	containernumitems = xbmc.getInfoLabel('Container.NumItems')
	'''---------------------------'''
	if (systemcurrentcontrol == "[..]" or systemcurrentcontrol == "[Default]") and (containernumitems == "0" or containernumitems == "1"):
		'''------------------------------
		---FIX-CONFIGURATION-FILE--------
		------------------------------'''
		print printfirst + space + "gamesbutton" + space + "Possible Error in file: launcher.xml"
		dialogok(addonString(130).encode('utf-8'),addonString(131).encode('utf-8'),"","")
		if not systemplatformwindows: os.system('sh /storage/.kodi/addons/script.htpt.emu/specials/scripts/copyemu.sh')
		xbmc.executebuiltin('ActivateWindow(Home.xml)')
		xbmc.sleep(2000)
		xbmc.executebuiltin('RunAddon(plugin.program.advanced.launcher)')
		'''---------------------------'''
	if id10str == "C" or id10str == "D":
		'''------------------------------
		---UNSUPPORT-DEVICE--------------
		------------------------------'''
		dialogok('$LOCALIZE[79501]',addonString(124) % (id10str), addonString(145) % (Button_Name) ,addonString(128))
		'''---------------------------'''
def backward(run2):
	#viewmode = xbmc.getInfoLabel('Container.Viewmode')
	#if viewmode == 'GeneralPT' : xbmc.executebuiltin('Control.SetFocus(50,0)')
	#if viewmode == 'IconsPT' : xbmc.executebuiltin('Control.SetFocus(58,0)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(Select)')
	xbmc.sleep(2000)

def setGeneral_ScriptON(custom, General_ScriptON):
	'''check if this script is already running'''
	if not validation2:
		if custom == "0":
			'''------------------------------
			---SCRIPT-START------------------
			------------------------------'''
			count = 0
			if General_ScriptON == "true":
				'''------------------------------
				---General_ScriptON-TRUE->FALSE--
				------------------------------'''
				while (General_ScriptON == "true" and count <= 3) and not xbmc.abortRequested:
					if count > 0 and not startup_aW:
						if count == 1: notification(addonString(119) + ".", "", "", 1000)
						elif count == 2: notification(addonString(119) + "..", "", "", 1000)
						#elif count == 3: notification(addonString(119) + "...", "", "", 1000)
						'''---------------------------'''
					xbmc.sleep(500)
					count += 1
					countS = str(count)
					General_ScriptON = getsetting('General_ScriptON')
					systemidle1 = xbmc.getCondVisibility('System.IdleTime(1)')
					if General_ScriptON != "true" and systemidle1:
						setsetting_custom1(addonID,'General_ScriptON',"true")
						setSkinSetting("1",'homebuttonsrunning',"true")
						if admin: xbmc.executebuiltin('Notification(Admin,homebuttonsrunning2 '+ countS +',1000)')
						count = 5
					else:
						if count == 3 and systemidle1:
							setsetting_custom1(addonID,'General_ScriptON',"false")
							setSkinSetting("1",'homebuttonsrunning',"false")
							if admin: xbmc.executebuiltin('Notification(Admin,count == 3 and systemidle1 '+ countS +',1000)')
						if count > 1 and not systemidle1:
							if admin: xbmc.executebuiltin('Notification(Admin,count > 1 and not systemidle1 '+ countS +',1000)')
							if not admin: notification_common("11")
							sys.exit()
			else:
				'''------------------------------
				---General_ScriptON-FALSE->-TRUE-
				------------------------------'''
				setsetting_custom1(addonID,'General_ScriptON',"true")
				setSkinSetting("1",'homebuttonsrunning',"true")
				if admin: xbmc.executebuiltin('Notification(Admin,homebuttonsrunning,1000)')
				'''---------------------------'''
		elif custom == "1":
			'''------------------------------
			---SCRIPT-END--------------------
			------------------------------'''
			count = 0
			while General_ScriptON != "true" and count < 3 and not xbmc.abortRequested:
				xbmc.sleep(500)
				count += 1
				countS = str(count)
				if admin: xbmc.executebuiltin('Notification(Admin,homebuttonsrunning -end '+ countS +',500)')
				General_ScriptON = getsetting('General_ScriptON')
				'''---------------------------'''
			if General_ScriptON == "true":
				setsetting_custom1(addonID,'General_ScriptON',"false")
				setSkinSetting("1",'homebuttonsrunning',"false")
				if admin: xbmc.executebuiltin('Notification(Admin,homebuttonsrunning -end,1000)')
				sys.exit()
				'''---------------------------'''

def resetnetwork(run):
	'''tweak and reload the network adapters'''
	xbmc.executebuiltin('Notification([COLOR Red] $VAR[CurrentMAC][/COLOR] $LOCALIZE[79061],$LOCALIZE[79062],5000)')
	if not systemplatformwindows: os.system('sh /storage/.kodi/addons/skin.htpt/specials/scripts/resetnetwork.sh')
	xbmc.sleep(1000)
	oewindow('run',"resetnetwork")

def oewindow(admin,name):
	xbmc.executebuiltin('RunScript(service.openelec.settings)')
	xbmc.sleep(500)
	'''1-system, 2-network, 3-connections, 4-services, 5-bluetooth, 6-about'''
	openelec1 = xbmc.getInfoLabel('$ADDON[service.openelec.settings 32002]')
	openelec2 = xbmc.getInfoLabel('$ADDON[service.openelec.settings 32000]')
	openelec3 = xbmc.getInfoLabel('$ADDON[service.openelec.settings 32100]')
	openelec4 = xbmc.getInfoLabel('$ADDON[service.openelec.settings 32001]')
	openelec5 = xbmc.getInfoLabel('$ADDON[service.openelec.settings 32331]')
	openelec6 = xbmc.getInfoLabel('$ADDON[service.openelec.settings 32196]')
	'''---------------------------'''
	'''mainwindow'''
	mainwindow = xbmc.getCondVisibility('Window.IsVisible(mainWindow.xml)')
	count = 0
	while count < 10 and not mainwindow and not xbmc.abortRequested:
		xbmc.sleep(100)
		count += 1
		mainwindow = xbmc.getCondVisibility('Window.IsVisible(mainWindow.xml)')
		xbmc.sleep(100)

	'''netsettingsbutto'''
	if name == 'netsettingsbutton' or name == 'resetnetwork':
		countbusy = 0
		while mainwindow and not xbmc.abortRequested:
			xbmc.sleep(200)
			mainwindow = xbmc.getCondVisibility('Window.IsVisible(mainWindow.xml)')
			systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
			dialogbusyW = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
			if not dialogbusyW:
				xbmc.sleep(100)
				dialogbusyW = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
				if not dialogbusyW:
					if systemcurrentcontrol == openelec1 or systemcurrentcontrol == openelec6: xbmc.executebuiltin('Action(Down)')
					elif systemcurrentcontrol == openelec4 or systemcurrentcontrol == openelec5: xbmc.executebuiltin('Action(Up)')
					if countbusy > 0: countbusy += -1
			if dialogbusyW: countbusy += 1
			xbmc.sleep(100)
			systemidle40 = xbmc.getCondVisibility('System.IdleTime(40)')
			if systemidle40 or countbusy >= 15: xbmc.executebuiltin('Action(Close)')
			
		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		print printfirst + "netsettingsbutton"
		'''---------------------------'''
		
	'''statusjoystick'''
	if name == 'statusjoystick':
		if admin: xbmc.executebuiltin('Notification(Admin,statusjoystick,1000)')
		while mainwindow and not xbmc.abortRequested:
			xbmc.sleep(200)
			mainwindow = xbmc.getCondVisibility('Window.IsVisible(mainWindow.xml)')
			systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
			if systemcurrentcontrol == openelec1 or systemcurrentcontrol == openelec2 or systemcurrentcontrol == openelec6: xbmc.executebuiltin('Action(Up)')
			elif systemcurrentcontrol == openelec3 or systemcurrentcontrol == openelec4: xbmc.executebuiltin('Action(Down)')
			elif systemcurrentcontrol == openelec5: xbmc.executebuiltin('Action(Right)')
			xbmc.sleep(100)
			systemidle40 = xbmc.getCondVisibility('System.IdleTime(40)')
			if systemidle40: xbmc.executebuiltin('Action(Close)')
			'''---------------------------'''
		print printfirst + "statusjoystick"

def externalusb(run):
	'''detect connected USB'''
	if not systemplatformwindows and myhtpt2:
		xbmc.sleep(40)
		if picturesbutton or videosbutton or startup_aW:
			os.system('sh /storage/.kodi/addons/skin.htpt/specials/scripts/externalusb.sh')
			#subprocess.call('/storage/.kodi/addons/script.htpt.homebuttons/specials/scripts/externalusb.sh', shell=True)
			xbmc.sleep(500)
		log = open('/storage/externalusb.log', 'r')
		rows = log.readlines()
		rowscountN = len(rows)
		rowscount = str(rowscountN)
		log.close()
		row1 = ""
		row2 = ""
		row3 = ""
		row4 = ""
		row5 = ""
		if rowscountN > 0: row1 = rows[0][:-1]
		if rowscountN > 1: row2 = rows[1][:-1]
		if rowscountN > 2: row3 = rows[2][:-1]
		if rowscountN > 3: row4 = rows[3][:-1]
		if rowscountN > 4: row5 = rows[4][:-1]
		if picturesbutton or videosbutton or startup_aW:
			if usb1str != row1: xbmc.executebuiltin('Skin.SetString(USB1,'+ row1 +')')
			if usb2str != row2: xbmc.executebuiltin('Skin.SetString(USB2,'+ row2 +')')
			if usb3str != row3: xbmc.executebuiltin('Skin.SetString(USB3,'+ row3 +')')
			if usb4str != row4: xbmc.executebuiltin('Skin.SetString(USB4,'+ row4 +')')
			if usb5str != row5: xbmc.executebuiltin('Skin.SetString(USB5,'+ row5 +')')
			'''---------------------------'''
		if admin and rowscountN > 0: xbmc.executebuiltin('Notification(Admin,'+ rowscount +' '+ row1 +' ,1000)')
		path0 = 'special://userdata/library/'
		path1 = '/var/media/'+ row1 +'/'
		path2 = '/var/media/'+ row2 +'/'
		path3 = '/var/media/'+ row3 +'/'
		path4 = '/var/media/'+ row4 +'/'
		path5 = '/var/media/'+ row5 +'/'
		pathwin = 'special://home/external/'
		if rowscountN == 0 and myhtpt3: xbmc.executebuiltin('Skin.ToggleSetting(myHTPT3)')
		if rowscountN > 0 and not myhtpt3: xbmc.executebuiltin('Skin.ToggleSetting(myHTPT3)')
		xbmc.sleep(200)
		'''---------------------------'''
		if (myvideonavW or mypicsW) and usbtoggle:
			#xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,)')
			#xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,)')
			if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path0 +')') and rowscountN > 0:
				if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path1 +'videos/,return)')
				if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path1 +'pictures/,return)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,1)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path1 +')')
			elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path1 +')') and rowscountN > 1:
				if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path2 +'videos/,return)')
				if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path2 +'pictures/,return)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,2)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path2 +')')
			elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path2 +')') and rowscountN > 2:
				if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path3 +'videos/,return)')
				if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path3 +'pictures/,return)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,3)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path3 +')')
			elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path3 +')') and rowscountN > 3:
				if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path4 +'videos/,return)')
				if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path4 +'pictures/,return)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,4)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path4 +')')
				'''---------------------------'''
			elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path4 +')') and rowscountN > 4:
				if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path5 +'videos/,return)')
				if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path5 +'pictures/,return)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,5)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path5 +')')
				'''---------------------------'''
			if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path1 +')') and rowscountN == 1:
				if id10str == "C" or id10str == "D":
					if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path1 +'videos/,return)')
					elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path1 +'pictures/,return)')
					'''---------------------------'''
				elif myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'videos/,return)')
				elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'pictures/,return)')
			elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path2 +')') and rowscountN == 2:
				if id10str == "C" or id10str == "D":
					if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path1 +'videos/,return)')
					elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path1 +'pictures/,return)')
					'''---------------------------'''
				elif myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'videos/,return)')
				elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'pictures/,return)')
			elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path3 +')') and rowscountN == 3:
				if id10str == "C" or id10str == "D":
					if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path1 +'videos/,return)')
					elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path1 +'pictures/,return)')
					'''---------------------------'''
				elif myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'videos/,return)')
				elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'pictures/,return)')
			elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path4 +')') and rowscountN == 4:
				if id10str == "C" or id10str == "D":
					if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path1 +'videos/,return)')
					elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path1 +'pictures/,return)')
					'''---------------------------'''
				elif myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'videos/,return)')
				elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'pictures/,return)')
			elif xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path5 +')') and rowscountN == 5:
				if id10str == "C" or id10str == "D":
					if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path1 +'videos/,return)')
					elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path1 +'pictures/,return)')
					'''---------------------------'''
				elif myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'videos/,return)')
				elif mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'pictures/,return)')
				'''---------------------------'''
			xbmc.sleep(20)
			containernumitems = xbmc.getInfoLabel('Container.NumItems')
			if containernumitems == 0: xbmc.executebuiltin('Action(Select)')
			
def mac7(run,macaddress,maccon1,maccon2,maccon10,maccon11):
	'''VALIDATION PROOF'''
	validation2 = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION2)')
	printpoint = ""
	if (not maccon1 and not maccon2) or (not maccon10 and not maccon11):
		xbmc.sleep(200)
		xbmc.executebuiltin('Notification(MAC7,step 1,1000)')
		if (not maccon1 and not maccon2):
			#macaddress = xbmc.getInfoLabel('Network.MacAddress')
			xbmc.executebuiltin('Skin.SetString(MAC,'+ macaddress +')')
			xbmc.sleep(500)
			maccon1 = xbmc.getCondVisibility('StringCompare(Skin.String(MAC),Skin.String(MAC1))')
			maccon2 = xbmc.getCondVisibility('StringCompare(Skin.String(MAC),Skin.String(MAC2))')
			printpoint = printpoint + "1"
		else:
			maccon10 = xbmc.getCondVisibility('StringCompare(Control.GetLabel(700100),NONE)')
			maccon11 = xbmc.getCondVisibility('StringCompare(Control.GetLabel(700100),7000)')
			printpoint = printpoint + "2"
		xbmc.sleep(200)
		if (not maccon1 and not maccon2) or (not maccon10 and not maccon11):
			if validation5 == '0':
				xbmc.executebuiltin('Notification(Admin,MAC7,step 2,1000)')
				if not validation: xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION)')
				if not validation2: xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION2)')
				if not widget: xbmc.executebuiltin('Skin.ToggleSetting(Widget)')
				xbmc.executebuiltin('Notification($LOCALIZE[79080],For Support: [COLOR Yellow]$LOCALIZE[79081][/COLOR],5000,icons/shield.png)')
				if macaddress and not loginscreenW and home_pW: xbmc.executebuiltin('ReplaceWindow(LoginScreen.xml)')
				if validation and playerhasmedia: xbmc.executebuiltin('Action(Stop)')
				
				if not maccon1 and not maccon2 and validation and not macaddress and id9str != 'COPIED':
					xbmc.executebuiltin('Skin.SetString(ID9,COPIED)')
					xbmc.executebuiltin('Notification(COPIED,,5000)')
					xbmc.executebuiltin('ReplaceWindow(LoginScreen.xml)')
				printpoint = printpoint + "3"
			else:
				if validation5 == '3': xbmc.executebuiltin('Skin.SetString(VALIDATION5,2)')
				if validation5 == '2': xbmc.executebuiltin('Skin.SetString(VALIDATION5,1)')
				if validation5 == '1': xbmc.executebuiltin('Skin.SetString(VALIDATION5,0)')
				
				xbmc.executebuiltin('Notification(Admin MAC7:,-validation5 reduced from ('+ validation5 +')')
				printpoint = printpoint + "4"
	else:
		'''UNLOCK'''
		printpoint = printpoint + "5"
		if validation2:
			printpoint = printpoint + "6"
			if hasinternet:
				xbmc.sleep(3000)
				xbmc.executebuiltin('Notification($LOCALIZE[79086],$LOCALIZE[79084],3000,icons/shield.png)')
				xbmc.sleep(1000)
				validation2 = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION2)')
				if validation2: xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION2)')
				printpoint = printpoint + "7"
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + space + "mac7_LV" + printpoint + space3
	'''---------------------------'''

def mac(run,macaddress):
	if validation and (home_aW or startup_aW or startup_pW or loginscreenbutton):
		print printfirst + "mac (1)"
		xbmc.sleep(40)
		if macaddress and macaddress != str503:
			macaddress = xbmc.getInfoLabel('Network.MacAddress')
			xbmc.executebuiltin('Skin.SetString(MAC,'+ macaddress +')')
			xbmc.sleep(500)
		if not validation2: xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION2)')
		if validation5 == '3':
			xbmc.executebuiltin('Skin.SetString(VALIDATION5,2)')
			xbmc.executebuiltin('AlarmClock(HTPTCHECK: '+ idstr +'*0 | '+ id1str +'*1 | '+ id2str +'*2 | '+ id3str +'*3 | '+ id4str +'*4 | '+ id5str +'*5 | '+ id6str +'*6 | '+ id7str +'*7 | '+ id8str +'*8 | '+ id9str +'*9 | '+ id10str +'*10 | '+ mac1str +'*MAC1 | '+ mac2str +'*MAC2 | '+ mac3str +'*MAC3 | '+ macaddress +'*MAC | '+ systemtotaluptime +'*TOTALUPTIME | '+ verrorstr +'*VERROR | ,Action(Stop),0,silent)')
			if not connected2 and not connected3 and systemuptime5: xbmc.executebuiltin('AlarmClock(loginscreendelay,ReplaceWindow(LoginScreen.xml),00:02,silent)')
		if validation5 == '2':
			xbmc.executebuiltin('Skin.SetString(VALIDATION5,1)')
			if not maccon10 and not maccon11 and home_aW: xbmc.executebuiltin('Notification($LOCALIZE[79080],$LOCALIZE[257]: $VAR[VERROR],5000,icons/shield.png)')
		if validation5 == '1':
			xbmc.executebuiltin('Skin.SetString(VALIDATION5,0)')
			xbmc.executebuiltin('Notification($LOCALIZE[79080],For Support: [COLOR Yellow]$LOCALIZE[79081][/COLOR],5000,icons/shield.png)')
		if validation5 == '0':
			if not loginscreenW: xbmc.executebuiltin('ReplaceWindow(LoginScreen.xml)')
			if loginscreen_aW: xbmc.executebuiltin('Notification($LOCALIZE[79080],For Support: [COLOR Yellow]$LOCALIZE[79081][/COLOR],5000,icons/shield.png)')
		xbmc.sleep(40)
		'''UNLOCK SYSTEM'''
		if (maccon1 or maccon2) and (maccon10 or maccon11):
			xbmc.sleep(40)
			print printfirst + "mac (2)"
			xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION)')
			if not widget: xbmc.executebuiltin('Skin.ToggleSetting(Widget)')
			xbmc.executebuiltin('Skin.SetString(VALIDATION5,3)')
			#xbmc.sleep(500)
			if hasinternet:
				xbmc.sleep(40)
				xbmc.executebuiltin('Notification($LOCALIZE[79083],$LOCALIZE[79082],5000,icons/shield2.png)')
				mac7('run',macaddress,maccon1,maccon2,maccon10,maccon11)
			else:
				xbmc.executebuiltin('Notification($LOCALIZE[79083],$LOCALIZE[24073],5000,icons/shield2.png)')
			#if home_aW:
				#xbmc.executebuiltin('Control.SetFocus('+ container9000pos +')')
				#xbmc.sleep(500)
				#if admin: xbmc.executebuiltin('Notification(Admin, '+ container9000pos +',2000,icons/shield2.png)')
				#xbmc.executebuiltin('Action(Select)')
			if loginscreen_aW:
				#xbmc.executebuiltin('ActivateWindow(0)')
				xbmc.executebuiltin('ReplaceWindow(0)')
				
