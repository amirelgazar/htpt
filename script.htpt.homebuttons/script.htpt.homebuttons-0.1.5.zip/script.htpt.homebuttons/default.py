import xbmc
import os, sys
import subprocess
import xbmcgui, xbmcaddon

addonName           = xbmcaddon.Addon().getAddonInfo("name")
printfirst = addonName + ": !@# "
space = " "
space2 = ": "
dialog = xbmcgui.Dialog()

'''HOME'''
moviesbutton = xbmc.getCondVisibility('Container(9000).HasFocus(340)') and not xbmc.getCondVisibility('Control.HasFocus(9090)')
tvshowsbutton = xbmc.getCondVisibility('Container(9000).HasFocus(341)') and not xbmc.getCondVisibility('Control.HasFocus(9090)')
israeltvbutton = xbmc.getCondVisibility('Container(9000).HasFocus(342)')
youtubebutton = xbmc.getCondVisibility('Container(9000).HasFocus(343)')
goprobutton = xbmc.getCondVisibility('Container(9000).HasFocus(344)')
moviesebutton = xbmc.getCondVisibility('Container(9000).HasFocus(320)')
tvshowsebutton = xbmc.getCondVisibility('Container(9000).HasFocus(321)')
weatherbutton = xbmc.getCondVisibility('Container(9000).HasFocus(345)')
picturesbutton = xbmc.getCondVisibility('Container(9000).HasFocus(507)')
gamesbutton = xbmc.getCondVisibility('Container(9000).HasFocus(323)')
trailers2button = xbmc.getCondVisibility('Container(9000).HasFocus(351)')
quizbutton = xbmc.getCondVisibility('Container(9000).HasFocus(509)')
videosbutton = xbmc.getCondVisibility('Container(9000).HasFocus(325)')
musicbutton = xbmc.getCondVisibility('Container(9000).HasFocus(508)')
kidsbutton = xbmc.getCondVisibility('Container(9000).HasFocus(322)')
mov3dsbutton = xbmc.getCondVisibility('Container(9000).HasFocus(324)')
internetbutton = xbmc.getCondVisibility('Container(9000).HasFocus(327)')
gadgetbutton = xbmc.getCondVisibility('Container(9000).HasFocus(328)')
karaokebutton = xbmc.getCondVisibility('Container(9000).HasFocus(326)')
gametrailersbutton = xbmc.getCondVisibility('Container(9000).HasFocus(329)')
guitarbutton = xbmc.getCondVisibility('Container(9000).HasFocus(330)')
favouritesbutton = xbmc.getCondVisibility('Container(9000).HasFocus(352)')
livetvbutton = xbmc.getCondVisibility('Container(9000).HasFocus(355)')
radiobutton = xbmc.getCondVisibility('Container(9000).HasFocus(356)')
settingsbutton = xbmc.getCondVisibility('Container(9000).HasFocus(348)')
widgettogglebutton = xbmc.getCondVisibility('Control.HasFocus(9090)')

'''OTHERS BUTTONS'''
adultbutton = xbmc.getCondVisibility('Container(50).HasFocus(49)')
formatbutton = xbmc.getCondVisibility('Container(50).HasFocus(92)')
realdebridbutton = xbmc.getCondVisibility('Container(50).HasFocus(99)')
loginscreenbutton = (xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(100)'))
#button = xbmc.getCondVisibility('Container(9000).HasFocus(?)')
#button = xbmc.getCondVisibility('Container(9000).HasFocus(?)')
#button = xbmc.getCondVisibility('Container(9000).HasFocus(?)')
#button = xbmc.getCondVisibility('Container(9000).HasFocus(?)')
'''SETTINGS'''
netsettingsbutton = (xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(108)')) or xbmc.getCondVisibility('Container(52).HasFocus(40)') or (xbmc.getCondVisibility('Window.IsVisible(Custom1170.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(10)'))
'''HELP'''
airplaybutton = xbmc.getCondVisibility('Container(50).HasFocus(1)')
messagebutton = xbmc.getCondVisibility('Container(50).HasFocus(2)')
resetnetworkbutton = xbmc.getCondVisibility('Container(50).HasFocus(10)')
debugbutton = xbmc.getCondVisibility('Container(50).HasFocus(5)') or (xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(102)'))
#button = xbmc.getCondVisibility('Container(9000).HasFocus(?)')
'''LEFT MENU'''
searchisraeltv = xbmc.getCondVisibility('Control.HasFocus(107)')
deletesearchyoutube = xbmc.getCondVisibility('Control.HasFocus(109)')
statusjoystick = xbmc.getCondVisibility('Control.HasFocus(100)')
allowjoystick = xbmc.getCondVisibility('Control.HasFocus(102)')
usbtoggle = xbmc.getCondVisibility('Control.HasFocus(70)')
'''Windows'''
home = xbmc.getCondVisibility('Window.IsVisible(0)')
home_p = xbmc.getCondVisibility('Window.Previous(0)')
home_a = xbmc.getCondVisibility('Window.IsActive(0)')
myvideonav = xbmc.getCondVisibility('Window.IsVisible(MyVideoNav.xml)')
mypics = xbmc.getCondVisibility('Window.IsVisible(MyPics.xml)')
mymusicnav = xbmc.getCondVisibility('Window.IsVisible(MyMusicNav.xml)')
settings = xbmc.getCondVisibility('Window.IsVisible(Settings.xml)')
myprograms = xbmc.getCondVisibility('Window.IsVisible(MyPrograms.xml)')
filemanager = xbmc.getCondVisibility('Window.IsVisible(FileManager.xml)')
startup = xbmc.getCondVisibility('Window.IsVisible(Startup.xml)')
startup_a = xbmc.getCondVisibility('Window.IsActive(Startup.xml)')
startup_p = xbmc.getCondVisibility('Window.Previous(Startup.xml)')
loginscreen = xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)')
loginscreen_a = xbmc.getCondVisibility('Window.IsActive(LoginScreen.xml)')
myweather = xbmc.getCondVisibility('Window.IsVisible(MyWeather.xml)')
dialogfavourites = xbmc.getCondVisibility('Window.IsVisible(DialogFavourites.xml)')
myvideonav = xbmc.getCondVisibility('Window.IsVisible(MyVideoNav.xml)')
skinsettings = xbmc.getCondVisibility('Window.IsVisible(SkinSettings.xml)')
dialogprogress = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
dialogok = xbmc.getCondVisibility('Window.IsVisible(DialogOk.xml)')
custom1170 = xbmc.getCondVisibility('Window.IsVisible(Custom1170.xml)')
custom1115 = xbmc.getCondVisibility('Window.IsVisible(Custom1115.xml)')
'''SKIN SETTINGS'''
admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
admin2 = xbmc.getInfoLabel('Skin.HasSetting(Admin2)')
validation = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION)')
validation2 = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION2)')
autoviewoff = xbmc.getInfoLabel('Skin.HasSetting(AutoViewoff)')
widget = xbmc.getInfoLabel('Skin.HasSetting(Widget)')
myhtpt2 = xbmc.getInfoLabel('Skin.HasSetting(myHTPT2)')
myhtpt3 = xbmc.getInfoLabel('Skin.HasSetting(myHTPT3)')
homebuttonsrunning = xbmc.getInfoLabel('Skin.HasSetting(homebuttonsrunning)')
connected = xbmc.getInfoLabel('Skin.HasSetting(Connected)')
connected2 = xbmc.getInfoLabel('Skin.HasSetting(Connected2)')
connected3 = xbmc.getInfoLabel('Skin.HasSetting(Connected3)')
'''OTHERS'''
settingslevel = xbmc.getInfoLabel('Skin.String(SettingsLevel)')
systemidle3 = xbmc.getCondVisibility('System.IdleTime(3)')
systemuptime = xbmc.getInfoLabel('System.Uptime')
systemtotaluptime = xbmc.getInfoLabel('System.TotalUptime')
test = xbmc.getInfoLabel('Skin.String(Test)')
systemcurrentwindow = xbmc.getInfoLabel('System.CurrentWindow')
systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
systemplatformwindows = xbmc.getCondVisibility('system.platform.windows')
if home: container9000pos = xbmc.getInfoLabel('Container(9000).Position')
containernumitems = xbmc.getInfoLabel('Container.NumItems')
'''CONDITIONS'''
systeminternetstate = xbmc.getCondVisibility('SubString(System.InternetState,$LOCALIZE[13297])')
playerhasmedia = xbmc.getCondVisibility('Player.HasMedia')
networkipaddress = xbmc.getCondVisibility('IsEmpty(Network.IPAddress)')
settinglevelbutton = xbmc.getCondVisibility('Control.HasFocus(20)')
airplaycon1 = xbmc.getCondVisibility('SubString(System.CurrentControl,AirPlay)')
airplaycon2 = xbmc.getCondVisibility('System.GetBool(services.airplay)')
airplaycon3 = xbmc.getCondVisibility('System.GetBool(services.zeroconf)')
allowjoystickcon2 = xbmc.getCondVisibility('SubString(System.CurrentControl,$LOCALIZE[35100])')
vhomecon1 = xbmc.getCondVisibility('!Container(9000).HasFocus(348)') and xbmc.getCondVisibility('!Container(9000).HasFocus(323)') and xbmc.getCondVisibility('!Container(9000).HasFocus(340)') and xbmc.getCondVisibility('!Container(9000).HasFocus(341)') and xbmc.getCondVisibility('!Container(9000).HasFocus(325)') and xbmc.getCondVisibility('!Container(9000).HasFocus(346)') and xbmc.getCondVisibility('!Container(9000).HasFocus(507)') and xbmc.getCondVisibility('!Container(9000).HasFocus(508)') and xbmc.getCondVisibility('!Container(9000).HasFocus(509)')
maccon1 = xbmc.getCondVisibility('StringCompare(Skin.String(MAC),Skin.String(MAC1))')
maccon2 = xbmc.getCondVisibility('StringCompare(Skin.String(MAC),Skin.String(MAC2))')
maccon10 = xbmc.getCondVisibility('StringCompare(Control.GetLabel(700100),NONE)')
maccon11 = xbmc.getCondVisibility('StringCompare(Control.GetLabel(700100),7000)')
'''STRINGS'''
viewmode = xbmc.getInfoLabel('Container.Viewmode')
macaddress = xbmc.getInfoLabel('Network.MacAddress')
airplaystr1 = xbmc.getInfoLabel('$LOCALIZE[1273]')
airplaystr2 = 'AirPlay'
airplaystr3 = xbmc.getInfoLabel('$LOCALIZE[1270]')
airplaystr4 = xbmc.getInfoLabel('Skin.String(AirPlay2)')
busystr = xbmc.getInfoLabel('$LOCALIZE[503]')
settingslevelstr1 = xbmc.getInfoLabel('$LOCALIZE[10036]')
settingslevelstr2 = xbmc.getInfoLabel('$LOCALIZE[10037]')
validation5 = xbmc.getInfoLabel('Skin.String(VALIDATION5)')
var700100 = xbmc.getInfoLabel('Control.GetLabel(700100)')
var70000 = xbmc.getInfoLabel('$LOCALIZE[70000]')
idstr = xbmc.getInfoLabel('Skin.String(ID)')
id1str = xbmc.getInfoLabel('Skin.String(ID1)')
id2str = xbmc.getInfoLabel('Skin.String(ID2)')
id3str = xbmc.getInfoLabel('Skin.String(ID3)')
id4str = xbmc.getInfoLabel('Skin.String(ID4)')
id5str = xbmc.getInfoLabel('Skin.String(ID5)')
id6str = xbmc.getInfoLabel('Skin.String(ID6)')
id7str = xbmc.getInfoLabel('Skin.String(ID7)')
id8str = xbmc.getInfoLabel('Skin.String(ID8)')
id9str = xbmc.getInfoLabel('Skin.String(ID9)')
id10str = xbmc.getInfoLabel('Skin.String(ID10)')
mac1str = xbmc.getInfoLabel('Skin.String(MAC1)')
mac2str = xbmc.getInfoLabel('Skin.String(MAC2)')
mac3str = xbmc.getInfoLabel('Skin.String(MAC3)')
verrorstr = xbmc.getInfoLabel('$VAR[VERROR]')
usb1str = xbmc.getInfoLabel('Skin.String(USB1)')
usb2str = xbmc.getInfoLabel('Skin.String(USB2)')
usb3str = xbmc.getInfoLabel('Skin.String(USB3)')
usb4str = xbmc.getInfoLabel('Skin.String(USB4)')
usb5str = xbmc.getInfoLabel('Skin.String(USB5)')
'''PATH'''
containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
listitempath = xbmc.getInfoLabel('ListItem.Path')
israeltvhome = 'plugin://plugin.video.sdarot.tv/'
videorootpath = 'library://video/'


def refresh(run):
	'''check if refresh script is running'''
	refreshrunnings = xbmc.getInfoLabel('Skin.HasSetting(refreshrunnings)')
	playerhasvideo = xbmc.getCondVisibility('Player.HasVideo')
	if refreshrunnings and not playerhasvideo:
		xbmc.executebuiltin('Skin.ToggleSetting(refreshrunnings)')
		if admin: xbmc.executebuiltin('Notification(Admin: refreshrunnings,-MANUAL OFF on 3,1000)')
		
		'''remove skin strings'''
		listitemtvshowtitle = xbmc.getInfoLabel('Skin.String(ListItemTVShowTitle)')
		listitemgenre = xbmc.getInfoLabel('Skin.String(ListItemGenre)')
		listitemduration = xbmc.getInfoLabel('Skin.String(ListItemDuration)')
		listitemrating = xbmc.getInfoLabel('Skin.String(ListItemRating)')
		listitemyear = xbmc.getInfoLabel('Skin.String(ListItemYear)')
		if listitemtvshowtitle: xbmc.executebuiltin('Skin.SetString(ListItemTVShowTitle,)')
		if listitemgenre: xbmc.executebuiltin('Skin.SetString(ListItemGenre,)')
		if listitemduration: xbmc.executebuiltin('Skin.SetString(ListItemDuration,)')
		if listitemrating: xbmc.executebuiltin('Skin.SetString(ListItemRating,)')
		if listitemyear: xbmc.executebuiltin('Skin.SetString(ListItemYear,)')
		
		if xbmc.getInfoLabel('Skin.String(TopVideoInformation1)'): xbmc.executebuiltin('Skin.SetString(TopVideoInformation1,)')
		if xbmc.getInfoLabel('Skin.String(TopVideoInformation2)'): xbmc.executebuiltin('Skin.SetString(TopVideoInformation2,)')
		if xbmc.getInfoLabel('Skin.String(TopVideoInformation3)'): xbmc.executebuiltin('Skin.SetString(TopVideoInformation3,)')
		if xbmc.getInfoLabel('Skin.String(TopVideoInformation4)'): xbmc.executebuiltin('Skin.SetString(TopVideoInformation4,)')
		if xbmc.getInfoLabel('Skin.String(TopVideoInformation5)'): xbmc.executebuiltin('Skin.SetString(TopVideoInformation5,)')
		if xbmc.getInfoLabel('Skin.String(TopVideoInformation6)'): xbmc.executebuiltin('Skin.SetString(TopVideoInformation6,)')
		if xbmc.getInfoLabel('Skin.String(TopVideoInformation7)'): xbmc.executebuiltin('Skin.SetString(TopVideoInformation7,)')
		if xbmc.getInfoLabel('Skin.String(TopVideoInformation8)'): xbmc.executebuiltin('Skin.SetString(TopVideoInformation8,)')
		if xbmc.getInfoLabel('Skin.String(TopVideoInformation9)'): xbmc.executebuiltin('Skin.SetString(TopVideoInformation9,)')
	'''remove strings for preventing autoplay bug'''
	if not refreshrunnings or playerhasvideo:
		dialogselectsources = xbmc.getInfoLabel('Skin.String(DialogSelectSources)')
		dialogselectsources3 = xbmc.getInfoLabel('Skin.String(DialogSelectSources3)')
		if dialogselectsources or dialogselectsources3:
			xbmc.sleep(1000)
			xbmc.executebuiltin('Skin.SetString(DialogSelectSources,)')
			xbmc.executebuiltin('Skin.SetString(DialogSelectSources3,)')

def settingschange(window,systemgetbool,falsetrue,force,string1,string2):
	'''systemgetbool'''
	systemgetbool2 = xbmc.getCondVisibility('System.GetBool('+ systemgetbool +')')
	systemgetbool2str = str(systemgetbool2)
	if systemgetbool2str != falsetrue or force == 'yes':
		if admin: xbmc.executebuiltin('Notification(Admin,settingschange '+ systemgetbool +' ('+ systemgetbool2str +'),10000)')
		xbmc.executebuiltin('ActivateWindow('+ window +')')
		'''Right'''
		systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
		if not string1 in systemcurrentcontrol:
			xbmc.executebuiltin('Action(Right)')
			xbmc.sleep(100)
			systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
			if not string1 in systemcurrentcontrol:
				xbmc.executebuiltin('Action(Right)')
				xbmc.sleep(100)
				systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
				if not string1 in systemcurrentcontrol:
					xbmc.executebuiltin('Action(Right)')
					xbmc.sleep(100)
					systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
					if not string1 in systemcurrentcontrol:
						xbmc.executebuiltin('Action(Right)')
						xbmc.sleep(100)
						systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
		xbmc.sleep(40)
		if string1 in systemcurrentcontrol: xbmc.executebuiltin('Action(Down)')
		
		'''Down'''
		xbmc.sleep(100)
		systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
		if not string2 in systemcurrentcontrol:
			xbmc.executebuiltin('Action(Down)')
			xbmc.sleep(100)
			systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
			if not string2 in systemcurrentcontrol:
				xbmc.executebuiltin('Action(Down)')
				xbmc.sleep(100)
				systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
				if not string2 in systemcurrentcontrol:
					xbmc.executebuiltin('Action(Down)')
					xbmc.sleep(100)
					systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
					if not string2 in systemcurrentcontrol:
						xbmc.executebuiltin('Action(Down)')
						xbmc.sleep(100)
						systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
		xbmc.sleep(40)
		
		'''Select'''
		systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
		if string2 in systemcurrentcontrol:
			xbmc.executebuiltin('Action(Select)')
			xbmc.sleep(100)
			if systemgetbool2 != falsetrue and force == 'yes': xbmc.executebuiltin('Action(Select)')
			systemgetbool2 = xbmc.getCondVisibility('System.GetBool('+ systemgetbool +')')
			if admin: xbmc.sleep(1000)
			if systemgetbool2 != falsetrue and force == 'yes' or force == 'no': xbmc.executebuiltin('Action(Back)')
			if not systemgetbool2: xbmc.executebuiltin('Notification('+ systemcurrentcontrol +',,5000)')

def homebuttonsrunnings(run):
	'''check if this script is already running'''
	if not validation2:
		if run == 'run':
			homebuttonsrunning = xbmc.getInfoLabel('Skin.HasSetting(homebuttonsrunning)')
			count = 0
			while (homebuttonsrunning and count <= 3) and not xbmc.abortRequested:
				if count > 0 and not startup_a: xbmc.executebuiltin('Notification($LOCALIZE[503],$LOCALIZE[31407],1000)')
				xbmc.sleep(500)
				count += 1
				countS = str(count)
				homebuttonsrunning = xbmc.getInfoLabel('Skin.HasSetting(homebuttonsrunning)')
				systemidle1 = xbmc.getCondVisibility('System.IdleTime(1)')
				if not homebuttonsrunning and systemidle1:
					xbmc.executebuiltin('Skin.ToggleSetting(homebuttonsrunning)')
					if admin: xbmc.executebuiltin('Notification(Admin,homebuttonsrunning2 '+ countS +',1000)')
					count = 5
				else:
					if count == 3 and systemidle1:
						xbmc.executebuiltin('Skin.ToggleSetting(homebuttonsrunning)')
						if admin: xbmc.executebuiltin('Notification(Admin,count == 3 and systemidle1 '+ countS +',1000)')
					if count > 1 and not systemidle1:
						if admin: xbmc.executebuiltin('Notification(Admin,count > 1 and not systemidle1 '+ countS +',1000)')
						if not admin: xbmc.executebuiltin('Notification($LOCALIZE[257],$LOCALIZE[79078],1000)')
						sys.exit()
			else:
				xbmc.executebuiltin('Skin.ToggleSetting(homebuttonsrunning)')
				if admin: xbmc.executebuiltin('Notification(Admin,homebuttonsrunning,1000)')

		if run == 'end':
			homebuttonsrunning = xbmc.getInfoLabel('Skin.HasSetting(homebuttonsrunning)')
			count = 0
			while not homebuttonsrunning and count < 3 and not xbmc.abortRequested:
				xbmc.sleep(500)
				count += 1
				countS = str(count)
				if admin: xbmc.executebuiltin('Notification(Admin,homebuttonsrunning -end '+ countS +',500)')
				homebuttonsrunning = xbmc.getInfoLabel('Skin.HasSetting(homebuttonsrunning)')
			if homebuttonsrunning:
				xbmc.executebuiltin('Skin.ToggleSetting(homebuttonsrunning)')
				if admin: xbmc.executebuiltin('Notification(Admin,homebuttonsrunning -end,1000)')
				sys.exit()
def bash(bashCommand,bashname):
	'''run BASH commands'''
	if not systemplatformwindows:
		xbmc.sleep(40)
		process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
		output = process.communicate()[0]
		if bashname == "Connected":
			xbmc.executebuiltin('Skin.SetString(Test,'+ output +')')
			if "1 packets transmitted" in output:
				if not connected: xbmc.executebuiltin('Skin.ToggleSetting(Connected)')
			else:
				if connected: xbmc.executebuiltin('Skin.ToggleSetting(Connected)')
		if bashname == "Connected2":
			xbmc.executebuiltin('Skin.SetString(Test,'+ output +')')
			if not "packets:0" in output and "inet addr" in output:
				if not connected2: xbmc.executebuiltin('Skin.ToggleSetting(Connected2)')
			else:
				if connected2: xbmc.executebuiltin('Skin.ToggleSetting(Connected2)')
		if bashname == "Connected3":
			xbmc.executebuiltin('Skin.SetString(Test,'+ output +')')
			if not "packets:0" in output and "inet addr" in output:
				if not connected3: xbmc.executebuiltin('Skin.ToggleSetting(Connected3)')
			else:
				if connected3: xbmc.executebuiltin('Skin.ToggleSetting(Connected3)')		
def scc(action1, action2, condition1, condition2):
	'''Moving sequences'''
	systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
	if systemcurrentcontrol != condition1 and systemcurrentcontrol != condition2: action1
	systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
	if systemcurrentcontrol == condition1 or systemcurrentcontrol == condition2: action2
	systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
	#xbmc.sleep(500)
	if admin: xbmc.executebuiltin('Notification(Admin,scc,1000)')
def scc2(action1, action2, condition1, condition2):
	systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
	#xbmc.executebuiltin('Notification('+ allowjoystickstr1 +',1,1000)')
	if condition2 in condition1: action2
	elif not condition2 in condition1: action1

def checkforhtptupdate(run):
	xbmc.executebuiltin('ActivateWindow(10001,addons://outdated/)')
	outdatedtotal = xbmc.getInfoLabel('Container().NumItems')
	xbmc.executebuiltin('Skin.SetString(Test3,1'+ outdatedtotal +')')
	if outdatedtotal != '0':
		#xbmc.getInfoLabel
		xbmc.executebuiltin('Control.SetFocus(50,0)')
		xbmc.sleep(1000)
		xbmc.executebuiltin('Control.SetFocus(50,1)')
		xbmc.sleep(5000)
def resetnetwork(run):
	'''tweak and reload the network adapters'''
	xbmc.executebuiltin('Notification([COLOR Red] $VAR[CurrentMAC][/COLOR] $LOCALIZE[79061],$LOCALIZE[79062],5000)')
	if not systemplatformwindows: os.system('sh /storage/.kodi/addons/skin.htpt/specials/scripts/resetnetwork.sh')
	xbmc.sleep(1000)
	oewindow('run')
def externalusb(run):
	'''detect connected USB'''
	if not systemplatformwindows and myhtpt2:
		xbmc.sleep(40)
		if picturesbutton or videosbutton or startup_a:
			os.system('sh /storage/.kodi/addons/skin.htpt/specials/scripts/externalusb.sh')
			#subprocess.call('/storage/.kodi/addons/script.htpt.homebuttons/specials/scripts/externalusb.sh', shell=True)
			xbmc.sleep(500)
		log = open('/storage/externalusb.log', 'r')
		rows = log.readlines()
		rowscountN = len(rows)
		rowscount = str(rowscountN)
		log.close()
		row1 = ""
		row2 = ""
		row3 = ""
		row4 = ""
		row5 = ""
		if rowscountN > 0: row1 = rows[0][:-1]
		if rowscountN > 1: row2 = rows[1][:-1]
		if rowscountN > 2: row3 = rows[2][:-1]
		if rowscountN > 3: row4 = rows[3][:-1]
		if rowscountN > 4: row5 = rows[4][:-1]
		if picturesbutton or videosbutton or startup_a:
			if usb1str != row1: xbmc.executebuiltin('Skin.SetString(USB1,'+ row1 +')')
			if usb2str != row2: xbmc.executebuiltin('Skin.SetString(USB2,'+ row2 +')')
			if usb3str != row3: xbmc.executebuiltin('Skin.SetString(USB3,'+ row3 +')')
			if usb4str != row4: xbmc.executebuiltin('Skin.SetString(USB4,'+ row4 +')')
			if usb5str != row5: xbmc.executebuiltin('Skin.SetString(USB5,'+ row5 +')')
		if admin and rowscountN > 0: xbmc.executebuiltin('Notification(Admin,'+ rowscount +' '+ row1 +' ,1000)')
		path0 = 'special://userdata/library/'
		path1 = '/var/media/'+ row1 +'/'
		path2 = '/var/media/'+ row2 +'/'
		path3 = '/var/media/'+ row3 +'/'
		path4 = '/var/media/'+ row4 +'/'
		path5 = '/var/media/'+ row5 +'/'
		pathwin = 'special://home/external/'
		if rowscountN == 0 and myhtpt3: xbmc.executebuiltin('Skin.ToggleSetting(myHTPT3)')
		if rowscountN > 0 and not myhtpt3: xbmc.executebuiltin('Skin.ToggleSetting(myHTPT3)')
		xbmc.sleep(200)
		if (myvideonav or mypics) and usbtoggle:
			#xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,)')
			#xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,)')
			if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path0 +')') and rowscountN > 0:
				if myvideonav: xbmc.executebuiltin('ActivateWindow(Video,'+ path1 +'videos/,return)')
				if mypics: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path1 +'pictures/,return)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,1)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path1 +')')
			if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path1 +')') and rowscountN > 1:
				if myvideonav: xbmc.executebuiltin('ActivateWindow(Video,'+ path2 +'videos/,return)')
				if mypics: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path2 +'pictures/,return)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,2)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path2 +')')
			if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path2 +')') and rowscountN > 2:
				if myvideonav: xbmc.executebuiltin('ActivateWindow(Video,'+ path3 +'videos/,return)')
				if mypics: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path3 +'pictures/,return)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,3)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path3 +')')
			if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path3 +')') and rowscountN > 3:
				if myvideonav: xbmc.executebuiltin('ActivateWindow(Video,'+ path4 +'videos/,return)')
				if mypics: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path4 +'pictures/,return)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,4)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path4 +')')
			if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path4 +')') and rowscountN > 4:
				if myvideonav: xbmc.executebuiltin('ActivateWindow(Video,'+ path5 +'videos/,return)')
				if mypics: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path5 +'pictures/,return)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVid,5)')
				xbmc.executebuiltin('Skin.SetString(VarCurrentPicVidPath,'+ path5 +')')
			if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path1 +')') and rowscountN == 1:
				if myvideonav: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'videos/,return)')
				if mypics: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'pictures/,return)')
			if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path2 +')') and rowscountN == 2:
				if myvideonav: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'videos/,return)')
				if mypics: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'pictures/,return)')
			if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path3 +')') and rowscountN == 3:
				if myvideonav: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'videos/,return)')
				if mypics: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'pictures/,return)')
			if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path4 +')') and rowscountN == 4:
				if myvideonav: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'videos/,return)')
				if mypics: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'pictures/,return)')
			if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path5 +')') and rowscountN == 5:
				if myvideonav: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'videos/,return)')
				if mypics: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'pictures/,return)')
			xbmc.sleep(20)
			containernumitems = xbmc.getInfoLabel('Container.NumItems')
			if containernumitems == 0: xbmc.executebuiltin('Action(Select)')
def mac7(run,macaddress,maccon1,maccon2,maccon10,maccon11):
	'''VALIDATION PROOF'''
	validation2 = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION2)')
	if (not maccon1 and not maccon2) or (not maccon10 and not maccon11):
		xbmc.sleep(200)
		xbmc.executebuiltin('Notification(MAC7,step 1,1000)')
		if (not maccon1 and not maccon2):
			#macaddress = xbmc.getInfoLabel('Network.MacAddress')
			xbmc.executebuiltin('Skin.SetString(MAC,'+ macaddress +')')
			xbmc.sleep(500)
			maccon1 = xbmc.getCondVisibility('StringCompare(Skin.String(MAC),Skin.String(MAC1))')
			maccon2 = xbmc.getCondVisibility('StringCompare(Skin.String(MAC),Skin.String(MAC2))')
		else:
			maccon10 = xbmc.getCondVisibility('StringCompare(Control.GetLabel(700100),NONE)')
			maccon11 = xbmc.getCondVisibility('StringCompare(Control.GetLabel(700100),7000)')
		xbmc.sleep(200)
		if (not maccon1 and not maccon2) or (not maccon10 and not maccon11):
			if validation5 == '0':
				xbmc.executebuiltin('Notification(Admin,MAC7,step 2,1000)')
				if not validation: xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION)')
				if not validation2: xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION2)')
				if not widget: xbmc.executebuiltin('Skin.ToggleSetting(Widget)')
				xbmc.executebuiltin('Notification($LOCALIZE[79080],For Support: [COLOR Yellow]$LOCALIZE[79081][/COLOR],5000,icons/shield.png)')
				if macaddress and not loginscreen and home_p: xbmc.executebuiltin('ReplaceWindow(LoginScreen.xml)')
				if validation and playerhasmedia: xbmc.executebuiltin('Action(Stop)')
				
				if not maccon1 and not maccon2 and validation and not macaddress and id9str != 'COPIED':
					xbmc.executebuiltin('Skin.SetString(ID9,COPIED)')
					xbmc.executebuiltin('Notification(COPIED,,5000)')
					xbmc.executebuiltin('ReplaceWindow(LoginScreen.xml)')
			else:
				if validation5 == '3': xbmc.executebuiltin('Skin.SetString(VALIDATION5,2)')
				if validation5 == '2': xbmc.executebuiltin('Skin.SetString(VALIDATION5,1)')
				if validation5 == '1': xbmc.executebuiltin('Skin.SetString(VALIDATION5,0)')
				
				xbmc.executebuiltin('Notification(Admin MAC7:,-validation5 reduced from ('+ validation5 +')')
	else:
		'''UNLOCK'''
		if validation2:
			if not systeminternetstate and not networkipaddress and (connected or systemplatformwindows):
				xbmc.sleep(3000)
				xbmc.executebuiltin('Notification($LOCALIZE[79086],$LOCALIZE[79084],3000,icons/shield.png)')
				xbmc.sleep(1000)
				validation2 = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION2)')
				if validation2 and not systeminternetstate and not networkipaddress: xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION2)')
def mac(run,macaddress):
	if validation and (home_a or startup_a or startup_p or (loginscreen_a and loginscreenbutton)):
		if admin: xbmc.executebuiltin('Notification(Admin,mac,1000)')
		xbmc.sleep(40)
		if macaddress and macaddress != busystr:
			macaddress = xbmc.getInfoLabel('Network.MacAddress')
			xbmc.executebuiltin('Skin.SetString(MAC,'+ macaddress +')')
			xbmc.sleep(500)
		if not validation2: xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION2)')
		if validation5 == '3':
			xbmc.executebuiltin('Skin.SetString(VALIDATION5,2)')
			xbmc.executebuiltin('AlarmClock(HTPTCHECK: '+ idstr +'*0 | '+ id1str +'*1 | '+ id2str +'*2 | '+ id3str +'*3 | '+ id4str +'*4 | '+ id5str +'*5 | '+ id6str +'*6 | '+ id7str +'*7 | '+ id8str +'*8 | '+ id9str +'*9 | '+ id10str +'*10 | '+ mac1str +'*MAC1 | '+ mac2str +'*MAC2 | '+ mac3str +'*MAC3 | '+ macaddress +'*MAC | '+ systemtotaluptime +'*TOTALUPTIME | '+ verrorstr +'*VERROR | ,Action(Stop),0,silent)')
		if validation5 == '2':
			xbmc.executebuiltin('Skin.SetString(VALIDATION5,1)')
			if not maccon10 and not maccon11 and home_a: xbmc.executebuiltin('Notification($LOCALIZE[79080],$LOCALIZE[257]: $VAR[VERROR],5000,icons/shield.png)')
		if validation5 == '1':
			xbmc.executebuiltin('Skin.SetString(VALIDATION5,0)')
			xbmc.executebuiltin('Notification($LOCALIZE[79080],For Support: [COLOR Yellow]$LOCALIZE[79081][/COLOR],5000,icons/shield.png)')
		if validation5 == '0':
			if not loginscreen: xbmc.executebuiltin('ReplaceWindow(LoginScreen.xml)')
			if loginscreen_a: xbmc.executebuiltin('Notification($LOCALIZE[79080],For Support: [COLOR Yellow]$LOCALIZE[79081][/COLOR],5000,icons/shield.png)')
		xbmc.sleep(40)
		'''UNLOCK SYSTEM'''
		if (maccon1 or maccon2) and (maccon10 or maccon11):
			xbmc.sleep(40)
			if admin: xbmc.executebuiltin('Notification(Admin,doubleclicklock,1000)')
			xbmc.executebuiltin('Skin.ToggleSetting(VALIDATION)')
			if not widget: xbmc.executebuiltin('Skin.ToggleSetting(Widget)')
			xbmc.executebuiltin('Skin.SetString(VALIDATION5,3)')
			#xbmc.sleep(500)
			if not systeminternetstate and not networkipaddress and (connected or systemplatformwindows):
				xbmc.sleep(40)
				xbmc.executebuiltin('Notification($LOCALIZE[79083],$LOCALIZE[79082],5000,icons/shield2.png)')
				mac7('run',macaddress,maccon1,maccon2,maccon10,maccon11)
			else:
				xbmc.executebuiltin('Notification($LOCALIZE[79083],$LOCALIZE[24073],5000,icons/shield2.png)')
			if home_a:
				#xbmc.executebuiltin('Control.SetFocus('+ container9000pos +')')
				#xbmc.sleep(500)
				if admin: xbmc.executebuiltin('Notification(Admin, '+ container9000pos +',2000,icons/shield2.png)')
				#xbmc.executebuiltin('Action(Select)')
			if loginscreen_a:
				xbmc.executebuiltin('ActivateWindow(0)')
def startup(run):
	validation = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION)')
	if startup_a and not validation:
		if admin: xbmc.executebuiltin('Notification(Admin,startup,1000)')
		xbmc.executebuiltin('ReplaceWindow(Home)')
		mac7('run',macaddress,maccon1,maccon2,maccon10,maccon11)
		externalusb('run')
		xbmc.executebuiltin('RunScript(service.skin.widgets)')
		#if not systemplatformwindows: settingschange('SystemSettings','input.enablemouse','0','no',xbmc.getInfoLabel('$LOCALIZE[14094]'),xbmc.getInfoLabel('$LOCALIZE[21369]'))
def homebuttons(run):
	'''activate home buttons'''
	if not validation and home:
		if moviesbutton:
			libraryhascontentmovies = xbmc.getCondVisibility('Library.HasContent(Movies)')
			if libraryhascontentmovies:
				if admin: xbmc.executebuiltin('Notification(Admin,moviesbutton,1000)')
				xbmc.executebuiltin('ActivateWindow(Videos,MovieTitles,return)')
			else:
				if not autoviewoff: xbmc.executebuiltin('Skin.ToggleSetting(AutoViewoff)')
				xbmc.executebuiltin('ActivateWindow(video,"special://userdata/library/movies/",return)')
				xbmc.executebuiltin('Notification($LOCALIZE[79079] $LOCALIZE[342] $LOCALIZE[79090],$LOCALIZE[79091],4000)')
		if tvshowsbutton:
			libraryhascontenttvshows = xbmc.getCondVisibility('Library.HasContent(TVShows)')
			if libraryhascontenttvshows:
				if admin: xbmc.executebuiltin('Notification(Admin,tvshowsbutton,1000)')
				xbmc.executebuiltin('ActivateWindow(VideoLibrary,TVShowTitles,return)')
			else:
				if not autoviewoff: xbmc.executebuiltin('Skin.ToggleSetting(AutoViewoff)')
				xbmc.executebuiltin('ActivateWindow(video,"special://userdata/library/tvshows/",return)')
				xbmc.executebuiltin('Notification($LOCALIZE[79079] $LOCALIZE[20343] $LOCALIZE[79090],$LOCALIZE[79091],4000)')
		if gamesbutton:
			#if admin: xbmc.executebuiltin('Notification(Admin,gamesbutton,1000)')
			if not systemplatformwindows:
				os.system('sh /storage/.kodi/addons/skin.htpt/specials/scripts/launcher.sh')
				#xbmc.sleep(200)
				xbmc.executebuiltin('XBMC.RunAddon(plugin.program.advanced.launcher)')
				xbmc.sleep(200)
				if systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow'):
					os.system('sh /storage/.kodi/addons/skin.htpt/specials/scripts/copy.sh')
					xbmc.sleep(2000)
					os.system('sh /storage/.kodi/addons/skin.htpt/specials/scripts/launcher.sh')
					xbmc.sleep(200)
					xbmc.executebuiltin('XBMC.RunAddon(plugin.program.advanced.launcher)')
			else: xbmc.executebuiltin('XBMC.RunAddon(plugin.program.advanced.launcher)')
		if picturesbutton or videosbutton:
			if picturesbutton:
				if admin: xbmc.executebuiltin('Notification(Admin,picturesbutton,1000)')
				xbmc.executebuiltin('ActivateWindow(Pictures,special://userdata/library/pictures/,return)')
				if not admin and not playerhasmedia: xbmc.executebuiltin('PlayMedia(special://userdata/addon_data/skin.htpt/music/playHTPT.mp3)')
			if videosbutton:
				xbmc.executebuiltin('ActivateWindow(Video,special://userdata/library/videos/,return)')
			externalusb('run')
		if favouritesbutton:
			if admin: xbmc.executebuiltin('Notification(Admin,favouritesbutton,1000)')
			xbmc.executebuiltin('ActivateWindow(134)')
		if settingsbutton:
			if admin: xbmc.executebuiltin('Notification(Admin,settingsbutton,1000)')
			if admin or admin2: xbmc.executebuiltin('ActivateWindow(1120)')
			else: xbmc.executebuiltin('ActivateWindow(Settings.xml)')
		if widgettogglebutton:
			if admin: xbmc.executebuiltin('Notification(Admin,widgettogglebutton,1000)')
			if xbmc.getCondVisibility('Control.IsVisible(311)'):
				xbmc.executebuiltin('Skin.ToggleSetting(MoviesShelfWL)')
				xbmc.executebuiltin('ActivateWindow(Videos,MovieTitles)')
				xbmc.sleep(100)
				xbmc.executebuiltin('ReplaceWindow(0)')
				xbmc.executebuiltin('Control.SetFocus(9090)')

			if xbmc.getCondVisibility('Control.IsVisible(312)'):
				xbmc.executebuiltin('Skin.ToggleSetting(TVShelf_Watchlist)')
				xbmc.executebuiltin('ActivateWindow(VideoLibrary,TVShowTitles)')
				xbmc.sleep(100)
				xbmc.executebuiltin('ReplaceWindow(0)')
				xbmc.executebuiltin('Control.SetFocus(9090)')
		
		'''buttons which require internet'''
		if not systeminternetstate and not networkipaddress and (connected or systemplatformwindows):
			#if admin: xbmc.executebuiltin('Notification(Admin,homebuttons internet,1000)')
			if israeltvbutton:
				if admin: xbmc.executebuiltin('Notification(Admin,israeltvbutton,1000)')
				listitempath = xbmc.getInfoLabel('ListItem.Path')
				israeltvrootpath = 'plugin://plugin.video.sdarot.tv/'
				'''1try'''
				xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.sdarot.tv/?mode=2&module=http%3a%2f%2fwww.sdarot.wf%2fseries%2fgenre%2f20%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99&name=%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99&url=all-heb,return)')
				xbmc.sleep(200)
				'''2'''				
				if systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow'):
					xbmc.executebuiltin('RunAddon(plugin.video.sdarot.tv)')
					xbmc.sleep(200)
					'''3'''
					xbmc.sleep(1500)
					containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
					if not israeltvrootpath in containerfolderpath:
						xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.sdarot.tv/?mode=2&module=http%3a%2f%2fwww.sdarot.ws%2fseries%2fgenre%2f20%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99&name=%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99&url=all-heb,return)')
						xbmc.sleep(200)
						'''4'''
						xbmc.sleep(1000)
						containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
						if not israeltvrootpath in containerfolderpath:
							xbmc.executebuiltin('RunAddon(plugin.video.sdarot.tv)')
							containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
							xbmc.sleep(1000)
							if not israeltvrootpath in containerfolderpath:
								if systemcurrentwindow != xbmc.getInfoLabel('System.CurrentWindow'): xbmc.executebuiltin('Notification($LOCALIZE[257],$LOCALIZE[79071],2000)')
			if goprobutton:
				if admin: xbmc.executebuiltin('Notification(Admin,goprobutton,1000)')
				#xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.youtube/?folder=true&login=false&path=%2froot%2fsearch&store=searches;,return)')
				if systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow'): xbmc.executebuiltin('RunAddon(plugin.video.GoProCamera)')
			if youtubebutton:
				if admin: xbmc.executebuiltin('Notification(Admin,youtubebutton,1000)')
				xbmc.executebuiltin('RunAddon(plugin.video.youtube)')
				xbmc.sleep(500)
				containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
				count = 0
				while count < 10 and not "plugin://plugin.video.youtube" in containerfolderpath and not xbmc.abortRequested:
					xbmc.sleep(100)
					count += 1
					containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
					xbmc.sleep(100)
				if "plugin://plugin.video.youtube" in containerfolderpath:
					xbmc.executebuiltin('Action(PageUp)')
					xbmc.executebuiltin('Action(Down)')
				
				
			if moviesebutton or tvshowsebutton:
				if admin: xbmc.executebuiltin('Notification(Admin,moviesebutton/tvshowsebutton,1000)')
				if moviesebutton: xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=root_movies,return)') #xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=movies_popular)')
				if tvshowsebutton: xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=root_shows,return)')
				xbmc.sleep(200)
				if systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow'):
					if not autoviewoff: xbmc.executebuiltin('Skin.ToggleSetting(AutoViewoff)')
					xbmc.executebuiltin('RunAddon(plugin.video.genesis)')
					xbmc.sleep(1000)
					containerfolderpath = xbmc.getCondVisibility('StringCompare(Container.FolderPath,plugin://plugin.video.genesis/)')
					if not containerfolderpath:
						xbmc.executebuiltin('Action(PageUp)')
						xbmc.executebuiltin('Action(PageUp)')
						xbmc.executebuiltin('Action(Select)')
						xbmc.sleep(800)
						containerfolderpath = xbmc.getCondVisibility('StringCompare(Container.FolderPath,plugin://plugin.video.genesis/)')
						#xbmc.sleep(1000)
					if containerfolderpath:
						xbmc.executebuiltin('Action(PageUp)')
						xbmc.executebuiltin('Action(Down)')
						if tvshowsebutton: xbmc.executebuiltin('Action(Down)')
						xbmc.executebuiltin('Action(Select)')
				else:
					xbmc.sleep(300)
					xbmc.executebuiltin('Action(PageDown)')
					xbmc.executebuiltin('Action(PageDown)')
			if weatherbutton:
				if admin: xbmc.executebuiltin('Notification(Admin,weatherbutton,1000)')
				xbmc.executebuiltin('ActivateWindow(MyWeather)')
				xbmc.sleep(200)
				xbmc.executebuiltin('Weather.Refresh')
			if trailers2button:
				if admin: xbmc.executebuiltin('Notification(Admin,trailers2button,1000)')
				xbmc.executebuiltin('RunAddon(screensaver.randomtrailers)')
			if quizbutton:
				if admin: xbmc.executebuiltin('Notification(Admin,quizbutton,1000)')
				#watchedmovies = xbmc.getInfoLabel('Window(Home).Property(Movies.Watched)')
				#watchedtvshows = xbmc.getInfoLabel('Window(Home).Property(TVShows.Watched,)')
				#xbmc.executebuiltin('Notification('+ watchedmovies +','+ watchedtvshows +',1000)')
				#xbmc.sleep(1000)
				xbmc.executebuiltin('RunAddon(script.moviequiz)')
				
			if musicbutton:
				if admin: xbmc.executebuiltin('Notification(Admin,musicbutton,1000)')
				musiclinkstr = xbmc.getInfoLabel('Skin.String(MusicLink)')
				libraryhascontentmusic = xbmc.getCondVisibility('Library.HasContent(Music)')
				if not libraryhascontentmusic: xbmc.executebuiltin('ActivateWindow(501,root),return)')
				elif musiclinkstr != "": xbmc.executebuiltin('ActivateWindow(502,'+ musiclinkstr +',return)')
				else: xbmc.executebuiltin('ActivateWindow(502,return)')
			if kidsbutton:
				if admin: xbmc.executebuiltin('Notification(Admin,kidsbutton,1000)')
				xbmc.executebuiltin('RunAddon(plugin.video.KIDSIL)')
			if mov3dsbutton:
				if admin: xbmc.executebuiltin('Notification(Admin,mov3dsbutton,1000)')
				#xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.movie25/?fanart;genre;iconimage=https%3a%2f%2fraw.github.com%2fmash2k3%2fMashupArtwork%2fmaster%2fskins%2fvector%2f3d.png;mode=223;name=3D%20Movies;plot;url=3D,return)')
				xbmc.executebuiltin('Notification($LOCALIZE[79072],For Support: [COLOR Yellow]$LOCALIZE[79081][/COLOR],4000)')
			if internetbutton:
				import xbmcgui
				#if admin: xbmc.executebuiltin('Notification(Admin,internetbutton,1000)')
				dialog = xbmcgui.Dialog()
				internetbuttonm1 = xbmc.getInfoLabel('$LOCALIZE[79215]')
				internetbuttonm2 = xbmc.getInfoLabel('$LOCALIZE[79216]')
				message1 = internetbuttonm1
				message2 = internetbuttonm2
				if dialog.yesno(message1,message2):
					internetbuttonn1 = xbmc.getInfoLabel('$LOCALIZE[79217]')
					internetbuttonn2 = xbmc.getInfoLabel('$LOCALIZE[79218]')
					xbmc.executebuiltin('Notification('+ internetbuttonn1 +','+ internetbuttonn2 +',2000)')
					settingschange('SystemSettings','input.enablemouse','1','no',xbmc.getInfoLabel('$LOCALIZE[14094]'),xbmc.getInfoLabel('$LOCALIZE[21369]'))
					xbmc.sleep(1000)
					if not systemplatformwindows: xbmc.executebuiltin('RunAddon(browser.chromium-browser)')
				else:
					settingschange('SystemSettings','input.enablemouse','0','no',xbmc.getInfoLabel('$LOCALIZE[14094]'),xbmc.getInfoLabel('$LOCALIZE[21369]'))
			if gadgetbutton:
				if admin: xbmc.executebuiltin('Notification(Admin,gadgetbutton,1000)')
				#if not systemplatformwindows: xbmc.executebuiltin('RunAddon(plugin.video.engadget)')
				xbmc.executebuiltin('Notification($LOCALIZE[79072],For Support: [COLOR Yellow]$LOCALIZE[79081][/COLOR],4000)')
			if karaokebutton:
				if admin: xbmc.executebuiltin('Notification(Admin,karaokebutton,1000)')
				xbmc.executebuiltin('RunAddon(plugin.video.MikeysKaraoke)')
			if gametrailersbutton:
				if admin: xbmc.executebuiltin('Notification(Admin,gametrailersbutton,1000)')
				xbmc.executebuiltin('RunAddon(plugin.video.g4tv)')
			if guitarbutton:
				if admin: xbmc.executebuiltin('Notification(Admin,guitarbutton,1000)')
				xbmc.executebuiltin('RunAddon(plugin.video.ultimateguitar)')
			if livetvbutton:
				if admin: xbmc.executebuiltin('Notification(Admin,livetvbutton,1000)')
				xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.israelive/?description&displayname=DTT%2b&iconimage=http%3a%2f%2fftp5.bizportal.co.il%2fweb%2fgiflib%2fnews%2fidan_plus_gay.jpg&mode=2&name=%5bCOLOR%20blue%5d%5bB%5d%5bDTT%2b%5d%5b%2fB%5d%5b%2fCOLOR%5d&url,return)')
				xbmc.sleep(700)
				containernumitems = xbmc.getInfoLabel('Container.NumItems')
				if systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow') or containernumitems == '0':
					xbmc.executebuiltin('RunAddon(plugin.video.israelive)')
					xbmc.sleep(700)
					if xbmc.getInfoLabel('Container.FolderPath') == 'plugin://plugin.video.israelive/':
						xbmc.executebuiltin('Action(PageUp)')
						xbmc.executebuiltin('Action(Down)')
						xbmc.executebuiltin('Action(Down)')
						xbmc.executebuiltin('Action(Down)')
						xbmc.executebuiltin('Action(Select)')
			if radiobutton:
				if admin: xbmc.executebuiltin('Notification(Admin,radiobutton,1000)')
				xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.israelive/?description&displayname=%d7%a8%d7%93%d7%99%d7%95&iconimage=http%3a%2f%2fmdmorrope.gob.pe%2fportalweb%2fimagenes%2fradioss.png&mode=2&name=%5bCOLOR%20blue%5d%5bB%5d%5b%d7%a8%d7%93%d7%99%d7%95%5d%5b%2fB%5d%5b%2fCOLOR%5d&url,return)')
				xbmc.sleep(700)
				containernumitems = xbmc.getInfoLabel('Container.NumItems')
				if systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow') or containernumitems == '0':
					xbmc.executebuiltin('RunAddon(plugin.video.israelive)')
					xbmc.sleep(700)
					if xbmc.getInfoLabel('Container.FolderPath') == 'plugin://plugin.video.israelive/':
						xbmc.executebuiltin('Action(PageUp)')
						xbmc.executebuiltin('Action(Down)')
						xbmc.executebuiltin('Action(Down)')
						xbmc.executebuiltin('Action(Select)')
		elif vhomecon1: xbmc.executebuiltin('Notification($LOCALIZE[79512],$LOCALIZE[21451],5000)')

def dialogkeyboard(input, heading, option, custom, addonsetting, addonsetting2):
	''''''
	if '$LOCALIZE' in heading: heading = xbmc.getInfoLabel(heading)
	dialog = xbmcgui.Dialog()
	keyboard = xbmc.Keyboard(input,heading,option)
	keyboard.doModal()
	returned = 'skip'
	if (keyboard.isConfirmed()):
		input2 = keyboard.getText()
		if custom == '1' and input2 != "": returned = 'ok'
		if custom == '2' and input2 == input: returned = 'ok'
		if custom == '3':
			if input2 != input and input2 != "" and option == 0: xbmc.executebuiltin('Notification('+ heading +': '+ input2 +',,4000)')
			if input2 != "": returned = 'ok'
			
		if option == 0: print printfirst + heading + space2 + input2 + " ( " + returned + " )"
		elif option != 0: print printfirst + heading + space2 + "*******" + " ( " + returned + " )"
	if returned == 'ok':
		returned == input2
		if addonsetting2 == "0": setsetting(addonsetting, input2)
		elif addonsetting2 == 'genesis':
			setsetting_genesis          = xbmcaddon.Addon('plugin.video.genesis').setSetting
			setsetting_genesis(addonsetting, input2)
	return returned
		
		
		
def dialogyesno(heading,line1):
	heading = xbmc.getInfoLabel(heading)
	line1 = xbmc.getInfoLabel(line1)
	returned = 'skip'
	if dialog.yesno(heading,line1): returned = 'ok'
	
	print printfirst + heading + "( " + returned + " )"
	return returned

def dialogok(heading,line1,line2,line3):
	heading = xbmc.getInfoLabel(heading)
	line1 = xbmc.getInfoLabel(line1)
	line2 = xbmc.getInfoLabel(line2)
	line3 = xbmc.getInfoLabel(line3)
	dialog.ok(heading,line1,line2,line3)
	print printfirst + heading
	
def skinbuttons(run):
	if skinsettings:
		if admin: xbmc.executebuiltin('Notification(Admin,skinsettings,1000)')
		if adultbutton:
			if admin: xbmc.executebuiltin('Notification(Admin,adultbutton,1000)')
			xbmc.executebuiltin('Skin.ToggleSetting(Adult)')
			if not systemplatformwindows:
				xbmc.sleep(1000)
				os.system('sh /storage/.kodi/addons/service.htpt/specials/scripts/copyemu.sh')
			xbmc.sleep(2000)
			xbmc.executebuiltin('XBMC.RunAddon(plugin.program.advanced.launcher)')
		if realdebridbutton:
			if admin: xbmc.executebuiltin('Notification(Admin,realdebridbutton,1000)')
			
			getsetting_genesis          = xbmcaddon.Addon('plugin.video.genesis').getSetting
			setsetting_genesis          = xbmcaddon.Addon('plugin.video.genesis').setSetting
			realdebrid = xbmc.getInfoLabel('Skin.HasSetting(RealDebrid)')
			realdedrid_user = getsetting_genesis('realdedrid_user')
			realdedrid_password = getsetting_genesis('realdedrid_password')
			if realdebrid:
				'''turn off'''
				if admin: xbmc.executebuiltin('Notification(Admin,realdebrid - off?,1000)')
				'''change username/password'''
				returned = dialogyesno('$LOCALIZE[79483]','$LOCALIZE[79484]')
				if returned == 'ok':
					'''username dialog'''
					if 'htpt' in realdedrid_user: realdedrid_user = ""
					returned = dialogkeyboard(realdedrid_user,'$LOCALIZE[20142]',0,'3','realdedrid_user','genesis')
					if returned == 'skip': xbmc.executebuiltin('Notification($LOCALIZE[257],$LOCALIZE[75002],2000)')
					else:
						'''password dialog'''
						returned = dialogkeyboard(realdedrid_password,'$LOCALIZE[15052]',1,'3','realdedrid_password','genesis')
						if returned == 'skip': xbmc.executebuiltin('Notification($LOCALIZE[257],$LOCALIZE[75002],2000)')
						else:
							dialogok('$LOCALIZE[79475]','$LOCALIZE[79479]','$LOCALIZE[79478]','$LOCALIZE[79474]')
				else:
					'''turn off'''
					xbmc.executebuiltin('Skin.ToggleSetting(RealDebrid)')
					setsetting_genesis('realdedrid_user', "")
					setsetting_genesis('realdedrid_password', "")
			else:
				'''turn on'''
				if admin: xbmc.executebuiltin('Notification(Admin,realdebrid - on,1000)')
				'''have account?'''
				returned = dialogyesno('$LOCALIZE[79482]','$LOCALIZE[79481]')
				if returned == 'ok':
					'''username dialog'''
					if admin or not 'htpt' in realdedrid_user: input = realdedrid_user
					else: input = ""
					returned = dialogkeyboard(input,'$LOCALIZE[20142]',0,'3','realdedrid_user','genesis')
					if returned == 'skip': xbmc.executebuiltin('Notification($LOCALIZE[257],$LOCALIZE[75002],2000)')
					else:
						'''password dialog'''
						#if not 'htpt' in realdedrid_user and not 'gkalni' in realdedrid_password and not 'ilovehtpt' in realdedrid_password: message1 = realdedrid_password
						#else: message1 = ""
						returned = dialogkeyboard(realdedrid_password,'$LOCALIZE[15052]',1,'3','realdedrid_password','genesis')
						if returned == 'skip': xbmc.executebuiltin('Notification($LOCALIZE[257],$LOCALIZE[75002],2000)')
						else:
							'''toggle on'''
							if admin: xbmc.executebuiltin('Notification(Admin,'+ realdedrid_user +' - '+ realdedrid_password +',1000)')
							xbmc.executebuiltin('Skin.ToggleSetting(RealDebrid)')
							dialogok('$LOCALIZE[79475]','$LOCALIZE[79479]','$LOCALIZE[79478]','$LOCALIZE[79474]')
					
				else:
					'''signup help'''
					dialogok('https://real-debrid.com/','$LOCALIZE[79480]','[CR]' + '$LOCALIZE[79477]','[CR]' + '$LOCALIZE[79476]')
				
				
				#xbmc.executebuiltin('Skin.ToggleSetting(RealDebrid)')
			if not systemplatformwindows:
				xbmc.sleep(1000)
				os.system('sh /storage/.kodi/addons/skin.htpt/specials/scripts/genesis.sh')
		if formatbutton:
			import xbmcgui
			if admin: xbmc.executebuiltin('Notification(Admin,formatbutton,1000)')
			mac5str = xbmc.getInfoLabel('Skin.String(MAC5)')
			#dialog = xbmcgui.Dialog()
			returned = dialogyesno('FORMAT YOUR DEVICE TOOL','CHOOSE YES TO PROCEED')
			if returned == 'ok':
				'''asking for a password'''
				xbmc.executebuiltin('Skin.SetNumeric(MAC5)')
				xbmc.sleep(3000)
				dialognumeric = xbmc.getCondVisibility('Window.IsVisible(DialogNumeric.xml)')
				while dialognumeric and not xbmc.abortRequested:
					xbmc.sleep(500)
					dialognumeric = xbmc.getCondVisibility('Window.IsVisible(DialogNumeric.xml)')
					xbmc.sleep(1000)
				mac5str = xbmc.getInfoLabel('Skin.String(MAC5)')
				xbmc.sleep(200)
				if admin: xbmc.executebuiltin('Notification(Admin,'+ mac5str +',1000)')
				if mac5str == var70000 and mac5str != "":
					xbmc.executebuiltin('Notification(FORMAT WILL START IN 10 MIN!,REBOOT ASAP FOR CANCELING THE PROCESS!,10000,icons/shield.png)')
				if mac5str != var70000 and mac5str != "":
					xbmc.executebuiltin('Notification(WRONG PASSWORD!!!,BE SURE YOU KNOW WHAT YOU ARE DOING!!!,10000,icons/shield.png)')
					if admin: xbmc.executebuiltin('Skin.ToggleSetting(Admin)')
					xbmc.executebuiltin('Skin.SetString(ID9,FTOOL)')
			else:
				if mac5str: xbmc.executebuiltin('Skin.SetString(MAC5,)')
				xbmc.executebuiltin('Notification(FORMAT CANCELED,...,2000,icons/shield.png)')
def settingslevelset(run):
	'''check if settingslevel = basic'''
	settingslevel = xbmc.getInfoLabel('Skin.String(SettingsLevel)')
	if settingslevel == settingslevelstr1:
		if admin: xbmc.executebuiltin('Notification(Admin,settingslevel == settingslevelstr1,1000)')
		scc(xbmc.executebuiltin('Action(Up)'),xbmc.executebuiltin('Action(Select)'),settingslevelstr1,settingslevelstr1)
		settingslevel = xbmc.getInfoLabel('Skin.String(SettingsLevel)')
		xbmc.executebuiltin('Action(Down)')
def helpbuttons(run):
	'''Help Buttons / LoginScreen'''
	if custom1170 or loginscreen:
		xbmc.sleep(40)
		#if admin: xbmc.executebuiltin('Notification(Admin,custom1170,1000)')
		if airplaybutton:
			if admin: xbmc.executebuiltin('Notification(Admin,airplaybutton,1000)')
			xbmc.executebuiltin('ActivateWindow(servicesettings)')
			settingslevelset('run')
			scc(xbmc.executebuiltin('Action(Left)'),xbmc.executebuiltin('Action(Down)'),airplaystr1,airplaystr2)
			if systemcurrentcontrol != airplaystr1 and systemcurrentcontrol != airplaystr2:
				scc(xbmc.executebuiltin('Action(Left)'),xbmc.executebuiltin('Action(Down)'),airplaystr1,airplaystr2)
			if not airplaycon1: xbmc.executebuiltin('Action(Down)')
			if not airplaycon1: xbmc.executebuiltin('Action(Down)')
			'''if Allow to receive AirPlay content'''
			if airplaycon1:
				xbmc.executebuiltin('Action(Select)')
				if admin and airplaycon2: xbmc.executebuiltin('Notification(Admin,airplaycon2,1000)')
				if airplaycon2:
					if airplaycon3:
						xbmc.executebuiltin('Notification($LOCALIZE[79063],$LOCALIZE[79064],5000)')
						if not systemplatformwindows:
							os.system('sh /storage/.kodi/addons/skin.htpt/specials/scripts/resetnetwork.sh')
							xbmc.sleep(1000)
							bash('ifconfig wlan0',"Connected2")
							xbmc.sleep(500)
							bash('ifconfig eth0',"Connected3")
					xbmc.sleep(200)
					xbmc.executebuiltin('Action(Select)')
				xbmc.executebuiltin('Action(Back)')
				if not airplaycon3: xbmc.executebuiltin('Notification($LOCALIZE[257],$LOCALIZE[34302],5000)')
		if resetnetworkbutton:
			resetnetwork('run')
			xbmc.sleep(500)
			bash('ifconfig wlan0',"Connected2")
			xbmc.sleep(500)
			bash('ifconfig eth0',"Connected3")
		'''buttons which require internet'''
		if not systeminternetstate and not networkipaddress and (connected or systemplatformwindows):
			if messagebutton:
				xbmc.executebuiltin('Notification($LOCALIZE[79072],For Support: [COLOR Yellow]$LOCALIZE[79081][/COLOR],4000)')
				if systemplatformwindows:
					xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.programm.htptmail/mailbox/INBOX/,return)')
			if debugbutton:
				xbmc.executebuiltin('RunAddon(script.htpt.debug)')
		elif vhomecon1: xbmc.executebuiltin('Notification($LOCALIZE[79512],$LOCALIZE[21451],5000)')		
def oewindow(admin,name):
	xbmc.executebuiltin('RunScript(service.openelec.settings)')
	xbmc.sleep(500)
	'''1-system, 2-network, 3-connections, 4-services, 5-bluetooth, 6-about'''
	openelec1 = xbmc.getInfoLabel('$ADDON[service.openelec.settings 32002]')
	openelec2 = xbmc.getInfoLabel('$ADDON[service.openelec.settings 32000]')
	openelec3 = xbmc.getInfoLabel('$ADDON[service.openelec.settings 32100]')
	openelec4 = xbmc.getInfoLabel('$ADDON[service.openelec.settings 32001]')
	openelec5 = xbmc.getInfoLabel('$ADDON[service.openelec.settings 32331]')
	openelec6 = xbmc.getInfoLabel('$ADDON[service.openelec.settings 32196]')
	'''mainwindow'''
	mainwindow = xbmc.getCondVisibility('Window.IsVisible(mainWindow.xml)')
	count = 0
	while count < 10 and not mainwindow and not xbmc.abortRequested:
		xbmc.sleep(100)
		count += 1
		mainwindow = xbmc.getCondVisibility('Window.IsVisible(mainWindow.xml)')
		xbmc.sleep(100)

	'''netsettingsbutton'''
	if name == 'netsettingsbutton':
		if admin: xbmc.executebuiltin('Notification(Admin,netsettingsbutton,1000)')
		while mainwindow and not xbmc.abortRequested:
			xbmc.sleep(200)
			mainwindow = xbmc.getCondVisibility('Window.IsVisible(mainWindow.xml)')
			systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
			if systemcurrentcontrol == openelec1 or systemcurrentcontrol == openelec6: xbmc.executebuiltin('Action(Down)')
			elif systemcurrentcontrol == openelec4 or systemcurrentcontrol == openelec5: xbmc.executebuiltin('Action(Up)')
			xbmc.sleep(100)
			systemidle40 = xbmc.getCondVisibility('System.IdleTime(40)')
			if systemidle40: xbmc.executebuiltin('Action(Close)')
	'''statusjoystick'''
	if name == 'statusjoystick':
		if admin: xbmc.executebuiltin('Notification(Admin,statusjoystick,1000)')
		while mainwindow and not xbmc.abortRequested:
			xbmc.sleep(200)
			mainwindow = xbmc.getCondVisibility('Window.IsVisible(mainWindow.xml)')
			systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
			if systemcurrentcontrol == openelec1 or systemcurrentcontrol == openelec2 or systemcurrentcontrol == openelec6: xbmc.executebuiltin('Action(Up)')
			elif systemcurrentcontrol == openelec3 or systemcurrentcontrol == openelec4: xbmc.executebuiltin('Action(Down)')
			elif systemcurrentcontrol == openelec5: xbmc.executebuiltin('Action(Right)')
			
			systemidle40 = xbmc.getCondVisibility('System.IdleTime(40)')
			if systemidle40: xbmc.executebuiltin('Action(Close)')
		
def backward(run2):
	#viewmode = xbmc.getInfoLabel('Container.Viewmode')
	#if viewmode == 'GeneralPT' : xbmc.executebuiltin('Control.SetFocus(50,0)')
	#if viewmode == 'IconsPT' : xbmc.executebuiltin('Control.SetFocus(58,0)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(PageUp)')
	xbmc.executebuiltin('Action(Select)')
	xbmc.sleep(2000)
def leftmenu(run):
	'''left menu'''
	containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
	if not validation:
		'''searchisraeltv'''
		if myvideonav and searchisraeltv:
			if admin: xbmc.executebuiltin('Notification(Admin,searchisraeltv,1000)')
			xbmc.executebuiltin('Action(Right)')
			if containerfolderpath != israeltvhome:
				if admin: xbmc.executebuiltin('Notification(Admin,!='+ containerfolderpath +',1000)')
				backward('run2')
				containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
				if containerfolderpath != israeltvhome:
					if admin: xbmc.executebuiltin('Notification(Admin,!='+ containerfolderpath +',1000)')
					backward('run2')
					containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
					if containerfolderpath != israeltvhome:
						if admin: xbmc.executebuiltin('Notification(Admin,!='+ containerfolderpath +',1000)')
						backward('run2')
						containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
			if containerfolderpath == israeltvhome:
				if admin: xbmc.executebuiltin('Notification(Admin,=='+ containerfolderpath +',1000)')
				xbmc.executebuiltin('Action(PageUp)')
				xbmc.executebuiltin('Action(PageUp)')
				xbmc.executebuiltin('Action(PageUp)')
				xbmc.executebuiltin('Action(Down)')
				xbmc.executebuiltin('Action(Select)')
		'''deletesearchyoutube'''
		#if myvideonav and deletesearchyoutube:
			#Z = 'special://userdata/addon_data/plugin.video.youtube/settings.xml'
			#if admin: xbmc.executebuiltin('Notification(Admin,deletesearchyoutube,1000)')
			#A = '"store_searches" value='
			#B = '"[^ ]*"'
			#bash('sed -i "s|a|b|g" z,"deletesearchyoutube")
			#xbmc.executebuiltin('Action(Right)')
		'''statusjoystick'''
		if myprograms and statusjoystick: oewindow(admin,'statusjoystick')
		'''allowjoystick'''
		if myprograms and allowjoystick:
			if admin: xbmc.executebuiltin('Notification(Admin,allowjoystick,1000)')
			settingschange('SystemSettings','input.enablejoystick','1','yes',xbmc.getInfoLabel('$LOCALIZE[14094]'),xbmc.getInfoLabel('$LOCALIZE[35100]'))
		'''70'''
		if (myvideonav or mypics) and usbtoggle:
			if admin: xbmc.executebuiltin('Notification(Admin,usbtoggle,1000)')
			#videopath0 = xbmc.getCondVisibility('SubString(Container.FolderPath,special://userdata/library/videos/)')
			externalusb('run')
			if systemplatformwindows:
				path0 = 'special://userdata/library/'
				pathwin = 'special://home/external/'
				if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path0 +')'):
					if myvideonav: xbmc.executebuiltin('ActivateWindow(Video,'+ pathwin +'videos/,return)')
					if mypics: xbmc.executebuiltin('ActivateWindow(Pictures,'+ pathwin +'pictures/,return)')
				if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ pathwin +')'):
					if myvideonav: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'videos/,return)')
					if mypics: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'pictures/,return)')
	else:
		if admin: xbmc.executebuiltin('Notification(Admin,no buttonproceed,1000)')

def miscbuttons(run):
	dialogsubtitles = xbmc.getCondVisibility('Window.IsVisible(DialogSubtitles.xml)')
	custom1125 = xbmc.getCondVisibility('Window.IsVisible(Custom1125.xml)')
	
	if dialogsubtitles:
		import json
		dialogkeyboard = xbmc.getCondVisibility('Window.IsVisible(DialogKeyboard.xml)')
		smartsearch = xbmc.getCondVisibility('Control.HasFocus(161)')
		if admin: xbmc.executebuiltin('Notification(Admin,smartsubsearch,1000)')
		isTV = 'false'
		isMovie = 'false'
		input = ""
		videoplayertitle = xbmc.getInfoLabel('VideoPlayer.Title')
		tvshowtitle = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
		season = xbmc.getInfoLabel('VideoPlayer.Season')
		episode = xbmc.getInfoLabel('VideoPlayer.Episode')
		title = xbmc.getInfoLabel('VideoPlayer.Title')
		year = xbmc.getInfoLabel('VideoPlayer.Year')
		country = xbmc.getInfoLabel('VideoPlayer.Country')
		tagline = xbmc.getInfoLabel('VideoPlayer.Tagline')
		if tvshowtitle != "" and season != "" and episode != "": isTV = 'true'
		elif title != "" and (year != "" or country != "" or tagline != ""): isMovie = 'true'
		xbmc.sleep(40)
		print printfirst + "dialogsubtitles: " + "tvshowtitle = " + tvshowtitle + " | season = " + season + " | episode = " + episode + " | title = " + title + " | year = " + year + " | videoplayertitle = " + videoplayertitle
		'''tvshow/movie?'''
		if videoplayertitle != "": input = videoplayertitle
		elif isTV == 'true':
			seasonN = int(season)
			episodeN = int(episode)
			if seasonN < 10 and episodeN < 10: input = tvshowtitle + " " + 'S0' + season + 'E0' + episode
			if seasonN > 10 and episodeN > 10: input = tvshowtitle + " " + 'S' + season + 'E' + episode
			if seasonN > 10 and episodeN < 10: input = tvshowtitle + " " + 'S' + season + 'E0' + episode
			if seasonN < 10 and episodeN > 10: input = tvshowtitle + " " + 'S0' + season + 'E' + episode
		elif isMovie == 'true': input = title + " " + year
		
		xbmc.sleep(1000)
		xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ input +'","done":false}}')
	#else:
		#if admin: xbmc.executebuiltin('Notification(Admin,NO smartsubsearch,1000)')
	
	if custom1125:
		import json
		#if admin: xbmc.executebuiltin('Notification(Admin,custom1125,1000)')
		#if (keyboard.isConfirmed()):
		#xel = xbmcgui.Window(xbmcgui.getCurrentWindowId())
		#dialog = xbmcgui.Dialog()        
		keyboard = xbmc.Keyboard()
		input = keyboard.getText()
		xbmc.executebuiltin('Notification(INPUT?,'+ input +',5000)')
		
		print printfirst + "custom1125: " + "input = " + input
		smartkeyboardcopy = xbmc.getCondVisibility('Control.HasFocus(202)')
		smartkeyboardhistory = xbmc.getCondVisibility('Control.HasFocus(201)')
		smartkeyboardpaste = xbmc.getCondVisibility('Control.HasFocus(204)')
		'''copy button'''
		if smartkeyboardcopy:
			'''variable'''
			smartkeyboardPN = xbmc.getInfoLabel('Skin.String(smartkeyboardPN)')
			smartkeyboardC1 = xbmc.getInfoLabel('Skin.String(smartkeyboardC1)')
			smartkeyboardC2 = xbmc.getInfoLabel('Skin.String(smartkeyboardC2)')
			smartkeyboardC3 = xbmc.getInfoLabel('Skin.String(smartkeyboardC3)')
			smartkeyboardC4 = xbmc.getInfoLabel('Skin.String(smartkeyboardC4)')
			smartkeyboardC5 = xbmc.getInfoLabel('Skin.String(smartkeyboardC5)')
			'''execute'''
			#xbmc.executebuiltin('Action(Close)')
			#xbmc.sleep(200)
			if admin: xbmc.executebuiltin('Notification(Admin,smartkeyboardcopy,1000)')
			if smartkeyboardPN == '1': xbmc.executebuiltin('Skin.SetString(smartkeyboardC1,'+ input +')')
			if smartkeyboardPN == '2': xbmc.executebuiltin('Skin.SetString(smartkeyboardC2,'+ input +')')
			if smartkeyboardPN == '3': xbmc.executebuiltin('Skin.SetString(smartkeyboardC3,'+ input +')')
			if smartkeyboardPN == '4': xbmc.executebuiltin('Skin.SetString(smartkeyboardC4,'+ input +')')
			if smartkeyboardPN == '5': xbmc.executebuiltin('Skin.SetString(smartkeyboardC5,'+ input +')')
			xbmc.executebuiltin('SetFocus(3000)')
			
		elif smartkeyboardhistory:
			'''variable'''
			smartkeyboardHN = xbmc.getInfoLabel('Skin.String(smartkeyboardHN)')
			smartkeyboardH1 = xbmc.getInfoLabel('Skin.String(smartkeyboardH1)')
			smartkeyboardH2 = xbmc.getInfoLabel('Skin.String(smartkeyboardH2)')
			smartkeyboardH3 = xbmc.getInfoLabel('Skin.String(smartkeyboardH3)')
			smartkeyboardH4 = xbmc.getInfoLabel('Skin.String(smartkeyboardH4)')
			smartkeyboardH5 = xbmc.getInfoLabel('Skin.String(smartkeyboardH5)')
			'''execute'''
			xbmc.executebuiltin('Action(Close)')
			xbmc.sleep(200)
			#xbmc.executebuiltin('Action(
			if admin: xbmc.executebuiltin('Notification(Admin,smartkeyboardhistory,1000)')
			if smartkeyboardHN == '1': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH1 +'","done":false}}')
			if smartkeyboardHN == '2': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH2 +'","done":false}}')
			if smartkeyboardHN == '3': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH3 +'","done":false}}')
			if smartkeyboardHN == '4': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH4 +'","done":false}}')
			if smartkeyboardHN == '5': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH5 +'","done":false}}')
			xbmc.executebuiltin('SetFocus(3000)')
		elif smartkeyboardpaste:
			'''variable'''
			smartkeyboardPN = xbmc.getInfoLabel('Skin.String(smartkeyboardPN)')
			smartkeyboardC1 = xbmc.getInfoLabel('Skin.String(smartkeyboardC1)')
			smartkeyboardC2 = xbmc.getInfoLabel('Skin.String(smartkeyboardC2)')
			smartkeyboardC3 = xbmc.getInfoLabel('Skin.String(smartkeyboardC3)')
			smartkeyboardC4 = xbmc.getInfoLabel('Skin.String(smartkeyboardC4)')
			smartkeyboardC5 = xbmc.getInfoLabel('Skin.String(smartkeyboardC5)')
			'''execute'''
			xbmc.executebuiltin('Action(Close)')
			xbmc.sleep(200)
			if admin: xbmc.executebuiltin('Notification(Admin,smartkeyboardpaste,1000)')
			if smartkeyboardPN == '1': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC1 +'","done":false}}')
			if smartkeyboardPN == '2': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC2 +'","done":false}}')
			if smartkeyboardPN == '3': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC3 +'","done":false}}')
			if smartkeyboardPN == '4': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC4 +'","done":false}}')
			if smartkeyboardPN == '5': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC5 +'","done":false}}')
			xbmc.executebuiltin('SetFocus(3000)')
class main:
	homebuttonsrunnings('run')
	mac('run',macaddress)
	homebuttons('run')
	skinbuttons('run')
	helpbuttons('run')
	leftmenu('run')
	if netsettingsbutton: oewindow(admin,'netsettingsbutton')
	miscbuttons('run')
	autoviewoff = xbmc.getInfoLabel('Skin.HasSetting(AutoViewoff)')
	if myvideonav or mypics or mymusicnav or myprograms or settings or filemanager or myweather or dialogfavourites:
		if home_p and validation2: mac7('run',macaddress,maccon1,maccon2,maccon10,maccon11)
	if autoviewoff:
		if admin: xbmc.executebuiltin('Notification(Admin,AutoViewoff = false,1000)')
		xbmc.sleep(2000)
		xbmc.executebuiltin('Skin.ToggleSetting(AutoViewoff)')
	startup('run')
	refresh('run')
	homebuttonsrunnings('end')