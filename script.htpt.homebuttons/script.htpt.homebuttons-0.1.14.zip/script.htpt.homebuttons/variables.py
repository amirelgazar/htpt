#import xbmc, os, subprocess, sys
#import xbmc, xbmcgui, xbmcaddon
import xbmc, xbmcgui, xbmcaddon
import datetime
import sys

'''------------------------------
---script.htpt.homebuttons-------
------------------------------'''
getsetting         = xbmcaddon.Addon().getSetting
setsetting         = xbmcaddon.Addon().setSetting
addonName          = xbmcaddon.Addon().getAddonInfo("name")
addonString        = xbmcaddon.Addon().getLocalizedString

Kids_no1 = getsetting('Kids_no1')
Kids_no2 = getsetting('Kids_no2')
Kids_no3 = getsetting('Kids_no3')

'''------------------------------
---systemhasaddon----------------
------------------------------'''
systemhasaddon_urlresolver = xbmc.getCondVisibility('System.HasAddon(script.module.urlresolver)')
systemhasaddon_genesis = xbmc.getCondVisibility('System.HasAddon(plugin.video.genesis)')
systemhasaddon_sdarottv = xbmc.getCondVisibility('System.HasAddon(plugin.video.sdarot.tv)')
systemhasaddon_aob = xbmc.getCondVisibility('System.HasAddon(plugin.video.aob)')
systemhasaddon_fantasticc = xbmc.getCondVisibility('System.HasAddon(plugin.video.fantasticc)')
systemhasaddon_videodevil = xbmc.getCondVisibility('System.HasAddon(plugin.video.videodevil)')

'''---------------------------'''
systemhasaddon_htptemu = xbmc.getCondVisibility('System.HasAddon(script.htpt.emu)')
systemhasaddon_htptdebug = xbmc.getCondVisibility('System.HasAddon(script.htpt.debug)')

'''---------------------------'''
if systemhasaddon_genesis:
	'''------------------------------
	---plugin.video.genesis----------
	------------------------------'''
	getsetting_genesis          = xbmcaddon.Addon('plugin.video.genesis').getSetting
	setsetting_genesis          = xbmcaddon.Addon('plugin.video.genesis').setSetting

	realdedrid_user = getsetting_genesis('realdedrid_user')
	realdedrid_password = getsetting_genesis('realdedrid_password')
	trakt_user = getsetting_genesis('trakt_user')
	trakt_password = getsetting_genesis('trakt_password')
	movreel_user = getsetting_genesis('movreel_user')
	movreel_password = getsetting_genesis('movreel_password')
	noobroom_mail = getsetting_genesis('noobroom_mail')
	noobroom_password = getsetting_genesis('noobroom_password')
	premiumize_user = getsetting_genesis('premiumize_user')
	premiumize_password = getsetting_genesis('premiumize_password')
	'''---------------------------'''
	
if systemhasaddon_sdarottv:
	'''------------------------------
	---plugin.video.sdarot.tv--------
	------------------------------'''
	getsetting_sdarottv          = xbmcaddon.Addon('plugin.video.sdarot.tv').getSetting
	setsetting_sdarottv          = xbmcaddon.Addon('plugin.video.sdarot.tv').setSetting

	sdarottv_user = getsetting_sdarottv('username')
	sdarottv_password = getsetting_sdarottv('user_password')
	'''---------------------------'''

'''------------------------------
---Window.-----------------------
------------------------------'''
homeW = xbmc.getCondVisibility('Window.IsVisible(Home.xml)')
home_pW = xbmc.getCondVisibility('Window.Previous(0)')
home_aW = xbmc.getCondVisibility('Window.IsActive(0)')
dialogtextviewerW = xbmc.getCondVisibility('Window.IsVisible(DialogTextViewer.xml)')
mypicsW = xbmc.getCondVisibility('Window.IsVisible(MyPics.xml)')
mymusicnavW = xbmc.getCondVisibility('Window.IsVisible(MyMusicNav.xml)')
myvideonavW = xbmc.getCondVisibility('Window.IsVisible(MyVideoNav.xml)')
startupW = xbmc.getCondVisibility('Window.IsVisible(Startup.xml)')
startup_aW = xbmc.getCondVisibility('Window.IsActive(Startup.xml)')
startup_pW = xbmc.getCondVisibility('Window.Previous(Startup.xml)')
videofullscreenW = xbmc.getCondVisibility('Window.IsVisible(VideoFullScreen.xml)')
dialogvideoinfoW = xbmc.getCondVisibility('Window.IsVisible(DialogVideoInfo.xml)')
dialogselectW = xbmc.getCondVisibility('Window.IsVisible(DialogSelect.xml)')
dialogbusyW = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
dialogsubtitlesW = xbmc.getCondVisibility('Window.IsVisible(DialogSubtitles.xml)')
custom1170W = xbmc.getCondVisibility('Window.IsVisible(Custom1170.xml)')
custom1191W = xbmc.getInfoLabel('Skin.String(custom1191)')
settingsW = xbmc.getCondVisibility('Window.IsVisible(Settings.xml)')
myprogramsW = xbmc.getCondVisibility('Window.IsVisible(MyPrograms.xml)')
filemanagerW = xbmc.getCondVisibility('Window.IsVisible(FileManager.xml)')
loginscreenW = xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)')
loginscreen_aW = xbmc.getCondVisibility('Window.IsActive(LoginScreen.xml)')
myweatherW = xbmc.getCondVisibility('Window.IsVisible(MyWeather.xml)')
dialogfavouritesW = xbmc.getCondVisibility('Window.IsVisible(DialogFavourites.xml)')
skinsettingsW = xbmc.getCondVisibility('Window.IsVisible(SkinSettings.xml)')
dialogprogressW = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
dialogselectW = xbmc.getCondVisibility('Window.IsVisible(DialogSelect.xml)')
dialogokW = xbmc.getCondVisibility('Window.IsVisible(DialogOk.xml)')
custom1170W = xbmc.getCondVisibility('Window.IsVisible(Custom1170.xml)')
custom1115W = xbmc.getCondVisibility('Window.IsVisible(Custom1115.xml)')
custom1124W = xbmc.getCondVisibility('Window.IsVisible(Custom1124.xml)')
custom1125W = xbmc.getCondVisibility('Window.IsVisible(Custom1125.xml)')

'''------------------------------
---HOME-BUTTONS------------------
------------------------------'''
moviesbutton = xbmc.getCondVisibility('Container(9000).HasFocus(340)') and not xbmc.getCondVisibility('Control.HasFocus(9090)')
tvshowsbutton = xbmc.getCondVisibility('Container(9000).HasFocus(341)') and not xbmc.getCondVisibility('Control.HasFocus(9090)')
israeltvbutton = xbmc.getCondVisibility('Container(9000).HasFocus(342)')
youtubebutton = xbmc.getCondVisibility('Container(9000).HasFocus(343)')
goprobutton = xbmc.getCondVisibility('Container(9000).HasFocus(344)')
moviesebutton = xbmc.getCondVisibility('Container(9000).HasFocus(320)')
tvshowsebutton = xbmc.getCondVisibility('Container(9000).HasFocus(321)')
weatherbutton = xbmc.getCondVisibility('Container(9000).HasFocus(345)')
picturesbutton = xbmc.getCondVisibility('Container(9000).HasFocus(507)')
gamesbutton = xbmc.getCondVisibility('Container(9000).HasFocus(323)')
trailers2button = xbmc.getCondVisibility('Container(9000).HasFocus(351)')
quizbutton = xbmc.getCondVisibility('Container(9000).HasFocus(509)')
videosbutton = xbmc.getCondVisibility('Container(9000).HasFocus(325)')
musicbutton = xbmc.getCondVisibility('Container(9000).HasFocus(508)')
kidsbutton = xbmc.getCondVisibility('Container(9000).HasFocus(322)')
mov3dsbutton = xbmc.getCondVisibility('Container(9000).HasFocus(324)')
internetbutton = xbmc.getCondVisibility('Container(9000).HasFocus(327)')
gadgetbutton = xbmc.getCondVisibility('Container(9000).HasFocus(328)')
karaokebutton = xbmc.getCondVisibility('Container(9000).HasFocus(326)')
gametrailersbutton = xbmc.getCondVisibility('Container(9000).HasFocus(329)')
guitarbutton = xbmc.getCondVisibility('Container(9000).HasFocus(330)')
adultbutton2 = xbmc.getCondVisibility('Container(9000).HasFocus(331)')
favouritesbutton = xbmc.getCondVisibility('Container(9000).HasFocus(352)')
livetvbutton = xbmc.getCondVisibility('Container(9000).HasFocus(355)')
radiobutton = xbmc.getCondVisibility('Container(9000).HasFocus(356)')
settingsbutton = xbmc.getCondVisibility('Container(9000).HasFocus(348)')
htptchannelbutton = xbmc.getCondVisibility('Container(9000).HasFocus(375)')
adult2button = xbmc.getCondVisibility('Container(9000).HasFocus(331)')
widgettogglebutton = xbmc.getCondVisibility('Control.HasFocus(9090)')
test2button = xbmc.getCondVisibility('Container(9000).HasFocus(371)')

'''------------------------------
---CUSTOM-BUTTONS----------------
------------------------------'''
button101 = xbmc.getCondVisibility('Control.HasFocus(101)') #xbmc.getCondVisibility('Container(9000).HasFocus(101)')
button102 = xbmc.getCondVisibility('Control.HasFocus(102)') #xbmc.getCondVisibility('Container(9000).HasFocus(101)')


'''OTHERS BUTTONS'''
adultbutton = xbmc.getCondVisibility('Container(50).HasFocus(49)')
formatbutton = xbmc.getCondVisibility('Container(50).HasFocus(92)')
fixipbutton = xbmc.getCondVisibility('Container(50).HasFocus(116)')
trakttvbutton = xbmc.getCondVisibility('Container(50).HasFocus(94)')
sdarottvbutton = xbmc.getCondVisibility('Container(50).HasFocus(95)')
noobroombutton = xbmc.getCondVisibility('Container(50).HasFocus(96)')
premiumizebutton = xbmc.getCondVisibility('Container(50).HasFocus(97)')
movreelbutton = xbmc.getCondVisibility('Container(50).HasFocus(98)')
movreelbutton = xbmc.getCondVisibility('Container(50).HasFocus(98)')
realdebridbutton = xbmc.getCondVisibility('Container(50).HasFocus(99)')
userdataresetbutton = xbmc.getCondVisibility('Container(50).HasFocus(80)')
paymentmethodbutton = xbmc.getCondVisibility('Container(50).HasFocus(106)')
id60button = xbmc.getCondVisibility('Container(50).HasFocus(160)')
loginscreenbutton = (xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(100)'))
subsliderbutton = (xbmc.getCondVisibility('Window.IsVisible(DialogSubtitles.xml)') and xbmc.getCondVisibility('Control.HasFocus(73)'))
smartsearchbutton = (xbmc.getCondVisibility('Window.IsVisible(DialogSubtitles.xml)') and xbmc.getCondVisibility('Control.HasFocus(161)'))
#button = xbmc.getCondVisibility('Container(9000).HasFocus(?)')
#button = xbmc.getCondVisibility('Container(9000).HasFocus(?)')
#button = xbmc.getCondVisibility('Container(9000).HasFocus(?)')
#button = xbmc.getCondVisibility('Container(9000).HasFocus(?)')
'''SETTINGS'''
netsettingsbutton = (xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(108)')) or xbmc.getCondVisibility('Container(52).HasFocus(40)') or (xbmc.getCondVisibility('Window.IsVisible(Custom1170.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(10)'))
settinglevelbutton = xbmc.getCondVisibility('Control.HasFocus(20)')
'''HELP'''
airplaybutton = xbmc.getCondVisibility('Container(50).HasFocus(1)')
messagebutton = xbmc.getCondVisibility('Container(50).HasFocus(2)')
resetnetworkbutton = xbmc.getCondVisibility('Container(50).HasFocus(10)')
debugbutton = xbmc.getCondVisibility('Container(50).HasFocus(5)') or (xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(102)'))
#button = xbmc.getCondVisibility('Container(9000).HasFocus(?)')
'''LEFT MENU'''
searchisraeltv = xbmc.getCondVisibility('Control.HasFocus(107)')
deletesearchyoutube = xbmc.getCondVisibility('Control.HasFocus(109)')
statusjoystick = xbmc.getCondVisibility('Control.HasFocus(100)')
allowjoystick = xbmc.getCondVisibility('Control.HasFocus(102)')
leftmenubutton110 = xbmc.getCondVisibility('Control.HasFocus(110)')
usbtoggle = xbmc.getCondVisibility('Control.HasFocus(70)')
numinumibutton = xbmc.getCondVisibility('Control.HasFocus(110)')

'''------------------------------
---DEFAULT-----------------------
------------------------------'''
printfirst = addonName + ": !@# "
space = " "
space2 = ": "
space3 = "_"
dialog = xbmcgui.Dialog()
systemplatformwindows = xbmc.getCondVisibility('system.platform.windows')
systemidle3 = xbmc.getCondVisibility('System.IdleTime(3)')
systemidle10 = xbmc.getCondVisibility('System.IdleTime(10)')
systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
systemcurrentwindow = xbmc.getInfoLabel('System.CurrentWindow')

'''------------------------------
---Skin.HasSetting---------------
------------------------------'''
admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
admin2 = xbmc.getInfoLabel('Skin.HasSetting(Admin2)')
autoviewoff = xbmc.getInfoLabel('Skin.HasSetting(AutoViewoff)')
myhtpt2 = xbmc.getInfoLabel('Skin.HasSetting(myHTPT2)')
myhtpt3 = xbmc.getInfoLabel('Skin.HasSetting(myHTPT3)')
homebuttonsrunning = xbmc.getInfoLabel('Skin.HasSetting(homebuttonsrunning)')
connected = xbmc.getInfoLabel('Skin.HasSetting(Connected)')
connected2 = xbmc.getInfoLabel('Skin.HasSetting(Connected2)')
connected3 = xbmc.getInfoLabel('Skin.HasSetting(Connected3)')
autoplaysd = xbmc.getInfoLabel('Skin.HasSetting(AutoPlaySD)')
autoplaypause = xbmc.getInfoLabel('Skin.HasSetting(AutoPlay_Pause)')
validation = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION)')
validation2 = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION2)')
validation5 = xbmc.getInfoLabel('Skin.String(VALIDATION5)')
widget = xbmc.getInfoLabel('Skin.HasSetting(Widget)')
adult = xbmc.getInfoLabel('Skin.HasSetting(Adult)')
adult2 = xbmc.getInfoLabel('Skin.HasSetting(Adult2)')
'''------------------------------
---ACCOUNTS----------------------
------------------------------'''
Account1_Active = xbmc.getInfoLabel('Skin.HasSetting(Account1_Active)')
Account1_Period = xbmc.getInfoLabel('Skin.String(Account1_Period)')
Account1_EndDate = xbmc.getInfoLabel('Skin.String(Account1_EndDate)')
Account2_Active = xbmc.getInfoLabel('Skin.HasSetting(Account2_Active)')
Account2_Period = xbmc.getInfoLabel('Skin.String(Account2_Period)')
Account2_EndDate = xbmc.getInfoLabel('Skin.String(Account2_EndDate)')
Account3_Active = xbmc.getInfoLabel('Skin.HasSetting(Account3_Active)')
Account3_Period = xbmc.getInfoLabel('Skin.String(Account3_Period)')
Account3_EndDate = xbmc.getInfoLabel('Skin.String(Account3_EndDate)')
Account4_Active = xbmc.getInfoLabel('Skin.HasSetting(Account4_Active)')
Account4_Period = xbmc.getInfoLabel('Skin.String(Account4_Period)')
Account4_EndDate = xbmc.getInfoLabel('Skin.String(Account4_EndDate)')
Account5_Active = xbmc.getInfoLabel('Skin.HasSetting(Account5_Active)')
Account5_Period = xbmc.getInfoLabel('Skin.String(Account5_Period)')
Account5_EndDate = xbmc.getInfoLabel('Skin.String(Account5_EndDate)')

Account10_Active = xbmc.getInfoLabel('Skin.HasSetting(Account10_Active)')
'''------------------------------
---System.-----------------------
------------------------------'''
systeminternetstate = xbmc.getInfoLabel('System.InternetState')
systemuptime = xbmc.getInfoLabel('System.Uptime')
systemuptime5 = xbmc.getCondVisibility('!IntegerGreaterThan(System.Uptime,5)')
systemtotaluptime = xbmc.getInfoLabel('System.TotalUptime')
systemcputemperature = xbmc.getInfoLabel('System.CPUTemperature')
screenresolution = xbmc.getInfoLabel('System.ScreenResolution')
dhcpaddress = xbmc.getInfoLabel('Network.DHCPAddress')
macaddress = xbmc.getInfoLabel('Network.MacAddress')
systemuptime2 = xbmc.getInfoLabel('System.Uptime') + " / " + xbmc.getInfoLabel('System.TotalUptime') 
freespace2 = xbmc.getInfoLabel('System.TotalSpace') + " / " + xbmc.getInfoLabel('System.FreeSpacePercent')
if xbmc.getCondVisibility('System.HasAddon(service.htpt)'): htptversion = xbmc.getInfoLabel('System.AddonVersion(skin.htpt)') + "+"
elif xbmc.getCondVisibility('!System.HasAddon(service.htpt)'): htptversion = xbmc.getInfoLabel('System.AddonVersion(skin.htpt)') + "-"
buildversion = xbmc.getInfoLabel('System.BuildVersion')
htptdebugversion = xbmc.getInfoLabel('System.AddonVersion(script.htpt.debug)')
htptserviceversion = xbmc.getInfoLabel('system.AddonVersion(service.htpt)')
htpthelpversion = xbmc.getInfoLabel('System.AddonVersion(service.htpt.help)')
htpthomebuttonsversion = xbmc.getInfoLabel('System.AddonVersion(script.htpt.homebuttons)')
htptremoteversion = xbmc.getInfoLabel('System.AddonVersion(script.htpt.remote)')
htptrefreshversion = xbmc.getInfoLabel('System.AddonVersion(script.htpt.refresh)')
htptfixversion = xbmc.getInfoLabel('System.AddonVersion(service.htpt.fix)')
htptskinversion = xbmc.getInfoLabel('System.AddonVersion(skin.htpt)')

'''------------------------------
---DATES-----------------------
------------------------------'''	
datenow = datetime.date.today()
datenowS = str(datenow)
daynow = datenow.strftime("%a")
daynowS = str(daynow)
timenow = datetime.datetime.now()
timenow2 = timenow.strftime("%H:%M")
timenow3 = timenow.strftime("%H")
timenow2S = str(timenow2)
timenow3S = str(timenow3)
timenow3N = int(timenow3S)
#timenow = datenow.strftime("%I:%M:%S %p")
if timenow3N > 03 and timenow3N < 12: timezone = "A"
elif timenow3N > 11 and timenow3N < 20: timezone = "B"
elif timenow3N > 19 or timenow3N < 04: timezone = "C"
if admin: print printfirst + datenowS + space + daynowS + space + timenow2S + space + "timezone: " + timezone

'''------------------------------
---CONTAINER---------------------
------------------------------'''
containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
containerfoldername = xbmc.getInfoLabel('Container.FolderName')
container50position = xbmc.getInfoLabel('Container(50).Position')
container120numitems = xbmc.getInfoLabel('Container(120).NumItems') #DialogSubtitles
containernumitems = xbmc.getInfoLabel('Container.NumItems')
viewmode = xbmc.getInfoLabel('Container.Viewmode')




'''------------------------------
---Network.----------------------
------------------------------'''
networkgatewayaddress = xbmc.getInfoLabel('Network.GatewayAddress')
networkipaddress = xbmc.getInfoLabel('Network.IPAddress')
'''------------------------------
---VIDEO-------------------------
------------------------------'''
playerhasvideo = xbmc.getCondVisibility('Player.HasVideo')
playerpaused = xbmc.getCondVisibility('Player.Paused')
videoplayerhassubtitles = xbmc.getCondVisibility('VideoPlayer.HasSubtitles')
playercache = xbmc.getInfoLabel('Player.CacheLevel')
playertitle = xbmc.getInfoLabel('Player.Title')
playerhasmedia = xbmc.getCondVisibility('Player.HasMedia')
'''---------------------------'''	
playertime = xbmc.getInfoLabel("Player.Time(hh)") + xbmc.getInfoLabel("Player.Time(mm)") + xbmc.getInfoLabel("Player.Time(ss)")
playertimeremaining = xbmc.getInfoLabel("Player.TimeRemaining(hh)") + xbmc.getInfoLabel("Player.TimeRemaining(mm)") + xbmc.getInfoLabel("Player.TimeRemaining(ss)")
playerduration = xbmc.getInfoLabel("Player.Duration(hh)") + xbmc.getInfoLabel("Player.Duration(mm)") + xbmc.getInfoLabel("Player.Duration(ss)")

'''---------------------------'''
playlistlength = xbmc.getInfoLabel('Playlist.Length(video)')
playlistlengthN = int(playlistlength)
playlistposition = xbmc.getInfoLabel('Playlist.Position(video)')
playlistpositionN = int(playlistposition)
'''---------------------------'''
videoplayertitle = xbmc.getInfoLabel('VideoPlayer.Title')
videoplayerseason = xbmc.getInfoLabel('VideoPlayer.Season')
videoplayertvshowtitle = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
videoplayeryear = xbmc.getInfoLabel('VideoPlayer.Year')
videoplayertagline = xbmc.getInfoLabel('VideoPlayer.Tagline')
videoplayercountry = xbmc.getInfoLabel('VideoPlayer.Country')
videoplayerseason = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
#videoplayerseason = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
#videoplayerseason = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
#videoplayerseason = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
videoplayercontentMOVIE = xbmc.getCondVisibility('VideoPlayer.Content(movies)')
videoplayercontentTV = xbmc.getCondVisibility('VideoPlayer.Content(tvshows)')
videoplayercontentSEASON = xbmc.getCondVisibility('VideoPlayer.Content(seasons)')
videoplayercontentEPISODE = xbmc.getCondVisibility('VideoPlayer.Content(episodes)')

'''------------------------------
---SKIN STRINGS-------------
------------------------------'''
listitemtvshowtitlestr = xbmc.getInfoLabel('Skin.String(ListItemTVShowTitle)')
listitemseason = xbmc.getInfoLabel('ListItem.Season')
listitemepisode = xbmc.getInfoLabel('ListItem.Episode')
listitemgenrestr = xbmc.getInfoLabel('Skin.String(ListItemGenre)')
listitemdurationstr = xbmc.getInfoLabel('Skin.String(ListItemDuration)')
listitemratingstr = xbmc.getInfoLabel('Skin.String(ListItemRating)')
listitemyearstr = xbmc.getInfoLabel('Skin.String(ListItemYear)')
settingslevel = xbmc.getInfoLabel('Skin.String(SettingsLevel)')
musiclinkstr = xbmc.getInfoLabel('Skin.String(MusicLink)')

'''------------------------------
---LIBRARY.----------------------
------------------------------'''
libraryhascontentmusic = xbmc.getCondVisibility('Library.HasContent(Music)')

'''------------------------------
---LISTITEM----------------------
------------------------------'''
listitempath = xbmc.getInfoLabel('ListItem.Path')

'''------------------------------
---PATH--------------------------
------------------------------'''
israeltvhome = 'plugin://plugin.video.sdarot.tv/'
videorootpath = 'library://video/'

'''------------------------------
---CUSTOM-------------
------------------------------'''
test = xbmc.getInfoLabel('Skin.String(Test)')
airplaycon1 = xbmc.getCondVisibility('SubString(System.CurrentControl,AirPlay)')
airplaycon2 = xbmc.getCondVisibility('System.GetBool(services.airplay)')
airplaycon3 = xbmc.getCondVisibility('System.GetBool(services.zeroconf)')
allowjoystickcon2 = xbmc.getCondVisibility('SubString(System.CurrentControl,$LOCALIZE[35100])')
vhomecon1 = xbmc.getCondVisibility('!Container(9000).HasFocus(348)') and xbmc.getCondVisibility('!Container(9000).HasFocus(323)') and xbmc.getCondVisibility('!Container(9000).HasFocus(340)') and xbmc.getCondVisibility('!Container(9000).HasFocus(341)') and xbmc.getCondVisibility('!Container(9000).HasFocus(325)') and xbmc.getCondVisibility('!Container(9000).HasFocus(346)') and xbmc.getCondVisibility('!Container(9000).HasFocus(507)') and xbmc.getCondVisibility('!Container(9000).HasFocus(508)') and xbmc.getCondVisibility('!Container(9000).HasFocus(509)')
maccon1 = xbmc.getCondVisibility('StringCompare(Skin.String(MAC),Skin.String(MAC1))')
maccon2 = xbmc.getCondVisibility('StringCompare(Skin.String(MAC),Skin.String(MAC2))')
maccon10 = xbmc.getCondVisibility('StringCompare(Control.GetLabel(700100),NONE)')
maccon11 = xbmc.getCondVisibility('StringCompare(Control.GetLabel(700100),7000)')

dialogselectsources = xbmc.getInfoLabel('Skin.String(DialogSelectSources)')
dialogselectsources2 = xbmc.getInfoLabel('Skin.String(DialogSelectSources2)')
dialogselectsources3 = xbmc.getInfoLabel('Skin.String(DialogSelectSources3)')
dialogselectsources5 = xbmc.getInfoLabel('Skin.String(DialogSelectSources5)')

dialogsubtitles2 = xbmc.getInfoLabel('Skin.String(DialogSubtitles2)')
dialogsubtitlesna1 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA1)')
dialogsubtitlesna2 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA2)')
dialogsubtitlesna3 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA3)')
dialogsubtitlesna4 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA4)')
dialogsubtitlesna5 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA5)')
dialogsubtitlesna6 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA6)')
dialogsubtitlesna7 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA7)')
dialogsubtitlesna8 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA8)')
dialogsubtitlesna9 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA9)')
dialogsubtitlesna10 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA10)')


'''------------------------------
---MIXED-------------------------
------------------------------'''
maccheck = xbmc.getInfoLabel('Network.MacAddress') + " ( " + xbmc.getInfoLabel('Skin.String(MAC1)') + " / " + xbmc.getInfoLabel('Skin.String(MAC2)') + " )"
if homeW: container9000pos = xbmc.getInfoLabel('Container(9000).Position')
istv = (xbmc.getInfoLabel('ListItem.TVShowTitle') != "" and xbmc.getInfoLabel('ListItem.Season') != "" and xbmc.getInfoLabel('ListItem.Episode') != "") or ("videodb://tvshows" in containerfolderpath or "library://video/tvshows" in containerfolderpath)
istvS = str(istv)
ismovie = (xbmc.getInfoLabel('ListItem.Year') != "" or xbmc.getInfoLabel('ListItem.Country') != "" or xbmc.getInfoLabel('ListItem.Tagline') != "") and not istv
ismovieS = str(ismovie)
istv4 = " S" in dialogselectsources3 and " E" in dialogselectsources3
istv4S = str(istv4)
ismovie4 = " (" in dialogselectsources3 and ")" in dialogselectsources3 and not istv4
ismovie4S = str(ismovie4)
istvmoviep = (videoplayertitle in dialogselectsources3 or videoplayertitle in dialogselectsources5)
isgenesis = "videodb://tvshows" in containerfolderpath or "library://video/tvshows" in containerfolderpath or "plugin://plugin.video.genesis/" in containerfolderpath
hasinternet = systeminternetstate != "" and networkipaddress != "" and (connected or systemplatformwindows)
'''------------------------------
---CONTROL-----------------------
------------------------------'''
cancelbutton = xbmc.getCondVisibility('Control.HasFocus(10)') and xbmc.getCondVisibility('Window.IsActive(DialogProgress.xml)')
autoplaypausebutton = (xbmc.getCondVisibility('Window.IsVisible(Home.xml)') and xbmc.getCondVisibility('Control.HasFocus(9093)')) or (xbmc.getCondVisibility('Window.IsVisible(MyVideoNav.xml)') and xbmc.getCondVisibility('Control.HasFocus(111)'))
debugbutton = xbmc.getCondVisibility('Container(50).HasFocus(5)') or (xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(102)'))
controlisvisible311 = xbmc.getCondVisibility('Control.IsVisible(311)') or xbmc.getCondVisibility('Control.HasFocus(340)')
controlisvisible311S = str(controlisvisible311)
controlisvisible312 = xbmc.getCondVisibility('Control.IsVisible(312)') or xbmc.getCondVisibility('Control.HasFocus(341)')
controlisvisible312S = str(controlisvisible312)
controlgetlabel100 = xbmc.getInfoLabel('Control.GetLabel(100)') #DialogSubtitles Service Name
var700100 = xbmc.getInfoLabel('Control.GetLabel(700100)')

	
'''------------------------------
---$LOCALIZE--------------------
------------------------------'''
truestr = xbmc.getInfoLabel('$LOCALIZE[20122]')
cancelstr = xbmc.getInfoLabel('$LOCALIZE[222]')
trialstr = xbmc.getInfoLabel('$LOCALIZE[70001]')
trial2str = xbmc.getInfoLabel('$LOCALIZE[70002]')
verrorstr = xbmc.getInfoLabel('$VAR[VERROR]')
id6v1str = xbmc.getInfoLabel('$LOCALIZE[70014]')
id6v2str = xbmc.getInfoLabel('$LOCALIZE[70015]')
id6v3str = xbmc.getInfoLabel('$LOCALIZE[70016]')
airplaystr1 = xbmc.getInfoLabel('$LOCALIZE[1273]')
airplaystr2 = 'AirPlay'
airplaystr3 = xbmc.getInfoLabel('$LOCALIZE[1270]')
airplaystr4 = xbmc.getInfoLabel('Skin.String(AirPlay2)')
busystr = xbmc.getInfoLabel('$LOCALIZE[503]')
numinumistr = xbmc.getInfoLabel('$LOCALIZE[79068]')
settingslevelstr1 = xbmc.getInfoLabel('$LOCALIZE[10036]')
settingslevelstr2 = xbmc.getInfoLabel('$LOCALIZE[10037]')
var70000 = xbmc.getInfoLabel('$LOCALIZE[70000]')
'''------------------------------
---ID----------------------------
------------------------------'''
'''idstr = USERNAME EN , id1str = USERNAME HE, id2str = INSTALLATION DATE, id3str = WARRENTY END, id4str = ADDRESS, id5str = TELEPHONE NUMBER, id6str = PAYMENT TERMS, id7str = QUESTION, id8str = TECHNICAL NAME, id9str = CODE RED, id10str = HTPT'S MODEL, ID11 = MAC1, ID12 = MAC2'''
idstr = xbmc.getInfoLabel('Skin.String(ID)')
id1str = xbmc.getInfoLabel('Skin.String(ID1)')
id2str = xbmc.getInfoLabel('Skin.String(ID2)')
id3str = xbmc.getInfoLabel('Skin.String(ID3)')
id4str = xbmc.getInfoLabel('Skin.String(ID4)')
id5str = xbmc.getInfoLabel('Skin.String(ID5)')
id6str = xbmc.getInfoLabel('Skin.String(ID6)')
id7str = xbmc.getInfoLabel('Skin.String(ID7)')
id8str = xbmc.getInfoLabel('Skin.String(ID8)')
id9str = xbmc.getInfoLabel('Skin.String(ID9)')
id10str = xbmc.getInfoLabel('Skin.String(ID10)')
id11str = xbmc.getInfoLabel('Skin.String(ID11)')
id12str = xbmc.getInfoLabel('Skin.String(ID12)')
id60str = xbmc.getInfoLabel('Skin.String(ID60)')
''''''
idnamestr = xbmc.getInfoLabel('$LOCALIZE[1014]')
id2namestr = xbmc.getInfoLabel('$LOCALIZE[70010]')
id3namestr = xbmc.getInfoLabel('$LOCALIZE[70011]')
id4namestr = xbmc.getInfoLabel('$LOCALIZE[19115]')
id5namestr = xbmc.getInfoLabel('$LOCALIZE[75006]')
id6namestr = xbmc.getInfoLabel('$LOCALIZE[70012]')
id60namestr = xbmc.getInfoLabel('$LOCALIZE[70012]')
id7namestr = 'Question'
id8namestr = xbmc.getInfoLabel('$LOCALIZE[70013]')
id9namestr = 'CODE RED'
id10namestr = xbmc.getInfoLabel('$LOCALIZE[79031]')
id11namestr = 'MAC1 (LAN)'
id12namestr = 'MAC2 (WLAN)'
''''''
fixip = xbmc.getInfoLabel('Skin.String(fixip)')
trial = xbmc.getInfoLabel('Skin.HasSetting(Trial)')
trial2 = xbmc.getInfoLabel('Skin.HasSetting(Trial2)')
trialdate = xbmc.getInfoLabel('Skin.String(TrialDate)')
trialdate2 = xbmc.getInfoLabel('Skin.String(TrialDate2)')

idtrial = 'htptuser'
#idtrial = 'htptuser27'
idpstr = xbmc.getInfoLabel('$LOCALIZE[79246]')
#idp2str = xbmc.getInfoLabel('$LOCALIZE[79246]')
idp2str = xbmc.getInfoLabel('$LOCALIZE[79247]')

mac1str = xbmc.getInfoLabel('Skin.String(MAC1)')
mac2str = xbmc.getInfoLabel('Skin.String(MAC2)')
mac3str = xbmc.getInfoLabel('Skin.String(MAC3)')
verrorstr = xbmc.getInfoLabel('$VAR[VERROR]')
usb1str = xbmc.getInfoLabel('Skin.String(USB1)')
usb2str = xbmc.getInfoLabel('Skin.String(USB2)')
usb3str = xbmc.getInfoLabel('Skin.String(USB3)')
usb4str = xbmc.getInfoLabel('Skin.String(USB4)')
usb5str = xbmc.getInfoLabel('Skin.String(USB5)')