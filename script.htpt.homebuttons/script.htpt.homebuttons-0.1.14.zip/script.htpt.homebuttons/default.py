import xbmc
import os, sys
import subprocess
import xbmcgui, xbmcaddon

from variables import *
from modules import *
from modules2 import *

def addonsettingall(run):
	
	if systemhasaddon_sdarottv:
		'''------------------------------
		---plugin.video.sdarot.tv--------
		------------------------------'''
		addonsettings('SDAROT TV', 'plugin.video.sdarot.tv', 'Account2_Active', 'Account2_Period', 'username','user_password', "", "", "", "")
		addonsettings2('plugin.video.sdarot.tv','DEBUG',"false",'cache',"24",'domain',"http://www.sdarot.wf",'',"",'',"")
	
		if not systemplatformwindows: bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.video.sdarot.tv/sdarot-cookiejar.txt',"plugin.video.sdarot.tv")
		'''---------------------------'''
	else:
		print printfirst + space + "addonsettingall" + space2 + "Addon is missing! - " + "plugin.video.sdarot.tv"
		'''---------------------------'''
	
	try:
		'''------------------------------
		---service.subtitles.subtitle----
		------------------------------'''
		addonsettings2('service.subtitles.subtitle','SUBemail',idstr + "@gmail.com",'SUBpassword',idpstr,'',"",'',"",'',"")
		if not systemplatformwindows: bash('rm -rf /storage/.kodi/userdata/addon_data/service.subtitles.subtitle/cookiejar.txt',"service.subtitles.subtitle")
		'''---------------------------'''
	except:
		print printfirst + space + "addonsettingall" + space2 + "Addon is missing! - " + "service.subtitles.subtitle"
		'''---------------------------'''
			
	try:
		'''------------------------------
		---plugin.video.israelive--------
		------------------------------'''
		addonsettings2('plugin.video.israelive','useIPTV',"false",'useEPG',"true",'StreramProtocol',"1",'forceRemoteDefaults',"true",'StreramsMethod',"0")
		addonsettings2('plugin.video.israelive','catColor',"chartreuse",'useEPG',"true",'chColor',"yellow",'prColor',"floralwhite",'timesColor',"none")
		'''---------------------------'''
	except:
		print printfirst + space + "addonsettingall" + space2 + "Addon is missing! - " + "plugin.video.israelive"
		'''---------------------------'''
		
	try:
		'''------------------------------
		---plugin.video.youtube----------
		------------------------------'''
		addonsettings2('plugin.video.youtube','kodion.view.override',"true",'kodion.video.quality',"4",'kodion.view.default',"50",'kodion.view.episodes',"58",'kodion.search.size',"4")
		addonsettings2('plugin.video.youtube','kodion.setup_wizard',"false",'youtube.folder.disliked_videos.show',"false",'youtube.language',"iw-IL",'kodion.fanart.show',"false",'youtube.folder.sign.in.show',"true")
		if not systemplatformwindows: bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.video.youtube/kodion/cache.sqlite',"plugin.video.youtube")
		'''---------------------------'''
	except:
		print printfirst + space + "addonsettingall" + space2 + "Addon is missing! - " + "plugin.video.youtube"
		'''---------------------------'''
		
	try:
		'''------------------------------
		---service.autosubs--------------
		------------------------------'''
		pass
		#addonsettings2('service.autosubs','check_for_specific',"true",'selected_language',"Hebrew",'debug',"false",'ExcludeTime',"15",'ignore_words',"theme")
		#addonsettings2('service.autosubs','ExcludeHTTP',"false",'ExcludeLiveTV',"true",'',"",'',"",'',"")
		'''---------------------------'''
	except:
		print printfirst + space + "addonsettingall" + space2 + "Addon is missing! - " + "service.autosubs"
		'''---------------------------'''
	
	if systemhasaddon_aob:
		'''------------------------------
		---plugin.video.aob--------------
		------------------------------'''
		addonsettings2('plugin.video.aob','tvshows-view',"58",'default-view',"50",'auto-view',"true",'',"",'',"")
		'''---------------------------'''
	else:
		print printfirst + space + "addonsettingall" + space2 + "Addon is missing! - " + "plugin.video.aob"
		'''---------------------------'''
		
	'''------------------------------
	---script.htpt.homebuttons-------
	------------------------------'''	
	dialogtextviewerW = xbmc.getCondVisibility('Window.IsVisible(DialogTextViewer.xml)')
	while dialogtextviewerW and not xbmc.abortRequested:
		xbmc.sleep(1000)
		dialogtextviewerW = xbmc.getCondVisibility('Window.IsVisible(DialogTextViewer.xml)')
		'''---------------------------'''
	set_accountdate('REALDEBRID','plugin.video.genesis', 'realdedrid_user', 'realdedrid_password', realdedrid_user, realdedrid_password, 'Account1_Active', 'Account1_Period', 'Account1_EndDate', Account1_Active, Account1_Period, Account1_EndDate, "1")
	set_accountdate('SDAROT TV','plugin.video.sdarot.tv', 'username', 'user_password', sdarottv_user, sdarottv_password, 'Account2_Active', 'Account2_Period', 'Account2_EndDate', Account2_Active, Account2_Period, Account2_EndDate, "1")
	'''---------------------------'''

def skinsettingsall(run):
	if not adult2: setSkinSetting("1",'adult',"false")
def homebuttons(run):
	'''activate home buttons'''
	if not validation and homeW:
		if moviesbutton:
			libraryhascontentmovies = xbmc.getCondVisibility('Library.HasContent(Movies)')
			if libraryhascontentmovies:
				if admin: xbmc.executebuiltin('Notification(Admin,moviesbutton,1000)')
				xbmc.executebuiltin('ActivateWindow(Videos,MovieTitles,return)')
			else:
				if not autoviewoff: xbmc.executebuiltin('Skin.ToggleSetting(AutoViewoff)')
				xbmc.executebuiltin('ActivateWindow(video,"special://userdata/library/movies/",return)')
				xbmc.executebuiltin('Notification($LOCALIZE[79079] $LOCALIZE[342] $LOCALIZE[79090],$LOCALIZE[79091],4000)')
				'''---------------------------'''
		elif tvshowsbutton:
			libraryhascontenttvshows = xbmc.getCondVisibility('Library.HasContent(TVShows)')
			if libraryhascontenttvshows:
				if admin: xbmc.executebuiltin('Notification(Admin,tvshowsbutton,1000)')
				xbmc.executebuiltin('ActivateWindow(VideoLibrary,TVShowTitles,return)')
			else:
				if not autoviewoff: xbmc.executebuiltin('Skin.ToggleSetting(AutoViewoff)')
				xbmc.executebuiltin('ActivateWindow(video,"special://userdata/library/tvshows/",return)')
				xbmc.executebuiltin('Notification($LOCALIZE[79079] $LOCALIZE[20343] $LOCALIZE[79090],$LOCALIZE[79091],4000)')
				'''---------------------------'''
		elif gamesbutton:
			'''------------------------------
			---GAMES-BUTTON------------------
			------------------------------'''
			gamesbutton_(admin)
			'''---------------------------'''
		elif picturesbutton or videosbutton:
			'''------------------------------
			---PICTURE-&-VIDEO-BUTTON--------
			------------------------------'''
			if picturesbutton:
				'''------------------------------
				---PICTURE--BUTTON---------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,picturesbutton,1000)')
				xbmc.executebuiltin('ActivateWindow(Pictures,special://userdata/library/pictures/,return)')
				if not admin and not playerhasmedia: xbmc.executebuiltin('PlayMedia(special://userdata/addon_data/skin.htpt/music/playHTPT.mp3)')
				'''---------------------------'''
			if videosbutton:
				'''------------------------------
				---VIDEO-BUTTON------------------
				------------------------------'''
				xbmc.executebuiltin('ActivateWindow(Video,special://userdata/library/videos/,return)')
				'''---------------------------'''
			externalusb('run')
			'''---------------------------'''
		elif favouritesbutton:
			if admin: xbmc.executebuiltin('Notification(Admin,favouritesbutton,1000)')
			xbmc.executebuiltin('ActivateWindow(134)')
			'''---------------------------'''
		elif settingsbutton:
			if admin: xbmc.executebuiltin('Notification(Admin,settingsbutton,1000)')
			if admin or admin2: xbmc.executebuiltin('ActivateWindow(1120)')
			else: xbmc.executebuiltin('ActivateWindow(Settings.xml)')
			'''---------------------------'''
		elif widgettogglebutton:
			if admin: xbmc.executebuiltin('Notification(Admin,widgettogglebutton,1000)')
			if xbmc.getCondVisibility('Control.IsVisible(311)'):
				xbmc.executebuiltin('Skin.ToggleSetting(MoviesShelfWL)')
				xbmc.executebuiltin('ActivateWindow(Videos,MovieTitles)')
				xbmc.sleep(100)
				xbmc.executebuiltin('ReplaceWindow(0)')
				xbmc.executebuiltin('Control.SetFocus(9090)')
				'''---------------------------'''
			if xbmc.getCondVisibility('Control.IsVisible(312)'):
				xbmc.executebuiltin('Skin.ToggleSetting(TVShelf_Watchlist)')
				xbmc.executebuiltin('ActivateWindow(VideoLibrary,TVShowTitles)')
				xbmc.sleep(100)
				xbmc.executebuiltin('ReplaceWindow(0)')
				xbmc.executebuiltin('Control.SetFocus(9090)')
				'''---------------------------'''
		elif htptchannelbutton:
			#xbmc.executebuiltin('RunScript(script.toolbox,info=textviewer,header='+ message1 +',text='+ message2 +')')
			xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.youtube/channel/UCcYT8oPT83Yuw4_GUZ3mMFg/)')
			header = '[COLOR=Yellow]' + htptskinversion + '[/COLOR]' + addonString(19) + "-"
			if not systemplatformwindows:
				log = open('/storage/.kodi/addons/skin.htpt/changelog.txt', 'r')
				skinpath = '/storage/.kodi/addons/skin.htpt/1080i/'
			elif systemplatformwindows:
				log = open('Z:\\addons\\skin.htpt\\changelog.txt', 'r')
				skinpath = 'Z:\\addons\\skin.htpt\\1080i\\'
			message2 = log.read()
			log.close()
			w = TextViewer_Dialog('DialogTextViewer.xml', skinpath, header=header, text=message2)
			w.doModal()
			'''---------------------------'''
		elif test2button:
			'''------------------------------
			---test-2-button-----------------
			------------------------------'''
			#getsetting_refresh          = xbmcaddon.Addon('script.htpt.refresh').getSetting
			#Current_Name = getsetting_refresh('Current_Name')
			#az = Current_Name[-6:]
			'''---------------------------'''
			print printfirst + space + "test2button" + space2 + az
			'''---------------------------'''
		if hasinternet:
			'''------------------------------
			---Require-Internet--------------
			------------------------------'''
			if admin: print printfirst + space + "homebuttons internet" + space3
			if israeltvbutton:
				if systemhasaddon_sdarottv:
					addonsettings('SDAROT TV', 'plugin.video.sdarot.tv', 'Account2_Active', 'Account2_Period', 'username','user_password', "", "", "", "")
					addonsettings2('plugin.video.sdarot.tv','DEBUG',"false",'cache',"24",'domain',"http://www.sdarot.wf",'',"",'',"")
				if admin: xbmc.executebuiltin('Notification(Admin,israeltvbutton,1000)')
				listitempath = xbmc.getInfoLabel('ListItem.Path')
				israeltvrootpath = 'plugin://plugin.video.sdarot.tv/'
				'''1try'''
				xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.sdarot.tv/?mode=2&module=http%3a%2f%2fwww.sdarot.wf%2fseries%2fgenre%2f20%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99&name=%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99&url=all-heb,return)')
				xbmc.sleep(200)
				'''2'''				
				if systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow'):
					xbmc.executebuiltin('RunAddon(plugin.video.sdarot.tv)')
					xbmc.sleep(200)
					'''3'''
					xbmc.sleep(1500)
					containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
					if not israeltvrootpath in containerfolderpath:
						xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.sdarot.tv/?mode=2&module=http%3a%2f%2fwww.sdarot.ws%2fseries%2fgenre%2f20%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99&name=%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99&url=all-heb,return)')
						xbmc.sleep(200)
						'''4'''
						xbmc.sleep(1000)
						containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
						if not israeltvrootpath in containerfolderpath:
							xbmc.executebuiltin('RunAddon(plugin.video.sdarot.tv)')
							containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
							xbmc.sleep(1000)
							if not israeltvrootpath in containerfolderpath:
								if systemcurrentwindow != xbmc.getInfoLabel('System.CurrentWindow'): xbmc.executebuiltin('Notification($LOCALIZE[257],$LOCALIZE[79071],2000)')
			if goprobutton:
				if admin: xbmc.executebuiltin('Notification(Admin,goprobutton,1000)')
				#xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.youtube/?folder=true&login=false&path=%2froot%2fsearch&store=searches;,return)')
				if systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow'): xbmc.executebuiltin('RunAddon(plugin.video.GoProCamera)')
			if youtubebutton:
				if admin: xbmc.executebuiltin('Notification(Admin,youtubebutton,1000)')
				xbmc.executebuiltin('RunAddon(plugin.video.youtube)')
				xbmc.sleep(500)
				containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
				count = 0
				while count < 10 and not "plugin://plugin.video.youtube" in containerfolderpath and not xbmc.abortRequested:
					xbmc.sleep(100)
					count += 1
					containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
					xbmc.sleep(100)
				if "plugin://plugin.video.youtube" in containerfolderpath:
					xbmc.executebuiltin('Action(PageUp)')
					xbmc.executebuiltin('Action(Down)')							
			if moviesebutton or tvshowsebutton:
				if admin: xbmc.executebuiltin('Notification(Admin,moviesebutton/tvshowsebutton,1000)')
				if moviesebutton: xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=root_movies,return)') #xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=movies_featured,return)') #xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=root_movies,return)') #xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=movies_popular)')
				if tvshowsebutton: xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=root_shows,return)')
				xbmc.sleep(200)
				if systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow'):
					if not autoviewoff: xbmc.executebuiltin('Skin.ToggleSetting(AutoViewoff)')
					xbmc.executebuiltin('RunAddon(plugin.video.genesis)')
					xbmc.sleep(1000)
					containerfolderpath = xbmc.getCondVisibility('StringCompare(Container.FolderPath,plugin://plugin.video.genesis/)')
					if not containerfolderpath:
						xbmc.executebuiltin('Action(PageUp)')
						xbmc.executebuiltin('Action(PageUp)')
						xbmc.executebuiltin('Action(Select)')
						xbmc.sleep(800)
						containerfolderpath = xbmc.getCondVisibility('StringCompare(Container.FolderPath,plugin://plugin.video.genesis/)')
						#xbmc.sleep(1000)
					if containerfolderpath:
						xbmc.executebuiltin('Action(PageUp)')
						xbmc.executebuiltin('Action(Down)')
						if tvshowsebutton: xbmc.executebuiltin('Action(Down)')
						xbmc.executebuiltin('Action(Select)')
				else:
					xbmc.sleep(300)
					xbmc.executebuiltin('Action(PageDown)')
					xbmc.executebuiltin('Action(PageDown)')
			if weatherbutton:
				if admin: xbmc.executebuiltin('Notification(Admin,weatherbutton,1000)')
				xbmc.executebuiltin('ActivateWindow(MyWeather)')
				xbmc.sleep(200)
				xbmc.executebuiltin('Weather.Refresh')
			if trailers2button:
				if admin: xbmc.executebuiltin('Notification(Admin,trailers2button,1000)')
				xbmc.executebuiltin('RunAddon(screensaver.randomtrailers)')
			if quizbutton:
				if admin: xbmc.executebuiltin('Notification(Admin,quizbutton,1000)')
				#watchedmovies = xbmc.getInfoLabel('Window(Home).Property(Movies.Watched)')
				#watchedtvshows = xbmc.getInfoLabel('Window(Home).Property(TVShows.Watched,)')
				#xbmc.executebuiltin('Notification('+ watchedmovies +','+ watchedtvshows +',1000)')
				#xbmc.sleep(1000)
				xbmc.executebuiltin('RunAddon(script.moviequiz)')
				'''---------------------------'''				
			if musicbutton or custom1124W:
				'''------------------------------
				---MUSIC-BUTTON------------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,musicbutton,1000)')
				if not custom1124W: xbmc.executebuiltin('ActivateWindow(1124,return)')
				else:
					if admin: xbmc.executebuiltin('Notification(Admin,musicbutton2,1000)')
					if button101:
						'''------------------------------
						---LOCAL-MUSIC-------------------
						------------------------------'''
						if not libraryhascontentmusic: xbmc.executebuiltin('ActivateWindow(501,root),return)')
						elif musiclinkstr != "": xbmc.executebuiltin('ActivateWindow(502,'+ musiclinkstr +',return)')
						else: xbmc.executebuiltin('ActivateWindow(502,return)')
						'''---------------------------'''
					elif button102:
						'''------------------------------
						---ISRAELI-MUSIC-----------------
						------------------------------'''
						if admin: xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.htpt.music/?limit&mode=listItunesVideos&type=browse&url=19),return)')
						notification_common("10")
						'''---------------------------'''
					else:
						pass
						
			if kidsbutton:
				'''------------------------------
				---KIDS-BUTTON-------------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,kidsbutton,1000)')
				#kidssettings("run")
				xbmc.sleep(200)
				#xbmc.executebuiltin('RunAddon(plugin.video.KIDSIL)')
				xbmc.executebuiltin('RunAddon(plugin.video.htpt.kids)')
				'''---------------------------'''
			if mov3dsbutton:
				'''------------------------------
				---3D-MOVIES-BUTTON--------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,mov3dsbutton,1000)')
				#xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.movie25/?fanart;genre;iconimage=https%3a%2f%2fraw.github.com%2fmash2k3%2fMashupArtwork%2fmaster%2fskins%2fvector%2f3d.png;mode=223;name=3D%20Movies;plot;url=3D,return)')
				notification_common("10")
				'''---------------------------'''
			if internetbutton:
				'''------------------------------
				---INTERNET-BUTTON---------------
				------------------------------'''
				import xbmcgui
				#if admin: xbmc.executebuiltin('Notification(Admin,internetbutton,1000)')
				dialog = xbmcgui.Dialog()
				internetbuttonm1 = xbmc.getInfoLabel('$LOCALIZE[79215]')
				internetbuttonm2 = xbmc.getInfoLabel('$LOCALIZE[79216]')
				message1 = internetbuttonm1
				message2 = internetbuttonm2
				'''---------------------------'''
				if dialog.yesno(message1,message2):
					internetbuttonn1 = xbmc.getInfoLabel('$LOCALIZE[79217]')
					internetbuttonn2 = xbmc.getInfoLabel('$LOCALIZE[79218]')
					xbmc.executebuiltin('Notification('+ internetbuttonn1 +','+ internetbuttonn2 +',2000)')
					settingschange('SystemSettings','input.enablemouse','1','no',xbmc.getInfoLabel('$LOCALIZE[14094]'),xbmc.getInfoLabel('$LOCALIZE[21369]'))
					xbmc.sleep(1000)
					if not systemplatformwindows: xbmc.executebuiltin('RunAddon(browser.chromium-browser)')
					'''---------------------------'''
				else:
					settingschange('SystemSettings','input.enablemouse','0','no',xbmc.getInfoLabel('$LOCALIZE[14094]'),xbmc.getInfoLabel('$LOCALIZE[21369]'))
					'''---------------------------'''
			if gadgetbutton:
				'''------------------------------
				---GADGET-BUTTON-----------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,gadgetbutton,1000)')
				#if not systemplatformwindows: xbmc.executebuiltin('RunAddon(plugin.video.engadget)')
				notification_common("10")
				'''---------------------------'''
			if karaokebutton:
				'''------------------------------
				---KARAOKE-BUTTON----------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,karaokebutton,1000)')
				xbmc.executebuiltin('RunAddon(plugin.video.MikeysKaraoke)')
				'''---------------------------'''
			if gametrailersbutton:
				'''------------------------------
				---GAMERS-BUTTON-----------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,gametrailersbutton,1000)')
				xbmc.executebuiltin('RunAddon(plugin.video.g4tv)')
				'''---------------------------'''
			elif guitarbutton:
				'''------------------------------
				---GAMERS-BUTTON-----------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,guitarbutton,1000)')
				xbmc.executebuiltin('RunAddon(plugin.video.ultimateguitar)')
				'''---------------------------'''
			elif adultbutton2:
				'''------------------------------
				---ADULT-MOVIE-BUTTON------------
				------------------------------'''
				adultbutton2_(admin)
				'''---------------------------'''
			if livetvbutton:
				'''------------------------------
				---LIVE-TV-BUTTON----------------
				------------------------------'''
				if admin: xbmc.executebuiltin('Notification(Admin,livetvbutton,1000)')
				xbmc.executebuiltin('RunAddon(plugin.video.israelive)')
				xbmc.sleep(1500)
				containernumitems = xbmc.getInfoLabel('Container.NumItems')
				containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
				systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
				#if "displayname=10000" in containerfolderpath: xbmc.executebuiltin('Action(Back)')
				print printfirst + "livetvbutton " + containernumitems + space + systemcurrentcontrol
				#xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.israelive/?description&displayname=DTT%2b&iconimage=http%3a%2f%2fftp5.bizportal.co.il%2fweb%2fgiflib%2fnews%2fidan_plus_gay.jpg&mode=2&name=%5bCOLOR%20blue%5d%5bB%5d%5bDTT%2b%5d%5b%2fB%5d%5b%2fCOLOR%5d&url,return)')
				#xbmc.sleep(700)
				#containernumitems = xbmc.getInfoLabel('Container.NumItems')
				#if systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow') or containernumitems == '0':
					#xbmc.executebuiltin('RunAddon(plugin.video.israelive)')
					#xbmc.sleep(700)
					#if xbmc.getInfoLabel('Container.FolderPath') == 'plugin://plugin.video.israelive/':
					#	xbmc.executebuiltin('Action(PageUp)')
						#xbmc.executebuiltin('Action(Down)')
						#xbmc.executebuiltin('Action(Down)')
						#xbmc.executebuiltin('Action(Down)')
						#xbmc.executebuiltin('Action(Select)')
			if radiobutton:
				'''------------------------------
				---RADIO-BUTTON------------------
				------------------------------'''
				print printfirst + "radiobutton"
				xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.israelive/?categoryid=9999&description&displayname=10000&iconimage=http%3a%2f%2fmdmorrope.gob.pe%2fportalweb%2fimagenes%2fradioss.png&mode=2&name=%5bCOLOR%20chartreuse%5d%5bB%5d%5b%d7%a8%d7%93%d7%99%d7%95%5d%5b%2fB%5d%5b%2fCOLOR%5d&url,return)')
				xbmc.sleep(700)
				containernumitems = xbmc.getInfoLabel('Container.NumItems')
				if systemcurrentwindow == xbmc.getInfoLabel('System.CurrentWindow') or containernumitems == '0':
					xbmc.executebuiltin('RunAddon(plugin.video.israelive)')
					xbmc.sleep(700)
					if xbmc.getInfoLabel('Container.FolderPath') == 'plugin://plugin.video.israelive/':
						xbmc.executebuiltin('Action(PageUp)')
						xbmc.executebuiltin('Action(Down)')
						xbmc.executebuiltin('Action(Down)')
						xbmc.executebuiltin('Action(Select)')
		elif vhomecon1:
			xbmc.executebuiltin('Notification($LOCALIZE[79512],$LOCALIZE[21451],5000)')
			if admin: print printfirst + space + "homebuttons internet Error" + space3 + "systeminternetstate" + space2 + systeminternetstate + space + "networkipaddress" + space2 +  networkipaddress
			'''---------------------------'''
def helpbuttons(run):
	''''''
	if custom1170W or loginscreenW:
		'''------------------------------
		---HELP-/-LOGINSCREEN-WINDOWS----
		------------------------------'''
		xbmc.sleep(40)
		#if admin: xbmc.executebuiltin('Notification(Admin,custom1170,1000)')
		if airplaybutton:
			'''------------------------------
			---AIRPLAY-BUTTON----------------
			------------------------------'''
			xbmc.executebuiltin('ActivateWindow(servicesettings)')
			settingslevelset('run')
			scc(xbmc.executebuiltin('Action(Left)'),xbmc.executebuiltin('Action(Down)'),airplaystr1,airplaystr2)
			if systemcurrentcontrol != airplaystr1 and systemcurrentcontrol != airplaystr2:
				scc(xbmc.executebuiltin('Action(Left)'),xbmc.executebuiltin('Action(Down)'),airplaystr1,airplaystr2)
			if not airplaycon1: xbmc.executebuiltin('Action(Down)')
			if not airplaycon1: xbmc.executebuiltin('Action(Down)')
			'''if Allow to receive AirPlay content'''
			if airplaycon1:
				xbmc.executebuiltin('Action(Select)')
				if admin and airplaycon2: xbmc.executebuiltin('Notification(Admin,airplaycon2,1000)')
				if airplaycon2:
					if airplaycon3:
						xbmc.executebuiltin('Notification($LOCALIZE[79063],$LOCALIZE[79064],5000)')
						#if not systemplatformwindows: os.system('sh /storage/.kodi/addons/skin.htpt/specials/scripts/resetnetwork.sh')
					xbmc.sleep(200)
					xbmc.executebuiltin('Action(Select)')
				xbmc.executebuiltin('Action(Back)')
				if not airplaycon3: xbmc.executebuiltin('Notification($LOCALIZE[257],$LOCALIZE[34302],5000)')
			print printfirst + "airplaybutton"
		if resetnetworkbutton:
			'''------------------------------
			---RESET-NETWORK-BUTTON----------
			------------------------------'''
			resetnetwork('run')
		'''buttons which require internet'''
		if hasinternet:
			if messagebutton:
				notification_common("10")
				if systemplatformwindows:
					xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.programm.htptmail/mailbox/INBOX/,return)')
					'''---------------------------'''
			if debugbutton:
				if not systemhasaddon_htptdebug: xbmc.executebuiltin('ActivateWindow(10001,plugin://script.htpt.debug/)')
				else: xbmc.executebuiltin('RunAddon(script.htpt.debug)')
				'''---------------------------'''
		elif vhomecon1: xbmc.executebuiltin('Notification($LOCALIZE[79512],$LOCALIZE[21451],5000)')		

def leftmenu(run):
	'''left menu'''
	containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
	if not validation:
		'''searchisraeltv'''
		if myvideonavW and searchisraeltv:
			xbmc.executebuiltin('Action(Right)')
			if containerfolderpath != israeltvhome:
				backward('run2')
				containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
				if containerfolderpath != israeltvhome:
					backward('run2')
					containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
					if containerfolderpath != israeltvhome:
						backward('run2')
						containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
			if containerfolderpath == israeltvhome:
				xbmc.executebuiltin('Action(PageUp)')
				xbmc.executebuiltin('Action(PageUp)')
				xbmc.executebuiltin('Action(PageUp)')
				xbmc.executebuiltin('Action(Down)')
				xbmc.executebuiltin('Action(Select)')
			print printfirst + "searchisraeltv"
		'''deletesearchyoutube'''
		#if myvideonavW and deletesearchyoutube:
			#Z = 'special://userdata/addon_data/plugin.video.youtube/settings.xml'
			#if admin: xbmc.executebuiltin('Notification(Admin,deletesearchyoutube,1000)')
			#A = '"store_searches" value='
			#B = '"[^ ]*"'
			#bash('sed -i "s|a|b|g" z,"deletesearchyoutube")
			#xbmc.executebuiltin('Action(Right)')
		'''statusjoystick'''
		if myprogramsW:
			'''------------------------------
			---MYPROGRAMS.NAV-IS-VISIBLE-----
			------------------------------'''
			if containerfoldername == "Advanced Launcher":
				'''------------------------------
				---EMULATORS---------------------
				------------------------------'''
				if statusjoystick: oewindow(admin,'statusjoystick')
				'''allowjoystick'''
				if myprogramsW and allowjoystick:
					print printfirst + "allowjoystick"
					settingschange('SystemSettings','input.enablejoystick','1','yes',xbmc.getInfoLabel('$LOCALIZE[14094]'),xbmc.getInfoLabel('$LOCALIZE[35100]'))
				if leftmenubutton110:
					'''------------------------------
					---EMULATOR-ADVANCED-SETTINGS----
					------------------------------'''
					if admin: xbmc.executebuiltin('Notification(Admin,EMULATOR-ADVANCED-SETTINGS,1000)')
					if not systemhasaddon_htptemu: xbmc.executebuiltin('ActivateWindow(10001,plugin://script.htpt.emu/)')
					else:
						xbmc.executebuiltin('RunScript(script.htpt.emu)')
		'''70'''
		if (myvideonavW or mypicsW) and usbtoggle:
			if admin: xbmc.executebuiltin('Notification(Admin,usbtoggle,1000)')
			#videopath0 = xbmc.getCondVisibility('SubString(Container.FolderPath,special://userdata/library/videos/)')
			externalusb('run')
			if systemplatformwindows:
				path0 = 'special://userdata/library/'
				pathwin = 'special://home/external/'
				if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path0 +')'):
					if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ pathwin +'videos/,return)')
					if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ pathwin +'pictures/,return)')
				if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ pathwin +')'):
					if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'videos/,return)')
					if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'pictures/,return)')
			print printfirst + "usbtoggle"
		if myvideonavW and numinumibutton:
			pl=xbmc.PlayList(1)
			pl.clear()
			count = 0
			while count < 7 and not xbmc.abortRequested:
				xbmc.sleep(10)
				count += 1
				listitem = xbmcgui.ListItem(numinumistr,
				thumbnailImage='special://skin/media/icons/kids.png')
				url = 'special://userdata/addon_data/skin.htpt/video/numinumi.mp4'
				xbmc.PlayList(1).add(url, listitem)

			xbmc.Player().play(pl)
			xbmc.executebuiltin('Action(Right)')
			xbmc.executebuiltin('Action(PageUp)')
			xbmc.executebuiltin('Action(FullScreen)')
	else:
		if admin: xbmc.executebuiltin('Notification(Admin,no buttonproceed,1000)')

def miscbuttons(run):
	if smartsearchbutton:
		import json
		dialogkeyboard = xbmc.getCondVisibility('Window.IsVisible(DialogKeyboard.xml)')
		if admin: xbmc.executebuiltin('Notification(Admin,smartsubsearch,1000)')
		isTV = 'false'
		isMovie = 'false'
		input = ""
		playertitle = xbmc.getInfoLabel('Player.Title')
		videoplayertitle = xbmc.getInfoLabel('VideoPlayer.Title')
		tvshowtitle = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
		season = xbmc.getInfoLabel('VideoPlayer.Season')
		episode = xbmc.getInfoLabel('VideoPlayer.Episode')
		title = xbmc.getInfoLabel('VideoPlayer.Title')
		year = xbmc.getInfoLabel('VideoPlayer.Year')
		country = xbmc.getInfoLabel('VideoPlayer.Country')
		tagline = xbmc.getInfoLabel('VideoPlayer.Tagline')
		if tvshowtitle != "" and season != "" and episode != "": isTV = 'true'
		elif title != "" and (year != "" or country != "" or tagline != ""): isMovie = 'true'
		xbmc.sleep(40)
		print printfirst + "dialogsubtitles: " + "tvshowtitle = " + tvshowtitle + " | season = " + season + " | episode = " + episode + " | title = " + title + " | year = " + year + " | videoplayertitle = " + videoplayertitle + space + "playertitle =" + playertitle
		'''tvshow/movie?'''
		if videoplayertitle != "": input = videoplayertitle
		elif isTV == 'true':
			seasonN = int(season)
			episodeN = int(episode)
			if seasonN < 10 and episodeN < 10: input = tvshowtitle + " " + 'S0' + season + 'E0' + episode
			if seasonN > 10 and episodeN > 10: input = tvshowtitle + " " + 'S' + season + 'E' + episode
			if seasonN > 10 and episodeN < 10: input = tvshowtitle + " " + 'S' + season + 'E0' + episode
			if seasonN < 10 and episodeN > 10: input = tvshowtitle + " " + 'S0' + season + 'E' + episode
		elif isMovie == 'true': input = title + " " + year
		xbmc.executebuiltin('SendClick(160)')
		xbmc.sleep(1000)
		xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ input +'","done":false}}')
	#else:
		#if admin: xbmc.executebuiltin('Notification(Admin,NO smartsubsearch,1000)')
	if subsliderbutton:
		'''------------------------------
		---subslider---------------------
		------------------------------'''
		if admin: notification("admin: " + "subsliderbutton","","",1000)
		if systemplatformwindows: filepath = "Z:\\addons\\script.htpt.homebuttons\\specials\\scripts\\subslider.py"
		if not systemplatformwindows: filepath = "/storage/.kodi/addons/script.htpt.homebuttons/specials/scripts/subslider.py"
		xbmc.executebuiltin('RunScript('+ filepath +', -10)')
		'''---------------------------'''
		
	if custom1125W:
		import json
		#if admin: xbmc.executebuiltin('Notification(Admin,custom1125,1000)')
		#if (keyboard.isConfirmed()):
		#xel = xbmcgui.Window(xbmcgui.getCurrentWindowId())
		#dialog = xbmcgui.Dialog()        
		keyboard = xbmc.Keyboard()
		input = keyboard.getText()
		xbmc.executebuiltin('Notification(INPUT?,'+ input +',5000)')
		
		print printfirst + "custom1125: " + "input = " + input
		smartkeyboardcopy = xbmc.getCondVisibility('Control.HasFocus(202)')
		smartkeyboardhistory = xbmc.getCondVisibility('Control.HasFocus(201)')
		smartkeyboardpaste = xbmc.getCondVisibility('Control.HasFocus(204)')
		'''copy button'''
		if smartkeyboardcopy:
			'''variable'''
			smartkeyboardPN = xbmc.getInfoLabel('Skin.String(smartkeyboardPN)')
			smartkeyboardC1 = xbmc.getInfoLabel('Skin.String(smartkeyboardC1)')
			smartkeyboardC2 = xbmc.getInfoLabel('Skin.String(smartkeyboardC2)')
			smartkeyboardC3 = xbmc.getInfoLabel('Skin.String(smartkeyboardC3)')
			smartkeyboardC4 = xbmc.getInfoLabel('Skin.String(smartkeyboardC4)')
			smartkeyboardC5 = xbmc.getInfoLabel('Skin.String(smartkeyboardC5)')
			'''execute'''
			#xbmc.executebuiltin('Action(Close)')
			#xbmc.sleep(200)
			if admin: xbmc.executebuiltin('Notification(Admin,smartkeyboardcopy,1000)')
			if smartkeyboardPN == '1': xbmc.executebuiltin('Skin.SetString(smartkeyboardC1,'+ input +')')
			if smartkeyboardPN == '2': xbmc.executebuiltin('Skin.SetString(smartkeyboardC2,'+ input +')')
			if smartkeyboardPN == '3': xbmc.executebuiltin('Skin.SetString(smartkeyboardC3,'+ input +')')
			if smartkeyboardPN == '4': xbmc.executebuiltin('Skin.SetString(smartkeyboardC4,'+ input +')')
			if smartkeyboardPN == '5': xbmc.executebuiltin('Skin.SetString(smartkeyboardC5,'+ input +')')
			xbmc.executebuiltin('SetFocus(3000)')
			
		elif smartkeyboardhistory:
			'''variable'''
			smartkeyboardHN = xbmc.getInfoLabel('Skin.String(smartkeyboardHN)')
			smartkeyboardH1 = xbmc.getInfoLabel('Skin.String(smartkeyboardH1)')
			smartkeyboardH2 = xbmc.getInfoLabel('Skin.String(smartkeyboardH2)')
			smartkeyboardH3 = xbmc.getInfoLabel('Skin.String(smartkeyboardH3)')
			smartkeyboardH4 = xbmc.getInfoLabel('Skin.String(smartkeyboardH4)')
			smartkeyboardH5 = xbmc.getInfoLabel('Skin.String(smartkeyboardH5)')
			'''execute'''
			xbmc.executebuiltin('Action(Close)')
			xbmc.sleep(200)
			#xbmc.executebuiltin('Action(
			if admin: xbmc.executebuiltin('Notification(Admin,smartkeyboardhistory,1000)')
			if smartkeyboardHN == '1': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH1 +'","done":false}}')
			if smartkeyboardHN == '2': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH2 +'","done":false}}')
			if smartkeyboardHN == '3': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH3 +'","done":false}}')
			if smartkeyboardHN == '4': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH4 +'","done":false}}')
			if smartkeyboardHN == '5': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH5 +'","done":false}}')
			xbmc.executebuiltin('SetFocus(3000)')
		elif smartkeyboardpaste:
			'''variable'''
			smartkeyboardPN = xbmc.getInfoLabel('Skin.String(smartkeyboardPN)')
			smartkeyboardC1 = xbmc.getInfoLabel('Skin.String(smartkeyboardC1)')
			smartkeyboardC2 = xbmc.getInfoLabel('Skin.String(smartkeyboardC2)')
			smartkeyboardC3 = xbmc.getInfoLabel('Skin.String(smartkeyboardC3)')
			smartkeyboardC4 = xbmc.getInfoLabel('Skin.String(smartkeyboardC4)')
			smartkeyboardC5 = xbmc.getInfoLabel('Skin.String(smartkeyboardC5)')
			'''execute'''
			xbmc.executebuiltin('Action(Close)')
			xbmc.sleep(200)
			if admin: xbmc.executebuiltin('Notification(Admin,smartkeyboardpaste,1000)')
			if smartkeyboardPN == '1': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC1 +'","done":false}}')
			if smartkeyboardPN == '2': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC2 +'","done":false}}')
			if smartkeyboardPN == '3': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC3 +'","done":false}}')
			if smartkeyboardPN == '4': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC4 +'","done":false}}')
			if smartkeyboardPN == '5': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC5 +'","done":false}}')
			xbmc.executebuiltin('SetFocus(3000)')

def startup(run):
	validation = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION)')
	if startup_aW and not validation:
		print printfirst + "startup (1)"
		xbmc.executebuiltin('ReplaceWindow(Home)')
		mac7('run',macaddress,maccon1,maccon2,maccon10,maccon11)
		externalusb('run')
		xbmc.executebuiltin('RunScript(service.skin.widgets)')
		xbmc.sleep(5000)
		xbmc.executebuiltin('RunScript(script.htpt.remote)')
		'''addonsettings'''
		addonsettingall('run')
		skinsettingsall('run')
		#if not systemplatformwindows: settingschange('SystemSettings','input.enablemouse','0','no',xbmc.getInfoLabel('$LOCALIZE[14094]'),xbmc.getInfoLabel('$LOCALIZE[21369]'))

class skinbuttons:
	if skinsettingsW:
		if adultbutton:
			'''------------------------------
			---ADULT-GAMES-------------------
			------------------------------'''
			print printfirst + space + "adultbutton"
			xbmc.executebuiltin('Skin.ToggleSetting(Adult)')
			if not systemplatformwindows:
				xbmc.sleep(1000)
				os.system('sh /storage/.kodi/addons/script.htpt.emu/specials/scripts/copyemu.sh')
			if not adult:
				'''------------------------------
				---ADULT-BUTTON-OFF->ON----------
				------------------------------'''
				returned = dialogyesno(addonString(97).encode('utf-8'),addonString(98).encode('utf-8'))
				if returned == "ok":
					'''------------------------------
					---ADULT-ALWAYS-ON---------------
					------------------------------'''
					setSkinSetting("1",'Adult2',"true")
					'''---------------------------'''
				else:
					'''------------------------------
					---ADULT-ALWAYS-OFF--------------
					------------------------------'''
					setSkinSetting("1",'Adult2',"false")
					'''---------------------------'''
				setSkinSetting("1",'Admin2',"false")
				'''---------------------------'''
				list0 = xbmc.getInfoLabel('$LOCALIZE[75003]')
				list1 = xbmc.getInfoLabel('$LOCALIZE[15016]')
				returned = dialogselect(addonString(99).encode('utf-8'),[list0, list1],0)
				returned = int(returned)
				if returned == -1:
					dialogok(addonString(95).encode('utf-8'),addonString(96).encode('utf-8'),"","")
				else:
					xbmc.executebuiltin('ActivateWindow(Home.xml)')
					xbmc.sleep(200)
					'''---------------------------'''
					if returned == 0: adultbutton2_(admin)
					elif returned == 1:
						gamesbutton_(admin)
						xbmc.sleep(1000)
						xbmc.executebuiltin('Action(PageDown)')
			else: setSkinSetting("1",'Adult2',"false")
			
		elif trakttvbutton and systemhasaddon_genesis:
			'''------------------------------
			---TRAKT-TV-BUTTON---------------
			------------------------------'''
			account_button('TRAKT TV','plugin.video.genesis', 'trakt_user', 'trakt_password', trakt_user, trakt_password, 'Account10_Active', '', '', Account10_Active, "N/A", "N/A", "")
			'''---------------------------'''
		elif sdarottvbutton and systemhasaddon_sdarottv:
			'''------------------------------
			---SDAROT-TV-BUTTON--------------
			------------------------------'''
			account_button('SDAROT TV','plugin.video.sdarot.tv', 'username', 'user_password', sdarottv_user, sdarottv_password, 'Account2_Active', 'Account2_Period', 'Account2_EndDate', Account2_Active, Account2_Period, Account2_EndDate, "")
			'''---------------------------'''
		elif noobroombutton and systemhasaddon_genesis:
			'''------------------------------
			---NOOBROOM-BUTTON---------------
			------------------------------'''
			notification_common("10")
			#account_button('NOOBROOM','plugin.video.genesis', 'noobroom_mail', 'noobroom_password', noobroom_mail, noobroom_password, 'Account5_Active', 'Account5_Period', 'Account5_EndDate', Account5_Active, Account5_Period, Account5_EndDate, "")
			'''---------------------------'''
		elif premiumizebutton and systemhasaddon_genesis:
			'''------------------------------
			---PREMIUMIZE-BUTTON-------------
			------------------------------'''
			notification_common("10")
			#account_button('PREMIUMIZE','plugin.video.genesis', 'premiumize_user', 'premiumize_password', premiumize_user, premiumize_password, 'Account4_Active', 'Account4_Period', 'Account4_EndDate', Account4_Active, Account4_Period, Account4_EndDate, "")
			'''---------------------------'''
		elif movreelbutton and systemhasaddon_genesis:
			'''------------------------------
			---MOVREEL-BUTTON----------------
			------------------------------'''
			notification_common("10")
			#account_button('MOVREEL','plugin.video.genesis', 'movreel_user', 'movreel_password', movreel_user, movreel_password, 'Account3_Active', 'Account3_Period', 'Account3_EndDate', Account3_Active, Account3_Period, Account3_EndDate, "")
			'''---------------------------'''
		elif realdebridbutton and systemhasaddon_genesis:
			'''------------------------------
			---REALDEBRID-BUTTON-------------
			------------------------------'''
			account_button('REALDEBRID','plugin.video.genesis', 'realdedrid_user', 'realdedrid_password', realdedrid_user, realdedrid_password, 'Account1_Active', 'Account1_Period', 'Account1_EndDate', Account1_Active, Account1_Period, Account1_EndDate, "")
			'''---------------------------'''
		
		elif paymentmethodbutton:
			'''------------------------------
			---PAYMENT-TERMS-----------------
			------------------------------'''
			list0 = xbmc.getInfoLabel('$LOCALIZE[70014]')
			list1 = xbmc.getInfoLabel('$LOCALIZE[70015]')
			list2 = xbmc.getInfoLabel('$LOCALIZE[70016]')
			returned = dialogselect('$LOCALIZE[70012]',[list0, list1, list2],0)
			returned = int(returned)
			returnedS = str(returned)
			returned2 = "list" + returnedS
			if returned == -1:
				dialogok('$LOCALIZE[31406]',"","","")
			else:
				if returned == 0: setSkinSetting("0",'ID6',list0)
				elif returned == 1: setSkinSetting("0",'ID6',list1)
				elif returned == 2: setSkinSetting("0",'ID6',list2)
				'''---------------------------'''
			
		elif formatbutton:
			mac5str = xbmc.getInfoLabel('Skin.String(MAC5)')
			returned = dialogyesno('FORMAT YOUR DEVICE TOOL','CHOOSE YES TO PROCEED')
			if returned == 'ok':
				'''asking for a password'''
				xbmc.executebuiltin('Skin.SetNumeric(MAC5)')
				xbmc.sleep(3000)
				dialognumericW = xbmc.getCondVisibility('Window.IsVisible(DialogNumeric.xml)')
				while dialognumericW and not xbmc.abortRequested:
					xbmc.sleep(500)
					dialognumericW = xbmc.getCondVisibility('Window.IsVisible(DialogNumeric.xml)')
					xbmc.sleep(1000)
				mac5str = xbmc.getInfoLabel('Skin.String(MAC5)')
				xbmc.sleep(200)
				if mac5str == var70000 and mac5str != "":
					xbmc.executebuiltin('Notification(FORMAT WILL START IN 10 MIN!,REBOOT ASAP FOR CANCELING THE PROCESS!,10000,icons/shield.png)')
				if mac5str != var70000 and mac5str != "":
					xbmc.executebuiltin('Notification(WRONG PASSWORD!!!,BE SURE YOU KNOW WHAT YOU ARE DOING!!!,10000,icons/shield.png)')
					if admin: xbmc.executebuiltin('Skin.ToggleSetting(Admin)')
					xbmc.executebuiltin('Skin.SetString(ID9,FTOOL)')
					xbmc.executebuiltin('ReplaceWindow(Startup.xml)')
			else:
				if mac5str: xbmc.executebuiltin('Skin.SetString(MAC5,)')
				xbmc.executebuiltin('Notification(FORMAT CANCELED,...,2000,icons/shield.png)')
			if mac5str != var70000: print printfirst + "formatbutton" + space2 + mac5str + " ( " + returned + " ) "
			elif mac5str == var70000: print printfirst + "formatbutton" + space2 + "*******" + " ( " + returned + " ) "
		#if fixip:
		#if id60button:
				
			
		elif userdataresetbutton:
			dialogok('USERDATA DELETED!','[CR]' + 'THERE IS NO WAY BACK NOW...',"","")
			if not systemplatformwindows:
				bash('rm -rf /storage/.kodi/userdata/addon_data/script.htpt.debug',"script.htpt.debug")
				bash('rm -rf /storage/.kodi/userdata/addon_data/script.htpt.homebuttons',"script.htpt.homebuttons")
				bash('rm -rf /storage/.kodi/userdata/addon_data/script.htpt.remote',"script.htpt.remote")
				bash('rm -rf /storage/.kodi/userdata/addon_data/script.htpt.fix',"service.htpt.fix")
				bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.video.genesis',"plugin.video.genesis")
				bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.program.advanced.launcher',"plugin.program.advanced.launcher")
				bash('rm -rf /storage/.kodi/userdata/addon_data/script.htpt.emu',"script.htpt.emu")
				bash('rm -rf /storage/.kodi/userdata/addon_data/service.htpt',"service.htpt")
			#print printfirst + "userdataresetbutton" + space2 + mac5str + " ( " + returned + " ) "
			
class main:
	homebuttonsrunnings('run')
	mac('run',macaddress)
	homebuttons('run')
	#skinbuttons('run')
	helpbuttons('run')
	leftmenu('run')
	if netsettingsbutton: oewindow(admin,'netsettingsbutton')
	miscbuttons('run')
	autoviewoff = xbmc.getInfoLabel('Skin.HasSetting(AutoViewoff)')
	if myvideonavW or mypicsW or mymusicnavW or myprogramsW or settingsW or filemanagerW or myweatherW or dialogfavouritesW:
		if home_pW and validation2: mac7('run',macaddress,maccon1,maccon2,maccon10,maccon11)
	if autoviewoff:
		print printfirst + "autoviewoff"
		xbmc.sleep(2000)
		xbmc.executebuiltin('Skin.ToggleSetting(AutoViewoff)')
	startup('run')
	topvideoinformation2('run')
	homebuttonsrunnings('end')