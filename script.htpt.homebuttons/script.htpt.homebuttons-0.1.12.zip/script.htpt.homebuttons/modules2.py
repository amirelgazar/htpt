import xbmc, xbmcaddon, xbmcgui
#import subprocess, os, sys

from variables import *
#from modules import *

def account_button(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, custom):
	try: from modules import *
	except: pass
	getsetting_addon         = xbmcaddon.Addon(addon).getSetting
	printpoint = ""
	'''---------------------------'''
	if skinsetting:
		'''------------------------------
		---DIALOG-YESNO-USER+PASS--------
		------------------------------'''
		returned = dialogyesno(addonString(74).encode('utf-8'),addonString(75).encode('utf-8') + '[CR]' + addonString(73).encode('utf-8') % (username))
		if returned == 'ok':
			'''------------------------------
			---DIALOG-KEYBOARD-USER----------
			------------------------------'''
			printpoint = printpoint + "1"
			if 'htpt' in username: username = ""
			returned = dialogkeyboard(username,'$LOCALIZE[20142]',0,'3',usernameS,addon)
			if returned == 'skip':
				notification('$LOCALIZE[257]',addonString(69).encode('utf-8'),"",2000)
				printpoint = printpoint + "7"
				'''---------------------------'''
			else:
				'''------------------------------
				---DIALOG-KEYBOARD-PASS----------
				------------------------------'''
				printpoint = printpoint + "2"
				returned = dialogkeyboard(password,'$LOCALIZE[15052]',1,'3',passwordS,addon)
				if returned == 'skip':
					notification('$LOCALIZE[257]',addonString(69).encode('utf-8'),"",2000)
					printpoint = printpoint + "7"
				else:
					printpoint = printpoint + "3"
					'''---------------------------'''
		'''------------------------------
		---DIALOG-YES-NO-PERIOD----------
		------------------------------'''
		if not "7" in printpoint:
			returned = dialogyesno(addonString(70).encode('utf-8'),addonString(71).encode('utf-8') % (skinsetting2))
			if returned == 'ok':
				printpoint = printpoint + "4"
				returned = dialognumeric(0,addonString(68).encode('utf-8'),skinsetting2,'2',skinsetting2S)
				if returned == 'skip': notification('$LOCALIZE[257]',addonString(69).encode('utf-8'),"",2000)
				else:
					printpoint = printpoint + "5"
					
		if printpoint == "" or "7" in printpoint:
			'''------------------------------
			---DIALOG-YES-NO-TURNOFF---------
			------------------------------'''
			returned = dialogyesno(addonString(72).encode('utf-8'),addonString(73).encode('utf-8') % (username))
			if returned == 'ok':
				setSkinSetting("1", skinsettingS, "false")
				setSkinSetting("0", skinsetting2S, "")
				setSkinSetting("0", skinsetting3S, "")
				setsetting_genesis(usernameS, "")
				setsetting_genesis(passwordS, "")
				'''---------------------------'''
			else:
				notification(addonString(66).encode('utf-8'),addonString(67).encode('utf-8'),"",4000)
				'''---------------------------'''
				
		if ("1" in printpoint and "3" in printpoint) or ("4" in printpoint and "5" in printpoint):
			'''------------------------------
			---DIALOG-OK-ACCOUNT-EDITED------
			------------------------------'''
			xbmc.sleep(500)
			skinsetting = xbmc.getInfoLabel('Skin.HasSetting('+ skinsettingS +')')
			skinsetting2 = xbmc.getInfoLabel('Skin.String('+ skinsetting2S +')')
			username = getsetting_addon(usernameS)
			password = getsetting_addon(passwordS)
			'''---------------------------'''
			
			if name == "REALDEBRID":
				'''------------------------------
				---REALDEBRID--------------------
				------------------------------'''
				dialogok(addonString(56).encode('utf-8') % ('[COLOR=Yellow]' + name + '[/COLOR]'),addonString(73).encode('utf-8') % (username),addonString(61).encode('utf-8') % (password),addonString(71).encode('utf-8') % (skinsetting2))
				dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + addonString(76).encode('utf-8'),addonString(77).encode('utf-8'),addonString(78).encode('utf-8'),addonString(79).encode('utf-8'))
				set_accountdate(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, "0")
				'''---------------------------'''
				
			elif name == "SDAROT TV":
				'''------------------------------
				---SDAROT-TV---------------------
				------------------------------'''
				dialogok(addonString(56).encode('utf-8') % ('[COLOR=Yellow]' + name + '[/COLOR]'),addonString(73).encode('utf-8') % (username),addonString(61).encode('utf-8') % (password),addonString(71).encode('utf-8') % (skinsetting2))
				dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + addonString(76).encode('utf-8'),addonString(77).encode('utf-8'),addonString(87).encode('utf-8'),addonString(88).encode('utf-8'))
				set_accountdate(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, "0")
				'''---------------------------'''	

	else:
		'''------------------------------
		---DIALOG-YES-NO-HAVE-ACCOUNT?---
		------------------------------'''
		returned = dialogyesno(addonString(57).encode('utf-8') % (name),addonString(65).encode('utf-8'))
		if returned == 'ok':
			'''------------------------------
			---DIALOG-KEYBOARD-USER----------
			------------------------------'''
			if admin or not 'htpt' in username: input = username
			else: input = ""
			returned = dialogkeyboard(input,'$LOCALIZE[20142]',0,'3',usernameS,addon)
			if returned == 'skip': pass
			else:
				'''------------------------------
				---DIALOG-KEYBOARD-PASS----------
				------------------------------'''
				returned = dialogkeyboard(password,'$LOCALIZE[15052]',1,'3',passwordS,addon)
				if returned == 'skip': pass
				else:
					'''------------------------------
					---DIALOG-NUMERIC--PERIOD--------
					------------------------------'''
					returned = dialognumeric(0,addonString(68).encode('utf-8'),"30",'2',skinsetting2S)
					if returned == 'skip': pass
					else:
						'''------------------------------
						---DIALOG-OK-ACCOUNT-ON-------
						------------------------------'''
						setSkinSetting("1", skinsettingS, "true")
						xbmc.sleep(500)
						skinsetting = xbmc.getInfoLabel('Skin.HasSetting('+ skinsettingS +')')
						skinsetting2 = xbmc.getInfoLabel('Skin.String('+ skinsetting2S +')')
						skinsetting3 = xbmc.getInfoLabel('Skin.String('+ skinsetting3S +')')
						username = getsetting_addon(usernameS)
						password = getsetting_addon(passwordS)
						'''---------------------------'''
						
						if name == "REALDEBRID":
							'''------------------------------
							---REALDEBRID--------------------
							------------------------------'''
							dialogok(addonString(56).encode('utf-8') % ('[COLOR=Yellow]' + name + '[/COLOR]'),addonString(73).encode('utf-8') % (username),addonString(61).encode('utf-8') % (password),addonString(71).encode('utf-8') % (skinsetting2))
							dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + addonString(76).encode('utf-8'),addonString(77).encode('utf-8'),addonString(78).encode('utf-8'),addonString(79).encode('utf-8'))
							set_accountdate(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, "0")
							'''---------------------------'''
							
						elif name == "SDAROT TV":
							'''------------------------------
							---SDAROT-TV---------------------
							------------------------------'''
							dialogok(addonString(56).encode('utf-8') % ('[COLOR=Yellow]' + name + '[/COLOR]'),addonString(73).encode('utf-8') % (username),addonString(61).encode('utf-8') % (password),addonString(71).encode('utf-8') % (skinsetting2))
							dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + addonString(76).encode('utf-8'),addonString(77).encode('utf-8'),addonString(87).encode('utf-8'),addonString(88).encode('utf-8'))
							set_accountdate(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, "0")
							'''---------------------------'''
							
			if returned == 'skip':
				'''------------------------------
				---DIALOG-NOTIFICATION-TURNOFF---
				------------------------------'''
				notification('$LOCALIZE[257]',addonString(69).encode('utf-8'),"",2000)
				setSkinSetting("1", skinsettingS, "false")
				setSkinSetting("0", skinsetting2S, "")
				setSkinSetting("0", skinsetting3S, "")
				setsetting_custom1(addon,usernameS,"")
				setsetting_custom1(addon,passwordS,"")
				'''---------------------------'''
		else:
			'''------------------------------
			---DIALOG-OK-SIGNUP-INFO---------
			------------------------------'''
			if name == "REALDEBRID": dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + 'https://real-debrid.com/',addonString(64).encode('utf-8'),'[CR]' + addonString(80).encode('utf-8'),'[CR]' + addonString(81).encode('utf-8'))
			elif name == "SDAROT TV": dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + 'http://sdarot.wf/',addonString(64).encode('utf-8'),'[CR]' + addonString(83).encode('utf-8'),'[CR]' + addonString(84).encode('utf-8'))
			'''---------------------------'''
	
	if name == "REALDEBRID":
		'''------------------------------
		---urlresolver-------------------
		------------------------------'''
		if systemhasaddon_urlresolver: addonsettings2('script.module.urlresolver','RealDebridResolver_login',"true",'RealDebridResolver_enabled',"true",'RealDebridResolver_priority',"101",'RealDebridResolver_username',username,'RealDebridResolver_password',password)
		'''---------------------------'''
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "account_button LV_" + printpoint + space2 + name + space + addon + space3
	'''---------------------------'''
		
def set_accountdate(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, custom):
	try: from modules import *
	except: pass
	'''------------------------------
	---CALCULATE-END-DATES-----------
	------------------------------'''
	try: numberN = int(skinsetting2)
	except: numberN = 0
	dateafter2 = datenow + datetime.timedelta(days=numberN)
	dateafter2S = str(dateafter2)
	
	if skinsetting3 != "":
		dateleft = stringtodate(skinsetting3,'%Y-%m-%d')
		dateleft2 = str(dateleft)
		dateleft2S = str(dateleft2)
		datenow2 = stringtodate(datenowS,'%Y-%m-%d')
		number2 = dateleft - datenow2
		number2S = str(number2)
		if "day," in number2S: number2S = number2S.replace(" day, 0:00:00","",1)
		elif "days," in number2S: number2S = number2S.replace(" days, 0:00:00","",1)
		else: number2S = "0"
		if admin: notification("number2S:" + number2S,"","",2000)
		number2N = int(number2S)
	else:
		number2S = "0"
		number2N = int(number2S)
	if number2N < 0: 
		number2S = "0"
		number2N = int(number2S)
	'''---------------------------'''
	
	if custom == "0":
		'''------------------------------
		---MANUAL-SET--------------------
		------------------------------'''
		#setsetting(skinsetting3, dateafter2S)
		setSkinSetting("0", skinsetting3S, dateafter2S)
		'''---------------------------'''
		
		'''---------------------------'''
	if custom == "1":
		'''------------------------------
		---AUTO-SET----------------------
		------------------------------'''
		
		'''---------------------------'''
		if skinsetting2 != "" or skinsetting3 != "": setSkinSetting("0", skinsetting2S, number2S)
		'''---------------------------'''
		
		if skinsetting and number2N < 7:
			'''------------------------------
			---PERIOD-ABOUT-TO-END-----------
			------------------------------'''
			if number2N > 0 and number2N < 7: dialogok(addonString(63).encode('utf-8') + '[CR]' + '[COLOR=Yellow]' + name + '[/COLOR]',"",addonString(73).encode('utf-8') % (username) + '[CR]' + addonString(71).encode('utf-8') % (number2S),"")
			elif skinsetting and number2N == 0: dialogok(addonString(60).encode('utf-8') + '[CR]' + '[COLOR=Yellow]' + name + '[/COLOR]',"",addonString(73).encode('utf-8') % (username) + '[CR]' + addonString(71).encode('utf-8') % (number2S),"")
			'''---------------------------'''
			
			'''------------------------------
			---DIALOG-YESNO-REMAKE-----------
			------------------------------'''
			returned = dialogyesno(addonString(59).encode('utf-8') + space + name,addonString(58).encode('utf-8') + '[CR]' + addonString(73).encode('utf-8') % (username))
			if returned == "ok":
				skinsettingsW = xbmc.getCondVisibility('Window.IsVisible(SkinSettings.xml)')
				if not skinsettingsW: xbmc.executebuiltin('ActivateWindow(SkinSettings.xml)')
				'''---------------------------'''
				count = 0
				while count < 40 and not skinsettingsW and not xbmc.abortRequested:
					'''------------------------------
					---skinsettingsW-PENDING---------
					------------------------------'''
					xbmc.sleep(100)
					count += 1
					skinsettingsW = xbmc.getCondVisibility('Window.IsVisible(SkinSettings.xml)')
					'''---------------------------'''
				if skinsettingsW:
					'''------------------------------
					---skinsettingsW-TRUE------------
					------------------------------'''
					xbmc.executebuiltin('Control.SetFocus(100,4)')
					xbmc.executebuiltin('Control.SetFocus(50,1)')
					xbmc.sleep(40)
					count = 0
					'''---------------------------'''
					count = 0
					systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
					while count < 10 and not name in systemcurrentcontrol and not xbmc.abortRequested:
						'''------------------------------
						---systemcurrentcontrol=name-----
						------------------------------'''
						xbmc.executebuiltin('Action(Down)')
						count += 1
						xbmc.sleep(40)
						if admin: print printfirst + space + "set_accountdate" + space2 + "systemcurrentcontrol=name" + space2 + systemcurrentcontrol + " != " + name + space3
						systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
						xbmc.sleep(100)
						
				
				if name == 'REALDEBRID': account_button(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, custom)
				elif name == 'SDAROT TV': account_button(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, custom)
				'''---------------------------'''
			elif number2N == 0:
				'''------------------------------
				---SETTING-OFF-------------------
				------------------------------'''
				setSkinSetting("1", skinsettingS, "false")
				setSkinSetting("0", skinsetting2S, "")
				setSkinSetting("0", skinsetting3S, "")
			'''---------------------------'''
	
		elif not skinsetting and number2N > 0:
			'''------------------------------
			---SETTING-SHOULD-BE-ON?---------
			------------------------------'''
			pass
			
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin and custom == "1": print printfirst + "set_accountdate" + space + "name" + space2 + name + space + skinsetting + space + skinsetting2 + space + "number2S" + space2 + number2S + space + custom + space3
	'''---------------------------'''