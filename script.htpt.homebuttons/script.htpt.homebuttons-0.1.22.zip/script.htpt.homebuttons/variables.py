'''------------------------------
---shared_variables--------------
------------------------------'''
import xbmcaddon, sys, os
servicehtptPath          = xbmcaddon.Addon('service.htpt').getAddonInfo("path")
sharedlibDir = os.path.join(servicehtptPath, 'resources', 'lib', 'shared')
sys.path.insert(0, sharedlibDir)
from shared_variables import *
'''---------------------------'''
#libDir = os.path.join(addonPath, 'resources', 'lib')
#sys.path.insert(0, libDir)

'''------------------------------
---script.htpt.homebuttons-------
------------------------------'''
getsetting         = xbmcaddon.Addon().getSetting
setsetting         = xbmcaddon.Addon().setSetting
addonName          = xbmcaddon.Addon().getAddonInfo("name")
addonString        = xbmcaddon.Addon().getLocalizedString
addonID          = xbmcaddon.Addon().getAddonInfo("id")
addonPath          = xbmcaddon.Addon().getAddonInfo("path")
addonVersion          = xbmcaddon.Addon().getAddonInfo("version")

printfirst = addonName + ": !@# "

General_ScriptON = getsetting('General_ScriptON')
'''---------------------------'''

'''------------------------------
---HOME-BUTTONS------------------
------------------------------'''
moviesbutton = xbmc.getCondVisibility('Container(9000).HasFocus(340)') and not xbmc.getCondVisibility('Control.HasFocus(9090)')
tvshowsbutton = xbmc.getCondVisibility('Container(9000).HasFocus(341)') and not xbmc.getCondVisibility('Control.HasFocus(9090)')
israeltvbutton = xbmc.getCondVisibility('Container(9000).HasFocus(342)')
youtubebutton = xbmc.getCondVisibility('Container(9000).HasFocus(343)')
goprobutton = xbmc.getCondVisibility('Container(9000).HasFocus(344)')
moviesebutton = xbmc.getCondVisibility('Container(9000).HasFocus(320)')
tvshowsebutton = xbmc.getCondVisibility('Container(9000).HasFocus(321)')
weatherbutton = xbmc.getCondVisibility('Container(9000).HasFocus(345)')
picturesbutton = xbmc.getCondVisibility('Container(9000).HasFocus(507)')
gamesbutton = xbmc.getCondVisibility('Container(9000).HasFocus(323)')
trailers2button = xbmc.getCondVisibility('Container(9000).HasFocus(351)')
quizbutton = xbmc.getCondVisibility('Container(9000).HasFocus(509)')
videosbutton = xbmc.getCondVisibility('Container(9000).HasFocus(325)')
musicbutton = xbmc.getCondVisibility('Container(9000).HasFocus(508)')
kidsbutton = xbmc.getCondVisibility('Container(9000).HasFocus(322)')
mov3dsbutton = xbmc.getCondVisibility('Container(9000).HasFocus(324)')
internetbutton = xbmc.getCondVisibility('Container(9000).HasFocus(327)')
gadgetbutton = xbmc.getCondVisibility('Container(9000).HasFocus(328)')
karaokebutton = xbmc.getCondVisibility('Container(9000).HasFocus(326)')
gametrailersbutton = xbmc.getCondVisibility('Container(9000).HasFocus(329)')
guitarbutton = xbmc.getCondVisibility('Container(9000).HasFocus(330)')
adultbutton2 = xbmc.getCondVisibility('Container(9000).HasFocus(331)')
favouritesbutton = xbmc.getCondVisibility('Container(9000).HasFocus(352)')
radiobutton = xbmc.getCondVisibility('Container(9000).HasFocus(356)')
morebutton = xbmc.getCondVisibility('Container(9000).HasFocus(357)')
settingsbutton = xbmc.getCondVisibility('Container(9000).HasFocus(348)')
htptchannelbutton = xbmc.getCondVisibility('Container(9000).HasFocus(375)')
adult2button = xbmc.getCondVisibility('Container(9000).HasFocus(331)')
widgettogglebutton = xbmc.getCondVisibility('Control.HasFocus(9090)')
test2button = xbmc.getCondVisibility('Container(9000).HasFocus(371)')

'''------------------------------
---CUSTOM-BUTTONS----------------
------------------------------'''
button99 = xbmc.getCondVisibility('Control.HasFocus(99)')
button101 = xbmc.getCondVisibility('Control.HasFocus(101)')
button102 = xbmc.getCondVisibility('Control.HasFocus(102)')
button103 = xbmc.getCondVisibility('Control.HasFocus(103)')
button104 = xbmc.getCondVisibility('Control.HasFocus(104)')
button105 = xbmc.getCondVisibility('Control.HasFocus(105)')


'''OTHERS BUTTONS'''
adultbutton = xbmc.getCondVisibility('Container(50).HasFocus(49)')
formatbutton = xbmc.getCondVisibility('Container(50).HasFocus(92)')
fixipbutton = xbmc.getCondVisibility('Container(50).HasFocus(116)')
trakttvbutton = xbmc.getCondVisibility('Container(50).HasFocus(94)')
sdarottvbutton = xbmc.getCondVisibility('Container(50).HasFocus(95)')
noobroombutton = xbmc.getCondVisibility('Container(50).HasFocus(96)')
premiumizebutton = xbmc.getCondVisibility('Container(50).HasFocus(97)')
movreelbutton = xbmc.getCondVisibility('Container(50).HasFocus(98)')
movreelbutton = xbmc.getCondVisibility('Container(50).HasFocus(98)')
realdebridbutton = xbmc.getCondVisibility('Container(50).HasFocus(99)')
userdataresetbutton = xbmc.getCondVisibility('Container(50).HasFocus(80)')
paymentmethodbutton = xbmc.getCondVisibility('Container(50).HasFocus(106)')
id60button = xbmc.getCondVisibility('Container(50).HasFocus(160)')
loginscreenbutton = (xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(100)'))
subsliderbutton = (xbmc.getCondVisibility('Window.IsVisible(DialogSubtitles.xml)') and xbmc.getCondVisibility('Control.HasFocus(73)'))
smartsearchbutton = (xbmc.getCondVisibility('Window.IsVisible(DialogSubtitles.xml)') and xbmc.getCondVisibility('Control.HasFocus(161)'))
stabilitytestbutton = xbmc.getCondVisibility('Container(100).HasFocus(5)') + xbmc.getCondVisibility('Control.HasFocus(130)') + skinsettingsW
#button = xbmc.getCondVisibility('Container(9000).HasFocus(?)')
#button = xbmc.getCondVisibility('Container(9000).HasFocus(?)')
#button = xbmc.getCondVisibility('Container(9000).HasFocus(?)')
'''SETTINGS'''
netsettingsbutton = (xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(108)')) or xbmc.getCondVisibility('Container(52).HasFocus(40)') or (xbmc.getCondVisibility('Window.IsVisible(Custom1170.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(10)'))
settinglevelbutton = xbmc.getCondVisibility('Control.HasFocus(20)')
'''HELP'''
airplaybutton = xbmc.getCondVisibility('Container(50).HasFocus(1)')
messagebutton = xbmc.getCondVisibility('Container(50).HasFocus(2)')
resetnetworkbutton = xbmc.getCondVisibility('Container(50).HasFocus(10)')
debugbutton = xbmc.getCondVisibility('Container(50).HasFocus(5)') or (xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(102)'))
#button = xbmc.getCondVisibility('Container(9000).HasFocus(?)')
'''LEFT MENU'''
searchisraeltv = xbmc.getCondVisibility('Control.HasFocus(107)')
deletesearchyoutube = xbmc.getCondVisibility('Control.HasFocus(109)')
statusjoystick = xbmc.getCondVisibility('Control.HasFocus(100)')
allowjoystick = xbmc.getCondVisibility('Control.HasFocus(102)')
leftmenubutton110 = xbmc.getCondVisibility('Control.HasFocus(110)') #EMULATOR-ADVANCED-SETTINGS
usbtoggle = xbmc.getCondVisibility('Control.HasFocus(70)')
controlisenabled70 = xbmc.getCondVisibility('Control.IsEnabled(70)')
numinumibutton = xbmc.getCondVisibility('Control.HasFocus(110)')
helpbutton = xbmc.getCondVisibility('Control.HasFocus(130)')
button704 = xbmc.getCondVisibility('Control.HasFocus(704)')
container50button320 = xbmc.getCondVisibility('Container(50).HasFocus(320)')
container50button321 = xbmc.getCondVisibility('Container(50).HasFocus(321)')
'''---------------------------'''


'''------------------------------
---VIDEO-------------------------
------------------------------'''

'''---------------------------'''	
playertime = xbmc.getInfoLabel("Player.Time(hh)") + xbmc.getInfoLabel("Player.Time(mm)") + xbmc.getInfoLabel("Player.Time(ss)")
playertimeremaining = xbmc.getInfoLabel("Player.TimeRemaining(hh)") + xbmc.getInfoLabel("Player.TimeRemaining(mm)") + xbmc.getInfoLabel("Player.TimeRemaining(ss)")
playerduration = xbmc.getInfoLabel("Player.Duration(hh)") + xbmc.getInfoLabel("Player.Duration(mm)") + xbmc.getInfoLabel("Player.Duration(ss)")

'''---------------------------'''

'''------------------------------
***MIXED-------------------------
------------------------------'''
#maccheck = xbmc.getInfoLabel('Network.MacAddress') + " ( " + xbmc.getInfoLabel('Skin.String(MAC1)') + " / " + xbmc.getInfoLabel('Skin.String(MAC2)') + " )"
myvideopath = xbmc.getCondVisibility('SubString(Container.FolderPath,special://userdata/library/videos)') or xbmc.getCondVisibility('SubString(Container.FolderPath,/var/media/)') or xbmc.getCondVisibility('SubString(Container.FolderPath,special://home/external/)') or xbmc.getCondVisibility('SubString(Container.FolderPath,sources://video/)') or xbmc.getCondVisibility('Skin.String(VarCurrentPicVid)')
'''---------------------------'''



'''------------------------------
---CUSTOM-------------
------------------------------'''
test = xbmc.getInfoLabel('Skin.String(Test)')
allowjoystickcon2 = xbmc.getCondVisibility('SubString(System.CurrentControl,$LOCALIZE[35100])')
vhomecon1 = xbmc.getCondVisibility('!Container(9000).HasFocus(348)') and xbmc.getCondVisibility('!Container(9000).HasFocus(323)') and xbmc.getCondVisibility('!Container(9000).HasFocus(340)') and xbmc.getCondVisibility('!Container(9000).HasFocus(341)') and xbmc.getCondVisibility('!Container(9000).HasFocus(325)') and xbmc.getCondVisibility('!Container(9000).HasFocus(346)') and xbmc.getCondVisibility('!Container(9000).HasFocus(507)') and xbmc.getCondVisibility('!Container(9000).HasFocus(508)') and xbmc.getCondVisibility('!Container(9000).HasFocus(509)')
maccon1 = xbmc.getCondVisibility('StringCompare(Skin.String(MAC),Skin.String(MAC1))')
maccon2 = xbmc.getCondVisibility('StringCompare(Skin.String(MAC),Skin.String(MAC2))')
maccon10 = xbmc.getCondVisibility('StringCompare(Control.GetLabel(700100),NONE)')
maccon11 = xbmc.getCondVisibility('StringCompare(Control.GetLabel(700100),7000)')

