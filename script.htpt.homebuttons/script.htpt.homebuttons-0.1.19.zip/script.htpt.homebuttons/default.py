import xbmc
import os, sys
import subprocess
import xbmcgui, xbmcaddon

from variables import *
from modules import *
from modules2 import *

def leftmenu(run):
	'''left menu'''
	containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
	if not validation:
		'''searchisraeltv'''
		if myvideonavW and searchisraeltv:
			xbmc.executebuiltin('Action(Right)')
			if containerfolderpath != israeltvhome:
				backward('run2')
				containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
				if containerfolderpath != israeltvhome:
					backward('run2')
					containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
					if containerfolderpath != israeltvhome:
						backward('run2')
						containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
			if containerfolderpath == israeltvhome:
				xbmc.executebuiltin('Action(PageUp)')
				xbmc.executebuiltin('Action(PageUp)')
				xbmc.executebuiltin('Action(PageUp)')
				xbmc.executebuiltin('Action(Down)')
				xbmc.executebuiltin('Action(Select)')
			print printfirst + "searchisraeltv"
		'''deletesearchyoutube'''
		#if myvideonavW and deletesearchyoutube:
			#Z = 'special://userdata/addon_data/plugin.video.youtube/settings.xml'
			#if admin: xbmc.executebuiltin('Notification(Admin,deletesearchyoutube,1000)')
			#A = '"store_searches" value='
			#B = '"[^ ]*"'
			#bash('sed -i "s|a|b|g" z,"deletesearchyoutube")
			#xbmc.executebuiltin('Action(Right)')
		if mypvrchannels:
			if controlhasfocus32:
				'''update live tv channels list'''
				xbmc.executebuiltin('RunScript(plugin.video.israelive,,mode=34)') #REFRESH ALL SETTINGS

		if helpbutton:
			if mypicsW:
				HelpButton_Video_Pic(str1, 'pictures')
			elif mymusicnavW:
				HelpButton_Video_Pic(str2, 'music')
			elif (myvideonavW and myvideopath):
				HelpButton_Video_Pic(str3, 'videos')
				
		'''70'''
		if (myvideonavW or mypicsW) and usbtoggle:
			if admin: xbmc.executebuiltin('Notification(Admin,usbtoggle,1000)')
			#videopath0 = xbmc.getCondVisibility('SubString(Container.FolderPath,special://userdata/library/videos/)')
			externalusb('run')
			if systemplatformwindows:
				path0 = 'special://userdata/library/'
				pathwin = 'special://home/external/'
				if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ path0 +')'):
					if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ pathwin +'videos/,return)')
					if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ pathwin +'pictures/,return)')
				if xbmc.getCondVisibility('SubString(Container.FolderPath,'+ pathwin +')'):
					if myvideonavW: xbmc.executebuiltin('ActivateWindow(Video,'+ path0 +'videos/,return)')
					if mypicsW: xbmc.executebuiltin('ActivateWindow(Pictures,'+ path0 +'pictures/,return)')
			print printfirst + "usbtoggle"
		if myvideonavW and numinumibutton:
			pl=xbmc.PlayList(1)
			pl.clear()
			count = 0
			while count < 7 and not xbmc.abortRequested:
				xbmc.sleep(10)
				count += 1
				listitem = xbmcgui.ListItem(numinumistr,
				thumbnailImage='special://skin/media/icons/kids.png')
				url = 'special://userdata/addon_data/skin.htpt/video/numinumi.mp4'
				xbmc.PlayList(1).add(url, listitem)

			xbmc.Player().play(pl)
			xbmc.executebuiltin('Action(Right)')
			xbmc.executebuiltin('Action(PageUp)')
			xbmc.executebuiltin('Action(FullScreen)')
	else:
		if admin: xbmc.executebuiltin('Notification(Admin,no buttonproceed,1000)')
		
def miscbuttons(admin):

	
	if subsliderbutton:
		'''------------------------------
		---subslider---------------------
		------------------------------'''
		if admin: notification("admin: " + "subsliderbutton","","",1000)
		if systemplatformwindows: filepath = "Z:\\addons\\script.htpt.homebuttons\\specials\\scripts\\subslider.py"
		if not systemplatformwindows: filepath = "/storage/.kodi/addons/script.htpt.homebuttons/specials/scripts/subslider.py"
		xbmc.executebuiltin('RunScript('+ filepath +', -10)')
		'''---------------------------'''
		
	if customhomecustomizerW:
		'''------------------------------
		---CustomHomeCustomizer----------
		------------------------------'''
		if button704:
			'''------------------------------
			---Startup-Window----------------
			------------------------------'''
			if container50button320 or container50button321:
			
				if container50button320:
					'''------------------------------
					---MOVIES------------------------
					------------------------------'''
					heading = str512 + space + str342
					list0 = "0. " + str20108 #root
					list1 = "1. " + addonString_genesis(30527).encode('utf-8') #Most Popular
					list2 = "2. " + addonString_genesis(30531).encode('utf-8') #Latest HD Movies
					list3 = "3. " + addonString_genesis(30535).encode('utf-8') #Search
					list4 = "4. " + addonString_genesis(30541).encode('utf-8') #Genres
					returned, value = dialogselect(heading,[list0, list1, list2, list3, list4],0)
					if returned != -1:
						setSkinSetting("0",'moviesestartup',str(returned))
						#setSkinSetting("0",'moviesestartup',value)
						'''---------------------------'''
					
				elif container50button321:
					'''------------------------------
					---TVSHOWS------------------------
					------------------------------'''
					heading = str512 + space + str20343
					list0 = "0. " + str20108 #root
					list1 = "1. " + addonString_genesis(30527).encode('utf-8') #Most Popular
					list2 = "2. " + addonString_genesis(30544).encode('utf-8') #Returning TV Shows
					list3 = "3. " + addonString_genesis(30535).encode('utf-8') #Search
					list4 = "4. " + addonString_genesis(30541).encode('utf-8') #Genres
					returned, value = dialogselect(heading,[list0, list1, list2, list3, list4],0)
					if returned != -1:
						setSkinSetting("0",'tvshowsestartup',str(returned))
						'''---------------------------'''

	if stabilitytestbutton:
		'''------------------------------
		---MODEL C - Stability Test------
		------------------------------'''
		if not systemplatformwindows: os.system('sh /storage/.kodi/addons/skin.htpt/specials/scripts/stabilitytest.sh')
		'''---------------------------'''
class main:
	setGeneral_ScriptON("0", General_ScriptON, "")
	mac('run',macaddress)
	if not validation and homeW: homebuttons(admin)
	if skinsettingsW: skinbuttons(admin)
	if custom1170W or loginscreenW: helpbuttons(admin)
	leftmenu('run')
	if netsettingsbutton: oewindow('Network')
	miscbuttons(admin)
	autoviewoff = xbmc.getInfoLabel('Skin.HasSetting(AutoViewoff)')
	if myvideonavW or mypicsW or mymusicnavW or myprogramsW or settingsW or filemanagerW or myweatherW or dialogfavouritesW:
		if home_pW and validation2: mac7('run',macaddress,maccon1,maccon2,maccon10,maccon11)
	if autoviewoff:
		print printfirst + "autoviewoff"
		xbmc.sleep(2000)
		xbmc.executebuiltin('Skin.ToggleSetting(AutoViewoff)')
	startup(validation)
	topvideoinformation2(admin)
	setGeneral_ScriptON("1", General_ScriptON, "")