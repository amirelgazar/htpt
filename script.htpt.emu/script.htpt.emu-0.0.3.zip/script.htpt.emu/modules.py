#import xbmc, os, subprocess, sys
#import xbmc, xbmcgui, xbmcaddon
import xbmc, xbmcgui, xbmcaddon
import os, subprocess
#import datetime
from variables import *
from shared_modules import *