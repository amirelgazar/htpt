#!/usr/bin/python
import xbmc, sys, xbmcaddon

from variables import *
from modules import *

class copyemu:
	if emubutton:
		returned = dialogyesno(addonString(18).encode('utf-8'), addonString(19).encode('utf-8'))
		if returned == "ok" and not systemplatformwindows:
			bash('rm -rf /storage/.kodi/userdata/addon_data/script.htpt.emu/launchers.xml',"launchers.xml")
			xbmc.sleep(500)
			os.system('sh /storage/.kodi/addons/script.htpt.emu/specials/scripts/copyemu.sh')
			xbmc.sleep(1000)
		
if not systemplatformwindows:
	bash('cp -f /storage/emulators/retroarch/config/retroarch.cfg /storage/.kodi/addons/script.htpt.emu/emusettings.py',"cp")
	xbmc.sleep(1000)
	
from emusettings import *

class emusettings2:
	'''------------------------------
	---CHANGE-RETROARCH-SETTINGS-----
	------------------------------'''
	setsetting('General_LastModified',datenowS)
	if not systemplatformwindows or systemplatformwindows:
		'''------------------------------
		---video_black_frame_insertion---
		------------------------------'''
		if video_black_frame_insertion2 != video_black_frame_insertion and video_black_frame_insertion2 != "":
			replace_word(file1,'video_black_frame_insertion = "' + video_black_frame_insertion + '"','video_black_frame_insertion = "' + video_black_frame_insertion2 + '"')
			replace_word(file2,'video_black_frame_insertion = "' + video_black_frame_insertion + '"','video_black_frame_insertion = "' + video_black_frame_insertion2 + '"')
			replace_word(file3,'video_black_frame_insertion = "' + video_black_frame_insertion + '"','video_black_frame_insertion = "' + video_black_frame_insertion2 + '"')
			replace_word(file4,'video_black_frame_insertion = "' + video_black_frame_insertion + '"','video_black_frame_insertion = "' + video_black_frame_insertion2 + '"')
			replace_word(file5,'video_black_frame_insertion = "' + video_black_frame_insertion + '"','video_black_frame_insertion = "' + video_black_frame_insertion2 + '"')
			replace_word(file6,'video_black_frame_insertion = "' + video_black_frame_insertion + '"','video_black_frame_insertion = "' + video_black_frame_insertion2 + '"')
			replace_word(file7,'video_black_frame_insertion = "' + video_black_frame_insertion + '"','video_black_frame_insertion = "' + video_black_frame_insertion2 + '"')
			replace_word(file8,'video_black_frame_insertion = "' + video_black_frame_insertion + '"','video_black_frame_insertion = "' + video_black_frame_insertion2 + '"')
			replace_word(file9,'video_black_frame_insertion = "' + video_black_frame_insertion + '"','video_black_frame_insertion = "' + video_black_frame_insertion2 + '"')
			print printfirst + space + "video_black_frame_insertion" + space2 + video_black_frame_insertion + " - " + video_black_frame_insertion2
			'''---------------------------'''
		
		'''------------------------------
		---video_refresh_rate------------
		------------------------------'''
		if video_refresh_rate2 != video_refresh_rate and video_refresh_rate2 != "":
			replace_word(file1,'video_refresh_rate = "' + video_refresh_rate + '"','video_refresh_rate = "' + video_refresh_rate2 + '"')
			replace_word(file2,'video_refresh_rate = "' + video_refresh_rate + '"','video_refresh_rate = "' + video_refresh_rate2 + '"')
			replace_word(file3,'video_refresh_rate = "' + video_refresh_rate + '"','video_refresh_rate = "' + video_refresh_rate2 + '"')
			replace_word(file4,'video_refresh_rate = "' + video_refresh_rate + '"','video_refresh_rate = "' + video_refresh_rate2 + '"')
			replace_word(file5,'video_refresh_rate = "' + video_refresh_rate + '"','video_refresh_rate = "' + video_refresh_rate2 + '"')
			replace_word(file6,'video_refresh_rate = "' + video_refresh_rate + '"','video_refresh_rate = "' + video_refresh_rate2 + '"')
			replace_word(file7,'video_refresh_rate = "' + video_refresh_rate + '"','video_refresh_rate = "' + video_refresh_rate2 + '"')
			replace_word(file8,'video_refresh_rate = "' + video_refresh_rate + '"','video_refresh_rate = "' + video_refresh_rate2 + '"')
			replace_word(file9,'video_refresh_rate = "' + video_refresh_rate + '"','video_refresh_rate = "' + video_refresh_rate2 + '"')
			print printfirst + space + "video_refresh_rate" + space2 + video_refresh_rate + " - " + video_refresh_rate2
			'''---------------------------'''
		
		'''------------------------------
		---video_smooth------------
		------------------------------'''
		if video_smooth2 != video_smooth and video_smooth2 != "":
			replace_word(file1,'video_smooth = "' + video_smooth + '"','video_smooth = "' + video_smooth2 + '"')
			replace_word(file2,'video_smooth = "' + video_smooth + '"','video_smooth = "' + video_smooth2 + '"')
			replace_word(file3,'video_smooth = "' + video_smooth + '"','video_smooth = "' + video_smooth2 + '"')
			replace_word(file4,'video_smooth = "' + video_smooth + '"','video_smooth = "' + video_smooth2 + '"')
			replace_word(file5,'video_smooth = "' + video_smooth + '"','video_smooth = "' + video_smooth2 + '"')
			replace_word(file6,'video_smooth = "' + video_smooth + '"','video_smooth = "' + video_smooth2 + '"')
			replace_word(file7,'video_smooth = "' + video_smooth + '"','video_smooth = "' + video_smooth2 + '"')
			replace_word(file8,'video_smooth = "' + video_smooth + '"','video_smooth = "' + video_smooth2 + '"')
			replace_word(file9,'video_smooth = "' + video_smooth + '"','video_smooth = "' + video_smooth2 + '"')
			print printfirst + space + "video_smooth" + space2 + video_smooth + " - " + video_smooth2
			'''---------------------------'''
			
		'''------------------------------
		---audio_device2-----------------
		------------------------------'''
		if audio_device2 != audio_device and audio_device2 != "":
			replace_word(file1,'audio_device = "' + audio_device + '"','audio_device = "' + audio_device2 + '"')
			replace_word(file2,'audio_device = "' + audio_device + '"','audio_device = "' + audio_device2 + '"')
			replace_word(file3,'audio_device = "' + audio_device + '"','audio_device = "' + audio_device2 + '"')
			replace_word(file4,'audio_device = "' + audio_device + '"','audio_device = "' + audio_device2 + '"')
			replace_word(file5,'audio_device = "' + audio_device + '"','audio_device = "' + audio_device2 + '"')
			replace_word(file6,'audio_device = "' + audio_device + '"','audio_device = "' + audio_device2 + '"')
			replace_word(file7,'audio_device = "' + audio_device + '"','audio_device = "' + audio_device2 + '"')
			replace_word(file8,'audio_device = "' + audio_device + '"','audio_device = "' + audio_device2 + '"')
			replace_word(file9,'audio_device = "' + audio_device + '"','audio_device = "' + audio_device2 + '"')
			print printfirst + space + "audio_device" + space2 + audio_device + " - " + audio_device2
			'''---------------------------'''
		
		'''------------------------------
		---audio_out_rate----------------
		------------------------------'''
		if audio_out_rate2 != audio_out_rate and audio_out_rate2 != "":
			replace_word(file1,'audio_out_rate = "' + audio_out_rate + '"','audio_out_rate = "' + audio_out_rate2 + '"')
			replace_word(file2,'audio_out_rate = "' + audio_out_rate + '"','audio_out_rate = "' + audio_out_rate2 + '"')
			replace_word(file3,'audio_out_rate = "' + audio_out_rate + '"','audio_out_rate = "' + audio_out_rate2 + '"')
			replace_word(file4,'audio_out_rate = "' + audio_out_rate + '"','audio_out_rate = "' + audio_out_rate2 + '"')
			replace_word(file5,'audio_out_rate = "' + audio_out_rate + '"','audio_out_rate = "' + audio_out_rate2 + '"')
			replace_word(file6,'audio_out_rate = "' + audio_out_rate + '"','audio_out_rate = "' + audio_out_rate2 + '"')
			replace_word(file7,'audio_out_rate = "' + audio_out_rate + '"','audio_out_rate = "' + audio_out_rate2 + '"')
			replace_word(file8,'audio_out_rate = "' + audio_out_rate + '"','audio_out_rate = "' + audio_out_rate2 + '"')
			replace_word(file9,'audio_out_rate = "' + audio_out_rate + '"','audio_out_rate = "' + audio_out_rate2 + '"')
			print printfirst + space + "audio_out_rate" + space2 + audio_out_rate + " - " + audio_out_rate2
			'''---------------------------'''
		
		'''------------------------------
		---audio_sync--------------------
		------------------------------'''
		if audio_sync2 != audio_sync and audio_sync2 != "":
			replace_word(file1,'audio_sync = "' + audio_sync + '"','audio_sync = "' + audio_sync + '"')
			replace_word(file2,'audio_sync = "' + audio_sync + '"','audio_sync = "' + audio_sync + '"')
			replace_word(file3,'audio_sync = "' + audio_sync + '"','audio_sync = "' + audio_sync + '"')
			replace_word(file4,'audio_sync = "' + audio_sync + '"','audio_sync = "' + audio_sync + '"')
			replace_word(file5,'audio_sync = "' + audio_sync + '"','audio_sync = "' + audio_sync + '"')
			replace_word(file6,'audio_sync = "' + audio_sync + '"','audio_sync = "' + audio_sync + '"')
			replace_word(file7,'audio_sync = "' + audio_sync + '"','audio_sync = "' + audio_sync + '"')
			replace_word(file8,'audio_sync = "' + audio_sync + '"','audio_sync = "' + audio_sync + '"')
			replace_word(file9,'audio_sync = "' + audio_sync + '"','audio_sync = "' + audio_sync + '"')
			print printfirst + space + "audio_sync" + space2 + audio_sync + " - " + audio_sync2
			'''---------------------------'''
			
		'''------------------------------
		---audio_latency-----------------
		------------------------------'''
		if audio_latency2 != audio_latency and audio_latency2 != "":
			replace_word(file1,'audio_latency = "' + audio_latency + '"','audio_latency = "' + audio_latency2 + '"')
			replace_word(file2,'audio_latency = "' + audio_latency + '"','audio_latency = "' + audio_latency2 + '"')
			replace_word(file3,'audio_latency = "' + audio_latency + '"','audio_latency = "' + audio_latency2 + '"')
			replace_word(file4,'audio_latency = "' + audio_latency + '"','audio_latency = "' + audio_latency2 + '"')
			replace_word(file5,'audio_latency = "' + audio_latency + '"','audio_latency = "' + audio_latency2 + '"')
			replace_word(file6,'audio_latency = "' + audio_latency + '"','audio_latency = "' + audio_latency2 + '"')
			replace_word(file7,'audio_latency = "' + audio_latency + '"','audio_latency = "' + audio_latency2 + '"')
			replace_word(file8,'audio_latency = "' + audio_latency + '"','audio_latency = "' + audio_latency2 + '"')
			replace_word(file9,'audio_latency = "' + audio_latency + '"','audio_latency = "' + audio_latency2 + '"')
			print printfirst + space + "audio_latency" + space2 + audio_latency + " - " + audio_latency2
			
		'''------------------------------
		---audio_volume------------------
		------------------------------'''
		if audio_volume2 != audio_volume and audio_volume2 != "":
			replace_word(file1,'audio_volume = "' + audio_volume + '"','audio_volume = "' + audio_volume2 + '"')
			replace_word(file2,'audio_volume = "' + audio_volume + '"','audio_volume = "' + audio_volume2 + '"')
			replace_word(file3,'audio_volume = "' + audio_volume + '"','audio_volume = "' + audio_volume2 + '"')
			replace_word(file4,'audio_volume = "' + audio_volume + '"','audio_volume = "' + audio_volume2 + '"')
			replace_word(file5,'audio_volume = "' + audio_volume + '"','audio_volume = "' + audio_volume2 + '"')
			replace_word(file6,'audio_volume = "' + audio_volume + '"','audio_volume = "' + audio_volume2 + '"')
			replace_word(file7,'audio_volume = "' + audio_volume + '"','audio_volume = "' + audio_volume2 + '"')
			replace_word(file8,'audio_volume = "' + audio_volume + '"','audio_volume = "' + audio_volume2 + '"')
			replace_word(file9,'audio_volume = "' + audio_volume + '"','audio_volume = "' + audio_volume2 + '"')
			print printfirst + space + "audio_volume" + space2 + audio_volume + " - " + audio_volume2
		
class emusettings3:
	if emubutton:
		if admin: notification("emubutton","","",1000)
		bash('retroarch --menu -v -c /storage/emulators/retroarch/config/retroarch.cfg',"retroarch menu")