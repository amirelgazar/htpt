import xbmc, os, subprocess, sys
import xbmcgui, xbmcaddon

xbmc.sleep(10000)

from variables import *
from modules import *

class main:
	'''------------------------------
	---STARTUP-----------------------
	------------------------------'''
	xbmc.sleep(5000)
	if not systemplatformwindows: os.system('sh /storage/.kodi/addons/script.htpt.emu/specials/scripts/copyemu.sh')
	xbmc.sleep(2000)
	xbmc.executebuiltin('runscript(script.htpt.emu,,)')