import xbmc, xbmcgui, xbmcaddon
import os, subprocess

from variables import *
from shared_modules import *