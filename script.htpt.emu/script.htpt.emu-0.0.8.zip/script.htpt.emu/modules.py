import xbmc, xbmcgui, xbmcaddon
import os, subprocess

from variables import *
from shared_modules import *

def downloads(admin, printpoint, name, connected):

	
	if connected:
		printpoint = printpoint + "1"
		#from commondownloader import * #GAL TEST THIS!
		file = ""
		
		if not systemplatformwindows:
			printpoint = printpoint + "2"
			if "A" in id10str or "B" in id10str:
				printpoint = printpoint + "3"
				if addonVersion != "0.0.8":
					printpoint = printpoint + "4"
					if not os.path.exists(os.path.join(rom_path,'Sega Master System')):
						file = "Sega Master System.zip"
						fileID = getfileID(file)
						DownloadFile("https://www.dropbox.com/s/"+fileID+"/Sega%20Master%20System.zip?dl=1", file, temp_path, rom_path)
					elif not os.path.exists(os.path.join(rom_path,'TurboGrafx 16')):
						file = "TurboGrafx 16.zip"
						fileID = getfileID(file)
						DownloadFile("https://www.dropbox.com/s/"+fileID+"/TurboGrafx%2016.zip?dl=1", file, temp_path, rom_path)
					elif not os.path.exists(os.path.join(rom_path,'Sega Genesis')):
						file = "Sega Genesis.zip"
						fileID = getfileID(file)
						DownloadFile("https://www.dropbox.com/s/"+fileID+"/Sega%20Genesis.zip?dl=1", file, temp_path, rom_path)
					elif not os.path.exists(os.path.join(rom_path,'Nintendo')):
						file = "Nintendo.zip"
						fileID = getfileID(file)
						DownloadFile("https://www.dropbox.com/s/"+fileID+"/Nintendo.zip?dl=1", file, temp_path, rom_path)
					elif not os.path.exists(os.path.join(rom_path,'Super Nintendo')):
						file = "Super Nintendo.zip"
						fileID = getfileID(file)
						DownloadFile("https://www.dropbox.com/s/"+fileID+"/Super%20Nintendo.zip?dl=1", file, temp_path, rom_path)
					elif not os.path.exists(os.path.join(rom_path,'Nintendo 64')):
						file = "Nintendo 64.zip"
						fileID = getfileID(file)
						DownloadFile("https://www.dropbox.com/s/"+fileID+"/Nintendo%2064.zip?dl=1", file, temp_path, rom_path)
	
	else: printpoint = printpoint + "9"
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + name + "_LV" + printpoint + space + "file" + space2 + file
	'''---------------------------'''
	
def mode4(admin, name):
	'''------------------------------
	---OPEN-SETTINGS-----------------
	------------------------------'''
	returned = dialogyesno(addonString(16).encode('utf-8'), addonString(17).encode('utf-8'))
	if returned == "ok":
		xbmc.executebuiltin('Addon.OpenSettings(script.htpt.emu)')
		xbmc.sleep(2000)
		dialogaddonsettingsW = xbmc.getCondVisibility('Window.IsVisible(DialogAddonSettings.xml)')
		while dialogaddonsettingsW and not xbmc.abortRequested:
			xbmc.sleep(1000)
			dialogaddonsettingsW = xbmc.getCondVisibility('Window.IsVisible(DialogAddonSettings.xml)')
			'''---------------------------'''
	if admin:
		print printfirst + name + space + "file1_fix" + space2 + file1_fix + newline + "file1_fix2" + space2 + file1_fix2 + newline + "configpath" + space2 + configpath + newline + "file1_fix" + space2 + file1_fix

def mode5(admin, name):
	'''------------------------------
	---MUSIC-DEBUG-------------------
	------------------------------'''
	if not systemplatformwindows:
		returned = dialogyesno(addonString(79), localize(79603))
		if returned == 'ok':					
			output = bash('aplay -l | grep -e "card" | grep -n ""','aplay -l')
			output = output.split('\n')
			CARD_DEVICE = ""
			i = 0
			for line in output:
				if line != "":
					i += 1
					CARD_ = find_string(line, "card ", ": ")
					CARD_ = CARD_.replace("card ","")
					CARD_ = CARD_.replace(": ",",")
					DEVICE_ = find_string(line, "device ", ": ")
					DEVICE_ = DEVICE_.replace("device ","")
					DEVICE_ = DEVICE_.replace(": ","")
					CARD_DEVICE = CARD_DEVICE + newline + "OPTION" + str(i) + space2 + "hw:" + CARD_ + DEVICE_
					
			print CARD_ + space + DEVICE_ + newline + str(output) + "CARD_DEVICE" + space2 + CARD_DEVICE
			header = addonString(79).encode('utf-8')
			message2 = "[CR]---------------------------[CR]" + CARD_DEVICE + "[CR]---------------------------[CR][CR]" + addonString(77).encode('utf-8')
			w = TextViewer_Dialog('DialogTextViewer.xml', "", header=header, text=message2)
			w.doModal()
			'''---------------------------'''

def mode6(admin, name):
	'''------------------------------
	---RELOAD-CFG--------------------
	------------------------------'''
	returned = dialogyesno(addonString(18).encode('utf-8'), addonString(19).encode('utf-8') + '[CR]' + addonString(15).encode('utf-8'))
	if returned == "ok" and not systemplatformwindows:
		path = os.path.join(addondata_path, 'script.htpt.emu', 'launchers.xml')
		removefiles(path)
		xbmc.sleep(500)
		os.system('sh /storage/.kodi/addons/script.htpt.emu/specials/scripts/copyemu.sh')
		xbmc.sleep(1000)
	else: notification_common("9")
	
	