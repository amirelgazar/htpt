#import xbmc, os, subprocess, sys
#import xbmc, xbmcgui, xbmcaddon
import xbmc, xbmcgui, xbmcaddon
from variables import *
#from variablesp import *
from modulesp import *
#from shared_modules import *