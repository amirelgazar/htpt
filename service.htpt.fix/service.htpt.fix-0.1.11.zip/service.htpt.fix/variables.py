'''------------------------------
---shared_variables--------------
------------------------------'''
import xbmcaddon, sys, os
servicehtptPath          = xbmcaddon.Addon('service.htpt').getAddonInfo("path")
sharedlibDir = os.path.join(servicehtptPath, 'resources', 'lib', 'shared')
sys.path.insert(0, sharedlibDir)
from shared_variables import *
'''---------------------------'''
#libDir = os.path.join(addonPath, 'resources', 'lib')
#sys.path.insert(0, libDir)

'''------------------------------
---ADDON-COMMON------------------
------------------------------'''
getsetting         = xbmcaddon.Addon().getSetting
setsetting         = xbmcaddon.Addon().setSetting
addonName          = xbmcaddon.Addon().getAddonInfo("name")
addonString        = xbmcaddon.Addon().getLocalizedString
addonID          = xbmcaddon.Addon().getAddonInfo("id")
addonPath          = xbmcaddon.Addon().getAddonInfo("path")
addonVersion          = xbmcaddon.Addon().getAddonInfo("version")

printfirst = addonName + ": !@# "
'''------------------------------
---service.htpt.fix--------------
------------------------------'''
Addon_Update = getsetting('Addon_Update')
Addon_UpdateDate = getsetting('Addon_UpdateDate')
Addon_UpdateLog = getsetting('Addon_UpdateLog')
Addon_Version = getsetting('Addon_Version')
Addon_ServiceON = getsetting('Addon_ServiceON')
'''---------------------------'''
Fix_1 = getsetting('Fix_1')
Fix_2 = getsetting('Fix_2')
Fix_3 = getsetting('Fix_3')
Fix_4 = getsetting('Fix_4')
Fix_5 = getsetting('Fix_5')
'''---------------------------'''
Fix_10 = getsetting('Fix_10')
Fix_11 = getsetting('Fix_11')
Fix_12 = getsetting('Fix_12')
Fix_13 = getsetting('Fix_13')
Fix_14 = getsetting('Fix_14')
'''---------------------------'''
Fix_100 = getsetting('Fix_100')
Fix_101 = getsetting('Fix_101')
Fix_102 = getsetting('Fix_102')
Fix_103 = getsetting('Fix_103')
Fix_104 = getsetting('Fix_104')
Fix_L = [Fix_1, Fix_2, Fix_3, Fix_4, Fix_5, Fix_100, Fix_101, Fix_102, Fix_103, Fix_104]
Fix_LastDate = getsetting('Fix_LastDate')
Fix_Done = getsetting('Fix_Done')
'''---------------------------'''
Red_Alert = getsetting('Red_Alert')
Red_LV1 = getsetting('Red_LV1')
Red_LV2 = getsetting('Red_LV2')
Red_LV3 = getsetting('Red_LV3')
Red_LV4 = getsetting('Red_LV4')
Red_LV5 = getsetting('Red_LV5')
Red_L = [Red_LV1, Red_LV2, Red_LV3, Red_LV4, Red_LV5]
Red_LastDate = getsetting('Red_LastDate')
Red_Done = getsetting('Red_Done')
'''---------------------------'''
Purchase_Date = getsetting('Purchase_Date')
#Purchase_UpdateLog = getsetting('Purchase_UpdateLog')



'''------------------------------
---systemhasaddon----------------
------------------------------'''
systemhasaddon_metadatauniversal = xbmc.getCondVisibility('System.HasAddon(metadata.universal)')
systemhasaddon_metadatathemoviedb = xbmc.getCondVisibility('System.HasAddon(metadata.themoviedb.org)')
systemhasaddon_scripthtptdebug = xbmc.getCondVisibility('System.HasAddon(script.htpt.debug)')
systemhasaddon_servicehtpt = xbmc.getCondVisibility('System.HasAddon(service.htpt)')
'''---------------------------'''

'''---------------------------'''
if systemhasaddon_servicehtpt:
	getsetting_servicehtpt = xbmcaddon.Addon('service.htpt').getSetting

	servicehtpt_Skin_UpdateLog = getsetting_servicehtpt('Skin_UpdateLog')
	'''---------------------------'''
else:
	xbmc.executebuiltin('ActivateWindow(10025,plugin://service.htpt)')
	xbmc.executebuiltin('Action(Down)')
	xbmc.executebuiltin('Action(Select)')
	xbmc.sleep(15000)

'''------------------------------
---System.-----------------------
------------------------------'''
systeminternetstate = xbmc.getInfoLabel('System.InternetState')
systemuptime = xbmc.getInfoLabel('System.Uptime')
systemcputemperature = xbmc.getInfoLabel('System.CPUTemperature')
screenresolution = xbmc.getInfoLabel('System.ScreenResolution')
dhcpaddress = xbmc.getInfoLabel('Network.DHCPAddress')
systemuptime2 = xbmc.getInfoLabel('System.Uptime') + " / " + xbmc.getInfoLabel('System.TotalUptime') 
freespace2 = xbmc.getInfoLabel('System.TotalSpace') + " / " + xbmc.getInfoLabel('System.FreeSpacePercent')
if xbmc.getCondVisibility('System.HasAddon(service.htpt)'): htptversion = xbmc.getInfoLabel('System.AddonVersion(skin.htpt)') + "+"
elif xbmc.getCondVisibility('!System.HasAddon(service.htpt)'): htptversion = xbmc.getInfoLabel('System.AddonVersion(skin.htpt)') + "-"
buildversion = xbmc.getInfoLabel('System.BuildVersion')
htptdebugversion = xbmc.getInfoLabel('System.AddonVersion(script.htpt.debug)')
htptserviceversion = xbmc.getInfoLabel('system.AddonVersion(service.htpt)')
htpthelpversion = xbmc.getInfoLabel('System.AddonVersion(service.htpt.help)')
htpthomebuttonsversion = xbmc.getInfoLabel('System.AddonVersion(script.htpt.homebuttons)')
htptremoteversion = xbmc.getInfoLabel('System.AddonVersion(script.htpt.remote)')
htptrefreshversion = xbmc.getInfoLabel('System.AddonVersion(script.htpt.refresh)')
htptfixversion = xbmc.getInfoLabel('System.AddonVersion(service.htpt.fix)')


'''------------------------------
---DATES-----------------------
------------------------------'''	
datenow = datetime.date.today()
datenowS = str(datenow)

dateafter = datenow + datetime.timedelta(days=7)
dateafterS = str(dateafter)

daynow = datenow.strftime("%a")
daynowS = str(daynow)
timenow = datetime.datetime.now()
timenow3 = timenow.strftime("%H")
timenow3S = str(timenow3)
timenow3N = int(timenow3S)

'''------------------------------
---CONTAINER---------------------
------------------------------'''
containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
container120numitems = xbmc.getInfoLabel('Container(120).NumItems') #DialogSubtitles

'''------------------------------
---Network.----------------------
------------------------------'''
networkgatewayaddress = xbmc.getInfoLabel('Network.GatewayAddress')
networkipaddress = xbmc.getInfoLabel('Network.IPAddress')
'''------------------------------
---VIDEO-------------------------
------------------------------'''
playerhasvideo = xbmc.getCondVisibility('Player.HasVideo')
playerpaused = xbmc.getCondVisibility('Player.Paused')
videoplayerhassubtitles = xbmc.getCondVisibility('VideoPlayer.HasSubtitles')
playercache = xbmc.getInfoLabel('Player.CacheLevel')
playertitle = xbmc.getInfoLabel('Player.Title')
'''---------------------------'''	
playertime = xbmc.getInfoLabel("Player.Time(hh)") + xbmc.getInfoLabel("Player.Time(mm)") + xbmc.getInfoLabel("Player.Time(ss)")
playertimeremaining = xbmc.getInfoLabel("Player.TimeRemaining(hh)") + xbmc.getInfoLabel("Player.TimeRemaining(mm)") + xbmc.getInfoLabel("Player.TimeRemaining(ss)")
playerduration = xbmc.getInfoLabel("Player.Duration(hh)") + xbmc.getInfoLabel("Player.Duration(mm)") + xbmc.getInfoLabel("Player.Duration(ss)")

'''---------------------------'''
playlistlength = xbmc.getInfoLabel('Playlist.Length(video)')
playlistlengthN = int(playlistlength)
playlistposition = xbmc.getInfoLabel('Playlist.Position(video)')
playlistpositionN = int(playlistposition)
'''---------------------------'''
videoplayertitle = xbmc.getInfoLabel('VideoPlayer.Title')
videoplayerseason = xbmc.getInfoLabel('VideoPlayer.Season')
videoplayertvshowtitle = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
videoplayeryear = xbmc.getInfoLabel('VideoPlayer.Year')
videoplayertagline = xbmc.getInfoLabel('VideoPlayer.Tagline')
videoplayercountry = xbmc.getInfoLabel('VideoPlayer.Country')
videoplayerseason = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
#videoplayerseason = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
#videoplayerseason = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
#videoplayerseason = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
videoplayercontentMOVIE = xbmc.getCondVisibility('VideoPlayer.Content(movies)')
videoplayercontentTV = xbmc.getCondVisibility('VideoPlayer.Content(tvshows)')
videoplayercontentSEASON = xbmc.getCondVisibility('VideoPlayer.Content(seasons)')
videoplayercontentEPISODE = xbmc.getCondVisibility('VideoPlayer.Content(episodes)')




'''------------------------------
---CUSTOM-------------
------------------------------'''

dialogselectsources = xbmc.getInfoLabel('Skin.String(DialogSelectSources)')
dialogselectsources2 = xbmc.getInfoLabel('Skin.String(DialogSelectSources2)')
dialogselectsources3 = xbmc.getInfoLabel('Skin.String(DialogSelectSources3)')
dialogselectsources5 = xbmc.getInfoLabel('Skin.String(DialogSelectSources5)')

dialogsubtitles2 = xbmc.getInfoLabel('Skin.String(DialogSubtitles2)')
dialogsubtitlesna1 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA1)')
dialogsubtitlesna2 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA2)')
dialogsubtitlesna3 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA3)')
dialogsubtitlesna4 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA4)')
dialogsubtitlesna5 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA5)')
dialogsubtitlesna6 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA6)')
dialogsubtitlesna7 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA7)')
dialogsubtitlesna8 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA8)')
dialogsubtitlesna9 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA9)')
dialogsubtitlesna10 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA10)')


'''------------------------------
---MIXED-------------------------
------------------------------'''
hasinternet = systeminternetstate != "" and networkipaddress != "" and not "169.254." in networkipaddress and (connected or systemplatformwindows)
mac = xbmc.getInfoLabel('Network.MacAddress') + " ( " + xbmc.getInfoLabel('Skin.String(MAC1)') + " / " + xbmc.getInfoLabel('Skin.String(MAC2)') + " )"
istv = (xbmc.getInfoLabel('ListItem.TVShowTitle') != "" and xbmc.getInfoLabel('ListItem.Season') != "" and xbmc.getInfoLabel('ListItem.Episode') != "") or ("videodb://tvshows" in containerfolderpath or "library://video/tvshows" in containerfolderpath)
istvS = str(istv)
ismovie = (xbmc.getInfoLabel('ListItem.Year') != "" or xbmc.getInfoLabel('ListItem.Country') != "" or xbmc.getInfoLabel('ListItem.Tagline') != "") and not istv
ismovieS = str(ismovie)
istv4 = " S" in dialogselectsources3 and " E" in dialogselectsources3
istv4S = str(istv4)
ismovie4 = " (" in dialogselectsources3 and ")" in dialogselectsources3 and not istv4
ismovie4S = str(ismovie4)
istvmoviep = (videoplayertitle in dialogselectsources3 or videoplayertitle in dialogselectsources5)
isgenesis = "videodb://tvshows" in containerfolderpath or "library://video/tvshows" in containerfolderpath or "plugin://plugin.video.genesis/" in containerfolderpath

'''------------------------------
---Library.----------------------
------------------------------'''
libraryisscanningvideo = xbmc.getCondVisibility('Library.IsScanningVideo')
libraryisscanningmusic = xbmc.getCondVisibility('Library.IsScanningMusic')

'''------------------------------
---CONTROL-----------------------
------------------------------'''
cancelbutton = xbmc.getCondVisibility('Control.HasFocus(10)') and xbmc.getCondVisibility('Window.IsActive(DialogProgress.xml)')
autoplaypausebutton = (xbmc.getCondVisibility('Window.IsVisible(Home.xml)') and xbmc.getCondVisibility('Control.HasFocus(9093)')) or (xbmc.getCondVisibility('Window.IsVisible(MyVideoNav.xml)') and xbmc.getCondVisibility('Control.HasFocus(111)'))
debugbutton = xbmc.getCondVisibility('Container(50).HasFocus(5)') or (xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(102)'))
controlisvisible311 = xbmc.getCondVisibility('Control.IsVisible(311)') or xbmc.getCondVisibility('Control.HasFocus(340)')
controlisvisible311S = str(controlisvisible311)
controlisvisible312 = xbmc.getCondVisibility('Control.IsVisible(312)') or xbmc.getCondVisibility('Control.HasFocus(341)')
controlisvisible312S = str(controlisvisible312)
controlgetlabel100 = xbmc.getInfoLabel('Control.GetLabel(100)') #DialogSubtitles Service Name
controlhasfocus20 = xbmc.getCondVisibility('Control.HasFocus(20)')

	
'''------------------------------
---$LOCALIZE--------------------
------------------------------'''
truestr = xbmc.getInfoLabel('$LOCALIZE[20122]')
trialstr = xbmc.getInfoLabel('$LOCALIZE[70001]') #Trial
trial2str = xbmc.getInfoLabel('$LOCALIZE[70002]') #TrialRenew
trial3str = xbmc.getInfoLabel('$LOCALIZE[70003]') #TrialEnd (PREVIOUSLY-TrailEnd)
verrorstr = xbmc.getInfoLabel('$VAR[VERROR]')
str79041 = xbmc.getInfoLabel('$LOCALIZE[79041]')
id6v1str = xbmc.getInfoLabel('$LOCALIZE[70014]')
id6v2str = xbmc.getInfoLabel('$LOCALIZE[70015]')
id6v3str = xbmc.getInfoLabel('$LOCALIZE[70016]')
str20442 = xbmc.getInfoLabel('$LOCALIZE[20442]') #Change content
str20333 = xbmc.getInfoLabel('$LOCALIZE[20333]') #Set content
str342 = xbmc.getInfoLabel('$LOCALIZE[342]') #Movies
str36901 = xbmc.getInfoLabel('$LOCALIZE[36901]') #movies
str231 = xbmc.getInfoLabel('$LOCALIZE[231]') #None
str16018 = xbmc.getInfoLabel('$LOCALIZE[16018]') #None
str36909 = xbmc.getInfoLabel('$LOCALIZE[36909]') #musicvideos
str20389 = xbmc.getInfoLabel('$LOCALIZE[20389]') #Music videos
str36903 = xbmc.getInfoLabel('$LOCALIZE[36903]') #TV shows
str20343 = xbmc.getInfoLabel('$LOCALIZE[20343]') #TV shows
str186 = xbmc.getInfoLabel('$LOCALIZE[186]') #OK
str12321 = xbmc.getInfoLabel('$LOCALIZE[186]') #Ok
str106 = xbmc.getInfoLabel('$LOCALIZE[106]') #No
str107 = xbmc.getInfoLabel('$LOCALIZE[107]') #Yes
str222 = xbmc.getInfoLabel('$LOCALIZE[222]') #Cancel
str20329 = xbmc.getInfoLabel('$LOCALIZE[20329]') #Movies are in separate folders that match the movie title
str20346 = xbmc.getInfoLabel('$LOCALIZE[20346]') #Scan recursively
str70020 = xbmc.getInfoLabel('$LOCALIZE[70020]') #WOULD YOU LIKE TO ADD THIS CONTENT TO HTPT?


'''------------------------------
---LIST--------------------------
------------------------------'''
#ChangeContentL = ["(" + str20442 + ")","(" + str342 + ")","(" + str36901 + ")","(" + str231 + ")","(" + str16018 + ")","(" + str36909 + ")","(" + str20389 + ")","(" + str36903 + ")","(" + str20343 + ")"] #Change content
ChangeContentL = [str20442,str342,str36901,str231,str16018,str36909,str20389,str36903,str20343] #Change content



'''------------------------------
---ID----------------------------
------------------------------'''
'''idstr = USERNAME EN , id1str = USERNAME HE, id2str = INSTALLATION DATE, id3str = WARRENTY END, id4str = ADDRESS, id5str = TELEPHONE NUMBER, id6str = PAYMENT TERMS, id7str = QUESTION, id8str = TECHNICAL NAME, id9str = CODE RED, id10str = HTPT'S MODEL, ID11 = MAC1, ID12 = MAC2'''
idstr = xbmc.getInfoLabel('Skin.String(ID)')
id1str = xbmc.getInfoLabel('Skin.String(ID1)')
id2str = xbmc.getInfoLabel('Skin.String(ID2)')
id3str = xbmc.getInfoLabel('Skin.String(ID3)')
id4str = xbmc.getInfoLabel('Skin.String(ID4)')
id5str = xbmc.getInfoLabel('Skin.String(ID5)')
id6str = xbmc.getInfoLabel('Skin.String(ID6)')
id7str = xbmc.getInfoLabel('Skin.String(ID7)')
id8str = xbmc.getInfoLabel('Skin.String(ID8)')
id9str = xbmc.getInfoLabel('Skin.String(ID9)')
id10str = xbmc.getInfoLabel('Skin.String(ID10)')
id11str = xbmc.getInfoLabel('Skin.String(ID11)')
id12str = xbmc.getInfoLabel('Skin.String(ID12)')
id60str = xbmc.getInfoLabel('Skin.String(ID60)')
''''''
idnamestr = xbmc.getInfoLabel('$LOCALIZE[1014]')
id2namestr = xbmc.getInfoLabel('$LOCALIZE[70010]')
id3namestr = xbmc.getInfoLabel('$LOCALIZE[70011]')
id4namestr = xbmc.getInfoLabel('$LOCALIZE[19115]')
id5namestr = xbmc.getInfoLabel('$LOCALIZE[75006]')
id6namestr = xbmc.getInfoLabel('$LOCALIZE[70012]')
id60namestr = xbmc.getInfoLabel('$LOCALIZE[70012]')
id7namestr = 'Question'
id8namestr = xbmc.getInfoLabel('$LOCALIZE[70013]')
id9namestr = 'CODE RED'
id10namestr = xbmc.getInfoLabel('$LOCALIZE[79031]')
id11namestr = 'MAC1 (LAN)'
id12namestr = 'MAC2 (WLAN)'
''''''
fixip = xbmc.getInfoLabel('Skin.String(fixip)')
trial = xbmc.getInfoLabel('Skin.HasSetting(Trial)')
trial2 = xbmc.getInfoLabel('Skin.HasSetting(Trial2)')
trialdate = xbmc.getInfoLabel('Skin.String(TrialDate)')
trialdate2 = xbmc.getInfoLabel('Skin.String(TrialDate2)')

idtrial = 'htptuser'
#idtrial = 'htptuser27'
idpstr = xbmc.getInfoLabel('$LOCALIZE[79246]')
#idp2str = xbmc.getInfoLabel('$LOCALIZE[79246]')
idp2str = xbmc.getInfoLabel('$LOCALIZE[79247]')
