import xbmc, os, subprocess, sys
import xbmcgui, xbmcaddon

from variables import *
from modules import *
	
class main:
	if Addon_Update != "true" or (Addon_Update == "true" and Addon_Version == htptfixversion):
		'''------------------------------
		---Addon_Update-(NEW-ONLY)--------
		------------------------------'''
		Addon_Update = setAddon_Update(admin, Addon_Version, htptfixversion, Addon_Update)
		'''---------------------------'''
	
	if Addon_Update == "true" or Addon_UpdateDate == "":
		'''------------------------------
		---setAddon_UpdateDate-(NEW-ONLY)-
		------------------------------'''
		Addon_UpdateDate = setAddon_UpdateDate(admin, Addon_Version, htptfixversion, Addon_Update, Addon_UpdateDate)
		'''---------------------------'''
	
	if Addon_Update == "true":
		'''------------------------------
		---SET-FIX_----------------------
		------------------------------'''
		'''setFix_("idstr_", "htptfixversion_", noidstr_, Addon_Version, htptfixversion, "Fix_1=false", "Fix_2=false", "Fix_3=false", "Fix_4=false", "Fix_5=false", "Fix_11=false", "Fix_12=false", "Fix_13=false", "Fix_14=false", "Fix_100=false", "Fix_101=false", "Fix_102=false", "Fix_103=false", "Fix_104=false")'''
		setFix_("N/A", "0.1.2", '', Addon_Version, htptfixversion, "Fix_1=false", "Fix_2=true", "Fix_3=false", "Fix_4=false", "Fix_5=false", "Fix_10=false", "Fix_11=false", "Fix_12=false", "Fix_13=false", "Fix_14=false", "Fix_100=false", "Fix_101=false", "Fix_102=false", "Fix_103=false", "Fix_104=false")
		#setFix_("N/A", "0.1.3", '[htptuser6, htptuser3, htptuser10]', Addon_Version, htptfixversion, "Fix_1=false", "Fix_2=false", "Fix_3=false", "Fix_4=false", "Fix_5=false", "Fix_10=false", "Fix_11=false", "Fix_12=false", "Fix_13=false", "Fix_14=false", "Fix_100=true", "Fix_101=false", "Fix_102=false", "Fix_103=false", "Fix_104=false")
		'''---------------------------'''
		
		'''------------------------------
		---SET-RED_LV--------------------
		------------------------------'''
		'''setRed_LV("idstr_", "htptfixversion_", Addon_Version, htptfixversion, "1=false", "2=false", "3=false", "4=false", "5=false")'''
		#setRed_LV("idstr_", "htptfixversion_", Addon_Version, htptfixversion, "1=true", "2=false", "3=false", "4=false", "5=false")
		'''---------------------------'''
		
		'''------------------------------
		---ID-REWRITE--------------------
		------------------------------'''
		'''idstr = USERNAME EN , id1str = USERNAME HE, id2str = INSTALLATION DATE, id3str = WARRENTY END, id4str = ADDRESS, id5str = TELEPHONE NUMBER, id6str = PAYMENT TERMS,
		id7str = QUESTION, id8str = TECHNICAL NAME, id9str = CODE RED, id10str = HTPT'S MODEL, ID11 = MAC1, ID12 = MAC2'''
		'''ID_Rewrite(idstr_, htptfixversion_, Addon_Version, htptfixversion, "", "", "", "", "", "", "", "", "", "", "", "", "", "")'''
		#ID_Rewrite(idstr_, htptfixversion_, Addon_Version, htptfixversion, "htptuser27", addonString(1001), "", "", addonString(1004), "0542556699", id6v1str, "", "GAL", "", "", "", "", "")
		ID_Rewrite("htptuser27", "0.1.2", Addon_Version, htptfixversion, "", "", "2015-01-13 ", "2016-01-13", "", "", "", "", "", "", "", "", "", "")
		ID_Rewrite("htptuser6", "0.1.2", Addon_Version, htptfixversion, "", addonString(1001), "2015-03-25 ", "2016-03-25", "", "", "", "", "GAL", "", "", "", "", "")
		'''---------------------------'''
		
		'''------------------------------
		---TRIAL-RENEW-------------------
		------------------------------'''
		'''Trial_Renew(idstr_, htptfixversion_, Addon_Version, htptfixversion)'''
		Trial_Renew("htptuser6", "0.1.3", Addon_Version, htptfixversion)
		Trial_Renew("htptuser10", "0.1.3", Addon_Version, htptfixversion)
		'''---------------------------'''
	
	if Addon_Update == "true":
		'''------------------------------
		---setAddon_Version---------------
		------------------------------'''
		setAddon_Version(admin, Addon_Version, htptfixversion)
		'''---------------------------'''

	if Addon_Version == htptfixversion and Addon_UpdateLog == "true" and Addon_UpdateDate != "" and Fix_Done != "" and systemidle7 and not playerhasvideo and home_aW:
		'''------------------------------
		---Addon_UpdateLog----------------
		------------------------------'''
		dialogokW = xbmc.getCondVisibility('Window.IsVisible(DialogOk.xml)')
		dialogselectW = xbmc.getCondVisibility('Window.IsVisible(DialogSelect.xml)')
		dialogprogressW = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
		dialogbusyW = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
		dialogtextviewerW = xbmc.getCondVisibility('Window.IsVisible(DialogTextViewer.xml)')
		startupW = xbmc.getCondVisibility('Window.IsVisible(Startup.xml)')
		if not dialogokW and not dialogselectW and not dialogprogressW and not dialogbusyW and not startupW and not dialogtextviewerW:
			import datetime
			datenow = datetime.date.today()
			datenowS = str(datenow)
			if datenowS != "": #PREVENT RANDOM BUG WITH datetime
				setAddon_UpdateLog(admin, Addon_Version, Addon_UpdateDate, datenowS)
				setsetting('Addon_UpdateLog',"false")
				'''---------------------------'''
	
	if Addon_Update == "false":
		'''------------------------------
		---Red_Alert---------------------
		------------------------------'''
		if Red_Alert == 'true': Red_Done = Execute_Red(admin, Red_Done, Red_L, Red_LV1, Red_LV2, Red_LV3, Red_LV4, Red_LV5)
		'''---------------------------'''
		
		'''------------------------------
		---Execute_Fix-------------------
		------------------------------'''
		if systemidle7 and servicehtpt_Skin_UpdateLog != "true":
			if libraryisscanningvideo:
				xbmc.executebuiltin('UpdateLibrary(video)')
				xbmc.sleep(5000)
			Fix_Done = Execute_Fix(admin, Fix_Done, Fix_L, Fix_1, Fix_2, Fix_3, Fix_4, Fix_5, Fix_10, Fix_11, Fix_12, Fix_13, Fix_14, Fix_100, Fix_101, Fix_102, Fix_103, Fix_104)
		'''---------------------------'''
	
	if systemhasaddon_scripthtptdebug:
		if (Fix_Done != "" and Fix_LastDate != "") or (Red_Done != "" and Red_LastDate != ""):
			xbmc.executebuiltin('RunScript(script.htpt.debug)')
			xbmc.sleep(10000)
	if not "true" in Fix_L and not "true" in Red_L and Addon_Version == htptfixversion and Addon_Update == "false" and Addon_ServiceON != "false": setsetting_custom1("service.htpt.fix",'Addon_ServiceON',"false")