#import xbmc, os, subprocess, sys
#import xbmc, xbmcgui, xbmcaddon
import xbmc, xbmcgui, xbmcaddon
import datetime
import sys

'''------------------------------
---service.htpt.fix--------------
------------------------------'''
getsetting         = xbmcaddon.Addon().getSetting
setsetting         = xbmcaddon.Addon().setSetting
addonName          = xbmcaddon.Addon().getAddonInfo("name")
addonString        = xbmcaddon.Addon().getLocalizedString

fix_no1 = getsetting('fix_no1')
fix_lastdate = getsetting('fix_lastdate')

'''------------------------------
---DEFAULT-----------------------
------------------------------'''
printfirst = addonName + ": !@# "
space = " "
space2 = ": "
space3 = "_"
dialog = xbmcgui.Dialog()
systemplatformwindows = xbmc.getCondVisibility('system.platform.windows')
systemidle3 = xbmc.getCondVisibility('System.IdleTime(3)')
systemidle10 = xbmc.getCondVisibility('System.IdleTime(10)')
systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')

'''------------------------------
---Skin.HasSetting---------------
------------------------------'''
admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
connected = xbmc.getInfoLabel('Skin.HasSetting(Connected)')
connected2 = xbmc.getInfoLabel('Skin.HasSetting(Connected2)')
connected3 = xbmc.getInfoLabel('Skin.HasSetting(Connected3)')
realdebrid = xbmc.getInfoLabel('Skin.HasSetting(RealDebrid)')
sdarottv = xbmc.getInfoLabel('Skin.HasSetting(SdarotTV)')
autoplaysd = xbmc.getInfoLabel('Skin.HasSetting(AutoPlaySD)')
autoplaypause = xbmc.getInfoLabel('Skin.HasSetting(AutoPlay_Pause)')
validation = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION)')

'''------------------------------
---System.-----------------------
------------------------------'''
systeminternetstate = xbmc.getInfoLabel('System.InternetState')
systemuptime = xbmc.getInfoLabel('System.Uptime')
systemcputemperature = xbmc.getInfoLabel('System.CPUTemperature')
screenresolution = xbmc.getInfoLabel('System.ScreenResolution')
dhcpaddress = xbmc.getInfoLabel('Network.DHCPAddress')
systemuptime2 = xbmc.getInfoLabel('System.Uptime') + " / " + xbmc.getInfoLabel('System.TotalUptime') 
freespace2 = xbmc.getInfoLabel('System.TotalSpace') + " / " + xbmc.getInfoLabel('System.FreeSpacePercent')
if xbmc.getCondVisibility('System.HasAddon(service.htpt)'): htptversion = xbmc.getInfoLabel('System.AddonVersion(skin.htpt)') + "+"
elif xbmc.getCondVisibility('!System.HasAddon(service.htpt)'): htptversion = xbmc.getInfoLabel('System.AddonVersion(skin.htpt)') + "-"
buildversion = xbmc.getInfoLabel('System.BuildVersion')
htptdebugversion = xbmc.getInfoLabel('System.AddonVersion(script.htpt.debug)')
htptserviceversion = xbmc.getInfoLabel('system.AddonVersion(service.htpt)')
htpthelpversion = xbmc.getInfoLabel('System.AddonVersion(service.htpt.help)')
htpthomebuttonsversion = xbmc.getInfoLabel('System.AddonVersion(script.htpt.homebuttons)')
htptremoteversion = xbmc.getInfoLabel('System.AddonVersion(script.htpt.remote)')
htptrefreshversion = xbmc.getInfoLabel('System.AddonVersion(script.htpt.refresh)')
htptfixversion = xbmc.getInfoLabel('System.AddonVersion(service.htpt.fix)')


'''------------------------------
---DATES-----------------------
------------------------------'''	
datenow = datetime.date.today()
datenowS = str(datenow)

dateafter = datenow + datetime.timedelta(days=7)
dateafterS = str(dateafter)

daynow = datenow.strftime("%a")
daynowS = str(daynow)
timenow = datetime.datetime.now()
timenowS = timenow.strftime("%H:%M")

'''------------------------------
---CONTAINER---------------------
------------------------------'''
containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
container120numitems = xbmc.getInfoLabel('Container(120).NumItems') #DialogSubtitles
'''------------------------------
---Window.-----------------------
------------------------------'''
homeW = xbmc.getCondVisibility('Window.IsVisible(Home.xml)')
myvideonavW = xbmc.getCondVisibility('Window.IsVisible(MyVideoNav.xml)')
startupW = xbmc.getCondVisibility('Window.IsVisible(Startup.xml)')
videofullscreen = xbmc.getCondVisibility('Window.IsVisible(VideoFullScreen.xml)')
dialogvideoinfo = xbmc.getCondVisibility('Window.IsVisible(DialogVideoInfo.xml)')
dialogselectW = xbmc.getCondVisibility('Window.IsVisible(DialogSelect.xml)')
dialogsubtitlesW = xbmc.getCondVisibility('Window.IsVisible(DialogSubtitles.xml)')
loginscreen = xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)')
custom1170 = xbmc.getCondVisibility('Window.IsVisible(Custom1170.xml)')
custom1191 = xbmc.getInfoLabel('Skin.String(custom1191)')
myprograms = xbmc.getCondVisibility('Window.IsVisible(MyPrograms.xml)')
startup = xbmc.getCondVisibility('Window.IsVisible(Startup.xml)')
startup_a = xbmc.getCondVisibility('Window.IsActive(Startup.xml)')


'''------------------------------
---Network.----------------------
------------------------------'''
networkgatewayaddress = xbmc.getInfoLabel('Network.GatewayAddress')
networkipaddress = xbmc.getInfoLabel('Network.IPAddress')
'''------------------------------
---VIDEO-------------------------
------------------------------'''
playerhasvideo = xbmc.getCondVisibility('Player.HasVideo')
playerpaused = xbmc.getCondVisibility('Player.Paused')
videoplayerhassubtitles = xbmc.getCondVisibility('VideoPlayer.HasSubtitles')
playercache = xbmc.getInfoLabel('Player.CacheLevel')
playertitle = xbmc.getInfoLabel('Player.Title')
'''---------------------------'''	
playertime = xbmc.getInfoLabel("Player.Time(hh)") + xbmc.getInfoLabel("Player.Time(mm)") + xbmc.getInfoLabel("Player.Time(ss)")
playertimeremaining = xbmc.getInfoLabel("Player.TimeRemaining(hh)") + xbmc.getInfoLabel("Player.TimeRemaining(mm)") + xbmc.getInfoLabel("Player.TimeRemaining(ss)")
playerduration = xbmc.getInfoLabel("Player.Duration(hh)") + xbmc.getInfoLabel("Player.Duration(mm)") + xbmc.getInfoLabel("Player.Duration(ss)")

'''---------------------------'''
playlistlength = xbmc.getInfoLabel('Playlist.Length(video)')
playlistlengthN = int(playlistlength)
playlistposition = xbmc.getInfoLabel('Playlist.Position(video)')
playlistpositionN = int(playlistposition)
'''---------------------------'''
videoplayertitle = xbmc.getInfoLabel('VideoPlayer.Title')
videoplayerseason = xbmc.getInfoLabel('VideoPlayer.Season')
videoplayertvshowtitle = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
videoplayeryear = xbmc.getInfoLabel('VideoPlayer.Year')
videoplayertagline = xbmc.getInfoLabel('VideoPlayer.Tagline')
videoplayercountry = xbmc.getInfoLabel('VideoPlayer.Country')
videoplayerseason = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
#videoplayerseason = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
#videoplayerseason = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
#videoplayerseason = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
videoplayercontentMOVIE = xbmc.getCondVisibility('VideoPlayer.Content(movies)')
videoplayercontentTV = xbmc.getCondVisibility('VideoPlayer.Content(tvshows)')
videoplayercontentSEASON = xbmc.getCondVisibility('VideoPlayer.Content(seasons)')
videoplayercontentEPISODE = xbmc.getCondVisibility('VideoPlayer.Content(episodes)')

'''------------------------------
---SKIN STRINGS-------------
------------------------------'''
listitemtvshowtitle = xbmc.getInfoLabel('Skin.String(ListItemTVShowTitle)')
listitemseason = xbmc.getInfoLabel('ListItem.Season')
listitemepisode = xbmc.getInfoLabel('ListItem.Episode')
listitemgenre = xbmc.getInfoLabel('Skin.String(ListItemGenre)')
listitemduration = xbmc.getInfoLabel('Skin.String(ListItemDuration)')
listitemrating = xbmc.getInfoLabel('Skin.String(ListItemRating)')
listitemyear = xbmc.getInfoLabel('Skin.String(ListItemYear)')

'''------------------------------
---LISTITEM-------------
------------------------------'''
listitempath = xbmc.getInfoLabel('ListItem.Path')



'''------------------------------
---CUSTOM-------------
------------------------------'''

dialogselectsources = xbmc.getInfoLabel('Skin.String(DialogSelectSources)')
dialogselectsources2 = xbmc.getInfoLabel('Skin.String(DialogSelectSources2)')
dialogselectsources3 = xbmc.getInfoLabel('Skin.String(DialogSelectSources3)')
dialogselectsources5 = xbmc.getInfoLabel('Skin.String(DialogSelectSources5)')

dialogsubtitles2 = xbmc.getInfoLabel('Skin.String(DialogSubtitles2)')
dialogsubtitlesna1 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA1)')
dialogsubtitlesna2 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA2)')
dialogsubtitlesna3 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA3)')
dialogsubtitlesna4 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA4)')
dialogsubtitlesna5 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA5)')
dialogsubtitlesna6 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA6)')
dialogsubtitlesna7 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA7)')
dialogsubtitlesna8 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA8)')
dialogsubtitlesna9 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA9)')
dialogsubtitlesna10 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA10)')


'''------------------------------
---MIXED-------------------------
------------------------------'''
mac = xbmc.getInfoLabel('Network.MacAddress') + " ( " + xbmc.getInfoLabel('Skin.String(MAC1)') + " / " + xbmc.getInfoLabel('Skin.String(MAC2)') + " )"
istv = (xbmc.getInfoLabel('ListItem.TVShowTitle') != "" and xbmc.getInfoLabel('ListItem.Season') != "" and xbmc.getInfoLabel('ListItem.Episode') != "") or ("videodb://tvshows" in containerfolderpath or "library://video/tvshows" in containerfolderpath)
istvS = str(istv)
ismovie = (xbmc.getInfoLabel('ListItem.Year') != "" or xbmc.getInfoLabel('ListItem.Country') != "" or xbmc.getInfoLabel('ListItem.Tagline') != "") and not istv
ismovieS = str(ismovie)
istv4 = " S" in dialogselectsources3 and " E" in dialogselectsources3
istv4S = str(istv4)
ismovie4 = " (" in dialogselectsources3 and ")" in dialogselectsources3 and not istv4
ismovie4S = str(ismovie4)
istvmoviep = (videoplayertitle in dialogselectsources3 or videoplayertitle in dialogselectsources5)
isgenesis = "videodb://tvshows" in containerfolderpath or "library://video/tvshows" in containerfolderpath or "plugin://plugin.video.genesis/" in containerfolderpath
'''------------------------------
---CONTROL-----------------------
------------------------------'''
cancelbutton = xbmc.getCondVisibility('Control.HasFocus(10)') and xbmc.getCondVisibility('Window.IsActive(DialogProgress.xml)')
autoplaypausebutton = (xbmc.getCondVisibility('Window.IsVisible(Home.xml)') and xbmc.getCondVisibility('Control.HasFocus(9093)')) or (xbmc.getCondVisibility('Window.IsVisible(MyVideoNav.xml)') and xbmc.getCondVisibility('Control.HasFocus(111)'))
debugbutton = xbmc.getCondVisibility('Container(50).HasFocus(5)') or (xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(102)'))
controlisvisible311 = xbmc.getCondVisibility('Control.IsVisible(311)') or xbmc.getCondVisibility('Control.HasFocus(340)')
controlisvisible311S = str(controlisvisible311)
controlisvisible312 = xbmc.getCondVisibility('Control.IsVisible(312)') or xbmc.getCondVisibility('Control.HasFocus(341)')
controlisvisible312S = str(controlisvisible312)
controlgetlabel100 = xbmc.getInfoLabel('Control.GetLabel(100)') #DialogSubtitles Service Name

	
'''------------------------------
---$LOCALIZE--------------------
------------------------------'''
truestr = xbmc.getInfoLabel('$LOCALIZE[20122]')
cancelstr = xbmc.getInfoLabel('$LOCALIZE[222]')
trialstr = xbmc.getInfoLabel('$LOCALIZE[70001]')
trial2str = xbmc.getInfoLabel('$LOCALIZE[70002]')
verrorstr = xbmc.getInfoLabel('$VAR[VERROR]')
id6v1str = xbmc.getInfoLabel('$LOCALIZE[70014]')
id6v2str = xbmc.getInfoLabel('$LOCALIZE[70015]')
id6v3str = xbmc.getInfoLabel('$LOCALIZE[70016]')
'''------------------------------
---ID----------------------------
------------------------------'''
'''idstr = USERNAME EN , id1str = USERNAME HE, id2str = INSTALLATION DATE, id3str = WARRENTY END, id4str = ADDRESS, id5str = TELEPHONE NUMBER, id6str = PAYMENT TERMS, id7str = QUESTION, id8str = TECHNICAL NAME, id9str = CODE RED, id10str = HTPT'S MODEL, ID11 = MAC1, ID12 = MAC2'''
idstr = xbmc.getInfoLabel('Skin.String(ID)')
id1str = xbmc.getInfoLabel('Skin.String(ID1)')
id2str = xbmc.getInfoLabel('Skin.String(ID2)')
id3str = xbmc.getInfoLabel('Skin.String(ID3)')
id4str = xbmc.getInfoLabel('Skin.String(ID4)')
id5str = xbmc.getInfoLabel('Skin.String(ID5)')
id6str = xbmc.getInfoLabel('Skin.String(ID6)')
id7str = xbmc.getInfoLabel('Skin.String(ID7)')
id8str = xbmc.getInfoLabel('Skin.String(ID8)')
id9str = xbmc.getInfoLabel('Skin.String(ID9)')
id10str = xbmc.getInfoLabel('Skin.String(ID10)')
id11str = xbmc.getInfoLabel('Skin.String(ID11)')
id12str = xbmc.getInfoLabel('Skin.String(ID12)')
id60str = xbmc.getInfoLabel('Skin.String(ID60)')
''''''
idnamestr = xbmc.getInfoLabel('$LOCALIZE[1014]')
id2namestr = xbmc.getInfoLabel('$LOCALIZE[70010]')
id3namestr = xbmc.getInfoLabel('$LOCALIZE[70011]')
id4namestr = xbmc.getInfoLabel('$LOCALIZE[19115]')
id5namestr = xbmc.getInfoLabel('$LOCALIZE[75006]')
id6namestr = xbmc.getInfoLabel('$LOCALIZE[70012]')
id60namestr = xbmc.getInfoLabel('$LOCALIZE[70012]')
id7namestr = 'Question'
id8namestr = xbmc.getInfoLabel('$LOCALIZE[70013]')
id9namestr = 'CODE RED'
id10namestr = xbmc.getInfoLabel('$LOCALIZE[79031]')
id11namestr = 'MAC1 (LAN)'
id12namestr = 'MAC2 (WLAN)'
''''''
fixip = xbmc.getInfoLabel('Skin.String(fixip)')
trial = xbmc.getInfoLabel('Skin.HasSetting(Trial)')
trial2 = xbmc.getInfoLabel('Skin.HasSetting(Trial2)')
trialdate = xbmc.getInfoLabel('Skin.String(TrialDate)')
trialdate2 = xbmc.getInfoLabel('Skin.String(TrialDate2)')

idtrial = 'htptuser'
#idtrial = 'htptuser27'
idpstr = xbmc.getInfoLabel('$LOCALIZE[79246]')
#idp2str = xbmc.getInfoLabel('$LOCALIZE[79246]')
idp2str = xbmc.getInfoLabel('$LOCALIZE[79247]')
