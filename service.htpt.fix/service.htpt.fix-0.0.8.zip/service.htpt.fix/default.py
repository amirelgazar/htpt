import xbmc, xbmcgui
import os, sys
import subprocess
import xbmcaddon

'''OTHERS'''
xbmc.sleep(1000)
import datetime
from variables import *
from modules import *

		
class startup_once:
	xbmc.sleep(1000)
	newfixtrigger("2015-02-15",'fix_no1',"","")
	'''---------------------------'''
class startup_repeat:
	validation = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION)')
	while validation and not xbmc.abortRequested:
		xbmc.sleep(1000)
		#ID_Rewrite('2015-02-15', 'htptuser5',"htptuser27", addonString(1001).encode('utf-8'), "", "", addonString(1004).encode('utf-8'), "0542556699", id6v1str, "", "GAL", "", "", "", "", "")
		#ID_Rewrite('2015-02-16', 'htptuser5',"htptuser27", addonString(1001).encode('utf-8'), "", "", addonString(1004).encode('utf-8'), "0542556699", id6v1str, "", "GAL", "", "", "", "", "")
		xbmc.sleep(7000)
		#loginscreen = xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)')
		#loginscreen_p = xbmc.getCondVisibility('Window.Previous(LoginScreen.xml)')
		validation = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION)')
		'''---------------------------'''
		Trial_Renew('2015-03-03', 'htptuser27')
		#Trial_Renew('2015-02-23', 'htptuser6')
		xbmc.sleep(1000)
		'''---------------------------'''
class home_once:
	home = xbmc.getCondVisibility('Window.IsVisible(0)')
	while not home and not xbmc.abortRequested:
		xbmc.sleep(1000)
		home = xbmc.getCondVisibility('Window.IsVisible(0)')
		xbmc.sleep(1000)
		'''---------------------------'''
	fix_no1 = getsetting('fix_no1')
	if fix_no1 == 'true':
		'''------------------------------
		---fix_no1-----------------------
		------------------------------'''
		bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.video.israelive',"plugin.video.israelive")
		dialogok(addonString(40).encode('utf-8'),xbmc.getInfoLabel('[COLOR=Yellow]$LOCALIZE[19023][/COLOR]'), "", addonString(42).encode('utf-8'))
		setsetting('fix_no1',"false")
		'''---------------------------'''

sys.exit()


class repeat:
	'''------------------------------
	---REPEAT------------------------
	------------------------------'''
	count = 0
	while 1 and not xbmc.abortRequested:
		xbmc.sleep(7000)
		admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
		if count < 10: count += 1
		elif count >= 10: count = 1
		if admin:
			countS = str(count)
			xbmc.executebuiltin('Skin.SetString(TimerFix,'+ countS +')')
		'''actions'''
		#if count == 7:
	if xbmc.abortRequested:
		'''------------------------------
		---ABORT-------------------------
		------------------------------'''
		print printfirst + "Error 1170: AbortRequested!"
		sys.exit()
		
		
#repeat()