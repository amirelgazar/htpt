import xbmc, xbmcgui
import os, sys, datetime
import subprocess
import xbmcaddon

getsetting         = xbmcaddon.Addon().getSetting
setsetting         = xbmcaddon.Addon().setSetting
addonName           = xbmcaddon.Addon().getAddonInfo("name")
addonString            = xbmcaddon.Addon().getLocalizedString

'''OTHERS'''
xbmc.sleep(5000)
printfirst = addonName + ": !@# "
space = " "
space2 = ": "
space3 = "_"
admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
systemplatformwindows = xbmc.getCondVisibility('system.platform.windows')
datenow = datetime.date.today()
datenowS = str(datenow)
''''''

'''ADDON SETTINGS'''
datenow = datetime.date.today()
datenowS = str(datenow)
'''fix_no1 = plugin.video.israelive, '''
fix_no1 = getsetting('fix_no1')
fix_lastdate = getsetting('fix_lastdate')


def bash(bashCommand,bashname):
	'''run BASH commands'''
	if not systemplatformwindows:
		xbmc.sleep(40)
		process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
		output = process.communicate()[0]
		return output

def dialogkeyboard(input, heading, option, custom, addonsetting, addonsetting2):
	''''''
	if '$LOCALIZE' in heading: heading = xbmc.getInfoLabel(heading)
	dialog = xbmcgui.Dialog()
	keyboard = xbmc.Keyboard(input,heading,option)
	keyboard.doModal()
	returned = 'skip'
	if (keyboard.isConfirmed()):
		input2 = keyboard.getText()
		if custom == '1' and input2 != "": returned = 'ok'
		if custom == '2' and input2 == input: returned = 'ok'
		if custom == '3':
			if input2 != input and input2 != "" and option == 0: xbmc.executebuiltin('Notification('+ heading +': '+ input2 +',,4000)')
			if input2 != "": returned = 'ok'
			
		if option == 0: print printfirst + heading + space2 + input2 + " ( " + returned + " )"
		elif option != 0: print printfirst + heading + space2 + "*******" + " ( " + returned + " )"
	if returned == 'ok':
		returned == input2
		if addonsetting2 == "0": setsetting(addonsetting, input2)
		elif addonsetting2 == 'genesis':
			setsetting_genesis          = xbmcaddon.Addon('plugin.video.genesis').setSetting
			setsetting_genesis(addonsetting, input2)
		elif addonsetting2 == 'sdarottv':
			setsetting_sdarottv          = xbmcaddon.Addon('plugin.video.sdarot.tv').setSetting
			setsetting_sdarottv(addonsetting, input2)
	return returned
	
def dialogok(heading,line1,line2,line3):
	dialog = xbmcgui.Dialog()
	if '$LOCALIZE' in heading and not "addonString" in heading: heading = xbmc.getInfoLabel(heading)
	if '$LOCALIZE' in line1 and not "addonString" in line1: line1 = xbmc.getInfoLabel(line1)
	if '$LOCALIZE' in line2 and not "addonString" in line2: line2 = xbmc.getInfoLabel(line2)
	if '$LOCALIZE' in line3 and not "addonString" in line3: line3 = xbmc.getInfoLabel(line3)
	heading = str(heading)
	line1 = str(line1)
	line2 = str(line2)
	line3 = str(line3)
	dialog.ok(heading,line1,line2,line3)
	print printfirst + heading + space2 + line1 + space2 + line2 + space2 + line3


def Trial_Renew(issuedate, htptuser):
	trial = xbmc.getInfoLabel('Skin.HasSetting(Trial)')
	trial2 = xbmc.getInfoLabel('Skin.HasSetting(Trial2)')
	trialdate = xbmc.getInfoLabel('Skin.String(TrialDate)')
	trialdate2 = xbmc.getInfoLabel('Skin.String(TrialDate2)')
	trialstr = xbmc.getInfoLabel('$LOCALIZE[70001]')
	trial2str = xbmc.getInfoLabel('$LOCALIZE[70002]')
	verrorstr = xbmc.getInfoLabel('$VAR[VERROR]')
	idstr = xbmc.getInfoLabel('Skin.String(ID)')
	id3str = xbmc.getInfoLabel('Skin.String(ID3)')
	id9str = xbmc.getInfoLabel('Skin.String(ID9)')
	dateafter = datenow + datetime.timedelta(days=7)
	dateafterS = str(dateafter)
	if admin: print printfirst + "Trial_Renew: " + "datenowS: " + datenowS + " issuedate: " + issuedate + " htptuser: " + htptuser + space + "(0)"
	if trial2 and not trial and id9str == 'TrailEnd' and id3str == 'TrailEnd' and verrorstr != 'NONE':
		print printfirst + "Trial_Renew: " + htptuser + space + "(1)"
		if trialdate != "" and trialdate2 != "":
			print printfirst + "Trial_Renew: " + trialdate + " - " + trialdate2 + space + "(2)"
			if datenowS == issuedate and htptuser == idstr:
				print printfirst + "Trial_Renew: " + issuedate + space + "(3)"
				'''execute'''
				xbmc.executebuiltin('Skin.SetString(TrialDate,'+ issuedate +')')
				xbmc.executebuiltin('Skin.SetString(TrialDate2,'+ dateafterS +')')
				xbmc.executebuiltin('Skin.SetString(ID3,'+ trial2str +')')
				xbmc.executebuiltin('Skin.SetString(ID9,'+ trialstr +')')
				dialogok(addonString(10).encode('utf-8'),addonString(11).encode('utf-8') + space2 + trialdate + " - " + trialdate2, addonString(12).encode('utf-8') + space2 + issuedate + " - " + dateafterS, '$LOCALIZE[79084]')

def newfixtrigger(fixdate,fix1, fix2, fix3):
	'''APPLY FIXS'''
	print printfirst + "newfixtrigger (1) " + fixdate + " = " + datenowS + " ( " + fix_lastdate + " ) "
	if fixdate == datenowS and fix_lastdate != fixdate:
		'''CHOOSEN FIXS TO APPLY'''
		if fix1 != "": setsetting(fix1,"true")
		if fix2 != "": setsetting(fix2,"true")
		if fix3 != "": setsetting(fix3,"true")
		setsetting('fix_lastdate',fixdate)
		fixreturn = fix1 + space3 + fix2 + space3 + fix3 + space3
		print printfirst + "newfixtrigger (2) " + fixreturn
class startup_once:
	newfixtrigger("2015-01-22",'fix_no1',"","")
class startup_repeat:
	validation = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION)')
	while validation and not xbmc.abortRequested:
		xbmc.sleep(7000)
		#loginscreen = xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)')
		#loginscreen_p = xbmc.getCondVisibility('Window.Previous(LoginScreen.xml)')
		validation = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION)')
		Trial_Renew('2015-01-16', 'finalmakerr')
		xbmc.sleep(1000)

class home_once:
	home = xbmc.getCondVisibility('Window.IsVisible(0)')
	while not home and not xbmc.abortRequested:
		xbmc.sleep(1000)
		home = xbmc.getCondVisibility('Window.IsVisible(0)')
		xbmc.sleep(1000)
		
	if fix_no1 == 'true':
		bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.video.israelive',"plugin.video.israelive")
		dialogok(addonString(40).encode('utf-8'),xbmc.getInfoLabel('[COLOR=Yellow]$LOCALIZE[19023][/COLOR]'), "", addonString(42).encode('utf-8'))
		setsetting('fix_no1',"false")
		
class repeat:
	count = 0
	while 1 and not xbmc.abortRequested:
		xbmc.sleep(7000)
		admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
		if count < 10: count += 1
		elif count >= 10: count = 1
		if admin:
			countS = str(count)
			xbmc.executebuiltin('Skin.SetString(TimerFix,'+ countS +')')
		'''actions'''
		#if count == 7:
	if xbmc.abortRequested:
		print printfirst + "Error 1170: AbortRequested!"
		sys.exit()
		
		
#repeat()