import xbmc, xbmcgui
import os, sys
import subprocess
import xbmcaddon

'''OTHERS'''
xbmc.sleep(4000)
from variables import *
from modules import *

class resetsettings:
	if Addon_Version == "" and Addon_UpdateDate == "":
		'''------------------------------
		---DELETE-ADDON-USERDATA---------
		------------------------------'''
		if not systemplatformwindows: bash('rm -rf /storage/.kodi/userdata/addon_data/service.htpt.fix/settings.xml',"service.htpt.fix - userdata")
		print printfirst + "resetsettings" + space2 + "settings.xml REMOVED!" 
		'''---------------------------'''
	else:
		addonsettings2("service.htpt.fix",'Red_LV1',"false",'Red_LV2',"false",'Red_LV3',"false",'Red_LV4',"false",'Red_LV5',"false")
		addonsettings2("service.htpt.fix",'Red_Alert',"false",'',"",'Addon_ServiceON',"true",'Addon_UpdateLog',"true",'',"")
		'''---------------------------'''
	xbmc.sleep(1000)
	if id3str == "Trail": setSkinSetting("0",'ID3',trialstr)
	if id3str == "TrailRenew": setSkinSetting("0",'ID3',trial2str)
	if id3str == "TrailEnd": setSkinSetting("0",'ID3',trial3str)
	if id9str == "Trail": setSkinSetting("0",'ID9',trialstr)
	if id9str == "TrailRenew": setSkinSetting("0",'ID9',trial2str)
	if id9str == "TrailEnd": setSkinSetting("0",'ID9',trial3str)
	'''---------------------------'''
	
class startup:
	Trial(admin)
	'''---------------------------'''
class clean:
	Clean_Library(admin, "1")
	Clean_Library(admin, "2")
	Clean_Library(admin, "3")
	if not systemplatformwindows: bash('rm -rf /storage/.kodi/addons/#',"addons/#")
	if not systemplatformwindows: bash('rm -rf /storage/.kodi/userdata/#',"addon_data/#")
	'''---------------------------'''
	
class hideaddons:
	'''liveshows''' 
	if idstr != "finalmakerr": setSkinSetting("1",'YouTube.20',"true")
	else: setSkinSetting("1",'YouTube.20',"false")
	'''---------------------------'''
	'''plugin.video.youtube.channels''' 
	if idstr != "finalmakerr": setSkinSetting("1",'YouTube.24',"true")
	else: setSkinSetting("1",'YouTube.24',"false")
	'''---------------------------'''
	'''plugin.video.improveverywhere''' 
	if idstr != "finalmakerr": setSkinSetting("1",'YouTube.27',"true")
	else: setSkinSetting("1",'YouTube.27',"false")
	'''---------------------------'''
	'''plugin.video.youtube.3d''' 
	if idstr != "finalmakerr": setSkinSetting("1",'YouTube.25',"true")
	else: setSkinSetting("1",'YouTube.25',"false")
	'''---------------------------'''
	'''plugin.video.discovery_com''' 
	if idstr != "finalmakerr": setSkinSetting("1",'YouTube.29',"true")
	else: setSkinSetting("1",'YouTube.29',"false")
	'''---------------------------'''
	'''plugin.video.the666sicco''' 
	if idstr != "finalmakerr": setSkinSetting("1",'GoPro.25',"true")
	else: setSkinSetting("1",'GoPro.25',"false")
	'''---------------------------'''
	'''plugin.video.thaakillah''' 
	if idstr != "finalmakerr": setSkinSetting("1",'GoPro.29',"true")
	else: setSkinSetting("1",'GoPro.29',"false")
	'''---------------------------'''
class main:
	count = 0
	while 1 and not xbmc.abortRequested:
		'''------------------------------
		---VARIABLES---------------------
		------------------------------'''
		#if admin: print printfirst + "DEBUGGING! (0)" + space + "Fix_1/2/3" + space2 + Fix_1 + " / " + Fix_2 + " / " + Fix_3 + space + "Addon_Version" + space2 + Addon_Version + space + "Addon_UpdateLog" + space2 + Addon_UpdateLog
		systeminternetstate = xbmc.getInfoLabel('System.InternetState')
		networkipaddress = xbmc.getInfoLabel('Network.IPAddress')
		connected = xbmc.getInfoLabel('Skin.HasSetting(Connected)')
		hasinternet = systeminternetstate != "" and networkipaddress != "" and not "169.254." in networkipaddress and (connected or systemplatformwindows)
		'''---------------------------'''
		admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
		admin2 = xbmc.getInfoLabel('Skin.HasSetting(Admin2)')
		playerhasvideo = xbmc.getCondVisibility('Player.HasVideo')
		systemidle7 = xbmc.getCondVisibility('System.IdleTime(7)')
		systemidle120 = xbmc.getCondVisibility('System.IdleTime(120)')
		validation = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION)')
		validation2 = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION2)')
		home_aW = xbmc.getCondVisibility('Window.IsActive(0)')
		'''---------------------------'''
		dialogbusyW = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
		dialogokW = xbmc.getCondVisibility('Window.IsVisible(DialogOk.xml)')
		dialogprogressW = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
		dialogselectW = xbmc.getCondVisibility('Window.IsVisible(DialogSelect.xml)')
		dialogyesnoW = xbmc.getCondVisibility('Window.IsVisible(DialogYesNo.xml)')
		dialogtextviewerW = xbmc.getCondVisibility('Window.IsVisible(DialogTextViewer.xml)')
		startupW = xbmc.getCondVisibility('Window.IsVisible(Startup.xml)')
		'''---------------------------'''
		if (not playerhasvideo and systemidle7 and home_aW and not validation) or ((validation or validation2) and not homeW):
			if (validation or validation2) and not homeW: xbmc.executebuiltin('RunScript(service.htpt.fix)')
			elif not dialogprogressW and not dialogokW and not dialogbusyW and not dialogtextviewerW and not dialogyesnoW and not dialogselectW and not startupW:
				'''------------------------------
				---COUNT-------------------------
				------------------------------'''
				count += 1
				xbmc.executebuiltin('RunScript(service.htpt.fix)')
				countS = str(count)
				if admin: print printfirst + space + "count" + space2 + countS
				'''---------------------------'''
				
			'''---------------------------'''
			if admin and not systemidle120: xbmc.sleep(5000)
			else: xbmc.sleep(10000)
			'''---------------------------'''
				
		'''------------------------------
		---SLEEP-------------------------
		------------------------------'''
		if admin and not systemidle120: xbmc.sleep(5000)
		elif playerhasvideo: xbmc.sleep(120000)
		elif not home_aW: xbmc.sleep(20000)
		else: xbmc.sleep(10000)
		'''---------------------------'''
		
		if count >= 10:
			print printfirst + "Clean Exit"
			if admin: notification(printfirst,"Clean Exit","",2000)
			setsetting_custom1("service.htpt.fix",'Addon_ServiceON',"false")
			sys.exit()
			'''---------------------------'''
			
	if xbmc.abortRequested:
		print printfirst + "Error 1170: AbortRequested!"
		sys.exit()
		'''---------------------------'''
