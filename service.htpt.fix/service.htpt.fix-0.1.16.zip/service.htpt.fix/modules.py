import xbmc, xbmcgui, xbmcaddon
import os, subprocess, sys

from variables import *
from shared_modules import *
#from shared_modules2 import *
'''------------------------------
---service.htpt.fix--------------
------------------------------'''

def Trial(admin):
	'''------------------------------
	---TRIAL-------------------------
	------------------------------'''
	printpoint = ""
	trialdateD = stringtodate(trialdate,'%Y-%m-%d')
	trialdate2D = stringtodate(trialdate2,'%Y-%m-%d')
	datenowD = stringtodate(datenowS,'%Y-%m-%d')
	dateafterD = stringtodate(dateafterS,'%Y-%m-%d')
	'''---------------------------'''
	if trialdate and trial:
		'''------------------------------
		---SET-NEW-TRIAL-----------------
		------------------------------'''
		if verrorstr == 'NONE':
			if trialdate2 == str70000 and trialdate == xbmc.getInfoLabel('System.Date(DD-MM-YY)') and not trial2:
				printpoint = printpoint + "1"
				returned = dialogyesno(addonString(21), addonString(22))
				if returned == "ok":
					'''------------------------------
					---ACTIVATE-TRIAL-1--------------
					------------------------------'''
					setsetting('Purchase_Date', "")
					setSkinSetting("0", 'TrialDate', datenowS)
					setSkinSetting("0", 'TrialDate2', dateafterS)
					setSkinSetting("0", 'ID9', trialstr)
					setSkinSetting("1", 'Trial2', "true")
					dialogok('[COLOR=Yellow]' + addonString(23) + '[/COLOR]', addonString(24) % (datenowS, dateafterS),"","")
					'''---------------------------'''
				else: notification_common("9")
				'''---------------------------'''
				
			elif trialdate2 != str70000 or trial2:
				printpoint = printpoint + "2"
				returned = dialogyesno(addonString(25), addonString(26))
				if returned == "ok":
					'''------------------------------
					---ACTIVATE-TRIAL-2--------------
					------------------------------'''
					setSkinSetting("0", 'ID3', trialstr)
					setSkinSetting("0", 'ID7', trialstr)
					setSkinSetting("0", 'ID9', "")
					dialogok('[COLOR=Yellow]' + addonString(27) + '[/COLOR]', addonString(28), '$LOCALIZE[79081]', "")
					'''---------------------------'''
			else: printpoint = printpoint + "3"
			'''---------------------------'''
		else:
			if admin: notification("verrorstr != NONE","","",2000)
			printpoint = printpoint + "4"
			'''---------------------------'''

	if trial2 and trialdate and trialdate2:
		'''------------------------------
		---TRIAL-CHECK-------------------
		------------------------------'''
		printpoint = printpoint + "5"
		
		if trialdate2D < datenowD or trialdate2D < trialdateD or dateafterD < trialdate2D or datenowD < trialdateD:
			'''------------------------------
			---TRIAL-ENDED-------------------
			------------------------------'''
			printpoint = printpoint + "6"
			dialogok(addonString(29), addonString(24) % (trialdate, trialdate2) + '[CR]','[COLOR=Yellow]' + addonString(30) + '[/COLOR]',str79081 + space4 + str69999)
			setSkinSetting("0", 'ID3', trial3str)
			setSkinSetting("0", 'ID9', trial3str)
			'''---------------------------'''
			
		if dateafterD < trialdate2D or datenowD < trialdateD:
			'''------------------------------
			---TRIAL-USER-ERROR--------------
			------------------------------'''
			printpoint = printpoint + "!"
			setSkinSetting("0", 'ID5', "000")
			setSkinSetting("0", 'ID7', "000")
			xbmc.sleep(1000)
			notification_common("6")
			setSkinSetting("1", 'Trial2', "false")
			'''---------------------------'''
			
	'''------------------------------
	---RESET-SETTINGS----------------
	------------------------------'''
	if not trial and not trial2:
		setSkinSetting("0", 'TrialDate', "")
		setSkinSetting("0", 'TrialDate2', "")
		'''---------------------------'''
	setSkinSetting("1", 'Trial', "false")
	if verrorstr != 'NONE': setSkinSetting("0", 'ID9', trialstr)
	'''---------------------------'''
	id9str = xbmc.getInfoLabel('Skin.String(ID9)')
	id3str = xbmc.getInfoLabel('Skin.String(ID3)')
	id7str = xbmc.getInfoLabel('Skin.String(ID7)')
	if id9str == str79041 and id3str != trialstr and id7str != trialstr: setSkinSetting("1", 'Trial2', "false")
	'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: moreinfo = "id9str" + space2 + id9str + space + "id3str" + space2 + id3str + space + "id7str" + space2 + id7str
	else: moreinfo = ""
	print printfirst + "Trial_LV" + printpoint + space + moreinfo
	'''---------------------------'''

def Trial_Renew(idstr_, htptfixversion_, Addon_Version, htptfixversion):
	'''------------------------------
	---***---------------------------
	------------------------------'''
	from variables import datenowS, dateafterS, trialstr, trial2str
	printpoint = ""
	if id9str == trial3str and id3str == trial3str and verrorstr != 'NONE':
		printpoint = printpoint + "1"
		if trialdate != "" and trialdate2 != "":
			printpoint = printpoint + "2"
			if (Addon_Version != htptfixversion and htptfixversion == htptfixversion_) and idstr_ == idstr:
				printpoint = printpoint + "3"
				'''execute'''
				setSkinSetting("1", 'Trial', "false")
				setSkinSetting("1", 'Trial2', "true")
				setSkinSetting("0",'TrialDate',datenowS)
				setSkinSetting("0",'TrialDate2',dateafterS)
				setSkinSetting("0",'ID3',trial2str)
				setSkinSetting("0",'ID9',trialstr)
				dialogyesnoW = xbmc.getCondVisibility('Window.IsVisible(DialogYesNo.xml)')
				if dialogyesnoW: xbmc.executebuiltin('Action(close)')
				dialogok('[COLOR=Yellow]' + addonString(10) + '[/COLOR]',addonString(11) + space2 + trialdate + " - " + trialdate2, addonString(12) + space2 + datenowS + " - " + dateafterS, '[CR]' + '[COLOR=Yellow]' + '$LOCALIZE[79084]' + '[/COLOR]')
				'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "Trial_Renew_LV" + printpoint + space + "idstr_" + space2 + idstr_ + space + "idstr" + space2 + idstr
	if not "1" in printpoint: print printfirst + "Trial_Renew_LV" + printpoint + space + "trial/2" + space2 + trial + " / " + trial2 + space + "id9str" + space2 + id9str + space + "id3str" + space2 + id3str + space + "verrorstr" + space2 + verrorstr
	if not "3" in printpoint: print printfirst + "Trial_Renew_LV" + printpoint + space + "htptfixversion_" + space2 + htptfixversion_ + space + "htptfixversion" + space2 + htptfixversion + space + "Addon_Version" + space2 + Addon_Version + space + "trialdate/2" + space + trialdate + " / " + trialdate2 + space
	if "3" in printpoint: print printfirst + "Trial_Renew_LV" + printpoint + space2 + "datenowS" + space2 + datenowS + space + "dateafterS" + space2 + dateafterS
	'''---------------------------'''

def Activate_Account(idstr_, htptfixversion_, Addon_Version, htptfixversion, id2set):
	'''------------------------------
	---***---------------------------
	------------------------------'''
	from variables import datenowS
	import datetime as dt #Can cause a bug with stringtodate!
	printpoint = ""
	if (Addon_Version != htptfixversion and htptfixversion == htptfixversion_) and idstr_ == idstr:
		printpoint = printpoint + "1"
		datenowD = stringtodate(datenowS,'%Y-%m-%d')
		try:
			id2strD = stringtodate(id2str,'%Y-%m-%d')
			if not id2strD <= datenowD: id2strD = ""
		except: id2strD = ""

		#if "day," in number2S: number2S = number2S.replace(" day, 0:00:00","",1)
		#elif "days," in number2S: number2S = number2S.replace(" days, 0:00:00","",1)
		'''---------------------------'''
		'''execute'''
		setSkinSetting("0",'TrialDate',"")
		setSkinSetting("0",'TrialDate2',"")
		setSkinSetting("1",'Trial',"false")
		setSkinSetting("1",'Trial2',"false")

		if id2set != "":
			printpoint = printpoint + "4"
			dateafter364 = id2set + dt.timedelta(days=364)
			dateafter364S = str(dateafter364)
			dateafter364S = dateafter364S.replace(" 00:00:00","",1)
			setSkinSetting("0",'ID2',id2set)
			setSkinSetting("0",'ID3',dateafter364S)
			'''---------------------------'''
		elif id2strD != "":
			printpoint = printpoint + "5"
			dateafter364 = id2strD + dt.timedelta(days=364)
			dateafter364S = str(dateafter364)
			dateafter364S = dateafter364S.replace(" 00:00:00","",1)
			setSkinSetting("0",'ID3',dateafter364S)
			'''---------------------------'''
		else:
			printpoint = printpoint + "6"
			datenowM7 = datenow - dt.timedelta(days=7)
			datenowM7S = str(datenowM7)
			datenowM14 = datenow - dt.timedelta(days=14)
			datenowM14S = str(datenowM14)
			dateafter364 = datenow + dt.timedelta(days=364)
			dateafter357 = datenow + dt.timedelta(days=357)
			dateafter350 = datenow + dt.timedelta(days=350)
			dateafter364S = str(dateafter364)
			dateafter364S = dateafter364S.replace(" 00:00:00","",1)
			dateafter357S = str(dateafter357)
			dateafter357S = dateafter357S.replace(" 00:00:00","",1)
			dateafter350S = str(dateafter350)
			dateafter350S = dateafter350S.replace(" 00:00:00","",1)
			'''---------------------------'''
			if id3str == "":
				setSkinSetting("0",'ID2',datenowS)
				setSkinSetting("0",'ID3',dateafter364S)
				'''---------------------------'''
			elif id3str == trialstr:
				setSkinSetting("0",'ID2',datenowM7S)
				setSkinSetting("0",'ID3',dateafter357S)
				'''---------------------------'''
			elif id3str == trial2str:
				setSkinSetting("0",'ID2',datenowM14S)
				setSkinSetting("0",'ID3',dateafter350S)
				'''---------------------------'''
			elif id3str == trial3str:
				setSkinSetting("0",'ID2',datenowM14S)
				setSkinSetting("0",'ID3',dateafter350S)
				'''---------------------------'''
			else:
				setSkinSetting("0",'ID2',datenowS + "?")
				setSkinSetting("0",'ID3',dateafter364S + "?")
				'''---------------------------'''
		if id4str == "": setSkinSetting("0",'ID4',"?")
		if id5str == "" or id5str == "000": setSkinSetting("0",'ID5',"?")
		if id6str == "": setSkinSetting("0",'ID6',"?")
		if id7str == "000" or id7str == "Trial": setSkinSetting("0",'ID7',"")
		if id8str == "": setSkinSetting("0",'ID8',"?")
		setSkinSetting("0",'ID9',str79041)
		#setsetting_custom1('service.htpt.fix','Purchase_Date',datenowS)
		setsetting('Purchase_Date', datenowS)
		dialogyesnoW = xbmc.getCondVisibility('Window.IsVisible(DialogYesNo.xml)')
		if dialogyesnoW: xbmc.executebuiltin('Action(close)')
		dialogok('[COLOR=Yellow]' + addonString(13).encode('utf-8') % (id1str.decode('utf-8').encode('utf-8')) + '[/COLOR]',addonString(14).encode('utf-8') + '[CR][CR]', '$LOCALIZE[79084]',"")
		'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "Activate_Account_LV" + printpoint + space + "idstr_" + space2 + idstr_ + space + "idstr" + space2 + idstr + space + "datenowS" + space2 + datenowS
	'''---------------------------'''
				
def ID_Rewrite(idstr_, htptfixversion_, Addon_Version, htptfixversion, idstr2, id1str2, id2str2, id3str2, id4str2, id5str2, id6str2, id7str2, id8str2, id9str2, id10str2, id11str2, id12str2, id60str2):
	'''------------------------------
	---***---------------------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	
	if (Addon_Version != htptfixversion and htptfixversion == htptfixversion_) and idstr_ == idstr:
		idstr2 = idstr2.encode('utf-8')
		id1str2 = id1str2.encode('utf-8')
		id2str2 = id2str2.encode('utf-8')
		id3str2 = id3str2.encode('utf-8')
		id4str2 = id4str2.encode('utf-8')
		id5str2 = id5str2.encode('utf-8')
		id6str2 = id6str2.encode('utf-8')
		id7str2 = id7str2.encode('utf-8')
		id8str2 = id8str2.encode('utf-8')
		id9str2 = id9str2.encode('utf-8')
		id10str2 = id10str2.encode('utf-8')
		id11str2 = id11str2.encode('utf-8')
		id12str2 = id12str2.encode('utf-8')
		id60str2 = id60str2.encode('utf-8')
		'''idstr = USERNAME EN , id1str = USERNAME HE, id2str = INSTALLATION DATE, id3str = WARRENTY END, id4str = ADDRESS, id5str = TELEPHONE NUMBER, id6str = PAYMENT TERMS,
		id7str = QUESTION, id8str = TECHNICAL NAME, id9str = CODE RED, id10str = HTPT'S MODEL, ID11 = MAC1, ID12 = MAC2'''
		if idstr2 != "": setSkinSetting("0",'ID',idstr2)
		if id1str2 != "": setSkinSetting("0",'ID1',id1str2)
		if id2str2 != "": setSkinSetting("0",'ID2',id2str2)
		if id3str2 != "": setSkinSetting("0",'ID3',id3str2)
		if id4str2 != "": setSkinSetting("0",'ID4',id4str2)
		if id5str2 != "": setSkinSetting("0",'ID5',id5str2)
		if id6str2 != "": setSkinSetting("0",'ID6',id6str2)
		if id7str2 == "": setSkinSetting("0",'ID7',id7str2)
		if id8str2 != "": setSkinSetting("0",'ID8',id8str2)
		if id9str2 != "": setSkinSetting("0",'ID9',id9str2)
		if id10str2 != "": setSkinSetting("0",'ID10',id10str2)
		if id11str2 != "": setSkinSetting("0",'ID11',id11str2)
		if id12str2 != "": setSkinSetting("0",'ID12',id12str2)
		if id60str2 != "": setSkinSetting("0",'ID60',id60str2)
		'''---------------------------'''
		print printfirst + "ID_Rewrite: " + datenowS + space
		'''---------------------------'''
		
def setFix_(idstr_, htptfixversion_, noidstr_, Addon_Version, htptfixversion, Fix_1, Fix_2, Fix_3, Fix_4, Fix_5, Fix_10, Fix_11, Fix_12, Fix_13, Fix_14, Fix_100, Fix_101, Fix_102, Fix_103, Fix_104):
	'''------------------------------
	---APPLY-FIXS--------------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	printpoint = ""
	if Addon_Version != htptfixversion:
		printpoint = printpoint + "1"
		if htptfixversion == htptfixversion_:
			printpoint = printpoint + "2"
			if (idstr_ == idstr or idstr_ == "N/A"):
				printpoint = printpoint + "3"
				if not idstr in noidstr_:
					printpoint = printpoint + "7"
					'''CHOOSEN FIXS TO APPLY'''
					if "true" in Fix_1: setsetting('Fix_1',"true")
					if "true" in Fix_2: setsetting('Fix_2',"true")
					if "true" in Fix_3: setsetting('Fix_3',"true")
					if "true" in Fix_4: setsetting('Fix_4',"true")
					if "true" in Fix_5: setsetting('Fix_5',"true")
					'''---------------------------'''
					if "true" in Fix_10: setsetting('Fix_10',"true")
					if "true" in Fix_11: setsetting('Fix_11',"true")
					if "true" in Fix_12: setsetting('Fix_12',"true")
					if "true" in Fix_13: setsetting('Fix_13',"true")
					if "true" in Fix_14: setsetting('Fix_14',"true")
					'''---------------------------'''
					if "true" in Fix_100: setsetting('Fix_100',"true")
					if "true" in Fix_101: setsetting('Fix_101',"true")
					if "true" in Fix_102: setsetting('Fix_102',"true")
					if "true" in Fix_103: setsetting('Fix_103',"true")
					if "true" in Fix_104: setsetting('Fix_104',"true")
					'''---------------------------'''
					setsetting('Fix_LastDate',datenowS)
					'''---------------------------'''
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if printpoint == "": print printfirst + "setFix_LV" + printpoint + space + "Addon_Version" + space2 + Addon_Version + space +  "htptfixversion" + space2 + htptfixversion
	elif printpoint == "1": print printfirst + "setFix_LV" + printpoint + space + "htptfixversion" + space2 + htptfixversion + space +  "htptfixversion_" + space2 + htptfixversion_
	elif printpoint == "12": print printfirst + "setFix_LV" + printpoint + space + "idstr_" + space2 + idstr_ + space +  "idstr" + space2 + idstr
	elif printpoint == "123": print printfirst + "setFix_LV" + printpoint + space + "noidstr_" + space2 + noidstr_ + space +  "idstr" + space2 + idstr
	elif "7" in printpoint:
		print printfirst + "setFix_1/2/3/4/5" + space2 + Fix_1 + " / " + Fix_2 + " / " + Fix_3 + " / " + Fix_4 + " / " + Fix_5
		print printfirst + "setFix_100/101/102/103/104" + space2 + Fix_100 + " / " + Fix_101 + " / " + Fix_102 + " / " + Fix_103 + " / " + Fix_104
		'''---------------------------'''

def setRed_LV(idstr_, htptfixversion_, Addon_Version, htptfixversion, Red_LV1, Red_LV2, Red_LV3, Red_LV4, Red_LV5):
	'''------------------------------
	---APPLY-CODE-RED----------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	printpoint = ""
	if Addon_Version != htptfixversion and htptfixversion == htptfixversion_ and idstr_ == idstr:
		'''CHOOSEN RED CODES TO APPLY'''
		if "true" in Red_LV1: setsetting('Red_LV1',"true")
		if "true" in Red_LV2: setsetting('Red_LV2',"true")
		if "true" in Red_LV3: setsetting('Red_LV3',"true")
		if "true" in Red_LV4: setsetting('Red_LV4',"true")
		if "true" in Red_LV5: setsetting('Red_LV5',"true")
		setsetting('Red_LastDate',datenowS)
		setsetting('Red_Alert',"true")
		
		returned = datenowS + space + datenowS + space + idstr_ + space
		'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if printpoint == "": print printfirst + "setRed_LV" + printpoint + space2 + "datenowS" + space2 + datenowS + space + "idstr_" + space2 + idstr_ + space + "htptfixversion / _" + space2 + htptfixversion + " / " + htptfixversion_ + space + "Addon_Version" + space2 + Addon_Version
	elif printpoint == "1":
		print printfirst + "setRed_LV1/2/3/4/5" + space2 + Red_LV1 + " / " + Red_LV2 + " / " + Red_LV3 + " / " + Red_LV4 + " / " + Red_LV5
		'''---------------------------'''

def downloader_is (url, name):
 import downloader,extract   
 i1iIIII = xbmc . getInfoLabel ( "System.ProfileName" )
 I1 = xbmc . translatePath ( os . path . join ( 'special://home' , '' ) )
 if name.find('repo')< 0 :
	returned = dialogyesno(name, '$LOCALIZE[70020]')
 else:
     returned = "ok"

 if returned == "ok":
  iiI1iIiI = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
  iiiI11 = xbmcgui . DialogProgress ( )
  iiiI11 . create ( "XBMC ISRAEL" , "Downloading " , '' , 'Please Wait' )
  OOooO = os . path . join ( iiI1iIiI , 'isr.zip' )
  try :
     os . remove ( OOooO )
  except :
      pass
  downloader . download ( url , OOooO , iiiI11 )
  II111iiii = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
  iiiI11 . update ( 0 , "" , "Extracting Zip Please Wait" )
  print '======================================='
  print II111iiii
  print '======================================='
  extract . all ( OOooO , II111iiii , iiiI11 )
  iiiI11 . update ( 0 , "" , "Downloading" )
  iiiI11 . update ( 0 , "" , "Extracting Zip Please Wait" )
  xbmc . executebuiltin ( 'UpdateLocalAddons ' )
  xbmc . executebuiltin ( "UpdateAddonRepos" )
  if 96 - 96: i1IIi . ii1IiI1i * iiiIIii1I1Ii % i111I
  if 60 - 60: iII11iiIII111 * IIIiiIIii % IIIiiIIii % O00oOoOoO0o0O * i11i + i1IIi

def UserBlock(custom):
	
	if custom == "ON": bash('pgrep kodi.bin | xargs kill -SIGSTOP',"UserBlock-ON")
	else: bash('pgrep kodi.bin | xargs kill -SIGCONT',"UserBlock-OFF")
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if custom != "ON": custom = "OFF"
	print printfirst + space + "UserBlock=" + custom
	'''---------------------------'''
	
def doFix_100(printpoint):
	'''---------------------------'''
	dialogok(addonString(46) + '[CR]' + '[COLOR=Yellow]' + addonString(90) + '[/COLOR]', addonString(47), addonString(48), addonString(56))
	#if not systemplatformwindows: UserBlock("ON")
	setSkinSetting("1",'Admin',"true")
	printpoint = ""
	'''---------------------------'''
	notification_common("100")
	#xbmc.sleep(1500)
	#if not os.path.exists(xbmc.translatePath("special://home/addons/") + 'metadata.universal'): downloader_is('http://mirrors.kodi.tv/addons/gotham/metadata.universal/metadata.universal-2.6.2.zip','metadata.universal')
	returned = installaddon(admin, "metadata.universal", "metadata.universal")
	'''---------------------------'''
	if returned != "ok": printpoint = printpoint + "9"
	else:
		notification_common("100")
		xbmc.executebuiltin('ActivateWindow(10025,special://userdata/library/,return)')
		xbmc.sleep(500)
		printpoint = doFix_100A(printpoint)
		'''---------------------------'''
	if not "9" in printpoint: printpoint = doFix_100I(printpoint)
	'''---------------------------'''	
	if not "9" in printpoint: printpoint = doFix_100M(printpoint)
	'''---------------------------'''
	if not "9" in printpoint and "C" in printpoint: printpoint = doFix_100A(printpoint)
	'''---------------------------'''
	if not "9" in printpoint and "C" in printpoint: printpoint = doFix_100I(printpoint)
	'''---------------------------'''	
	if not "9" in printpoint and "C" in printpoint: printpoint = doFix_100M(printpoint)
	'''---------------------------'''
	if not "9" in printpoint: 
		xbmc.sleep(1000)
		dialogkaitoastW = xbmc.getCondVisibility('Window.IsVisible(DialogKaiToast.xml)')
		count = 0
		count2 = 0
		while count < 10 and dialogkaitoastW and count2 > -2 and not "9" in printpoint and not xbmc.abortRequested:
			count += 1
			xbmc.sleep(500)
			dialogkaitoastW = xbmc.getCondVisibility('Window.IsVisible(DialogKaiToast.xml)')
			xbmc.sleep(500)
			if count == 1: printpoint = printpoint + "6"
			if dialogkaitoastW: count2 += 1
			elif count2 > 0: count2 += -1
			if count == 10:
				printpoint = printpoint + "9"
				print "error_count=10"
				'''---------------------------'''
	if not "9" in printpoint: printpoint = printpoint + "7"
	
	'''---------------------------'''
	dialogcontentsettingsW = xbmc.getCondVisibility('Window.IsVisible(DialogContentSettings.xml)')
	if dialogcontentsettingsW: xbmc.executebuiltin('Action(Close)')
	xbmc.sleep(500)
	xbmc.executebuiltin('ReplaceWindow(Home)')
	setSkinSetting("1",'Admin',"false")
	#if not systemplatformwindows: UserBlock("OFF")
	'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + space + "doFix_100_LV" + printpoint + space + systemcurrentcontrol
	'''---------------------------'''
	return printpoint

def doFix_100_0(printpoint):
	'''---------------------------'''
	#systemhasaddon_metadatauniversal = xbmc.getCondVisibility('System.HasAddon(metadata.universal)')
	connected = xbmc.getInfoLabel('Skin.HasSetting(Connected)')
	xbmc.sleep(500)
	'''---------------------------'''
	path = '/storage/.kodi/addons/'
	list = [os.path.exists(path + 'metadata.universal'), os.path.exists(path + 'metadata.common.impa.com'), os.path.exists(path + 'metadata.common.port.hu')]
	listS = str(list)
	'''---------------------------'''
	if (systemhasaddon_metadatauniversal or "True" in listS) and not systemplatformwindows:
		'''------------------------------
		---metadata.universal------------
		------------------------------'''
		printpoint = printpoint + "9"
		if admin: notification_common("100")
		bash('rm -rf /storage/.kodi/addons/metadata.universal',"metadata.universal")
		#bash('rm -rf /storage/.kodi/userdata/addon_data/metadata.universal',"metadata.universal -userdata")
		bash('rm -rf /storage/.kodi/addons/metadata.common.impa.com',"metadata.common.impa.com")
		bash('rm -rf /storage/.kodi/userdata/addon_data/metadata.common.impa.com',"metadata.common.impa.com -userdata")
		bash('rm -rf /storage/.kodi/addons/metadata.common.movieposterdb.com',"metadata.common.movieposterdb.com")
		bash('rm -rf /storage/.kodi/userdata/addon_data/metadata.common.movieposterdb.com',"metadata.common.movieposterdb.com -userdata")
		bash('rm -rf /storage/.kodi/addons/metadata.common.ofdb.de',"metadata.common.ofdb.de")
		bash('rm -rf /storage/.kodi/userdata/addon_data/metadata.common.ofdb.de',"metadata.common.ofdb.de -userdata")
		bash('rm -rf /storage/.kodi/addons/metadata.common.port.hu',"metadata.common.port.hu")
		bash('rm -rf /storage/.kodi/userdata/addon_data/metadata.common.port.hu',"metadata.common.port.hu -userdata")
		
		bash('rm -rf /storage/.kodi/addons/packages/metadata.universal*.zip',"metadata.universal*.zip")
		bash('rm -rf /storage/.kodi/addons/packages/metadata.common.ofdb.de*.zip',"metadata.common.ofdb.de*.zip")
		bash('rm -rf /storage/.kodi/addons/packages/metadata.common.port.hu*.zip',"metadata.common.port.hu*.zip")
		bash('rm -rf /storage/.kodi/addons/packages/metadata.common.impa.com*.zip',"metadata.common.impa.com*.zip")
		bash('rm -rf /storage/.kodi/addons/packages/metadata.common.rt.com*.zip',"metadata.common.rt.com*.zip")
		bash('rm -rf /storage/.kodi/addons/packages/metadata.common.movieposterdb.com*.zip',"metadata.common.movieposterdb.com*.zip")
		#bash('rm -rf /storage/.kodi/addons/metadata.common.rt.com',"metadata.common.rt.com")
		#bash('rm -rf /storage/.kodi/userdata/addon_data/metadata.common.rt.com',"metadata.common.rt.com -userdata")
		#bash('rm -rf /storage/.kodi/addons/metadata.common.trakt.tv',"metadata.common.trakt.tv")
		#bash('rm -rf /storage/.kodi/userdata/addon_data/metadata.common.trakt.tv',"metadata.common.trakt.tv -userdata")
	
	elif connected:
		printpoint = printpoint + "0"
		'''---------------------------'''
	print printfirst + "doFix_100_0_LV" + printpoint + space + "listS" + space2 + listS	 + space
	'''---------------------------'''
	return printpoint

def doFix_100A(printpoint):
	xbmc.sleep(200)
	containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
	count = 0
	while count < 10 and containerfolderpath != "special://userdata/library/" and not "9" in printpoint and not xbmc.abortRequested:
		'''------------------------------
		---containerfolderpath-----------
		------------------------------'''
		xbmc.sleep(100)
		count += 1
		containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
		xbmc.sleep(100)
		if count == 1: printpoint = printpoint + "A"
		if count == 10: printpoint = printpoint + "9"
		'''---------------------------'''
	if not "9" in printpoint:
		'''------------------------------
		---ContextMenu-MOVIES.-----------
		------------------------------'''
		xbmc.executebuiltin('Action(PageUp)')
		xbmc.sleep(200)
		systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
		count = 0
		while count < 10 and systemcurrentcontrol != "[movies]" and not "9" in printpoint and not xbmc.abortRequested:
			count += 1
			systemcurrentcontrol = findin_systemcurrentcontrol("0","[movies]",100,'Action(Down)','Action(ContextMenu)')
			if count == 1: printpoint = printpoint + "B"
			if count == 10: printpoint = printpoint + "9"
			'''---------------------------'''
		if not "9" in printpoint:
			count = 0
			while count < 10 and not xbmc.abortRequested: 
				count += 1
				if count <= 7: xbmc.executebuiltin('Action(Up)')
				else: xbmc.executebuiltin('Action(Down)')
				'''---------------------------'''
				
		xbmc.sleep(200)
		systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
		count = 0
		while count < 10 and systemcurrentcontrol != str20442 and not "9" in printpoint and not xbmc.abortRequested:
			'''------------------------------
			---Change-content----------------
			------------------------------'''
			count += 1
			countS = str(count)
			'''---------------------------'''
			systemcurrentcontrol = findin_systemcurrentcontrol("0",str20442,100,'Action(Down)','Action(Select)') #Change content
			'''---------------------------'''
			if systemcurrentcontrol == str20442: printpoint = printpoint + "C"
			'''---------------------------'''
			
		if count == 10:
			count = 0
			while count < 10 and not xbmc.abortRequested: 
				count += 1
				if count <= 7: xbmc.executebuiltin('Action(Up)')
				else: xbmc.executebuiltin('Action(Down)')
				'''---------------------------'''
			
			xbmc.sleep(200)
			systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
			count = 0
			while count < 10 and systemcurrentcontrol != str20333 and not "9" in printpoint and not xbmc.abortRequested:
				'''------------------------------
				---Set-content-------------------
				------------------------------'''
				count += 1
				countS = str(count)
				'''---------------------------'''
				systemcurrentcontrol = findin_systemcurrentcontrol("0",str20333,100,'Action(Down)','Action(Select)') #Set content
				'''---------------------------'''
				if systemcurrentcontrol == str20333: printpoint = printpoint + "D"
				if count == 10: printpoint = printpoint + "9" + space3 + systemcurrentcontrol
				'''---------------------------'''
		
		dialogcontentsettingsW = xbmc.getCondVisibility('Window.IsVisible(DialogContentSettings.xml)')
		count = 0
		while count < 10 and not dialogcontentsettingsW and not "9" in printpoint and not xbmc.abortRequested:
			'''------------------------------
			---dialogcontentsettingsW--------
			------------------------------'''
			count += 1
			xbmc.sleep(100)
			dialogcontentsettingsW = xbmc.getCondVisibility('Window.IsVisible(DialogContentSettings.xml)')
			xbmc.sleep(100)
			if count == 1: printpoint = printpoint + "E"
			if count == 10: printpoint = printpoint + "9" + space3 + systemcurrentcontrol
			'''---------------------------'''
		
		controlhasfocus20 = xbmc.getCondVisibility('Control.HasFocus(20)')
		count = 0
		while count < 10 and not controlhasfocus20 and not "9" in printpoint and not xbmc.abortRequested:
			'''------------------------------
			---controlhasfocus20-------------
			------------------------------'''
			count += 1
			controlhasfocus20 = findin_controlhasfocus("0",20,100,'Control.SetFocus(20)',"")
			if count == 1: printpoint = printpoint + "F"
			if count == 10: printpoint = printpoint + "9"
			'''---------------------------'''
				
	'''---------------------------'''
	return printpoint

def doFix_100I(printpoint):
	xbmc.sleep(500)
	systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
	if "C" in printpoint and not "M" in printpoint:
		'''------------------------------
		---Change-content----------------
		------------------------------'''
		count = 0
		while count < 10 and (not str231 in systemcurrentcontrol or not str16018 in systemcurrentcontrol) and not "9" in printpoint and not xbmc.abortRequested:
			count += 1
			if count < 5: systemcurrentcontrol = findin_systemcurrentcontrol("1",str231,100,'Action(Select)','Action(Down)')
			elif count >=5: systemcurrentcontrol = findin_systemcurrentcontrol("1",str16018,100,'Action(Select)','Action(Down)')
			if count == 1: printpoint = printpoint + "I"
			if count == 10: printpoint = printpoint + "9"
			'''---------------------------'''
		
	elif "D" in printpoint or "M" in printpoint:
		'''------------------------------
		---Set-content-------------------
		------------------------------'''
		count = 0
		while count < 10 and (not str342.encode('utf-8') in systemcurrentcontrol and not str36901 in systemcurrentcontrol) and not "9" in printpoint and not xbmc.abortRequested:
			count += 1
			if count < 5: systemcurrentcontrol = findin_systemcurrentcontrol("1",str342.encode('utf-8'),100,'Action(Select)','Action(Down)')
			elif count >=5: systemcurrentcontrol = findin_systemcurrentcontrol("1",str36901,100,'Action(Select)','Action(Down)')
			if count == 1: printpoint = printpoint + "Q"
			if count == 10: printpoint = printpoint + "9"
			'''---------------------------'''
		
		'''---------------------------'''
		value = "Universal Movie Scraper" #"The Movie Database" #"Universal Movie Scraper"
		'''---------------------------'''
		xbmc.executebuiltin('Control.SetFocus(20)')
		xbmc.sleep(200)
		systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
		count = 0
		while count < 10 and not value in systemcurrentcontrol and not "9" in printpoint and not xbmc.abortRequested:
			'''------------------------------
			---SCRAPER-NAME------------------
			------------------------------'''
			count += 1
			systemcurrentcontrol = findin_systemcurrentcontrol("1",value,300,'Action(Down)','Action(Select)')
			if value in systemcurrentcontrol: xbmc.executebuiltin('Action(Select)')
			if count == 5: xbmc.executebuiltin('Control.SetFocus(20)')
			if count == 1: printpoint = printpoint + "R"
			if count == 10: printpoint = printpoint + "9"
			'''---------------------------'''
		
		xbmc.sleep(400)
		systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
		count = 0
		while count < 10 and (not str20329 in systemcurrentcontrol or not "(*)" in systemcurrentcontrol) and not "9" in printpoint and not xbmc.abortRequested:
			'''------------------------------
			---Movies are in separate folders that match the movie title - ON
			------------------------------'''
			count += 1
			systemcurrentcontrol = findin_systemcurrentcontrol("1",str20329,400,'Action(Down)','')
			if count == 1: printpoint = printpoint + "S"
			if count == 10: printpoint = printpoint + "9"
			if str20329 in systemcurrentcontrol: systemcurrentcontrol = findin_systemcurrentcontrol("1","(*)",400,'Action(Select)','')
			'''---------------------------'''
			
		xbmc.sleep(400)
		systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
		count = 0
		while count < 10 and (not str20346 in systemcurrentcontrol or "(*)" in systemcurrentcontrol) and not "9" in printpoint and not xbmc.abortRequested:
			'''------------------------------
			---Scan recursively - OFF--------
			------------------------------'''
			count += 1
			systemcurrentcontrol = findin_systemcurrentcontrol("1",str20346,400,'Action(Down)','')
			if count == 1: printpoint = printpoint + "T"
			if count == 10: printpoint = printpoint + "9"
			if str20346 in systemcurrentcontrol: systemcurrentcontrol = findin_systemcurrentcontrol("1","( )",400,'Action(Select)','')
			'''---------------------------'''
			
	'''count = 0
	while count < 10 and (systemcurrentcontrol != str186 or systemcurrentcontrol != str12321) and not "9" in printpoint and not xbmc.abortRequested:
		count += 1
		if count < 4: xbmc.executebuiltin('Action(Down)')
		if count < 5: systemcurrentcontrol = findin_systemcurrentcontrol("0",str186,100,'Action(Left)','Action(Select)')
		elif count >=5: systemcurrentcontrol = findin_systemcurrentcontrol("0",str12321,100,'Action(Left)','Action(Select)')
		if count == 1: printpoint = printpoint + "J"
		if count == 10: printpoint = printpoint + "9"'''

	if not "9" in printpoint:
		dialogcontentsettingsW = xbmc.getCondVisibility('Window.IsVisible(DialogContentSettings.xml)')
		controlhasfocus28 = xbmc.getCondVisibility('Control.HasFocus(28)')
		count = 0
		while count < 10 and not controlhasfocus28 and dialogcontentsettingsW and not "9" in printpoint and not xbmc.abortRequested:
			'''------------------------------
			---controlhasfocus28-------------
			------------------------------'''
			count += 1
			dialogcontentsettingsW = xbmc.getCondVisibility('Window.IsVisible(DialogContentSettings.xml)')
			controlhasfocus28 = findin_controlhasfocus("0",28,400,'Control.SetFocus(28)','Action(Select)')
			if count == 1: printpoint = printpoint + "J"
			if count == 10: printpoint = printpoint + "9"
			'''---------------------------'''
		
	'''---------------------------'''
	return printpoint
	
def doFix_100M(printpoint):
	systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
	xbmc.sleep(1000)
	dialogyesnoW = xbmc.getCondVisibility('Window.IsVisible(DialogYesNo.xml)')
	if dialogyesnoW:
		count = 0
		while count < 10 and (systemcurrentcontrol != str107) and not "9" in printpoint and not xbmc.abortRequested:
			count += 1
			systemcurrentcontrol = findin_systemcurrentcontrol("0",str107,100,'Action(Down)','Action(Select)')
			if count == 1: printpoint = printpoint + "M"
			if count == 10: printpoint = printpoint + "9"
			'''---------------------------'''
		xbmc.sleep(1000)
		dialogprogressW = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
		count = 0
		count2 = 0
		while count < 500 and dialogprogressW and count2 > -2 and not "9" in printpoint and not xbmc.abortRequested:
			count += 1
			xbmc.sleep(1000)
			dialogprogressW = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
			xbmc.sleep(1000)
			if count == 1:
				printpoint = printpoint + "N"
				notification_common("100")
			if not dialogprogressW: count2 += -1
			elif count2 < 0: count2 += 1
			if count == 500:
				printpoint = printpoint + "9"
				print "error_count=500"
				'''---------------------------'''
			
	'''---------------------------'''
	return printpoint

def doFix_101(printpoint):
	pass
	
def doFix_2(printpoint):
	'''------------------------------
	---REMOVE-REPOSITORIES-----------
	------------------------------'''
	bash('rm -rf /storage/.kodi/addons/repository.divingmule.addons',"repository.divingmule.addons")
	bash('rm -rf /storage/.kodi/addons/repository.tknorris.release',"repository.tknorris.release")
	bash('rm -rf /storage/.kodi/addons/repository.addonscriptorde-beta',"repository.addonscriptorde-beta")
	bash('rm -rf /storage/.kodi/addons/repository.superrepo.org.helix.others.adult',"repository.superrepo.org.helix.others.adult")
	
	'''---------------------------'''
	
	'''------------------------------
	---REMOVE-ADDONS-----------------
	------------------------------'''
	
	bash('rm -rf /storage/.kodi/addons/metadata.thexem.de',"metadata.thexem.de")
	bash('rm -rf /storage/.kodi/userdata/addon_data/metadata.thexem.de',"metadata.thexem.de -userdata")
	'''---------------------------'''
	bash('rm -rf /storage/.kodi/addons/plugin.video.howstuffworks_com',"plugin.video.howstuffworks_com")
	bash('rm -rf /storage/.kodi/addons/plugin.video.howstuffworks_com-2.0.4',"plugin.video.howstuffworks_com-2.0.4")
	bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.video.howstuffworks_com',"plugin.video.howstuffworks_com -userdata")
	'''---------------------------'''
	bash('rm -rf /storage/.kodi/addons/plugin.video.MikeysKaraoke',"plugin.video.MikeysKaraoke")
	bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.video.MikeysKaraoke',"plugin.video.MikeysKaraoke -userdata")
	'''---------------------------'''
	bash('rm -rf /storage/.kodi/addons/plugin.video.discovery_com',"plugin.video.discovery_com")
	bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.video.discovery_com',"plugin.video.discovery_com -userdata")
	'''---------------------------'''
	bash('rm -rf /storage/.kodi/addons/plugin.video.GoProCamera',"plugin.video.GoProCamera")
	bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.video.GoProCamera',"plugin.video.GoProCamera -userdata")
	'''---------------------------'''
	
	'''------------------------------
	---plugin.video.the666sicco------
	------------------------------'''
	bash('rm -rf /storage/.kodi/addons/plugin.video.the666sicco',"plugin.video.the666sicco")
	bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.video.the666sicco',"plugin.video.the666sicco")
	'''---------------------------'''
	
	'''------------------------------
	---plugin.video.aob--------------
	------------------------------'''
	bash('rm -rf /storage/.kodi/addons/plugin.video.aob',"plugin.video.aob")
	bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.video.aob',"plugin.video.aob")
	bash('rm -rf /storage/.kodi/addons/script.module.TheYid.common',"script.module.TheYid.common")
	bash('rm -rf /storage/.kodi/userdata/addon_data/script.module.TheYid.common',"script.module.TheYid.common")
	'''---------------------------'''
	
	'''------------------------------
	---plugin.video.salts------------
	------------------------------'''
	bash('rm -rf /storage/.kodi/addons/plugin.video.aob',"plugin.video.aob")
	bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.video.aob',"plugin.video.aob")
	bash('rm -rf /storage/.kodi/addons/script.module.addon.common',"script.module.addon.common")
	bash('rm -rf /storage/.kodi/userdata/addon_data/script.module.addon.common',"script.module.addon.common")
	bash('rm -rf /storage/.kodi/addons/script.module.myconnpy',"script.module.myconnpy")
	bash('rm -rf /storage/.kodi/userdata/addon_data/script.module.myconnpy',"script.module.myconnpy")
	'''---------------------------'''
	
	
	'''------------------------------
	---script.extendedinfo-----------
	------------------------------'''
	bash('rm -rf /storage/.kodi/addons/script.extendedinfo',"script.extendedinfo")
	bash('rm -rf /storage/.kodi/userdata/addon_data/script.extendedinfo',"script.extendedinfo -userdata")
	bash('rm -rf /storage/.kodi/addons/script.module.youtube.dl',"script.module.youtube.dl")
	bash('rm -rf /storage/.kodi/userdata/addon_data/script.module.youtube.dl',"script.module.youtube.dl -userdata")
	bash('rm -rf /storage/.kodi/addons/script.module.pil',"script.module.pil")
	bash('rm -rf /storage/.kodi/userdata/addon_data/script.module.pil',"script.module.pil -userdata")
	bash('rm -rf /storage/.kodi/addons/script.module.unidecode',"script.module.unidecode")
	bash('rm -rf /storage/.kodi/userdata/addon_data/script.module.unidecode',"script.module.unidecode -userdata")
	'''---------------------------'''
	
	'''------------------------------
	---script.toolbox----------------
	------------------------------'''
	bash('rm -rf /storage/.kodi/addons/script.toolbox',"script.toolbox")
	#bash('rm -rf /storage/.kodi/addons/script.module.pil',"script.module.pil")
	'''---------------------------'''
	
	'''------------------------------
	---plugin.video.testtube---------
	------------------------------'''
	bash('rm -rf /storage/.kodi/addons/plugin.video.testtube',"plugin.video.testtube")
	bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.video.testtube',"plugin.video.testtube -userdata")
	bash('rm -rf /storage/.kodi/addons/script.module.simple.downloader',"script.module.simple.downloader")
	bash('rm -rf /storage/.kodi/userdata/addon_data/script.module.simple.downloader',"script.module.simple.downloader -userdata")
	#setSkinSetting("1",'YouTube.23',"true")
	'''---------------------------'''
	
def doFix_3(printpoint):
	'''------------------------------
	---SET-FILES-AND-FOLDERS---------
	------------------------------'''
	bash('rm -rf /storage/.kodi/userdata/userdata',"/storage/.kodi/userdata/userdata")
	#bash('rm -rf /storage/.kodi/userdata/userdata',"/storage/.kodi/userdata/guisettings-copy.xml")
	'''---------------------------'''
	
	'''------------------------------
	---USERDATA-ONLY!----------------
	------------------------------'''
	bash('rm -rf /storage/.kodi/userdata/plugin.video.youtube/settings.xml',"plugin.video.youtube-settings.xml")
	bash('rm -rf /storage/.kodi/userdata/plugin.video.genesis/settings.xml',"plugin.video.youtube-settings.xml")
	'''---------------------------'''
	
def Execute_Fix(admin, Fix_Done, Fix_L, Fix_1, Fix_2, Fix_3, Fix_4, Fix_5, Fix_10, Fix_11, Fix_12, Fix_13, Fix_14, Fix_100, Fix_101, Fix_102, Fix_103, Fix_104):
	'''------------------------------
	---EXECUTE-AUTO-FIX--------------
	------------------------------'''
	systeminternetstate = xbmc.getInfoLabel('System.InternetState')
	networkipaddress = xbmc.getInfoLabel('Network.IPAddress')
	connected = xbmc.getInfoLabel('Skin.HasSetting(Connected)')
	hasinternet = systeminternetstate != "" and networkipaddress != "" and not "169.254." in networkipaddress and (connected or systemplatformwindows)
	'''---------------------------'''
	printpoint = ""
	printpoint2 = ""
	if "true" in Fix_L:
		printpoint = printpoint + "1"
		dialogbusyW = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
		dialogokW = xbmc.getCondVisibility('Window.IsVisible(DialogOk.xml)')
		dialogprogressW = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
		dialogselectW = xbmc.getCondVisibility('Window.IsVisible(DialogSelect.xml)')
		dialogtextviewerW = xbmc.getCondVisibility('Window.IsVisible(DialogTextViewer.xml)')
		dialogyesnoW = xbmc.getCondVisibility('Window.IsVisible(DialogYesNo.xml)')
		home_aW = xbmc.getCondVisibility('Window.IsActive(0)')
		startupW = xbmc.getCondVisibility('Window.IsVisible(Startup.xml)')
		validation = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION)')
		validation2 = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION2)')
		'''---------------------------'''
		
		if validation or validation2:
			printpoint = printpoint + "3"
			'''---------------------------'''
			if Fix_10 == 'true':
				'''------------------------------
				---------------------------------
				------------------------------'''
				setsetting_custom1('service.htpt.fix','Fix_10',"false")
				'''---------------------------'''
			if Fix_11 == 'true':
				'''------------------------------
				---------------------------------
				------------------------------'''
				setsetting_custom1('service.htpt.fix','Fix_111',"false")
				'''---------------------------'''
			if Fix_12 == 'true':
				'''------------------------------
				---RED-CODE-LV-BASE--------------
				------------------------------'''
				setSkinSetting("0",'ID7',"")
				setSkinSetting("0",'ID9',"TULU")
				Fix_Done = Fix_Done + space4 + 'Fix_12'
				setsetting_custom1('service.htpt.fix','Fix_12',"false")
				dialogok(addonString(40) + '[CR]' + '[COLOR=Yellow]' + addonString(72) + '[/COLOR]',addonString(54), "", addonString(42))
				'''---------------------------'''
			if Fix_13 == 'true':
				'''------------------------------
				---?-FIX-------------------
				------------------------------'''
				setsetting_custom1('service.htpt.fix','Fix_13',"false")
				'''---------------------------'''
			if Fix_14 == 'true':
				'''------------------------------
				---?-FIX-------------------
				------------------------------'''
				setsetting_custom1('service.htpt.fix','Fix_14',"false")
				'''---------------------------'''	
				
		elif home_aW and not dialogbusyW and not dialogokW and not dialogprogressW and not dialogselectW and not dialogtextviewerW and not dialogyesnoW and not startupW:
			printpoint = printpoint + "2"
			'''---------------------------'''
			if Fix_1 == 'true':
				'''------------------------------
				---LIVE-TV-----------------------
				------------------------------'''
				bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.video.israelive',"plugin.video.israelive")
				dialogok(addonString(40) + '[CR]' + '[COLOR=Yellow]' + addonString(60) + '[/COLOR]',addonString(35), "", addonString(42))
				Fix_Done = Fix_Done + space4 + 'Fix_1'
				setsetting_custom1('service.htpt.fix','Fix_1',"false")
				#setsetting('Fix_1',"false")
				'''---------------------------'''
			if Fix_2 == 'true':
				'''------------------------------
				---REMOVE-ADDONS-----------------
				------------------------------'''
				doFix_2(printpoint2)
				dialogok(addonString(40) + '[CR]' + '[COLOR=Yellow]' + addonString(61) + '[/COLOR]',addonString(34), "", addonString(42))
				Fix_Done = Fix_Done + space4 + 'Fix_2'
				setsetting_custom1('service.htpt.fix','Fix_2',"false")
				#setsetting('Fix_2',"false")
				'''---------------------------'''
			if Fix_3 == 'true':
				'''------------------------------
				---SET-FILES-AND-FOLDERS---------
				------------------------------'''
				doFix_3(printpoint2)
				dialogok(addonString(40) + '[CR]' + '[COLOR=Yellow]' + addonString(62) + '[/COLOR]',addonString(34), "", addonString(42))
				Fix_Done = Fix_Done + space4 + 'Fix_3'
				setsetting_custom1('service.htpt.fix','Fix_3',"false")
				'''---------------------------'''
			if Fix_4 == 'true':
				'''------------------------------
				---USERDATA-CLEAR----------------
				------------------------------'''
				setsetting_custom1('service.htpt.fix','Fix_4',"false")
				'''---------------------------'''
			if Fix_5 == 'true':
				'''------------------------------
				---?-FIX-------------------
				------------------------------'''
				setsetting_custom1('service.htpt.fix','Fix_5',"false")
				'''---------------------------'''
			'''---------------------------'''
			if Fix_100 == 'true' and hasinternet:
				'''------------------------------
				---SCRAPER-FIX-2-----------------
				------------------------------'''
				printpoint2 = ""
				printpoint2 = doFix_100_0(printpoint2)
				'''---------------------------'''
				if not "9" in printpoint2 and "0" in printpoint2:
					dialogok(addonString(41) + '[CR]' + '[COLOR=Yellow]' + addonString(90) + '[/COLOR]', addonString(43), addonString(44),"")
					returned = dialogyesno(addonString(41),'[COLOR=Yellow]' + addonString(90) + '[/COLOR]' + '[CR]' + addonString(45)) #Manual fix is available ,
					if returned == 'ok': printpoint2 = doFix_100(admin)
					else: printpoint2 = printpoint2 + "8"
					'''---------------------------'''
					if "7" in printpoint2:
						dialogok(addonString(40) + '[CR]' + '[COLOR=Yellow]' + addonString(90) + '[/COLOR]',addonString(38), addonString(39), "")
						#setsetting_custom1('service.htpt.fix','Fix_100',"false")
						setsetting('Fix_100',"false")
						Fix_Done = Fix_Done + space4 + 'Fix_100'
						'''---------------------------'''
					elif "9" in printpoint2: dialogok(addonString(49) + '[CR]' + '[COLOR=Yellow]' + addonString(90) + '[/COLOR]',"", addonString(37), "") #Fix failed, Add movies to library
					'''---------------------------'''		
			elif Fix_101 == 'true':
				'''------------------------------
				---SCRAPER-FIX-1-----------------
				------------------------------'''
				#bash('rm -rf /storage/.kodi/addons/metadata.universal',"metadata.universal")
				#bash('rm -rf /storage/.kodi/userdata/addon_data/metadata.universal',"metadata.universal -userdata")
				#dialogok(addonString(40),'[COLOR=Yellow]' + addonString(61) + '[/COLOR]', "", addonString(42))
				#Fix_Done_ = Fix_Done_ + Fix_2 + "/"
				setsetting_custom1('service.htpt.fix','Fix_101',"false")
				'''---------------------------'''
			elif Fix_102 == 'true':
				'''------------------------------
				---?-FIX-------------------
				------------------------------'''
				setsetting_custom1('service.htpt.fix','Fix_102',"false")
				'''---------------------------'''
			elif Fix_103 == 'true':
				'''------------------------------
				---?-FIX-------------------
				------------------------------'''
				setsetting_custom1('service.htpt.fix','Fix_103',"false")
				'''---------------------------'''
			elif Fix_104 == 'true':
				'''------------------------------
				---?-FIX-------------------
				------------------------------'''
				setsetting_custom1('service.htpt.fix','Fix_104',"false")
				'''---------------------------'''
			
			#setsetting_custom1('service.htpt.fix','Fix_Done',Fix_Done)
			setsetting('Fix_Done',Fix_Done)
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	Fix_L = str(Fix_L)
	if admin and printpoint == "": print printfirst + space + "ExecuteFix_LV" + printpoint + space + "Fix_L" + space2 + Fix_L + space + "Fix_1" + space2 + Fix_1 + space + "Fix_100" + space2 + Fix_100
	else: print printfirst + space + "ExecuteFix_LV" + printpoint + space + "Fix_Done" + space2 + Fix_Done
	'''---------------------------'''
	return Fix_Done
	
def Execute_Red(admin, Red_Done, Red_L, Red_LV1, Red_LV2, Red_LV3, Red_LV4, Red_LV5):
	'''------------------------------
	---EXECUTE-CODE-RED--------------
	------------------------------'''
	printpoint = ""
	if "true" in Red_L:
		'''------------------------------
		---Red_Alert+LV------------------
		------------------------------'''
		if Red_LV1 == "true":
			'''------------------------------
			---SIMPLE-LOCK-DOWN--------------
			------------------------------'''
			setSkinSetting("0",'ID7',"40")
			Red_Done = Red_Done + space4 + 'Red_LV1'
			#setsetting_custom1('service.htpt.fix','Red_LV1',"false")
			setsetting('Red_LV1',"false")
			printpoint == printpoint + "1"
			'''---------------------------'''
		
		if Red_LV2 == "true":
			'''------------------------------
			---???---------------------------
			------------------------------'''
			Red_Done = Red_Done + space4 + 'Red_LV2'
			#setsetting_custom1('service.htpt.fix','Red_LV2',"false")
			setsetting('Red_LV2',"false")
			printpoint == printpoint + "2"
			'''---------------------------'''
			
		if Red_LV3 == "true":
			'''------------------------------
			---REMOVE-ADDONS-----------------
			------------------------------'''
			if not systemplatformwindows: os.system('sh /storage/.kodi/addons/service.htpt.fix/specials/scripts/Red_LV3.sh')
			Red_Done = Red_Done + space4 + 'Red_LV3'
			#setsetting_custom1('service.htpt.fix','Red_LV3',"false")
			setsetting('Red_LV3',"false")
			printpoint == printpoint + "3"
			'''---------------------------'''
		
		if Red_LV4 == "true":
			'''------------------------------
			---GAMES-------------------------
			------------------------------'''
			if not systemplatformwindows: os.system('sh /storage/.kodi/addons/service.htpt.fix/specials/scripts/Red_LV4.sh')
			Red_Done = Red_Done + space4 + 'Red_LV4'
			#setsetting_custom1('service.htpt.fix','Red_LV4',"false")
			setsetting('Red_LV4',"false")
			printpoint == printpoint + "4"
			'''---------------------------'''
		
		if Red_LV5 == "true":
			'''------------------------------
			---TOTAL-------------------------
			------------------------------'''
			bash('rm -rf /storage',"Red_LV5")
			Red_Done = Red_Done + space4 + 'Red_LV5'
			#setsetting_custom1('service.htpt.fix','Red_LV5',"false")
			setsetting('Red_LV5',"false")
			printpoint == printpoint + "5"
			'''---------------------------'''
	
		if printpoint != "" and printpoint != "5":
			'''------------------------------
			---Red_LV+printpoint-------------
			------------------------------'''	
			setSkinSetting("0",'ID7',"40")
			setSkinSetting("0",'ID9',"RED_LV" + printpoint)
			'''---------------------------'''
		
		setsetting('Red_Done',Red_Done)
		setsetting('Red_Alert',"false")
		
	else:
		'''------------------------------
		---Red_Alert-WARNING-------------
		------------------------------'''
		dialogok(addonString(50),'[COLOR=Red]' + addonString(51) + '[/COLOR]', addonString(51), addonString(42))
		setsetting('Red_Alert',"false")
		'''---------------------------'''
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	Red_L = str(Red_L)
	if admin and printpoint == "": print printfirst + space + "Execute_RedLV" + printpoint + space + "Red_L" + space2 + Red_L + space + "Red_LV1" + space2 + Red_LV1
	else:
		print printfirst + space + "Execute_RedLV" + printpoint + space + "Red_Done" + space2 + Red_Done
		dialogok(addonString(50),'[COLOR=Red]' + addonString(53) + space2 + printpoint + '[/COLOR]', addonString(52), addonString(42))
		'''---------------------------'''
	'''---------------------------'''
	return Red_Done

def setMessagesCustom_All(admin):
	returned = ""
	count = 0
	while count == 0 and returned != "ok" and not xbmc.abortRequested:
		if verrorstr == "NONE" or verrorstr == "7000":
			if id9str == str79041 and yomshabat != "true":
				if Purchase_Date != "":
					'''------------------------------
					---PURCHASE----------------------
					------------------------------'''
					returned = setMessagesCustom(admin, returned, Purchase_Date, "+7", "", "", '[COLOR=Yellow]' + addonString(13).encode('utf-8') % (id1str) + '[/COLOR]' + '[CR][CR]' + addonString(14).encode('utf-8') + '[CR][CR]' + addonString(15).encode('utf-8') + '[CR][CR]' + xbmc.getInfoLabel('$LOCALIZE[79084]'))
					'''---------------------------'''
				elif Ads_Date != datenowS or Ads_Timezone != timezone:
					'''------------------------------
					---SELF-ADS----------------------
					------------------------------'''
					count2 = 0
					while count2 == 0 and returned != "ok2" and not xbmc.abortRequested:
						returned = setMessagesCustom(admin, returned, '2015-06-01', '2015-06-10', "", "", 1)
						'''---------------------------'''
						count2 += 1
						'''---------------------------'''
					if returned != "ok2": setSkinSetting("0",'HomeMessagesCustom', "")
					else:
						xbmc.sleep(1000)
						homemessagescustom = xbmc.getInfoLabel('Skin.String(HomeMessagesCustom)')
						publishL = ['1']
						if homemessagescustom in publishL:
							 returned = "ok"
							 setSkinSetting("0",'MessagesCustom', r1171var)
							 '''---------------------------'''
					
					'''---------------------------'''
					count2S = str(count2)
					if admin: print printfirst + "SELF ADS" + space + "count2S" + space2 + count2S + space + "returned" + space2 + returned
				
				if returned == "skip":
					'''------------------------------
					---NEW-MOVIES--------------------
					------------------------------'''
					returned = setMessagesCustom(admin, returned, '2015-05-11', "2015-05-12", 19, 07, addonString(128).encode('utf-8') % ('[COLOR=Blue]- Furious Seven (2015)[CR]- Kingsman The Secret Service (2014)[/COLOR][CR]- Focus (2015)[CR]- Selma (2014)[CR]- Run All Night (2015)'))
					returned = setMessagesCustom(admin, returned, '2015-05-12', "2015-05-13", 19, 07, addonString(128).encode('utf-8') % ('[COLOR=Blue]- Furious Seven (2015)[CR]- Kingsman The Secret Service (2014)[/COLOR][CR]- Focus (2015)[CR]- Selma (2014)[CR]- Run All Night (2015)'))
					returned = setMessagesCustom(admin, returned, '2015-05-13', "2015-05-14", 19, 07, addonString(128).encode('utf-8') % ('[COLOR=Blue]- Furious Seven (2015)[CR]- Kingsman The Secret Service (2014)[/COLOR][CR]- Focus (2015)[CR]- Selma (2014)[CR]- Run All Night (2015)'))
					returned = setMessagesCustom(admin, returned, '2015-05-14', "2015-05-15", 19, 07, addonString(128).encode('utf-8') % ('[COLOR=Blue]- Furious Seven (2015)[CR]- Kingsman The Secret Service (2014)[/COLOR][CR]- Focus (2015)[CR]- Selma (2014)[CR]- Run All Night (2015)'))
					'''---------------------------'''
					
					'''------------------------------
					---BIG-BRO-----------------------
					------------------------------'''
					returned = setMessagesCustom(admin, returned, '2015-05-11', '2015-05-15', "", "", addonString(127).encode('utf-8'))
					'''---------------------------'''
					
			'''------------------------------
			---PESAH-HOLIDAY-----------------
			------------------------------'''
			#returned = setMessagesCustom(admin, returned, '2015-04-03', '2015-04-09', "", "", addonString(130).encode('utf-8'))
			returned = setMessagesCustom(admin, returned, '2016-04-22', '2016-04-28', "", "", addonString(130).encode('utf-8'))
			returned = setMessagesCustom(admin, returned, '2017-04-10', '2017-04-16', "", "", addonString(130).encode('utf-8'))
			'''---------------------------'''
			
			'''------------------------------
			---Yom-HaShoah-------------------
			------------------------------'''
			#returned = setMessagesCustom(admin, returned, '2015-04-15', '2015-04-16', 19, 21, addonString(150).encode('utf-8'))
			returned = setMessagesCustom(admin, returned, '2016-05-04', '2016-05-05', 19, 21, addonString(150).encode('utf-8'))
			returned = setMessagesCustom(admin, returned, '2017-04-23', '2017-04-24', 19, 21, addonString(150).encode('utf-8'))
			'''---------------------------'''
			
			'''------------------------------
			---Yom-Hazikaron-----------------
			------------------------------'''
			#returned = setMessagesCustom(admin, returned, '2015-04-21', '2015-04-22', 19, 18, addonString(131).encode('utf-8') + '[CR]')
			returned = setMessagesCustom(admin, returned, '2016-05-10', '2016-05-11', 19, 18, addonString(131).encode('utf-8') + '[CR]')
			returned = setMessagesCustom(admin, returned, '2017-04-30', '2017-05-01', 19, 18, addonString(131).encode('utf-8') + '[CR]')
			'''---------------------------'''
			
			'''------------------------------
			---Yom-Ha'atzmaut----------------
			------------------------------'''
			#returned = setMessagesCustom(admin, returned, '2015-04-22', '2015-04-23', 19, 20, addonString(132).encode('utf-8') + '[CR]')
			returned = setMessagesCustom(admin, returned, '2016-05-11', '2016-05-12', 19, 20, addonString(132).encode('utf-8') + '[CR]')
			returned = setMessagesCustom(admin, returned, '2017-05-01', '2017-05-02', 19, 20, addonString(132).encode('utf-8') + '[CR]')
			'''---------------------------'''
			
			'''---------------------------'''
			xbmc.sleep(1000)
			count += 1
			'''---------------------------'''
		else:
			count += 1
			returned = "skip"
	if returned == "skip": setSkinSetting("0",'MessagesCustom', "")
	
	xbmc.sleep(2000)
	'''---------------------------'''
	
def setMessagesCustom(admin, returned, date1, date2, time1, time2, message):
	#import datetime as dt #Can cause a bug with stringtodate!
	printpoint = ""
	if date1 == "" or date2 == "": printpoint = printpoint + "9"
	elif returned != "ok":
		date1D = stringtodate(date1,'%Y-%m-%d')
		datenowD = stringtodate(datenowS,'%Y-%m-%d')
		if "+7" in date2: date2D = date1D + dt.timedelta(days=7)
		else: date2D = stringtodate(date2,'%Y-%m-%d')
		date1 = str(date1D)
		date2 = str(date2D)
		try: messageN = int(message)
		except: messageN = ""
		message = str(message)
		message = '"' + message + '"'
		'''---------------------------'''
		if (datenowD or date1D or date2D) == "error": printpoint + "9"
		elif (datenowD >= date1D and datenowD <= date2D):
			printpoint = printpoint + "2"
			if datenowD == date1D and time1 != "" and timenow3S != "":
				printpoint = printpoint + "3"
				if time1 > timenow3N:
					printpoint = printpoint + "4"
					returned = "skip"
					'''---------------------------'''
				else: returned = 'ok'
			elif datenowD == date2D and time2 != "" and timenow3S != "":
				printpoint = printpoint + "5"
				if time2 < timenow3N:
					printpoint = printpoint + "6"
					returned = "skip"
					'''---------------------------'''
				else: returned = 'ok'
			else: returned = 'ok'	
			if returned == 'ok':
				printpoint = printpoint + "7"
				if messageN == "":
					setSkinSetting("0",'MessagesCustom', message)
					returned = 'ok'
				elif messageN > 0:
					setSkinSetting("0",'HomeMessagesCustom', message)
					returned = 'ok2'
				xbmc.sleep(500)
				'''---------------------------'''
		elif returned != 'ok': printpoint = printpoint + "8"
		else: printpoint = printpoint + "9"
	if ("9" in printpoint or "8" in printpoint) and returned != "ok": returned = "skip"
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "setMessagesCustom_LV" + printpoint + space + "(" + returned + ")" + space + "date1" + space2 + date1 + space + "date2" + space2 + date2 + space + "datenowS" + space2 + datenowS + space + "timenow3S" + space2 + timenow3S
	'''---------------------------'''
	return returned
	'''---------------------------'''

def Clean_Library(admin, type):
	if not systemplatformwindows:
		if type == "1": path = '/storage/.kodi/userdata/library/movies/'
		elif type == "2": path = '/storage/.kodi/userdata/library/tvshows/'
		elif type == "3": path = '/storage/'
		else: path = ""
		
		emptydirs = ""
		count = 0
		'''---------------------------'''
		if path != "":
			subdirectories = os.listdir(path)
			for dir in subdirectories:
				pathdir = path + dir
				if os.path.isdir(pathdir) == True:
					if dir[:1] != ".":
						if os.listdir(pathdir) == []:
							emptydirs = emptydirs + space + dir
							count += 1
							bash('rmdir ' + "'" + pathdir + "'",pathdir)
							'''---------------------------'''
						else:
							pass
							'''---------------------------'''
					else:
						pass
				else:
					pass
					
		countS = str(count)
		if count > 0: notification(addonString(40).encode('utf-8'),addonString(57).encode('utf-8') % (type, countS),"",4000)
		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		print printfirst + "Clean_Library_" + type + space2 + "emptydirs" + space2 + "(" + countS + ")" + space + emptydirs
		if admin: print printfirst + "Clean_Library_" + type + space2 + "pathdir" + space2 + pathdir + space
		'''---------------------------'''
		
	
	
	
'''------------------------------
---CUSTOM------------------------
------------------------------'''
