import xbmc, xbmcgui, xbmcaddon
from variables import *
from shared_modules import *

def testStream(admin, AutoPlay_Pause, AutoPlay_SD, AutoPlay_HD, Current_Dialog, Current_Header, Current_Name, Current_M_T, Current_Source, Current_WatchTime, Current_Year, General_Connected, General_ConnectionScore, General_CountWait, General_CountWaitSelect, General_CustomVAR, General_ScriptON, General_StartWindow):
	'''------------------------------
	---SMOOTH-TRUE/FALSE-------------
	------------------------------'''
	playerhasvideo = xbmc.getCondVisibility('Player.HasVideo')
	playerpaused = xbmc.getCondVisibility('Player.Paused')
	General_ConnectionScoreN = int(General_ConnectionScore)
	#if admin: notification("General_ConnectionScore_2=" + General_ConnectionScore,"","",2000)
	count = 0
	countS = str(count)
	printpoint = ""
	smooth = ""
	if playerpaused: xbmc.executebuiltin('Action(Play)') #TRY TO PREVENT PAUSE OF THIS SERVICE IF CACHE
	xbmc.sleep(200)
	while count < 10 and playerhasvideo and not xbmc.abortRequested:
		if count > 0: xbmc.sleep(500)
		'''------------------------------
		---VARIABLES---------------------
		------------------------------'''
		connected = xbmc.getInfoLabel('Skin.HasSetting(Connected)')
		playerhasvideo = xbmc.getCondVisibility('Player.HasVideo')
		playerpaused = xbmc.getCondVisibility('Player.Paused')
		playercache = xbmc.getInfoLabel('Player.CacheLevel')
		'''---------------------------'''
		if count > 0: xbmc.sleep(500)
		count += 1
		countS = str(count)
		'''---------------------------'''
		if count > 0:
			'''------------------------------
			--APPLY-MANY---------------------
			------------------------------'''	
			if not connected: setGeneral_Connected(connected)
			if smooth == "":
				if not playerpaused: xbmc.executebuiltin('Action(Pause)')
				printpoint = printpoint + "1"
				
			elif smooth == "true":
				'''------------------------------
				--VARIABLES----------------------
				------------------------------'''	
				containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
				istv2 = (xbmc.getInfoLabel('VideoPlayer.TVShowTitle') != "" and xbmc.getInfoLabel('VideoPlayer.Season') != "" and xbmc.getInfoLabel('VideoPlayer.Episode') != "") or ("videodb://tvshows" in containerfolderpath or "library://video/tvshows" in containerfolderpath)
				ismovie2 = (xbmc.getInfoLabel('VideoPlayer.Year') != "" or xbmc.getInfoLabel('VideoPlayer.Country') != "" or xbmc.getInfoLabel('VideoPlayer.Tagline') != "") and not istv2
				#videoplayerhassubtitles = xbmc.getCondVisibility('VideoPlayer.HasSubtitles')
				'''---------------------------'''
				if playerpaused: xbmc.executebuiltin('Action(Play)')
				#if not "2" in printpoint and not videoplayerhassubtitles and (istv2 or ismovie2): xbmc.executebuiltin('ActivateWindow(subtitlesearch)')
				if not "2" in printpoint: setGeneral_ConnectionScore(admin, AutoPlay_Pause, AutoPlay_SD, AutoPlay_HD, Current_Dialog, Current_Header, Current_Name, Current_M_T, Current_Source, Current_WatchTime, Current_Year, General_Connected, General_ConnectionScore, General_CountWait, General_CountWaitSelect, General_CustomVAR, General_ScriptON, General_StartWindow, smooth)
				printpoint = printpoint + "2"
				'''---------------------------'''
				
			elif smooth == "fix":
				if count == 6:
					if playerpaused: xbmc.executebuiltin('Action(Play)')
					if (playercache == "0" or playercache == "1"): xbmc.executebuiltin('Action(FastForward)')
				elif count == 7:
					if (playercache == "0" or playercache == "1"): xbmc.executebuiltin('Action(Rewind)')
				elif count == 8:
					if playerpaused: xbmc.executebuiltin('Action(Play)')
					if (playercache == "0" or playercache == "1"): xbmc.executebuiltin('Action(SmallStepBack)')
				elif count == 9:
					if playercache != '100':
						'''------------------------------
						--SMOOTH-FIX-FALSE---------------
						------------------------------'''	
						smooth = "false"	
						if not "3" in printpoint: setGeneral_ConnectionScore(admin, AutoPlay_Pause, AutoPlay_SD, AutoPlay_HD, Current_Dialog, Current_Header, Current_Name, Current_M_T, Current_Source, Current_WatchTime, Current_Year, General_Connected, General_ConnectionScore, General_CountWait, General_CountWaitSelect, General_CustomVAR, General_ScriptON, General_StartWindow, smooth)
						General_ConnectionScore2N = General_ConnectionScoreN - 1
						printpoint = printpoint + "3"
				printpoint = printpoint + "5"
				'''---------------------------'''
				
		if count == 1:
			'''------------------------------
			--APPLY-ONCE---------------------
			------------------------------'''
			notification(addonString(270),addonString(271),"",2000)
			'''---------------------------'''
		elif smooth != "true" and count > 3 and count < 9 and playercache == '100':
			'''------------------------------
			--SMOOTH-TRUE--------------------
			------------------------------'''	
			smooth = "true"
			count = 7
			notification(addonString(272),addonString(273),"",2000)
			'''---------------------------'''
		elif count == 5 and playercache != '100':
			'''------------------------------
			--SMOOTH-?-----------------------
			------------------------------'''	
			smooth = "fix"
			notification('$LOCALIZE[79505]','$LOCALIZE[31407]',"",10000)
			if playerpaused: xbmc.executebuiltin('Action(Play)')
			'''---------------------------'''
	videoplayerhassubtitles = xbmc.getCondVisibility('VideoPlayer.HasSubtitles')
	videoplayersubtitlesenabled = xbmc.getCondVisibility('VideoPlayer.SubtitlesEnabled')
	if "2" in printpoint:
		printpoint = printpoint + "6"
		if not videoplayerhassubtitles:
			printpoint = printpoint + "6"
			if ((istv2 or ismovie2) or Current_M_T == "0" or Current_M_T == "1"):
				xbmc.executebuiltin('ActivateWindow(subtitlesearch)')
				notification(addonString(123),addonString(124),"",4000)
				'''---------------------------'''
		else:
			if not videoplayersubtitlesenabled: xbmc.executebuiltin('Action(ShowSubtitles)')
	if smooth != "false" and (General_CustomVAR == "6" or General_CustomVAR == "20"): openDialogOK(admin, AutoPlay_Pause, AutoPlay_SD, AutoPlay_HD, AutoPlay2, Current_Dialog, Current_Header, Current_Name, Current_M_T, Current_Source, Current_WatchTime, Current_Year, General_Connected, General_ConnectionScore, General_CountWait, General_CountWaitSelect, General_CustomVAR, General_ScriptON, General_StartWindow)
	'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	playertime = xbmc.getInfoLabel("Player.Time(hh)") + xbmc.getInfoLabel("Player.Time(mm)") + xbmc.getInfoLabel("Player.Time(ss)")
	print printfirst + "testStream_LV" + printpoint + space + "smooth" + space2 + smooth + space + "count" + space2 + countS + "playertime" + space2 + playertime
	if not admin: print printfirst + "testStream" + space + "Current_Name" + space2 + Current_Name + space + "Current_Source" + space2 + Current_Source
	else:
		print printfirst + "testStream-admin" + space + "videoplayerhassubtitles" + space2 + str(videoplayerhassubtitles)
		print printfirst + "VARCHECK" + space2 + "AutoPlay_Pause" + space2 + AutoPlay_Pause + space + "AutoPlay_SD" + space2 + AutoPlay_SD + space + "AutoPlay_HD" + space2 + AutoPlay_HD
		print printfirst + "VARCHECK" + space2 + "Current_Dialog" + space2 + Current_Dialog + space + "Current_Name" + space2 + Current_Name + space + "Current_M_T" + space2 + Current_M_T + space + "Current_Source" + space2 + Current_Source + space + "Current_Year" + space2 + Current_Year
		print printfirst + "VARCHECK" + space2 + "General_Connected" + space2 + General_Connected + space + "General_CountWait" + space2 + General_CountWait + space + "General_ConnectionScore" + space2 + General_ConnectionScore + space + "General_CountWaitSelect" + space2 + General_CountWaitSelect
		print printfirst + "VARCHECK" + space2 + "General_CustomVAR" + space2 + General_CustomVAR + space + "General_ScriptON" + space2 + General_ScriptON + space + "General_StartWindow" + space2 + General_StartWindow
		'''---------------------------'''

def getDialogW(custom):
	'''------------------------------
	---DIALOG-Windows----------------
	------------------------------'''
	Current_Dialog = getsetting('Current_Dialog')
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	dialogbusyW = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
	dialogprogressW = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
	dialogselectW = xbmc.getCondVisibility('Window.IsVisible(DialogSelect.xml)')
	dialogyesnoW = xbmc.getCondVisibility('Window.IsVisible(DialogYesNo.xml)')
	dialogokW = xbmc.getCondVisibility('Window.IsVisible(DialogOK.xml)')
	dialogkaitoastW = xbmc.getCondVisibility('Window.IsVisible(DialogKaiToast.xml)')
	dialogkeyboardW = xbmc.getCondVisibility('Window.IsVisible(DialogKeyboard.xml)')
	dialogsubtitlesW = xbmc.getCondVisibility('Window.IsVisible(DialogSubtitles.xml)')
	videofullscreenW = xbmc.getCondVisibility('Window.IsVisible(VideoFullScreen.xml)')
	'''---------------------------'''
	dialogHeader = ""
	dialogHeaderCustom = ""
	dialogMessage = ""
	dialogMessageCustom = ""
	'''---------------------------'''
	if dialogselectW:
		dialogHeader = xbmc.getInfoLabel('Control.GetLabel(1)') ### Skin.HasSetting(Admin) | !StringCompare(Control.GetLabel(1),Genesis)
		dialogHeaderCustom = xbmc.getInfoLabel('Control.GetLabel(100)') ###CUSTOM
		dialogMessage = ""
		dialogMessageCustom = ""
		returned_Dialog = "dialogselectW"
		'''---------------------------'''
	elif dialogyesnoW:
		dialogHeader = xbmc.getInfoLabel('Control.GetLabel(1)') ###
		dialogHeaderCustom = ""
		dialogMessage = xbmc.getInfoLabel('Control.GetLabel(9)') ###TEXTBOX
		if xbmc.getCondVisibility('!IsEmpty(Control.GetLabel(90))'): dialogMessageCustom = xbmc.getInfoLabel('Control.GetLabel(90)') ###CUSTOM
		else: dialogMessageCustom = ""
		returned_Dialog = "dialogyesnoW"
		'''---------------------------'''
	elif dialogkeyboardW:
		dialogHeader = xbmc.getInfoLabel('Control.GetLabel(311)')
		dialogHeaderCustom = xbmc.getInfoLabel('Control.GetLabel(317)')
		dialogMessage = xbmc.getInfoLabel('Control.GetLabel(312)') ###EDIT
		dialogMessageCustom = "" ###NONE
		returned_Dialog = "dialogkeyboardW"
		'''---------------------------'''
	elif dialogprogressW:
		dialogHeader = xbmc.getInfoLabel('Control.GetLabel(1)')
		dialogHeaderCustom = ""
		dialogMessage = xbmc.getInfoLabel('Control.GetLabel(9)') ###TEXTBOX
		if xbmc.getCondVisibility('Control.IsVisible(90)'): dialogMessageCustom = xbmc.getInfoLabel('Control.GetLabel(90)') ###CUSTOM
		else: dialogMessageCustom = ""
		returned_Dialog = "dialogprogressW"
		'''---------------------------'''
	elif dialogbusyW:
		if xbmc.getCondVisibility('Control.IsVisible(9)'): dialogHeader = xbmc.getInfoLabel('Control.GetLabel(9)') ###NONE
		elif xbmc.getCondVisibility('Control.IsVisible(100)'): dialogHeaderCustom = xbmc.getInfoLabel('Control.GetLabel(100)') ###CUSTOM
		elif xbmc.getCondVisibility('Control.IsVisible(101)'): dialogHeaderCustom = xbmc.getInfoLabel('Control.GetLabel(101)') ###CUSTOM
		dialogMessage = "" ###NONE
		if xbmc.getCondVisibility('!IsEmpty(Control.GetLabel(90))'): dialogMessageCustom = xbmc.getInfoLabel('Control.GetLabel(90)') ###CUSTOM
		returned_Dialog = "dialogbusyW"
		'''---------------------------'''
	elif dialogokW:
		if xbmc.getCondVisibility('Control.IsVisible(1)'): dialogHeader = xbmc.getInfoLabel('Control.GetLabel(1)') ### Skin.HasSetting(Admin) | StringCompare(Control.GetLabel(100),) | StringCompare(Control.GetLabel(1),$LOCALIZE[19240])
		elif xbmc.getCondVisibility('Control.IsVisible(100)'): dialogHeaderCustom = xbmc.getInfoLabel('Control.GetLabel(100)') ###CUSTOM
		if xbmc.getCondVisibility('Control.IsVisible(9)'): dialogMessage = xbmc.getInfoLabel('Control.GetLabel(9)') ###TEXTBOX
		elif xbmc.getCondVisibility('!Control.IsVisible(9)'): dialogMessageCustom = xbmc.getInfoLabel('Control.GetLabel(90)') ###CUSTOM
		returned_Dialog = "dialogokW"
		'''---------------------------'''
	elif dialogsubtitlesW:
		dialogHeader = ""
		dialogHeaderCustom = ""
		dialogMessage = xbmc.getInfoLabel('Container(120).ListItem.Label2') ###FILE NAME
		dialogMessageCustom = xbmc.getInfoLabel('Container(120).ListItem.Label') ###FILE LANGUAGE
		returned_Dialog = "dialogsubtitlesW"
		'''---------------------------'''
	elif videofullscreenW:
		dialogHeader = ""
		dialogHeaderCustom = ""
		dialogMessage = ""
		dialogMessageCustom = ""
		returned_Dialog = "videofullscreenW"
		'''---------------------------'''
	else:
		'''------------------------------
		---NOTHING-SPECIFIC--------------
		------------------------------'''
		dialogHeader = ""
		dialogHeaderCustom = ""
		dialogMessage = ""
		dialogMessageCustom = ""
		returned_Dialog = ""
		'''---------------------------'''
	#elif dialogkaitoastW:
		#if xbmc.getCondVisibility('Control.IsVisible(401)'): dialogHeader = xbmc.getInfoLabel('Control.GetLabel(401)')
		#elif xbmc.getCondVisibility('!Control.IsVisible(401)'): dialogHeaderCustom = xbmc.getInfoLabel('Control.GetLabel(410)')
		#if xbmc.getCondVisibility('Control.IsVisible(402)'): dialogMessage = xbmc.getInfoLabel('Control.GetLabel(402)')
		#elif xbmc.getCondVisibility('Control.IsVisible(420)'): dialogMessageCustom = xbmc.getInfoLabel('Control.GetLabel(420)')
		#returned_Dialog = "dialogkaitoastW"
		#'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if returned_Dialog != "" and admin: print printfirst + "getDialogW" + space2 + "Current_Dialog" + space2 + Current_Dialog + " - " + "returned_Dialog" + space2 + returned_Dialog + space + "dialogHeader" + space2 + dialogHeader + space3 + "dialogHeaderCustom" + space2 + dialogHeaderCustom + space3 + "dialogMessage" + space2 + dialogMessage + space3 + "dialogMessageCustom" + space2 + dialogMessageCustom + space3
	'''---------------------------'''
	
	'''------------------------------
	---RETURN-END--------------------
	------------------------------'''
	if custom == "dialog":
		setsetting_custom1('script.htpt.refresh','Current_Dialog',returned_Dialog)
		return returned_Dialog
		'''---------------------------'''
	elif custom == "header" or custom == "header2":
		returned_Header = dialogHeader
		if returned_Header == "Error occurred": returned_Header = "Sdarot.tv Video"
		if custom == "header":
			setsetting_custom1('script.htpt.refresh','Current_Header',returned_Header)
			setSkinSetting("0",'Current_Header',returned_Header)
		return returned_Header
		'''---------------------------'''
	elif custom == "message":
		returned_Message = dialogMessage
		return returned_Message
		'''---------------------------'''

def setGeneral_TimeZone(General_ScriptON):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	General_TimeZone = getsetting('General_TimeZone')
	timezone = get_timenow(1)
	'''---------------------------'''
	if General_TimeZone != timezone:
		'''------------------------------
		---TIMEZONE-SWIFT----------------
		------------------------------'''
		setsetting_custom1('script.htpt.refresh','General_TimeZone',timezone)
		GenesisSettings("2", "", General_ConnectionScore, General_CustomVAR)
		General_TimeZone2 = getsetting('General_TimeZone')
		
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if General_TimeZone != timezone: print printfirst + "setGeneral_TimeZone" + space2 + General_TimeZone + " - " + General_TimeZone2 + " (" + timezone + " )" + space3

def findvar(what):
	pass

def varfixset(admin, AutoPlay_PauseFIX, AutoPlay_SDFIX, AutoPlay_HDFIX, AutoPlay2FIX, Current_DialogFIX, Current_HeaderFIX, Current_NameFIX, Current_M_TFIX, Current_SourceFIX, Current_WatchTimeFIX, Current_YearFIX, General_ConnectedFIX, General_ConnectionScoreFIX, General_CountWaitFIX, General_CountWaitSelectFIX, General_CustomVARFIX, General_ScriptONFIX, General_StartWindowFIX):
	'''------------------------------
	---VARFIXSET---------------------
	------------------------------'''
	#AutoPlay_Pause = AutoPlay_PauseFIX
	#AutoPlay_SD = AutoPlay_SDFIX
	#AutoPlay_HD = AutoPlay_HDFIX
	AutoPlay2 = AutoPlay2FIX
	Current_Dialog = Current_DialogFIX
	Current_Header = Current_HeaderFIX
	Current_Name = Current_NameFIX
	Current_M_T = Current_M_TFIX
	Current_Source = Current_SourceFIX
	Current_WatchTime = Current_WatchTimeFIX
	Current_Year = Current_YearFIX
	General_Connected = General_ConnectedFIX
	#General_ConnectionScore = General_ConnectionScoreFIX
	General_CountWait = General_CountWaitFIX
	General_CountWaitSelect = General_CountWaitSelectFIX
	General_CustomVAR = General_CustomVARFIX
	General_ScriptON = General_ScriptONFIX
	General_StartWindow = General_StartWindowFIX
	'''---------------------------'''
	#setsetting_custom1('script.htpt.refresh','AutoPlay_Pause',AutoPlay_PauseFIX)
	#setsetting_custom1('script.htpt.refresh','AutoPlay_SD',AutoPlay_SDFIX)
	#setsetting_custom1('script.htpt.refresh','AutoPlay_HD',AutoPlay_HDFIX)
	setsetting_custom1('script.htpt.refresh','Current_Dialog',Current_DialogFIX)
	setsetting_custom1('script.htpt.refresh','Current_Header',Current_HeaderFIX)
	setsetting_custom1('script.htpt.refresh','Current_Name',Current_NameFIX)
	setsetting_custom1('script.htpt.refresh','Current_M_T',Current_M_TFIX)
	setsetting_custom1('script.htpt.refresh','Current_Source',Current_SourceFIX)
	setsetting_custom1('script.htpt.refresh','Current_WatchTime',Current_WatchTimeFIX)
	setsetting_custom1('script.htpt.refresh','Current_Year',Current_YearFIX)
	setsetting_custom1('script.htpt.refresh','General_Connected',General_ConnectedFIX)
	#setsetting_custom1('script.htpt.refresh','General_ConnectionScore',General_ConnectionScoreFIX)
	setsetting_custom1('script.htpt.refresh','General_CountWait',General_CountWaitFIX)
	setsetting_custom1('script.htpt.refresh','General_CountWaitSelect',General_CountWaitSelectFIX)
	setsetting_custom1('script.htpt.refresh','General_CustomVAR',General_CustomVARFIX)
	setsetting_custom1('script.htpt.refresh','General_ScriptON',General_ScriptONFIX)
	setsetting_custom1('script.htpt.refresh','General_StartWindow',General_StartWindowFIX)
	'''---------------------------'''
	if admin: print printfirst + "VARFIXGET2" + space2 + "AutoPlay_Pause" + space2 + AutoPlay_PauseFIX + space + "AutoPlay_SD" + space2 + AutoPlay_SDFIX + space + "AutoPlay_HD" + space2 + AutoPlay_HDFIX + space + "AutoPlay2FIX" + space2 + AutoPlay2FIX
	if admin: print printfirst + "VARFIXGET2" + space2 + "Current_Dialog" + space2 + Current_DialogFIX + space + "Current_Name" + space2 + Current_NameFIX + space + "Current_M_T" + space2 + Current_M_TFIX + space + "Current_Source" + space2 + Current_SourceFIX + space + "Current_Year" + space2 + Current_YearFIX
	if admin: print printfirst + "VARFIXGET2" + space2 + "General_Connected" + space2 + General_ConnectedFIX + space + "General_CountWait" + space2 + General_CountWaitFIX + space + "General_ConnectionScore" + space2 + General_ConnectionScoreFIX + space + "General_CountWaitSelect" + space2 + General_CountWaitSelectFIX
	if admin: print printfirst + "VARFIXGET2" + space2 + "General_CustomVAR" + space2 + General_CustomVARFIX + space + "General_ScriptON" + space2 + General_ScriptONFIX + space + "General_StartWindow" + space2 + General_StartWindowFIX
	'''---------------------------'''
	if admin: print printfirst + "VARFIXSET" + space2 + "AutoPlay_Pause" + space2 + AutoPlay_Pause + space + "AutoPlay_SD" + space2 + AutoPlay_SD + space + "AutoPlay_HD" + space2 + AutoPlay_HD + space + "AutoPlay2" + space2 + AutoPlay2
	if admin: print printfirst + "VARFIXSET" + space2 + "Current_Dialog" + space2 + Current_Dialog + space + "Current_Name" + space2 + Current_Name + space + "Current_M_T" + space2 + Current_M_T + space + "Current_Source" + space2 + Current_Source + space + "Current_Year" + space2 + Current_Year
	if admin: print printfirst + "VARFIXSET" + space2 + "General_Connected" + space2 + General_Connected + space + "General_CountWait" + space2 + General_CountWait + space + "General_ConnectionScore" + space2 + General_ConnectionScore + space + "General_CountWaitSelect" + space2 + General_CountWaitSelect
	if admin: print printfirst + "VARFIXSET" + space2 + "General_CustomVAR" + space2 + General_CustomVAR + space + "General_ScriptON" + space2 + General_ScriptON + space + "General_StartWindow" + space2 + General_StartWindow
	'''---------------------------'''
	
def setGeneral_Refresh(General_ScriptON):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	from variables import getsetting
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	General_Refresh = getsetting('General_Refresh')
	
	if General_ScriptON == "false":
		if General_Refresh != "" and General_Refresh != "false":
			xbmc.executebuiltin('RunScript(script.htpt.refresh,,?mode=3)')
			xbmc.sleep(500)
		elif General_Refresh == "":
			pass
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	General_Refresh2 = getsetting('General_Refresh')
	if admin: print printfirst + "setGeneral_Refresh" + space2 + General_Refresh + " - " + General_Refresh2 + space + "General_ScriptON" + space2 + General_ScriptON
	'''---------------------------'''
	
def setGeneral_StartWindow(General_ScriptON, General_StartWindow):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	from variables import getsetting
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	homeW = xbmc.getCondVisibility('Window.IsVisible(Home.xml)')
	myvideonavW = xbmc.getCondVisibility('Window.IsVisible(MyVideoNav.xml)')
	dialogvideoinfoW = xbmc.getCondVisibility('Window.IsVisible(DialogVideoInfo.xml)')

	if General_ScriptON == "true":
		if dialogvideoinfoW: setsetting_custom1('script.htpt.refresh','General_StartWindow',"2")
		elif myvideonavW: setsetting_custom1('script.htpt.refresh','General_StartWindow',"0")
		elif homeW: setsetting_custom1('script.htpt.refresh','General_StartWindow',"1")
	elif General_ScriptON == "false":
		setsetting_custom1('script.htpt.refresh','General_StartWindow',"")
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	General_StartWindow2 = getsetting('General_StartWindow')
	homeW = str(homeW)
	myvideonavW = str(myvideonavW)
	dialogvideoinfoW = str(dialogvideoinfoW)
	
	if admin: print printfirst + "setGeneral_StartWindow" + space2 + General_StartWindow + " - " + General_StartWindow2 + space3 + "General_ScriptON" + space2 + General_ScriptON + space3 + "myvideonavW/homeW/dialogvideoinfoW" + space2 + myvideonavW + "/" + homeW + "/" + dialogvideoinfoW
	'''---------------------------'''
	
def setCurrent_M_T(General_StartWindow):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
	dialogselectsources3 = xbmc.getInfoLabel('Skin.String(DialogSelectSources3)')
	istv = (xbmc.getInfoLabel('ListItem.TVShowTitle') != "" and xbmc.getInfoLabel('ListItem.Season') != "" and xbmc.getInfoLabel('ListItem.Episode') != "") or ("videodb://tvshows" in containerfolderpath or "library://video/tvshows" in containerfolderpath)
	isisraeltv = xbmc.getCondVisibility('SubString(Container.FolderPath,plugin://plugin.video.sdarot.tv)')
	istvS = str(istv)
	ismovie = (xbmc.getInfoLabel('ListItem.Year') != "" or xbmc.getInfoLabel('ListItem.Country') != "" or xbmc.getInfoLabel('ListItem.Tagline') != "") and not istv
	ismovieS = str(ismovie)
	
	istv4 = " S" in dialogselectsources3 and " E" in dialogselectsources3
	istv4S = str(istv4)
	ismovie4 = " (" in dialogselectsources3 and ")" in dialogselectsources3 and not istv4
	ismovie4S = str(ismovie4)
	'''---------------------------'''
	if General_StartWindow == "0" or General_StartWindow == "2":
		'''------------------------------
		---LIBRARY-----------------------
		------------------------------'''
		if ismovie: setsetting_custom1('script.htpt.refresh','Current_M_T',"0")
		elif istv: setsetting_custom1('script.htpt.refresh','Current_M_T',"1")
		elif isisraeltv: setsetting_custom1('script.htpt.refresh','Current_M_T',"3")
		'''---------------------------'''
		
	elif General_StartWindow == "1":
		'''------------------------------
		---HOME--------------------------
		------------------------------'''
		if ismovie4: setsetting_custom1('script.htpt.refresh','Current_M_T',"0")
		elif istv4: setsetting_custom1('script.htpt.refresh','Current_M_T',"1")
		'''---------------------------'''

	elif General_StartWindow == "":
		'''------------------------------
		---NONE--------------------------
		------------------------------'''
		setsetting_custom1('script.htpt.refresh','Current_M_T',"")
		'''---------------------------'''
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "setCurrent_M_T" + space2 + "ismovieS" + space2 + ismovieS + space + "istvS" + space2 + istvS + space + "istv4S" + space2 + istv4S + space + "ismovie4S" + space2 + ismovie4S + space + "General_StartWindow" + space2 + General_StartWindow + space3
	'''---------------------------'''
			
def topvideoinformation(General_StartWindow,Current_M_T):
	try:
		'''------------------------------
		---VARIABLES---------------------
		------------------------------'''
		'''1=duration , 2=year, 3=rating, 4=poster, 5=plot, 6=genre, 7=tag/episode_info, 8=title, 9=episode thumb '''
		admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
		topvideoinformation1 = xbmc.getInfoLabel('$VAR[TopVideoInformation1]')
		topvideoinformation2 = xbmc.getInfoLabel('$VAR[TopVideoInformation2]')	
		topvideoinformation3 = xbmc.getInfoLabel('$VAR[TopVideoInformation3]')
		topvideoinformation4 = xbmc.getInfoLabel('$VAR[TopVideoInformation4]')
		topvideoinformation5 = '"' + xbmc.getInfoLabel('$VAR[TopVideoInformation5]') + '"'
		topvideoinformation6 = xbmc.getInfoLabel('$VAR[TopVideoInformation6]')
		topvideoinformation7 = xbmc.getInfoLabel('$VAR[TopVideoInformation7]')
		topvideoinformation8 = xbmc.getInfoLabel('$VAR[TopVideoInformation8]')
		topvideoinformation9 = xbmc.getInfoLabel('$VAR[TopVideoInformation9]')
		''''''
		topvideoinformation1a = xbmc.getInfoLabel('Skin.String(TopVideoInformation1)')
		topvideoinformation2a = xbmc.getInfoLabel('Skin.String(TopVideoInformation2)')	
		topvideoinformation3a = xbmc.getInfoLabel('Skin.String(TopVideoInformation3)')
		topvideoinformation4a = xbmc.getInfoLabel('Skin.String(TopVideoInformation4)')
		topvideoinformation5a = xbmc.getInfoLabel('Skin.String(TopVideoInformation5)')
		topvideoinformation6a = xbmc.getInfoLabel('Skin.String(TopVideoInformation6)')
		topvideoinformation7a = xbmc.getInfoLabel('Skin.String(TopVideoInformation7)')
		topvideoinformation8a = xbmc.getInfoLabel('Skin.String(TopVideoInformation8)')
		topvideoinformation9a = xbmc.getInfoLabel('Skin.String(TopVideoInformation9)')
		'''---------------------------'''
		#topvideoinformation5=topvideoinformation5.replace(",","")
		'''---------------------------'''
		admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
		'''---------------------------'''
		if Current_M_T == "0":
			'''------------------------------
			---ismovie-----------------------
			------------------------------'''
			pass
			'''---------------------------'''	
		elif Current_M_T == "1":
			'''------------------------------
			---istv--------------------------
			------------------------------'''
			if General_StartWindow == "0" or General_StartWindow == "2":
				'''------------------------------
				---LIBRARY-----------------------
				------------------------------'''
				if topvideoinformation1 and not topvideoinformation1a: xbmc.executebuiltin('Skin.SetString(TopVideoInformation1, '+ topvideoinformation1 +')')
				if topvideoinformation2 and not topvideoinformation2a: xbmc.executebuiltin('Skin.SetString(TopVideoInformation2, '+ topvideoinformation2 +')')
				if topvideoinformation3 and not topvideoinformation3a: xbmc.executebuiltin('Skin.SetString(TopVideoInformation3, '+ topvideoinformation3 +')')
				if topvideoinformation4 and not topvideoinformation4a: xbmc.executebuiltin('Skin.SetString(TopVideoInformation4, '+ topvideoinformation4 +')')
				if topvideoinformation5 and not topvideoinformation5a: xbmc.executebuiltin('Skin.SetString(TopVideoInformation5, '+ topvideoinformation5 +')')
				if topvideoinformation6 and not topvideoinformation6a: xbmc.executebuiltin('Skin.SetString(TopVideoInformation6, '+ topvideoinformation6 +')')
				if topvideoinformation7 and not topvideoinformation7a: xbmc.executebuiltin('Skin.SetString(TopVideoInformation7, '+ topvideoinformation7 +')')
				if topvideoinformation8 and not topvideoinformation8a: xbmc.executebuiltin('Skin.SetString(TopVideoInformation8, '+ topvideoinformation8 +')')
				#if topvideoinformation9 and not topvideoinformation9a: xbmc.executebuiltin('Skin.SetString(TopVideoInformation9, '+ topvideoinformation9 +')')

		elif Current_M_T == "":
			'''------------------------------
			---NONE--------------------------
			------------------------------'''
			if topvideoinformation8a != topvideoinformation8:
				'''------------------------------
				---STRING vs CURRENT TITLE-------
				------------------------------'''
				if topvideoinformation1a: xbmc.executebuiltin('Skin.SetString(TopVideoInformation1,)')
				if topvideoinformation2a: xbmc.executebuiltin('Skin.SetString(TopVideoInformation2,)')
				if topvideoinformation3a: xbmc.executebuiltin('Skin.SetString(TopVideoInformation3,)')
				if topvideoinformation4a: xbmc.executebuiltin('Skin.SetString(TopVideoInformation4,)')
				if topvideoinformation5a: xbmc.executebuiltin('Skin.SetString(TopVideoInformation5,)')
				if topvideoinformation6a: xbmc.executebuiltin('Skin.SetString(TopVideoInformation6,)')
				if topvideoinformation7a: xbmc.executebuiltin('Skin.SetString(TopVideoInformation7,)')
				if topvideoinformation8a: xbmc.executebuiltin('Skin.SetString(TopVideoInformation8,)')
				if topvideoinformation9a: xbmc.executebuiltin('Skin.SetString(TopVideoInformation9,)')

		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		if admin and Current_M_T == "1": print printfirst + "topvideoinformation5" + space2 + topvideoinformation5 + space + "topvideoinformation4" + space2 + topvideoinformation4
		if admin and Current_M_T == "" and topvideoinformation8a != topvideoinformation8: print printfirst + "topvideoinformation" + space2 + "clear TopVideoInformation"
		elif admin and Current_M_T == "1" and (General_StartWindow == "0" or General_StartWindow == "2"): print printfirst + "topvideoinformation" + space2 + "setting TopVideoInformation" + "(" + General_StartWindow + ") " + space + "topvideoinformation7" + space2 + topvideoinformation7
		elif admin: print printfirst + "topvideoinformation" + space + "EMPTY-ERROR?"
		'''---------------------------'''
	except: print printfirst + "topvideoinformation" + space + "exception_error"

def setDialogSelectSources3(General_StartWindow, General_StartWindow2, Current_M_T, Current_M_T2):
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	listitemseason = xbmc.getInfoLabel('ListItem.Season')
	if listitemseason != "": listitemseasonN = int(listitemseason)
	listitemepisode = xbmc.getInfoLabel('ListItem.Episode')
	if listitemepisode != "": listitemepisodeN = int(listitemepisode)
	listitemtvshowtitle = xbmc.getInfoLabel('ListItem.TVShowTitle')
	listitemtitle = xbmc.getInfoLabel('ListItem.Title')
	listitemyear = xbmc.getInfoLabel('ListItem.Year')
	dialogselectsources3 = xbmc.getInfoLabel('Skin.String(DialogSelectSources3)')
	listitemlabel = xbmc.getInfoLabel('ListItem.Label')
	'''---------------------------'''
	Current_WatchTime = getsetting('Current_WatchTime')
	try: Current_WatchTimeN = int(Current_WatchTime)
	except: Current_WatchTimeN = 0
	result = ""
	printpoint = ""
	'''---------------------------'''
	if Current_M_T != "":
		printpoint = printpoint + "1"
		if General_StartWindow == "0":
			'''------------------------------
			---LIBRARY-----------------------
			------------------------------'''
			if Current_M_T == "0":
				'''------------------------------
				---ismovie-----------------------
				------------------------------'''
				result = listitemtitle + space + "(" + listitemyear + ")"
				#setSkinSetting("0",'DialogSelectSources3',result)
				#xbmc.executebuiltin('Skin.SetString(DialogSelectSources3,'+ result +'')
				printpoint = printpoint + "2"
				'''---------------------------'''	
			elif Current_M_T == "1":
				'''------------------------------
				---istv--------------------------
				------------------------------'''
				if listitemseasonN < 10 and listitemepisodeN < 10: result = listitemtvshowtitle + space + "S0" + listitemseason + space + "E0" + listitemepisode
				elif listitemseasonN < 10 and listitemepisodeN >= 10: result = listitemtvshowtitle + space + "S0" + listitemseason + space + "E" + listitemepisode
				elif listitemseasonN >= 10 and listitemepisodeN < 10: result = listitemtvshowtitle + space + "S" + listitemseason + space + "E0" + listitemepisode
				elif listitemseasonN >= 10 and listitemepisodeN >= 10: result = listitemtvshowtitle + space + "S" + listitemseason + space + "E" + listitemepisode
				else:
					result = ""
					printpoint = printpoint + "3"
				#setSkinSetting("0",'DialogSelectSources3',result)
				#xbmc.executebuiltin('Skin.SetString(DialogSelectSources3,'+ result +'')
				printpoint = printpoint + "4"
				'''---------------------------'''
			elif Current_M_T == "3":
				'''------------------------------
				---isisraeltv--------------------
				------------------------------'''
				result = listitemlabel
				'''---------------------------'''
				
		elif General_StartWindow == "1":
			'''------------------------------
			---HOME--------------------------
			------------------------------'''
			result = dialogselectsources3
			'''---------------------------'''
		elif General_StartWindow == "2":
			'''------------------------------
			---DIALOG-VIDEO-INFO-------------
			------------------------------'''
			result = dialogselectsources3
			'''---------------------------'''
		else: printpoint = printpoint + "6"
	else:
		'''------------------------------
		---Current_M_T==""---------------
		------------------------------'''
		if General_StartWindow2 != "1" and General_StartWindow2 != "2":
			#setSkinSetting("0",'DialogSelectSources3',result)
			#xbmc.executebuiltin('Skin.SetString(DialogSelectSources3,'+ result +'')
			printpoint = printpoint + "7"
			'''---------------------------'''
		else:
			'''------------------------------
			---KEEP-DialogSelectSources3-----
			------------------------------'''
			result = dialogselectsources3
			printpoint = printpoint + "8"
			'''---------------------------'''
			
	setSkinSetting("0",'DialogSelectSources3',result)
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if dialogselectsources3 != result or admin: print printfirst + "setDialogSelectSources3_LV" + printpoint + space2 + dialogselectsources3 + " - " + result + space + "Current_M_T/2" + space2 + Current_M_T + " - " + Current_M_T2 + space + "General_StartWindow" + space2 + General_StartWindow + space + "Current_WatchTime" + space2 + Current_WatchTime + space + "General_CountWaitSelect" + space2 + General_CountWaitSelect
	if admin: print printfirst + "setDialogSelectSources3" + space + "listitemtvshowtitle" + space2 + listitemtvshowtitle + space + "listitemtitle" + space2 + listitemtitle + space
	'''---------------------------'''
	return result
	
def setCurrent_Name(Current_Name2, Current_M_T, Current_M_T2, General_StartWindow, General_StartWindow2, dialogselectsources3):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	dialogselectopen = xbmc.getInfoLabel('Skin.HasSetting(DialogSelectOpen)')
	dialogselectopenS = str(dialogselectopen)
	#dialogselectsources3 = xbmc.getInfoLabel('Skin.String(DialogSelectSources3)')
	AutoPlay_Pause = getsetting('AutoPlay_Pause')
	Current_Name = getsetting('Current_Name')
	Current_Watched = getsetting('Current_Watched')
	Current_WatchTime = getsetting('Current_WatchTime')
	General_CustomVAR = getsetting('General_CustomVAR')
	General_CountWaitSelect = getsetting('General_CountWaitSelect')
	try: General_CountWaitSelectN = int(General_CountWaitSelect)
	except: General_CountWaitSelectN = 0
	Current_WatchTime = getsetting('Current_WatchTime')
	try: Current_WatchTimeN = int(Current_WatchTime)
	except: Current_WatchTimeN = 0
	printpoint = ""
	'''---------------------------'''
	if Current_M_T != "":
		#if AutoPlay_Pause == "false" or (AutoPlay_Pause == "true" and General_CountWaitSelectN > 0):
		'''------------------------------
		---ismovie/istv------------------
		------------------------------'''
		setsetting_custom1('script.htpt.refresh','Current_Name',dialogselectsources3)
		printpoint = printpoint + "1"
		'''---------------------------'''
	elif Current_M_T == "" and Current_Name2 != "":
		'''------------------------------
		---NONE-& Current_Name-----------
		------------------------------'''
		setsetting_custom1('script.htpt.refresh','Current_Name',"")
		printpoint = printpoint + "2"
		if General_CustomVAR != "1" and not dialogselectopen:
			printpoint = printpoint + "3"
			setSkinSetting("0",'DialogSelectSources5',Current_Name2)
			'''---------------------------'''
		if Current_WatchTimeN > 5 and General_CustomVAR != "12":
			'''------------------------------
			---WATCHED-MORE-THEN-5-MINS------
			------------------------------'''
			import datetime as dt
			import time
			datenow = dt.date.today()
			datenowS = str(datenow)
			timenow = dt.datetime.now()
			timenow2 = timenow.strftime("%H:%M")
			timenow2S = str(timenow2)
			printpoint = printpoint + "5"
			'''---------------------------'''	
			if Current_M_T2 == "0":
				'''------------------------------
				---LastMovie_Name----------------
				------------------------------'''
				setsetting_custom1('script.htpt.refresh','LastMovie_Name',Current_Name2)
				setsetting_custom1('script.htpt.refresh','LastMovie_Date',datenowS + space + timenow2S)
				setsetting_custom1('script.htpt.refresh','LastMovie_Watched',Current_Watched)
				setsetting_custom1('script.htpt.refresh','LastMovie_WatchTime',Current_WatchTime)
				'''---------------------------'''	
			elif Current_M_T2 == "1":
				'''------------------------------
				---LastTV_Name-------------------
				------------------------------'''
				setsetting_custom1('script.htpt.refresh','LastTV_Name',Current_Name2)
				setsetting_custom1('script.htpt.refresh','LastTV_Date',datenowS + space + timenow2S)
				setsetting_custom1('script.htpt.refresh','LastTV_Watched',Current_Watched)
				setsetting_custom1('script.htpt.refresh','LastTV_WatchTime',Current_WatchTime)
				'''---------------------------'''
			elif Current_M_T2 == "3":
				'''------------------------------
				---LastIsraeliTV_Name------------
				------------------------------'''
				setsetting_custom1('script.htpt.refresh','LastIsraelTV_Name',Current_Name2)
				setsetting_custom1('script.htpt.refresh','LastIsraelTV_Date',datenowS + space + timenow2S)
				setsetting_custom1('script.htpt.refresh','LastIsraelTV_Watched',Current_Watched)
				setsetting_custom1('script.htpt.refresh','LastIsraelTV_WatchTime',Current_WatchTime)
				'''---------------------------'''	
				
			else: printpoint = printpoint + "9"
				
	else: printpoint = printpoint + "8"
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	Current_Name = getsetting('Current_Name')
	print printfirst + "setCurrent_Name_LV" + printpoint + space2 + "Current_Name/2" + space2 + Current_Name +  " - " + Current_Name2 + space + "Current_M_T/2" + space2 + Current_M_T + " - " + Current_M_T2 + space + "General_StartWindow" + space2 + General_StartWindow + space + "Current_WatchTime" + space2 + Current_WatchTime + space + "AutoPlay_Pause" + space2 + AutoPlay_Pause + space + "General_CountWaitSelect" + space2 + General_CountWaitSelect + space + "General_CustomVAR" + space2 + General_CustomVAR + space + "dialogselectopenS" + space2 + dialogselectopenS
	'''---------------------------'''
	
def setCurrent_Source(admin, Current_Source, Current_M_T, dialogselectsources):
	#Current_Source = getsetting('Current_Source')
	dialogselectsources = xbmc.getInfoLabel('Skin.String(dialogselectsources)')
	printpoint = ""
	'''---------------------------'''
	if Current_M_T != "":
		if dialogselectsources != "":
			'''------------------------------
			---ismovie/istv------------------
			------------------------------'''
			if not "***" in dialogselectsources: #not "***" in dialogselectsources and #addonString_genesis(30408).encode('utf-8')
				setsetting_custom1('script.htpt.refresh','Current_Source',dialogselectsources)
				#setsetting('Current_Source',dialogselectsources)
				setSkinSetting("0",'DialogSelectSources2',dialogselectsources)
				#xbmc.executebuiltin('Skin.SetString(DialogSelectSources2,'+ result +'')
				printpoint = printpoint + "2"
			else:
				setsetting_custom1('script.htpt.refresh','Current_Source',"")
				#setsetting('Current_Source',"")
				setSkinSetting("0",'DialogSelectSources2',"")
				if admin: print printfirst + space + "dialogselectsources" + space2 + dialogselectsources + space + "is actually auto"
				printpoint = printpoint + "3"
				'''---------------------------'''
		else: printpoint = printpoint + "8"
	else:
		printpoint = printpoint + "9"
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	Current_Source2 = getsetting('Current_Source')
	print printfirst + "setCurrent_Source_LV" + printpoint + space2 + "Current_Source/2" + space2 + Current_Source + " / " + Current_Source2 + space + "Current_M_T" + space2 + Current_M_T + space
	'''---------------------------'''
	
def setLast_Source(Current_M_T, Current_M_T2):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	dialogselectopen = xbmc.getInfoLabel('Skin.HasSetting(DialogSelectOpen)')
	dialogselectopenS = str(dialogselectopen)
	dialogselectsources = xbmc.getInfoLabel('Skin.String(DialogSelectSources)')
	'''---------------------------'''
	Current_Source = getsetting('Current_Source')
	Current_WatchTime = getsetting('Current_WatchTime')
	General_CustomVAR = getsetting('General_CustomVAR')
	try: Current_WatchTimeN = int(Current_WatchTime)
	except: Current_WatchTimeN = 0
	printpoint = ""
	'''---------------------------'''
	if Current_M_T == "" and dialogselectsources != "" and General_CustomVAR != "12":
		'''------------------------------
		---SET-LAST-SOURCE---------------
		------------------------------'''
		setsetting_custom1('script.htpt.refresh','Current_Source',"")
		setSkinSetting("0",'DialogSelectSources',"")
		printpoint = printpoint + "4"
		'''---------------------------'''
		if General_CustomVAR != "1" and General_CustomVAR != "11" and not dialogselectopen:
			setSkinSetting("0",'DialogSelectSources2',dialogselectsources)
			printpoint = printpoint + "5"
			'''---------------------------'''
		if Current_WatchTimeN > 5:
			'''------------------------------
			---WATCHED-MORE-THEN-5-MINS------
			------------------------------'''
			if Current_M_T2 == "0":
				'''------------------------------
				---LastMovie_Source----------------
				------------------------------'''
				setsetting_custom1('script.htpt.refresh','LastMovie_Source',dialogselectsources)
				printpoint = printpoint + "6"
				'''---------------------------'''	
			elif Current_M_T2 == "1":
				'''------------------------------
				---LastTV_Source-------------------
				------------------------------'''
				setsetting_custom1('script.htpt.refresh','LastTV_Source',dialogselectsources)
				printpoint = printpoint + "7"
				'''---------------------------'''
			else: print printfirst + "setCurrent_Source" + space + "Error!"
		else: printpoint = printpoint + "8"
	else:
		printpoint = printpoint + "9"
		#setsetting_custom1('script.htpt.refresh','Current_Source',"")
		#setsetting('Current_Source',"")
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	Current_Source2 = getsetting('Current_Source')
	#Current_M_T = getsetting('Current_M_T')
	print printfirst + "setLast_Source_LV" + printpoint + space2 + "Current_Source/2" + space2 + Current_Source + space + Current_Source2 + space + "Current_M_T" + space2 + Current_M_T + " - " + Current_M_T2 + space + "Current_WatchTime" + space2 + Current_WatchTime + space + space + "General_CustomVAR" + space2 + General_CustomVAR + space + "dialogselectopenS" + space2 + dialogselectopenS
	'''---------------------------'''

def setCurrent_Year(General_ScriptON, Current_Name, Current_M_T2):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	listitemyear = xbmc.getInfoLabel('ListItem.Year')
	listitemyear2 = Current_Name[-6:]
	listitemyear2 = str(listitemyear2)
	listitemyear2 = listitemyear2.replace("(","")
	listitemyear2 = listitemyear2.replace(")","")
	listitemyear2len = len(listitemyear2)
	listitemyear2len = str(listitemyear2len)
	Current_Year = getsetting('Current_Year')
	Current_WatchTime = getsetting('Current_WatchTime')
	try: Current_WatchTimeN = int(Current_WatchTime)
	except: Current_WatchTimeN = 0
	'''---------------------------'''
	
	if General_ScriptON == "true":
		'''------------------------------
		---Current_Year-SETUP------------
		------------------------------'''
		if listitemyear != "": setsetting_custom1('script.htpt.refresh','Current_Year',listitemyear)
		elif listitemyear2len == "4": setsetting_custom1('script.htpt.refresh','Current_Year',listitemyear2)
		elif listitemyear2len != "4" and listitemyear2len != "": print printfirst + "listitemyear2len" + " Error " + listitemyear2len
		'''---------------------------'''
	elif General_ScriptON == "false":
		'''------------------------------
		---Current_Year-HISTORY----------
		------------------------------'''
		if Current_Year != "" and Current_WatchTimeN > 5:
			'''------------------------------
			---WATCHED-MORE-THEN-5-MINS------
			------------------------------'''
			if Current_M_T2 == "0":
				'''------------------------------
				---ismovie-----------------------
				------------------------------'''
				setsetting_custom1('script.htpt.refresh','LastMovie_Year',Current_Year)
				'''---------------------------'''
			elif Current_M_T2 == "1":
				'''------------------------------
				---istv--------------------------
				------------------------------'''
				setsetting_custom1('script.htpt.refresh','LastTV_Year',Current_Year)
				'''---------------------------'''
		setsetting_custom1('script.htpt.refresh','Current_Year',"")
		'''---------------------------'''
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin:
		if General_ScriptON == "true": print printfirst + space + "setCurrent_Year" + space2 + "General_ScriptON" + space2 + General_ScriptON + space + "listitemyear2 =" + listitemyear2 + " (" + listitemyear2len + ") " + "listitemyear=" + listitemyear + space + "Current_Name" + space2 + Current_Name
		elif General_ScriptON == "false": print printfirst + space + "setCurrent_Year" + space2 + "General_ScriptON" + space2 + General_ScriptON + space + "Current_Year" + space2 + Current_Year + space + "Current_M_T2" + space2 + Current_M_T2
		
def setLast_Subtitle(Current_M_T,Current_M_T2,Current_Name2):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	from variables import getsetting, addonString
	Current_WatchTime = getsetting('Current_WatchTime')
	try: Current_WatchTimeN = int(Current_WatchTime)
	except: Current_WatchTimeN = 0
	LastMovie_Name = getsetting('LastMovie_Name')
	LastTV_Name = getsetting('LastTV_Name')
	printpoint = ""
	'''---------------------------'''
	Current_Subtitle = getsetting('Current_Subtitle')
	Current_Subtitle1 = getsetting('Current_Subtitle1')
	Current_Subtitle2 = getsetting('Current_Subtitle2')
	Current_Subtitle3 = getsetting('Current_Subtitle3')
	Current_Subtitle4 = getsetting('Current_Subtitle4')
	Current_Subtitle5 = getsetting('Current_Subtitle5')
	Current_Subtitle6 = getsetting('Current_Subtitle6')
	Current_Subtitle7 = getsetting('Current_Subtitle7')
	Current_Subtitle8 = getsetting('Current_Subtitle8')
	Current_Subtitle9 = getsetting('Current_Subtitle9')
	Current_Subtitle10 = getsetting('Current_Subtitle10')
	'''---------------------------'''
	if Current_M_T == "":
		'''------------------------------
		---NONE--------------------------
		------------------------------'''
		setSkinSetting("0",'dialogsubtitles',"")
		setSkinSetting("0",'dialogsubtitles2',"")
		setSkinSetting5("0",'dialogsubtitlesna1',"",'dialogsubtitlesna2',"",'dialogsubtitlesna3',"",'dialogsubtitlesna4',"",'dialogsubtitlesna5',"")
		setSkinSetting5("0",'dialogsubtitlesna6',"",'dialogsubtitlesna7',"",'dialogsubtitlesna8',"",'dialogsubtitlesna9',"",'dialogsubtitlesna10',"")
		'''---------------------------'''
		setsetting_custom1('script.htpt.refresh','Current_Subtitle',"")
		setsetting_custom1('script.htpt.refresh','Current_Subtitle1',"")
		setsetting_custom1('script.htpt.refresh','Current_Subtitle2',"")
		setsetting_custom1('script.htpt.refresh','Current_Subtitle3',"")
		setsetting_custom1('script.htpt.refresh','Current_Subtitle4',"")
		setsetting_custom1('script.htpt.refresh','Current_Subtitle5',"")
		setsetting_custom1('script.htpt.refresh','Current_Subtitle6',"")
		setsetting_custom1('script.htpt.refresh','Current_Subtitle7',"")
		setsetting_custom1('script.htpt.refresh','Current_Subtitle8',"")
		setsetting_custom1('script.htpt.refresh','Current_Subtitle9',"")
		setsetting_custom1('script.htpt.refresh','Current_Subtitle10',"")
		'''---------------------------'''
		printpoint = printpoint + "1"
		
	if Current_M_T2 != "" and Current_Name2 != "" and General_CustomVAR != "12":	
		if Current_WatchTimeN > 5:
			'''------------------------------
			---WATCHED-MORE-THEN-5-MINS------
			------------------------------'''
			printpoint = printpoint + "3"
			if Current_M_T2 == "0":
				'''------------------------------
				---ismovie-----------------------
				------------------------------'''
				if Current_Name2 == LastMovie_Name:
					setsetting_custom1('script.htpt.refresh','LastMovie_Subtitle',Current_Subtitle)
					addonsettings2('script.htpt.refresh','LastMovie_Subtitle1',Current_Subtitle1,'LastMovie_Subtitle2',Current_Subtitle2,'LastMovie_Subtitle3',Current_Subtitle3,'LastMovie_Subtitle4',Current_Subtitle4,'LastMovie_Subtitle5',Current_Subtitle5)
					addonsettings2('script.htpt.refresh','LastMovie_Subtitle6',Current_Subtitle6,'LastMovie_Subtitle7',Current_Subtitle7,'LastMovie_Subtitle8',Current_Subtitle8,'LastMovie_Subtitle9',Current_Subtitle9,'LastMovie_Subtitle10',Current_Subtitle10)
					printpoint = printpoint + "4"
				else:
					print printfirst + "Error" + space2 + "Current_Name2" + space2 + Current_Name2 + " != " + "LastMovie_Name" + space2 + LastMovie_Name + space3
					'''---------------------------'''	
			elif Current_M_T2 == "1":
				'''------------------------------
				---istv--------------------------
				------------------------------'''
				if Current_Name2 == LastTV_Name:
					setsetting_custom1('script.htpt.refresh','LastTV_Subtitle',Current_Subtitle)
					addonsettings2('script.htpt.refresh','LastTV_Subtitle1',Current_Subtitle1,'LastTV_Subtitle2',Current_Subtitle2,'LastTV_Subtitle3',Current_Subtitle3,'LastTV_Subtitle4',Current_Subtitle4,'LastTV_Subtitle5',Current_Subtitle5)
					addonsettings2('script.htpt.refresh','LastTV_Subtitle6',Current_Subtitle6,'LastTV_Subtitle7',Current_Subtitle7,'LastTV_Subtitle8',Current_Subtitle8,'LastTV_Subtitle9',Current_Subtitle9,'LastTV_Subtitle10',Current_Subtitle10)
					printpoint = printpoint + "6"
				else:
					print printfirst + "Error" + space2 + "Current_Name2" + space2 + Current_Name2 + " != " + "LastTV_Name" + space2 + LastTV_Name + space3
					'''---------------------------'''
		else:
			printpoint = printpoint + "8"
			
		
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''	
	if admin: print printfirst + "setLast_Subtitle_LV" + printpoint + space2 + "Current_M_T" + space2 + Current_M_T + "Current_M_T2" + space2 + Current_M_T2 + "Current_Name2" + space2 + Current_Name2 + space + "Current_WatchTime" + space2 + Current_WatchTime
	'''---------------------------'''

def setGeneral_Connected(connectedv2):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	from variables import systemplatformwindows, getsetting, setsetting
	connected = xbmc.getInfoLabel('Skin.HasSetting(Connected)')
	connected2 = xbmc.getInfoLabel('Skin.HasSetting(Connected2)')
	connected3 = xbmc.getInfoLabel('Skin.HasSetting(Connected3)')
	pingnow = xbmc.getInfoLabel('Skin.String(Ping_Now)')
	pingrate = xbmc.getInfoLabel('Skin.String(Ping_Rate)')
	'''---------------------------'''
	General_ScriptON = getsetting('General_ScriptON')
	General_CountWait = getsetting('General_CountWait')
	General_Connected = getsetting('General_Connected')
	General_Connected2 = General_Connected
	'''---------------------------'''
	General_ConnectedN = int(General_Connected)
	printpoint = ""
	try: pingnowN = int(pingnow)
	except: pingnowN = 0
	'''---------------------------'''
	
	printpoint = printpoint + "1"
	if General_ScriptON == "true":
		'''------------------------------
		---General_ScriptON-ON-----------
		------------------------------'''
		printpoint = printpoint + "2"
		if connected2 or connected3:
			'''------------------------------
			---NETWORK-IS-UP-----------------
			------------------------------'''
			printpoint = printpoint + "3"
			if not connected or pingnowN > 500:
				'''------------------------------
				---PING-FAILED-------------------
				------------------------------'''
				printpoint = printpoint + "4"
				if not xbmc.Player().isPlayingVideo(): General_Connected2 = calculate('script.htpt.refresh','General_Connected',"1","")
				elif xbmc.Player().isPlayingVideo(): General_Connected2 = calculate('script.htpt.refresh','General_Connected',"1","")
				'''---------------------------'''
			else:
				'''------------------------------
				---PING-OK-----------------------
				------------------------------'''
				printpoint = printpoint + "5"
				if xbmc.Player().isPlayingVideo() and General_ConnectedN > 0: General_Connected2 = calculate('script.htpt.refresh','General_Connected',"2","")
				'''---------------------------'''
		else:
			'''------------------------------
			---NETWORK-IS-DOWN-----------------
			------------------------------'''
			printpoint = printpoint + "6"
			'''---------------------------'''
				
		'''---------------------------'''		
		General_Connected2N = int(General_Connected2)
		if General_Connected2N > 3: notification(addonString(250),"","",2000)
		'''---------------------------'''
		
		if General_ScriptON == "false": # or (General_Connected2N > 3 and xbmc.Player().isPlayingVideo())
			'''------------------------------
			---General_ScriptON-OFF----------
			------------------------------'''
			printpoint = printpoint + "7"
			setsetting_custom1('script.htpt.refresh','General_Connected',"0")
			General_Connected2 = "0"
		
		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		list = [5,10,15,20,25,30]
		if General_Connected2N > General_ConnectedN and General_Connected2N in list: print printfirst + "setGeneral_Connected_LV" + printpoint + space2 + General_Connected + " - " + General_Connected2 + space3
		'''---------------------------'''
		
def setGeneral_CustomVAR(General_CustomVAR, General_ScriptON, Current_Dialog2, General_CountWait2, AutoPlay2):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	#from variables import systemplatformwindows, getsetting, setsetting
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	connected = xbmc.getInfoLabel('Skin.HasSetting(Connected)')
	dialogselectopen = xbmc.getInfoLabel('Skin.HasSetting(DialogSelectOpen)')
	dialogselectopenS = str(dialogselectopen)
	#dialogselectsources = xbmc.getInfoLabel('Skin.String(DialogSelectSources)')
	networkgatewayaddress = xbmc.getInfoLabel('Network.GatewayAddress')
	networkipaddress = xbmc.getInfoLabel('Network.IPAddress')
	systeminternetstate = xbmc.getInfoLabel('System.InternetState')
	systemidle1 = xbmc.getCondVisibility('System.IdleTime(1)')
	#systemidle3 = xbmc.getCondVisibility('System.IdleTime(3)')
	printpoint = ""
	'''---------------------------'''
	AutoPlay_Pause = getsetting('AutoPlay_Pause')
	#AutoPlay2 = getsetting('AutoPlay2')
	AutoPlay2N = int(AutoPlay2)
	Current_Dialog = getsetting('Current_Dialog')
	Current_Header = getsetting('Current_Header')
	Current_Source = getsetting('Current_Source')
	customvar = xbmc.getInfoLabel('Skin.String(General_CustomVAR)')
	General_ConnectionScore = getsetting('General_ConnectionScore')
	General_ConnectionScoreN = int(General_ConnectionScore)
	General_CountWait = getsetting('General_CountWait')
	General_CountWaitSelect = getsetting('General_CountWaitSelect')
	General_CountWaitSelectN = int(General_CountWaitSelect)
	General_CountWaitN = int(General_CountWait)
	General_Connected = getsetting('General_Connected')
	General_ConnectedN = int(General_Connected)
	General_ConnectedN_ = General_ConnectedN * 7
	General_ConnectedN_S = str(General_ConnectedN_)
	'''---------------------------'''
	
	if General_ScriptON == "false":
		if General_CustomVAR != "" and Current_Dialog == "" and Current_Dialog2 == "":
			'''------------------------------
			---CustomVAR-""------------------
			------------------------------'''
			setsetting_custom1('script.htpt.refresh','General_CustomVAR',"")
			'''---------------------------'''
	elif General_ScriptON == "true":
		if ((Current_Dialog2 == "dialogselectW" and Current_Dialog == "dialogokW") or (dialogselectopen and not systemidle1) or customvar == "1" or General_CustomVAR == "1"): #General_CountWaitSelect == General_CountWait #setGeneral_CustomVAR (dialogselectopen and Current_Dialog == "dialogokW")
			'''------------------------------
			---ACTION-ABORTED-(1)------------
			------------------------------'''
			if dialogselectopen: setsetting_custom1('script.htpt.refresh','General_CustomVAR',"11")
			else: setsetting_custom1('script.htpt.refresh','General_CustomVAR',"1")
			printpoint = printpoint + "1"
			'''---------------------------'''
		elif General_CustomVAR != "1" or Current_Header == "Sdarot.tv Video":
			if not connected:
				'''------------------------------
				---NO-NETWORK-(20)---------------
				------------------------------'''
				setsetting_custom1('script.htpt.refresh','General_CustomVAR',"20")
				'''---------------------------'''
			elif customvar == "12":
				'''------------------------------
				---TRAILER-(12)------------------
				------------------------------'''
				setsetting_custom1('script.htpt.refresh','General_CustomVAR',"12")
				'''---------------------------'''
			elif Current_Header == "Genesis":
				if General_ConnectedN_ > General_CountWaitN and General_ConnectedN > 1:
					'''------------------------------
					---INTERNET-DROP-(6)-------------
					------------------------------'''
					setsetting_custom1('script.htpt.refresh','General_CustomVAR',"6")
					printpoint = printpoint + "6"
					'''---------------------------'''
				elif Current_Dialog == "dialogprogressW" and Current_Dialog2 != "dialogselectW" and Current_Dialog2 != "dialogkeyboardW" and not General_CountWaitSelectN > 0 and Current_Source == "": 
					'''------------------------------
					---SOURCES-NOT-FOUND-(4)---------
					------------------------------'''
					setsetting_custom1('script.htpt.refresh','General_CustomVAR',"4")
					printpoint = printpoint + "4"
					'''---------------------------'''
				elif Current_Dialog == "dialogkeyboardW" or Current_Dialog2 == "dialogkeyboardW":
					'''------------------------------
					---SCREEN-VALIDATION-FAILED-(2)--
					------------------------------'''
					setsetting_custom1('script.htpt.refresh','General_CustomVAR',"2")
					printpoint = printpoint + "2"
					'''---------------------------'''
				
				elif ((Current_Dialog2 == "dialogselectW" and Current_Dialog != "dialogokW" and Current_Source != "") or General_CountWaitN == 1 or (Current_Source != "" and Current_Dialog == "dialogprogressW")):
					'''------------------------------
					---INVALID-SOURCE-(40)-----------
					------------------------------'''
					setsetting_custom1('script.htpt.refresh','General_CustomVAR',"40")
					printpoint = printpoint + "4.0"
					'''---------------------------'''
					
				elif SE_ColorPurple in Current_Source or SE_ColorPurple2 in Current_Source or SE_ColorPurple3 in Current_Source:
					'''------------------------------
					---PAYMENT-SOURCES-(8)-----------
					------------------------------'''
					setsetting_custom1('script.htpt.refresh','General_CustomVAR',"8")
					printpoint = printpoint + "8"
					'''---------------------------'''
					
				elif Current_Dialog == "dialogbusyW" and General_CountWaitN < 5:
					'''------------------------------
					---UNABLE-TO-STREAM-(...)--------
					------------------------------'''
					setsetting_custom1('script.htpt.refresh','General_CustomVAR',"...")
					'''---------------------------'''
					
				elif (General_CountWaitN > 5 and General_CountWaitN < 30):
					if Current_Dialog == "dialogprogressW" or Current_Dialog == "dialogbusyW":
						if SE_ColorGreen in Current_Source or SE_ColorGreen2 in Current_Source or SE_ColorGreen3 in Current_Source or SE_ColorGreen4 in Current_Source:
							'''------------------------------
							---OVERLOADED-HOST-SERVER-(5)----
							------------------------------'''
							setsetting_custom1('script.htpt.refresh','General_CustomVAR',"5")
							printpoint = printpoint + "5"
							'''---------------------------'''
						else:
							'''------------------------------
							---UNABLE-TO-STREAM-(...)--------
							------------------------------'''
							setsetting_custom1('script.htpt.refresh','General_CustomVAR',"...")
							'''---------------------------'''
							
				elif General_CountWaitN > 30 and General_CustomVAR != "3":
					'''------------------------------
					---SLOW-SERVER---(3/5)-----------
					------------------------------'''
					if General_CountWaitN == 40 and (General_ConnectionScoreN < 2 or admin): notification(addonString(239),addonString(248),"",5000)
					if Current_Dialog == "dialogprogressW" and General_ConnectionScoreN < 4 and AutoPlay_Pause == "true":
						xbmc.executebuiltin('Action(Select)')
						xbmc.sleep(1000)
					'''---------------------------'''
					if General_CustomVAR != "5": setsetting_custom1('script.htpt.refresh','General_CustomVAR',"3")
					#elif General_CustomVAR == "5": setsetting_custom1('script.htpt.refresh','General_CustomVAR',"5")
					#xbmc.sleep(200)
			
			elif Current_Header == "Sdarot.tv Video":
				dialogokW = xbmc.getCondVisibility('Window.IsVisible(DialogOK.xml)')
				if xbmc.getCondVisibility('Control.IsVisible(1)'): dialogHeader = xbmc.getInfoLabel('Control.GetLabel(1)') ### Skin.HasSetting(Admin) | StringCompare(Control.GetLabel(100),) | StringCompare(Control.GetLabel(1),$LOCALIZE[19240])
				else: dialogHeader = ""
				'''---------------------------'''
				if dialogHeader == "Error occurred" or systemidle1 or AutoPlay2 != "0":
					if dialogokW: xbmc.executebuiltin('Dialog.Close(12002)') #xbmc.executebuiltin('SendClick(10)')
					xbmc.sleep(200)
					if xbmc.Player().isPlayingVideo() and Current_Dialog == ("videofullscreenW" or ""): pass #setsetting_custom1('script.htpt.refresh','General_CustomVAR',"57")
					
					elif General_CustomVAR == "54": pass
					
					elif AutoPlay2N == 0:
						'''------------------------------
						---Error occurred-(50)-----------
						------------------------------'''
						setsetting_custom1('script.htpt.refresh','General_CustomVAR',"50")
						'''---------------------------'''
						
					elif AutoPlay2N < AutoPlay2MaxN and AutoPlay2N > 0:
						'''------------------------------
						---AutoPlay-IsraelTV-(51)--------
						------------------------------'''
						systemidle3 = xbmc.getCondVisibility('System.IdleTime(3)')
						if AutoPlay2N < 2: setsetting_custom1('script.htpt.refresh','General_CustomVAR',"51")
						elif systemidle3: setsetting_custom1('script.htpt.refresh','General_CustomVAR',"52")
						else:
							setsetting_custom1('script.htpt.refresh','General_CustomVAR',"1")
							notification_common("8")
							'''---------------------------'''
					
					elif AutoPlay2N == -1: #UNUSED
						'''------------------------------
						---Exit-(55)---------------------
						------------------------------'''
						setsetting_custom1('script.htpt.refresh','General_CustomVAR',"55")
						'''---------------------------'''
						
					else:
						'''------------------------------
						---AutoPlay-End-(53)-------------
						------------------------------'''
						setsetting_custom1('script.htpt.refresh','General_CustomVAR',"53")
						'''---------------------------'''
				else:
					printpoint = printpoint + "8"	
			else:
				printpoint = printpoint + "7"
	'''------------------------------
	---RESULT------------------------
	------------------------------'''
	General_CustomVAR2 = getsetting('General_CustomVAR')
	if General_CustomVAR2 != "1": setSkinSetting("0",'General_CustomVAR',General_CustomVAR2)
	if admin and (General_CustomVAR != General_CustomVAR2) or (General_CustomVAR == "" and General_CustomVAR2 == ""): print printfirst + "setGeneral_CustomVAR_LV" + printpoint + space + "Current_Header" + space2 + Current_Header + space + "General_CustomVAR/2" + space2 + General_CustomVAR + " / " + General_CustomVAR2 + space + "Current_Dialog" + space2 + Current_Dialog2 + " - " + Current_Dialog + space + "Current_Header" + space2 + Current_Header + space + "General_ConnectedN_S" + space2 + General_ConnectedN_S + space + "General_ConnectionScore" + space2 + General_ConnectionScore + space + "Current_Source" + space2 + Current_Source + space + "General_CountWait" + space2 + General_CountWait2 + " - " + General_CountWait + space + "General_CountWaitSelect" + space2 + General_CountWaitSelect + space + "dialogselectopenS" + space2 + dialogselectopenS + space + "AutoPlay2" + space2 + AutoPlay2 + space + "AutoPlay2Max" + space2 + AutoPlay2Max
	'''---------------------------'''
	return General_CustomVAR2
	
def setGeneral_CountWait(admin):
	'''---------------------------'''
	General_CountWait2 = calculate('script.htpt.refresh','General_CountWait', "1", "")
	setSkinSetting("0",'General_CountWait',General_CountWait2)
	General_CountWait2N = int(General_CountWait2)
	General_CountWaitN = int(General_CountWait)
	valueN = General_CountWait2N - General_CountWaitN
	'''---------------------------'''

	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin and valueN != 1: print printfirst + "setGeneral_CountWait" + space2 + General_CountWait2 + space + "General_CountWait" + space2 + General_CountWait2
	'''---------------------------'''

def setGeneral_ConnectionScore(admin, AutoPlay_Pause, AutoPlay_SD, AutoPlay_HD, Current_Dialog, Current_Header, Current_Name, Current_M_T, Current_Source, Current_WatchTime, Current_Year, General_Connected, General_ConnectionScore, General_CountWait, General_CountWaitSelect, General_CustomVAR, General_ScriptON, General_StartWindow, smooth):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	from variables import addonString, getsetting, setsetting
	if admin: notification("setGeneral_ConnectionScore=" + General_ConnectionScore,"","",2000)
	General_ConnectionScoreN = int(General_ConnectionScore)
	General_ConnectionScore2 = General_ConnectionScore
	General_ConnectionScore2N = int(General_ConnectionScore2)
	pingrate = xbmc.getInfoLabel('Skin.String(Ping_Rate)')
	#Current_Dialog = getsetting('Current_Dialog')

	#Current_Source = getsetting('Current_Source')
	#General_CustomVAR = getsetting('General_CustomVAR')
	#General_CountWait = getsetting('General_CountWait')
	#AutoPlay_Pause = getsetting('AutoPlay_Pause')
	#AutoPlay_SD = getsetting('AutoPlay_SD')
	#AutoPlay_HD = getsetting('AutoPlay_HD')
	printpoint = ""
	'''---------------------------'''
	
	if not xbmc.Player().isPlayingVideo():
		printpoint = printpoint + "1"
		if Current_Dialog == "dialogokW":
			'''------------------------------
			---REDUCE-NO-VIDEO---------------
			------------------------------'''
			if General_ConnectionScoreN == 5:
				'''------------------------------
				---GENESIS-SETTINGS-RESET--------
				------------------------------'''
				GenesisSettings("0", "", General_ConnectionScore, General_CustomVAR)
				xbmc.sleep(200)
				'''---------------------------'''
			if General_ConnectionScoreN > 2:
				trigger = ["1","11","2","4","5","8","20","40"]
				#if General_CustomVAR != "1" and General_CustomVAR != "2" and General_CustomVAR != "4" and General_CustomVAR != "20" and General_CustomVAR != "8" and General_CustomVAR != "11":
				if General_CustomVAR != "" and not General_CustomVAR in trigger:
					'''------------------------------
					---REDUCE-1----------------------
					------------------------------'''
					calculate('script.htpt.refresh','General_ConnectionScore',"2",General_ConnectionScore)
					General_ConnectionScore2N = General_ConnectionScoreN - 1
					printpoint = printpoint + "2"
					'''---------------------------'''
			else:
				trigger = ["3","6"]
				#if General_CustomVAR != "1" and General_CustomVAR != "2" and General_CustomVAR != "4" and General_CustomVAR != "20" and General_CustomVAR != "8" and General_CustomVAR != "11":
				if General_CustomVAR != "" and General_CustomVAR in trigger and pingrate != "5":
					'''------------------------------
					---REDUCE-2----------------------
					------------------------------'''
					calculate('script.htpt.refresh','General_ConnectionScore',"2",General_ConnectionScore)
					General_ConnectionScore2N = General_ConnectionScoreN - 1
					printpoint = printpoint + "3"
					'''---------------------------'''
	elif xbmc.Player().isPlayingVideo():
		printpoint = printpoint + "5"
		if smooth == "false":
			'''------------------------------
			---REDUCE-VIDEO------------------
			------------------------------'''
			if General_ConnectionScoreN > 0:
				calculate('script.htpt.refresh','General_ConnectionScore',"2",General_ConnectionScore)
				General_ConnectionScore2N = General_ConnectionScoreN -1
				'''---------------------------'''

			trigger = ["3","...","5"]
			if General_CustomVAR in trigger: openDialogOK(admin, AutoPlay_Pause, AutoPlay_SD, AutoPlay_HD, AutoPlay2, Current_Dialog, Current_Header, Current_Name, Current_M_T, Current_Source, Current_WatchTime, Current_Year, General_Connected, General_ConnectionScore, General_CountWait, General_CountWaitSelect, General_CustomVAR, General_ScriptON, General_StartWindow)
			else:
				'''------------------------------
				---NOTIFICATION------------------
				------------------------------'''
				if General_ConnectionScore2N == 0: notification(addonString(225),addonString(227),"",5000) #RESET ROUTER
				elif General_CustomVAR == "5": notification(addonString(235),addonString(234),"",5000) #NITUV LO TAKIN
				elif General_CustomVAR != "5": notification(addonString(233),addonString(236),"",10000) #HOMES BESHART ZEH
				'''---------------------------'''				
			printpoint = printpoint + "6"
			'''---------------------------'''
		elif smooth == "true":	
			'''------------------------------
			---INCREASE---------------------
			------------------------------'''
			if General_ConnectionScoreN < 5:
				calculate('script.htpt.refresh','General_ConnectionScore',"1",General_ConnectionScore)
				General_ConnectionScore2N = General_ConnectionScoreN + 1
				printpoint = printpoint + "7"
				'''---------------------------'''
			else: printpoint = printpoint + "8"
	
	General_ConnectionScore2 = str(General_ConnectionScore2N)
	setSkinSetting("0",'General_ConnectionScore',General_ConnectionScore2)
	if xbmc.Player().isPlayingVideo():
		if General_ConnectionScore2N > 3:
			'''------------------------------
			---FORCE-AutoPlay_Pause=FALSE----
			------------------------------'''
			setsetting_custom1('script.htpt.refresh','AutoPlay_Pause',"false")
			#setSkinSetting("1",'AutoPlay_Pause',"false")
			GenesisSettings("4", "false", General_ConnectionScore2, General_CustomVAR)
			'''---------------------------'''
			
		elif General_ConnectionScore2N <= 3:
			'''------------------------------
			---FORCE-AutoPlay_Pause=TRUE----
			------------------------------'''
			setsetting_custom1('script.htpt.refresh','AutoPlay_Pause',"true")
			#setSkinSetting("1",'AutoPlay_Pause',"true")
			GenesisSettings("4", "true", General_ConnectionScore2, General_CustomVAR)
			'''---------------------------'''
			
	if General_ConnectionScore != General_ConnectionScore2: setsetting_custom1('script.htpt.refresh','General_CurTrigger',"...")
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "setGeneral_ConnectionScore_LV" + printpoint + space2 + General_ConnectionScore + " - " + General_ConnectionScore2 + space + "smooth" + space2 + smooth #if General_ConnectionScore != General_ConnectionScore2
	if admin: print printfirst + "VARCHECK" + space2 + "AutoPlay_Pause" + space2 + AutoPlay_Pause + space + "AutoPlay_SD" + space2 + AutoPlay_SD + space + "AutoPlay_HD" + space2 + AutoPlay_HD
	if admin: print printfirst + "VARCHECK" + space2 + "Current_Dialog" + space2 + Current_Dialog + space + "Current_Name" + space2 + Current_Name + space + "Current_M_T" + space2 + Current_M_T + space + "Current_Source" + space2 + Current_Source + space + "Current_Year" + space2 + Current_Year
	if admin: print printfirst + "VARCHECK" + space2 + "General_Connected" + space2 + General_Connected + space + "General_CountWait" + space2 + General_CountWait + space + "General_ConnectionScore" + space2 + General_ConnectionScore + space + "General_CountWaitSelect" + space2 + General_CountWaitSelect
	if admin: print printfirst + "VARCHECK" + space2 + "General_CustomVAR" + space2 + General_CustomVAR + space + "General_ScriptON" + space2 + General_ScriptON + space + "General_StartWindow" + space2 + General_StartWindow
	'''---------------------------'''

def openDialogOK(admin, AutoPlay_Pause, AutoPlay_SD, AutoPlay_HD, AutoPlay2, Current_Dialog, Current_Header, Current_Name, Current_M_T, Current_Source, Current_WatchTime, Current_Year, General_Connected, General_ConnectionScore, General_CountWait, General_CountWaitSelect, General_CustomVAR, General_ScriptON, General_StartWindow):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	from variables import addonString, getsetting, setsetting
	dialogselectopen = xbmc.getInfoLabel('Skin.HasSetting(DialogSelectOpen)')
	pingrate = xbmc.getInfoLabel('Skin.String(Ping_Rate)')
	try: pingrateN = int(pingrate)
	except: pingrateN = 1
	#Current_Source = getsetting('Current_Source')
	#Current_M_T = getsetting('Current_M_T')
	#Current_Name = getsetting('Current_Name')
	#Current_Year = getsetting('Current_Year')
	#General_Connected = getsetting('General_Connected')
	#General_CountWait = getsetting('General_CountWait')
	connected = xbmc.getInfoLabel('Skin.HasSetting(Connected)')
	connected2 = xbmc.getInfoLabel('Skin.HasSetting(Connected2)')
	connected3 = xbmc.getInfoLabel('Skin.HasSetting(Connected3)')
	#AutoPlay_Pause = getsetting('AutoPlay_Pause')
	#AutoPlay_SD = getsetting('AutoPlay_SD')
	#AutoPlay_HD = getsetting('AutoPlay_HD')
	#General_CustomVAR = getsetting('General_CustomVAR')
	#General_ConnectionScore = getsetting('General_ConnectionScore')
	General_ConnectionScoreN = int(General_ConnectionScore)
	AutoPlay2N = int(AutoPlay2)
	'''---------------------------'''
	#if admin: notification("General_CustomVAR:",General_CustomVAR,"",1000)
	#if not xbmc.Player().isPlayingVideo() or Current_Dialog2 != "videofullscreenW":
	
	if General_CustomVAR == "1":
		'''------------------------------
		---ACTION-ABORTED-(1)------------
		------------------------------'''
		dialogok(addonString(220)," "," ","")
		'''---------------------------'''
	
	elif Current_Header == "Genesis":
		if General_CustomVAR == "11":
			'''------------------------------
			---ACTION-ABORTED-?-(11)---------
			------------------------------'''
			pass
			#dialogok(addonString(220)," "," ","")
			'''---------------------------'''
		
		elif General_CustomVAR == "20":
			'''------------------------------
			---NO-NETWORK-(20)---------------
			------------------------------'''
			dialogok(addonString(250), addonString(251),"","")
			'''---------------------------'''
		
		elif General_CustomVAR == "6":
			'''------------------------------
			---INTERNET-DROP-(6)-------------
			------------------------------'''
			if connected2 and connected3:
				'''------------------------------
				---WLAN-AND-LAN------------------
				------------------------------'''
				dialogok(addonString(241) % (General_Connected, General_CountWait),addonString(242),addonString(243),"")
				'''---------------------------'''
			elif connected2:
				'''------------------------------
				---WLAN--------------------------
				------------------------------'''
				dialogok(addonString(241) % (General_Connected, General_CountWait),addonString(244),addonString(243),"")
				'''---------------------------'''
			elif connected3:
				'''------------------------------
				---LAN---------------------------
				------------------------------'''
				dialogok(addonString(241) % (General_Connected, General_CountWait),addonString(246),addonString(247),addonString(248))
				'''---------------------------'''
			else:
				'''------------------------------
				---WLAN-AND-LAN-DISABLED---------
				------------------------------'''
				dialogok(addonString(251),addonString(245),addonString(243),"")
				'''---------------------------'''
				
		elif General_CustomVAR == "4":
			'''------------------------------
			---SOURCES-NOT-FOUND-(4)---------
			------------------------------'''
			if Current_Source == "" and General_ConnectionScoreN == 0: dialogok(addonString(229),addonString(231)," ","") #No Sources... , 
			elif Current_Year == yearnowS and Current_M_T == "0":
				'''------------------------------
				---ismovie-new-------------------
				------------------------------'''
				if AutoPlay_Pause == "false":
					dialogok(addonString(229),addonString(219),addonString(206),addonString(218)) #No Sources... , Probably new movie., Try again in a few more days , Note: You may try again with Manual Play.
					if (General_CustomVAR == "4" and General_ConnectionScoreN > 3):
						returned = dialogyesno(addonString(213) + addonString(70) + "?",addonString(240)) #Would you like to Cancel Autoplay? , This will allow you to manually choose a source.
						if returned == "ok": xbmc.executebuiltin('RunScript(script.htpt.refresh,,?mode=2)') #setsetting_custom1('script.htpt.refresh','General_CurTrigger',"4")
						else: setsetting_custom1('script.htpt.refresh','General_CurTrigger',"...")
				else:
					dialogok(addonString(229),addonString(219),addonString(206),"") #No Sources... , Probably new movie. , Try again in a few more days
				#elif General_ConnectionScore == "5": dialogok(addonString(229),addonString(219),addonString(200) + " (SD) ",addonString(205)) #No Sources...
			elif Current_Source != "": dialogok(addonString(229),'[COLOR=Red]' + Current_Source + '[/COLOR]',addonString(230),"") #No Sources..., <source>, Try a different host
			elif AutoPlay_Pause == "false": dialogok(addonString(229), addonString(218), space, space) #No Sources..., Note: You may try again with Manual Play.
			else: dialogok(addonString(229),addonString(207),space,space) #No Sources..., Note: This content may remain unavailable.
			'''---------------------------'''
			
		elif General_CustomVAR != "" and AutoPlay_Pause != "true" and (AutoPlay_HD == "true" or AutoPlay_SD == "true") and not xbmc.Player().isPlayingVideo():
			'''------------------------------
			---AUTOPLAY-HD-OFF---------------
			------------------------------'''
			if AutoPlay_HD == "true":
				'''------------------------------
				---AUTOPLAY-SD-ON-----------------
				------------------------------'''
				dialogok(addonString(204) + " (HD) ", addonString(200) + " (SD) ", '[COLOR=Yellow]' + addonString(205) + '[/COLOR]',"")
				'''---------------------------'''
			elif AutoPlay_SD == "true": 
				'''------------------------------
				---MANUALPLAY-ON-----------------
				------------------------------'''
				dialogok(addonString(204) + " (SD) ", addonString(201), '[COLOR=Yellow]' + addonString(205) + '[/COLOR]',"")
				'''---------------------------'''
			elif AutoPlay_HD == "false" and AutoPlay_SD == "false":
				'''------------------------------
				---AUTOPLAY-SD-OFF---------------
				------------------------------'''
				dialogok(addonString(204) + " (SD) ", addonString(202), '[COLOR=Yellow]' + addonString(205) + '[/COLOR]',"")
				'''---------------------------'''
		
		elif General_CustomVAR == "40":
			'''------------------------------
			---INVALID-SOURCE-(40)-----------
			------------------------------'''
			if Current_Source != "": dialogok(addonString(217), '[COLOR=Red]' + Current_Source + '[/COLOR]', addonString(234),"")
			else: print printfirst + space + "openDialogOK" + space2 + "General_CustomVAR40_ERROR!!!"
			
		elif General_CustomVAR == "2":
			'''------------------------------
			---LETTER-VALIDATION-FAILED-(2)--
			------------------------------'''
			dialogok(addonString(222),addonString(223),"","")
			'''---------------------------'''
			
		elif General_ConnectionScore == "0":
			'''------------------------------
			---TURN-ROUTER-OFF-10M-----------
			------------------------------'''
			dialogok(addonString(225),addonString(228),addonString(227),"")
			'''---------------------------'''
			
		elif General_CustomVAR == "5":
			'''------------------------------
			---OVERLOADED-HOST-SERVER-(5)----
			------------------------------'''
			if Current_Source == "":
				'''------------------------------
				---AUTOPLAY-ON-------------------
				------------------------------'''
				if not xbmc.Player().isPlayingVideo():
					'''------------------------------
					---VIDEO-OFF---------------------
					------------------------------'''
					dialogok(addonString(233),"",addonString(214),addonString(252))
					'''---------------------------'''
				else:
					'''------------------------------
					---VIDEO-ON----------------------
					------------------------------'''
					dialogok(addonString(233),"",addonString(253),addonString(238))
					'''---------------------------'''
					
			else:
				'''------------------------------
				---AUTOPLAY-OFF------------------
				------------------------------'''
				if not xbmc.Player().isPlayingVideo():
					'''------------------------------
					---VIDEO-OFF---------------------
					------------------------------'''
					dialogok(addonString(233),'[COLOR=Red]' + Current_Source + '[/COLOR]',addonString(234),"")
					'''---------------------------'''
				else:
					'''------------------------------
					---VIDEO-ON----------------------
					------------------------------'''
					dialogok(addonString(233),'[COLOR=Red]' + Current_Source + '[/COLOR]',addonString(236),addonString(238))
					'''---------------------------'''
					
			'''---------------------------'''
		
		elif General_CustomVAR == "8":
			'''------------------------------
			---PAYMENT-SOURCE-(8)------------
			------------------------------'''
			if Current_Source != "":
				'''------------------------------
				---AUTOPLAY-ON-------------------
				------------------------------'''
				if General_ConnectionScoreN >= 4:
					'''------------------------------
					---FIRST-MESSAGES----------------
					------------------------------'''
					dialogok(addonString(232),'[COLOR=Purple]' + Current_Source + '[/COLOR]',addonString(234),"")
					'''---------------------------'''
				else:
					'''------------------------------
					---SPECIFIC-MESSAGES----------------
					------------------------------'''
					if "REALDEBRID" in Current_Source:
						'''------------------------------
						---REALDEBRID--------------------
						------------------------------'''
						if Account1_Active: dialogok(addonString(232),'[COLOR=Purple]' + Current_Source + '[/COLOR]',addonString(249), "")
						else: dialogok(addonString(232),'[COLOR=Purple]' + Current_Source + '[/COLOR]',addonString(215), addonString(216))
						'''---------------------------'''
						
			elif Current_Source == "": dialogok(addonString(232),addonString(215),addonString(216),"")	
			'''---------------------------'''
			
		elif General_CustomVAR == "...":
			'''------------------------------
			---UNABLE-TO-STREAM-(...)--------
			------------------------------'''
			if Current_Source == "":
				'''------------------------------
				---AUTOPLAY-ON-------------------
				------------------------------'''
				if not xbmc.Player().isPlayingVideo():
					'''------------------------------
					---VIDEO-OFF---------------------
					------------------------------'''
					dialogok(addonString(235),"",addonString(255),addonString(252))
					'''---------------------------'''
				else:
					'''------------------------------
					---VIDEO-ON----------------------
					------------------------------'''
					dialogok(addonString(235),"",addonString(253),addonString(238))
					'''---------------------------'''
			else:
				'''------------------------------
				---AUTOPLAY-OFF------------------
				------------------------------'''
				if not xbmc.Player().isPlayingVideo():
					'''------------------------------
					---VIDEO-OFF---------------------
					------------------------------'''
					dialogok(addonString(235),'[COLOR=Red]' + Current_Source + '[/COLOR]',addonString(234),addonString(254))
					'''---------------------------'''
				else:
					'''------------------------------
					---VIDEO-ON----------------------
					------------------------------'''
					dialogok(addonString(235),'[COLOR=Red]' + Current_Source + '[/COLOR]',addonString(236),addonString(238))
					'''---------------------------'''
				
		elif General_CustomVAR == "3":
			'''------------------------------
			---SLOW-STREAM-------------------
			------------------------------'''
			if General_ConnectionScoreN < 2 or pingrateN < 4:
				'''------------------------------
				---YOUR-INTERNET-----------------
				------------------------------'''
				if Current_Source == "":
					'''------------------------------
					---AUTOPLAY-ON-------------------
					------------------------------'''
					if not xbmc.Player().isPlayingVideo():
						'''------------------------------
						---VIDEO-OFF---------------------
						------------------------------'''
						if General_ConnectionScoreN == 0: dialogok(addonString(225),"",addonString(228),addonString(248))
						elif General_ConnectionScoreN == 1: dialogok(addonString(225),"",addonString(228),"")
						elif pingrateN < 4: dialogok(addonString(225),"",addonString(234),addonString(226))
						'''---------------------------'''
					else:
						'''------------------------------
						---VIDEO-ON---------------------
						------------------------------'''
						if General_ConnectionScoreN == 0: dialogok(addonString(225),"",addonString(228),addonString(248))
						elif General_ConnectionScoreN == 1: dialogok(addonString(225),"",addonString(228),"")
						elif pingrateN < 4: dialogok(addonString(225),"",addonString(236),addonString(226))
						'''---------------------------'''
						
				else:
					'''------------------------------
					---AUTOPLAY-OFF-------------------
					------------------------------'''
					if not xbmc.Player().isPlayingVideo():
						'''------------------------------
						---VIDEO-OFF---------------------
						------------------------------'''
						if General_ConnectionScoreN == 0: dialogok(addonString(225),'[COLOR=Red]' + Current_Source + '[/COLOR]',addonString(228),addonString(248))
						elif General_ConnectionScoreN == 1: dialogok(addonString(225),'[COLOR=Red]' + Current_Source + '[/COLOR]',addonString(228),addonString(238))
						elif pingrateN < 4: dialogok(addonString(225),'[COLOR=Red]' + Current_Source + '[/COLOR]',addonString(234),addonString(226))
						'''---------------------------'''
					else:
						'''------------------------------
						---VIDEO-ON----------------------
						------------------------------'''
						if General_ConnectionScoreN == 0: dialogok(addonString(225),'[COLOR=Red]' + Current_Source + '[/COLOR]',addonString(228),addonString(248))
						elif General_ConnectionScoreN == 1: dialogok(addonString(225),'[COLOR=Red]' + Current_Source + '[/COLOR]',addonString(228),addonString(238))
						elif pingrateN < 4: dialogok(addonString(225),'[COLOR=Red]' + Current_Source + '[/COLOR]',addonString(236),addonString(226))
						'''---------------------------'''
			else:	
				'''------------------------------
				---THE-SPECIFIC-SERVER-----------
				------------------------------'''
				if Current_Source == "":
					'''------------------------------
					---AUTOPLAY-ON-------------------
					------------------------------'''
					if not xbmc.Player().isPlayingVideo():
						'''------------------------------
						---VIDEO-OFF---------------------
						------------------------------'''
						dialogok(addonString(237),addonString(214),addonString(230),addonString(252))
						'''---------------------------'''
					else:
						'''------------------------------
						---VIDEO-ON----------------------
						------------------------------'''
						dialogok(addonString(237),addonString(214),addonString(253),addonString(252))
						'''---------------------------'''
				else:
					'''------------------------------
					---AUTOPLAY-OFF------------------
					------------------------------'''
					if not xbmc.Player().isPlayingVideo():
						'''------------------------------
						---VIDEO-OFF---------------------
						------------------------------'''
						dialogok(addonString(237),'[COLOR=Red]' + Current_Source + '[/COLOR]',addonString(234),addonString(254))
						'''---------------------------'''
						
					else:
						'''------------------------------
						---VIDEO-ON----------------------
						------------------------------'''
						dialogok(addonString(237),'[COLOR=Red]' + Current_Source + '[/COLOR]',addonString(236),addonString(238))
						'''---------------------------'''
	
	elif Current_Header == "Sdarot.tv Video":
		if General_CustomVAR == "50":
			'''------------------------------
			---Error occurred-(50)-----------
			------------------------------'''
			dialogok('[COLOR=Yellow]' + "SDAROT TV" + '[/COLOR]' + '[CR]' + addonString(224), addonString(256),"","")
			'''---------------------------'''
		elif General_CustomVAR == "51":
			'''------------------------------
			---Error occurred-(51)-----------
			------------------------------'''
			dialogok(addonString(208) + space + '[CR]' + '[COLOR=Yellow]' + "SDAROT TV" + '[/COLOR]', addonString(256),"","")
			'''---------------------------'''
		elif General_CustomVAR == "53":
			'''------------------------------
			---Operation-Failed-(53)---------
			------------------------------'''
			dialogok('[COLOR=Yellow]' + "SDAROT TV" + '[/COLOR]' + '[CR]' + addonString(204), addonString(256),"","")
			'''---------------------------'''
			
		elif General_CustomVAR == "59":
			'''------------------------------
			---AutoPlay2-Abort-(59)----------
			------------------------------'''
			dialogok('[COLOR=Yellow]' + "SDAROT TV" + '[/COLOR]' + '[CR]' + addonString(202), " ","","")
			'''---------------------------'''

	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "openDialogOK" + space2 + "General_CustomVAR" + space2 + General_CustomVAR + space + "General_ConnectionScore" + space2 + General_ConnectionScore + space + "AutoPlay_Pause" + space2 + AutoPlay_Pause
	if admin: print printfirst + "VARCHECK" + space2 + "AutoPlay_Pause" + space2 + AutoPlay_Pause + space + "AutoPlay_SD" + space2 + AutoPlay_SD + space + "AutoPlay_HD" + space2 + AutoPlay_HD + space + "AutoPlay2" + space2 + AutoPlay2
	if admin: print printfirst + "VARCHECK" + space2 + "Current_Dialog" + space2 + Current_Dialog + space + "Current_Header" + space2 + Current_Header + space + "Current_Name" + space2 + Current_Name + space + "Current_M_T" + space2 + Current_M_T + space + "Current_Source" + space2 + Current_Source + space + "Current_Year" + space2 + Current_Year
	if admin: print printfirst + "VARCHECK" + space2 + "General_Connected" + space2 + General_Connected + space + "General_CountWait" + space2 + General_CountWait + space + "General_ConnectionScore" + space2 + General_ConnectionScore + space + "General_CountWaitSelect" + space2 + General_CountWaitSelect
	if admin: print printfirst + "VARCHECK" + space2 + "General_CustomVAR" + space2 + General_CustomVAR + space + "General_ScriptON" + space2 + General_ScriptON + space + "General_StartWindow" + space2 + General_StartWindow
	'''---------------------------'''

def setGeneral_CurTrigger(General_ScriptON, General_ConnectionScore, AutoPlay_Pause, General_CustomVAR):
	'''------------------------------
	---TRIGGER-ACTIONS-AFTER-ONOFF---
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	General_CurTrigger = getsetting('General_CurTrigger')
	General_ConnectionScore = getsetting('General_ConnectionScore')
	AutoPlay_Pause = getsetting('AutoPlay_Pause')
	'''---------------------------'''
	if General_CurTrigger == "": pass
	elif General_CurTrigger == "...":
		GenesisSettings("4", AutoPlay_Pause, General_ConnectionScore, General_CustomVAR)
		GenesisSettings("3", AutoPlay_Pause, General_ConnectionScore, General_CustomVAR)
		GenesisSettings("2", AutoPlay_Pause, General_ConnectionScore, General_CustomVAR)
		'''---------------------------'''
	elif General_CurTrigger == "6":
		pass
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	setsetting_custom1('script.htpt.refresh','General_CurTrigger',"")
	General_CurTrigger2 = getsetting('General_CurTrigger')
	if General_CurTrigger != General_CurTrigger2 or admin: print printfirst + "setGeneral_CurTrigger" + space2 + General_CurTrigger + " - " + General_CurTrigger2 + space + "General_ScriptON" + space2 + General_ScriptON + space + "General_ConnectionScore" + space2 + General_ConnectionScore + space + "AutoPlay_Pause" + space2 + AutoPlay_Pause + space + "General_CustomVAR" + space2 + General_CustomVAR
	'''---------------------------'''
	
def RefreshSettings(AutoPlay_Pause, Current_Name, Current_Source, General_ConnectionScore, General_CustomVAR, General_CountWait, General_CountWaitSelect, Current_Header):
	'''------------------------------
	---script.htpt.refresh-----------
	------------------------------'''
	dialogselectsources = xbmc.getInfoLabel('Skin.String(DialogSelectSources)')
	dialogselectsources3 = xbmc.getInfoLabel('Skin.String(DialogSelectSources3)')
	'''---------------------------'''
	
	'''------------------------------
	---General_...-------------------
	------------------------------'''
	#General_Refresh = getsetting('General_Refresh')
	#General_StartWindow = getsetting('General_StartWindow')
	#General_TimeZone = getsetting('General_TimeZone')
	#General_Connected = getsetting('General_Connected')
	'''---------------------------'''
	#General_ScriptON = getsetting('General_ScriptON')
	#setSkinSetting("1",'General_ScriptON',General_ScriptON)
	'''---------------------------'''
	#General_ConnectionScore = getsetting('General_ConnectionScore')
	setSkinSetting("0",'General_ConnectionScore',General_ConnectionScore)
	'''---------------------------'''
	#General_CountWait = getsetting('General_CountWait')
	#General_CountWaitSelect = getsetting('General_CountWaitSelect')
	setSkinSetting("0",'General_CountWait',General_CountWait)
	'''---------------------------'''
	#General_CustomVAR = getsetting('General_CustomVAR')
	customvar = xbmc.getInfoLabel('Skin.String(General_CustomVAR)') ###PREVENT QUICK CANCEL BUG###
	if customvar != "1" and General_CustomVAR != "1" and customvar != "12": setSkinSetting("0",'General_CustomVAR',General_CustomVAR)
	'''------------------------------
	---AUTOPLAY----------------------
	------------------------------'''
	#dialogbusyW = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
	#dialogprogressW = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
	#dialogselectW = xbmc.getCondVisibility('Window.IsVisible(DialogSelect.xml)')
	'''---------------------------'''
	if not dialogselectW and not dialogprogressW and not dialogbusyW:
		GenesisSettings("4", AutoPlay_Pause, General_ConnectionScore, General_CustomVAR)
		GenesisSettings("3", AutoPlay_Pause, General_ConnectionScore, General_CustomVAR)
		GenesisSettings("2", AutoPlay_Pause, General_ConnectionScore, General_CustomVAR)
	#else:
		#AutoPlay_Pause = getsetting('AutoPlay_Pause')
		#AutoPlay_SD = getsetting('AutoPlay_SD')
		#AutoPlay_HD = getsetting('AutoPlay_HD')
	'''---------------------------'''
	
	'''------------------------------
	---Current_...-------------------
	------------------------------'''
	Current_Header = getsetting('Current_Header')
	#Current_M_T = getsetting('Current_M_T')
	#Current_Watched = getsetting('Current_Watched')
	#Current_Name = getsetting('Current_Name')
	setsetting_custom1('script.htpt.refresh','Current_Name',dialogselectsources3)
	#Current_Year = getsetting('Current_Year')
	#Current_Source = dialogselectsources
	setsetting_custom1('script.htpt.refresh','Current_Source',dialogselectsources)
	#Current_Dialog = getsetting('Current_Dialog')
	#Current_Duration = getsetting('Current_Duration')
	#Current_RefreshPoint = getsetting('Current_RefreshPoint')
	'''---------------------------'''
	
	'''------------------------------
	---LastMovie_...-----------------
	------------------------------'''
	#LastMovie_Name = getsetting('LastMovie_Name')
	#LastMovie_Year = getsetting('LastMovie_Year')
	#LastMovie_Source = getsetting('LastMovie_Source')
	'''---------------------------'''
	
	'''------------------------------
	---LastTV_...--------------------
	------------------------------'''
	#LastTV_Name = getsetting('LastTV_Name')
	#LastTV_Year = getsetting('LastTV_Year')
	#LastTV_Source = getsetting('LastTV_Source')
	'''---------------------------'''
	
	'''------------------------------
	---SE_Color...-------------------
	------------------------------'''
	#setsetting_custom1('script.htpt.refresh','SE_ColorRed',"NONE")
	#setSkinSetting("0",'SE_ColorRed',SE_ColorRed)
	#setsetting_custom1('script.htpt.refresh','SE_ColorRed2',"BILLIONUPLOADS")
	#setSkinSetting("0",'SE_ColorRed2',SE_ColorRed2)
	#setsetting_custom1('script.htpt.refresh','SE_ColorRed3',"G2G")
	#setSkinSetting("0",'SE_ColorRed3',SE_ColorRed3)
	'''---------------------------'''
	#setsetting_custom1('script.htpt.refresh','SE_ColorGreen',"ORORO")
	#setSkinSetting("0",'SE_ColorGreen',SE_ColorGreen)
	#setsetting_custom1('script.htpt.refresh','SE_ColorGreen2',"VK")
	#setSkinSetting("0",'SE_ColorGreen2',SE_ColorGreen2)
	#setsetting_custom1('script.htpt.refresh','SE_ColorGreen3',"NONE")
	#setSkinSetting("0",'SE_ColorGreen3',SE_ColorGreen3)
	'''---------------------------'''
	#setsetting_custom1('script.htpt.refresh','SE_ColorPurple',"REALDEBRID")
	#setSkinSetting("0",'SE_ColorPurple',SE_ColorPurple)
	#setsetting_custom1('script.htpt.refresh','SE_ColorPurple2',"NONE")
	#setSkinSetting("0",'SE_ColorPurple2',SE_ColorPurple2)
	#setsetting_custom1('script.htpt.refresh','SE_ColorPurple3',"NONE")
	#setSkinSetting("0",'SE_ColorPurple3',SE_ColorPurple3)
	'''---------------------------'''		
	xbmc.sleep(500) ###For skinsettings to take effect
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "RefreshSettings" + space2 + "AutoPlay_Pause" + space2 + AutoPlay_Pause + space + "General_ScriptON" + space2 + General_ScriptON + space + "General_CustomVAR" + space2 + General_CustomVAR + space + "General_CountWait" + space2 + General_CountWait + space + "Current_Header" + space2 + Current_Header
	'''---------------------------'''
	
def GenesisSettings(custom, AutoPlay_Pause, General_ConnectionScore, General_CustomVAR):
	addon = 'plugin.video.genesis'
	if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
		'''------------------------------
		---plugin.video.genesis----------
		------------------------------'''
		admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
		Account10_Active = xbmc.getInfoLabel('Skin.HasSetting(Account10_Active)')
		autoplaysd = xbmc.getInfoLabel('Skin.HasSetting(AutoPlaySD)')
		General_ScriptON = getsetting('General_ScriptON')
		General_ConnectionScoreN = int(General_ConnectionScore)
		pingrate = xbmc.getInfoLabel('Skin.String(Ping_Rate)')
		try: pingrateN = int(pingrate)
		except: pingrateN = 0
		printpoint = ""
		'''---------------------------'''
		
		if custom == "0" or custom == "ALL":
			'''FIXED'''
			addonsettings2('plugin.video.genesis','appearance',"GOne",'',"",'check_episode_link',"true",'check_library',"false",'check_movie_link',"false") #A-C
			addonsettings2('plugin.video.genesis','downloads',"special://userdata/library/downloads/",'',"",'fanart',"true",'furk_user',"",'furk_password',"") #D-F
			addonsettings2('plugin.video.genesis','',"",'',"",'host_select',"0",'',"",'',"") #G-I
			addonsettings2('plugin.video.genesis','',"",'',"",'',"",'latest_episodes',"1",'',"") #J-L 
			addonsettings2('plugin.video.genesis','movie_downloads',"special://userdata/library/movies/",'movie_library',"special://userdata/library/movies/",'',"",'',"",'',"") #M-O
			addonsettings2('plugin.video.genesis','playback_info',"true",'play_hd',"true",'',"",'',"",'resume_playback',"true") #P-R
			addonsettings2('plugin.video.genesis','',"",'root_movies',"1",'root_episodes_trakt',"0",'root_episodes',"0",'root_calendar',"0") #P-R
			addonsettings2('plugin.video.genesis','service_interval',"0",'service_limit',"false",'service_update',"true",'service_notification',"false",'',"") #S-U
			addonsettings2('plugin.video.genesis','',"",'',"",'subtitles',"true",'sublang1',"Hebrew",'sublang2',"English") #S-U
			addonsettings2('plugin.video.genesis','',"",'trakt_episodes',"false",'tv_library',"special://userdata/library/tvshows/",'tv_downloads',"special://userdata/library/tvshows/",'update_library',"true") #S-U
			addonsettings2('plugin.video.genesis','',"",'',"",'',"",'watched_library',"true",'watched_trakt',"true") #V-W
			addonsettings2('plugin.video.genesis','',"",'',"",'',"",'',"",'',"") #Y-Z
			
			'''HOSTS ON/OFF'''
			if not admin: addonsettings2('plugin.video.genesis','furk',"false",'furk_tv',"false",'noobroom',"false",'noobroom_tv',"false",'g2g',"false")

			'''HOSTS PRIORITY HD'''
			addonsettings2('plugin.video.genesis','hosthd1',"Videomega",'hosthd2',"Sweflix",'hosthd3',"YIFY",'hosthd4',"Muchmovies",'hosthd5',"")
			addonsettings2('plugin.video.genesis','hosthd6',"Movreel",'hosthd7',"VK",'hosthd8',"GVideo",'hosthd9',"",'hosthd10',"")
			addonsettings2('plugin.video.genesis','hosthd11',"",'hosthd12',"",'hosthd13',"",'hosthd14',"",'hosthd15',"")
			addonsettings2('plugin.video.genesis','hosthd16',"",'hosthd17',"",'hosthd18',"",'hosthd19',"",'hosthd20',"")
			
			'''HOSTS PRIORITY SD'''
			addonsettings2('plugin.video.genesis','host1',"Ororo",'host2',"",'host3',"",'host4',"VK",'host5',"Gvideo")
			addonsettings2('plugin.video.genesis','host6',"",'host7',"iShared",'host8',"",'host9',"Bestreams",'host10',"Movreel")
			addonsettings2('plugin.video.genesis','host11',"",'host12',"",'host13',"",'host14',"",'host15',"Streamin")
			addonsettings2('plugin.video.genesis','host16',"",'host17',"Novamov",'host18',"",'host19',"",'host20',"")
			'''---------------------------'''
			printpoint = printpoint + "1"
		
		if custom == "2" or custom == "ALL":
			'''------------------------------
			---ON-TIMEZONE/ACCOUNTS----------
			------------------------------'''
			General_TimeZone = getsetting('General_TimeZone')
			'''---------------------------'''
			'''ACCOUNTS'''
			addonsettings('TRAKT TV', 'plugin.video.genesis', 'Account10_Active', '1', 'trakt_user', 'trakt_password', "", "", "", "")
			addonsettings('MOVREEL', 'plugin.video.genesis', 'Account3_Active', 'Account3_Period', 'movreel_user', 'movreel_password', "", "", "", "")
			addonsettings('REALDEBRID', 'plugin.video.genesis', 'Account1_Active', 'Account1_Period', 'realdedrid_user', 'realdedrid_password', "", "Sun", "A", "")
			if not id40str:
				addonsettings2('plugin.video.genesis','imdb_user',"ur60711363",'',"",'',"",'',"",'',"")
				if not Account4_Active: addonsettings2('plugin.video.genesis','premiumize_user',"",'noobroom_password',"",'',"",'',"",'',"")
				if not Account5_Active: addonsettings2('plugin.video.genesis','noobroom_mail',"",'premiumize_password',"",'',"",'',"",'',"")
				'''---------------------------'''
			if General_TimeZone == "A":
				printpoint = printpoint + "1"
			elif General_TimeZone == "B":
				printpoint = printpoint + "2"
			elif General_TimeZone == "C":
				printpoint = printpoint + "3"
			
			if General_ConnectionScoreN > 3 or pingrateN > 3:
				addonsettings2('plugin.video.genesis','playback_1080p_hosts',"true",'playback_720p_hosts',"true",'playback_captcha',"false",'playback_quality',"0",'',"")
				'''---------------------------'''
			elif General_ConnectionScoreN > 1 and pingrateN > 2:
				addonsettings2('plugin.video.genesis','playback_1080p_hosts',"false",'playback_720p_hosts',"true",'playback_captcha',"true",'playback_quality',"1",'',"")
				'''---------------------------'''
			else:
				addonsettings2('plugin.video.genesis','playback_1080p_hosts',"false",'playback_720p_hosts',"false",'playback_captcha',"false",'playback_quality',"1",'',"")
				'''---------------------------'''
				
		if custom == "3" or custom == "ALL":
			'''------------------------------
			---HOSTS ON/OFF+PRIORITY---------
			------------------------------'''
			if admin:
				notification("GenesisSettings(3): ","Score: " + General_ConnectionScore + " / " + "Pause: " + AutoPlay_Pause,"",2000)
				xbmc.sleep(1000)
			
			if AutoPlay_Pause == "true" or General_ConnectionScoreN < 4 or General_CustomVAR == "4": # or (General_ConnectionScoreN == 4 and not autoplaysd)
				'''------------------------------
				---ALL-MANUAL-(*)-OR-<-3---------
				------------------------------'''
				addonsettings2('plugin.video.genesis','alluc',"true",'alluc_tv',"true",'animeultima_tv',"true",'clickplay_tv',"true",'directdl_tv',"true") #A-C
				addonsettings2('plugin.video.genesis','afdah',"true",'',"",'',"",'',"",'',"") #A-C
				addonsettings2('plugin.video.genesis','directdl_tv',"true",'',"",'einthusan',"true",'',"",'',"") #D-F
				addonsettings2('plugin.video.genesis','',"",'',"",'gvcenter',"true",'gvcenter_tv',"true",'',"") #G-I
				addonsettings2('plugin.video.genesis','icefilms',"true",'icefilms_tv',"true",'',"",'iwatchonline',"true",'iwatchonline_tv',"true") #G-I
				addonsettings2('plugin.video.genesis','',"",'',"",'',"",'',"",'',"") #J-L
				addonsettings2('plugin.video.genesis','merdb',"true",'merdb_tv',"true",'movie25',"true",'movieshd',"true",'',"") #M-O
				addonsettings2('plugin.video.genesis','moviestorm',"true",'moviestorm_tv',"true",'movietube',"true",'movietube_tv',"true",'moviezone',"true") #M-O
				addonsettings2('plugin.video.genesis','',"",'',"",'muchmovies',"true",'',"",'',"") #M-O
				addonsettings2('plugin.video.genesis','onlinemovies',"true",'ororo_tv',"true",'',"",'',"",'',"") #M-O
				addonsettings2('plugin.video.genesis','primewire',"true",'primewire_tv',"true",'',"",'',"",'',"") #P-R
				addonsettings2('plugin.video.genesis','sweflix',"true",'',"",'tvrelease_tv',"true",'',"",'',"") #S-U
				addonsettings2('plugin.video.genesis','vidics',"true",'vidics_tv',"true",'',"",'vkbox',"true",'vkbox_tv',"true") #V-W
				addonsettings2('plugin.video.genesis','watchfree',"true",'watchfree_tv',"true",'watchseries_tv',"true",'wso',"true",'wso_tv',"true") #V-W
				addonsettings2('plugin.video.genesis','',"",'',"",'yify',"true",'yifystream',"true",'yifystream_tv',"true") #X-Z
				printpoint = printpoint + "7"
				'''---------------------------'''
				
			elif AutoPlay_Pause == "false":
				printpoint = printpoint + "1"
				if General_ConnectionScore == "5":
					'''------------------------------
					---HD-ONLY-AUTO-(5)--------------
					------------------------------'''
					addonsettings2('plugin.video.genesis','alluc',"true",'alluc_tv',"false",'animeultima_tv',"false",'clickplay_tv',"true",'directdl_tv',"true") #A-C
					addonsettings2('plugin.video.genesis','afdah',"true",'',"",'',"",'',"",'',"") #A-C
					addonsettings2('plugin.video.genesis','directdl_tv',"true",'',"",'einthusan',"true",'',"",'',"") #D-F
					addonsettings2('plugin.video.genesis','',"",'',"",'gvcenter',"true",'gvcenter_tv',"true",'',"") #G-I
					addonsettings2('plugin.video.genesis','icefilms',"false",'icefilms_tv',"false",'',"",'iwatchonline',"true",'iwatchonline_tv',"true") #G-I
					addonsettings2('plugin.video.genesis','',"",'',"",'',"",'',"",'',"") #J-L
					addonsettings2('plugin.video.genesis','merdb',"false",'merdb_tv',"false",'movie25',"false",'movieshd',"true",'',"") #M-O
					addonsettings2('plugin.video.genesis','moviestorm',"false",'moviestorm_tv',"false",'movietube',"true",'movietube_tv',"true",'moviezone',"true") #M-O
					addonsettings2('plugin.video.genesis','',"",'',"",'muchmovies',"true",'',"",'',"") #M-O
					addonsettings2('plugin.video.genesis','onlinemovies',"true",'ororo_tv',"true",'',"",'',"",'',"") #M-O
					addonsettings2('plugin.video.genesis','primewire',"false",'primewire_tv',"false",'',"",'',"",'',"") #P-R
					addonsettings2('plugin.video.genesis','sweflix',"true",'',"",'tvrelease_tv',"true",'',"",'',"") #S-U
					addonsettings2('plugin.video.genesis','vidics',"false",'vidics_tv',"false",'',"",'vkbox',"true",'vkbox_tv',"true") #V-W
					addonsettings2('plugin.video.genesis','watchfree',"false",'watchfree_tv',"false",'watchseries_tv',"true",'wso',"false",'wso_tv',"false") #V-W
					addonsettings2('plugin.video.genesis','',"",'',"",'yify',"true",'yifystream',"true",'yifystream_tv',"true") #X-Z
					printpoint = printpoint + "2"
					'''---------------------------'''
					
				elif General_ConnectionScore == "4" and autoplaysd:
					'''------------------------------
					---SD-ONLY-AUTO-(4)--------------
					------------------------------'''
					addonsettings2('plugin.video.genesis','alluc',"false",'alluc_tv',"true",'animeultima_tv',"false",'clickplay_tv',"false",'directdl_tv',"true") #A-C
					addonsettings2('plugin.video.genesis','afdah',"false",'',"",'',"",'',"",'',"") #A-C
					addonsettings2('plugin.video.genesis','directdl_tv',"true",'',"",'einthusan',"false",'',"",'',"") #D-F
					addonsettings2('plugin.video.genesis','',"",'',"",'gvcenter',"false",'gvcenter_tv',"false",'',"") #G-I
					addonsettings2('plugin.video.genesis','icefilms',"false",'icefilms_tv',"false",'',"",'iwatchonline',"true",'iwatchonline_tv',"true") #G-I
					addonsettings2('plugin.video.genesis','',"",'',"",'',"",'',"",'',"") #J-L
					addonsettings2('plugin.video.genesis','merdb',"false",'merdb_tv',"false",'movie25',"false",'movieshd',"true",'',"") #M-O
					addonsettings2('plugin.video.genesis','moviestorm',"true",'moviestorm_tv',"true",'movietube',"true",'movietube_tv',"true",'moviezone',"false") #M-O
					addonsettings2('plugin.video.genesis','',"",'',"",'muchmovies',"false",'',"",'',"") #M-O
					addonsettings2('plugin.video.genesis','onlinemovies',"true",'ororo_tv',"true",'',"",'',"",'',"") #M-O
					addonsettings2('plugin.video.genesis','primewire',"false",'primewire_tv',"false",'',"",'',"",'',"") #P-R
					addonsettings2('plugin.video.genesis','sweflix',"false",'',"",'tvrelease_tv',"true",'',"",'',"") #S-U
					addonsettings2('plugin.video.genesis','vidics',"false",'vidics_tv',"false",'',"",'vkbox',"false",'vkbox_tv',"false") #V-W
					addonsettings2('plugin.video.genesis','watchfree',"false",'watchfree_tv',"false",'watchseries_tv',"true",'wso',"false",'wso_tv',"false") #V-W
					addonsettings2('plugin.video.genesis','',"",'',"",'yify',"false",'yifystream',"false",'yifystream_tv',"false") #X-Z
					printpoint = printpoint + "3"
					'''---------------------------'''
				elif General_ConnectionScore == "3":
					'''------------------------------
					---SD-ONLY-AUTO-(3)--------------
					------------------------------'''
					pass
					printpoint = printpoint + "4"
					'''---------------------------'''
				
		if custom == "4" or custom == "ALL":
			'''------------------------------
			---AUTOPLAY-GENERAL--------------
			------------------------------'''
			#if General_ScriptON == "false":	
			if General_ConnectionScore == "5" or (General_ConnectionScore == "4" and not autoplaysd):
				'''------------------------------
				---General_ConnectionScore-5-----
				------------------------------'''
				if AutoPlay_Pause == "true":
					'''------------------------------
					---AutoPlay_Pause-true----------
					------------------------------'''
					addonsettings2('plugin.video.genesis','autoplay',"false",'playback_auto_sd',"false",'autoplay_library',"false",'playback_info',"false",'',"")
					addonsettings2('script.htpt.refresh','',"",'AutoPlay_HD',"true",'AutoPlay_SD',"false",'',"",'',"")
					printpoint = printpoint + "2"
					setSkinSetting("1",'AutoPlay_Pause',"true")
					setSkinSetting("1",'AutoPlay_HD',"true")
					setSkinSetting("1",'AutoPlay_SD',"false")
					'''---------------------------'''
				else:
					'''------------------------------
					---AutoPlay_Pause-false----------
					------------------------------'''
					addonsettings2('plugin.video.genesis','autoplay',"true",'playback_auto_sd',"false",'autoplay_library',"true",'playback_info',"true",'',"")
					addonsettings2('script.htpt.refresh','',"",'AutoPlay_HD',"true",'AutoPlay_SD',"false",'',"",'',"")
					printpoint = printpoint + "3"
					setSkinSetting("1",'AutoPlay_Pause',"false")
					setSkinSetting("1",'AutoPlay_HD',"true")
					setSkinSetting("1",'AutoPlay_SD',"false")
					'''---------------------------'''
					
			elif General_ConnectionScore == "4" and autoplaysd:
				'''------------------------------
				---General_ConnectionScore-4-----
				------------------------------'''
				if AutoPlay_Pause == "true":
					'''------------------------------
					---AutoPlay_Pause-true----------
					------------------------------'''
					addonsettings2('plugin.video.genesis','autoplay',"false",'playback_auto_sd',"true",'autoplay_library',"false",'playback_info',"false",'',"")
					addonsettings2('script.htpt.refresh','',"",'AutoPlay_HD',"false",'AutoPlay_SD',"true",'',"",'',"")
					printpoint = printpoint + "4"
					setSkinSetting("1",'AutoPlay_Pause',"true")
					setSkinSetting("1",'AutoPlay_HD',"false")
					setSkinSetting("1",'AutoPlay_SD',"true")
					'''---------------------------'''
				else:
					'''------------------------------
					---AutoPlay_Pause-false----------
					------------------------------'''
					addonsettings2('plugin.video.genesis','autoplay',"true",'playback_auto_sd',"true",'autoplay_library',"true",'playback_info',"true",'',"")
					addonsettings2('script.htpt.refresh','',"",'AutoPlay_HD',"false",'AutoPlay_SD',"true",'',"",'',"")
					printpoint = printpoint + "5"
					setSkinSetting("1",'AutoPlay_Pause',"false")
					setSkinSetting("1",'AutoPlay_HD',"false")
					setSkinSetting("1",'AutoPlay_SD',"true")
					'''---------------------------'''
					
			elif General_ConnectionScoreN < 4:
				'''------------------------------
				---General_ConnectionScore-0-3---
				------------------------------'''
				'''------------------------------
				---AutoPlay_Pause-true----------
				------------------------------'''
				addonsettings2('plugin.video.genesis','autoplay',"false",'playback_auto_sd',"false",'autoplay_library',"false",'playback_info',"false",'',"")
				addonsettings2('script.htpt.refresh','AutoPlay_Pause',"true",'AutoPlay_HD',"false",'AutoPlay_SD',"false",'',"",'',"")
				printpoint = printpoint + "6"
				setSkinSetting("1",'AutoPlay_Pause',"true")
				setSkinSetting("1",'AutoPlay_HD',"false")
				setSkinSetting("1",'AutoPlay_SD',"false")
				'''---------------------------'''
			if idstr == "finalmakerr" and not admin: setsetting_custom1('script.htpt.refresh','playback_info',"false")
			'''---------------------------'''
		elif custom == "5":
			'''------------------------------
			---AUTOPLAY-FORCE----------------
			------------------------------'''
			if General_ConnectionScoreN < 5:
				'''------------------------------
				---General_ConnectionScore-5-----
				------------------------------'''
				if autoplaysd:
					addonsettings2('plugin.video.genesis','autoplay',"true",'playback_auto_sd',"true",'autoplay_library',"true",'',"",'',"")
					addonsettings2('script.htpt.refresh','AutoPlay_Pause',"false",'AutoPlay_HD',"false",'AutoPlay_SD',"true",'',"",'',"")
					printpoint = printpoint + "9"
					'''---------------------------'''
				else:
					addonsettings2('plugin.video.genesis','autoplay',"true",'playback_auto_sd',"false",'autoplay_library',"true",'',"",'',"")
					addonsettings2('script.htpt.refresh','AutoPlay_Pause',"false",'AutoPlay_HD',"true",'AutoPlay_SD',"false",'',"",'',"")
					printpoint = printpoint + "10"
					'''---------------------------'''
		
		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		if admin: print printfirst + "GenesisSettings" + space3 + custom + space + "( " + General_ConnectionScore + " ) " + "LV_" + printpoint + space + "AutoPlay_Pause" + space2 + AutoPlay_Pause + space + "General_CustomVAR" + space2 + General_CustomVAR
		'''---------------------------'''
		