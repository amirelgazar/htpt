import xbmc, os, subprocess, sys
import xbmcgui, xbmcaddon

from variables import *
from modules import *
from shared_modules3 import get_params

printpoint = ""
'''---------------------------'''
try: params=get_params()
except Exception, TypeError: notification_common("18")
mode=None
'''---------------------------'''
try: mode=int(params["mode"])
except: pass
'''---------------------------'''

if mode == 1:
	'''------------------------------
	---Cancel_Button-----------------
	------------------------------'''
	list = ["1", "3", "20"]
	if not General_CustomVAR in list:
		setsetting_custom1('script.htpt.refresh','General_CustomVAR',"1")
		setSkinSetting("0",'General_CustomVAR',"1")

	General_CustomVAR2 = getsetting('General_CustomVAR')
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "Cancel_Button" + space2 + "General_CustomVAR" + space2 + General_CustomVAR + " - " + General_CustomVAR2
	'''---------------------------'''

elif mode == 2:
	'''------------------------------
	---AutoPlay-Pause----------------
	------------------------------'''
	if AutoPlay_Pause == "false":
		'''------------------------------
		---AutoPlay-PAUSE-ON-------------
		------------------------------'''
		AutoPlay_Pause2 = "true"
		setsetting_custom1('script.htpt.refresh','AutoPlay_Pause',"true")
		setSkinSetting("1",'AutoPlay_Pause',"true")
		addonsettings2('plugin.video.genesis','autoplay',"false",'',"",'autoplay_library',"false",'playback_info',"true",'',"")
		if not xbmc.Player().isPlayingVideo():
			if AutoPlay_HD == "true": notification(addonString(202).encode('utf-8') + " (HD) ","","",2000)
			elif AutoPlay_SD == "true": notification(addonString(202).encode('utf-8') + " (SD) ","","",2000)
			'''---------------------------'''
			
	elif AutoPlay_Pause == "true":
		'''------------------------------
		---AutoPlay-PAUSE-OFF------------
		------------------------------'''
		AutoPlay_Pause2 = "false"
		setsetting_custom1('script.htpt.refresh','AutoPlay_Pause',"false")
		setSkinSetting("1",'AutoPlay_Pause',"false")
		addonsettings2('plugin.video.genesis','autoplay',"true",'',"",'autoplay_library',"true",'playback_info',"false",'',"")
		if not xbmc.Player().isPlayingVideo():
			if AutoPlay_HD == "true": notification(addonString(200).encode('utf-8') + " (HD) ","","",1000)
			elif AutoPlay_SD == "true": notification(addonString(200).encode('utf-8') + " (SD) ","","",1000)
			else:
				notification(addonString(200) + " (HD) ","","",1000)
				addonsettings2('plugin.video.genesis','playback_auto_sd',"false",'',"",'',"",'',"",'',"")
				'''---------------------------'''
		if admin3 or id40str: setsetting_custom1('script.htpt.refresh','playback_info',"true")
		
	if autoplaypausebutton:
		if homeW: xbmc.executebuiltin('Action(Down)')
		elif myvideonavW: xbmc.executebuiltin('Action(Right)')
	
	GenesisSettings("3", AutoPlay_Pause2, General_ConnectionScore, General_CustomVAR)
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "AutoPlay_PauseButton" + space2 + "AutoPlay_Pause" + space2 + AutoPlay_Pause + " - " + AutoPlay_Pause2 + space3
	'''---------------------------'''

elif mode == 3:
	'''------------------------------
	---Refresh-----------------------
	------------------------------'''
	printpoint = ""
	General_Refresh2 = getsetting('General_Refresh')
	homeW = xbmc.getCondVisibility('Window.IsVisible(Home.xml)')
	myvideonavW = xbmc.getCondVisibility('Window.IsVisible(MyVideoNav.xml)')
	setsetting_custom1('script.htpt.refresh','General_Refresh',"")
	setsetting_custom1('script.htpt.refresh','General_StartWindow',"")
	GenesisSettings("0", "", General_ConnectionScore, General_CustomVAR)
	'''---------------------------'''
	
	if General_Refresh == "0":
		'''------------------------------
		---ismovie-----------------------
		------------------------------'''
		printpoint = printpoint + "1"
		if not myvideonavW: xbmc.executebuiltin('ActivateWindow(Videos,MovieTitles)')
		xbmc.executebuiltin('Notification($LOCALIZE[79067] $LOCALIZE[71030],$LOCALIZE[31407],5000)')
		'''---------------------------'''
		
	elif refreshbutton or General_Refresh == "1":
		'''------------------------------
		---istv--------------------------
		------------------------------'''
		printpoint = printpoint + "2"
		if not myvideonavW: xbmc.executebuiltin('ActivateWindow(VideoLibrary,TVShowTitles)')
		xbmc.executebuiltin('Notification($LOCALIZE[79067] $LOCALIZE[73120],$LOCALIZE[31407],5000)')
		'''---------------------------'''
		
	'''------------------------------
	---MYVIDEO-NAV-------------------
	------------------------------'''
	count = 0
	while count < 10 and not myvideonavW and not xbmc.abortRequested:
		count += 1
		xbmc.sleep(200)
		myvideonavW = xbmc.getCondVisibility('Window.IsVisible(MyVideoNav.xml)')
		'''---------------------------'''
	#xbmc.sleep(500)
	
	xbmc.executebuiltin('Container.Refresh')
	xbmc.sleep(1000)
	xbmc.executebuiltin('RunScript(script.htpt.widgets)')
	xbmc.sleep(3000)
	xbmc.executebuiltin('Notification($LOCALIZE[653]. ,$LOCALIZE[31407],2000)')
	if "C" in id10str or "D" in id10str: xbmc.sleep(1000)
	'''---------------------------'''
	
	if General_StartWindow == "1" or refreshbutton:
		'''------------------------------
		---HOME--------------------------
		------------------------------'''
		printpoint = printpoint + "3"
		homeW = xbmc.getCondVisibility('Window.IsVisible(Home.xml)')
		xbmc.sleep(1200)
		xbmc.executebuiltin('Notification($LOCALIZE[653].. ,$LOCALIZE[31407],2000)')
		xbmc.executebuiltin('ReplaceWindow(0)')
		count = 0
		while count < 10 and not homeW and not xbmc.abortRequested:
			count += 1
			xbmc.sleep(200)
			homeW = xbmc.getCondVisibility('Window.IsVisible(Home.xml)')
			if count == 3: xbmc.executebuiltin('ReplaceWindow(Home.xml)') #NEW
			'''---------------------------'''
		
		xbmc.sleep(500)
		
		if (refreshbutton or General_Refresh == "1") and homeW:
			'''------------------------------
			---HOME--------------------------
			------------------------------'''
			printpoint = printpoint + "4"
			xbmc.executebuiltin('Control.SetFocus(2)')
			xbmc.executebuiltin('Action(Up)')
			xbmc.executebuiltin('Action(Up)')
			'''---------------------------'''
			
		elif General_Refresh == "0":
			'''------------------------------
			---ismovie-----------------------
			------------------------------'''
			printpoint = printpoint + "5"
			xbmc.executebuiltin('Control.SetFocus(1)')
			xbmc.executebuiltin('Action(Up)')
			xbmc.executebuiltin('Action(Up)')
			'''---------------------------'''
			
	if General_StartWindow == "1":
		'''------------------------------
		---HOME--------------------------
		------------------------------'''
		printpoint = printpoint + "6"
		xbmc.sleep(1000)
		xbmc.executebuiltin('Notification($LOCALIZE[653]... ,$LOCALIZE[31407],1000)')
		dialogselectsources3 = xbmc.getInfoLabel('Skin.String(DialogSelectSources3)')
		dialogselectsources5 = xbmc.getInfoLabel('Skin.String(DialogSelectSources5)')
		'''---------------------------'''
		if dialogselectsources3 == dialogselectsources5:
			'''------------------------------
			---TRIGGER-REFRESH2--------------
			------------------------------'''
			xbmc.executebuiltin('Control.SetFocus(9092)')
			xbmc.executebuiltin('Action(Select)')
			printpoint = printpoint + "7"
	
	RefreshSettings(AutoPlay_Pause, Current_Name, Current_Source, General_ConnectionScore, General_CustomVAR, General_CountWait, General_CountWaitSelect, Current_Header)
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "Refresh_Button_LV" + printpoint + space + "General_Refresh" + space2 + General_Refresh + space + "General_StartWindow" + space2 + General_StartWindow + space + "General_Refresh2" + space2 + General_Refresh2 + space + "dialogselectsources3/5" + space2 + dialogselectsources3 + space4 + dialogselectsources5
	'''---------------------------'''

elif mode == 5:
	'''------------------------------
	---Download-Button---------------
	------------------------------'''
	#if General_ScriptON != "true":
	name = 'Download-Button'
	
	notification_common("2")
	setsetting_custom1('plugin.video.genesis','host_select',"1")
	if AutoPlay_Pause == "false":
		xbmc.executebuiltin('RunScript(script.htpt.refresh,,?mode=2)')
		printpoint = printpoint + "A"
		
	count = 0
	while count < 10 and AutoPlay_Pause != "true" and not xbmc.abortRequested:
		count += 1
		xbmc.sleep(100)
		AutoPlay_Pause = getsetting('AutoPlay_Pause')
		xbmc.sleep(100)
		if count == 1: printpoint = printpoint + "B"
		'''---------------------------'''
	
	xbmc.sleep(500)
	#xbmc.executebuiltin('RunScript(plugin.video.genesis,,?action=downloader)')
	
	#xbmc.executebuiltin('RunScript(plugin.video.genesis,,?action=root_movies)')
	#xbmc.executebuiltin('RunPlugin(plugin.video.genesis,,?action=movies_popular)')
	#xbmc.executebuiltin('RunScript(plugin.video.genesis,,?action=addPlayableItem)')
	#plugin://plugin.video.genesis/?action=movies_popular
	#xbmc.executebuiltin('ReloadSkin()')
	xbmc.executebuiltin('Container.Update(containerfolderpath)')
	xbmc.sleep(2000)
	#returned = ActivateWindow("1", 'plugin.video.genesis', containerfolderpath, "", wait=True)
	#if 'ok' in returned: xbmc.executebuiltin('Action(Select)')
	
	count = 0 ; systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl') ; action = "" ; container57position2 = xbmc.getInfoLabel('Container(57).Position')
	while count < 10 and (count < 2 or not listitemlabel in systemcurrentcontrol) and ((count < 2 or systemidle3) or admin) and not xbmc.abortRequested:
		printpoint = printpoint + "0"
		count += 1
		container57position2 = xbmc.getInfoLabel('Container(57).Position')
		
		if container57position2 == container57position:
			printpoint = printpoint + "7"
			count = 20
		elif container57position2 in line_57_1L:
			printpoint = printpoint + "1"
			if container57position in line_57_1L:
				if int(container57position) > int(container57position2): action = 'Action(Right)'
				else: action = 'Action(Left)'
			elif container57position in line_57_2L: action = 'Action(Down)'
			elif container57position in line_57_3L: action = 'Action(Down)'
			elif container57position in line_57_4L: action = 'Action(Down)'
			'''---------------------------'''
		elif container57position2 in line_57_2L:
			printpoint = printpoint + "2"
			if container57position in line_57_2L:
				if int(container57position) > int(container57position2): action = 'Action(Right)'
				else: action = 'Action(Left)'
			elif container57position in line_57_3L: action = 'Action(Down)'
			elif container57position in line_57_4L: action = 'Action(Down)'
			elif container57position in line_57_1L: action = 'Action(Up)'
			'''---------------------------'''
		elif container57position2 in line_57_3L:
			printpoint = printpoint + "3"
			if container57position in line_57_3L:
				if int(container57position) > int(container57position2): action = 'Action(Right)'
				else: action = 'Action(Left)'
			elif container57position in line_57_4L: action = 'Action(Down)'
			elif container57position in line_57_1L: action = 'Action(Up)'
			elif container57position in line_57_2L: action = 'Action(Up)'
			'''---------------------------'''
		elif container57position2 in line_57_4L:
			printpoint = printpoint + "4"
			if container57position in line_57_4L:
				if int(container57position) > int(container57position2): action = 'Action(Right)'
				else: action = 'Action(Left)'
			elif container57position in line_57_1L: action = 'Action(Up)'
			elif container57position in line_57_2L: action = 'Action(Up)'
			elif container57position in line_57_3L: action = 'Action(Up)'
			'''---------------------------'''
		
		findin_systemcurrentcontrol("1",listitemlabel,100,action,'')
		systemidle3 = xbmc.getCondVisibility('System.IdleTime(3)')
	
	if "7" in printpoint: #count < 10 or count == 20
		printpoint = printpoint + "E"
		xbmc.executebuiltin('Action(Select)')
		
		setSkinSetting("0", 'General_CustomVAR', "13")
		setSkinSetting("0", 'DialogSelectSources3', listitemlabel)
		xbmc.sleep(2000)
		count = 0 ; dialogprogressW = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)') ; dialogbusyW = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
		while count < 20 and (dialogprogressW or dialogbusyW) and not xbmc.abortRequested:
			count += 1
			xbmc.sleep(1000)
			dialogprogressW = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
			dialogbusyW = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
			if count == 1: printpoint = printpoint + "F"
			'''---------------------------'''
		if count == 20: notification_common("11")
		else:
			printpoint = printpoint + "G"
			count = 0 ; containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
			while count < 10 and not "plugin://plugin.video.genesis/?action=addPlayableItem" in containerfolderpath and not xbmc.abortRequested:
				count += 1
				xbmc.sleep(200)
				containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
				'''---------------------------'''
			if count < 10:
				printpoint = printpoint + "7"
				dialogok('$LOCALIZE[79072]', '$LOCALIZE[74433]', '$LOCALIZE[75207]', '$LOCALIZE[75208]')
				
				count = 0
				containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
				while count < 10 and "plugin://plugin.video.genesis/?action=addPlayableItem" in containerfolderpath and not xbmc.abortRequested:
					count += 1
					containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
					dialogcontextmenuW = xbmc.getCondVisibility('Window.IsVisible(DialogContextMenu.xml)')
					xbmc.sleep(1000)
					if dialogcontextmenuW:
						notification('$LOCALIZE[78926]', '$LOCALIZE[78928]', "", 2000)
						count = 10
					xbmc.sleep(1000)
	elif count == 10:
		printpoint = printpoint + "9"
		notification_common("11")	
	else:
		printpoint = printpoint + "8"
		notification_common("19")	
	
	
	
	setSkinSetting("0", 'General_CustomVAR', "")
	setSkinSetting("0", 'DialogSelectSources3', "")	
	setsetting_custom1('plugin.video.genesis','host_select',"0")
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + name + "_LV" + printpoint + space + "dialogselectsources" + space2 + dialogselectsources + space + "dialogselectsources3" + space2 + dialogselectsources3 + newline + "container57position" + space2 + str(container57position) + space + "container57position2" + space2 + str(container57position2) + space + "listitemlabel" + space2 + listitemlabel + space + "systemcurrentcontrol" + space2 + systemcurrentcontrol + space + "containerfolderpath" + space2 + containerfolderpath + space
	'''---------------------------'''

elif mode == 10: #if General_Sync == "true":
	'''------------------------------
	---General_Sync------------------
	------------------------------'''
	if libraryisscanningvideo: xbmc.executebuiltin('UpdateLibrary(video)')
	RefreshSettings(AutoPlay_Pause, Current_Name, Current_Source, General_ConnectionScore, General_CustomVAR, General_CountWait, General_CountWaitSelect, Current_Header)
	sys.exit()
	
elif mode == 11:
	'''------------------------------
	---GenesisSettings---------------
	------------------------------'''
	GenesisSettings("ALL", AutoPlay_Pause, General_ConnectionScore, General_CustomVAR)



class main:
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "RunScript" + space + "mode" + space2 + str(mode)

	'''---------------------------'''
	#xbmc.sleep(500)
	#notification(controlisvisible311S,controlisvisible312S,"",5000)
	#topvideoinformation('run')
