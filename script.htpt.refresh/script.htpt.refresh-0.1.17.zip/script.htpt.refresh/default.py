import xbmc, os, subprocess, sys
import xbmcgui, xbmcaddon

from variables import *
from modules import *

if General_Sync == "true":
	#if not autoplaypausebutton and General_Refresh == "":
	if libraryisscanningvideo: xbmc.executebuiltin('UpdateLibrary(video)')
	RefreshSettings(AutoPlay_Pause, Current_Name, Current_Source, General_ConnectionScore, General_CustomVAR, General_CountWait, General_CountWaitSelect)
	#xbmc.sleep(500)
	setsetting('General_Sync',"false")
	if admin: notification("General_Sync" + space2 + General_Sync,"","",1000)
	sys.exit()

class AutoPlay_PauseButton:
	'''------------------------------
	---AutoPlay-Pause----------------
	------------------------------'''
	if autoplaypausebutton:
		'''---------------------------'''
		if AutoPlay_Pause == "false":
			'''------------------------------
			---AutoPlay-PAUSE-ON-------------
			------------------------------'''
			AutoPlay_Pause2 = "true"
			setsetting_custom1('script.htpt.refresh','AutoPlay_Pause',"true")
			setSkinSetting("1",'AutoPlay_Pause',"true")
			addonsettings2('plugin.video.genesis','autoplay',"false",'',"",'autoplay_library',"false",'playback_info',"true",'',"")
			if AutoPlay_HD == "true": notification(addonString(202).encode('utf-8') + " (HD) ","","",2000)
			elif AutoPlay_SD == "true": notification(addonString(202).encode('utf-8') + " (SD) ","","",2000)
			'''---------------------------'''
		elif AutoPlay_Pause == "true":
			'''------------------------------
			---AutoPlay-PAUSE-OFF------------
			------------------------------'''
			AutoPlay_Pause2 = "false"
			setsetting_custom1('script.htpt.refresh','AutoPlay_Pause',"false")
			setSkinSetting("1",'AutoPlay_Pause',"false")
			addonsettings2('plugin.video.genesis','autoplay',"true",'',"",'autoplay_library',"true",'playback_info',"false",'',"")
			if AutoPlay_HD == "true": notification(addonString(200).encode('utf-8') + " (HD) ","","",1000)
			elif AutoPlay_SD == "true": notification(addonString(200).encode('utf-8') + " (SD) ","","",1000)
			else:
				notification(addonString(200) + " (HD) ","","",1000)
				addonsettings2('plugin.video.genesis','playback_auto_sd',"false",'',"",'',"",'',"",'',"")
				'''---------------------------'''
			
		if homeW: xbmc.executebuiltin('Action(Down)')
		elif myvideonavW: xbmc.executebuiltin('Action(Right)')
		
		GenesisSettings("3", AutoPlay_Pause2, General_ConnectionScore, General_CustomVAR)
		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		print printfirst + "AutoPlay_PauseButton" + space2 + "AutoPlay_Pause" + space2 + AutoPlay_Pause + " - " + AutoPlay_Pause2 + space3
		'''---------------------------'''
		
class Refresh_Button:
	if refreshbutton or General_Refresh != "":
		'''------------------------------
		---Refresh-----------------------
		------------------------------'''
		myvideonavW = xbmc.getCondVisibility('Window.IsVisible(MyVideoNav.xml)')
		setsetting_custom1('script.htpt.refresh','General_Refresh',"")
		setsetting_custom1('script.htpt.refresh','General_StartWindow',"")
		xbmc.sleep(500)
		GenesisSettings("0", "", General_ConnectionScore, General_CustomVAR)
		'''---------------------------'''
		
		if General_Refresh == "0":
			'''------------------------------
			---ismovie-----------------------
			------------------------------'''
			if not myvideonavW: xbmc.executebuiltin('ActivateWindow(Videos,MovieTitles)')
			xbmc.executebuiltin('Notification($LOCALIZE[79067] $LOCALIZE[71030],$LOCALIZE[31407],4000)')
			'''---------------------------'''
			
		elif refreshbutton or General_Refresh == "1":
			'''------------------------------
			---istv--------------------------
			------------------------------'''
			if not myvideonavW: xbmc.executebuiltin('ActivateWindow(VideoLibrary,TVShowTitles)')
			xbmc.executebuiltin('Notification($LOCALIZE[79067] $LOCALIZE[73120],$LOCALIZE[31407],4000)')
			'''---------------------------'''
			
		'''------------------------------
		---MYVIDEO-NAV-------------------
		------------------------------'''
		xbmc.sleep(1500)
		xbmc.executebuiltin('Container.Refresh')
		xbmc.executebuiltin('RunScript(service.skin.widgets)')
		xbmc.sleep(500)
		'''---------------------------'''
		if General_StartWindow == "1" or refreshbutton:
			'''------------------------------
			---HOME--------------------------
			------------------------------'''
			xbmc.sleep(1200)
			xbmc.executebuiltin('ReplaceWindow(0)')
			xbmc.sleep(700)
			'''---------------------------'''
			if refreshbutton or General_Refresh == "1":
				'''------------------------------
				---HOME--------------------------
				------------------------------'''
				xbmc.executebuiltin('Control.SetFocus(2)')
				xbmc.executebuiltin('Action(Up)')
				xbmc.executebuiltin('Action(Up)')
			elif General_Refresh == "0":
				'''------------------------------
				---ismovie-----------------------
				------------------------------'''
				xbmc.executebuiltin('Control.SetFocus(1)')
				xbmc.executebuiltin('Action(Up)')
				xbmc.executebuiltin('Action(Up)')
				'''---------------------------'''
		if General_StartWindow == "1":
			'''------------------------------
			---HOME--------------------------
			------------------------------'''
			from variables import dialogselectsources3, dialogselectsources5
			'''---------------------------'''
			if dialogselectsources3 == dialogselectsources5:
				'''------------------------------
				---TRIGGER-REFRESH2--------------
				------------------------------'''
				xbmc.executebuiltin('Control.SetFocus(9092)')
				xbmc.executebuiltin('Action(Select)')
				print printfirst + "refresh2" + space3

		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		print printfirst + "Refresh_Button"
		'''---------------------------'''

#class Cancel_Button:
	#if cancelbutton and customvar == "1":
		#count = 0
		#while count < 5 and not xbmc.abortRequested:
			#General_CustomVAR = getsetting('General_CustomVAR')
			#if General_CustomVAR != "1" and General_CustomVAR != "3" and General_CustomVAR != "20": setsetting_custom1('script.htpt.refresh','General_CustomVAR',"1")
			#count += 1
			#xbmc.sleep(200)

		#General_CustomVAR2 = getsetting('General_CustomVAR')
		#setSkinSetting("0",'General_CustomVAR',General_CustomVAR2)
		#print printfirst + "Cancel_Button" + space2 + "General_CustomVAR/2" + space2 + General_CustomVAR + " - " + General_CustomVAR2

class main:
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "script.htpt.refresh - DONE!"
	'''---------------------------'''
	#xbmc.sleep(500)
	#notification(controlisvisible311S,controlisvisible312S,"",5000)
	#topvideoinformation('run')
