import xbmc, os, subprocess, sys
import xbmcgui, xbmcaddon

from variables import *
from modules import *

def OnOff(value, General_ConnectionScore, AutoPlay_Pause, General_CustomVAR):
	#from variables import getsetting
	#admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	if value == "true":
		'''---------------------------'''
		setsetting_custom1('script.htpt.refresh', 'General_Sync', "true")
		#setsetting('General_Sync',"true") ###CAUSE GENERAL_CONNECTION SCREW UP O_o###
		xbmc.executebuiltin('RunScript(script.htpt.refresh)')
		xbmc.sleep(400)
	else:
		setGeneral_CurTrigger(value, General_ConnectionScore, AutoPlay_Pause, General_CustomVAR)
		returned_Header = getDialogW("header2")
		if xbmc.Player().isPlayingVideo() and returned_Header in headerL:
			notification("Video Stop","","",4000)
			xbmc.executebuiltin('Action(Stop)')
			if admin: print printfirst + "OnOff" + space + "Video Stop" 
		else:
			setSkinSetting("0",'Current_Header',"")
			setsetting_custom1('script.htpt.refresh','Current_Header',"")

	'''------------------------------
	---General_ScriptON--------------
	------------------------------'''
	setsetting_custom1('script.htpt.refresh','General_ScriptON',value)
	General_ScriptON = getsetting('General_ScriptON')
	setSkinSetting("1",'General_ScriptON',value)
	'''---------------------------'''
	
	'''------------------------------
	---setGeneral_Refresh------------
	------------------------------'''
	setGeneral_Refresh(General_ScriptON)
	'''---------------------------'''
	
	'''------------------------------
	---General_StartWindow-----------
	------------------------------'''
	General_StartWindow2 = getsetting('General_StartWindow')
	setGeneral_StartWindow(General_ScriptON, General_StartWindow2)
	General_StartWindow = getsetting('General_StartWindow')
	'''---------------------------'''
	
	'''------------------------------
	---Current_M_T-------------------
	------------------------------'''
	Current_M_T2 = getsetting('Current_M_T')
	setCurrent_M_T(General_StartWindow)
	Current_M_T = getsetting('Current_M_T')
	'''---------------------------'''
	
	'''------------------------------
	---topvideoinformation-----------
	------------------------------'''
	topvideoinformation(General_StartWindow,Current_M_T)
	'''---------------------------'''
	
	'''------------------------------
	---setDialogSelectSources3-------
	------------------------------'''
	dialogselectsources3 = setDialogSelectSources3(General_StartWindow, General_StartWindow2, Current_M_T, Current_M_T2)
	'''---------------------------'''
	
	'''------------------------------
	---setCurrent_Name---------------
	------------------------------'''
	Current_Name2 = getsetting('Current_Name')
	setCurrent_Name(Current_Name2, Current_M_T, Current_M_T2,General_StartWindow, General_StartWindow2, dialogselectsources3)
	Current_Name = getsetting('Current_Name')
	'''---------------------------'''
	
	'''------------------------------
	---setCurrent_Source-------------
	------------------------------'''
	#Current_Source2 = getsetting('Current_Source')
	setLast_Source(Current_M_T, Current_M_T2)
	#Current_Source = getsetting('Current_Source')
	'''---------------------------'''
	
	'''------------------------------
	---Current_YEAR------------------
	------------------------------'''
	setCurrent_Year(General_ScriptON, Current_Name, Current_M_T2)
	'''---------------------------'''
	
	'''------------------------------
	---LastMovie/TV_Subtitle---------
	------------------------------'''
	setLast_Subtitle(Current_M_T,Current_M_T2,Current_Name2)
	'''---------------------------'''
	
	'''------------------------------
	---General_TimeZone--------------
	------------------------------'''
	setGeneral_TimeZone(General_ScriptON)
	'''---------------------------'''
	
	'''---------------------------'''
	addonsettings2('script.htpt.refresh','',"",'General_CountWait',"0",'Current_WatchTime',"0",'General_CountWaitSelect',"0",'',"")
	setSkinSetting5("0",'',"",'General_CountWait',"0",'',"",'',"",'',"")
	'''---------------------------'''
	if value == "true":
		'''------------------------------
		---General_ScriptON-TRUE---------
		------------------------------'''
		#customvar = xbmc.getInfoLabel('Skin.String(General_CustomVAR)')
		#if customvar != "12":
		setsetting_custom1('script.htpt.refresh','General_CustomVAR',"")
		setSkinSetting("0",'General_CustomVAR',"")
		'''---------------------------'''
	else:
		'''------------------------------
		---General_ScriptON-FALSE--------
		------------------------------'''
		setsetting_custom1('script.htpt.refresh','General_CustomVAR',"")
		setSkinSetting("0",'General_CustomVAR',"")
		'''---------------------------'''
		setSkinSetting("0",'AutoPlay2',"0")
		addonsettings2('script.htpt.refresh','General_StartWindow',"",'Current_M_T',"",'General_Connected',"0",'Current_Watched',"false",'AutoPlay2',"0")
		addonsettings2('script.htpt.refresh','Current_Duration',"",'Current_RefreshPoint',"",'Current_Source',"",'Current_Name',"",'Current_Header',"")
		'''---------------------------'''
		#setGeneral_CurTrigger(General_ScriptON, General_ConnectionScore, AutoPlay_Pause)
		#setGeneral_CurTrigger(General_ScriptON,"","")
	#if value == "false": xbmc.executebuiltin('RunScript(script.htpt.refresh)') ###CAUSE BUG WITH VARIABLES DO NOT UPDATE RIGHT

	print printfirst + "OnOff" + space2 + General_ScriptON + " - " + value + space + "General_ConnectionScore" + space2 + General_ConnectionScore + space + "AutoPlay_Pause" + space2 + AutoPlay_Pause + space + "General_CustomVAR" + space2 + General_CustomVAR
	
def checkStream(admin, admin2):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	from variables import getsetting, setsetting
	connected = xbmc.getInfoLabel('Skin.HasSetting(Connected)')
	customvar = xbmc.getInfoLabel('Skin.String(General_CustomVAR)')
	dialogselectsources = xbmc.getInfoLabel('Skin.String(dialogselectsources)')
	dialogselectsources2 = xbmc.getInfoLabel('Skin.String(dialogselectsources2)')
	pingrate = xbmc.getInfoLabel('Skin.String(Ping_Rate)')
	AutoPlay_Pause = getsetting('AutoPlay_Pause')
	AutoPlay_SD = getsetting('AutoPlay_SD')
	AutoPlay_HD = getsetting('AutoPlay_HD')
	AutoPlay2 = getsetting('AutoPlay2')
	Current_Dialog = getsetting('Current_Dialog')
	Current_Header = getsetting('Current_Header')
	Current_Name = getsetting('Current_Name')
	Current_M_T = getsetting('Current_M_T')
	Current_Source = getsetting('Current_Source')
	Current_WatchTime = getsetting('Current_WatchTime')
	Current_Year = getsetting('Current_Year')
	General_Connected = getsetting('General_Connected')
	General_ConnectionScore = getsetting('General_ConnectionScore')
	General_CountWait = getsetting('General_CountWait')
	General_CountWaitSelect = getsetting('General_CountWaitSelect')
	General_CustomVAR = getsetting('General_CustomVAR')
	General_ScriptON = getsetting('General_ScriptON')
	General_StartWindow = getsetting('General_StartWindow')
	'''---------------------------'''
	General_CountWaitN = int(General_CountWait)
	AutoPlay2N = int(AutoPlay2)
	Current_Dialog2 = getsetting('Current_Dialog')
	'''---------------------------'''
	Current_Dialog = getDialogW("dialog")
	printpoint = ""
	xbmc.sleep(500)

	if (General_ScriptON == "true" or General_Connected != "0") and Current_Dialog != "dialogokW":
		'''------------------------------
		---setGeneral_Connected----------
		------------------------------'''
		setGeneral_Connected(connected)
		'''---------------------------'''
							
	if (General_ScriptON == "true" or General_CustomVAR != "") and Current_Dialog != "dialogokW": #and (Current_Dialog == "dialogprogressW" or Current_Dialog == "dialogbusyW")
		'''------------------------------
		---setGeneral_CustomVAR----------
		------------------------------'''
		General_CustomVAR = setGeneral_CustomVAR(General_CustomVAR, General_ScriptON, Current_Dialog2, General_CountWait, AutoPlay2)
		'''---------------------------'''

	if General_ScriptON == "false":
		'''------------------------------
		---General_ScriptON-FALSE---------
		------------------------------'''
		if customvar == "12": pass
		elif Current_Dialog == "dialogprogressW" or Current_Dialog == "dialogselectW":
			'''------------------------------
			-dialogprogress-/-dialogselectW--
			------------------------------'''
			returned_Header = getDialogW("header")
			if returned_Header == "Genesis" or returned_Header == "Sdarot.tv Video":
				if admin: print printfirst + "OnOff-true (1)" 
				OnOff("true", General_ConnectionScore, AutoPlay_Pause, General_CustomVAR)
				'''---------------------------'''
			else: pass
		elif Current_Dialog == "dialogbusyW":
			'''------------------------------
			---dialogbusyW-&-isgenesis-------
			------------------------------'''
			homeW = xbmc.getCondVisibility('Window.IsVisible(Home.xml)')
			dialogselectsources3 = xbmc.getInfoLabel('Skin.String(DialogSelectSources3)')
			containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
			isgenesis = "videodb://tvshows" in containerfolderpath or "library://video/tvshows" in containerfolderpath or "plugin://plugin.video.genesis/" in containerfolderpath
			if isgenesis:
				istv = (xbmc.getInfoLabel('ListItem.TVShowTitle') != "" and xbmc.getInfoLabel('ListItem.Season') != "" and xbmc.getInfoLabel('ListItem.Episode') != "") or ("videodb://tvshows" in containerfolderpath or "library://video/tvshows" in containerfolderpath)
				ismovie = (xbmc.getInfoLabel('ListItem.Year') != "" or xbmc.getInfoLabel('ListItem.Country') != "" or xbmc.getInfoLabel('ListItem.Tagline') != "") and not istv
				if istv or ismovie:
					if admin:
						print printfirst + "OnOff-true (2)" 
					OnOff("true", General_ConnectionScore, AutoPlay_Pause, General_CustomVAR)
					'''---------------------------'''
			elif homeW and dialogselectsources3:
				if admin:
					print printfirst + "OnOff-true (3)" 
				OnOff("true", General_ConnectionScore, AutoPlay_Pause, General_CustomVAR)
				'''---------------------------'''
	elif General_ScriptON == "true":
		'''------------------------------
		---General_ScriptON-TRUE---------
		------------------------------'''
		if Current_Dialog == "dialogokW" and Current_Header == "Sdarot.tv Video":
			'''------------------------------
			---dialogokW-ON------------------
			------------------------------'''
			openDialogOK(admin, AutoPlay_Pause, AutoPlay_SD, AutoPlay_HD, AutoPlay2, Current_Dialog, Current_Header, Current_Name, Current_M_T, Current_Source, Current_WatchTime, Current_Year, General_Connected, General_ConnectionScore, General_CountWait, General_CountWaitSelect, General_CustomVAR, General_ScriptON, General_StartWindow)
			if General_CustomVAR == "50":
				'''------------------------------
				---Error occurred-(50)-----------
				------------------------------'''
				returned = dialogyesno(addonString(257), addonString(258))
				if returned == "ok":
					setsetting_custom1('script.htpt.refresh','AutoPlay2',"1")
					dialogok('[COLOR=Yellow]' + addonString(257) + '[/COLOR]', addonString(259), '[COLOR=Red]' + addonString(260) + '[/COLOR]', "")
					xbmc.sleep(200)
					xbmc.executebuiltin('Action(Select)')
					'''---------------------------'''
				else:
					printpoint = printpoint + "8"
					setsetting_custom1('script.htpt.refresh','AutoPlay2',"0")
					'''---------------------------'''
			
			elif General_CustomVAR == "51" or General_CustomVAR == "52":
				'''------------------------------
				---AutoPlay-IsraelTV-(51)--------
				------------------------------'''
				Current_Dialog = getDialogW("dialog")
				if Current_Dialog == "dialogokW":
					xbmc.executebuiltin('Action(Select)') #xbmc.executebuiltin('Dialog.Close(12002)')
					xbmc.sleep(200)
					if admin: print printfirst + "AutoPlay2" + space2 + AutoPlay2 + "--1"
					AutoPlay2 = calculate('script.htpt.refresh','AutoPlay2',"1","")
					setSkinSetting("0",'AutoPlay2',AutoPlay2)
					if admin: print printfirst + "AutoPlay2" + space2 + AutoPlay2 + "--2"
					AutoPlay2N = int(AutoPlay2)
					'''---------------------------'''
					
			elif General_CustomVAR == "1" or General_CustomVAR == "53":
				if General_CustomVAR == "1": notification(addonString(220),"","",1000)
				elif General_CustomVAR == "53": notification(addonString(204),"","",1000)
				openDialogOK(admin, AutoPlay_Pause, AutoPlay_SD, AutoPlay_HD, AutoPlay2, Current_Dialog, Current_Header, Current_Name, Current_M_T, Current_Source, Current_WatchTime, Current_Year, General_Connected, General_ConnectionScore, General_CountWait, General_CountWaitSelect, General_CustomVAR, General_ScriptON, General_StartWindow)
				OnOff("false", General_ConnectionScore, AutoPlay_Pause, General_CustomVAR)
				xbmc.executebuiltin('Dialog.Close(okdialog)')
				'''---------------------------'''
		elif Current_Dialog == "" and (General_CustomVAR == "51" or General_CustomVAR == "52") and Current_Header == "Sdarot.tv Video":
			listitemlabel = xbmc.getInfoLabel('ListItem.Label')
			listitemlabel1 = xbmc.getInfoLabel('Container().ListItem(-1).Label')
			listitemlabel2 = xbmc.getInfoLabel('Container().ListItem(1).Label')
			Current_Dialog = getDialogW("dialog")
			if admin: print printfirst + "Sdarot.tv Video_service" + space + "listitemlabel" + space2 + listitemlabel + space + "listitemlabel1" + space2 + listitemlabel1 + space + "listitemlabel2" + space2 + listitemlabel2
			'''---------------------------'''
			if Current_Dialog == "":
				if Current_Dialog2 == "dialogbusyW": xbmc.sleep(1000)
				elif (Current_Name == listitemlabel or (Current_Name != listitemlabel1 and Current_Name != listitemlabel2) or General_CustomVAR == "51"):
					xbmc.executebuiltin('Action(Select)')
					xbmc.sleep(200)
					dialogkaitoastW = xbmc.getCondVisibility('Window.IsVisible(DialogKaiToast.xml)')
					if not dialogkaitoastW: notification(addonString(208) + space + AutoPlay2 + "/" + AutoPlay2Max,addonString(260),"",2000)
					'''---------------------------'''
				else:
					setSkinSetting("0",'General_CustomVAR',"1")
					'''---------------------------'''
					
		elif Current_Dialog == "dialogokW" and Current_Dialog2 != "dialogokW" and Current_Header == "Genesis":
			'''------------------------------
			---dialogokW-ON------------------
			------------------------------'''
			if Current_Dialog2 != "dialogokW":
				setGeneral_CustomVAR(General_CustomVAR, General_ScriptON, Current_Dialog2, General_CountWait, AutoPlay2)
				setGeneral_ConnectionScore(admin, AutoPlay_Pause, AutoPlay_SD, AutoPlay_HD, Current_Dialog, Current_Name, Current_M_T, Current_Source, Current_WatchTime, Current_Year, General_Connected, General_ConnectionScore, General_CountWait, General_CountWaitSelect, General_CustomVAR, General_ScriptON, General_StartWindow, "")
				openDialogOK(admin, AutoPlay_Pause, AutoPlay_SD, AutoPlay_HD, AutoPlay2, Current_Dialog, Current_Header, Current_Name, Current_M_T, Current_Source, Current_WatchTime, Current_Year, General_Connected, General_ConnectionScore, General_CountWait, General_CountWaitSelect, General_CustomVAR, General_ScriptON, General_StartWindow)
				OnOff("false", General_ConnectionScore, AutoPlay_Pause, General_CustomVAR)
			else:
				printpoint = printpoint + "6"
				#if admin: notification("Current_Dialog2 != dialogokW ","false",General_CustomVAR,2000)
				'''---------------------------'''
		elif Current_Dialog == "dialogselectW":
			'''------------------------------
			---dialogselectW-ON--------------
			------------------------------'''
			#setsetting_custom1('script.htpt.refresh','Current_Source',dialogselectsources)
			#setSkinSetting("0",'DialogSelectSources2',dialogselectsources)
			if Current_Dialog2 != "dialogselectW" and Current_Dialog2 != "":
				setsetting_custom1('script.htpt.refresh','General_CountWaitSelect',General_CountWait)
				'''---------------------------'''
		elif Current_Dialog2 == "dialogselectW": #and Current_Dialog != "dialogselectW" and Current_Dialog != "": # and General_CustomVAR != "1" and General_CustomVAR != "4"
			'''------------------------------
			---Current_Source----------------
			------------------------------'''
			setCurrent_Source(admin, Current_Source, Current_M_T, dialogselectsources)
			'''---------------------------'''	
		elif Current_Dialog == "dialogbusyW":
			'''------------------------------
			---dialogbusyW-------------------
			------------------------------'''
			setGeneral_CountWait(admin)
			#calculate('script.htpt.refresh','General_CountWait',"1","")
			#General_CountWait2 = getsetting('General_CountWait')
			#setSkinSetting("0",'General_CountWait',General_CountWait2)
			
			setGeneral_Connected(connected)
			'''---------------------------'''
		elif Current_Dialog == "dialogyesnoW":
			'''------------------------------
			---dialogyesnoW-ON---------------
			------------------------------'''
			pass
			'''---------------------------'''			
		elif Current_Dialog == "dialogprogressW":
			'''------------------------------
			--dialogprogress-ON--------------
			------------------------------'''
			setGeneral_CountWait(admin)
			#calculate('script.htpt.refresh','General_CountWait',"1","")
			#General_CountWait2 = getsetting('General_CountWait')
			#setSkinSetting("0",'General_CountWait',General_CountWait2)
			setGeneral_Connected(connected)
			'''---------------------------'''			
		elif Current_Dialog == "" and (Current_Dialog2 == "" or Current_Dialog2 == "dialogokW"): #Current_Header == "Sdarot.tv Video")
			'''------------------------------
			--dialog-OFF---------------------
			------------------------------'''
			OnOff("false", General_ConnectionScore, AutoPlay_Pause, General_CustomVAR)
			'''---------------------------'''
		#if xbmc.Player().isPlayingVideo(): print printfirst + "checkStream" + space2 + "Current_Dialog" + space2 + Current_Dialog + space + "General_ScriptON" + space2 + General_ScriptON + space + "Current_Dialog" + space2 + Current_Dialog + space + "General_CustomVAR" + space2 + General_CustomVAR + space + "General_CountWait" + space2 + General_CountWait
		if xbmc.Player().isPlayingVideo() or Current_Dialog == "dialogokW":
			print printfirst + "checkStream_LV" + printpoint + space + "Current_Dialog" + space2 + Current_Dialog + space + "Current_Dialog2" + space2 + Current_Dialog2
			if admin: print printfirst + "VARCHECK" + space2 + "AutoPlay_Pause" + space2 + AutoPlay_Pause + space + "AutoPlay_SD" + space2 + AutoPlay_SD + space + "AutoPlay_HD" + space2 + AutoPlay_HD
			if admin: print printfirst + "VARCHECK" + space2 + "Current_Dialog" + space2 + Current_Dialog + space + "Current_Header" + space2 + Current_Header + space + "Current_Name" + space2 + Current_Name + space + "Current_M_T" + space2 + Current_M_T + space + "Current_Source" + space2 + Current_Source + space + "Current_Year" + space2 + Current_Year
			if admin: print printfirst + "VARCHECK" + space2 + "General_Connected" + space2 + General_Connected + space + "General_CountWait" + space2 + General_CountWait + space + "General_ConnectionScore" + space2 + General_ConnectionScore + space + "General_CountWaitSelect" + space2 + General_CountWaitSelect
			if admin: print printfirst + "VARCHECK" + space2 + "General_CustomVAR" + space2 + General_CustomVAR + space + "General_ScriptON" + space2 + General_ScriptON + space + "General_StartWindow" + space2 + General_StartWindow
		'''---------------------------'''

def getPlayerInfo(admin):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	from variables import admin, systemidle3
	from variables import getsetting, setsetting
	playerpaused = xbmc.getCondVisibility('Player.Paused')
	playerduration = xbmc.getInfoLabel("Player.Duration(hh)") + xbmc.getInfoLabel("Player.Duration(mm)") + xbmc.getInfoLabel("Player.Duration(ss)")
	playerdurationN = int(playerduration)
	refreshtimeN = playerdurationN * 0.90
	refreshtimeN = int(round(refreshtimeN,-1))
	refreshtime = str(refreshtimeN)
	'''---------------------------'''
	#setsetting('Current_Duration',playerduration)
	#setsetting('Current_RefreshPoint',refreshtime)
	setsetting_custom1('script.htpt.refresh','Current_Duration',playerduration)
	setsetting_custom1('script.htpt.refresh','Current_RefreshPoint',refreshtime)
	'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "getPlayerInfo" + space + "playerduration" + space2 + playerduration + space + "refreshtime" + space2 + refreshtime + space3
	'''---------------------------'''
	return playerdurationN
	
def setCurrent_Watched(admin):
	#if admin or not admin:
	try:
		'''------------------------------
		---VARIABLES---------------------
		------------------------------'''
		from variables import getsetting, setsetting
		Current_RefreshPoint = getsetting('Current_RefreshPoint')
		Current_Watched = getsetting('Current_Watched')
		General_Refresh = getsetting('General_Refresh')
		General_CountWait = getsetting('General_CountWait')
		Current_Name = getsetting('Current_Name')
		General_StartWindow = getsetting('General_StartWindow')
		Current_RefreshPointN = int(Current_RefreshPoint)
		Current_M_T = getsetting('Current_M_T')
		Current_Source = getsetting('Current_Source')
		playertime = xbmc.getInfoLabel("Player.Time(hh)") + xbmc.getInfoLabel("Player.Time(mm)") + xbmc.getInfoLabel("Player.Time(ss)")
		playertimeN = int(playertime)
		playerduration = xbmc.getInfoLabel("Player.Duration(hh)") + xbmc.getInfoLabel("Player.Duration(mm)") + xbmc.getInfoLabel("Player.Duration(ss)")
		'''---------------------------'''
		
		if playertimeN > Current_RefreshPointN: setsetting_custom1('script.htpt.refresh','Current_Watched',"true")
		elif playertimeN < Current_RefreshPointN: setsetting_custom1('script.htpt.refresh','Current_Watched',"false")
		'''---------------------------'''
		Current_Watched2 = getsetting('Current_Watched')
		if admin and Current_Watched != Current_Watched2: notification("Admin","Current_Watched Switched!","",1000)
		'''---------------------------'''
		
		if Current_Watched == "false":
			'''------------------------------
			---General_Refresh-OFF-----------
			------------------------------'''
			setsetting_custom1('script.htpt.refresh','General_Refresh',"false")
			'''---------------------------'''
			
		else:
			'''------------------------------
			---General_Refresh-ON------------
			------------------------------'''
			if Current_M_T == "0": setsetting_custom1('script.htpt.refresh','General_Refresh',"0")
			elif Current_M_T == "1": setsetting_custom1('script.htpt.refresh','General_Refresh',"1")
			'''---------------------------'''
			playlistlength = xbmc.getInfoLabel('Playlist.Length(video)')
			playlistlengthN = int(playlistlength)
			playlistposition = xbmc.getInfoLabel('Playlist.Position(video)')
			playlistpositionN = int(playlistposition)
			playertimeremaining = xbmc.getInfoLabel("Player.TimeRemaining(hh)") + xbmc.getInfoLabel("Player.TimeRemaining(mm)") + xbmc.getInfoLabel("Player.TimeRemaining(ss)")
			try: playertimeremainingN = int(playertimeremaining)
			except: playertimeremainingN = 0
			'''---------------------------'''
			if playertimeremainingN < 7:
				if playlistpositionN < playlistlengthN and playlistlengthN > 1:
					'''------------------------------
					---PLAYLIST-TIME-ABOUT-TO-END----
					------------------------------'''
					if playertimeremainingN > 4:
						GenesisSettings("5", AutoPlay_Pause, General_ConnectionScore, General_CustomVAR)
						setsetting_custom1('script.htpt.refresh','General_CountWait',"0")
					'''---------------------------'''
			
				elif General_StartWindow == "1":
					'''------------------------------
					---counter dialogselectW bug!----
					------------------------------'''
					print printfirst + "counter dialogselectW bug!" + space + playertimeremaining + space3
					if admin: notification("Admin","counter dialogselectW bug!!!","",2000)
					xbmc.executebuiltin('Action(Pause)')
					xbmc.sleep(1000)
					xbmc.executebuiltin('Action(Stop)')
					OnOff("false", General_ConnectionScore, AutoPlay_Pause, General_CustomVAR)
					'''---------------------------'''
		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		Current_Watched2 = getsetting('Current_Watched')
		if Current_Watched != Current_Watched2 and admin: print printfirst + space + "setCurrent_Watched" + space2 + "playertime" + space2 + playertime + space + "playerduration" + space2 + playerduration + space3 + "Current_RefreshPoint" + space2 + Current_RefreshPoint
		if Current_Watched != Current_Watched2: print printfirst + "setCurrent_Watched" + space2 + Current_Watched2 + space + "Current_Name" + space2 + Current_Name + space + "Current_Source" + space2 + Current_Source + space + "General_CountWait" + space2 + General_CountWait + space + "playertime" + space2 + playertime
		'''---------------------------'''
	except:
		print printfirst + "setCurrent_Watched" + space + "except-pass" + space3

def setCurrent_WatchTime(admin):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	admin2 = xbmc.getInfoLabel('Skin.HasSetting(Admin2)')
	Current_WatchTime = getsetting('Current_WatchTime')
	Current_WatchTime2 = calculate('script.htpt.refresh','Current_WatchTime',"1","")
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin and admin2: print printfirst + space + "setCurrent_WatchTime" + space2 + Current_WatchTime + " - " + Current_WatchTime2
	'''---------------------------'''

def setCurrent_Subtitle(admin):
	dialogsubtitles2 = xbmc.getInfoLabel('Skin.String(DialogSubtitles2)')
	dialogsubtitlesna1 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA1)')
	dialogsubtitlesna2 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA2)')
	dialogsubtitlesna3 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA3)')
	dialogsubtitlesna4 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA4)')
	dialogsubtitlesna5 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA5)')
	dialogsubtitlesna6 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA6)')
	dialogsubtitlesna7 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA7)')
	dialogsubtitlesna8 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA8)')
	dialogsubtitlesna9 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA9)')
	dialogsubtitlesna10 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA10)')
	'''---------------------------'''
	setsetting_custom1('script.htpt.refresh','Current_Subtitle',dialogsubtitles2)
	setsetting_custom1('script.htpt.refresh','Current_Subtitle1',dialogsubtitlesna1)
	setsetting_custom1('script.htpt.refresh','Current_Subtitle2',dialogsubtitlesna2)
	setsetting_custom1('script.htpt.refresh','Current_Subtitle3',dialogsubtitlesna3)
	setsetting_custom1('script.htpt.refresh','Current_Subtitle4',dialogsubtitlesna4)
	setsetting_custom1('script.htpt.refresh','Current_Subtitle5',dialogsubtitlesna5)
	setsetting_custom1('script.htpt.refresh','Current_Subtitle6',dialogsubtitlesna6)
	setsetting_custom1('script.htpt.refresh','Current_Subtitle7',dialogsubtitlesna7)
	setsetting_custom1('script.htpt.refresh','Current_Subtitle8',dialogsubtitlesna8)
	setsetting_custom1('script.htpt.refresh','Current_Subtitle9',dialogsubtitlesna9)
	setsetting_custom1('script.htpt.refresh','Current_Subtitle10',dialogsubtitlesna10)
	'''---------------------------'''
	Current_Subtitle = getsetting('Current_Subtitle')
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + space + "setCurrent_Subtitle" + space2 + Current_Subtitle + space + "(" + dialogsubtitles2 + ")"
	'''---------------------------'''
	
def setGeneral_SubSearch(count):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	dialogsubtitlesW = getsetting('dialogsubtitlesW')
	count2 = 0
	'''---------------------------'''
	while count2 < 100 and dialogsubtitlesW and not xbmc.abortRequested:
		'''------------------------------
		---VARIABLES---------------------
		------------------------------'''
		from variables import getsetting, setsetting
		dialogsubtitlesW = getsetting('dialogsubtitlesW')
		General_SubSearch = getsetting('General_SubSearch')
		dialogsubtitles2 = xbmc.getInfoLabel('Skin.String(DialogSubtitles2)')
		dialogsubtitles = xbmc.getInfoLabel('Skin.String(DialogSubtitles)')
		container120numitems = xbmc.getInfoLabel('Container(120).NumItems') #DialogSubtitles
		controlgetlabel100 = xbmc.getInfoLabel('Control.GetLabel(100)') #DialogSubtitles Service Name
		'''---------------------------'''
		xbmc.sleep(1000)
		count2 += 1
		'''---------------------------'''
		#onClick(self, int controlId)
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "setGeneral_SubSearch" + space2 + General_SubSearch + space + "count/2" + space2 + count + " / " + count2 + space 
	'''---------------------------'''

class main:
	'''------------------------------
	---STARTUP-----------------------
	------------------------------'''
	xbmc.sleep(7000)
	OnOff("false", "5", "false", "")
	addonsettings2('script.htpt.refresh','General_CountWaitSelect',"0",'General_CurTrigger',"",'AutoPlay2',"0",'',"",'',"")
	addonsettings2('script.htpt.refresh','General_Connected',"0",'General_ConnectionScore',"5",'Current_WatchTime',"0",'General_Refresh',"",'Current_Source',"")
	addonsettings2('script.htpt.refresh','',"",'Current_Watched',"false",'AutoPlay_Pause',"false",'Current_Year',"",'General_CustomVAR',"")
	setSkinSetting5("0",'DialogSelectSources',"",'DialogSelectSources3',"",'General_CustomVAR',"",'General_ConnectionScore',"5",'',"")
	#if not systemplatformwindows: bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.video.genesis',"plugin.video.genesis")
	xbmc.sleep(3000)
	GenesisSettings("0", "", General_ConnectionScore, General_CustomVAR)
	xbmc.sleep(2000)
	AutoPlay_Pause = getsetting('AutoPlay_Pause')
	General_ConnectionScore = getsetting('General_ConnectionScore')
	RefreshSettings(AutoPlay_Pause, Current_Name, Current_Source, General_ConnectionScore, General_CustomVAR, General_CountWait, General_CountWaitSelect, Current_Header)
	
	'''---------------------------'''
	while 1 and not xbmc.abortRequested:
		'''------------------------------
		---VARIABLES---------------------
		------------------------------'''
		from variables import getsetting
		admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
		istvmoviep = (videoplayertitle in dialogselectsources3 or videoplayertitle in dialogselectsources5)
		systemidle10 = xbmc.getCondVisibility('System.IdleTime(10)')
		General_ScriptON = getsetting('General_ScriptON')
		'''---------------------------'''
		if admin: print printfirst + "service.py " + space + "main class"
		xbmc.sleep(1000)
		count = 0

		while systemidle10 and General_ScriptON == "false" and not xbmc.abortRequested:
			'''------------------------------
			---IDLE TIME---------------------
			------------------------------'''
			from variables import getsetting
			admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
			systemidle10 = xbmc.getCondVisibility('System.IdleTime(10)')
			General_ScriptON = getsetting('General_ScriptON')
			'''---------------------------'''
			xbmc.sleep(1000)
			count += 1

			'''---------------------------'''
			if count == 1 and admin: print printfirst + "service.py" + space + "idletime10"
			
			'''---------------------------'''
		count = 0
		while not xbmc.Player().isPlayingVideo() and (not systemidle10 or General_ScriptON == "true") and not xbmc.abortRequested:
			'''------------------------------
			---VIDEO-OFF---------------------
			------------------------------'''
			if count == 0 and admin: print printfirst + "service.py " + "VIDEO-OFF"
			from variables import getsetting
			admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
			admin2 = xbmc.getInfoLabel('Skin.HasSetting(Admin2)')
			systemidle10 = xbmc.getCondVisibility('System.IdleTime(10)')
			General_ScriptON = getsetting('General_ScriptON')
			'''---------------------------'''
			xbmc.sleep(500) #+500 in checkStream!
			count += 1
			'''---------------------------'''
			checkStream(admin, admin2)
			'''---------------------------'''
		if xbmc.Player().isPlayingVideo():
			'''------------------------------
			---VARFIXGET---------------------
			------------------------------'''
			General_StartWindow = getsetting('General_StartWindow')
			AutoPlay_Pause = getsetting('AutoPlay_Pause')
			AutoPlay_SD = getsetting('AutoPlay_SD')
			AutoPlay_HD = getsetting('AutoPlay_HD')
			AutoPlay2 = getsetting('AutoPlay2')
			Current_Dialog = getsetting('Current_Dialog')
			Current_Header = getsetting('Current_Header')
			Current_Name = getsetting('Current_Name')
			Current_M_T = getsetting('Current_M_T')
			Current_Source = getsetting('Current_Source')
			Current_WatchTime = getsetting('Current_WatchTime')
			Current_Year = getsetting('Current_Year')
			General_Connected = getsetting('General_Connected')
			General_ConnectionScore = getsetting('General_ConnectionScore')
			General_CountWait = getsetting('General_CountWait')
			General_CountWaitSelect = getsetting('General_CountWaitSelect')
			General_CustomVAR = getsetting('General_CustomVAR')
			General_ScriptON = getsetting('General_ScriptON')
			General_StartWindow = getsetting('General_StartWindow')
			'''---------------------------'''
			General_StartWindowFIX = General_StartWindow
			AutoPlay_PauseFIX = AutoPlay_Pause
			AutoPlay_SDFIX = AutoPlay_SD
			AutoPlay_HDFIX = AutoPlay_HD
			AutoPlay2FIX = getsetting('AutoPlay2')
			Current_DialogFIX = Current_Dialog
			Current_HeaderFIX = Current_Header
			Current_NameFIX = Current_Name
			Current_M_TFIX = Current_M_T
			Current_SourceFIX = Current_Source
			Current_WatchTimeFIX = Current_WatchTime
			Current_YearFIX = Current_Year
			General_ConnectedFIX = General_Connected
			General_ConnectionScoreFIX = General_ConnectionScore
			General_CountWaitFIX = General_CountWait
			General_CountWaitSelectFIX = General_CountWaitSelect
			General_CustomVARFIX = General_CustomVAR
			General_ScriptONFIX = General_ScriptON
			General_StartWindowFIX = General_StartWindow
			'''---------------------------'''
			if admin: print printfirst + "VARFIXGET" + space2 + "AutoPlay_Pause" + space2 + AutoPlay_PauseFIX + space + "AutoPlay_SD" + space2 + AutoPlay_SDFIX + space + "AutoPlay_HD" + space2 + AutoPlay_HDFIX + space + "AutoPlay2" + space2 + AutoPlay2FIX
			if admin: print printfirst + "VARFIXGET" + space2 + "Current_Dialog" + space2 + Current_DialogFIX + space + "Current_Header" + space2 + Current_HeaderFIX + space + "Current_Name" + space2 + Current_NameFIX + space + "Current_M_T" + space2 + Current_M_TFIX + space + "Current_Source" + space2 + Current_SourceFIX + space + "Current_Year" + space2 + Current_YearFIX
			if admin: print printfirst + "VARFIXGET" + space2 + "General_Connected" + space2 + General_ConnectedFIX + space + "General_CountWait" + space2 + General_CountWaitFIX + space + "General_ConnectionScore" + space2 + General_ConnectionScoreFIX + space + "General_CountWaitSelect" + space2 + General_CountWaitSelectFIX
			if admin: print printfirst + "VARFIXGET" + space2 + "General_CustomVAR" + space2 + General_CustomVARFIX + space + "General_ScriptON" + space2 + General_ScriptONFIX + space + "General_StartWindow" + space2 + General_StartWindowFIX
			'''---------------------------'''
			count = 0
			videoplayertitle = xbmc.getInfoLabel('VideoPlayer.Title')
			dialogselectsources3 = xbmc.getInfoLabel('Skin.String(DialogSelectSources3)')
			dialogselectsources5 = xbmc.getInfoLabel('Skin.String(DialogSelectSources5)')
			containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
			istv4 = " S" in dialogselectsources3 and " E" in dialogselectsources3
			ismovie4 = " (" in dialogselectsources3 and ")" in dialogselectsources3 and not istv4
			istv2 = (xbmc.getInfoLabel('VideoPlayer.TVShowTitle') != "" and xbmc.getInfoLabel('VideoPlayer.Season') != "" and xbmc.getInfoLabel('VideoPlayer.Episode') != "") or ("videodb://tvshows" in containerfolderpath or "library://video/tvshows" in containerfolderpath)
			ismovie2 = xbmc.getInfoLabel('VideoPlayer.Content') == "movies" or ((xbmc.getInfoLabel('VideoPlayer.Year') != "" or xbmc.getInfoLabel('VideoPlayer.Country') != "") and xbmc.getInfoLabel('VideoPlayer.Tagline') != "") and not istv2
			istvmoviep = "false"
			#if (videoplayertitle in dialogselectsources3 or videoplayertitle in dialogselectsources5) and videoplayertitle != "": istvmoviep = "true"
			if (istv2 or ismovie2): istvmoviep = "true"
			
			if admin and istvmoviep == "true": notification("test","istvmoviep","",2000)
			'''---------------------------'''
			
		while xbmc.Player().isPlayingVideo() and not xbmc.abortRequested: #and (General_ScriptON == "true" or istvmoviep == "true") 
			'''------------------------------
			---VIDEO-ON----------------------
			------------------------------'''
			if count > 0: xbmc.sleep(1000)
			if count < 60: count += 1
			'''---------------------------'''
			from variables import getsetting
			admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
			systemidle10 = xbmc.getCondVisibility('System.IdleTime(10)')
			General_ScriptON = getsetting('General_ScriptON')
			systemidle3 = xbmc.getCondVisibility('System.IdleTime(3)')
			playerhasvideo = xbmc.getCondVisibility('Player.HasVideo')
			playerpaused = xbmc.getCondVisibility('Player.Paused')
			'''------------------------------'''
			if count == 1:
				playerdurationN = 0
				if (General_ScriptON == "true" or istvmoviep == "true"):
					videoplayerisfullscreen = xbmc.getCondVisibility('VideoPlayer.IsFullscreen')
					if General_StartWindow == "2" and not videoplayerisfullscreen: xbmc.executebuiltin('Action(FullScreen)')
					xbmc.sleep(1000) #1500 (WORKED GREAT!)
					'''---------------------------'''
					#notification("test","","",2000)
					try:
						playerdurationN = getPlayerInfo(admin)
						'''------------------------------'''
					except:
						pass
						if admin: print printfirst + "service.py " + "OnOff(false_z)"
						#except: onoff("false", General_ConnectionScore, AutoPlay_Pause, General_CustomVAR)
						'''------------------------------'''
					if Current_Header == "Genesis" and playerdurationN > 1500: testStream(admin, AutoPlay_Pause, AutoPlay_SD, AutoPlay_HD, Current_Dialog, Current_Name, Current_M_T, Current_Source, Current_WatchTime, Current_Year, General_Connected, General_ConnectionScore, General_CountWait, General_CountWaitSelect, General_CustomVAR, General_ScriptON, General_StartWindow)
					'''------------------------------'''
			if count == 2:
				Current_Dialog = getDialogW("dialog")
				count2 = 0
				while count2 < 3 and xbmc.Player().isPlayingVideo() and Current_Dialog != ("videofullscreenW" and "") and not xbmc.abortRequested:
					'''prevent bug with player not opening fast enough'''
					xbmc.sleep(500)
					count2 += 1
					Current_Dialog = getDialogW("dialog")
				#if count2 < 3:
				if Current_M_T == "3" and AutoPlay2 != "0":
					notification(addonString(272), addonString(273), "", 4000)
					setsetting_custom1('script.htpt.refresh','AutoPlay2',"0")
					setSkinSetting("0",'AutoPlay2',"0")
					setsetting_custom1('script.htpt.refresh','General_CustomVAR',"54")
					setSkinSetting("0",'General_CustomVAR',"54")
					'''------------------------------'''
				elif istvmoviep and General_ScriptON == "false" and playerdurationN > 1500:
					if admin: print printfirst + "service.py " + "OnOff(true)"
					OnOff("true", General_ConnectionScore, AutoPlay_Pause, General_CustomVAR)
					'''------------------------------'''
				elif Current_Header == "Genesis": pass
				elif Current_Header == "Sdarot.tv Video": pass
				elif Current_M_T != "": pass
				elif General_ScriptON == "true":
					if admin: print printfirst + "service.py " + "OnOff(false)***"
					OnOff("false", General_ConnectionScore, AutoPlay_Pause, General_CustomVAR)
					'''------------------------------'''
			
			if count == 3: varfixset(admin, AutoPlay_PauseFIX, AutoPlay_SDFIX, AutoPlay_HDFIX, AutoPlay2FIX, Current_DialogFIX, Current_HeaderFIX, Current_NameFIX, Current_M_TFIX, Current_SourceFIX, Current_WatchTimeFIX, Current_YearFIX, General_ConnectedFIX, General_ConnectionScoreFIX, General_CountWaitFIX, General_CountWaitSelectFIX, General_CustomVARFIX, General_ScriptONFIX, General_StartWindowFIX)
			if count == 3.5:
				'''------------------------------
				---VARFIXSET---------------------
				------------------------------'''
				AutoPlay_Pause = AutoPlay_PauseFIX
				AutoPlay_SD = AutoPlay_SDFIX
				AutoPlay_HD = AutoPlay_HDFIX
				AutoPlay2 = AutoPlay2FIX
				Current_Dialog = Current_DialogFIX
				Current_Header = Current_HeaderFIX
				Current_Name = Current_NameFIX
				Current_M_T = Current_M_TFIX
				Current_Source = Current_SourceFIX
				Current_WatchTime = Current_WatchTimeFIX
				Current_Year = Current_YearFIX
				General_Connected = General_ConnectedFIX
				General_ConnectionScore = General_ConnectionScoreFIX
				General_CountWait = General_CountWaitFIX
				General_CountWaitSelect = General_CountWaitSelectFIX
				General_CustomVAR = General_CustomVARFIX
				General_ScriptON = General_ScriptONFIX
				General_StartWindow = General_StartWindowFIX
				'''---------------------------'''
				#setsetting_custom1('script.htpt.refresh','AutoPlay_Pause',AutoPlay_PauseFIX)
				#setsetting_custom1('script.htpt.refresh','AutoPlay_SD',AutoPlay_SDFIX)
				#setsetting_custom1('script.htpt.refresh','AutoPlay_HD',AutoPlay_HDFIX)
				setsetting_custom1('script.htpt.refresh','Current_Dialog',Current_DialogFIX)
				setsetting_custom1('script.htpt.refresh','Current_Header',Current_HeaderFIX)
				setsetting_custom1('script.htpt.refresh','Current_Name',Current_NameFIX)
				setsetting_custom1('script.htpt.refresh','Current_M_T',Current_M_TFIX)
				setsetting_custom1('script.htpt.refresh','Current_Source',Current_SourceFIX)
				setsetting_custom1('script.htpt.refresh','Current_WatchTime',Current_WatchTimeFIX)
				setsetting_custom1('script.htpt.refresh','Current_Year',Current_YearFIX)
				setsetting_custom1('script.htpt.refresh','General_Connected',General_ConnectedFIX)
				#setsetting_custom1('script.htpt.refresh','General_ConnectionScore',General_ConnectionScoreFIX)
				setsetting_custom1('script.htpt.refresh','General_CountWait',General_CountWaitFIX)
				setsetting_custom1('script.htpt.refresh','General_CountWaitSelect',General_CountWaitSelectFIX)
				setsetting_custom1('script.htpt.refresh','General_CustomVAR',General_CustomVARFIX)
				setsetting_custom1('script.htpt.refresh','General_ScriptON',General_ScriptONFIX)
				setsetting_custom1('script.htpt.refresh','General_StartWindow',General_StartWindowFIX)
				'''---------------------------'''
				if admin: print printfirst + "VARFIXGET2" + space2 + "AutoPlay_Pause" + space2 + AutoPlay_PauseFIX + space + "AutoPlay_SD" + space2 + AutoPlay_SDFIX + space + "AutoPlay_HD" + space2 + AutoPlay_HDFIX
				if admin: print printfirst + "VARFIXGET2" + space2 + "Current_Dialog" + space2 + Current_DialogFIX + space + "Current_Header" + space2 + Current_HeaderFIX + space + "Current_Name" + space2 + Current_NameFIX + space + "Current_M_T" + space2 + Current_M_TFIX + space + "Current_Source" + space2 + Current_SourceFIX + space + "Current_Year" + space2 + Current_YearFIX
				if admin: print printfirst + "VARFIXGET2" + space2 + "General_Connected" + space2 + General_ConnectedFIX + space + "General_CountWait" + space2 + General_CountWaitFIX + space + "General_ConnectionScore" + space2 + General_ConnectionScoreFIX + space + "General_CountWaitSelect" + space2 + General_CountWaitSelectFIX
				if admin: print printfirst + "VARFIXGET2" + space2 + "General_CustomVAR" + space2 + General_CustomVARFIX + space + "General_ScriptON" + space2 + General_ScriptONFIX + space + "General_StartWindow" + space2 + General_StartWindowFIX
				'''---------------------------'''
				if admin: print printfirst + "VARFIXSET" + space2 + "AutoPlay_Pause" + space2 + AutoPlay_Pause + space + "AutoPlay_SD" + space2 + AutoPlay_SD + space + "AutoPlay_HD" + space2 + AutoPlay_HD
				if admin: print printfirst + "VARFIXSET" + space2 + "Current_Dialog" + space2 + Current_Dialog + space + "Current_Header" + space2 + Current_Header + space + "Current_Name" + space2 + Current_Name + space + "Current_M_T" + space2 + Current_M_T + space + "Current_Source" + space2 + Current_Source + space + "Current_Year" + space2 + Current_Year
				if admin: print printfirst + "VARFIXSET" + space2 + "General_Connected" + space2 + General_Connected + space + "General_CountWait" + space2 + General_CountWait + space + "General_ConnectionScore" + space2 + General_ConnectionScore + space + "General_CountWaitSelect" + space2 + General_CountWaitSelect
				if admin: print printfirst + "VARFIXSET" + space2 + "General_CustomVAR" + space2 + General_CustomVAR + space + "General_ScriptON" + space2 + General_ScriptON + space + "General_StartWindow" + space2 + General_StartWindow
				'''---------------------------'''
			if not playerhasvideo: pass
			elif count > 3 and not systemidle3:
				Current_Dialog2 = getsetting('Current_Dialog')
				Current_Dialog = getDialogW("dialog")
				if Current_Dialog == "dialogprogressW" or Current_Dialog == "dialogselectW":
					'''------------------------------
					-dialogprogress-/-dialogselectW--
					------------------------------'''
					returned_Header = getDialogW("header2")
					#headerL = ["Genesis", "Sdarot.tv Video", addonString(61).encode('utf-8')]
					if returned_Header in headerL:
						'''------------------------------
						--General_ScriptON-OFF-----------
						------------------------------'''
						print printfirst + "service.py" + space + "General_ScriptON-OFF"
						OnOff("false", General_ConnectionScore, AutoPlay_Pause, General_CustomVAR)
						setsetting_custom1('script.htpt.refresh','Current_Header',returned_Header)
						setSkinSetting("0",'Current_Header',returned_Header)
						'''------------------------------'''
				elif Current_Dialog != "dialogsubtitlesW" and Current_Dialog2 == "dialogsubtitlesW":
					'''------------------------------
					---dialogsubtitlesW--------------
					------------------------------'''
					setCurrent_Subtitle(admin)
					#setGeneral_SubSearch(count)
			elif General_ScriptON != "true": xbmc.sleep(1000)
			else:
				'''------------------------------
				---setGeneral_Connected----------
				------------------------------'''
				setGeneral_Connected(connected)
				'''---------------------------'''
				
				'''------------------------------
				---WATCHED-CHECK-----------------
				------------------------------'''
				if count >= 60 and not playerpaused and systemidle3:
					setCurrent_Watched(admin)
					if count == 60: setCurrent_WatchTime(admin)
					if count == 120: count = 59
					count += 1
					'''---------------------------'''