'''------------------------------
---shared_variables--------------
------------------------------'''
import xbmc, xbmcgui, xbmcaddon
import datetime
import xbmcaddon, sys, os
servicehtptPath          = xbmcaddon.Addon('service.htpt').getAddonInfo("path")
sharedlibDir = os.path.join(servicehtptPath, 'resources', 'lib', 'shared')
sys.path.insert(0, sharedlibDir)
from shared_variables import *
'''---------------------------'''
#libDir = os.path.join(addonPath, 'resources', 'lib')
#sys.path.insert(0, libDir)

'''------------------------------
---script.htpt.refresh-------------
------------------------------'''
getsetting         = xbmcaddon.Addon().getSetting
setsetting         = xbmcaddon.Addon().setSetting
addonName          = xbmcaddon.Addon().getAddonInfo("name")
addonString        = xbmcaddon.Addon().getLocalizedString
addonID          = xbmcaddon.Addon().getAddonInfo("id")
addonPath          = xbmcaddon.Addon().getAddonInfo("path")
addonVersion          = xbmcaddon.Addon().getAddonInfo("version")

printfirst = addonName + ": !@# "
'''---------------------------'''
AutoPlay_Pause = getsetting('AutoPlay_Pause')
AutoPlay_SD = getsetting('AutoPlay_SD')
AutoPlay_HD = getsetting('AutoPlay_HD')
AutoPlay2 = getsetting('AutoPlay2')
'''---------------------------'''
AutoPlay2Max = getsetting('AutoPlay2Max')
try:
	AutoPlay2MaxN = int(AutoPlay2Max)
except:
	setsetting('AutoPlay2Max',"40")
	AutoPlay2Max = "40"
	AutoPlay2MaxN = 40
	'''---------------------------'''
General_Connected = getsetting('General_Connected')
General_ConnectionScore = getsetting('General_ConnectionScore')
try: General_ConnectionScoreN = int(General_ConnectionScore)
except: pass
General_CustomVAR = getsetting('General_CustomVAR')
General_CountWait = getsetting('General_CountWait')
General_CountWaitSelect = getsetting('General_CountWaitSelect')
General_CurTrigger = getsetting('General_CurTrigger')
General_Refresh = getsetting('General_Refresh')
General_ScriptON = getsetting('General_ScriptON')
General_StartWindow = getsetting('General_StartWindow')
General_Sync = getsetting('General_Sync')
General_TimeZone = getsetting('General_TimeZone')
'''---------------------------'''
Current_Dialog = getsetting('Current_Dialog')
Current_Header = getsetting('Current_Header')
Current_M_T = getsetting('Current_M_T')
Current_Name = getsetting('Current_Name')
Current_RefreshPoint = getsetting('Current_RefreshPoint')
Current_Source = getsetting('Current_Source')
Current_Watched = getsetting('Current_Watched')
Current_WatchTime = getsetting('Current_WatchTime')
Current_Year = getsetting('Current_Year')
'''---------------------------'''
Current_Subtitle = getsetting('Current_Subtitle')
Current_Subtitle1 = getsetting('Current_Subtitle1')
Current_Subtitle2 = getsetting('Current_Subtitle2')
Current_Subtitle3 = getsetting('Current_Subtitle3')
Current_Subtitle4 = getsetting('Current_Subtitle4')
Current_Subtitle5 = getsetting('Current_Subtitle5')
Current_Subtitle6 = getsetting('Current_Subtitle6')
Current_Subtitle7 = getsetting('Current_Subtitle7')
Current_Subtitle8 = getsetting('Current_Subtitle8')
Current_Subtitle9 = getsetting('Current_Subtitle9')
Current_Subtitle10 = getsetting('Current_Subtitle10')
'''---------------------------'''
LastMovie_Name = getsetting('LastMovie_Name')
LastMovie_Source = getsetting('LastMovie_Source')
LastMovie_Year = getsetting('LastMovie_Year')
'''---------------------------'''
LastMovie_Subtitle = getsetting('LastMovie_Subtitle')
LastMovie_Subtitle1 = getsetting('LastMovie_Subtitle1')
LastMovie_Subtitle2 = getsetting('LastMovie_Subtitle2')
LastMovie_Subtitle3 = getsetting('LastMovie_Subtitle3')
LastMovie_Subtitle4 = getsetting('LastMovie_Subtitle4')
LastMovie_Subtitle5 = getsetting('LastMovie_Subtitle5')
LastMovie_Subtitle6 = getsetting('LastMovie_Subtitle6')
LastMovie_Subtitle7 = getsetting('LastMovie_Subtitle7')
LastMovie_Subtitle8 = getsetting('LastMovie_Subtitle8')
LastMovie_Subtitle9 = getsetting('LastMovie_Subtitle9')
LastMovie_Subtitle10 = getsetting('LastMovie_Subtitle10')
'''---------------------------'''
LastTV_Name = getsetting('LastTV_Name')
LastTV_Source = getsetting('LastTV_Source')
LastTV_Year = getsetting('LastTV_Year')
'''---------------------------'''
LastTV_Subtitle = getsetting('LastTV_Subtitle')
LastTV_Subtitle1 = getsetting('LastTV_Subtitle1')
LastTV_Subtitle2 = getsetting('LastTV_Subtitle2')
LastTV_Subtitle3 = getsetting('LastTV_Subtitle3')
LastTV_Subtitle4 = getsetting('LastTV_Subtitle4')
LastTV_Subtitle5 = getsetting('LastTV_Subtitle5')
LastTV_Subtitle6 = getsetting('LastTV_Subtitle6')
LastTV_Subtitle7 = getsetting('LastTV_Subtitle7')
LastTV_Subtitle8 = getsetting('LastTV_Subtitle8')
LastTV_Subtitle9 = getsetting('LastTV_Subtitle9')
LastTV_Subtitle10 = getsetting('LastTV_Subtitle10')
'''---------------------------'''
SE_ColorRed = "BILLIONUPLOADS"
SE_ColorRed2 = "BILLIONUPLOADS"
SE_ColorRed3 = "G2G"
SE_ColorGreen = "ORORO"
SE_ColorGreen2 = "VK"
SE_ColorGreen3 = "MOVIETUBE"
SE_ColorGreen4 = "SWEFLIX"
SE_ColorPurple = "REALDEBRID"
SE_ColorPurple2 = "REALDEBRID"
SE_ColorPurple3 = "REALDEBRID"
'''---------------------------'''

'''------------------------------
***SKIN-STRINGS------------------
------------------------------'''
dialogselectsources = xbmc.getInfoLabel('Skin.String(DialogSelectSources)')
dialogselectsources2 = xbmc.getInfoLabel('Skin.String(DialogSelectSources2)')
dialogselectsources3 = xbmc.getInfoLabel('Skin.String(DialogSelectSources3)')
dialogselectsources5 = xbmc.getInfoLabel('Skin.String(DialogSelectSources5)')
dialogsubtitles2 = xbmc.getInfoLabel('Skin.String(DialogSubtitles2)')
dialogsubtitlesna1 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA1)')
dialogsubtitlesna2 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA2)')
dialogsubtitlesna3 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA3)')
dialogsubtitlesna4 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA4)')
dialogsubtitlesna5 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA5)')
dialogsubtitlesna6 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA6)')
dialogsubtitlesna7 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA7)')
dialogsubtitlesna8 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA8)')
dialogsubtitlesna9 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA9)')
dialogsubtitlesna10 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA10)')
'''---------------------------'''

'''------------------------------
***MIXED-------------------------
------------------------------'''
isgenesis = "videodb://tvshows" in containerfolderpath or "library://video/tvshows" in containerfolderpath or "plugin://plugin.video.genesis/" in containerfolderpath
istv = (xbmc.getInfoLabel('ListItem.TVShowTitle') != "" and xbmc.getInfoLabel('ListItem.Season') != "" and xbmc.getInfoLabel('ListItem.Episode') != "") or ("videodb://tvshows" in containerfolderpath or "library://video/tvshows" in containerfolderpath)
istvS = str(istv)
istv2 = (xbmc.getInfoLabel('VideoPlayer.TVShowTitle') != "" and xbmc.getInfoLabel('VideoPlayer.Season') != "" and xbmc.getInfoLabel('VideoPlayer.Episode') != "") or ("videodb://tvshows" in containerfolderpath or "library://video/tvshows" in containerfolderpath)
istv4 = " S" in dialogselectsources3 and " E" in dialogselectsources3
istv4S = str(istv4)
'''---------------------------'''
ismovie = (xbmc.getInfoLabel('ListItem.Year') != "" or xbmc.getInfoLabel('ListItem.Country') != "" or xbmc.getInfoLabel('ListItem.Tagline') != "") and not istv
ismovieS = str(ismovie)
ismovie2 = xbmc.getInfoLabel('VideoPlayer.Content') == "movies" or ((xbmc.getInfoLabel('VideoPlayer.Year') != "" or xbmc.getInfoLabel('VideoPlayer.Country') != "") and xbmc.getInfoLabel('VideoPlayer.Tagline') != "") and not istv2
ismovie4 = " (" in dialogselectsources3 and ")" in dialogselectsources3 and not istv4
ismovie4S = str(ismovie4)
'''---------------------------'''
istvmoviep = (videoplayertitle in dialogselectsources3 or videoplayertitle in dialogselectsources5)
'''---------------------------'''
headerL = ["Genesis", "Sdarot.tv Video", addonString(61).encode('utf-8')]
'''------------------------------
---GENESIS----------------------------
------------------------------'''