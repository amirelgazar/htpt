import xbmc, os, subprocess, sys
import xbmcgui, xbmcaddon

from variables import *
from modules import *
from shared_modules3 import get_params

printpoint = ""
'''---------------------------'''
params=get_params()
url=None
name=None
mode=None
iconimage=None
desc=None
num=None
'''---------------------------'''
try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try: mode=int(params["mode"])
except: pass
try: num=urllib.unquote_plus(params["num"])
except: pass
'''---------------------------'''
notification("test","","",1000)
if mode == 1:
	'''------------------------------
	---Cancel_Button-----------------
	------------------------------'''
	list = ["1", "3", "20"]
	if not General_CustomVAR in list:
		setsetting_custom1('script.htpt.refresh','General_CustomVAR',"1")
		setSkinSetting("0",'General_CustomVAR',"1")

	General_CustomVAR2 = getsetting('General_CustomVAR')
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "Cancel_Button" + space2 + "General_CustomVAR" + space2 + General_CustomVAR + " - " + General_CustomVAR2
	'''---------------------------'''

elif mode == 2:
	'''------------------------------
	---AutoPlay-Pause----------------
	------------------------------'''
	if AutoPlay_Pause == "false":
		'''------------------------------
		---AutoPlay-PAUSE-ON-------------
		------------------------------'''
		AutoPlay_Pause2 = "true"
		setsetting_custom1('script.htpt.refresh','AutoPlay_Pause',"true")
		setSkinSetting("1",'AutoPlay_Pause',"true")
		addonsettings2('plugin.video.genesis','autoplay',"false",'',"",'autoplay_library',"false",'playback_info',"true",'',"")
		if AutoPlay_HD == "true": notification(addonString(202).encode('utf-8') + " (HD) ","","",2000)
		elif AutoPlay_SD == "true": notification(addonString(202).encode('utf-8') + " (SD) ","","",2000)
		'''---------------------------'''
	elif AutoPlay_Pause == "true":
		'''------------------------------
		---AutoPlay-PAUSE-OFF------------
		------------------------------'''
		AutoPlay_Pause2 = "false"
		setsetting_custom1('script.htpt.refresh','AutoPlay_Pause',"false")
		setSkinSetting("1",'AutoPlay_Pause',"false")
		addonsettings2('plugin.video.genesis','autoplay',"true",'',"",'autoplay_library',"true",'playback_info',"false",'',"")
		if AutoPlay_HD == "true": notification(addonString(200).encode('utf-8') + " (HD) ","","",1000)
		elif AutoPlay_SD == "true": notification(addonString(200).encode('utf-8') + " (SD) ","","",1000)
		else:
			notification(addonString(200) + " (HD) ","","",1000)
			addonsettings2('plugin.video.genesis','playback_auto_sd',"false",'',"",'',"",'',"",'',"")
			'''---------------------------'''
	
	if autoplaypausebutton:
		if homeW: xbmc.executebuiltin('Action(Down)')
		elif myvideonavW: xbmc.executebuiltin('Action(Right)')
	
	GenesisSettings("3", AutoPlay_Pause2, General_ConnectionScore, General_CustomVAR)
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "AutoPlay_PauseButton" + space2 + "AutoPlay_Pause" + space2 + AutoPlay_Pause + " - " + AutoPlay_Pause2 + space3
	'''---------------------------'''

elif mode == 3:
	'''------------------------------
	---Refresh-----------------------
	------------------------------'''
	printpoint = ""
	General_Refresh2 = getsetting('General_Refresh')
	homeW = xbmc.getCondVisibility('Window.IsVisible(Home.xml)')
	myvideonavW = xbmc.getCondVisibility('Window.IsVisible(MyVideoNav.xml)')
	setsetting_custom1('script.htpt.refresh','General_Refresh',"")
	setsetting_custom1('script.htpt.refresh','General_StartWindow',"")
	GenesisSettings("0", "", General_ConnectionScore, General_CustomVAR)
	'''---------------------------'''
	
	if General_Refresh == "0":
		'''------------------------------
		---ismovie-----------------------
		------------------------------'''
		printpoint = printpoint + "1"
		if not myvideonavW: xbmc.executebuiltin('ActivateWindow(Videos,MovieTitles)')
		xbmc.executebuiltin('Notification($LOCALIZE[79067] $LOCALIZE[71030],$LOCALIZE[31407],4000)')
		'''---------------------------'''
		
	elif refreshbutton or General_Refresh == "1":
		'''------------------------------
		---istv--------------------------
		------------------------------'''
		printpoint = printpoint + "2"
		if not myvideonavW: xbmc.executebuiltin('ActivateWindow(VideoLibrary,TVShowTitles)')
		xbmc.executebuiltin('Notification($LOCALIZE[79067] $LOCALIZE[73120],$LOCALIZE[31407],4000)')
		'''---------------------------'''
		
	'''------------------------------
	---MYVIDEO-NAV-------------------
	------------------------------'''
	count = 0
	while count < 10 and not myvideonavW and not xbmc.abortRequested:
		count += 1
		xbmc.sleep(200)
		myvideonavW = xbmc.getCondVisibility('Window.IsVisible(MyVideoNav.xml)')
		'''---------------------------'''
		
	xbmc.sleep(1000)
	xbmc.executebuiltin('Container.Refresh')
	xbmc.executebuiltin('RunScript(service.skin.widgets)')
	xbmc.sleep(2000)
	'''---------------------------'''
	if General_StartWindow == "1" or refreshbutton:
		'''------------------------------
		---HOME--------------------------
		------------------------------'''
		printpoint = printpoint + "3"
		homeW = xbmc.getCondVisibility('Window.IsVisible(Home.xml)')
		xbmc.sleep(1200)
		xbmc.executebuiltin('ReplaceWindow(0)')
		count = 0
		while count < 10 and not homeW and not xbmc.abortRequested:
			count += 1
			xbmc.sleep(200)
			homeW = xbmc.getCondVisibility('Window.IsVisible(Home.xml)')
			'''---------------------------'''
			
		if (refreshbutton or General_Refresh == "1") and homeW:
			'''------------------------------
			---HOME--------------------------
			------------------------------'''
			printpoint = printpoint + "4"
			xbmc.sleep(200)
			xbmc.executebuiltin('Control.SetFocus(2)')
			xbmc.executebuiltin('Action(Up)')
			xbmc.executebuiltin('Action(Up)')
			'''---------------------------'''
			
		elif General_Refresh == "0":
			'''------------------------------
			---ismovie-----------------------
			------------------------------'''
			printpoint = printpoint + "5"
			xbmc.executebuiltin('Control.SetFocus(1)')
			xbmc.executebuiltin('Action(Up)')
			#xbmc.executebuiltin('Action(Up)')
			'''---------------------------'''
			
	if General_StartWindow == "1":
		'''------------------------------
		---HOME--------------------------
		------------------------------'''
		printpoint = printpoint + "6"
		dialogselectsources3 = xbmc.getInfoLabel('Skin.String(DialogSelectSources3)')
		dialogselectsources5 = xbmc.getInfoLabel('Skin.String(DialogSelectSources5)')
		'''---------------------------'''
		if dialogselectsources3 == dialogselectsources5:
			'''------------------------------
			---TRIGGER-REFRESH2--------------
			------------------------------'''
			xbmc.executebuiltin('Control.SetFocus(9092)')
			xbmc.executebuiltin('Action(Select)')
			printpoint = printpoint + "7"
	
	RefreshSettings(AutoPlay_Pause, Current_Name, Current_Source, General_ConnectionScore, General_CustomVAR, General_CountWait, General_CountWaitSelect, Current_Header)
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "Refresh_Button_LV" + printpoint + space + "General_Refresh" + space2 + General_Refresh + space + "General_Refresh2" + space2 + General_Refresh2 + space + "dialogselectsources3/5" + space2 + dialogselectsources3 + space4 + dialogselectsources5
	'''---------------------------'''
	
elif mode == 10: #if General_Sync == "true":
	'''------------------------------
	---General_Sync------------------
	------------------------------'''
	if libraryisscanningvideo: xbmc.executebuiltin('UpdateLibrary(video)')
	RefreshSettings(AutoPlay_Pause, Current_Name, Current_Source, General_ConnectionScore, General_CustomVAR, General_CountWait, General_CountWaitSelect, Current_Header)
	sys.exit()
	




class main:
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "script.htpt.refresh - DONE!"
	print printfirst + "*TEST" + space + "mode" + space2 + str(mode)

	'''---------------------------'''
	#xbmc.sleep(500)
	#notification(controlisvisible311S,controlisvisible312S,"",5000)
	#topvideoinformation('run')
