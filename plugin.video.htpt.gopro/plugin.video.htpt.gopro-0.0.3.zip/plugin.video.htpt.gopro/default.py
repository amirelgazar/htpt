# -*- coding: utf-8 -*-

import xbmc
import os, sys
import subprocess
import xbmcgui, xbmcaddon

from variables import *
from modules import *

url, name, mode, iconimage, desc, num = pluginend(admin)

setsetting_custom1(addonID,'Current_View',58)
pluginend2(admin, containerfolderpath)