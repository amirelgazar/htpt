﻿# -*- coding: utf-8 -*-

import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os,random
import json,repoCheck

from variables import *
from modules import *

#import commonkids
#from commonkids import *

def CATEGORIES():
	
	addDir(addonString(41).encode('utf-8'),'',41,addonMediaPath + "41.png",addonString(141).encode('utf-8'),'1')
	addDir(addonString(42).encode('utf-8'),'',42,addonMediaPath + "42.jpg",addonString(142).encode('utf-8'),'1')
	addDir(addonString(44).encode('utf-8'),'',44,addonMediaPath + "44.png",addonString(144).encode('utf-8'),'1')
	addDir(addonString(45).encode('utf-8'),'',45,addonMediaPath + "45.jpg",addonString(145).encode('utf-8'),'1')
	addDir(addonString(46).encode('utf-8'),'',46,addonMediaPath + "46.png",addonString(146).encode('utf-8'),'1')
	addDir(addonString(47).encode('utf-8'),'',47,addonMediaPath + "47.jpg",addonString(147).encode('utf-8'),'1')
	addDir(addonString(48).encode('utf-8'),'',48,addonMediaPath + "48.jpg",addonString(148).encode('utf-8'),'1')
	addDir(addonString(49).encode('utf-8'),'',49,addonMediaPath + "49.jpg",addonString(149).encode('utf-8'),'1')
	if General_TrustedOnly == "false": addDir(addonString(43).encode('utf-8'),'',43,addonMediaPath + "42.jpg",addonString(143).encode('utf-8'),'1')
	
	#if OFF_15 != "true": addDir('מצויירים קלאסיים','https://dl.dropboxusercontent.com/s/cwcptnocx310g00/Merry_Melodies.plx',7,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSmzwydiY6V_l5sE_ed7Rf66G6B8Ug2p7ajn4uPAhH2NYpDVMNBUQ','','1')
	
	
	
	
	'''many sources'''
	#YOUsubs('UC5RJ8so5jivihrnHB5qrV_Q')
	setView('', '50')
	'''------------------------------
	---וואלה-VOD!--------------------
	------------------------------'''
	
	
	#if OFF_9 != "true": addDir(addonString(22).encode('utf-8'),'plugin://plugin.video.wallaNew.video/?mode=1&module=wallavod&name=%d7%99%d7%9c%d7%93%d7%99%d7%9d&url=englishName%3dkids',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300',addonString(110).encode('utf-8'),'1')
	#if OFF_9 != "true": addDir('קלסיקלטת','plugin://plugin.video.wallaNew.video/?mode=1&module=338&name=קלסיקלטת&url=http://vod.walla.co.il/channel/338/clasicaletet',8,'https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcTYE2VT8CR2O31MsqAhdaydYrqrCD--HCCdGcs7blBn3Zh92Kwq','','1')
	#if OFF_10 != "true": addDir('ניק','plugin://plugin.video.wallaNew.video/?mode=1&module=nick&name=ניק&url=http://nick.walla.co.il/',8,'http://www.karmieli.co.il/sites/default/files/images/nico.jpg','','1')
	#if OFF_11 != "true": addDir('גוניור','plugin://plugin.video.wallaNew.video/?mode=1&module=junior&name=גוניור&url=http://junior.walla.co.il/',8,'http://upload.wikimedia.org/wikipedia/he/1/19/%D7%A2%D7%A8%D7%95%D7%A5_%D7%92%27%D7%95%D7%A0%D7%99%D7%95%D7%A8.jpg','','1')
	#if OFF_13 != "true": addDir('וואלה ילדים','plugin://plugin.video.wallaNew.video/?mode=1&module=wallavod&name=י%d7%99%d7%9c%d7%93%d7%99%d7%9d&url=englishName%3dkids',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300','','1')
	'''---------------------------'''
	

'''1=SONGS, 2=SHOWS, 3=LITTLE, 4=TVSHOWS, 5=MOVIES, 6=?, 7=BABY, 8=?, 9=OTHERS'''
def CATEGORIES1(admin):
	'''שירים לילדים בעברית 1'''
	addDir(addonString(57).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "1" + space5 + addonString(16).encode('utf-8'),'UCfm5IpcgGCooON4Mm2vq40A',9,'http://i.ytimg.com/i/fm5IpcgGCooON4Mm2vq40A/1.jpg?v=52fcd974',addonString(116).encode('utf-8'),'1')
	'''שירים לילדים בעברית 2 - חינוכית'''
	addDir(addonString(57).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "2" + space5 + addonString(39).encode('utf-8'),'23music',9,addonMediaPath + "92.jpg",addonString(139).encode('utf-8'),'1')
	'''שירים לילדים בעברית 3 - ייס'''
	addDir(addonString(57).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "3" + space5 + addonString(21).encode('utf-8'),'PLF11AD94724D37E02',13,'http://static.wixstatic.com/media/96e157_2b95d7111507dcbbf4d07a346b1a08bf.jpg_srz_261_263_85_22_0.50_1.20_0.00_jpg_srz',addonString(121).encode('utf-8'),'1')
	'''שירים לילדים בעברית 4 - דיסני'''
	addDir(addonString(57).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "4" + space5 + addonString(38).encode('utf-8'),'6QxAhInaZ79pTg7wi3ZF-Q',9,'http://i.ytimg.com/i/6QxAhInaZ79pTg7wi3ZF-Q/1.jpg?v=78ea3c',addonString(138).encode('utf-8'),'1')
	'''שירים לילדים בעברית 5'''
	addDir(addonString(57).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "5",'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%a9%d7%99%d7%a8%d7%99%d7%9d%20(19)&url=genre%3dkids%26genreId%3d7450',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300',addonString(197).encode('utf-8'),'1')
	'''---------------------------'''
	
	'''שירים לילדים באנגלית 1 - פשוט ללמוד אנגלית'''
	addDir(addonString(57).encode('utf-8') + space + addonString(201).encode('utf-8') + space + "1" + space5 + addonString(55).encode('utf-8'),'UCLsooMJoIpl_7ux2jvdPB-Q',9,'http://yt3.ggpht.com/-nHzSx4QKfsY/AAAAAAAAAAI/AAAAAAAAAAA/o_0k7TejOiI/s88-c-k-no/photo.jpg',addonString(155).encode('utf-8'),'1')
	
	'''שירים לילדים באנגלית 3 - ילדים 123'''
	addDir(addonString(57).encode('utf-8') + space + addonString(201).encode('utf-8') + space + "3" + space5 + addonString(53).encode('utf-8'),'UCtgpDqkeOToveUgh8igrvXQ',9,'http://yt3.ggpht.com/-g_tUdVsQVnU/AAAAAAAAAAI/AAAAAAAAAAA/KqZGxwkomOo/s88-c-k-no/photo.jpg',addonString(153).encode('utf-8'),'1')
	'''שירים לילדים באנגלית 4 - הופלה קידס'''
	addDir(addonString(57).encode('utf-8') + space + addonString(201).encode('utf-8') + space + "4" + space5 + addonString(52).encode('utf-8'),'UC3djj8jS0370cu_ghKs_Ong',9,'http://yt3.ggpht.com/-sETONHncMk4/AAAAAAAAAAI/AAAAAAAAAAA/joBxW-hyTA4/s88-c-k-no/photo.jpg',addonString(152).encode('utf-8'),'1')
	'''שירים לילדים באנגלית 5 - צאוצאו'''
	addDir(addonString(57).encode('utf-8') + space + addonString(201).encode('utf-8') + space + "5" + space5 + addonString(50).encode('utf-8'),'UCBnZ16ahKA2DZ_T5W0FPUXg',9,'http://yt3.ggpht.com/-QHPC9emY_8c/AAAAAAAAAAI/AAAAAAAAAAA/03fPGkHcBbk/s88-c-k-no/photo.jpg',addonString(151).encode('utf-8'),'1')
	'''---------------------------'''
	
	'''סיפורים בעברית 1'''
	addDir(addonString(58).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "1",'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%a1%d7%99%d7%a4%d7%95%d7%a8%d7%99%d7%9d%20(5)&url=genre%3dkids%26genreId%3d7451',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300',addonString(198).encode('utf-8'),'1')
	'''---------------------------'''
	
	'''שירים וסיפורים לילדים באנגלית 1 - אנגלית זה כיף'''
	addDir(addonString(41).encode('utf-8') + space + addonString(201).encode('utf-8') + space + "1" + space5 + addonString(61).encode('utf-8'),'UC43wDpoNIpAK2NYfMz1m0Ow',9,'http://yt3.ggpht.com/-vviGyJGiPjE/AAAAAAAAAAI/AAAAAAAAAAA/kfJgGMxLQTw/s88-c-k-no/photo.jpg',addonString(161).encode('utf-8'),'1')
	'''שירים וסיפורים לילדים באנגלית 2'''
	addDir(addonString(41).encode('utf-8') + space + addonString(201).encode('utf-8') + space + "2" + space5 + addonString(59).encode('utf-8'),'UC-qWJlvaPME3MWvrY-yjXeA',9,'http://yt3.ggpht.com/-Wk6NXGS1pAk/AAAAAAAAAAI/AAAAAAAAAAA/nBondFZLttw/s88-c-k-no/photo.jpg',addonString(159).encode('utf-8'),'1')
	'''---------------------------'''
	setView('', '50')
	
def CATEGORIES2(admin):
	'''הצגות לילדים 1'''
	addDir(addonString(42).encode('utf-8') + space + "1",'',421,'http://www.ashops.co.il/Shops/shop_271/products/557/picture_317.jpg',addonString(110).encode('utf-8'),'1')
	'''מיכל הקטנה'''
	addDir(addonString(42).encode('utf-8') + space + "3" + space5 + addonString(17).encode('utf-8'),'UCPCJS9igpTu7COLmoDeMKXQ',9,addonMediaPath + "37.jpg",addonString(117).encode('utf-8'),'1')
	'''סבא טוביה'''
	addDir(addonString(42).encode('utf-8') + space + "4" + space5 + addonString(19).encode('utf-8'),'UCu4cSBULTvIKZ-tIqojGzxA',9,'http://yt3.ggpht.com/--gG5kz68N_k/AAAAAAAAAAI/AAAAAAAAAAA/37Cr6jMJSCg/s88-c-k-no/photo.jpg',addonString(119).encode('utf-8'),'1')
	'''---------------------------'''
	'''פסטיגל'''
	addDir(addonString(37).encode('utf-8') + space + "1",'UCKs_S8Uo5rLCNhlSanFpfFQ',9,'http://i.ytimg.com/i/Ks_S8Uo5rLCNhlSanFpfFQ/1.jpg?v=5410081a',addonString(137).encode('utf-8'),'1')
	'''פסטיגל 2'''
	addDir(addonString(37).encode('utf-8') + space + "2",'UCTxlaUXzxohVekL_Zym-hsw',9,addonMediaPath + "37.jpg",addonString(137).encode('utf-8'),'1')
	'''פסטיגל 3'''
	addDir(addonString(37).encode('utf-8') + space + "3",'UC8z6QWcSpDfeHY0sni4IDwA',9,'http://yt3.ggpht.com/-2Nux9ubjSCA/AAAAAAAAAAI/AAAAAAAAAAA/P8I968rchgE/s88-c-k-no/photo.jpg',addonString(137).encode('utf-8'),'1')
	'''---------------------------'''
	
	'''---------------------------'''
	setView('', '50')
	
def CATEGORIES4(admin):
	'''סדרות לילדים בעברית 1'''
	addDir(addonString(44).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "1",'UCl0jQT2Cj5brTRt5azL5E6g',9,'http://yt3.ggpht.com/-Sc-GjwGeiBs/AAAAAAAAAAI/AAAAAAAAAAA/DV9puDGf7nI/s88-c-k-no/photo.jpg',addonString(112).encode('utf-8'),'1')   
	'''סדרות לילדים בעברית 2'''
	addDir(addonString(44).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "2",'plugin://plugin.video.sdarot.tv/?mode=2&module=http%3a%2f%2fwww.sdarot.wf%2fseries%2fgenre%2f7%d7%90%d7%a0%d7%99%d7%9e%d7%a6%d7%99%d7%94&name=%d7%90%d7%a0%d7%99%d7%9e%d7%a6%d7%99%d7%94&url=all-heb&quot;',8,'http://www.hometheater.co.il/files/(40143)_icon.png',addonString(194).encode('utf-8'),'1')   
	'''סדרות לילדים בעברית 3'''
	addDir(addonString(44).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "3",'UCDfoEu-jaKsjNL6Fl0h5PUQ',9,'http://yt3.ggpht.com/-sgYlsKP54oM/AAAAAAAAAAI/AAAAAAAAAAA/Ie9pRPV0QLo/s88-c-k-no/photo.jpg',addonString(114).encode('utf-8'),'1')   
	'''סדרות לילדים בעברית 4'''
	addDir(addonString(44).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "4",'UCnToIWbMbc9VehbtjTBBnRw',9,addonMediaPath + "95.png",addonString(195).encode('utf-8'),'1')	
	'''סדרות לילדים בעברית 5'''
	addDir(addonString(44).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "5",'plugin://plugin.video.hotVOD.video/?mode=5&name=%20HOT%20VOD%20YOUNG&url=http%3a%2f%2fhot.ynet.co.il%2fhome%2f0%2c7340%2cL-7449%2c00.html',8,'http://i28.tinypic.com/20o8lt.jpg',addonString(136).encode('utf-8'),'1')	
	'''---------------------------'''
	
	'''סדרות לילדים בעברית / אנגלית 1'''
	addDir(addonString(44).encode('utf-8') + space + addonString(200).encode('utf-8') + space4 + addonString(201).encode('utf-8') + space + "1",'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%a1%d7%93%d7%a8%d7%95%d7%aa%20(31)&url=genre%3dkids%26genreId%3d7447',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300',addonString(199).encode('utf-8'),'1')
	'''---------------------------'''
	
	'''ערוץ קופיקו'''
	addDir(addonString(34).encode('utf-8'),'UCCktKuBGZ1kHifzp9Mxu6Eg',9,'http://upload.wikimedia.org/wikipedia/he/f/fc/Kofiko.jpg',addonString(134).encode('utf-8'),'1')
	'''---------------------------'''
	
	'''ערוץ גאליס 1''' '''צריך לסנן להראות רק פרקים מלאים'''
	#if OFF_20 != "true": addDir(addonString(56).encode('utf-8') + space + "1",'UC1ZvZmYKkigob8Vg7MSgqjg',9,'http://yt3.ggpht.com/-2NPlgdL7mU8/AAAAAAAAAAI/AAAAAAAAAAA/ch9GzL2fOlM/s88-c-k-no/photo.jpg',addonString(156).encode('utf-8'),'1')
	
	#'''סדרות לילדים'''
	#seriestvheb1 = 'ערוצי סדרות א'
	#if OFF_17 != "true": addDir(addonString(44).encode('utf-8') + space + "10",seriestvheb1.decode('utf-8'),9,"https://yt3.ggpht.com/-hbyD79o9YWk/AAAAAAAAAAI/AAAAAAAAAAA/gOv2DB9cLC4/s100-c-k-no/photo.jpg",addonString(93).encode('utf-8'),'1')
	'''---------------------------'''
	if not os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.supercartoons'):
		downloader_is("0", 'https://github.com/spoyser/spoyser-repo/raw/master/zips/repository.spoyser/repository.spoyser-1.0.5.zip','supercartoons repository')
		downloader_is("0", 'https://github.com/spoyser/spoyser-repo/blob/master/zips/plugin.video.supercartoons/plugin.video.supercartoons-1.0.4.zip?raw=true','supercartoons  addon')
		'''---------------------------'''
	else:
		'''סדרות לילדים באנגלית 1'''
		addDir(addonString(44).encode('utf-8') + space + addonString(201).encode('utf-8') + space + "1",'plugin://plugin.video.supercartoons/?mode=400&page=1',8,'https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcQQoKkxPt4MxnzTqM-ChAH7My_OdIZQJ2U6CoXIeDzOkdMBaG8G',addonString(130).encode('utf-8'),'1')
		'''---------------------------'''
	'''הפנתר הורוד באנגלית 1'''
	addDir(addonString(13).encode('utf-8') + space + addonString(201).encode('utf-8') + space + "1",'PinkPanthersShow',9,'http://i.ytimg.com/i/1fIyfhQtm1fSljyKBf2uKA/1.jpg?v=5041a378',addonString(113).encode('utf-8'),'1')
	'''הפנתר הורוד באנגלית 2'''
	addDir(addonString(13).encode('utf-8') + space + addonString(201).encode('utf-8') + space + "2",'UCFeUyPY6W8qX8w2o6oSiRmw',9,'http://yt3.ggpht.com/-lwlGXn90heE/AAAAAAAAAAI/AAAAAAAAAAA/FmCv96eMMNE/s88-c-k-no/photo.jpg',addonString(113).encode('utf-8'),'1')
	'''---------------------------'''
	setView('', '50')
	
def CATEGORIES5(admin):
	'''plugin.video.seretil'''
	seretil_me = ""
	if systemplatformwindows: output = cmd('ping seretil.me -n 1',"Connected2")
	else: output = bash('ping -W 1 -w 1 -4 -q seretil.me',"Connected")
	if ("1 packets received" or not "100% packet loss") in output: seretil_me = "true"
			
	if seretil_me == "true": addDir(addonString(11).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "1",'plugin://plugin.video.seretil/?mode=4&name=%d7%9e%d7%93%d7%95%d7%91%d7%91%d7%99%d7%9d%20%d7%a8%d7%90%d7%a9%d7%99&url=http%3a%2f%2fseretil.me%2fcategory%2f%25D7%25A1%25D7%25A8%25D7%2598%25D7%2599%25D7%259D-%25D7%259E%25D7%2593%25D7%2595%25D7%2591%25D7%2591%25D7%2599%25D7%259D%2fpage1%2f',8,'http://blog.tapuz.co.il/seretilNET/images/3745375_1.jpg',addonString(111).encode('utf-8'),'1')
	if General_TrustedOnly == "false": addDir('[COLOR=Red]' + addonString(11).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "2" + '[/COLOR]','plugin://plugin.video.seretil/?mode=211&name=%20%d7%90%d7%95%d7%a1%d7%a3%20%d7%a1%d7%a8%d7%98%d7%99%d7%9d%20%d7%9e%d7%93%d7%95%d7%91%d7%91%d7%99%d7%9d&url=http%3a%2f%2fseretil.me%2f%25D7%2590%25D7%2595%25D7%25A1%25D7%25A3-%25D7%25A1%25D7%25A8%25D7%2598%25D7%2599%25D7%259D-%25D7%259E%25D7%2593%25D7%2595%25D7%2591%25D7%2591%25D7%2599%25D7%259D%2f',8,'http://blog.tapuz.co.il/seretilNET/images/3745375_1.jpg',addonString(196).encode('utf-8'),'1')
	if General_TrustedOnly == "false": addDir('[COLOR=Red]' + addonString(11).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "3" + '[/COLOR]','plugin://plugin.video.seretil/?mode=211&name=%d7%90%d7%95%d7%a1%d7%a3%20%d7%9e%d7%a1%d7%a4%d7%a8%202%20%d7%a1%d7%a8%d7%98%d7%99%d7%9d%20%d7%9e%d7%93%d7%95%d7%91%d7%91%d7%99%d7%9d&url=http%3a%2f%2fseretil.me%2f%25D7%2590%25D7%2595%25D7%25A1%25D7%25A3-%25D7%2592%25D7%2593%25D7%2595%25D7%259C-%25D7%25A9%25D7%259C-%25D7%25A1%25D7%25A8%25D7%2598%25D7%2599%25D7%259D-%25D7%259E%25D7%25A6%25D7%2595%25D7%2599%25D7%25A8%25D7%2599%25D7%259D%25D7%259E%25D7%2593%25D7%2595%25D7%2591%25D7%2591%25D7%2599%25D7%259D%2f',8,'http://blog.tapuz.co.il/seretilNET/images/3745375_1.jpg',addonString(196).encode('utf-8'),'1')
	'''---------------------------'''
	
	'''סרטים מצוירים בעברית / באנגלית 1'''
	addDir(addonString(11).encode('utf-8') + space + addonString(200).encode('utf-8') + space4 + addonString(201).encode('utf-8') + space + "1",'plugin://plugin.video.gozlan.me/?mode=1&name=%d7%a1%d7%a8%d7%98%d7%99%20%d7%90%d7%a0%d7%99%d7%9e%d7%a6%d7%99%d7%94&url=http%3a%2f%2fanonymouse.org%2fcgi-bin%2fanon-www.cgi%2fhttp%3a%2f%2fgozlan.co%2f%2fsearch.html%3fg%3d%25D7%2590%25D7%25A0%25D7%2599%25D7%259E%25D7%25A6%25D7%2599%25D7%2594',8,'http://ftp.acc.umu.se/mirror/addons.superrepo.org/v5/addons/plugin.video.gozlan.me/icon.png',addonString(110).encode('utf-8'),'1')
	'''סרטים מצוירים בעברית / באנגלית 2'''
	addDir(addonString(11).encode('utf-8') + space + addonString(200).encode('utf-8') + space4 + addonString(201).encode('utf-8') + space + "2",'plugin://plugin.video.gozlan.me/?mode=1&name=%d7%a1%d7%a8%d7%98%d7%99%20%d7%9e%d7%a9%d7%a4%d7%97%d7%94&url=http%3a%2f%2fanonymouse.org%2fcgi-bin%2fanon-www.cgi%2fhttp%3a%2f%2fgozlan.co%2f%2fsearch.html%3fg%3d%25D7%259E%25D7%25A9%25D7%25A4%25D7%2597%25D7%2594',8,'http://ftp.acc.umu.se/mirror/addons.superrepo.org/v5/addons/plugin.video.gozlan.me/icon.png',addonString(110).encode('utf-8'),'1')
	'''סרטים מצוירים בעברית / באנגלית 3'''
	if seretil_me == "true": addDir(addonString(11).encode('utf-8') + space + addonString(200).encode('utf-8') + space4 + addonString(201).encode('utf-8') + space + "3",'plugin://plugin.video.seretil/?mode=4&name=%d7%90%d7%a0%d7%99%d7%9e%d7%a6%d7%99%d7%94%20-%d7%9c%d7%90%20%d7%94%d7%9b%d7%9c%20%d7%9e%d7%93%d7%95%d7%91%d7%91&url=http%3a%2f%2fseretil.me%2fcategory%2f%25D7%2590%25D7%25A0%25D7%2599%25D7%259E%25D7%25A6%25D7%2599%25D7%2594%2fpage1%2f',8,'http://blog.tapuz.co.il/seretilNET/images/3745375_1.jpg',addonString(110).encode('utf-8'),'1')
	'''סרטים מצוירים בעברית / באנגלית 1'''
	addDir(addonString(11).encode('utf-8') + space + addonString(200).encode('utf-8') + space4 + addonString(201).encode('utf-8') + space + "4",'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%a1%d7%a8%d7%98%d7%99%d7%9d%20(37)&url=genre%3dkids%26genreId%3d7449',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300',addonString(189).encode('utf-8'),'1')
	'''סרטים מצוירים בעברית / באנגלית 2'''
	addDir(addonString(11).encode('utf-8') + space + addonString(200).encode('utf-8') + space4 + addonString(201).encode('utf-8') + space + "5",'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%9e%d7%a9%d7%a4%d7%97%d7%94%20%d7%95%d7%99%d7%9c%d7%93%d7%99%d7%9d%20(42)&url=genre%3dmovies%26genreId%3d6261',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300',addonString(110).encode('utf-8'),'1')
	'''---------------------------'''
	
	'''plugin.video.10qtv'''
	if General_TrustedOnly == "false": addDir('[COLOR=Red]' + addonString(11).encode('utf-8') + space + "(10Q)" + '[/COLOR]','plugin://plugin.video.10qtv/?mode=6&name=אנימציה&url=http://www.10q.tv/board/filmy/animciha/5',8,'http://mirror.cinosure.com/superrepo/v5/addons/plugin.video.10qtv/icon.png',addonString(110).encode('utf-8'),'1')
	if General_TrustedOnly == "false": addDir('[COLOR=Red]' + addonString(11).encode('utf-8') + space + "(10Q)" + '[/COLOR]','plugin://plugin.video.10qtv/?mode=6&name=אנימציה&url=http://www.10q.tv/board/filmy/mshfhha/17',8,'http://mirror.cinosure.com/superrepo/v5/addons/plugin.video.10qtv/icon.png',addonString(110).encode('utf-8'),'1')
	'''---------------------------'''

	setView('', '50')
	
def CATEGORIES6(admin):
	'''ערוץ לולי'''
	addDir(addonString(33).encode('utf-8'),'UCcYc90JDakyeXGeZgPL1ejA',9,'http://yt3.ggpht.com/-n8_yk3MKYEk/AAAAAAAAAAI/AAAAAAAAAAA/0lOK__EwCtg/s88-c-k-no/photo.jpg',addonString(133).encode('utf-8'),'1')
	'''תכנים לפעוטות בעברית 1'''
	addDir(addonString(46).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "1",'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%a4%d7%a2%d7%95%d7%98%d7%95%d7%aa%20(46)&url=genre%3dkids%26genreId%3d7448',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300',addonString(110).encode('utf-8'),'1')
	'''בייבי אוריינטל'''
	addDir(addonString(28).encode('utf-8'),'PLpnRNlRK18UaUnOabh_ZysDsOY3QLvjkd',13,addonMediaPath + "19.jpg",addonString(110).encode('utf-8'),'1')
	'''בייבי איינשטיין'''
	addDir(addonString(20).encode('utf-8'),'PLlBpB13l5PDCndYQPS4PHw5ElfKZMhgCE',13,'http://d202m5krfqbpi5.cloudfront.net/books/1170326163l/46377.jpg',addonString(120).encode('utf-8'),'1') #TerrapinStation5
	'''ערוץ בייבי'''
	addDir(addonString(31).encode('utf-8'),'UCj10fKNd5h64J_M9YIQu0Zw',9,'http://yt3.ggpht.com/-RYFi0L82fh4/AAAAAAAAAAI/AAAAAAAAAAA/1hhzmsuRybc/s88-c-k-no/photo.jpg',addonString(131).encode('utf-8'),'1')
	'''לולה בייבי'''
	addDir(addonString(54).encode('utf-8'),'UCOYUFFxT50nvDaRj5Mn5XNg',9,'http://yt3.ggpht.com/-C9HFu_35bmk/AAAAAAAAAAI/AAAAAAAAAAA/O5-pgwvceRI/s88-c-k-no/photo.jpg',addonString(154).encode('utf-8'),'1')
	'''---------------------------'''
	setView('', '50')
	
def CATEGORIES7(admin):
	'''יובל המבולבל'''
	addDir(addonString(29).encode('utf-8'),'UC0r3m54hCOvyG47jzz08X2Q',9,'http://yt3.ggpht.com/-FHcf2Rxu08A/AAAAAAAAAAI/AAAAAAAAAAA/dxzE2ng3uXI/s88-c-k-no/photo.jpg',addonString(129).encode('utf-8'),'1')
	'''ערוץ הופ!'''
	addDir(addonString(32).encode('utf-8'),'UClZXqxeY540_Epab3WDHFGw',9,'http://yt3.ggpht.com/-A6Z6Bj0Y5os/AAAAAAAAAAI/AAAAAAAAAAA/k-1dO4Dm0m8/s88-c-k-no/photo.jpg',addonString(132).encode('utf-8'),'1')
	'''הופ ילדות ישראלית'''
	addDir(addonString(35).encode('utf-8'),'UCfNjGgy-3XfTzgWoGMt_QOw',9,'http://yt3.ggpht.com/-9bhXN_82zr8/AAAAAAAAAAI/AAAAAAAAAAA/AkRUBufsblk/s88-c-k-no/photo.jpg',addonString(135).encode('utf-8'),'1')
	'''ניק ג'וניור ישראל'''
	addDir(addonString(64).encode('utf-8'),'UCQWDQwBdFVOPjvBy6mgqUQQ',9,'http://yt3.ggpht.com/-jsb5s9cfdsk/AAAAAAAAAAI/AAAAAAAAAAA/pgREig-fcTE/s88-c-k-no/photo.jpg',addonString(164).encode('utf-8'),'1')
	'''---------------------------'''
	
	'''קטנטנים בעברית 1'''
	addDir(addonString(47).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "1",'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%97%d7%93%d7%a9%d7%99%d7%9d%20(20)&url=genre%3dkids%26genreId%3d7623',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300',addonString(110).encode('utf-8'),'1')
	'''קטנטנים בעברית 2'''
	#addDir(addonString(47).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "2",'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%97%d7%99%d7%a0%d7%95%d7%9b%d7%99%20(34)&url=genre%3dkids%26genreId%3d7452',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300',addonString(110).encode('utf-8'),'1')
	'''קטנטנים בעברית 3'''
	#addDir(addonString(47).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "3",'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%94%d7%a4%d7%a2%d7%9c%d7%94%20(4)&url=genre%3dkids%26genreId%3d7453',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300',addonString(110).encode('utf-8'),'1')
	'''קטנטנים בעברית 4'''
	addDir(addonString(47).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "4",'UC0GgioZ1XWa9xNJJH66h7rg',9,'http://yt3.ggpht.com/-2NPlgdL7mU8/AAAAAAAAAAI/AAAAAAAAAAA/ch9GzL2fOlM/s88-c-k-no/photo.jpg',addonString(136).encode('utf-8'),'1')
	'''קטנטנים בעברית 5'''
	addDir(addonString(47).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "5",'plugin://plugin.video.wallaNew.video/?mode=1&module=nickjr&name=ניקלאודיון גוניור&url=http://nickjr.walla.co.il/',8,'http://www.imanoga.co.il/wp-content/uploads/2012/06/646457567.jpg',addonString(110).encode('utf-8'),'1')
	'''---------------------------'''
	'''הנסיכה סופייה'''
	#addDir(addonString(46).encode('utf-8'),'',46,addonMediaPath + "46.png",addonString(146).encode('utf-8'),'1')
	addDir(addonString(67).encode('utf-8') + space + addonString(200).encode('utf-8'),'disneyjuniorisrael',9,'http://upload.wikimedia.org/wikipedia/he/a/a4/%D7%94%D7%A0%D7%A1%D7%99%D7%9B%D7%94_%D7%A1%D7%95%D7%A4%D7%99%D7%94.png',addonString(167).encode('utf-8'),'1')
	'''---------------------------'''
	'''ערוץ החיות באנגלית'''
	addDir(addonString(65).encode('utf-8') + space + addonString(201).encode('utf-8'),'UCS6hLNMMXi77SajUIvKGx5g',9,'http://yt3.ggpht.com/-9wTC-JCukjc/AAAAAAAAAAI/AAAAAAAAAAA/EqtzN1DW6HA/s88-c-k-no/photo.jpg',addonString(165).encode('utf-8'),'1')
	'''סי בייביס באנגלית'''
	addDir(addonString(63).encode('utf-8') + space + addonString(201).encode('utf-8'),'UC0fXNmjDoC7ckPyT6qM8Urw',9,'http://yt3.ggpht.com/-lrofuJsz1c8/AAAAAAAAAAI/AAAAAAAAAAA/8YJ0rAktf_o/s88-c-k-no/photo.jpg',addonString(163).encode('utf-8'),'1')
	'''רחוב סומסום באנגלית'''
	addDir(addonString(62).encode('utf-8') + space + addonString(201).encode('utf-8'),'UCoookXUzPciGrEZEXmh4Jjg',9,'http://yt3.ggpht.com/-Udx0C3ZTHUg/AAAAAAAAAAI/AAAAAAAAAAA/3BE1yYHQccs/s88-c-k-no/photo.jpg',addonString(162).encode('utf-8'),'1')
	'''יו-גאבה-גאבה באנגלית'''
	addDir(addonString(60).encode('utf-8') + space + addonString(201).encode('utf-8'),'UCxezak0GpjlCenFGbJ2mpog',9,'http://yt3.ggpht.com/-DCqlRFygCMs/AAAAAAAAAAI/AAAAAAAAAAA/OmWJ9YLZviE/s88-c-k-no/photo.jpg',addonString(160).encode('utf-8'),'1')
	'''---------------------------'''
	setView('', '50')
	
def CATEGORIES8(admin):
	'''ערוץ הילדים'''
	addDir(addonString(15).encode('utf-8') + space + "1",'UCOFp2_GttW3ljCuOc7r4l7g',9,'http://yt3.ggpht.com/-87JARv-G_rg/AAAAAAAAAAI/AAAAAAAAAAA/X9aVp9A1UiQ/s88-c-k-no/photo.jpg',addonString(150).encode('utf-8'),'1')
	'''---------------------------'''
	'''חינוכית 1'''
	addDir(addonString(39).encode('utf-8') + space + "1",'23tv',9,addonMediaPath + "39.png",addonString(139).encode('utf-8'),'1')
	'''חינוכית 2'''
	addDir(addonString(39).encode('utf-8') + space + "2",'UCYFLZdLRZGnmKQBH6RB8IjA',9,addonMediaPath + "39.png",addonString(139).encode('utf-8'),'1')
	'''חינוכית 3'''
	addDir(addonString(39).encode('utf-8') + space + "3",'UC_fUfLFo31WTFZPxgr1EcLA',9,addonMediaPath + "39.png",addonString(139).encode('utf-8'),'1')
	'''---------------------------'''
	
	setView('', '50')
	
def CATEGORIES9(admin):
	'''קטנטנים בהולנדית 1'''
	addDir(addonString(47).encode('utf-8') + space + addonString(202).encode('utf-8') + space + "1",'UCMf-gZNpJSPq80r9e22wl9A',9,'http://yt3.ggpht.com/-BXNeRxPOFpU/AAAAAAAAAAI/AAAAAAAAAAA/3DZSjgkhfJM/s88-c-k-no/photo.jpg',addonString(110).encode('utf-8'),'1')
	'''---------------------------'''
	'''קטנטנים באוקראינית 1'''
	addDir(addonString(47).encode('utf-8') + space + addonString(203).encode('utf-8') + space + "1",'UCZAL3xoDj13SeJGTFhq00Tw',9,'http://yt3.ggpht.com/-TrrOJ-NiNys/AAAAAAAAAAI/AAAAAAAAAAA/lhx315yY5gs/s88-c-k-no/photo.jpg',addonString(110).encode('utf-8'),'1')
	'''---------------------------'''
	'''שירים בצרפתית 1'''
	addDir(addonString(57).encode('utf-8') + space + addonString(204).encode('utf-8') + space + "1",'comptines',9,'https://yt3.ggpht.com/-MT6ThcO_qNI/AAAAAAAAAAI/AAAAAAAAAAA/GDibk7v0-FA/s100-c-k-no/photo.jpg',addonString(110).encode('utf-8'),'1')
	'''---------------------------'''
	'''שירים ברוסית 1'''
	addDir(addonString(57).encode('utf-8') + space + addonString(205).encode('utf-8') + space + "1",'PLJgmMSdWwadtTK4JzHhl5N5YR49ZVcGTK',13,'http://www.mapsofworld.com/images/world-countries-flags/russian-federation-flag.gif',addonString(110).encode('utf-8'),'1')
	'''---------------------------'''
	
	setView('', '50')
	
def CATEGORIES3(admin):
	setView('', '50')

def CATEGORIES21(admin):
	'''הופעות חיות'''
	YOULink('גיגיגיגונת קלטת ילדים', 'tKDm79jqRcI', 'http://erezdvd.co.il/sites/default/files/imagecache/product_full/products/369504.jpg','')
	YOULink('לירן הקוסם מהאגדות', 'kNS4xMdPIos', 'http://i.ytimg.com/vi/5gN4SMO8EfE/maxresdefault.jpg',addonString(110).encode('utf-8'))
	YOULink('גינת השטוזים', 'o20-0VygrsE','http://www.avivim-hafazot.co.il/uploadimages/188382.jpg',addonString(110).encode('utf-8'))
	#YOULink('מיקי ופונץ', '9rGV96uhqPw',addonString(110).encode('utf-8'))
	YOULink('יניב המגניב', 'f9s_aunAElY', 'http://img.mako.co.il/2013/07/22/kids_yaniv_hamagniv_.jpg',addonString(110).encode('utf-8'))
	YOULink('בילבי', 'sHMEnVpDJR8', 'http://i.ytimg.com/vi/2mxOiPccxOs/maxresdefault.jpg',addonString(110).encode('utf-8'))
	YOULink('עליבאבא וארבעים השודדים', 'gxgvTe3kPGY', 'http://i.ytimg.com/vi/EMtHOrNBXKU/hqdefault.jpg',addonString(110).encode('utf-8'))
	YOULink('שורום זורום', '9rGV96uhqPw', 'http://www.tipa.co.il/images/contentImages/images/dvd/shorom.jpg',addonString(110).encode('utf-8'))
	YOULink('אי המטמון', 'Cmd0VxJmmBA', 'http://images.mouse.co.il/storage/0/e/ggg--Matmon.jpg',addonString(110).encode('utf-8'))
	YOULink('שלגיה והצייד', '0rPEJ-kD1dc', 'http://www.dossinet.me/coverage_pics/1b5d66af0d230ff716d50f07fd6defc0.jpg',addonString(110).encode('utf-8'))
	YOULink('עליסה בארץ הפלאות', 'Cmd0VxJmmBA', 'http://images.mouse.co.il/storage/3/0/b--alice.jpg',addonString(110).encode('utf-8'))	
	YOULink('גינת הפלאים של רינת', 'PUL2C9mEAKQ', 'http://www.booknet.co.il/imgs/site/prod/7290013274434b.jpg',addonString(110).encode('utf-8'))
	#YOULink('משחקי הפסטיגל 2015', 'd2953353ab9e8', 'http://www.ligdol.co.il/Upload/pestigal2014_poster.jpg',addonString(110).encode('utf-8'))
	#YOULink('גאליס המופע', 'a6f7eacf00f28', 'http://up389.siz.co.il/up1/znmi3xqzndjg.jpg',addonString(110).encode('utf-8'))
	YOULink('דוד חיים', 'a5c04e985cccb', 'http://www.myfirsthomepage.co.il/mfhp/tv/image/haim1.jpg',addonString(110).encode('utf-8'))
	YOULink('2 דוד חיים', 'X3j6mQ9VgLI', 'http://www.nmcunited.co.il/Images/dynamic/movies/Dod-Haim2.jpg',addonString(110).encode('utf-8'))
	YOULink('ילד פלא', 'e5c134277697c', 'http://tzavta.co.il/images/siteCont/Content_233.2463.jpg',addonString(110).encode('utf-8'))
	YOULink('הפיגמות - המחזמר', 'YOs5zhvXUf8', 'http://img.tapuz.co.il/forums/22604478.jpg',addonString(110).encode('utf-8'))
	YOULink('האסופית', 'i5yQxLraENk', 'http://static.flatplanet.tv/movies/112055.jpg',addonString(110).encode('utf-8'))
	YOULink('מרקו', 'XgnCNCt71d8', 'http://www.ykp.co.il/cd_halev.jpg',addonString(110).encode('utf-8'))
	YOULink('רובין הוד', '6nZk0H89jDQ', 'http://erezdvd.co.il/sites/default/files/imagecache/product_full/products/14810.jpg',addonString(110).encode('utf-8'))
	YOULink('ספר הגונגל', 'TlWVoNz_B3o', 'http://images.mouse.co.il/storage/3/7/ggg--book20090908_2343750_0..jpg',addonString(110).encode('utf-8'))
	YOULink('פיטר פן - הראל סקעת', 'gTuMB5sz8pY', 'http://i48.tinypic.com/f5ceuq.jpg',addonString(110).encode('utf-8'))
	YOULink('אלאדין ויסמין', 'sVCYRfk3Wcc', 'http://www.tipa.co.il/images/contentImages/images/TV/al.jpg',addonString(110).encode('utf-8'))
	YOULink('סינדרלה - בר רפאלי', 'snr9wxyEzpA', 'http://afisha.israelinfo.ru/pictures/19949.jpg',addonString(110).encode('utf-8'))
	YOULink('תום סוייר והקלברי פין', 'kbzPyZV3cck', 'https://i.ytimg.com/vi/7w75Dc0ofT0/hqdefault.jpg',addonString(110).encode('utf-8'))
	YOULink('לא יאומן כי יסופר', '-ihwgBW3sVs', 'http://simania.co.il/bookimages/covers90/906630.jpg',addonString(110).encode('utf-8'))
	YOULink('עמי ותמי', '8d6a2e7a3cd54', 'http://www.tivon.co.il/vault/Zoar/amitami-B.jpg',addonString(110).encode('utf-8'))
	#YOULink('גיבורי האור 2', 'http://shorte.st/strackable/b4e6b9af7b276c4c1d8fa25950f5ef81/vod.k11.co.il/1/1/http://www.novamov.com/video/8d6a2e7a3cd54',addonString(110).encode('utf-8'))
	YOULink('גיבורי האור', 'nwlo00FHCRc', 'http://www.booknet.co.il/imgs/site/prod/7294276219850b.jpg',addonString(110).encode('utf-8'))
	YOULink('גיבורי האור - הדור הבא', '8422a40355d7c', 'http://4.bp.blogspot.com/-RmcNjqbNlAM/U99_hg0AyrI/AAAAAAAAD9Q/HJWmitLdwWw/s1600/%D7%92%D7%99%D7%91%D7%95%D7%A8%D7%99+%D7%94%D7%90%D7%95%D7%A8+%D7%97%D7%A0%D7%95%D7%9B%D7%94+2014+%D7%9B%D7%A8%D7%98%D7%99%D7%A1%D7%99%D7%9D.jpg',addonString(110).encode('utf-8'))
	YOULink('101 כלבים דלמטים', '020c8c5ebfe70', 'http://www.pashbar.co.il/pictures/show_big_0712083001297352431.jpg',addonString(110).encode('utf-8'))
	YOULink('יובל המבולבל - המסע אל הכוכב', '6UrdISJBBC4', 'http://www.avivim-hafazot.co.il/uploadimages/642148.jpg',addonString(110).encode('utf-8'))
	YOULink('יובל המבולבל - מסביב לזמן', '920d18542f05a', 'http://i.ytimg.com/vi/1Gsa64WsXmA/maxresdefault.jpg',addonString(110).encode('utf-8'))
	YOULink('יובל המבולבל - כוכב המשאלות', 'C2Rm4IuVWNQ', 'http://www.ashops.co.il/Shops/shop_271/products/557/picture_317.jpg',addonString(110).encode('utf-8'))
	YOULink('יובל המבולבל - נווה עצלנות', '99c23afc06d1a', 'http://3.bp.blogspot.com/-E10YgfqBuBc/VHMtJRkqz3I/AAAAAAAAZAI/3tjwSCO3MQo/s1600/3432d1bb8951834d8c2c74446f069d4b.jpg',addonString(110).encode('utf-8'))
	YOULink('הדרקון המתוק שלי', 'd6b387a31efcf', 'http://www.heichalpt.co.il/wp-content/uploads/2014/10/%D7%94%D7%93%D7%A8%D7%A7%D7%95%D7%9F-%D7%94%D7%9E%D7%AA%D7%95%D7%A7-%D7%A9%D7%9C%D7%99.jpg',addonString(110).encode('utf-8'))
	
	setView('', '58')
def ListLive(url):
	link=OPEN_URL(url)
	link=unescape(link)
	#print link
	matches1=re.compile('pe=(.*?)#',re.I+re.M+re.U+re.S).findall(link)
	#print str(matches1[0]) + '\n'
	for match in matches1 :
		#print "match=" + str(match)
		match=match+'#'
		if match.find('playlist') != 0 :
			regex='name=(.*?)URL=(.*?)#'
			matches=re.compile(regex,re.I+re.M+re.U+re.S).findall(match)
			#print str(matches)
			for name,url in  matches:
				thumb=''
				i=name.find('thumb')
				if i>0:
					thumb=name[i+6:]
					name=name[0:i]
		#print url
				addLink('[COLOR yellow]'+ name+'[/COLOR]',url,thumb,'')  
			
		else:
			regex='name=(.*?)URL=(.*?).plx'
			matches=re.compile(regex,re.I+re.M+re.U+re.S).findall(match)
			for name,url in matches:
				url=url+'.plx'
				if name.find('Radio') < 0 :
					addDir('[COLOR blue]'+name+'[/COLOR]',url,2,'','','1')
					
# reads  user names from my subscriptions 

def ShowFromUser(user):
	murl='https://gdata.youtube.com/feeds/api/users/'+user+'/shows?alt=json&start-index=1&max-results=50&v=2'
	resultJSON = json.loads(OPEN_URL(murl))
	shows=resultJSON['feed']['entry']
	#print shows[1]
	hasNext= True
	while hasNext:
		shows=resultJSON['feed']['entry']
		for  i in range (0, len(shows)) :
			showApiUrl=shows[i]['link'][1]['href']
			showApiUrl=showApiUrl[:-4]+'/content?v=2&alt=json'
			showName=shows[i]['title']['$t'].encode('utf-8')
			image= shows[i]['media$group']['media$thumbnail'][-1]['url']
			addDir(showName,showApiUrl,14,image,'','1')
		hasNext= resultJSON['feed']['link'][-1]['rel'].lower()=='next'
		if hasNext:
			resultJSON = json.loads(OPEN_URL(resultJSON['feed']['link'][-1]['href']))
		
def SeasonsFromShow(showApiUrl):
	#print showApiUrl
	resultJSON = json.loads(OPEN_URL(showApiUrl))
	seasons=resultJSON['feed']['entry']
	for i in range (0, len(seasons)) :
		#print seasons[i].keys()
		#print seasons[i]['title']['$t']
		for index,item in  enumerate(seasons[i]['gd$feedLink']) :
			if item['countHint'] !=0:
				resultJSON = json.loads(OPEN_URL( seasons[i]['gd$feedLink'][index]['href']+'&alt=json'))
				for  j in range (0, len(resultJSON['feed']['entry'])) :
					title= str(resultJSON['feed'][u'entry'][j][ u'media$group'][u'media$title'][u'$t'].encode('utf-8')).decode('utf-8')
					thumb =str(resultJSON['feed'][u'entry'][j][ u'media$group'][u'media$thumbnail'][-1][u'url'])
					episode_num=resultJSON['feed']['entry'][j]['yt$episode']['number']
					url= resultJSON['feed']['entry'][j]['link'][0]['href']
					match=re.compile('www.youtube.com/watch\?v\=(.*?)\&f').findall(url)
					#finalurl="plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid="+match[0]+"&hd=1"
					finalurl="plugin://plugin.video.youtube/play/?video_id="+match[0]+"&hd=1"
					addLink(title+' '+episode_num ,finalurl,thumb,'')

def YOUsubs(user):
	murl='http://gdata.youtube.com/feeds/api/users/'+user+'/subscriptions?alt=json&start-index=1&max-results=50'
	resultJSON = json.loads(OPEN_URL(murl))
	feed=resultJSON['feed']['entry']
	for i in range (0, len(feed)) :
		image=str(feed[i]['media$thumbnail']['url'])
		name = feed[i]['title']['$t'].replace('Activity of:','').encode('utf-8')
		url=feed[i]['yt$channelId']['$t'].encode('utf-8')
		addDir(name,url,9,image,'1','1')
	setView('', 'default')

#list the links from  usernames based on mash23 + improvment
def YOUList(name, url, iconimage, desc, num):
	returned = ""
	playlists=PlaylistsFromUser(url)
	
	if General_TVModeDialog == "true":
		list = [41,42,43,44,45,46,47,48,49]
		for i in list:
			i = str(i)
			#if admin: print printfirst + "YOUList-General_TVModeDialog" + space2 + "i" + space2 + i + space + containerfolderpath
			if "&mode=" + i + "&" in containerfolderpath:
				countl = 0
				for space in playlists:
					countl += 1
				countlS = str(countl)
				if playlists==[] or countl > 1:  #no playlists on  youtube channel
					'''------------------------------
					---PLAYLIST->-1------------------
					------------------------------'''
					returned = dialogyesno(addonString(300).encode('utf-8'),addonString(301).encode('utf-8'))
					if returned == "ok": TvMode(url)
					'''---------------------------'''
				
	if General_TVModeDialog != "true" or returned != "ok":
		if num == "" or num == None: num = '1'
		numN = int(num)
		num3N = 1
		'''---------------------------'''
		murl='http://gdata.youtube.com/feeds/api/users/'+url+'/uploads?&max-results=50&start-index='+num
		link=OPEN_URL(murl)
		'''ניגון מהיר'''
		addDir('[COLOR=Yellow]' + addonString(5).encode('utf-8') + '[/COLOR]',murl,11,addonMediaPath + "190.png",addonString(190).encode('utf-8'),'1')
		match=re.compile("http\://www.youtube.com/watch\?v\=([^\&]+)\&.+?<media\:descriptio[^>]+>([^<]+)</media\:description>.+?<media\:thumbnail url='([^']+)'.+?<media:title type='plain'>(.+?)/media:title>").findall(link)
		if url=='TerrapinStation5' :
			addDir(addonString(20).encode('utf-8') + '[COLOR=Yellow]' + addonString(7).encode('utf-8') + space2 + '[/COLOR]','PLlBpB13l5PDCndYQPS4PHw5ElfKZMhgCE',12,'http://d202m5krfqbpi5.cloudfront.net/books/1170326163l/46377.jpg','',num)
		else:		
			for playlistid,title,thumb, in playlists:
				'''רשימת השמעה'''
				if num == '1':
					num3N += 1
					numN += 1
					
					#num = str(numN)
					addDir('[COLOR=Yellow2]' + title + '[/COLOR]',playlistid,12,thumb,addonString(192).encode('utf-8'),num)
					#addDir(title + '[COLOR=Yellow]' + addonString(7).encode('utf-8') + space2 + '[/COLOR]',playlistid,12,thumb,'',num)
					#print playlistid
		for nurl,desc,thumb,rname in match:
			'''מדיה'''
			if (num == '1' and num3N < 8) or (num != '1' and num3N < 40): 
				rname=rname.replace('<','')
				num3N += 1
				numN += 1
				#num = str(numN)
				YOULink(rname, nurl, thumb, desc)
				#YOULink(rname, nurl, thumb, desc)
		
		'''עוד תוצאות'''
		if (num == '1' and num3N <= 8): num2N = int(num) + num3N
		else: num2N = int(num) + 40
		num2 = str(num2N)
		num3 = str(num3N)

		if admin or num == '1' or num3N == 40: addDir('[COLOR=Yellow]' + addonString(6).encode('utf-8') + '[/COLOR]',url,9,addonMediaPath + "191.png",addonString(191).encode('utf-8'),num2)
		setView('', 'default')
		
		
		if admin: print printfirst + "YOUList" + " " + "num/2/3" + space2 + num + " / " + num2 + " / " + num3
	


def YOULink(mname, url, thumb, desc):
	ok=True
	#url = "plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid="+url
	url = "plugin://plugin.video.youtube/play/?video_id="+url
	liz=xbmcgui.ListItem(mname, iconImage="DefaultVideo.png", thumbnailImage=thumb)
	liz.setInfo( type="Video", infoLabels={ "Title": mname, "Plot": desc } )
	liz.setProperty("IsPlayable","true")
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
	return ok

def TvMode(user):
	playlists=PlaylistsFromUser(user)
	if playlists==[]:  #no playlists on  youtube channel
		dialog = xbmcgui.Dialog()
		ok = dialog.ok('HTPT', addonString(302).encode('utf-8'))
		CATEGORIES()
	#print "str is" +  str(random.choice(playlists)[0])
	else:
		count = 0
		while count < 10 and xbmc.Player().isPlayingVideo() and not xbmc.abortRequested:
			xbmc.sleep(100)
			count += 1
			if count == 1: xbmc.executebuiltin('Action(Stop)')
		pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
		pl.clear()
		dp= xbmcgui.DialogProgress()
		dp.create('HTPT','כי לא הכל מובן מאליו')
		'''PlayListGain/2/3: url / duplicated / deleted'''
		PlayListGain = ""
		PlayListGain2 = 0
		PlayListGain3 = ""
		count = 0
		for i in range (1,51):  #50  RANDOM PROGRAMS IN TV MODE
			count += 1
			countS = str(count)
			if count < 2: dp.update(i*5, addonString(303).encode('utf-8'), "")
			else: dp.close()
			#print str (playlists)
			ran=str(random.choice(playlists)[0])
			finalurl,title,thumb,desc= RanFromPlayList(ran)
			liz = xbmcgui.ListItem(title, iconImage="DefaultVideo.png", thumbnailImage=thumb)
			liz.setInfo( type="Video", infoLabels={ "Title": title} )
			liz.setProperty("IsPlayable","true")
			
			if not finalurl in PlayListGain and not "Deleted video" in title: pl.add(finalurl, liz)
			elif "Deleted video" in title: PlayListGain3 = PlayListGain3 + space + finalurl
			else:
				PlayListGain2 = PlayListGain2 + 1
				if PlayListGain2 > 10:
					playlistlength = xbmc.getInfoLabel('Playlist.Length(video)')
					notification(addonString(305).encode('utf-8') % (playlistlength, PlayListGain2),addonString(306).encode('utf-8'),"",4000)
					sys.exit()
			PlayListGain = PlayListGain + space + finalurl
			if count == 1:
				xbmc.Player(xbmc.PLAYER_CORE_MPLAYER).play(pl)
				count2 = 0
				while count2 < 10 and not xbmc.Player().isPlayingVideo() and not xbmc.abortRequested:
					xbmc.sleep(500)
					count2 += 1
					xbmc.sleep(500)
			elif not xbmc.Player().isPlayingVideo(): sys.exit(1)
		playlistlength = xbmc.getInfoLabel('Playlist.Length(video)')
		playlistlengthN = int(playlistlength)
		if xbmc.Player().isPlayingVideo() and playlistlengthN > 5:
		    PlayListGain2S = str(PlayListGain2)
		    notification(addonString(305).encode('utf-8') % (playlistlength, PlayListGain2S),addonString(306).encode('utf-8'),"",4000)
		    print printfirst + "PlayListGain_" + countS + space + PlayListGain2S + space + "Duplicated Not Added!"
			#xbmc.Player(xbmc.PLAYER_CORE_MPLAYER).play(pl)
	
	print printfirst + "TvMode" + space2 + "count" + space2 + countS + space + "PlayListGain2S" + space + PlayListGain2S + space + "PlayListGain3" + space2 + PlayListGain3
		
def PlaylistsFromUser(user):
	url='https://gdata.youtube.com/feeds/api/users/'+user+ '/playlists?alt=json&max-results=50'
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	prms=json.loads(link)
	TotalPlaylists=int(prms['feed'][u'openSearch$totalResults'][u'$t'])
	j=1
	h=1
	lst=[]
	pages= (TotalPlaylists//50)  +1
	while  j<=pages :
		link=OPEN_URL(url)
		prms=json.loads(link)
		i=0
		while h<TotalPlaylists +1  and i<50:
			thumb=''
			try:
				playlistid=str(prms['feed'][u'entry'][i][u'yt$playlistId'][u'$t'])
				title=str(prms['feed'][u'entry'][i][u'title'][u'$t'].encode('utf-8'))
				thumb=str(prms['feed'][u'entry'][i][u'media$group'][u'media$thumbnail'][2][u'url'])
			except:
				pass
			i=i+1
			h=h+1
			lst.append((playlistid,title,thumb))
		j=j+1
		url='https://gdata.youtube.com/feeds/api/users/'+user+ '/playlists?alt=json&max-results=50&start-index='+str (j*50-49)
	return lst

def ListPlaylist(playlistid): 
	url='https://gdata.youtube.com/feeds/api/playlists/'+playlistid+'?alt=json&max-results=50'
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	prms=json.loads(link)

	pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
	pl.clear()
	playlist = []
	numOfItems=int(prms['feed'][u'openSearch$totalResults'][u'$t']) #if bigger than 50 needs  to add more result
	j=1
	h=1
	pages = (numOfItems //50)+1
	'''ניגון מהיר'''
	addDir('[COLOR=Yellow]' + addonString(5).encode('utf-8') + '[/COLOR]',playlistid,12,addonMediaPath + "190.png",addonString(190).encode('utf-8'),'1')
	while  j<= pages:
		link=OPEN_URL(url)
		prms=json.loads(link)
		i=0
		while i< 50  and  h<numOfItems:
			#print "i===" +str(i) +"numOfItems="+ str(numOfItems)
			try:
				urlPlaylist= str(prms['feed'][u'entry'][i][ u'media$group'][u'media$player'][0][u'url'])
				match=re.compile('www.youtube.com/watch\?v\=(.*?)\&f').findall(urlPlaylist)
				#finalurl="plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid="+match[0]+"&hd=1"
				finalurl="plugin://plugin.video.youtube/play/?video_id="+match[0]+"&hd=1"
				title= str(prms['feed'][u'entry'][i][ u'media$group'][u'media$title'][u'$t'].encode('utf-8')).decode('utf-8')
				thumb =str(prms['feed'][u'entry'][i][ u'media$group'][u'media$thumbnail'][2][u'url'])
				desc = str(prms['feed'][u'entry'][i][ u'media$group'][u'media$description'][u'$t'].encode('utf-8')).decode('utf-8')
				addLink(title,finalurl,thumb,desc)
			except:
				pass
			i=i+1
			h=h+1

		j=j+1
		url='https://gdata.youtube.com/feeds/api/playlists/'+playlistid+'?alt=json&max-results=50&start-index='+str (j*50-49)
	

def YOULinkAll(url):
	dp = xbmcgui.DialogProgress()
	dp.create(addonName ,addonString(4).encode('utf-8'))
	dp.update(0)
	pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
	pl.clear()
	link=OPEN_URL(url)
	match=re.compile("http\://www.youtube.com/watch\?v\=([^\&]+)\&.+?<media\:descriptio[^>]+>([^<]+)</media\:description>.+?<media\:thumbnail url='([^']+)'.+?<media:title type='plain'>(.+?)/media:title>").findall(link)
	playlist = []
	nItem = len(match)

	for nurl,desc,thumb,rname in match:
		rname=rname.replace('<','')
		#finalurl= "plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid="+nurl+"&hd=1"
		finalurl= "plugin://plugin.video.youtube/play/?video_id="+nurl+"&hd=1"
		liz = xbmcgui.ListItem(rname, iconImage="DefaultVideo.png", thumbnailImage=thumb)
		liz.setInfo( type="Video", infoLabels={ "Title": rname, "Plot": desc}) #NEW UNTESTED!!! (PLOT...)
		liz.setProperty("IsPlayable","true")
		playlist.append((finalurl ,liz))
		progress = len(playlist) / float(nItem) * 100  
		dp.update(int(progress), addonString(4).encode('utf-8') + "...",rname)
		if dp.iscanceled():
			return

	dp.close()
	for blob ,liz in playlist:
		try:
			if blob:
				pl.add(blob,liz)
		except:
			pass

	xbmc.Player(xbmc.PLAYER_CORE_MPLAYER).play(pl)

def RanFromPlayList(playlistid):
	url='https://gdata.youtube.com/feeds/api/playlists/'+playlistid+'?alt=json&max-results=50'
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	prms=json.loads(link)
	numOfItems=int(prms['feed'][u'openSearch$totalResults'][u'$t']) #if bigger than 50 needs  to add more result
	if numOfItems >1 :
		link=OPEN_URL(url)
		prms=json.loads(link)
		if numOfItems>49:
			numOfItems=49
		i=random.randint(1, numOfItems-1)
		#print str (len(prms['feed'][u'entry']))  +"and i="+ str(i)
		try:
			urlPlaylist= str(prms['feed'][u'entry'][i][ u'media$group'][u'media$player'][0][u'url'])
			match=re.compile('www.youtube.com/watch\?v\=(.*?)\&f').findall(urlPlaylist)
			#finalurl="plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid="+match[0]+"&hd=1"
			finalurl="plugin://plugin.video.youtube/play/?video_id="+match[0]+"&hd=1"
			title= str(prms['feed'][u'entry'][i][ u'media$group'][u'media$title'][u'$t'].encode('utf-8')).decode('utf-8')
			thumb =str(prms['feed'][u'entry'][i][ u'media$group'][u'media$thumbnail'][2][u'url'])
			#desc =str(prms['feed'][u'entry'][i][ u'media$group'][u'media$description'][2][u'url'])
			desc= str(prms['feed'][u'entry'][i][ u'media$group'][u'media$description'][u'$t'].encode('utf-8')).decode('utf-8')
		except :
			 return "","","",""  # private video from youtube
		'''liz = xbmcgui.ListItem(title, iconImage="DefaultVideo.png", thumbnailImage=thumb)
		liz.setInfo( type="Video", infoLabels={ "Title": title} )
		liz.setProperty("IsPlayable","true")
		pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
		pl.clear()
		pl.add(finalurl, liz)'''
		#xbmc.Player(xbmc.PLAYER_CORE_MPLAYER).play(pl)
		return finalurl,title,thumb,desc
	else:
		return "","","",""

def play_video(url):
	#xbmc.executebuiltin('PlayMedia(plugin://plugin.video.youtube/play/?video_id='+ url +')')
	#url='plugin://plugin.video.youtube/play/?video_id='+ url +''
	#link=OPEN_URL(url)
	#match=re.compile("http\://www.youtube.com/watch\?v\=([^\&]+)\&.+?<media\:descriptio[^>]+>([^<]+)</media\:description>.+?<media\:thumbnail url='([^']+)'.+?<media:title type='plain'>(.+?)/media:title>").findall(link)
	url='https://gdata.youtube.com/feeds/api/videos/'+ url +''
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	prms=json.loads(link)
	
	match=re.compile('www.youtube.com/watch\?v\=(.*?)\&f').url
	finalurl="plugin://plugin.video.youtube/play/?video_id="+match[0]+"&hd=1"
	title= str(prms['feed'][u'entry'][i][ u'media$group'][u'media$title'][u'$t'].encode('utf-8')).decode('utf-8')
	thumb =str(prms['feed'][u'entry'][i][ u'media$group'][u'media$thumbnail'][2][u'url'])
	description = str(prms['feed'][u'entry'][i][ u'media$group'][u'media$description'][u'$t'].encode('utf-8')).decode('utf-8')
	addLink(title,finalurl,thumb,description)
	#xbmc.Player(xbmc.PLAYER_CORE_MPLAYER).play(pl)
	
def PlayPlayList(playlistid):
	url='https://gdata.youtube.com/feeds/api/playlists/'+playlistid+'?alt=json&max-results=50'
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	prms=json.loads(link)

	playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
	playlist.clear()
	playlist1 = []
	numOfItems=int(prms['feed'][u'openSearch$totalResults'][u'$t']) #if bigger than 50 needs  to add more result
	
	j=1
	h=1
	pages = (numOfItems //50)+1
	while  j<= pages:
		link=OPEN_URL(url)
		prms=json.loads(link)
		i=0
		while i< 50  and  h<numOfItems :
			try:
				urlPlaylist= str(prms['feed'][u'entry'][i][ u'media$group'][u'media$player'][0][u'url'])
				match=re.compile('www.youtube.com/watch\?v\=(.*?)\&f').findall(urlPlaylist)
				#finalurl="plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid="+match[0]+"&hd=1"
				finalurl="plugin://plugin.video.youtube/play/?video_id="+match[0]+"&hd=1"
				title= str(prms['feed'][u'entry'][i][ u'media$group'][u'media$title'][u'$t'].encode('utf-8')).decode('utf-8')
				thumb =str(prms['feed'][u'entry'][i][ u'media$group'][u'media$thumbnail'][2][u'url'])
				liz = xbmcgui.ListItem(title, iconImage="DefaultVideo.png", thumbnailImage=thumb)
				liz.setInfo( type="Video", infoLabels={ "Title": title} )
				liz.setProperty("IsPlayable","true")
				playlist1.append((finalurl ,liz))
			except:
				pass
			i=i+1
			h=h+1

		j=j+1
		url='https://gdata.youtube.com/feeds/api/playlists/'+playlistid+'?alt=json&max-results=50&start-index='+str (j*50-49)
	random.shuffle(playlist1)
	for blob ,liz in playlist1:
		try:
			if blob:
				playlist.add(blob,liz)
		except:
			pass
	playlist.shuffle()

	xbmc.Player(xbmc.PLAYER_CORE_MPLAYER).play(playlist)

#https://gdata.youtube.com/feeds/api/users/polosoft/playlists (gets playlist fro, user) https://gdata.youtube.com/feeds/api/users/polosoft/playlists?alt=json
#https://gdata.youtube.com/feeds/api/playlists/PLN0EJVTzRDL_53Jz8bhZl4m3UtkY2btbV?max-results=50?alt=json  (gets items in playlist)
#https://gdata.youtube.com/feeds/api/playlists/PLN0EJVTzRDL_53Jz8bhZl4m3UtkY2btbV?max-results=50&alt=json

params=get_params()
url=None
name=None
mode=None
iconimage=None
desc=None
num=None

try:
	url=urllib.unquote_plus(params["url"])
except:
	pass
try:
	name=urllib.unquote_plus(params["name"])
except:
	pass
try:
	iconimage=urllib.unquote_plus(params["iconimage"])
except:
	pass
try:	
	mode=int(params["mode"])
except:
	pass
try:	
	num=urllib.unquote_plus(params["num"])
except:
	pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
   
'''------------------------------
---MODES-LIST--------------------
------------------------------'''
if mode==None or (url==None or len(url)<1) and mode < 40:
	CATEGORIES()
	#notification("Test",Addon_Version,"",2000)
	setAddon_Version(admin)
	repoCheck.UpdateRepo()
	if not os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'repository.xbmc-israel')):
		commonkids.downloader_israel("https://github.com/cubicle-vdo/xbmc-israel/raw/master/repo/repository.xbmc-israel/repository.xbmc-israel-1.0.4.zip", "", showProgress=False)
elif mode==41:       
	CATEGORIES1(admin)
elif mode==42:       
	CATEGORIES2(admin)
elif mode==421:       
	CATEGORIES21(admin)
elif mode==43:       
	CATEGORIES3(admin)
elif mode==44:       
	CATEGORIES4(admin)
elif mode==45:    
	CATEGORIES5(admin)
elif mode==46:       
	CATEGORIES6(admin)
elif mode==47:       
	CATEGORIES7(admin)
elif mode==48:       
	CATEGORIES8(admin)
elif mode==49:       
	CATEGORIES9(admin)
	
elif mode==1:
	#print ""+url
	Choose_series(url)
elif mode==2:
	series_land(url)
elif mode==3:
	play_episode(url)
elif mode==4:
	play_video(url)
elif mode==8:
	update_view(url)
elif mode==7:
	ListLive(url)
elif mode==9:
	YOUList(name, url, iconimage, desc, num)
elif mode==10:
	YOUsubs(url)
elif mode==11:
	YOULinkAll(url)
elif mode==12:
	PlayPlayList(url)
elif mode==13:
	ListPlaylist(url)
elif mode==14:       
	SeasonsFromShow(url)
elif mode==15:       
	CleanTheCache()
elif mode==16:       
	ShowFromUser(url)
elif mode==115:
	TvMode(url)
	
xbmcplugin.endOfDirectory(int(sys.argv[1]))