'''------------------------------
---shared_variables--------------
------------------------------'''
import xbmcaddon, sys, os
servicehtptPath          = xbmcaddon.Addon('service.htpt').getAddonInfo("path")
sharedlibDir = os.path.join(servicehtptPath, 'resources', 'lib', 'shared')
sys.path.insert(0, sharedlibDir)
from shared_variables import *
'''---------------------------'''

'''------------------------------
---script.htpt.homebuttons-------
------------------------------'''
getsetting         = xbmcaddon.Addon().getSetting
setsetting         = xbmcaddon.Addon().setSetting
addonName          = xbmcaddon.Addon().getAddonInfo("name")
addonString        = xbmcaddon.Addon().getLocalizedString
addonID          = xbmcaddon.Addon().getAddonInfo("id")
addonPath          = xbmcaddon.Addon().getAddonInfo("path")
addonVersion          = xbmcaddon.Addon().getAddonInfo("version")

printfirst = addonName + ": !@# "
'''---------------------------'''

addonMediaPath = addonPath + "/resources/media/"
#AddonID = 'plugin.video.htpt.kids'
#ADDON = xbmcaddon.Addon(id=AddonID)
#libDir = os.path.join(xbmc.translatePath("special://home/addons/"), addonID, 'resources', 'lib')
libDir = os.path.join(addonPath, 'resources', 'lib')
sys.path.insert(0, libDir)

General_AutoView = getsetting('General_AutoView')
General_TrustedOnly = getsetting('General_TrustedOnly')
General_TVModeDialog = getsetting('General_TVModeDialog')

Addon_Version = getsetting('Addon_Version')

'''------------------------------
---ON/OFF------------------------
------------------------------'''
OFF_1 = getsetting('OFF_1')
OFF_2 = getsetting('OFF_2')
OFF_3 = getsetting('OFF_3')
OFF_4 = getsetting('OFF_4')
OFF_5 = getsetting('OFF_5')
OFF_6 = getsetting('OFF_6')
OFF_7 = getsetting('OFF_7')
OFF_8 = getsetting('OFF_8')
OFF_9 = getsetting('OFF_9')
OFF_10 = getsetting('OFF_10')
OFF_11 = getsetting('OFF_11')
OFF_12 = getsetting('OFF_12')
OFF_13 = getsetting('OFF_13')
OFF_14 = getsetting('OFF_14')
OFF_15 = getsetting('OFF_15')
OFF_16 = getsetting('OFF_16')
OFF_17 = getsetting('OFF_17')
OFF_18 = getsetting('OFF_18')
OFF_19 = getsetting('OFF_19')
OFF_20 = getsetting('OFF_20')
OFF_21 = getsetting('OFF_21')
'''---------------------------'''




'''OTHERS BUTTONS'''
adultbutton = xbmc.getCondVisibility('Container(50).HasFocus(49)')
formatbutton = xbmc.getCondVisibility('Container(50).HasFocus(92)')
fixipbutton = xbmc.getCondVisibility('Container(50).HasFocus(116)')
trakttvbutton = xbmc.getCondVisibility('Container(50).HasFocus(94)')
sdarottvbutton = xbmc.getCondVisibility('Container(50).HasFocus(95)')
noobroombutton = xbmc.getCondVisibility('Container(50).HasFocus(96)')
premiumizebutton = xbmc.getCondVisibility('Container(50).HasFocus(97)')
movreelbutton = xbmc.getCondVisibility('Container(50).HasFocus(98)')
movreelbutton = xbmc.getCondVisibility('Container(50).HasFocus(98)')
realdebridbutton = xbmc.getCondVisibility('Container(50).HasFocus(99)')
userdataresetbutton = xbmc.getCondVisibility('Container(50).HasFocus(80)')
id60button = xbmc.getCondVisibility('Container(50).HasFocus(160)')
loginscreenbutton = (xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(100)'))
subsliderbutton = (xbmc.getCondVisibility('Window.IsVisible(DialogSubtitles.xml)') and xbmc.getCondVisibility('Control.HasFocus(73)'))
smartsearchbutton = (xbmc.getCondVisibility('Window.IsVisible(DialogSubtitles.xml)') and xbmc.getCondVisibility('Control.HasFocus(161)'))
#button = xbmc.getCondVisibility('Container(9000).HasFocus(?)')
#button = xbmc.getCondVisibility('Container(9000).HasFocus(?)')
#button = xbmc.getCondVisibility('Container(9000).HasFocus(?)')
#button = xbmc.getCondVisibility('Container(9000).HasFocus(?)')
'''SETTINGS'''
netsettingsbutton = (xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(108)')) or xbmc.getCondVisibility('Container(52).HasFocus(40)') or (xbmc.getCondVisibility('Window.IsVisible(Custom1170.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(10)'))

'''HELP'''
airplaybutton = xbmc.getCondVisibility('Container(50).HasFocus(1)')
messagebutton = xbmc.getCondVisibility('Container(50).HasFocus(2)')
resetnetworkbutton = xbmc.getCondVisibility('Container(50).HasFocus(10)')
debugbutton = xbmc.getCondVisibility('Container(50).HasFocus(5)') or (xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(102)'))
#button = xbmc.getCondVisibility('Container(9000).HasFocus(?)')

'''------------------------------
---CUSTOM-------------
------------------------------'''
test = xbmc.getInfoLabel('Skin.String(Test)')
airplaycon1 = xbmc.getCondVisibility('SubString(System.CurrentControl,AirPlay)')
airplaycon2 = xbmc.getCondVisibility('System.GetBool(services.airplay)')
airplaycon3 = xbmc.getCondVisibility('System.GetBool(services.zeroconf)')
allowjoystickcon2 = xbmc.getCondVisibility('SubString(System.CurrentControl,$LOCALIZE[35100])')
vhomecon1 = xbmc.getCondVisibility('!Container(9000).HasFocus(348)') and xbmc.getCondVisibility('!Container(9000).HasFocus(323)') and xbmc.getCondVisibility('!Container(9000).HasFocus(340)') and xbmc.getCondVisibility('!Container(9000).HasFocus(341)') and xbmc.getCondVisibility('!Container(9000).HasFocus(325)') and xbmc.getCondVisibility('!Container(9000).HasFocus(346)') and xbmc.getCondVisibility('!Container(9000).HasFocus(507)') and xbmc.getCondVisibility('!Container(9000).HasFocus(508)') and xbmc.getCondVisibility('!Container(9000).HasFocus(509)')
maccon1 = xbmc.getCondVisibility('StringCompare(Skin.String(MAC),Skin.String(MAC1))')
maccon2 = xbmc.getCondVisibility('StringCompare(Skin.String(MAC),Skin.String(MAC2))')
maccon10 = xbmc.getCondVisibility('StringCompare(Control.GetLabel(700100),NONE)')
maccon11 = xbmc.getCondVisibility('StringCompare(Control.GetLabel(700100),7000)')