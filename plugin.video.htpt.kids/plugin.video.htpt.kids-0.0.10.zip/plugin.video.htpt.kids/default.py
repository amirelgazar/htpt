﻿# -*- coding: utf-8 -*-

import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os,random
import json,repoCheck

from variables import *
from modules import *

url, name, mode, iconimage, desc, num, viewtype = pluginend(admin)
if viewtype != None:
	if admin: notification("viewtype: " + str(viewtype),"","",2000)
	setsetting_custom1(addonID,'Current_View',viewtype)
if url == None: pass
elif "http://nickjr.walla.co.il/" in url: setsetting_custom1(addonID,'Current_View',50)
elif ("plugin.video.gozlan.me" in url or "plugin.video.seretil" in url or "plugin.video.supercartoons" in url or "plugin.video.sdarot.tv" in url or "seretil.me" in url): setsetting_custom1(addonID,'Current_View',58)

pluginend2(admin, url, containerfolderpath, viewtype)