# -*- coding: utf-8 -*-
import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os

from variables import *
from shared_modules import *
if "plugin." in addonID: from shared_modules3 import *
'''---------------------------'''

def CATEGORIES():
	'''------------------------------
	---MAIN--------------------------
	------------------------------'''
	addDir(addonString(41).encode('utf-8'),'',101,addonMediaPath + "41.png",addonString(141).encode('utf-8'),'1',50)
	addDir(addonString(42).encode('utf-8'),'',102,addonMediaPath + "42.jpg",addonString(142).encode('utf-8'),'1',50)
	addDir(addonString(44).encode('utf-8'),'',104,addonMediaPath + "44.png",addonString(144).encode('utf-8'),'1',50)
	addDir(addonString(45).encode('utf-8'),'',105,addonMediaPath + "45.jpg",addonString(145).encode('utf-8'),'1',50)
	addDir(addonString(46).encode('utf-8'),'',106,addonMediaPath + "46.png",addonString(146).encode('utf-8'),'1',50)
	addDir(addonString(47).encode('utf-8'),'',107,addonMediaPath + "47.jpg",addonString(147).encode('utf-8'),'1',50)
	addDir(addonString(48).encode('utf-8'),'',108,addonMediaPath + "48.jpg",addonString(148).encode('utf-8'),'1',50)
	addDir(addonString(49).encode('utf-8'),'',109,addonMediaPath + "49.jpg",addonString(149).encode('utf-8'),'1',50)
	if General_TrustedOnly == "false": addDir(addonString(43).encode('utf-8'),'',111,addonMediaPath + "42.jpg",addonString(143).encode('utf-8'),'1',"")
	
	
	
	
	'''many sources'''
	#YOUsubs('UC5RJ8so5jivihrnHB5qrV_Q')
	setsetting_custom1(addonID,'Current_View',50)
	'''------------------------------
	---וואלה-VOD!--------------------
	------------------------------'''
	
	
	#if OFF_9 != "true": addDir(addonString(22).encode('utf-8'),'plugin://plugin.video.wallaNew.video/?mode=1&module=wallavod&name=%d7%99%d7%9c%d7%93%d7%99%d7%9d&url=englishName%3dkids',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300',addonString(110).encode('utf-8'),'1',"")
	#if OFF_9 != "true": addDir('קלסיקלטת','plugin://plugin.video.wallaNew.video/?mode=1&module=338&name=קלסיקלטת&url=http://vod.walla.co.il/channel/338/clasicaletet',8,'https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcTYE2VT8CR2O31MsqAhdaydYrqrCD--HCCdGcs7blBn3Zh92Kwq','','1',"")
	#if OFF_10 != "true": addDir('ניק','plugin://plugin.video.wallaNew.video/?mode=1&module=nick&name=ניק&url=http://nick.walla.co.il/',8,'http://www.karmieli.co.il/sites/default/files/images/nico.jpg','','1',"")
	#if OFF_11 != "true": addDir('גוניור','plugin://plugin.video.wallaNew.video/?mode=1&module=junior&name=גוניור&url=http://junior.walla.co.il/',8,'http://upload.wikimedia.org/wikipedia/he/1/19/%D7%A2%D7%A8%D7%95%D7%A5_%D7%92%27%D7%95%D7%A0%D7%99%D7%95%D7%A8.jpg','','1',"")
	#if OFF_13 != "true": addDir('וואלה ילדים','plugin://plugin.video.wallaNew.video/?mode=1&module=wallavod&name=י%d7%99%d7%9c%d7%93%d7%99%d7%9d&url=englishName%3dkids',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300','','1',"")
	'''---------------------------'''
	

'''1=SONGS, 2=SHOWS, 3=LITTLE, 4=TVSHOWS, 5=MOVIES, 6=?, 7=BABY, 8=?, 9=OTHERS'''
def CATEGORIES101(admin):
	'''שירים לילדים בעברית 1'''
	addDir(addonString(57).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "1" + space5 + addonString(16).encode('utf-8'),'UCfm5IpcgGCooON4Mm2vq40A',9,'http://i.ytimg.com/i/fm5IpcgGCooON4Mm2vq40A/1.jpg?v=52fcd974',addonString(116).encode('utf-8'),'1',"")
	'''שירים לילדים בעברית 2 - חינוכית'''
	addDir(addonString(57).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "2" + space5 + addonString(39).encode('utf-8'),'23music',9,'https://yt3.ggpht.com/-BooUjg1alE8/AAAAAAAAAAI/AAAAAAAAAAA/yEGo6JJp0uU/s100-c-k-no/photo.jpg' + "92.jpg",addonString(139).encode('utf-8'),'1',"")
	'''שירים לילדים בעברית 3 - ייס'''
	addDir(addonString(57).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "3" + space5 + addonString(21).encode('utf-8'),'PLF11AD94724D37E02',13,'http://static.wixstatic.com/media/96e157_2b95d7111507dcbbf4d07a346b1a08bf.jpg_srz_261_263_85_22_0.50_1.20_0.00_jpg_srz',addonString(121).encode('utf-8'),'1',"")
	'''שירים לילדים בעברית 4 - דיסני'''
	addDir(addonString(57).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "4" + space5 + addonString(38).encode('utf-8'),'plugin://plugin.video.youtube/channel/UC6QxAhInaZ79pTg7wi3ZF-Q/',8,'http://i.ytimg.com/i/6QxAhInaZ79pTg7wi3ZF-Q/1.jpg?v=78ea3c',addonString(138).encode('utf-8'),'1',"")
	'''שירים לילדים בעברית 5'''
	addDir(addonString(57).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "5",'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%a9%d7%99%d7%a8%d7%99%d7%9d%20(19)&url=genre%3dkids%26genreId%3d7450',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300',addonString(197).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''שירים לילדים בעברית 6'''
	addDir(addonString(57).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "6",'PLErYJg2XgxyVYzsbPxH2dzhlWLs9sWGTa',13,'http://erezdvd.co.il/sites/default/files/imagecache/product_full/products/numi-numi.jpg',addonString(128).encode('utf-8'),'1',"")
	#"מיטב השירים פרפר נחמד", "PL51YAgTlfPj45OPEXI-ibfJy8ON0k1ARh"
	#"שירים ישראלים לילדים ערוץ בייבי", "PLErYJg2XgxyXTMAJvmFXoW6Qe66Ztw0Fk"
	#"שירי ילדים", "PLFw7KwIWHNB1_mXvYXwqFOw6S026LL3tj"
	'''---------------------------'''
	'''שירים לילדים באנגלית 1 - פשוט ללמוד אנגלית'''
	addDir(addonString(57).encode('utf-8') + space + addonString(201).encode('utf-8') + space + "1" + space5 + addonString(55).encode('utf-8'),'UCLsooMJoIpl_7ux2jvdPB-Q',9,'http://yt3.ggpht.com/-nHzSx4QKfsY/AAAAAAAAAAI/AAAAAAAAAAA/o_0k7TejOiI/s88-c-k-no/photo.jpg',addonString(155).encode('utf-8'),'1',"")
	
	'''שירים לילדים באנגלית 3 - ילדים 123'''
	addDir(addonString(57).encode('utf-8') + space + addonString(201).encode('utf-8') + space + "3" + space5 + addonString(53).encode('utf-8'),'UCtgpDqkeOToveUgh8igrvXQ',9,'http://yt3.ggpht.com/-g_tUdVsQVnU/AAAAAAAAAAI/AAAAAAAAAAA/KqZGxwkomOo/s88-c-k-no/photo.jpg',addonString(153).encode('utf-8'),'1',"")
	'''שירים לילדים באנגלית 4 - הופלה קידס'''
	addDir(addonString(57).encode('utf-8') + space + addonString(201).encode('utf-8') + space + "4" + space5 + addonString(52).encode('utf-8'),'UC3djj8jS0370cu_ghKs_Ong',9,'http://yt3.ggpht.com/-sETONHncMk4/AAAAAAAAAAI/AAAAAAAAAAA/joBxW-hyTA4/s88-c-k-no/photo.jpg',addonString(152).encode('utf-8'),'1',"")
	'''שירים לילדים באנגלית 5 - צאוצאו'''
	addDir(addonString(57).encode('utf-8') + space + addonString(201).encode('utf-8') + space + "5" + space5 + addonString(50).encode('utf-8'),'UCBnZ16ahKA2DZ_T5W0FPUXg',9,'http://yt3.ggpht.com/-QHPC9emY_8c/AAAAAAAAAAI/AAAAAAAAAAA/03fPGkHcBbk/s88-c-k-no/photo.jpg',addonString(151).encode('utf-8'),'1',"")
	'''---------------------------'''
	
	'''שירים ענבלי בא לי'''
	addDir('שירים ענבלי בא לי','PLPWc8VdaIIsAHPacvuyNfA-y8VSxoh4or',13,'http://isc.wcdn.co.il/w9/skins/nick_jr/31/November_8424.png',"",'1',"")
	'''---------------------------'''
	
	'''אוסף שירים לילדים'''
	addDir('אוסף שירים לילדים',['&wallaNew=item_id%3D2538763', '&wallaNew=item_id%3D2538765', '&wallaNew=item_id%3D2538766', '&wallaNew=item_id%3D2538767', '&wallaNew=item_id%3D2538768', '&youtube_pl=PL0495C8F5A2024FA4', '&wallaNew=', '&wallaNew=', '&wallaNew=', '&wallaNew=', '&wallaNew=', '&wallaNew='],17,'http://www.diskids.co.il/images/stories/feature/1.png',"",'1',"")
	'''---------------------------'''
	
	'''בייבי אוריינטל'''
	addDir(addonString(28).encode('utf-8'),'PLpnRNlRK18UaUnOabh_ZysDsOY3QLvjkd',13,addonMediaPath + "19.jpg",addonString(110).encode('utf-8'),'1',50)
	
	'''סיפורי התנכ עם סבא טוביה'''
	addDir("סיפורי התנכ עם סבא טוביה",'PL6jaO-hu0IvwHsU9bzS8caFo8reAxEseX',13,'http://images.mouse.co.il/storage/2/e/b-saba.jpg',addonString(110).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''סיפורים לילדים מרים רות'''
	#addDir("סיפורים לילדים מרים רות",'PL6jaO-hu0Ivzi0gndI5Rb6YYcqut13wlD',13,'',addonString(110).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''אוסף סיפורים בעברית'''
	addDir(addonString(10160).encode('utf-8'),['&youtbe_pl=PL74E72320D1F7932C', '&youtube_id=qSOsMgZ1iwk', '&wallaNew=seasonId%3d2867134', '&youtube_id=tl64w59Hh8E', '&wallaNew=item_id%3D2833303', '&wallaNew=item_id%3D2833303', '&wallaNew=seasonId%3d2585073', '&wallaNew=seasonId%3d2535850', '&wallaNew=seasonId%seasonId%3d2554281', '&wallaNew=item_id%3D2526364', '&youtube_id=NPqxLDRQF3M', '&youtube_id=CvlF7okXM2g', '&youtube_id=uGXiT9zyYa0', '&youtube_id=HAXPFap0P0A', '&youtube_id=RCFSjBSXKHk', '&youtube_id=QCFEPr9LLA0', '&youtube_id=8-t8ujUVVIQ', '&youtube_id=', '&youtube_id=', '&youtube_id=', '&youtube_id='],17,'http://www.gidikoren.com/gidikoren/images/book_pitz_azar.jpg',addonString(101600).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''סיפורים בעברית 2'''
	addDir(addonString(58).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "2",'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%a1%d7%99%d7%a4%d7%95%d7%a8%d7%99%d7%9d%20(5)&url=genre%3dkids%26genreId%3d7451',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300',addonString(198).encode('utf-8'),'1',"")
	
	'''צ'פצ'ולה' - מיכל כלפון'''
	addDir(addonString(10775).encode('utf-8'),'PL9boemkB6hYz5WlmI-QH_xmRyZDpHKvt9',13,'http://yt3.ggpht.com/-4Rd1GQEZnaM/AAAAAAAAAAI/AAAAAAAAAAA/pfQtiUaNjng/s88-c-k-no/photo.jpg',addonString(107750).encode('utf-8'),'1',50)
	
	'''שירים וסיפורים לילדים באנגלית 1 - אנגלית זה כיף'''
	addDir(addonString(41).encode('utf-8') + space + addonString(201).encode('utf-8') + space + "1" + space5 + addonString(61).encode('utf-8'),'UC43wDpoNIpAK2NYfMz1m0Ow',9,'http://yt3.ggpht.com/-vviGyJGiPjE/AAAAAAAAAAI/AAAAAAAAAAA/kfJgGMxLQTw/s88-c-k-no/photo.jpg',addonString(161).encode('utf-8'),'1',"")
	'''שירים וסיפורים לילדים באנגלית 2'''
	addDir(addonString(41).encode('utf-8') + space + addonString(201).encode('utf-8') + space + "2" + space5 + addonString(59).encode('utf-8'),'UC-qWJlvaPME3MWvrY-yjXeA',9,'http://yt3.ggpht.com/-Wk6NXGS1pAk/AAAAAAAAAAI/AAAAAAAAAAA/nBondFZLttw/s88-c-k-no/photo.jpg',addonString(159).encode('utf-8'),'1',"")
	'''---------------------------'''
	setsetting_custom1(addonID,'Current_View',50)

def CATEGORIES10103(name, iconimage, desc):
	YOULink('שמוליק קיפוד, הצב של אורן, והלו הלו אבא', 'qSOsMgZ1iwk', 'http://best-store.co.il/images/prudact/Shmulik.Kipod_Main.Image.jpg',addonString(110).encode('utf-8'))
	
def CATEGORIES102(admin):
	
	'''הופעות שונות'''
	addDir(addonString(10200).encode('utf-8'),['&youtube_id=0FaBsetswDA', '&youtube_id=PUL2C9mEAKQ', '&youtube=o20-0VygrsE', '&youtube=-ihwgBW3sVs', '&youtube=_ixMuVcAGhA', '&youtube=YOs5zhvXUf8', '&youtube=kbzPyZV3cck', '&youtube=i5yQxLraENk', '&youtube=yfEzE5V409k', '&wallaNew=item_id%3D2833366', '&wallaNew=item_id%3D2817611'],17,'http://www.habama.co.il/Habama/Upload/Children/%D7%92%D7%90%D7%96-%D7%97%D7%9D-%D7%9C%D7%99%D7%9C%D7%93%D7%99%D7%9D-%D7%90%D7%91%D7%99%D7%91-%D7%A8%D7%A6%D7%99%D7%9F-%D7%A8%D7%A7%D7%A4%D7%AA-%D7%95%D7%9C%D7%98%D7%A8-%D7%95%D7%A0%D7%98%D7%95%D7%A8%D7%94.jpg',addonString(102000).encode('utf-8'),'1',50)
	
	'''101 כלבים דלמטים'''
	YOULink(addonString(10202).encode('utf-8'), '020c8c5ebfe70', 'http://www.pashbar.co.il/pictures/show_big_0712083001297352431.jpg',addonString(102020).encode('utf-8'))
	
	'''אי המטמון'''
	YOULink(addonString(10204).encode('utf-8'), 'Cmd0VxJmmBA', 'http://images.mouse.co.il/storage/0/e/ggg--Matmon.jpg',addonString(102040).encode('utf-8'))
	
	'''אלדין'''
	addDir(addonString(10205).encode('utf-8'),['&youtube_id=sVCYRfk3Wcc', '&youtube_id=aIY0onCV9u0'],17,'http://www.tipa.co.il/images/contentImages/images/TV/al.jpg',addonString(102050).encode('utf-8'),'1',50)
	
	'''בילבי'''
	YOULink(addonString(10207).encode('utf-8'), 'sHMEnVpDJR8', 'http://i.ytimg.com/vi/2mxOiPccxOs/maxresdefault.jpg',addonString(102070).encode('utf-8'))
	
	'''גאליס המופע'''
	YOULink(addonString(10209).encode('utf-8'), 'a6f7eacf00f28', 'http://up389.siz.co.il/up1/znmi3xqzndjg.jpg',addonString(102090).encode('utf-8'))
	
	'''גיבורי האור'''
	YOULink(addonString(10211).encode('utf-8'), 'nwlo00FHCRc', 'http://www.booknet.co.il/imgs/site/prod/7294276219850b.jpg',addonString(102110).encode('utf-8'))
	
	'''גיגיגיגונת קלטת ילדים'''
	YOULink(addonString(10213).encode('utf-8'), 'tKDm79jqRcI', 'http://erezdvd.co.il/sites/default/files/imagecache/product_full/products/369504.jpg',addonString(102130).encode('utf-8'))
	
	'''דוד חיים'''
	addDir(addonString(10219).encode('utf-8'),['&youtube_id=ugmThlqdPJw', '&youtube_id=X3j6mQ9VgLI', '&youtube_id=T_a52ktWfLc', '&youtube_id=FruAxOYP0uw'],17,'http://www.nmcunited.co.il/Images/dynamic/movies/Dod-Haim2.jpg',addonString(102190).encode('utf-8'),'1',50)
	
	'''הרקולס - המחזמר המלא'''
	YOULink(addonString(10227).encode('utf-8'), 'UiqG4WAcvCM', 'http://moridim.me/images/large/191.jpg',addonString(102270).encode('utf-8'))
	
	'''יובל המבולבל'''
	addDir(addonString(10705).encode('utf-8'),['&youtube_id=6UrdISJBBC4', '&youtube_id=920d18542f05a', '&youtube_id=C2Rm4IuVWNQ', '&youtube_id=99c23afc06d1a', '&youtube_id=CZDniCIenbA', '&youtube_id=H9rwsZ1roRQ'],17,'http://www.nmcunited.co.il/Images/dynamic/movies/Dod-Haim2.jpg',addonString(107050).encode('utf-8'),'1',50)
	
	'''ילד פלא'''
	YOULink(addonString(10231).encode('utf-8'), 'e5c134277697c', 'http://tzavta.co.il/images/siteCont/Content_233.2463.jpg',addonString(102310).encode('utf-8'))
	
	'''יניב המגניב'''
	YOULink(addonString(10233).encode('utf-8'), 'f9s_aunAElY', 'http://img.mako.co.il/2013/07/22/kids_yaniv_hamagniv_.jpg',addonString(102330).encode('utf-8'))
	
	'''לירן הקוסם מהאגדות'''
	YOULink(addonString(10239).encode('utf-8'), 'kNS4xMdPIos', 'http://i.ytimg.com/vi/5gN4SMO8EfE/maxresdefault.jpg',addonString(102390).encode('utf-8'))
	
	'''מותק הילדות התחברו'''
	addDir(addonString(10243).encode('utf-8'),['&youtube_id=1wLhD4yqQxU', '&youtube_id=_Lv0UHXaY4I', '&youtube_id=j_BClvgFwMw', '&youtube_id=_WBgn4iw8gw'],17,'http://media.org.il/images/Baby.girls.tap.the.musical.IL.1999_Front.Cover.jpg',addonString(102430).encode('utf-8'),'1',50)

	'''מותק של פסטיבל'''
	addDir(addonString(10244).encode('utf-8'),['&youtube_pl=PLE915B350E437A7D8', '&youtube_pl=PL8C370A361DD07BDB', '&youtube_id=t2ksCC_RyLw', '&youtube_id=2KQBeOM'],17,'http://www.yap.co.il/prdPics/4991_desc3_5_1_1409123377.jpg',addonString(102440).encode('utf-8'),'1',50)
	
	'''מיכל הקטנה''' #UCPCJS9igpTu7COLmoDeMKXQ
	addDir(addonString(10245).encode('utf-8'),['&wallaNew=item_id%3D2567432', '&wallaNew=item_id%3D2698903', '&wallaNew=item_id%3D2583625', '&youtube_id=IEeuv8mtRLI'],17,'http://www.pashbar.co.il/pictures/show_big_0523173001376412565.jpg',addonString(102450).encode('utf-8'),'1',"")
	
	'''מרקו'''
	YOULink(addonString(10248).encode('utf-8'), 'XgnCNCt71d8', 'http://www.ykp.co.il/cd_halev.jpg',addonString(102480).encode('utf-8'))
	
	'''משחקי הפסטיגל'''
	YOULink(addonString(10250).encode('utf-8'), 'd2953353ab9e8', 'http://www.ligdol.co.il/Upload/pestigal2014_poster.jpg',addonString(102500).encode('utf-8'))
	
	'''סינדרלה - בר רפאלי'''
	YOULink(addonString(10255).encode('utf-8'), 'snr9wxyEzpA', 'http://afisha.israelinfo.ru/pictures/19949.jpg',addonString(102550).encode('utf-8'))
	
	'''ספר הגונגל'''
	YOULink(addonString(10258).encode('utf-8'), 'TlWVoNz_B3o', 'http://images.mouse.co.il/storage/3/7/ggg--book20090908_2343750_0..jpg',addonString(102580).encode('utf-8'))
	
	'''עמי ותמי'''
	YOULink(addonString(10261).encode('utf-8'), '8d6a2e7a3cd54', 'http://www.tivon.co.il/vault/Zoar/amitami-B.jpg',addonString(102610).encode('utf-8'))
	
	'''עליבאבא וארבעים השודדים'''
	YOULink(addonString(10262).encode('utf-8'), 'gxgvTe3kPGY', 'http://i.ytimg.com/vi/EMtHOrNBXKU/hqdefault.jpg',addonString(102620).encode('utf-8'))
	
	'''עליסה בארץ הפלאות'''
	YOULink(addonString(10263).encode('utf-8'), '4Zp-6Ts07Qw', 'http://images.mouse.co.il/storage/3/0/b--alice.jpg',addonString(102630).encode('utf-8'))	
	
	'''פיטר פן - הראל סקעת'''
	YOULink(addonString(10267).encode('utf-8'), 'gTuMB5sz8pY', 'http://i48.tinypic.com/f5ceuq.jpg',addonString(102670).encode('utf-8'))
	
	'''צ'פצ'ולה' - מיכל כלפון'''
	addDir(addonString(10775).encode('utf-8'),['&wallaNew=item_id%3D2728550', '&youtube_id=EKlFN3awN_w', '&youtube_id=UC64wDQFgTq9RpI1P8_p-SxA'],17,'http://yt3.ggpht.com/-4Rd1GQEZnaM/AAAAAAAAAAI/AAAAAAAAAAA/pfQtiUaNjng/s88-c-k-no/photo.jpg',addonString(107750).encode('utf-8'),'1',50)
	
	'''רובין הוד'''
	YOULink(addonString(10272).encode('utf-8'), '6nZk0H89jDQ', 'http://erezdvd.co.il/sites/default/files/imagecache/product_full/products/14810.jpg',addonString(102720).encode('utf-8'))
	
	'''רינת גבאי'''
	YOULink(addonString(10274).encode('utf-8'), 'ykKWS-Udw2s', 'http://img.mako.co.il/2013/09/16/fantasy50X70-poster_SHOWS_g.jpg',addonString(102740).encode('utf-8'))
	
	'''שורום זורום'''
	YOULink(addonString(10284).encode('utf-8'), '9rGV96uhqPw', 'http://www.tipa.co.il/images/contentImages/images/dvd/shorom.jpg',addonString(102840).encode('utf-8'))
	
	'''שלגיה והצייד'''
	YOULink(addonString(10287).encode('utf-8'), '0rPEJ-kD1dc', 'http://www.dossinet.me/coverage_pics/1b5d66af0d230ff716d50f07fd6defc0.jpg',addonString(102870).encode('utf-8'))
	
	'''פסטיבל כיף לי'''
	addDir(addonString(10255).encode('utf-8'),['&youtube_id=lZgpGH9wTHY'],17,'http://3.bp.blogspot.com/-LIy_QkefJ-M/UuaoyVJu82I/AAAAAAAAAus/Dpd7rKKbUfM/s1600/KEF2014+POS+copy.jpg',addonString(102550).encode('utf-8'),'1',50)
	
	'''סבא טוביה'''
	addDir(addonString(19).encode('utf-8'),['&youtube_pl=PLE494A88ED3823578'],6,'http://yt3.ggpht.com/--gG5kz68N_k/AAAAAAAAAAI/AAAAAAAAAAA/37Cr6jMJSCg/s88-c-k-no/photo.jpg',addonString(119).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''פסטיגל'''
	addDir(addonString(37).encode('utf-8') + space + "1",'UCKs_S8Uo5rLCNhlSanFpfFQ',9,'http://i.ytimg.com/i/Ks_S8Uo5rLCNhlSanFpfFQ/1.jpg?v=5410081a',addonString(137).encode('utf-8'),'1',"")
	'''פסטיגל 2'''
	addDir(addonString(37).encode('utf-8') + space + "2",'UCTxlaUXzxohVekL_Zym-hsw',9,addonMediaPath + "37.jpg",addonString(137).encode('utf-8'),'1',"")
	'''פסטיגל 3'''
	addDir(addonString(37).encode('utf-8') + space + "3",'UC8z6QWcSpDfeHY0sni4IDwA',9,'http://yt3.ggpht.com/-2Nux9ubjSCA/AAAAAAAAAAI/AAAAAAAAAAA/P8I968rchgE/s88-c-k-no/photo.jpg',addonString(137).encode('utf-8'),'1',"")
	'''---------------------------'''
	
	'''---------------------------'''
	setsetting_custom1(addonID,'Current_View',50)


def CATEGORIES10201(name, iconimage, desc):
	'''הופעות חיות'''
	
	setsetting_custom1(addonID,'Current_View',58)
	
def CATEGORIES104(admin):
	'''סדרות לילדים בעברית 2'''
	addDir(addonString(44).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "2",'plugin://plugin.video.sdarot.tv/?mode=2&module=http%3a%2f%2fwww.sdarot.wf%2fseries%2fgenre%2f7%d7%90%d7%a0%d7%99%d7%9e%d7%a6%d7%99%d7%94&name=%d7%90%d7%a0%d7%99%d7%9e%d7%a6%d7%99%d7%94&url=all-heb&quot;',8,'http://www.hometheater.co.il/files/(40143)_icon.png',addonString(194).encode('utf-8'),'1',58)   
	'''סדרות לילדים בעברית 3'''
	addDir(addonString(44).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "3",'UCDfoEu-jaKsjNL6Fl0h5PUQ',9,'http://yt3.ggpht.com/-sgYlsKP54oM/AAAAAAAAAAI/AAAAAAAAAAA/Ie9pRPV0QLo/s88-c-k-no/photo.jpg',addonString(114).encode('utf-8'),'1',"")   

	'''סדרות לילדים בעברית 6'''
	addDir(addonString(44).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "6",'UC9DU2y9iXnrI0Y5NFoBQ4RQ/playlists',9,'https://yt3.ggpht.com/-gVieqiUD01U/AAAAAAAAAAI/AAAAAAAAAAA/r2Bv4norjK8/s100-c-k-no/photo.jpg',addonString(110).encode('utf-8'),'1',50)	
	'''---------------------------'''
	
	'''סדרות לילדים בעברית / אנגלית 1'''
	addDir(addonString(44).encode('utf-8') + space + addonString(200).encode('utf-8') + space4 + addonString(201).encode('utf-8') + space + "1",'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%a1%d7%93%d7%a8%d7%95%d7%aa%20(31)&url=genre%3dkids%26genreId%3d7447',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300',addonString(199).encode('utf-8'),'1',"")
	'''---------------------------'''
	
	'''אגדות המלך שלמה'''
	addDir('אגדות המלך שלמה',['&sdarot=series_id=815&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f815%2ftales-of-a-wise-king-hebdub-%d7%90%d7%92%d7%93%d7%95%d7%aa-%d7%94%d7%9e%d7%9c%d7%9a-%d7%a9%d7%9c%d7%9e%d7%94-%d7%9e%d7%93%d7%95%d7%91%d7%91', '&youtube_pl=PLOx5NGhretuY8wp75WCY5PQQx8agiZ2IC'],6,'http://www.sdarot.pm/media/series/815.jpg',addonString(104000).encode('utf-8'),'1',50)
	
	'''אוטובוס הקסמים'''
	addDir('אוטובוס הקסמים',['&sdarot=series_id=season_id=1&series_id=1032&series_name=%d7%90%d7%95%d7%98%d7%95%d7%91%d7%95%d7%a1%20%d7%94%d7%a7%d7%a1%d7%9e%d7%99%d7%9d%20-%20%2a%d7%9e%d7%93%d7%95%d7%91%d7%91%2b%d7%aa%d7%a8%d7%92%d7%95%d7%9d%20%d7%9e%d7%95%d7%91%d7%a0%d7%94%2a&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f1032%2fthe-magic-school-bus-%d7%90%d7%95%d7%98%d7%95%d7%91%d7%95%d7%a1-%d7%94%d7%a7%d7%a1%d7%9e%d7%99%d7%9d-%d7%9e%d7%93%d7%95%d7%91%d7%91-%d7%aa%d7%a8%d7%92%d7%95%d7%9d-%d7%9e%d7%95%d7%91%d7%a0%d7%94', '&youtube_id=iioi9z0kdr0', '&youtube_id=mHfDK2VH2HM', '&youtube_id=6mTNQh0ux8c', '&youtube_id=e-7Kr5ovHtU', '&youtube_id=vmW7J_qfKq8'],17,'http://www.sdarot.pm/media/series/1032.jpg','גברת פריזל היא מורה ייחודית שמעבירה את שיעוריה באמצעות טיולי שדה קסומים.','1',50)
	
	'''אנימניאקס'''
	addDir('אנימניאקס',['&sdarot=series_id=1104&series_name=%d7%90%d7%a0%d7%99%d7%9e%d7%a0%d7%99%d7%90%d7%a7%d7%a1%20%2a%d7%aa%d7%a8%d7%92%d7%95%d7%9d%20%d7%9e%d7%95%d7%91%d7%a0%d7%94%2a&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f1104%2fanimaniacs-%d7%90%d7%a0%d7%99%d7%9e%d7%a0%d7%99%d7%90%d7%a7%d7%a1-%d7%aa%d7%a8%d7%92%d7%95%d7%9d-%d7%9e%d7%95%d7%91%d7%a0%d7%94'],6,'http://www.sdarot.pm/media/series/1104.jpg','סדרת אנימציה אנרכיסטית שמאגדת את כל היצורים המצויירים שעשו יותר מדי בעיות לחברת האחים וורנר, ועל כן לא זכו לתהילת עולם כמו באגס באני ודאפי דאק.[CR]במרכז שלושה כתמים שחורים בשם יאקו וואקו ואחותם דוט, ומצטרפים אליהם לפרקים גם פינקי התמים ו-Brain השואף לכבוש את העולם במזימות קונספירטיביות, שלוש יונים בשם בובי, פסטו וסקוויט, וסנאית מזדקנת בשם סלאפי, שזכתה לעדנה מסוימת בתקופת תור הזהב של וורנר ועכשיו מתייבשת בפנסיה.','1',50)
	
	'''אקס מן'''
	addDir('אקס מן',['&sdarot=series_name=%d7%90%d7%a7%d7%a1-%d7%9e%d7%9f%20%2a%d7%aa%d7%a8%d7%92%d7%95%d7%9d%20%d7%9e%d7%95%d7%91%d7%a0%d7%94%2a&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f1434%2fx-men-%d7%90%d7%a7%d7%a1-%d7%9e%d7%9f-%d7%aa%d7%a8%d7%92%d7%95%d7%9d-%d7%9e%d7%95%d7%91%d7%a0%d7%94', '&youtube_pl=PLN0EJVTzRDL9ObPf7m4GCN2BL6Ayreybh', '&youtube_pl=PL240D6E0D52552316', '&youtube_pl=PL8D5045D1EA3AA091', '&youtube_pl=PLE69A961D0351E331'],6,'http://www.sdarot.pm/media/series/1434.jpg','סדרה מצוירת על חבורת גיבורי על מוטנטיים נלחמים למען הצדק והאמונה של בני האדם.','1',50)
	
	'''אקס-מן: הדור הבא'''
	if General_TrustedOnly == "true" or admin: addDir('אקס-מן: הדור הבא',['&sdarot=series_id=1435&series_name=%d7%90%d7%a7%d7%a1-%d7%9e%d7%9f%3a%20%d7%94%d7%93%d7%95%d7%a8%20%d7%94%d7%91%d7%90%20%2a%d7%aa%d7%a8%d7%92%d7%95%d7%9d%20%d7%9e%d7%95%d7%91%d7%a0%d7%94%2a&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f1435%2fx-men-evolution-%d7%90%d7%a7%d7%a1-%d7%9e%d7%9f-%d7%94%d7%93%d7%95%d7%a8-%d7%94%d7%91%d7%90-%d7%aa%d7%a8%d7%92%d7%95%d7%9d-%d7%9e%d7%95%d7%91%d7%a0%d7%94'],6,'http://www.sdarot.pm/media/series/1435.jpg','חברי האקס-מן מתפתחים וגדלים כעבור השנים, אבל עכשיו ישנם מוטנטים שרוצים להורגם.[CR]החברים זקוקים לעזרה וכך מצטרפים אליהם חברים חדשים לצוות כדי לנצח את הרעים.','1',50)
	
	'''ארתור'''
	addDir('ארתור',['&sdarot=series_id=461&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f461%2farthur-%d7%90%d7%a8%d7%aa%d7%95%d7%a8-%d7%9e%d7%93%d7%95%d7%91%d7%91-%d7%aa%d7%a8%d7%92%d7%95%d7%9d-%d7%9e%d7%95%d7%91%d7%a0%d7%94', '&youtube_pl=PL17sRM9raf1Q-i_fTe45N0UBqNgdnZTD6', '&youtube_pl=PLN0EJVTzRDL96B86muPPFwgdymQjlwmLZ'],6,'http://www.sdarot.pm/media/series/461.jpg',addonString(104000).encode('utf-8'),'1',50)
	
	'''בילבי'''
	addDir('בילבי',['&sdarot=season_id=1&series_id=1159&series_name=%d7%91%d7%99%d7%9c%d7%91%d7%99%20-%20%2a%d7%9e%d7%93%d7%95%d7%91%d7%91%2b%d7%aa%d7%a8%d7%92%d7%95%d7%9d%20%d7%9e%d7%95%d7%91%d7%a0%d7%94%2a&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f1159%2fpippi-longstocking-%d7%91%d7%99%d7%9c%d7%91%d7%99-%d7%9e%d7%93%d7%95%d7%91%d7%91-%d7%aa%d7%a8%d7%92%d7%95%d7%9d-%d7%9e%d7%95%d7%91%d7%a0%d7%94', '&youtube_id=CBWXP_5gxSw', '&youtube_id=kgLCdl2q8XQ', '&youtube_id=5tc2MzqqHH8', '&youtube_id=L878q4J48L8'],17,'http://www.sdarot.pm/media/series/1159.jpg','בילבי היא ילדה מיוחדת במינה שעושה כל מה שבא לה. היא חזקה ואמיצה, חכמה מכולם, שובבה ובלגניסטית לא קטנה.[CR]היא חיה בוילה עם חבריה: האחים טומי ואניקה, הקוף "מר נלסון" והסוס שלה. החבורה חווה הרפתקאות רבות ולפעמים גם מסתבכת בצרות; אבל, לא לדאוג בילבי תמיד מצליחה להתגבר על כל הקשיים העומדים בדרך בזכות כוחותיה המיוחדים, האנרגיה והדמיון המפותח שלה.','1',50)
	
	'''דורימון'''
	addDir("דורימון",'PLU6_PRY_7y1TQMr67fJ6WC2mzkqtVyU3B',13,'http://www.animation-animagic.com/img/conteudo/2632008151425.jpg',addonString(110).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''דיגימון'''
	addDir("דיגימון",'PLk98jt4ayAVJr26ugq6oAD6j0QjfVxSGD',13,'http://forumsgallery.tapuz.co.il/ForumsGallery/galleryimages/medium/453gallery_13767.gif',addonString(110).encode('utf-8'),'1',"")
	
	'''דני שובבני'''
	addDir("דני שובבני",['&youtube_id=zWwqxZPg8as', '&youtube_id=yLMFuFM5b7U', '&youtube_id=VYxab_Lh0gg', '&youtube_id=EjpsfP86Neo'],17,'http://www.sdarot.pm/media/series/448.jpg','דני שובבני הוא ילד שלא מפסיק לעשות שטויות, להציק לשכנים, לעשות נזקים ובקיצור להיות כמו כל ילד בן גילו. יחד עם כלבו המופרע בשם ראף, דני מחולל מהומות בשכונה, כאשר כוונותיו הטובות, הרצון המוטעה לעזור והסקרנות שלו שאינה יודעת שובע מובילים אותו להרפתקאות וכיופים.','1',"")
	
	'''דן דין השופט'''
	addDir('דין דין השופט',['&sdarot=season_id=1&series_id=1009&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f1009%2fthe-wisdom-of-the-gnomes-%d7%93%d7%9f-%d7%93%d7%99%d7%9f-%d7%94%d7%a9%d7%95%d7%a4%d7%98-%d7%9e%d7%93%d7%95%d7%91%d7%91', '&youtube_pl=PL17sRM9raf1Q-i_fTe45N0UBqNgdnZTD6', '&sdarot=plugin://plugin.video.sdarot.tv/?url=http%3A%2F%2Fwww.sdarot.wf%2Fwatch%2F461%2Farthur-%D7%90%D7%A8%D7%AA%D7%95%D7%A8-%D7%9E%D7%93%D7%95%D7%91%D7%91-%D7%AA%D7%A8%D7%92%D7%95%D7%9D-%D7%9E%D7%95%D7%91%D7%A0%D7%94&episode_id=2&season_id=1&series_id=461&series_name=%27%27&name=פרק 2'],6,'http://www.sdarot.pm/media/series/1009.jpg',addonString(104000).encode('utf-8'),'1',50)
	
	'''הדרדסים'''
	addDir('הדרדסים',['&youtube_pl=PL66F75CE8DFB7A2A2', '&youtube_pl=PLo3vmw8N0knb9tZuIy7AR9fMPTUzr1oiI', '&sdarot=series_id=236&series_name=%d7%94%d7%93%d7%a8%d7%93%d7%a1%d7%99%d7%9d%20-%20%d7%9e%d7%93%d7%95%d7%91%d7%91&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f236%2fthe-smurfs-%d7%94%d7%93%d7%a8%d7%93%d7%a1%d7%99%d7%9d-%d7%9e%d7%93%d7%95%d7%91%d7%91', '&hotVOD=http%3a%2f%2fhot.ynet.co.il%2fExt%2fComp%2fHot%2fTopSeriesPlayer_Hot%2fCdaTopSeriesPlayer_VidItems_Hot%2f0%2c13031%2cL-10842-525-0-0%2c00.html', '&hotVOD=http%3A%2F%2Fhot.ynet.co.il%2FCmn%2FApp%2FVideo%2FCmmAppVideoApi_AjaxItems%2F0%2C13776%2C48507-0%2C00.html'],6,'http://f.nanafiles.co.il/upload/Xternal/IsraBlog/73/34/75/753473/misc/23130510.jpg',addonString(104000).encode('utf-8'),'1',50)
	
	'''הזרבובים'''
	addDir("הזרבובים",['&youtube_pl=PLR7DTcU2p0QiY-wI8KC6f01uzKLDZcuAc', '&sdarot=season_id=1&series_id=1313&series_name=%d7%94%d7%96%d7%a8%d7%91%d7%95%d7%91%d7%99%d7%9d&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f1313%2fthe-snorks-%d7%94%d7%96%d7%a8%d7%91%d7%95%d7%91%d7%99%d7%9d'],6,'http://www.sdarot.pm/media/series/1313.jpg','הזרבובים הם יצורים תת מימיים, עליזים, ססגוניים, שמשתמשים בשנורקל שעל ראשם כדי לנוע במהירות במים וכדי לעשות מוסיקה.','1',50)
	'''---------------------------'''
	
	'''החתולים הסמוראים'''
	addDir("החתולים הסמוראים",'PLR7DTcU2p0QhPmznEmitRHkv5RcUG3E-s',13,'http://www.sdarot.pm/media/series/1147.jpg',"כשרובוט גרעיני עתיר ממדים קופץ לבקר בעירכם, למי תקראו? לחתולים הסמוראים!! פעולה, בידור והרבה אנשובי, הם המרכיבים העיקרים לרקיחת סדרת הרפתקאות מרגשות של חבורת החתולים הסמוראים, שוחרי הפיצה. כאשר הם אינם עסוקים בהצלת העולם מציפורניהם של אדוני הרשע והפשע, מנהלים החתולים הלוחמניים בית פיצה. אבל כל אימת שהרשע נושא אל-על את ראשו' הופכת הפיצריה החתולית למטה היי-טקי מתוחכם." + '[CR]' + 'מחמ"לם המצוייד, שולפים החתולים את ציפורניהם המושחזות ונכנסים לפעולה מהירה.','1',50)
	
	'''הקטקטים'''
	addDir("הקטקטים",['&youtube_pl=PLR7DTcU2p0Qg5sF-jE09YnRymKba8N8l_','&youtube_pl=PLN0EJVTzRDL-WaGew7sZQHQc1l48LSZmp'],6,'http://www.23tv.co.il/sip_storage/FILES/5/8305.jpg',addonString(110).encode('utf-8'),'1',50)	
	
	'''המומינים'''
	addDir("המומינים",['&youtube_pl=PL_8KXLhQVQMLvEJlwakyjEeFfOgGQKaCo','&youtube_pl=PL_8KXLhQVQMLB8AzFqkq5Tg7c_8ZX8RRb', '&youtube_pl=PLN0EJVTzRDL-IJiTK4_B1ni8tlRNQvaBg'],6,'http://upload.wikimedia.org/wikipedia/he/2/2b/%D7%94%D7%9E%D7%95%D7%9E%D7%99%D7%A0%D7%99%D7%9D.jpg',addonString(110).encode('utf-8'),'1',50)
	
	'''המעופפים הנועזים'''
	addDir("המעופפים הנועזים",['&youtube_pl=PLR7DTcU2p0QhYwFJuI0zFXFmAN-q6n4A0','&youtube_pl=PL_8KXLhQVQMLhguXwe-d2HjvficZsfbEj','&sdarot=season_id=1&series_id=1387&series_name=%d7%94%d7%9e%d7%a2%d7%95%d7%a4%d7%a4%d7%99%d7%9d%20%d7%94%d7%a0%d7%95%d7%a2%d7%96%d7%99%d7%9d%20%2a%d7%9e%d7%93%d7%95%d7%91%d7%91%2a&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f1387%2fthe-little-flying-bears-%d7%94%d7%9e%d7%a2%d7%95%d7%a4%d7%a4%d7%99%d7%9d-%d7%94%d7%a0%d7%95%d7%a2%d7%96%d7%99%d7%9d-%d7%9e%d7%93%d7%95%d7%91%d7%91'],6,'http://upload.wikimedia.org/wikipedia/he/archive/e/e8/20060406072630!Flying_bears.jpg',addonString(110).encode('utf-8'),'1',50)
	'''---------------------------'''
	'''הלב מרקו'''
	addDir("הלב מרקו",'PL_8KXLhQVQMLx3W2W6YXTmaNHoPmlLl28',12,'http://www.dossinet.me/coverage_pics/a0b25bf2f9a27e362a22f5a1dfac507f.jpg',addonString(110).encode('utf-8'),'1',"")
	
	'''הענק הירוק'''
	if General_TrustedOnly == "true" or admin: addDir("הענק הירוק",['&sdarot=series_id=1738&series_name=%d7%94%d7%a2%d7%a0%d7%a7%20%d7%94%d7%99%d7%a8%d7%95%d7%a7%20-%20%2a%d7%9e%d7%93%d7%95%d7%91%d7%91%2a&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f1738%2fthe-incredible-hulk-%d7%94%d7%a2%d7%a0%d7%a7-%d7%94%d7%99%d7%a8%d7%95%d7%a7-%d7%9e%d7%93%d7%95%d7%91%d7%91'],6,'http://www.sdarot.pm/media/series/1738.jpg','"הענק" (באנגלית: The Incredible Hulk, או בכינויו העברי "הענק הירוק") הוא דמות בדיונית המופיעה בחוברות קומיקס של חברת מארוול קומיקס.[CR]','1',50)
	
	'''וולברין והאקס מן'''
	addDir("וולברין והאקס מן",['&youtube_pl=PLR7DTcU2p0QhGsv3LuA3GnCJWjoPBCafl', '&sdraot=season_id=1&series_id=823&series_name=%d7%95%d7%95%d7%9c%d7%91%d7%a8%d7%99%d7%9f%20%d7%95%d7%94%d7%90%d7%a7%d7%a1-%d7%9e%d7%9f%20%2a%d7%aa%d7%a8%d7%92%d7%95%d7%9d%20%d7%9e%d7%95%d7%91%d7%a0%d7%94%2a&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f823%2fwolverine-and-the-x-men-%d7%95%d7%95%d7%9c%d7%91%d7%a8%d7%99%d7%9f-%d7%95%d7%94%d7%90%d7%a7%d7%a1-%d7%9e%d7%9f-%d7%aa%d7%a8%d7%92%d7%95%d7%9d-%d7%9e%d7%95%d7%91%d7%a0%d7%94'],6,'http://i.ytimg.com/vi/_C9qXB0iPUY/hqdefault.jpg','שנה אחרי פיצוץ מסתורי בבית הספר למוטנטים לוגן מתעמת שוב מול מוס שמכניס לכלא משפחה שהחביאה את לוגן. האנק מנסה לפענח את הפיצוץ בביה"ס ויחד עם לוגן מתכונן למלחמה הקרובה. וולברין ואקס מן - וולברין מאחד את צוות אקס מן- צוות מוטנטים רודפי השלום. הצוות מתמודד גם מול אויבים מוטנטים בהנהגתו של מגנטו, וגם מול בני אדם, בפיקודו של הסנאטור קלי, ומנסה למנוע מלחמה בין בני האדם למוטנטים שתביא להרס עולמי/','1',"")
	
	'''חוש חש הבלש'''
	addDir("חוש חש הבלש",['&sdraot=season_id=1&series_id=1397&series_name=%d7%97%d7%95%d7%a9%20%d7%97%d7%a9%20%d7%94%d7%91%d7%9c%d7%a9%20%2a%d7%9e%d7%93%d7%95%d7%91%d7%91%2a&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f1397%2finspector-gadget-%d7%97%d7%95%d7%a9-%d7%97%d7%a9-%d7%94%d7%91%d7%9c%d7%a9-%d7%9e%d7%93%d7%95%d7%91%d7%91', '&youtube_pl=PLcnOogeoQ4TrfP9mO57AQY543KTLaTl8N', '&youtube_id=MbgrFDbE3b0', '&youtube_id=kWmBP09MM9w', '&youtube_id=P3gW3zPEhjY', '&youtube_id=uj9miIc0Ow4'],17,'http://www.sdarot.pm/media/series/1397.jpg','','1',50)
	
	'''טום וג'רי'''
	addDir("טום וג'רי",['&youtube_pl=PLN0EJVTzRDL-jbMDnITZcYO48kE1Hv3mc', '&youtube_pl=PLs3DueTtwGGppFDT2xv9zVBf4mz6RuOLj', '&youtube_pl=PL6hnqKp_bygo_2MFE6j3WWLitYXwhHGx3', '&youtube_id=hzs5DU_0BYU', '&youtube_id=QdzLQswLmUw', '&youtube_id=m0-QNfVLpGk'],17,'https://upload.wikimedia.org/wikipedia/he/thumb/2/23/Tomjerrylogo40s.jpg/280px-Tomjerrylogo40s.jpg',"טום וג'רי (באנגלית: Tom and Jerry)‏ היא שמה של סדרת סרטי אנימציה קצרים מיוחדים ומצחיקים שנוצרו על ידי ויליאם האנה וג'וזף ברברה עבור MGM בשנות הארבעים, שנות החמישים ושנות השישים.",'1',50)
	
	'''משטרת האגדות'''
	addDir("משטרת האגדות",'PLR7DTcU2p0QiaEmc56lGHMpxW4ladE93X',13,'http://www.tvland.co.il/Pics/mishterethaagadotbig.jpg',addonString(110).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''נאנוק'''
	addDir("נאנוק",'PL_8KXLhQVQMJJ4nHubadbykzbHhzzmUPu',13,'http://www.popy.co.il/media/Objects/Contents/E39C72A33AED45878CAB555CC24CE6BB.png.img?w=209&h=161&t=f',addonString(110).encode('utf-8'),'1',50)
	'''---------------------------'''
	'''נילס הולגרסון'''
	addDir("נילס הולגרסון",['&youtube_pl=PL_8KXLhQVQMKVZInMgWpGe9osYlO5lcBa'],6,'http://www.sratim.co.il/contents/series/images/IL/2072.jpg',addonString(110).encode('utf-8'),'1',50)
	'''---------------------------'''
	'''ספיד רייסר'''
	addDir("ספיד רייסר",'PLR7DTcU2p0QjzH9muKiw1eTbp0aU3hB63',13,'http://www.sdarot.pm/media/series/1804.jpg','הסדרה מתמקדת הפעם בבנו של ספיד רייסר האגדי. צעיר, מוכשר, הולך בעקבות אביו המחליט לפתוח בית ספר לנערים ושם למצוא את הנהג הצעיר המהיר בעולם.','1',50)
	
	'''פאואר ריינגרס'''
	
	'''פיטר פן'''
	addDir("פיטר פן",['&youtube_pl=PL_8KXLhQVQMIMJ_lQkl0Z393wwTtRgg_i', '&sdarot=season_id=1&series_id=1000&series_name=%d7%a4%d7%99%d7%98%d7%a8%20%d7%a4%d7%9f%20%2a%d7%9e%d7%93%d7%95%d7%91%d7%91%2a&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f1000%2fpeter-pan-%d7%a4%d7%99%d7%98%d7%a8-%d7%a4%d7%9f-%d7%9e%d7%93%d7%95%d7%91%d7%91', '&youtube_id=PUzKEF3_PL4', '&youtube_id=a7Zq_16Utt4', '&youtube_id=nmXOtCRLQo', '&youtube_id=7KxbWRikL48', '&youtube_id=QgIoKrcxcWU', '&youtube_id=gH7sj9RIz-E', '&youtube_id=r_s4lnd6qgk', '&youtube_id=KSzOZV3M0n4', '&youtube_id=a9NjkgF1RY8', '&youtube_id=7KxAhXs6Xf0'],17,'https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcSpAqoUxOIErj3Kgl4053S4oixnvZCcvoJwhf83xupmupsHWKh8',"הטלוויזיה החינוכית חוזרת לשדר את הסדרה הקלסית פיטר פן, המבוססת על ספרו של ג'יימס מתיו ברי, ספר שיצא בשנת 1911 תחת השם"'"פיטר וּוונדי".','1',50)
	
	'''פינגווינים'''
	addDir("פינגווינים",'PL_8KXLhQVQMIkR9iafygY0ztBUPSAyUki',13,'https://i.ytimg.com/vi/vzVdiqGJZ7E/default.jpg',addonString(110).encode('utf-8'),'1',50)
	
	'''פינוקיו'''
	addDir('פינוקיו',['&youtube_pl=PL17BB1526E0625514', '&sdarot=series_id=904&series_name=%d7%a4%d7%99%d7%a0%d7%95%d7%a7%d7%99%d7%95%20%2a%d7%9e%d7%93%d7%95%d7%91%d7%91%2a&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f904%2fthe-adventures-of-pinocchio-%d7%a4%d7%99%d7%a0%d7%95%d7%a7%d7%99%d7%95-%d7%9e%d7%93%d7%95%d7%91%d7%91', '&youtube_id=V098tHKky5A', '&youtube_id=Rv1VHwYWPsE'],6,'http://www.sdarot.pm/media/series/904.jpg',"ג'פטו, הנגר הבודד, גילף מבול עץ בובה שניעורה לחיים והפכה לבן שמעולם לא היה לו.[CR]"'פינוקיו השובב נשלח לבי"ס, אך ברח מהבית, ויצא לגלות את העולם ולעבור הרפתקאות רבות עם הברווזה בלה.','1',50)
	
	'''קופיקו'''
	addDir('קופיקו',['&youtube_pl=UCCktKuBGZ1kHifzp9Mxu6Eg', '&youtube_pl=PLN0EJVTzRDL_9qHYdDXgf6tslifiY_4zI', '&youtube_pl=PLR7DTcU2p0QhDzYbbniDNwSbXUM_p6N3f', '&youtube_pl=PLR7DTcU2p0QgEdLPHhrhKtxElvYVrseAQ', '&youtube_pl=PLR7DTcU2p0QhNGUffSgu8_5dP3lnOGZTx', '&sdarot=season_id=1&series_id=1810&series_name=%d7%a7%d7%95%d7%a4%d7%99%d7%a7%d7%95%20%d7%97%d7%95%d7%a7%d7%99%20%d7%94%d7%92%27%d7%95%d7%a0%d7%92%d7%9c&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f1810%2fkofiko-jungle-laws-%d7%a7%d7%95%d7%a4%d7%99%d7%a7%d7%95-%d7%97%d7%95%d7%a7%d7%99-%d7%94%d7%92-%d7%95%d7%a0%d7%92%d7%9c', '&sdarot=series_id=422&series_name=%d7%a7%d7%95%d7%a4%d7%99%d7%a7%d7%95&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f422%2fkofiko-%d7%a7%d7%95%d7%a4%d7%99%d7%a7%d7%95'],6,'http://www.musicaneto.com/wp-content/uploads/2015/03/6246725.jpg',addonString(104070).encode('utf-8'),'1',50)
	
	'''רובוטריקים'''
	if General_TrustedOnly == "true" or admin: addDir('רובוטריקים',['&sdarot=series_id=1395&series_name=%d7%a8%d7%95%d7%91%d7%95%d7%98%d7%a8%d7%99%d7%a7%d7%99%d7%9d%20%2a%d7%9e%d7%93%d7%95%d7%91%d7%91%2a&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f1395%2ftransformers-hebdub-%d7%a8%d7%95%d7%91%d7%95%d7%98%d7%a8%d7%99%d7%a7%d7%99%d7%9d-%d7%9e%d7%93%d7%95%d7%91%d7%91'],17,'http://www.sdarot.pm/media/series/1395.jpg','הרובוטריקים (באנגלית: Transformers) הנה סדרת תכניות ילדים שהומצאה בעקבות סדרת צעצועים מצליחה של חברת טאקארה היפנית ולאחריה נוצרו גם סרטים נלווים וספרי קומיקס.[CR]היא נוצרה בארצות הברית בשנות ה-80. בסדרה מתואר מאבק בין מכונות?ענק בעלות תודעה, המסוגלות להפוך את צורתן מצורה דמוית-אנוש לצורה אחרת, לרוב כלי-רכב שונים.[CR]בישראל שודרו שתי העונות הראשונות של הסדרה בשנות השמונים בטלוויזיה החינוכית בדיבוב המקורי באנגלית עם כתוביות בעברית. כיום משודרת הסדרה בערוץ פוקס קידס בפרקים חדשים ובדיבוב לעברית.','1',50)
	
	'''רחוב סומסום'''
	addDir('רחוב סומסום',['&youtube_pl=PLN0EJVTzRDL-zyHvJ7O4PTkwfwhm0GM0O', '&youtube_id=S9yMeuZnqf8', '&youtube_id=8Ce3d4Y1lXc', '&youtube_id=irGBfOr5M-0', '&youtube_id=7MsiQVLXANI', '&youtube_id=b9cppzqQEdk', '&youtube_id=UbebFD2BzSQ', '&youtube_id=5dHad5l61t0', '&youtube_id=f4Z0MxSQ3dc', '&youtube_id=hBsDetJvy2E', '&youtube_id=Y8CFfUbvuZI', '&youtube_id=ELQ0xiL5X7I', '&youtube_id=5uRyIMy2ktA'],17,'https://upload.wikimedia.org/wikipedia/he/thumb/4/41/SessemeStreet.jpg/200px-SessemeStreet.jpg',addonString(104000).encode('utf-8'),'1',50)
	
	'''צבי הנינג'ה'''
	addDir("צבי הנינג'ה",['&sdarot=season_id=1&series_id=636&series_name=%d7%a6%d7%91%d7%99%20%d7%94%d7%a0%d7%99%d7%a0%d7%92%27%d7%94%20%2a%d7%aa%d7%a8%d7%92%d7%95%d7%9d%20%d7%9e%d7%95%d7%91%d7%a0%d7%94%2a&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f636%2fteenage-mutant-ninja-turtles-%d7%a6%d7%91%d7%99-%d7%94%d7%a0%d7%99%d7%a0%d7%92-%d7%94-%d7%aa%d7%a8%d7%92%d7%95%d7%9d-%d7%9e%d7%95%d7%91%d7%a0%d7%94', '&youtube_id=W7B3NXG0aDY', '&youtube_id=E7naeIx3rqo'],6,'http://www.sdarot.pm/media/series/636.jpg',"צבי הנינג'ה היא סדרת אנימציה ופעולה פופולרית המבוססת במקור על קומיקס למבוגרים.[CR]הסדרה הופקה לטלוויזיה במקור לערוץ סינדיקציה, ואחר כך עברה ל-CBS. התוכנית שודרה בין השנים 1987 ל-1996.",'1',50)
	
	'''צבי הנינג'ה הדור הבא'''
	if General_TrustedOnly == "true" or admin: addDir("צבי הנינג'ה הדור הבא",['&sdarot=series_id=1670&series_name=%d7%a6%d7%91%d7%99%20%d7%94%d7%a0%d7%99%d7%a0%d7%92%27%d7%94%3a%20%d7%94%d7%93%d7%95%d7%a8%20%d7%94%d7%91%d7%90%20-%20%2a%d7%9e%d7%93%d7%95%d7%91%d7%91%2a&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f1670%2fninja-turtles-the-next-mutation-%d7%a6%d7%91%d7%99-%d7%94%d7%a0%d7%99%d7%a0%d7%92-%d7%94-%d7%94%d7%93%d7%95%d7%a8-%d7%94%d7%91%d7%90-%d7%9e%d7%93%d7%95%d7%91%d7%91'],6,'http://www.sdarot.pm/media/series/862.jpg',"מאסטר צ'ונג אי, ידידו הוותיק של ספלינטר, חולה מאד. לפני מותו, הוא מבקש מבתו המאומצת להתאחד עם צבי הנינג'ה אשר בימים אלה התבגרו כדי להציל את האנושות מפני דרקון-לורד, אשר השתחרר מארץ החלומות ומתכוון לשלוט בעולם.[CR]",'1',50)
	
	'''סנדוקאן'''
	addDir("סנדוקאן",'PLR7DTcU2p0QgWYVQap5zPK0MkwJizYku_',13,'http://www.sdarot.pm/media/series/1308.jpg','הסדרה מספרת את סיפור הרפתקאותיהם של סנדוקאן, נסיך שהודח מכיסאו ומנסה להשיב לעצמו את כס המלוכה ואת אהובתו, הנסיכה מריאנה, ושל יאנז, הרפתקן פורטוגזי המשמש כיד ימינו.','1',50)
	'''---------------------------'''
	
	'''סופר סטרייקה''' #['PLU6_PRY_7y1TQMr67fJ6WC2mzkqtVyU3B', 'PLKMFPiSCwUk3bjgDUSlTPskV9rA74nBiB']
	addDir(addonString(70).encode('utf-8'),['&youtube_pl=PLU6_PRY_7y1TQMr67fJ6WC2mzkqtVyU3B', '&youtube_pl=PLKMFPiSCwUk3bjgDUSlTPskV9rA74nBiB'],6,'http://www.musicaneto.com/wp-content/uploads/2015/03/6246725.jpg',addonString(170).encode('utf-8'),'1',50)
	
	'''שאלתיאל קוואק'''
	addDir('שאלתיאל קוואק',['&youtube_pl=PL_8KXLhQVQMKOtRoV1SuOu95dvVo-ea2J', '&sdarot=series_id=1137&series_name=%d7%a9%d7%90%d7%9c%d7%aa%d7%99%d7%90%d7%9c%20%d7%a7%d7%95%d7%95%d7%90%d7%a7%20%2a%d7%9e%d7%93%d7%95%d7%91%d7%91%2a&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f1137%2falfred-j-kwak-%d7%a9%d7%90%d7%9c%d7%aa%d7%99%d7%90%d7%9c-%d7%a7%d7%95%d7%95%d7%90%d7%a7-%d7%9e%d7%93%d7%95%d7%91%d7%91'],6,'http://www.sdarot.pm/media/series/1137.jpg','זמן קצר לאחר לידתו, שאלתיאל קוואק מאבד את הוריו, אחיו ואחיותיו אשר נהרגים בתאונת דרכים.[CR]חפי החפרפרת, חבר טוב של משפחתו, מגדל אותו. יחד עם חבריו יוצא שאלתיאל להרפתקאות רבות ומשונות ומפיק לקחים. המדינה בה מתגוררים שאלתיאל קוואק וקרוביו היא מַיִמוניה (בהולנדית Groot-Waterland, באנגלית Great Waterland, כלומר "ארץ המים הגדולה").','1',50)
	
	'''שלגיה ושבעת הגמדים'''
	addDir("שלגיה ושבעת הגמדים",'PL_8KXLhQVQMKKrMMm0glr1TMQoxCjFuTk',13,'http://www.coloring4fun.com/wp-content/uploads/2013/03/snow-white-600x300.jpg',addonString(110).encode('utf-8'),'1',50)
	'''---------------------------'''
	
	'''ערוץ גאליס 1''' '''צריך לסנן להראות רק פרקים מלאים'''
	#if OFF_20 != "true": addDir(addonString(56).encode('utf-8') + space + "1",'UC1ZvZmYKkigob8Vg7MSgqjg',9,'http://yt3.ggpht.com/-2NPlgdL7mU8/AAAAAAAAAAI/AAAAAAAAAAA/ch9GzL2fOlM/s88-c-k-no/photo.jpg',addonString(156).encode('utf-8'),'1',"")
	
	#'''סדרות לילדים'''
	#seriestvheb1 = 'ערוצי סדרות א'
	#if OFF_17 != "true": addDir(addonString(44).encode('utf-8') + space + "10",seriestvheb1.decode('utf-8'),9,"https://yt3.ggpht.com/-hbyD79o9YWk/AAAAAAAAAAI/AAAAAAAAAAA/gOv2DB9cLC4/s100-c-k-no/photo.jpg",addonString(93).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''סדרות לילדים באנגלית 1'''
	addDir(addonString(44).encode('utf-8') + space + addonString(201).encode('utf-8') + space + "1",'plugin://plugin.video.supercartoons/?mode=400&page=1',8,'https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcQQoKkxPt4MxnzTqM-ChAH7My_OdIZQJ2U6CoXIeDzOkdMBaG8G',addonString(130).encode('utf-8'),'1',58)
	'''---------------------------'''
	'''סדרות לילדים באנגלית 2'''
	addDir(addonString(44).encode('utf-8') + space + addonString(201).encode('utf-8') + space + "2",'https://dl.dropboxusercontent.com/s/cwcptnocx310g00/Merry_Melodies.plx',7,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSmzwydiY6V_l5sE_ed7Rf66G6B8Ug2p7ajn4uPAhH2NYpDVMNBUQ','','1',"")
	'''test'''
	#addDir("test",'http://www.navixtreme.com/wiilist/all.plx?page=4',7,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSmzwydiY6V_l5sE_ed7Rf66G6B8Ug2p7ajn4uPAhH2NYpDVMNBUQ','','1',"")
	'''הפנתר הורוד באנגלית 1'''
	addDir(addonString(13).encode('utf-8') + space + addonString(201).encode('utf-8') + space + "1",'PinkPanthersShow',9,'http://i.ytimg.com/i/1fIyfhQtm1fSljyKBf2uKA/1.jpg?v=5041a378',addonString(113).encode('utf-8'),'1',"")
	'''הפנתר הורוד באנגלית 2'''
	addDir(addonString(13).encode('utf-8') + space + addonString(201).encode('utf-8') + space + "2",'UCFeUyPY6W8qX8w2o6oSiRmw',9,'http://yt3.ggpht.com/-lwlGXn90heE/AAAAAAAAAAI/AAAAAAAAAAA/FmCv96eMMNE/s88-c-k-no/photo.jpg',addonString(113).encode('utf-8'),'1',"")
	'''---------------------------'''
	setsetting_custom1(addonID,'Current_View',50)
	
def CATEGORIES105(admin):
	'''------------------------------
	---checksites--------------------
	------------------------------'''
	'''plugin.video.seretil'''
	check_seretil_me = urlcheck('http://seretil.me', ping=True)
	check_10q_tv = urlcheck('http://10q.tv', ping=True)
	check_gozlan_me = urlcheck('http://gozlan.me', ping=True)
	#if systemplatformwindows: output = cmd('ping seretil.me -n 1',"Connected2")
	#else: output = bash('ping -W 1 -w 1 -4 -q seretil.me',"Connected")
	#if (not systemplatformwindows and ("1 packets received" in output or not "100% packet loss" in output)) or (systemplatformwindows and ("Received = 1" in output or not "100% loss" in output)): check_seretil_me = "true"
	'''---------------------------'''
	
	'''plugin.video.10qtv'''
	
	#if systemplatformwindows: output = cmd('ping 10q.tv -n 1',"Connected2")
	#else: output = bash('ping -W 1 -w 1 -4 -q 10q.tv',"Connected")
	#if (not systemplatformwindows and ("1 packets received" in output or not "100% packet loss" in output)) or (systemplatformwindows and ("Received = 1" in output or not "100% loss" in output)): check_10q_tv = "true"
	'''---------------------------'''
	
	
	'''סרטים מדובבים'''
	count = 1
	if check_seretil_me == 'ok':
		#addDir(addonString(10520).encode('utf-8'),list1,6,'http://www.iphoneil.net/icone/111185-icon.png',addonString(105200).encode('utf-8'),'1',50)
		addDir(addonString(10520).encode('utf-8') + space + str(count),'plugin://plugin.video.movixws/?iconimage=http%3a%2f%2fwww.in-hebrew.co.il%2fimages%2flogo-s.jpg&mode=2&name=Kids%20-%20%d7%99%d7%9c%d7%93%d7%99%d7%9d&url=http%3a%2f%2fwww.movix.me%2fgenres%2fKids',8,'http://www.in-hebrew.co.il/images/logo-s.jpg','','1',50) ; count += 1
		addDir(addonString(10520).encode('utf-8') + space + str(count),'plugin://plugin.video.movixws/?iconimage=http%3a%2f%2ficons.iconarchive.com%2ficons%2fdesignbolts%2ffree-movie-folder%2f256%2fAnimated-icon.png&mode=2&name=Animation%20-%20%d7%90%d7%a0%d7%99%d7%9e%d7%a6%d7%99%d7%94&url=http%3a%2f%2fwww.movix.me%2fgenres%2fAnimation',8,'http://icons.iconarchive.com/icons/designbolts/free-movie-folder/256/Animated-icon.png','','1',50) ; count += 1
		addDir(addonString(10520).encode('utf-8') + space + str(count),'plugin://plugin.video.seretil/?mode=4&name=%d7%9e%d7%93%d7%95%d7%91%d7%91%d7%99%d7%9d%20%d7%a8%d7%90%d7%a9%d7%99&url=http%3a%2f%2fseretil.me%2fcategory%2f%25D7%25A1%25D7%25A8%25D7%2598%25D7%2599%25D7%259D-%25D7%259E%25D7%2593%25D7%2595%25D7%2591%25D7%2591%25D7%2599%25D7%259D%2fpage1%2f',8,'http://blog.tapuz.co.il/seretilNET/images/3745375_1.jpg',addonString(105200).encode('utf-8'),'1',58) ; count += 1
		if General_TrustedOnly == "false" or admin: 
			addDir('[COLOR=Red]' + addonString(10520).encode('utf-8') + space + str(count) + '[/COLOR]','plugin://plugin.video.seretil/?mode=211&name=%20%d7%90%d7%95%d7%a1%d7%a3%20%d7%a1%d7%a8%d7%98%d7%99%d7%9d%20%d7%9e%d7%93%d7%95%d7%91%d7%91%d7%99%d7%9d&url=http%3a%2f%2fseretil.me%2f%25D7%2590%25D7%2595%25D7%25A1%25D7%25A3-%25D7%25A1%25D7%25A8%25D7%2598%25D7%2599%25D7%259D-%25D7%259E%25D7%2593%25D7%2595%25D7%2591%25D7%2591%25D7%2599%25D7%259D%2f',8,'http://blog.tapuz.co.il/seretilNET/images/3745375_1.jpg',addonString(196).encode('utf-8'),'1',50) ; count += 1
			addDir('[COLOR=Red]' + addonString(10520).encode('utf-8') + space + str(count) + '[/COLOR]','plugin://plugin.video.seretil/?mode=211&name=%d7%90%d7%95%d7%a1%d7%a3%20%d7%9e%d7%a1%d7%a4%d7%a8%202%20%d7%a1%d7%a8%d7%98%d7%99%d7%9d%20%d7%9e%d7%93%d7%95%d7%91%d7%91%d7%99%d7%9d&url=http%3a%2f%2fseretil.me%2f%25D7%2590%25D7%2595%25D7%25A1%25D7%25A3-%25D7%2592%25D7%2593%25D7%2595%25D7%259C-%25D7%25A9%25D7%259C-%25D7%25A1%25D7%25A8%25D7%2598%25D7%2599%25D7%259D-%25D7%259E%25D7%25A6%25D7%2595%25D7%2599%25D7%25A8%25D7%2599%25D7%259D%25D7%259E%25D7%2593%25D7%2595%25D7%2591%25D7%2591%25D7%2599%25D7%259D%2f',8,'http://blog.tapuz.co.il/seretilNET/images/3745375_1.jpg',addonString(196).encode('utf-8'),'1',50) ; count += 1
			'''---------------------------'''
	'''---------------------------'''	

	'''סרטים מתורגמים'''
	count = 1
	if check_gozlan_me == 'ok':
		addDir(addonString(10535).encode('utf-8') + space + str(count),'plugin://plugin.video.gozlan.me/?mode=1&name=%d7%a1%d7%a8%d7%98%d7%99%20%d7%90%d7%a0%d7%99%d7%9e%d7%a6%d7%99%d7%94&url=http%3a%2f%2fanonymouse.org%2fcgi-bin%2fanon-www.cgi%2fhttp%3a%2f%2fgozlan.co%2f%2fsearch.html%3fg%3d%25D7%2590%25D7%25A0%25D7%2599%25D7%259E%25D7%25A6%25D7%2599%25D7%2594',8,'http://ftp.acc.umu.se/mirror/addons.superrepo.org/v5/addons/plugin.video.gozlan.me/icon.png','','1',58) ; count += 1
		addDir(addonString(10535).encode('utf-8') + space + str(count),'plugin://plugin.video.gozlan.me/?mode=1&name=%d7%a1%d7%a8%d7%98%d7%99%20%d7%9e%d7%a9%d7%a4%d7%97%d7%94&url=http%3a%2f%2fanonymouse.org%2fcgi-bin%2fanon-www.cgi%2fhttp%3a%2f%2fgozlan.co%2f%2fsearch.html%3fg%3d%25D7%259E%25D7%25A9%25D7%25A4%25D7%2597%25D7%2594',8,'http://ftp.acc.umu.se/mirror/addons.superrepo.org/v5/addons/plugin.video.gozlan.me/icon.png','','1',58) ; count += 1
		'''---------------------------'''
	if check_10q_tv == 'ok': 
		addDir(addonString(10535).encode('utf-8') + space + str(count),'plugin://plugin.video.10qtv/?mode=6&name=אנימציה&url=http://www.10q.tv/board/filmy/animciha/5',8,'http://mirror.cinosure.com/superrepo/v5/addons/plugin.video.10qtv/icon.png',addonString(110).encode('utf-8'),'1',57) ; count += 1
		addDir(addonString(10535).encode('utf-8') + space + str(count),'plugin://plugin.video.10qtv/?mode=6&name=%d7%9e%d7%a9%d7%a4%d7%97%d7%94&url=http%3a%2f%2fwww.10q.tv%2fboard%2ffilmy%2fmshfhha%2f17',8,'http://mirror.cinosure.com/superrepo/v5/addons/plugin.video.10qtv/icon.png',addonString(110).encode('utf-8'),'1',57) ; count += 1
		'''---------------------------'''
	
	addDir(addonString(10535).encode('utf-8') + space + str(count),['&wallaNew=genre%3dkids%26genreId%3d7449', '&wallaNew=genre%3dmovies%26genreId%3d6261'],6,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300',addonString(189).encode('utf-8'),'1',50) ; count += 1	
	'''---------------------------'''

	setsetting_custom1(addonID,'Current_View',50)
	
def CATEGORIES106(admin):

	'''ערוץ בייבי איינשטיין'''
	addDir(addonString(20).encode('utf-8'),['&youtube_ch=BabyEinsteinTV123', '&youtube_pl=PLRg7DhTholQCMjMfXLOQ2bVSTwpZz24OA'],6,'http://d202m5krfqbpi5.cloudfront.net/books/1170326163l/46377.jpg',addonString(120).encode('utf-8'),'1',50) #TerrapinStation5
	
	'''ערוץ בייבי'''
	addDir(addonString(31).encode('utf-8'),'UCj10fKNd5h64J_M9YIQu0Zw/playlists',9,'http://yt3.ggpht.com/-RYFi0L82fh4/AAAAAAAAAAI/AAAAAAAAAAA/1hhzmsuRybc/s88-c-k-no/photo.jpg',addonString(131).encode('utf-8'),'1',50)
	
	'''ערוץ לולי'''
	addDir(addonString(33).encode('utf-8'),'UCcYc90JDakyeXGeZgPL1ejA/playlists',9,'http://yt3.ggpht.com/-n8_yk3MKYEk/AAAAAAAAAAI/AAAAAAAAAAA/0lOK__EwCtg/s88-c-k-no/photo.jpg',addonString(133).encode('utf-8'),'1',50)
	
	'''אוליבר'''
	
	'''אוצר מילים עם נוני'''
	addDir(addonString(73).encode('utf-8'),'PLErYJg2XgxyXmgk6cyROtlJh2g-Fk_T6n',13,'http://i.ytimg.com/vi/m67adbe1SOg/0.jpg',addonString(173).encode('utf-8'),'1',50)
	'''---------------------------'''
	
	'''בילי בם בם'''
	
	'''גילגולון'''
	
	'''דובים ונהנים'''
	
	'''דרקו'''
	
	'''הגלופסים'''
	
	'''הכבשה שושנה'''
	addDir('[COLOR=Green]' + addonString(10630).encode('utf-8') + '[/COLOR]',['&wallaNew=item_id%3D2819037', '&wallaNew=item_id%3D2819043', '&wallaNew=item_id%3D2819050', '&wallaNew=item_id%3D2817560', '&wallaNew=item_id%3D2817583', '&wallaNew=item_id%3D2817533', '&wallaNew=item_id%3D2820067', '&youtube_pl=PLC47880737B43FF96'],17,'http://www.sdarot.pm/media/series/1487.jpg',addonString(106300).encode('utf-8'),'1',50)
	
	'''הנימנונמים'''
	addDir(addonString(10633).encode('utf-8'),['&wallaNew=seasonId%3d2556132', '&sdarot=season_id=1&series_id=873&series_name=%d7%94%d7%a0%d7%99%d7%9e%d7%a0%d7%95%d7%9e%d7%99%d7%9d%20%2a%d7%9e%d7%93%d7%95%d7%91%d7%91%2a&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f873%2fhanimnumim-%d7%94%d7%a0%d7%99%d7%9e%d7%a0%d7%95%d7%9e%d7%99%d7%9d-%d7%9e%d7%93%d7%95%d7%91%d7%91'],6,'http://www.sdarot.pm/media/series/873.jpg',addonString(106300).encode('utf-8'),'1',50)
	
	''''''
	
	''''''
	
	'''זומזומים'''
	
	''''''
	
	'''טונקי'''
	
	'''טיגה וטוגה'''
	
	''''''
	
	'''טימי הטלה'''
	
	'''טין טן'''
	
	'''טיפה טופה'''
	
	'''טלטאביז'''
	addDir(addonString(10642).encode('utf-8'),['&youtube_pl=PLBDE473A2E30EE847', '&youtube_id=TGmpQKg2NtQ', '&youtube_id=mAlgerULqyU', '&youtube_id=3cJYHKsa52E', '&youtube_id=BOzl3RHn4Io', '&youtube_id=VZzivZvWidI', '&youtube_id=NN_gqjA8jJQ', '&youtube_id=AL0RVZMr-VY', '&youtube_id=C_Km9NYD-Pw', '&youtube_id=d_zk--Iconw', '&youtube_id=d3yfZlIUwF4', '&youtube_id=GUWpiwVZ-gI', '&youtube_id=wTm5rDg8tqI', '&youtube_id=1E9Z0-ppTl0', '&youtube_id=JdKoA4lIENc', '&youtube_id=GI4j0xDtU5Y'],17,'https://upload.wikimedia.org/wikipedia/he/thumb/4/49/Teletubbies_DVD.jpg/200px-Teletubbies_DVD.jpg',addonString(106420).encode('utf-8'),'1',50)
	
	'''לולה בייבי'''
	addDir(addonString(54).encode('utf-8'),'UCOYUFFxT50nvDaRj5Mn5XNg',9,'http://yt3.ggpht.com/-C9HFu_35bmk/AAAAAAAAAAI/AAAAAAAAAAA/O5-pgwvceRI/s88-c-k-no/photo.jpg',addonString(154).encode('utf-8'),'1',"")
	
	'''מוסטי'''
	
	'''מיילו'''
	
	'''מיפי'''
	addDir('מיפי',['&sdarot=season_id=1&series_id=881&series_name=%d7%9e%d7%99%d7%a4%d7%99%20%2a%d7%9e%d7%93%d7%95%d7%91%d7%91%2a&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f881%2fmiffy-%d7%9e%d7%99%d7%a4%d7%99-%d7%9e%d7%93%d7%95%d7%91%d7%91', '&youtube_pl=PLTleo-h9TFqJWHazTOTJNQrcrkSZ_Gg83'],6,'http://www.sdarot.pm/media/series/881.jpg','סדרה המבוססת על סדרת ספרי ילדים מצליחה החושפת את הצופים בפני מושגי יסוד כמו צבעים, ספרות וצורות.[CR]בכל פרק אנחנו מגלים קצת על החיים של מיפי וחבריה הטובים ויוצאים להרפתקאות. מיפי הארנבת האהובה והמוכרת נולדה בכתביו וציוריו של האמן ההולנדי דיק ברונאה בשנת 1955, מתוך סיפורים שסיפר לביתו בת השנה על ארנבת שפגשו יחדיו בחיק הטבע. בסדרת הסרטים, נפגוש את מיפי ואת בני משפחתה השונים : הוריה, הסבים, דודה אליס, ברברה ובוריס הדובים, פופי החזיר, ועוד.','1',50)
	
	'''מיקמק'''
	addDir('מיקמק',['&sdarot=series_id=861&series_name=%d7%9e%d7%99%d7%a7%d7%9e%d7%a7%20%3a%20%d7%94%d7%a1%d7%93%d7%a8%d7%94%20%2a%d7%9e%d7%93%d7%95%d7%91%d7%91%2a&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f861%2fmikmak-hasidra-%d7%9e%d7%99%d7%a7%d7%9e%d7%a7-%d7%94%d7%a1%d7%93%d7%a8%d7%94-%d7%9e%d7%93%d7%95%d7%91%d7%91', '&youtube_pl=PL663sDNTault52-VzCCu4w0CfnoAtrmRg', '&youtube_pl=PL663sDNTaulu5KpP6eyz9Xr3caOQUDEl_', '&youtube_id=1CshWmAFinY', '&youtube_id=a5WNY-FMMyQ'],6,'http://www.sdarot.pm/media/series/881.jpg',"סדרת אנימציה משעשעת וקצבית, אשר עוקבת אחר ההרפתקאות של חבורת מיקמק - מקס, זואי, סאני וג'ימבו, קבוצה של ארבעה חברים אשר מפתחים משחקי מחשב וירטואליים.[CR]האויבים המושבעים של חבורת מיקמק היא גברת מיקיאוולי, פוליטיקאית משופשפת ואשת עסקים והעוזר הנאמן שלה מונדו. היא רוצה להשתלט על המעבדה שלהם ולבנות קניון גדול במקומו, כחלק מהתכנית הגדולה שלה לצבור כסף וכוח ולהשתלט על כל מיקמק סיטי (העיר).",'1',50)
	
	
	'''מספרי משימה'''
	addDir(addonString(10600).encode('utf-8'),['&youtube_id=DjUCZgrL8cY', '&youtube_id=TrUCf8Ys5Z4', '&youtube_id=Z7R7uJQf4Tc', '&youtube_id=grVwPnm4XC4', '&youtube_id=26-16M0Rhuo'],17,'http://i.ytimg.com/vi/DjUCZgrL8cY/hqdefault.jpg',addonString(106000).encode('utf-8'),'1',50)
	''''''
	
	''''''
	
	''''''
	
	''''''
	
	''''''
	
	'''פים ופימבה'''
	addDir("פים ופימבה",'PLTNonj9ImqaI2F7DHlMxZ3VDn8gwpaTKe',13,'http://msc.wcdn.co.il/archive/941107-54.jpg',addonString(154).encode('utf-8'),'1',58)
	
	''''''
	
	'''צרלי ודודו'''
	
	''''''
	
	'''קוקו הארנב'''
	
	'''קטני'''
	addDir("קטני",'PLbHXbhgZi5cL97NlobjLHNtBwIA9VHcmw',13,'https://i.ytimg.com/vi/QS3UHEmaaaQ/default.jpg',addonString(110).encode('utf-8'),'1',58)
	
	'''קמי'''
	
	'''שבט גולו'''
	
	'''תולי האהוב'''
	
	'''תפודים קטנים'''
	
	setsetting_custom1(addonID,'Current_View',50)
	
def CATEGORIES107(admin):
	'''הופ!'''
	addDir('[COLOR=Green]' + addonString(10703).encode('utf-8') + '[/COLOR]',['UClZXqxeY540_Epab3WDHFGw/playlists','UCfNjGgy-3XfTzgWoGMt_QOw/playlists'],6,'http://yt3.ggpht.com/-A6Z6Bj0Y5os/AAAAAAAAAAI/AAAAAAAAAAA/k-1dO4Dm0m8/s88-c-k-no/photo.jpg',addonString(107030).encode('utf-8'),'1',"")
	
	'''ניק ג'וניור ישראל'''
	#addDir('ניק ג'וניור ישראל','UCQWDQwBdFVOPjvBy6mgqUQQ',9,'http://yt3.ggpht.com/-jsb5s9cfdsk/AAAAAAAAAAI/AAAAAAAAAAA/pgREig-fcTE/s88-c-k-no/photo.jpg','','1',"")
	'''---------------------------'''
	
	'''קטנטנים בעברית 1'''
	addDir(addonString(47).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "1",'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%97%d7%93%d7%a9%d7%99%d7%9d%20(20)&url=genre%3dkids%26genreId%3d7623',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300',addonString(110).encode('utf-8'),'1',"")
	'''קטנטנים בעברית 2'''
	#addDir(addonString(47).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "2",'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%97%d7%99%d7%a0%d7%95%d7%9b%d7%99%20(34)&url=genre%3dkids%26genreId%3d7452',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300',addonString(110).encode('utf-8'),'1',"")
	'''קטנטנים בעברית 3'''
	#addDir(addonString(47).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "3",'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%94%d7%a4%d7%a2%d7%9c%d7%94%20(4)&url=genre%3dkids%26genreId%3d7453',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300',addonString(110).encode('utf-8'),'1',"")

	'''קטנטנים בעברית 5'''
	addDir(addonString(47).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "5",'plugin://plugin.video.wallaNew.video/?mode=1&module=nickjr&name=ניקלאודיון גוניור&url=http://nickjr.walla.co.il/',8,'http://www.imanoga.co.il/wp-content/uploads/2012/06/646457567.jpg',addonString(110).encode('utf-8'),'1',"50")
	'''---------------------------'''
	
	'''אדיבו'''
	addDir('אדיבו',['&youtube_pl=PL_8KXLhQVQMLeDwIbMl6RyoMQiCuY7tu-', '&sdarot=season_id=1&series_id=1641&series_name=%d7%90%d7%93%d7%99%d7%91%d7%95%20-%20%2a%d7%9e%d7%93%d7%95%d7%91%d7%91%2a&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f1641%2fadiboo-%d7%90%d7%93%d7%99%d7%91%d7%95-%d7%9e%d7%93%d7%95%d7%91%d7%91'],6,'http://www.sdarot.pm/media/series/1641.jpg','אדיבו היא סדרת ילדים נפוצה שעל פיה נעשו לא מעט משחקי מחשב המיועדים לילדים.[CR]אדיבו ואדיליה הם שני אחים חייזרים חמודים, ויש להם חיית מחמד חייזרית - בוזי, ורובוט חכם וידידותי - רוביטוק. לכל החבורה יש חללית מיוחדת שיכולה להתמזער ולטוס בתוך הגוף האנושי. בכל פרק רוביטוק מלמד את אדיבו ואת חבריו משהו חדש על גוף האדם: החל בדרך פעולת העין וכלה בפעולות המעיים המביכות יותר. דרך מצוינת עבור הילדים להכיר את אברי הגוף, תפקידם והשמות שלהם.','1',50)
	
	'''בגינה של לין'''
	addDir(addonString(10710).encode('utf-8'),'PLPWc8VdaIIsDcjHMTBavJG-Rm8p0wvvW_',12,'http://img.youtube.com/vi/lQt9W6DU5dQ/0.jpg',addonString(107110).encode('utf-8'),'1',"")
	
	'''בוב הבנאי'''
	addDir(addonString(10712).encode('utf-8'),'PL_8KXLhQVQMK80XCn7g3qVj7RwhrwiGHG',13,'http://www.moviesforkids.co.il/images/MainCatMovies/%D7%91%D7%95%D7%91-%D7%94%D7%91%D7%A0%D7%90%D7%99.jpg',addonString(107120).encode('utf-8'),'1',50)
	
	'''בולי איש השלג'''
	addDir('בולי איש השלג',['&sdarot=season_id=1&series_id=1642&series_name=%d7%91%d7%95%d7%9c%d7%99%20%d7%90%d7%99%d7%a9%20%d7%94%d7%a9%d7%9c%d7%92%20-%20%2a%d7%9e%d7%93%d7%95%d7%91%d7%91%2a&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f1642%2fbouli-%d7%91%d7%95%d7%9c%d7%99-%d7%90%d7%99%d7%a9-%d7%94%d7%a9%d7%9c%d7%92-%d7%9e%d7%93%d7%95%d7%91%d7%91', '&youtube_id=2j2ISqZ40GU', '&youtube_id=oV_sUQa4BLE', '&youtube_id=qi5D5LnmrYk'],17,'http://www.sdarot.pm/media/series/1641.jpg','לילותיו של בולי איש השלג וחבריו בכפר הבולים.[CR]מספרת על בולי איש שלג שהירח הפיח בו ובחבריו רוח חיים. קסמו של הירח מונע מהם מלהנמס גם בקיץ ובשמש, וכך הם מטיילים בעולם, משחקים, שוחים ומבלים.','1',50)
	
	'''דן הדוור'''
	addDir('דן הדוור',['&sdarot=season_id=1&series_id=1577&series_name=%d7%93%d7%9f%20%d7%94%d7%93%d7%95%d7%95%d7%a8&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f1577%2fdan-hadavar-%d7%93%d7%9f-%d7%94%d7%93%d7%95%d7%95%d7%a8' ,'&youtube_pl=PL_8KXLhQVQMK05YV3wTQ4SZyEo2kWDvNH'],6,'http://www.sdarot.pm/media/series/1577.jpg','','1',50)
	
	'''הורים וגורים'''
	addDir(addonString(10720).encode('utf-8'),'PL51YAgTlfPj5sp5nUKFuwuUddCXYjiH8F',13,'https://i.ytimg.com/vi/2QOPSd1hKhQ/default.jpg',addonString(107200).encode('utf-8'),'1',50)
	
	'''היי בינבה'''
	addDir('היי בינבה',['&sdarot=season_id=1&series_id=1142&series_name=%d7%94%d7%99%d7%99%20%d7%91%d7%99%d7%a0%d7%91%d7%94%20%2a%d7%9e%d7%93%d7%95%d7%91%d7%91%2a&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f1142%2fbumpety-boo-%d7%94%d7%99%d7%99-%d7%91%d7%99%d7%a0%d7%91%d7%94-%d7%9e%d7%93%d7%95%d7%91%d7%91' ,'&youtube_pl=PLsCZljh6GgKUyE7rFV66powMC1H7XrXx3', '&youtube_id=YUNtUxIc708'],6,'http://www.sdarot.pm/media/series/1142.jpg','הסדרה מתמקדת בבובי, נער צעיר אשר חלם תמיד על מכונית משלו ובבינבה, מכונית צהובה קטנה ומדברת שבקעה מתוך ביצה מוזרה בתוך משחטת רכב.[CR]בובי, אשר שומע אותה בוכה, יוצא לעזרתה רגע לפני שהיא נהרסת, ומאז הם נעשים חברים טובים. בינבה, בובי והכלב שלו, פונפון יוצאים יחדיו למסע הרפתקאות בעולם במטרה למצוא את אמהּ של בינבה. הם נאלצים להתחמק מזעם הרשע שמנסה לתפוס את בינבה בכל הזדמנות.','1',50)
	
	'''הלו קיטי'''
	addDir(addonString(10721).encode('utf-8'),'PL-_BcMXVkaspyjwz7S5Hs_Rgih0F1d8_d',13,'http://www.ligdol.co.il/Upload/hello%20kitty285.jpg',addonString(107210).encode('utf-8'),'1',50)
	
	'''הנסיכה סופיה הראשונה'''
	addDir(addonString(10722).encode('utf-8'),['&sdarot=image=http%3a%2f%2fwww.sdarot.wf%2fmedia%2fseries%2f1636.jpg&name=%d7%94%d7%a0%d7%a1%d7%99%d7%9b%d7%94%20%d7%a1%d7%95%d7%a4%d7%99%d7%94%20%d7%94%d7%a8%d7%90%d7%a9%d7%95%d7%a0%d7%94%20%2a%d7%9e%d7%93%d7%95%d7%91%d7%91%2a&series_id=1636&series_name=%d7%94%d7%a0%d7%a1%d7%99%d7%9b%d7%94%20%d7%a1%d7%95%d7%a4%d7%99%d7%94%20%d7%94%d7%a8%d7%90%d7%a9%d7%95%d7%a0%d7%94%20%2a%d7%9e%d7%93%d7%95%d7%91%d7%91%2a&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f1636%2fsofia-the-first-%d7%94%d7%a0%d7%a1%d7%99%d7%9b%d7%94-%d7%a1%d7%95%d7%a4%d7%99%d7%94-%d7%94%d7%a8%d7%90%d7%a9%d7%95%d7%a0%d7%94-%d7%9e%d7%93%d7%95%d7%91%d7%91"', '&youtube_pl=PLVwL64lSxWWyAUC6Bv-GAbdgQAv3CuCrr'],6,'http://upload.wikimedia.org/wikipedia/he/a/a4/%D7%94%D7%A0%D7%A1%D7%99%D7%9B%D7%94_%D7%A1%D7%95%D7%A4%D7%99%D7%94.png',addonString(107220).encode('utf-8'),'1',50)
	
	'''הסוד של מיה'''
	addDir(addonString(10723).encode('utf-8'),'PLPWc8VdaIIsCGEVOC2iJxnWNEjI13xbnA',12,'http://msc.wcdn.co.il/w-2-1/w-300/768225-54.jpg',addonString(107230).encode('utf-8'),'1',50)
	
	'''זמן לזוז'''
	addDir(addonString(10728).encode('utf-8'),'PLPWc8VdaIIsDYbIQJMDX4usMYw7pYmPxj',13,'http://images1.ynet.co.il/PicServer3/2012/12/04/4315826/lazooz_01.jpg',addonString(107280).encode('utf-8'),'1',50)
	
	'''יובל המבולבל'''
	addDir(addonString(10705).encode('utf-8'),['&youtube_ch=UC0r3m54hCOvyG47jzz08X2Q', '&youtube_pl=PL0495C8F5A2024FA4'],6,'http://yt3.ggpht.com/-FHcf2Rxu08A/AAAAAAAAAAI/AAAAAAAAAAA/dxzE2ng3uXI/s88-c-k-no/photo.jpg',addonString(107050).encode('utf-8'),'1',"")
	
	'''יצירה בקצרה'''
	addDir(addonString(10735).encode('utf-8'),['&youtube_pl=PLPWc8VdaIIsC0SPM0_dgOVIDn5vcCH8Ti', '&youtube_pl=PLPWc8VdaIIsD85fRihIJFTzwt9v_JX2t6'],6,'http://msc.wcdn.co.il/archive/1475513-5.jpg',addonString(107350).encode('utf-8'),'1',50)
	
	'''מועדון המאפים הטובים'''
	addDir(addonString(10745).encode('utf-8'),['&youtube_pl=PLPWc8VdaIIsDUd9awquJznDcL_aSyi00T','&youtube_pl=PLPWc8VdaIIsCfrHCUj7XKDG_rvLwE9V-p'],6,'http://www.erezdvd.co.il/sites/default/files/imagecache/product_full/products/gilisip.jpg',addonString(107450).encode('utf-8'),'1',"")
	
	'''מיקי כוכבת הילדים'''
	addDir(addonString(10746).encode('utf-8'),['&youtube_id=5Zf0uSGOzlA', '&youtube_id=BKCAXKFXwEg', '&youtube_id=zGyEGXx3qkU'],17,'http://yt3.ggpht.com/-LQQaGMJh2g0/AAAAAAAAAAI/AAAAAAAAAAA/KebzcCn-y_Y/s88-c-k-no/photo.jpg',addonString(107460).encode('utf-8'),'1',50)
	
	'''מר למה וגברת ככה'''
	addDir(addonString(10748).encode('utf-8'),'PLPWc8VdaIIsC8iEN7EhY46jmy93imkpHI',13,'http://msc.wcdn.co.il/archive/1673912-35.gif',addonString(107480).encode('utf-8'),'1',"")
	
	'''משפחת יומולדת'''
	addDir(addonString(10749).encode('utf-8'),'PLPWc8VdaIIsBOUPxtM2CD7yGs1D8NCM_Z',13,'http://msc.wcdn.co.il/archive/1620289-35.gif',addonString(107490).encode('utf-8'),'1',"")
	
	'''סיפורי פיות'''
	addDir(addonString(10769).encode('utf-8'),'PLPWc8VdaIIsD8YvtRkkqjYC5SF7TKvAcM',13,'http://isc.wcdn.co.il/w9/skins/nick_jr/17/header_pic_2745.png',addonString(107690).encode('utf-8'),'1',"")
	
	'''סמי הכבאי'''
	addDir(addonString(10770).encode('utf-8'),['&youtube_pl=PL_TbWUH2U7KmZtYRZlJtxzmYFP_m81vSk', '&youtube_pl=PLN0EJVTzRDL-IJiTK4_B1ni8tlRNQvaBg', '&youtube_pl=PL8x83ieZ_yGXSJbCVjtUc6ZV3XWY95iEH'],6,'http://www.ligdol.co.il/Upload/hello%20kitty285.jpg',addonString(107700).encode('utf-8'),'1',"")
	
	'''עולמו הקסום של מקס'''
	addDir(addonString(10772).encode('utf-8'),'PLPWc8VdaIIsCeVQhASYBNmykK4gKh0DCe',13,'http://images1.ynet.co.il/PicServer3/2013/07/21/4745895/max_01.jpg',addonString(107720).encode('utf-8'),'1',50)
	
	'''פליפר ולופקה'''
	addDir('פליפר ולופקה',['&sdarot=series_id=1153&series_name=%d7%a4%d7%9c%d7%99%d7%a4%d7%a8%20%d7%95%d7%9c%d7%95%d7%a4%d7%a7%d7%94%20-%20%2a%d7%9e%d7%93%d7%95%d7%91%d7%91%2b%d7%aa%d7%a8%d7%92%d7%95%d7%9d%20%d7%9e%d7%95%d7%91%d7%a0%d7%94%2a&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f1153%2fflipper-and-lopaka-%d7%a4%d7%9c%d7%99%d7%a4%d7%a8-%d7%95%d7%9c%d7%95%d7%a4%d7%a7%d7%94-%d7%9e%d7%93%d7%95%d7%91%d7%91-%d7%aa%d7%a8%d7%92%d7%95%d7%9d-%d7%9e%d7%95%d7%91%d7%a0%d7%94', '&youtube_pl=PLerEkB0tFW3aCqMAK0gzZkkF0QjxQx-4h', '&youtube_pl=PLerEkB0tFW3brFpEnqz3N4vU6L4NUBQi3'],6,'http://www.sdarot.pm/media/series/1153.jpg','וכבי סדרת האנימציה המדובבת לעברית, המתרחשת באי טרופי קסום ואידילי הם הדולפין פליפר והילד לופקה שהפכו לחברים טובים לאחר שפליפר הציל את לופקה מטביעה באוקיינוס.[CR]פליפר ולופקה, יחד עם החבורה האמיצה שלהם, יוצאים להרפתקאות מרתקות ונלחמים בכוחות הרוע שבראשם התמנון הענק והמרושע דקסטר ושומרי ראשו הכרישים חסרי המוח.','1',50)
	
	'''צ'פצ'ולה' - מיכל כלפון'''
	addDir(addonString(10775).encode('utf-8'),['&youtube_ch=UC64wDQFgTq9RpI1P8_p-SxA', '&youtube_id=_Jsa4Ml77-I', '&youtube_id=BduVyZALCYs', '&wallaNew=item_id%3D2728301', '&wallaNew=item_id%3D2728353'],17,'http://yt3.ggpht.com/-4Rd1GQEZnaM/AAAAAAAAAAI/AAAAAAAAAAA/pfQtiUaNjng/s88-c-k-no/photo.jpg',addonString(107750).encode('utf-8'),'1',50)
	
	'''רוני וקשיו'''
	addDir(addonString(10780).encode('utf-8'),['&youtube_pl=PLPWc8VdaIIsDPb04SHd5fzzqYt3FtmWs-','&youtube_pl=PLPWc8VdaIIsDCX6hU5b-ve2I_MRESc8FZ'],6,'http://amarganim.co.il/images_bo/%D7%A8%D7%95%D7%A0%D7%99%20%D7%95%D7%A7%D7%A9%D7%99%D7%95.jpg',addonString(107800).encode('utf-8'),'1',"")
	
	'''שטויות בחדשות'''
	addDir(addonString(10788).encode('utf-8'),'PLPWc8VdaIIsBzxaUfj3smv1tJ8sKQXwrW',13,'http://images1.ynet.co.il/PicServer3/2013/02/04/4440787/shtuyot_01.jpg',addonString(107880).encode('utf-8'),'1',"")
	
	'''שלוש ארבע לעבודה'''
	addDir(addonString(10790).encode('utf-8'),'PLPWc8VdaIIsASIzs8TcS3FFYEL68jBPWO',13,'http://www.hll.co.il/web/8888/nsf/web/8017/%D7%A9%D7%9C%D7%95%D7%A9-%D7%90%D7%A8%D7%91%D7%A2-%D7%9C%D7%A2%D7%91%D7%95%D7%93%D7%94.jpg',addonString(107900).encode('utf-8'),'1',"")
	
	'''שלדון'''
	addDir("שלדון",'PL_8KXLhQVQMLzs0EHUhG_9PwxVsFgDAo4',13,'https://i.ytimg.com/vi/6kSynpNXMBs/default.jpg',addonString(110).encode('utf-8'),'1',50)
	'''---------------------------'''
	'''מולי וצומי'''
	addDir("מולי וצומי",'PLfcYs4SRZfuJHmb8y_BpUpzAsm1guoAlK',13,'http://www.yap.co.il/prdPics/4309_desc3_2_1_1390393153.jpg',addonString(110).encode('utf-8'),'1',50)
	'''---------------------------'''
	
	'''הדוד חיים'''
	addDir("הדוד חיים",'PLTNonj9ImqaIuFt2AyqdYFx6bCnKoFsIc',13,'http://www.yap.co.il/prdPics/4298_desc3_2_2_1390119036.jpg',addonString(110).encode('utf-8'),'1',50)
	'''---------------------------'''
	
	'''מיכל הקטנה'''
	addDir(addonString(10245).encode('utf-8'),'PLTNonj9ImqaKElCJ-4e8X_3BzXvzEYU_0',13,'http://www.pashbar.co.il/pictures/show_big_0523173001376412565.jpg',addonString(102450).encode('utf-8'),'1',50)
	'''---------------------------'''
	
	'''מרתה מדברת'''
	addDir("מרתה מדברת",'PL_8KXLhQVQMLtfN5bkh11lSA6Awg5rt9y',13,'https://i.ytimg.com/vi/6kSynpNXMBs/default.jpg',addonString(110).encode('utf-8'),'1',50)
	'''---------------------------'''
	'''רוי בוי'''
	addDir("רוי בוי",'PLR7DTcU2p0Qg8pxiEld0Fg3K2Bd8gTKw5',13,'https://i.ytimg.com/vi/9s7UMkxTIJ8/hqdefault.jpg',addonString(110).encode('utf-8'),'1',50)
	
	'''תותית'''
	addDir(addonString(10795).encode('utf-8'),['&youtube_id=E9RRmFpgtbc', '&wallaNew=seasonId%3d2710592', '&youtube_id=DqWEQ-VrLNc', '&youtube_id=iy3S7iUyJWY', '&youtube_id=ohM0Z9lVbw4', '&youtube_id=2WQ_2sAQNYc', '&youtube_id=O-ny3Wa6Bi0', '&youtube_id=LEGS3FbxbAs', '&youtube_id=pkV4YtYAzjs', '&youtube_id=KdKzFy_dGjg', '&youtube_id=juGFPoJqVBo', '&youtube_id=w0NtPV6UPws', '&youtube_id=JhC0StH8FgQ', '&youtube_id=HvzIO8ocBYE', '&youtube_id=KdKzFy_dGjg', '&youtube_id=nH1nxEQ0jYg', '&youtube_id=sPCK-aP6lgg', '&youtube_id=YFgLpx2EexE', '&youtube_id=XgtIp_5sT6w'],17,'https://i1.ytimg.com/sh/YO96TrSN7Do/showposter.jpg?v=508e4f85',addonString(107950).encode('utf-8'),'1',50)
	'''---------------------------'''
	
	'''ערוץ החיות באנגלית'''
	addDir(addonString(65).encode('utf-8') + space + addonString(201).encode('utf-8'),'UCS6hLNMMXi77SajUIvKGx5g',9,'http://yt3.ggpht.com/-9wTC-JCukjc/AAAAAAAAAAI/AAAAAAAAAAA/EqtzN1DW6HA/s88-c-k-no/photo.jpg',addonString(165).encode('utf-8'),'1',"")
	'''סי בייביס באנגלית'''
	addDir(addonString(63).encode('utf-8') + space + addonString(201).encode('utf-8'),'UC0fXNmjDoC7ckPyT6qM8Urw',9,'http://yt3.ggpht.com/-lrofuJsz1c8/AAAAAAAAAAI/AAAAAAAAAAA/8YJ0rAktf_o/s88-c-k-no/photo.jpg',addonString(163).encode('utf-8'),'1',"")
	'''רחוב סומסום באנגלית'''
	addDir(addonString(62).encode('utf-8') + space + addonString(201).encode('utf-8'),'UCoookXUzPciGrEZEXmh4Jjg',9,'http://yt3.ggpht.com/-Udx0C3ZTHUg/AAAAAAAAAAI/AAAAAAAAAAA/3BE1yYHQccs/s88-c-k-no/photo.jpg',addonString(162).encode('utf-8'),'1',"")
	'''יו-גאבה-גאבה באנגלית'''
	addDir(addonString(60).encode('utf-8') + space + addonString(201).encode('utf-8'),'UCxezak0GpjlCenFGbJ2mpog',9,'http://yt3.ggpht.com/-DCqlRFygCMs/AAAAAAAAAAI/AAAAAAAAAAA/OmWJ9YLZviE/s88-c-k-no/photo.jpg',addonString(160).encode('utf-8'),'1',"")
	'''---------------------------'''
	setsetting_custom1(addonID,'Current_View',50)
	
def CATEGORIES108(admin):
	'''ערוץ החינוכית'''
	addDir('[COLOR]' + addonString(10802).encode('utf-8') + '[/COLOR]','UCYFLZdLRZGnmKQBH6RB8IjA/playlists',9,'https://yt3.ggpht.com/-1dd8K8gC_zQ/AAAAAAAAAAI/AAAAAAAAAAA/TI0NA67Pzv4/s100-c-k-no/photo.jpg',addonString(108020).encode('utf-8'),'1',"")
	'''ערוץ הילדים'''
	addDir('[COLOR=Green]' + addonString(10800).encode('utf-8') + '[/COLOR]','UCOFp2_GttW3ljCuOc7r4l7g/playlists',9,'http://yt3.ggpht.com/-87JARv-G_rg/AAAAAAAAAAI/AAAAAAAAAAA/X9aVp9A1UiQ/s88-c-k-no/photo.jpg',addonString(108000).encode('utf-8'),'1',"")
	'''---------------------------'''
	
	'''בבית של פיסטוק'''
	addDir('בבית של פיסטוק','PLN0EJVTzRDL96B86muPPFwgdymQjlwmLZ',13,'https://upload.wikimedia.org/wikipedia/he/thumb/6/6c/FistukLogo.jpg/250px-FistukLogo.jpg',addonString(108040).encode('utf-8'),'1',50)
	
	'''בלי סודות'''
	addDir(addonString(10804).encode('utf-8'),['&youtube_pl=PL9FD9492D8C95F00F', '&youtube_pl=PL29CF6709AA760AB5'],6,'https://upload.wikimedia.org/wikipedia/commons/thumb/f/f2/%D7%9C%D7%95%D7%92%D7%95_%D7%A6%D7%91%D7%A2%D7%95%D7%A0%D7%99.jpg/250px-%D7%9C%D7%95%D7%92%D7%95_%D7%A6%D7%91%D7%A2%D7%95%D7%A0%D7%99.jpg','בבית של פיסטוק היא ספין-אוף של סדרת הטלוויזיה הישראלית לילדים "רגע עם דודלי".[CR]הסדרה הופקה על ידי הטלוויזיה החינוכית במשך שתי עונות בין השנים 1981 - 1983 וכללה 29 פרקים שצולמו בעונה הראשונה בשחור-לבן (18 פרקים) ובעונה השנייה בצבע (11 פרקים). הסדרה שודרה בשידורים חוזרים לאורך כל שנות השמונים והתשעים וזכתה לפופולריות רבה בקרב ילדי ישראל.[CR]עלילת הסדרה מתמקדת בהרפתקאותיהם של פיסטוק (ספי ריבלין) וידידו רגע (ציפי מור). פיסטוק הוא אדם תמהוני חביב ומגושם המתגורר בבית קטן ומוזר על ראש גבעה ורגע הוא בובה שהפכה לילד. בנוסף, התוכנית הכילה גם פינה של בובה בשם "פלטיאל ממגדיאל" וסדרה נוספת עם בובות מהולנד בשם סיפורימפו אשר דובבו לעברית.[CR]הסדרה הופקה בתקציב נמוך משמעותית מסדרת האם "רגע עם דודלי". למעט פרקים מיוחדים היא צולמה רובה ככולה באולפני הטלוויזיה החינוכית ברמת אביב. החל מעונתה השנייה, זו הייתה ההפקה הראשונה של הטלוויזיה החינוכית שצולמה בצבע.[CR]רבים מפרקי הסדרה שצולמו בשחור-לבן נחשבים כיום לאבודים, מאחר שהטלוויזיה החינוכית מעולם לא שימרה אותם ולא העבירה אותם מהסרטים המקוריים לפורמט דיגיטלי מודרני.[CR]שיר הפתיחה של התוכנית נכתב על ידי לאה נאור, הולחן על ידי נורית הירש, ובוצע על ידי אילנית.','1',50)
	
	'''גיבורי התנ"ך'''
	addDir('גיבורי התנ"ך',['&sdarot=season_id=1&series_id=1083&series_name=%d7%92%d7%99%d7%91%d7%95%d7%a8%d7%99%20%d7%94%d7%aa%d7%a0%22%d7%9a&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f1083%2fgreatest-heroes-and-legends-of-the-bible-%d7%92%d7%99%d7%91%d7%95%d7%a8%d7%99-%d7%94%d7%aa%d7%a0-%d7%9a', '&youtube_pl=PLE8E08292878C59A1', '&youtube_pl=PL67F1DD7B9B45213A', '&youtube_pl=PLx1dI0IFg6RqlKwV-RPhXx_YZfDbadc7h'],6,'http://www.sdarot.pm/media/series/1083.jpg','אנתולוגיה של אירועים מפורסמים בתנ"ך.','1',50)
	
	'''גלילאו'''
	addDir(addonString(10810).encode('utf-8'),['&youtube_pl=PLth1a195qHsjFGXCmLtU0WZDuLq4CiWz4', '&youtube_pl=PL51YAgTlfPj6Ypxb-_Dh0eoCztCXiBYsN', '&youtube_pl=PLth1a195qHsigShKnT9DsIyKxcTBQ70Tf'],6,'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e9/Hila_Korach.jpg/250px-Hila_Korach.jpg',addonString(108100).encode('utf-8'),'1',50)
	
	'''הופה היי'''
	addDir('הופה היי','PL1236E31BAFB62B85',13,'https://upload.wikimedia.org/wikipedia/he/thumb/e/ef/Hopa_Hey.jpg/250px-Hopa_Hey.jpg','הופה היי הייתה להקה ותוכנית טלוויזיה ישראלית מצליחה לילדים ולכל המשפחה אשר הופיעה וצולמה ברחבי ישראל במהלך שנות השמונים ושנות התשעים.[CR]סדרת הטלוויזיה של הופה היי הופקה לטלוויזיה מיוני 1986 עד מאי 1995 והכילה 63 פרקים. הסדרה שודרה בערוץ הראשון במסגרת מחלקת התוכניות לילדים ונוער.[CR]בעקבות הצלחת סדרת הטלוויזיה בקרב ילדי ישראל, במהלך שנות פעילותה הופיעה הלהקה ברחבי ישראל בשמונה מופעים מצליחים והוציאה שבעה אלבומים. מוצרים נלווים נוספים של הופה היי אשר נמכרו לאורך השנים כוללים ספרים, קלטות וידאו וחטיף שוקולד.','1',50)
	
	'''היה היה'''
	addDir('היה היה',['&sdarot=season_id=1&series_id=440&series_name=%d7%94%d7%99%d7%94%20%d7%94%d7%99%d7%94%20%3a%20%d7%94%d7%97%d7%99%d7%99%d7%9d%20-%20%2a%d7%9e%d7%93%d7%95%d7%91%d7%91%2a&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f440%2fonce-upon-a-time-life-%d7%94%d7%99%d7%94-%d7%94%d7%99%d7%94-%d7%94%d7%97%d7%99%d7%99%d7%9d-%d7%9e%d7%93%d7%95%d7%91%d7%91', '&sdarot=season_id=1&series_id=418&series_name=%d7%94%d7%99%d7%94%20%d7%94%d7%99%d7%94%20%3a%20%d7%94%d7%90%d7%93%d7%9d%20-%20%2a%d7%9e%d7%93%d7%95%d7%91%d7%91%2a&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f418%2fonce-upon-a-time-man-%d7%94%d7%99%d7%94-%d7%94%d7%99%d7%94-%d7%94%d7%90%d7%93%d7%9d-%d7%9e%d7%93%d7%95%d7%91%d7%91', '&sdarot=series_id=575&series_name=%d7%94%d7%99%d7%94%20%d7%94%d7%99%d7%94%20%3a%20%d7%9b%d7%93%d7%95%d7%a8%20%d7%94%d7%90%d7%a8%d7%a5%20-%20%2a%d7%9e%d7%93%d7%95%d7%91%d7%91%2a&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f575%2fonce-upon-a-time-planet-earth-%d7%94%d7%99%d7%94-%d7%94%d7%99%d7%94-%d7%9b%d7%93%d7%95%d7%a8-%d7%94%d7%90%d7%a8%d7%a5-%d7%9e%d7%93%d7%95%d7%91%d7%91', '&sdarot=season_id=1&series_id=785&series_name=%d7%94%d7%99%d7%94%20%d7%94%d7%99%d7%94%20%3a%20%d7%9e%d7%9e%d7%a6%d7%99%d7%90%d7%99%d7%9d%20%2a%d7%9e%d7%93%d7%95%d7%91%d7%91%2a&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f785%2fonce-upon-a-time-the-discoverers-%d7%94%d7%99%d7%94-%d7%94%d7%99%d7%94-%d7%9e%d7%9e%d7%a6%d7%99%d7%90%d7%99%d7%9d-%d7%9e%d7%93%d7%95%d7%91%d7%91', '&sdarot=season_id=1&series_id=803&series_name=%d7%94%d7%99%d7%94%20%d7%94%d7%99%d7%94%20%3a%20%d7%94%d7%97%d7%9c%d7%9c%20%2a%d7%9e%d7%93%d7%95%d7%91%d7%91%2a&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f803%2fonce-upon-a-time-space-%d7%94%d7%99%d7%94-%d7%94%d7%99%d7%94-%d7%94%d7%97%d7%9c%d7%9c-%d7%9e%d7%93%d7%95%d7%91%d7%91','&youtube_id=6WCaz40rvns','&youtube_id=yeReDzCnrzM','&youtube_id=Ftbsw1Bnm6U','&youtube_id=-HoFfctF_SM','&youtube_id=j53c8kOZHE4','&youtube_id=jEQWJ4yepSA','&youtube_id=bAf0wS2WHXY','&youtube_id=yybYd8d_CJc'],17,'https://upload.wikimedia.org/wikipedia/he/thumb/0/04/Once_Upon_a_Time..._Life.jpg/250px-Once_Upon_a_Time..._Life.jpg','היה היה, היא סדרת אנימציה צרפתית לילדים אשר הופקה ב-1986 על ידי חברת ההפקות הצרפתית "פרוסידיס" של אלבר בארייה.[CR]הסדרה שודרה במקור ב-1987 בערוץ הצרפתי FR3. בישראל שודרה בדיבוב לעברית בטלוויזיה החינוכית לראשונה בסוף שנות ה-80 של המאה ה-20, ולאחר מכן בשידורים חוזרים רבים. בשנים האחרונות שודרה הסדרה בערוץ לוגי ב-HOT.[CR]התוכנית מלמדת חומר חינוכי באנימציה הומוריסטית.','1',50)
	
	'''הקומדי סטור'''
	addDir(addonString(10807).encode('utf-8'),['&youtube_id=OnTGfthIrSE','&youtube_id=xyo6FLeZ3Aw','&youtube_id=aSke8kN719Q','&youtube_id=Ui6doOZZdgg','&youtube_id=kQ-w5sdqOZ8','&youtube_id=eyUuh89Ivi0','&youtube_id=Tciexh7ZTio','&youtube_id=bCGekFm2_w4','&youtube_id=xlbcC9iQA0M'],17,'https://upload.wikimedia.org/wikipedia/he/5/58/Komedi.jpg',addonString(108070).encode('utf-8'),'1',"")
	
	'''חידון התנך'''
	addDir(addonString(10809).encode('utf-8'),'PL51YAgTlfPj51ODBIMhtOF_lYxjS1cuQh',13,'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a0/Peresohad1985hidon.jpg/350px-Peresohad1985hidon.jpg',addonString(108090).encode('utf-8'),'1',50)
	
	'''פרפר נחמד'''
	addDir("פרפר נחמד",['&youtube_pl=PL51YAgTlfPj7XTzORdSrWpgCfF1x7ZUeK', '&youtube_pl=PL5B247BE19DDE24D5'],6,'http://31.168.230.11/flix/buffer/thumbs/flx2202065_200611121829495450.jpg',addonString(110).encode('utf-8'),'1',50)
	
	'''קשת וענן'''
	addDir(addonString(10805).encode('utf-8'),['&youtube_pl=PL51YAgTlfPj6qcpdP7e44dNj7xHuwd3oo', '&sdarot=season_id=1&series_id=1751&series_name=%d7%a7%d7%a9%d7%aa%20%d7%95%d7%a2%d7%a0%d7%9f&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f1751%2fkeshet-veanan-%d7%a7%d7%a9%d7%aa-%d7%95%d7%a2%d7%a0%d7%9f'],6,'https://upload.wikimedia.org/wikipedia/he/thumb/5/56/Keshet_and_Anan_logo.jpg/250px-Keshet_and_Anan_logo.jpg',addonString(108050).encode('utf-8'),'1',50)
	
	'''ראש גדול'''
	addDir('ראש גדול',['&sdarot=series_id=572&series_name=%d7%a8%d7%90%d7%a9%20%d7%92%d7%93%d7%95%d7%9c&url=http%3a%2f%2fwww.sdarot.wf%2fwatch%2f572%2frosh-gadol-%d7%a8%d7%90%d7%a9-%d7%92%d7%93%d7%95%d7%9c', '&youtube_pl=PLNMdxRa6e5t-8xyd3eFtXKIHbd6gcZPXG', '&youtube_id=2cuxr5DLnwg', '&youtube_id=TEuf9SojWug', '&youtube_id=dspu_9neTsA', '&youtube_id=syv0DjQqJQ0'],17,'http://www.sdarot.pm/media/series/572.jpg','הסדרה סובבת סביב תלמידי חטיבת ביניים טיפוסית, ופותחת צוהר אל עולמם של ילדים מרקעים שונים בגיל הייחודי שבין ילדות לבגרות.[CR]בסדרה נחשפים האלמנטים המרכזיים של חייהם: הווי בית הספר, המורים והבחינות; עולם התקשורת, המחשבים והאינטרנט; מותגים, תדמיות, וחיפוש אחר זהות אישית; מערכות היחסים עם האחים וההורים; תחילתה של עצמאות כלכלית מסוימת בגיל שבו אפשר לעבוד קצת; ובעיקר - התעוררות מהוססת וראשונית של יחסי אהבה ומשיכה לבני המין השני.','1',50)
	
	'''רגע עם דודלי'''
	addDir(addonString(10806).encode('utf-8'),'PL51YAgTlfPj5gUK-SIhbYyAMUQASzrZAw',13,'https://upload.wikimedia.org/wikipedia/he/thumb/f/fe/Dodlee.jpg/250px-Dodlee.jpg',addonString(108060).encode('utf-8'),'1',50)
	
	'''שרגא בישגדא'''
	addDir(addonString(10808).encode('utf-8'),'PL51YAgTlfPj5KPYOntZkqg2Nwyqj2M1Lf',13,'https://i.ytimg.com/vi/E5JQ2o84iSw/hqdefault.jpg',addonString(108080).encode('utf-8'),'1',50)
	'''---------------------------'''

	setsetting_custom1(addonID,'Current_View',50)
	
def CATEGORIES109(admin):
	'''קטנטנים בהולנדית 1'''
	addDir(addonString(47).encode('utf-8') + space + addonString(202).encode('utf-8') + space + "1",'UCMf-gZNpJSPq80r9e22wl9A',9,'http://yt3.ggpht.com/-BXNeRxPOFpU/AAAAAAAAAAI/AAAAAAAAAAA/3DZSjgkhfJM/s88-c-k-no/photo.jpg',addonString(110).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''קטנטנים באוקראינית 1'''
	addDir(addonString(47).encode('utf-8') + space + addonString(203).encode('utf-8') + space + "1",'UCZAL3xoDj13SeJGTFhq00Tw',9,'http://yt3.ggpht.com/-TrrOJ-NiNys/AAAAAAAAAAI/AAAAAAAAAAA/lhx315yY5gs/s88-c-k-no/photo.jpg',addonString(110).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''שירים בצרפתית 1'''
	addDir(addonString(57).encode('utf-8') + space + addonString(204).encode('utf-8') + space + "1",'comptines',9,'https://yt3.ggpht.com/-MT6ThcO_qNI/AAAAAAAAAAI/AAAAAAAAAAA/GDibk7v0-FA/s100-c-k-no/photo.jpg',addonString(110).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''קטנטנים בצרפתית 1'''
	addDir(addonString(47).encode('utf-8') + space + addonString(204).encode('utf-8') + space + "1",'ssebastienn',9,'https://yt3.ggpht.com/-dhcbXAt2vto/AAAAAAAAAAI/AAAAAAAAAAA/hCIp6-YvL6w/s100-c-k-no/photo.jpg',addonString(188).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''שירים ברוסית 1'''
	addDir(addonString(57).encode('utf-8') + space + addonString(205).encode('utf-8') + space + "1",'PLJgmMSdWwadtTK4JzHhl5N5YR49ZVcGTK',13,'http://www.mapsofworld.com/images/world-countries-flags/russian-federation-flag.gif',addonString(110).encode('utf-8'),'1',"")
	'''---------------------------'''
	
	setsetting_custom1(addonID,'Current_View',50)
	
def CATEGORIES103(admin):
	setsetting_custom1(addonID,'Current_View',50)

	
#add_cat("רינת ויויו", "PLVisQUXwii8qa6lRDe1OmCIup6ylcprfc")
#add_cat("דורה ודייגו", "PLqx6fN1abed4oHQ2Y5xadY-ILjzFdoMNM")
#add_cat("פסטיגל", "PLwimDnICcPKPL4MdOLIQrGDMTOAshuQ2l")
#add_cat("מיקי", "PLwimDnICcPKP4vFp6zklqeNUSdq08mN1H")
#add_cat("מר עגבניה", "PLwimDnICcPKMSeyub1DLM_2jG4aPjqI7n")
#add_cat("לולי", "PLwimDnICcPKNQy5TSz2s5XKWsE6kKV5C1")
#add_cat("סופר סטרייקה", "PLU6_PRY_7y1TQMr67fJ6WC2mzkqtVyU3B")
#add_cat("דורימון", "PL95CWWe9DuaJ6xtv1V8ZxDvoG_cB3z4bc")
#add_cat("שירים לרזי", "PLdhkcuUltKcfTUBHVy02eKfRIEnmg7fnn")
