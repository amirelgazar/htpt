# -*- coding: utf-8 -*-
import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os
AddonID = 'plugin.video.htpt.kids' 
ADDON = xbmcaddon.Addon(id=AddonID)

from variables import *

def downloader_israel(url, name, showProgress=True):
	import downloader, extract

	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')

	if showProgress:
		dp = xbmcgui.DialogProgress()
		dp.create(AddonName, "Downloading", name, "Please Wait")
		downloader.download(url, packageFile, dp)
		dp.update(0, "", "Extracting Zip Please Wait")
		extract.all(packageFile, addonsDir, dp)
	else:
		urllib.urlretrieve(url, packageFile)
		extract.all(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")

#using xunity downloader with changes 
def downloader_is (custom, url, name):
 import downloader,extract   
 i1iIIII = xbmc . getInfoLabel ( "System.ProfileName" )
 I1 = xbmc . translatePath ( os . path . join ( 'special://home' , '' ) )
 O0OoOoo00o = xbmcgui . Dialog ( )
 if name.find('repo')< 0 and custom == "1":
     returned = dialogyesno(name, '$LOCALIZE[70020]')
 else:
     returned = "ok"
 if returned == "ok":
    iiI1iIiI = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
    iiiI11 = xbmcgui . DialogProgress ( )
    iiiI11.create('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + '$LOCALIZE[31407]' , '$LOCALIZE[24067]' , '' , '' )
    OOooO = os.path.join(iiI1iIiI , 'isr.zip' )
    try :
		os . remove ( OOooO )
    except :
        pass
    downloader . download ( url , OOooO , iiiI11 )
    II111iiii = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
    iiiI11 . update ( 0 , "" , "Extracting Zip Please Wait" )
    print '======================================='
    print II111iiii
    print '======================================='
    extract . all ( OOooO , II111iiii , iiiI11 )
    iiiI11 . update ( 0 , "" , "Downloading" )
    iiiI11 . update ( 0 , "" , "Extracting Zip Please Wait" )
    xbmc.executebuiltin('UpdateLocalAddons')
    xbmc.executebuiltin("UpdateAddonRepos")
    if 96 - 96: i1IIi . ii1IiI1i * iiiIIii1I1Ii % i111I
    if 60 - 60: iII11iiIII111 * IIIiiIIii % IIIiiIIii % O00oOoOoO0o0O * i11i + i1IIi

def dialogprogress(admin, id, action, name, header, line1, line2):
	id = xbmcgui.DialogProgress( )
	if action == 0: returned = id.create(name, header, line1, line2)
	else: returned = ""
	return returned
	
def unescape(text):
        try:            
            rep = {"&nbsp;": " ",
                   "\n": "",
                   "\t": "",
                   "\r":"",
                   "&#39;":"",
                   "&quot;":"\""
                   }
            for s, r in rep.items():
                text = text.replace(s, r)
				
            # remove html comments
            text = re.sub(r"<!--.+?-->", "", text)    
				
        except TypeError:
            pass

        return text

def findin_containerfolderpath2(custom,what,sleep,action,action2):
	'''action = not found | action2 = when found'''
	'''---------------------------'''
	what = str(what)
	containerfolderpath = xbmc.getInfoLabel('Container.FolderPath('+ what +')')
	
	#if custom == "0" and (what != "" and not containerfolderpath and action != ""): setView("", 50)
	'''---------------------------'''
	xbmc.sleep(sleep)
	containerfolderpath = xbmc.getInfoLabel('Container.FolderPath('+ what +')')
	xbmc.sleep(sleep)
	'''---------------------------'''
	if custom == "0" and (what != "" and what != containerfolderpath and containerfolderpath != "" and action2 != ""): setView(action, action2)
	'''---------------------------'''
	return containerfolderpath
	
def update_view(url):
    ok=True        
    xbmc.executebuiltin('XBMC.Container.Update(%s)' % url )
    containerfolderpath2 = xbmc.getInfoLabel('Container.FolderPath')
    containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
    count = 0
    while count < 20 and containerfolderpath2 == containerfolderpath and containerfolderpath != "" and not xbmc.abortRequested:
        count += 1
        if "http://nickjr.walla.co.il/" in url: containerfolderpath = findin_containerfolderpath2("0", containerfolderpath2, 200, "", 50)
        elif ("plugin.video.gozlan.me" in url or "plugin.video.seretil" in url or "plugin.video.wallaNew.video" in url or "plugin.video.supercartoons" in url or "plugin.video.sdarot.tv" in url or "seretil.me" in url): containerfolderpath = findin_containerfolderpath2("0", containerfolderpath2, 200, "", 58)
    countS = str(count)
    notification("test2",countS,"",1000)
	#print printfirst + "update_view" + space2 + countS + space + 
    return ok




def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    #list58 = ['plugin.video.sdarot.tv']
    #if 'plugin.video.sdarot.tv' in url: setView("", 58)
    #else: setView("", 50)
    return link
    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addDir(name, url, mode, iconimage, desc, num):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&num="+urllib.quote_plus(num)
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": desc} )
        menu = []
        
        #ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        if mode==12:
                #url=urllib.unquote(url)
                menu.append(('[COLOR=Purple]' + addonString(8).encode('utf-8') + '[/COLOR]', "XBMC.Container.Update(plugin://plugin.video.htpt.kids/?num&iconimage=''&mode=13&name=''&url=%s)"% (url)))
                liz.addContextMenuItems(items=menu, replaceItems=True)
                ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
                return ok
        if mode==9:
                menu.append(('[COLOR=Green]' + addonString(9).encode('utf-8') + '[/COLOR]', "XBMC.RunPlugin(plugin://plugin.video.htpt.kids/?num&iconimage=''&mode=115&name=''&url=%s)"% (url)))
                liz.addContextMenuItems(items=menu, replaceItems=True)
                ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
                return ok
        elif  mode==8 :
                ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
                return ok
        elif mode==11 or mode==15 or mode==115 :
                ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
                return ok
        elif mode==13:
             menu.append(('[COLOR=Yellow]' + addonString(5).encode('utf-8') + '[/COLOR]', "XBMC.RunPlugin(plugin://plugin.video.htpt.kids/?num&iconimage=''&mode=12&name=''&url=%s)"% (url)))
             liz.addContextMenuItems(items=menu, replaceItems=True)
             ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
             return ok
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addVideoLink(name, url, mode, iconimage='DefaultFolder.png', summary = ''):
        u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + name
        liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote(name), "Plot": urllib.unquote(summary)})    
        liz.setProperty('IsPlayable', 'true')
        ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
        return ok
		
def addLink(name,url,iconimage,desc):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": desc } )
        liz.setProperty("IsPlayable","true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
        return ok

		#below tells plugin about the views                
		
def setView(content, viewType):
	'''set content type so library shows more views and info'''
	if content:
		xbmcplugin.setContent(int(sys.argv[1]), content)
	if viewType == "":
		if content == 'episodes': viewType = 50
		elif content == 'seasons': viewType = 50
		elif content == 'tvshows': viewType = 58
		elif content == 'movies': viewType = 58
		else: viewType = 50
	if admin: notification("test3","","",1000)
	if General_AutoView == "true": xbmc.executebuiltin("Container.SetViewMode(%s)" % viewType )
                
                
                
def CleanTheCache():
    dir=xbmc.translatePath('special://temp/')
    file=os.path.join(dir, 'commoncache.db')
    f = open(file, 'w')
    f.write('')
    f.close
    
    dialogok("Cache Deleted!","","","")
    
                      
def mes():

        
	try:
		link=OPEN_URL('http://goo.gl/r6eog7')
		r = re.findall(r'ANNOUNCEMENTWINDOW ="ON"',link)
		if not r:
			return
			
		match=re.compile('<new>(.*?)\\n</new>',re.I+re.M+re.U+re.S).findall(link)
		if not match[0]:
			return
			
		#version = ADDON.getAddonInfo('version')
		dire=os.path.join(xbmc.translatePath( "special://userdata/addon_data" ).decode("utf-8"), addonID)
		if not os.path.exists(dire):
			'''------------------------------
			---CREATE-USERDATA-DIRECTORY-----
			------------------------------'''
			os.makedirs(dire)
			'''---------------------------'''
		aSeenFile = os.path.join(dire, 'announcementSeen.txt')
		if (os.path.isfile(aSeenFile)): 
			f = open(aSeenFile, 'r') 
			content = f.read() 
			f.close() 
			if content == match[0] :
				return

		f = open(aSeenFile, 'w') 
		f.write(match[0]) 
		f.close() 

		dp = xbmcgui . Dialog ( )
		dp.ok("UPDATES", match[0])
	except:
		pass

		
def dialogok(heading,line1,line2,line3):
	'''------------------------------
	---DIALOG-OK---------------------
	------------------------------'''
	dialog = xbmcgui.Dialog()
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	if '$LOCALIZE' in line1 or '$ADDON' in line1: line1 = xbmc.getInfoLabel(line1)
	if '$LOCALIZE' in line2 or '$ADDON' in line2: line2 = xbmc.getInfoLabel(line2)
	if '$LOCALIZE' in line3 or '$ADDON' in line3: line3 = xbmc.getInfoLabel(line3)
	#heading = str(heading.encode('utf-8'))
	#line1 = str(line1.encode('utf-8'))
	#line2 = str(line2.encode('utf-8'))
	#line3 = str(line3.encode('utf-8'))

	dialog.ok(heading,line1,line2,line3)
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + heading + space2 + line1 + space2 + line2 + space2 + line3
	'''---------------------------'''

def dialogselect(heading, list, autoclose):
	'''------------------------------
	---DIALOG-SELECT-----------------
	------------------------------'''
	dialog = xbmcgui.Dialog()
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)

	returned = dialog.select(heading,list,autoclose)
	returned = str(returned)
	
	print printfirst + heading + "( " + returned + " )"
	return returned
	'''---------------------------'''
	
def dialogkeyboard(input, heading, option, custom, addonsetting, addonsetting2):
	''''''
	if '$LOCALIZE' in heading: heading = xbmc.getInfoLabel(heading)
	dialog = xbmcgui.Dialog()
	keyboard = xbmc.Keyboard(input,heading,option)
	keyboard.doModal()
	returned = 'skip'
	if (keyboard.isConfirmed()):
		input2 = keyboard.getText()
		if custom == '1' and input2 != "": returned = 'ok'
		if custom == '2' and input2 == input: returned = 'ok'
		if custom == '3':
			if input2 != input and input2 != "" and option == 0: xbmc.executebuiltin('Notification('+ heading +': '+ input2 +',,4000)')
			if input2 != "": returned = 'ok'
			
		if option == 0: print printfirst + heading + space2 + input2 + " ( " + returned + " )"
		elif option != 0: print printfirst + heading + space2 + "*******" + " ( " + returned + " )"
	if returned == 'ok':
		returned == input2
		if addonsetting2 == "0": setsetting(addonsetting, input2)
		elif 'genesis' in addonsetting2:
			setsetting_genesis          = xbmcaddon.Addon('plugin.video.genesis').setSetting
			setsetting_genesis(addonsetting, input2)
		elif 'sdarot.tv' in addonsetting2:
			setsetting_sdarottv          = xbmcaddon.Addon('plugin.video.sdarot.tv').setSetting
			setsetting_sdarottv(addonsetting, input2)
	return returned

def dialognumeric(type,heading,input,custom,addonsetting):
	'''type: 0 = #, 1 = DD/MM/YYYY, 2 = HH:MM, 3 = #.#.#.#, message2 = heading, message1 = content'''
	if '$LOCALIZE' in heading: heading = xbmc.getInfoLabel(heading)
	try:
		input = int(input)
	except:
		input = 0
	returned = 'skip'
	try:
		if int(input) > 001000000 and int(input) < 9999999999 and input != "": input = str(input)
	except TypeError:
		input = 0
		print printfirst + "dialognumeric " + "except TypeError (1)"
	input = str(input)
	input2 = xbmcgui.Dialog().numeric(type, heading, input)
	try:
		if input2 != "": input2 = int(input2)
	except TypeError:
		xbmc.executebuiltin('Notification($LOCALIZE[257],$LOCALIZE[31406],2000)')
		sys.exit()
	if custom == '0':
		try:
			if input2 > 001000000 and input2 < 9999999999: returned = 'ok'
			elif input2 < 001000000 or input2 > 9999999999: returned = 'skip0'
		except TypeError:
			returned = 'skip'
	if custom == '1':
		if input2 != "": returned = 'ok'
	if custom == '2':
		if input2 == "": input2 = 0
		elif input2 != 0: returned = 'ok'
	#if type == '2' and input == message1: returned = 'ok'
	
	input = str(input)
	input2 = str(input2)
	print printfirst + heading + space2 + input2 + "( " + returned + " )"
	if returned == 'ok':
		if custom != "2":
			returned == input
			setsetting(addonsetting, input2)
		elif custom == "2":
			returned == input
			if returned == "": returned = 0
			setSkinSetting("0", addonsetting, input2)
			#setsetting(addonsetting, input2)
			
	return returned

def dialogyesno(heading,line1):
	'''------------------------------
	---DIALOG-YESNO------------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	if '$LOCALIZE' in line1 or '$ADDON' in line1: line1 = xbmc.getInfoLabel(line1)
	returned = 'skip'
	if dialog.yesno(heading,line1): returned = 'ok'
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "dialogyesno" + space2 + heading + space3 + line1 + "( " + returned + " )"
	'''---------------------------'''
	return returned
	'''---------------------------'''

def notification(heading, message, icon, time):
	'''------------------------------
	---Show a Notification alert.----
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	'''heading : string - dialog heading | message : string - dialog message. | icon : [opt] string - icon to use. (default xbmcgui.NOTIFICATION_INFO/NOTIFICATION_WARNING/NOTIFICATION_ERROR) | time : [opt] integer - time in milliseconds (default 5000) | sound : [opt] bool - play notification sound (default True)'''
	
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	if '$LOCALIZE' in message or '$ADDON' in message: message = xbmc.getInfoLabel(message)
	
	icon = "misc/logo/logo8.png"
	
	dialog.notification(heading, message, icon, time)
	
	#if "addonString" in heading and not "+" in heading: heading = str(heading.encode('utf-8'))
	if "addonString" in heading: heading = str(heading.encode('utf-8'))
	elif '$LOCALIZE' in heading or '$ADDON' in heading: heading = str(heading)
	if "addonString" in message: message = str(message.encode('utf-8'))
	elif '$LOCALIZE' in message or '$ADDON' in message: message = str(message)
	
	time = str(time)
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin:
		try: print printfirst + "notification" + space2 + heading + space3 + message + space + time
		except: print printfirst + "notification" + "..."
		'''---------------------------'''

def addonsettings(name, addon,skinsettingS, skinsetting2S, usernameS, passwordS, set3,opt1,opt2,opt3):
	'''------------------------------
	---SET-USERNAME-AND-PASSWORD-----
	------------------------------'''
	getsetting_custom          = xbmcaddon.Addon(addon).getSetting
	setsetting_custom          = xbmcaddon.Addon(addon).setSetting
	
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	skinsetting = xbmc.getInfoLabel('Skin.HasSetting('+ skinsettingS +')')
	skinsetting2 = xbmc.getInfoLabel('Skin.String('+ skinsetting2S +')')
	#if setting_custom == truestr: setting_custom = "true"
	#else: setting_custom = "false"
	try: skinsetting2N = int(skinsetting2)
	except: skinsetting2N = 0
	username = getsetting_custom(usernameS)
	password = getsetting_custom(passwordS)
	setting3 = getsetting_custom(set3)
	printpoint = ""
	'''---------------------------'''
	if (skinsetting or id9str == 'Trial' or id2str == datenowS) and usernameS != "" and passwordS != "":
		if admin: notification("test0","","",1000)
		if ('htpt' in username and not "finalmakerr" in idstr) and idstr != username and id9str != 'Trial' and id2str != datenowS:
			'''------------------------------
			---SET-DEFAULT-------------------
			------------------------------'''
			setsetting_custom(usernameS,idstr)
			setsetting_custom(passwordS,idpstr)
			printpoint = printpoint + "1"
			if admin: notification("test1","","",1000)
			'''---------------------------'''
		elif id9str == 'Trial' or id2str == datenowS:
			'''------------------------------
			---SET-TRIAL---------------------
			------------------------------'''
			setsetting_custom(usernameS,idtrial)
			setsetting_custom(passwordS,idp2str)
			printpoint = printpoint + "2"
			if admin: notification("test2","","",1000)
			'''---------------------------'''
		elif skinsetting and ((username == "" or password == "") or skinsetting2 == "0"):
			'''------------------------------
			---SET-NONE----------------------
			------------------------------'''
			setsetting_custom(usernameS,"")
			setsetting_custom(passwordS,"")
			printpoint = printpoint + "5"
			if admin: notification("test1.2","","",1000)
			'''---------------------------'''
		elif skinsetting:
			'''------------------------------
			---NO-CHANGES--------------------
			------------------------------'''
			printpoint = printpoint + "6"
			if admin: notification("test1.3","","",1000)
			'''---------------------------'''
	else:
		'''------------------------------
		---NO-ACCOUNT-OR-TRIAL-----------
		------------------------------'''
		daynowS = get_daynow(1)
		timezone = get_timenow(1)
		General_TimeZone = getsetting('General_TimeZone')
		if name == 'REALDEBRID' and (daynowS == opt1 or General_TimeZone != opt2):
			'''------------------------------
			---SET-NONE----------------------
			------------------------------'''
			setsetting_custom(usernameS,"")
			setsetting_custom(passwordS,"")
			printpoint = printpoint + "3"
			'''---------------------------'''
		else:
			'''------------------------------
			---SET-DEFAULT-------------------
			------------------------------'''
			setsetting_custom(usernameS,idstr)
			setsetting_custom(passwordS,idpstr)
			printpoint = printpoint + "4"
			'''---------------------------'''
			
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if printpoint == "0": print printfirst + "addonsettings LV_0" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "?"
	if printpoint == "1": print printfirst + "addonsettings LV_1" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "RESET"
	elif printpoint == "2": print printfirst + "addonsettings LV_2" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "Trial / DATENOW"
	elif printpoint == "3": print printfirst + "addonsettings LV_3" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "NONE" + space + "ID: " + idstr + space + "daynowS" + space2 + daynowS + space + "timenow3S" + space2 + timenow3S + space + "datenowS" + space2 + datenowS + space + "timezone" + space2 + timezone
	elif printpoint == "4": print printfirst + "addonsettings LV_4" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "DEFAULT" + space + "ID: " + idstr + space + "timezone" + space2 + timezone
	elif printpoint == "5": print printfirst + "addonsettings LV_5" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "skinsetting2" + space2 + skinsetting2 + "UNREGISTER"
	elif printpoint == "6": print printfirst + "addonsettings LV_6" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "REGISTERED"
	elif printpoint == "": print printfirst + "addonsettings LV_0-Error?"
	'''---------------------------'''
	
def addonsettings2(addon,set1,set1v,set2,set2v,set3,set3v,set4,set4v,set5,set5v):
	'''------------------------------
	---SET-ADDON-SETTING-5-----------
	------------------------------'''
	getsetting_custom          = xbmcaddon.Addon(addon).getSetting
	setsetting_custom          = xbmcaddon.Addon(addon).setSetting

	setting1 = getsetting_custom(set1)
	setting2 = getsetting_custom(set2)
	setting3 = getsetting_custom(set3)
	setting4 = getsetting_custom(set4)
	setting5 = getsetting_custom(set5)
	
	checkChange = "false"
	'''---------------------------'''
	if set1 != "" and set1v != setting1:
		setsetting_custom(set1,set1v)
		if checkChange != "true": checkChange = "true"
	if set2 != "" and set2v != setting2:
		setsetting_custom(set2,set2v)
		if checkChange != "true": checkChange = "true"
	if set3 != "" and set3v != setting3:
		setsetting_custom(set3,set3v)
		if checkChange != "true": checkChange = "true"
	if set4 != "" and set4v != setting4:
		setsetting_custom(set4,set4v)
		if checkChange != "true": checkChange = "true"
	if set5 != "" and set5v != setting5:
		setsetting_custom(set5,set5v)
		if checkChange != "true": checkChange = "true"
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if checkChange == "true": print printfirst + "addonsettings2 " + addon + space + set1 + space2 + set1v + space + set2 + space2 + set2v + space + set3 + space2 + set3v + space + set4 + space2 + set4v + space + set5 + space2 + set5v + space
	'''---------------------------'''
	
def setsetting_custom1(addon,set1,set1v):
	'''------------------------------
	---SET-ADDON-SETTING-1-----------
	------------------------------'''
	getsetting_custom          = xbmcaddon.Addon(addon).getSetting
	setsetting_custom          = xbmcaddon.Addon(addon).setSetting
	
	set = getsetting_custom(set1)
	'''---------------------------'''
	if set != set1v:
		setsetting_custom(set1,set1v)
		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		print printfirst + "setsetting_custom1" + space2 + addon + space + set1 + space2 + set1v + space3
		'''---------------------------'''
		
def setSkinSetting(custom,set1,set1v):
	'''------------------------------
	---SET-SKIN-SETTING-1------------
	------------------------------'''
	from variables import truestr
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	admin2 = xbmc.getInfoLabel('Skin.HasSetting(Admin2)')

	''' custom: 0 = Skin.String, 1 = Skin.HasSetting'''
	'''---------------------------'''
	if custom == "0":
		setting1 = xbmc.getInfoLabel('Skin.String('+ set1 +')')
		setting2 = ""
		if setting1 != set1v: xbmc.executebuiltin('Skin.SetString('+ set1 +','+ set1v +')')
		'''---------------------------'''
		
	elif custom == "1":
		setting2 = xbmc.getInfoLabel('Skin.HasSetting('+ set1 +')')
		if setting2 == truestr: setting1 = "true"
		else:
			setting1 = "false"
		if setting1 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set1 +')')
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if setting1 != set1v and admin and admin2: print printfirst + "setSkinSetting" + space3 + custom + space + set1 + space2 + setting1 + " - " + set1v + space3 + "( " + "setting2" + space2 + setting2 + " ) "
	'''---------------------------'''

def setSkinSetting5(custom,set1,set1v,set2,set2v,set3,set3v,set4,set4v,set5,set5v):
	'''------------------------------
	---SET-SKIN-SETTING-5------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	''' custom: 0 = Skin.String, 1 = Skin.HasSetting'''
	if custom == "0":
		setting1 = xbmc.getInfoLabel('Skin.String('+ set1 +')')
		setting2 = xbmc.getInfoLabel('Skin.String('+ set2 +')')
		setting3 = xbmc.getInfoLabel('Skin.String('+ set3 +')')
		setting4 = xbmc.getInfoLabel('Skin.String('+ set4 +')')
		setting5 = xbmc.getInfoLabel('Skin.String('+ set5 +')')
	elif custom == "1":
		setting1 = xbmc.getInfoLabel('Skin.HasSetting('+ set1 +')')
		setting2 = xbmc.getInfoLabel('Skin.HasSetting('+ set2 +')')
		setting3 = xbmc.getInfoLabel('Skin.HasSetting('+ set3 +')')
		setting4 = xbmc.getInfoLabel('Skin.HasSetting('+ set4 +')')
		setting5 = xbmc.getInfoLabel('Skin.HasSetting('+ set5 +')')
	'''---------------------------'''
	if custom == "0":
		if setting1 != set1v: xbmc.executebuiltin('Skin.SetString('+ set1 +','+ set1v +')')
		if setting2 != set2v: xbmc.executebuiltin('Skin.SetString('+ set2 +','+ set2v +')')
		if setting3 != set3v: xbmc.executebuiltin('Skin.SetString('+ set3 +','+ set3v +')')
		if setting4 != set4v: xbmc.executebuiltin('Skin.SetString('+ set4 +','+ set4v +')')
		if setting5 != set5v: xbmc.executebuiltin('Skin.SetString('+ set5 +','+ set5v +')')
	elif custom == "1":
		if setting1 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set1 +')')
		if setting2 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set2 +')')
		if setting3 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set3 +')')
		if setting4 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set4 +')')
		if setting5 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set5 +')')
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''	
	if admin and (setting1 != set1v or setting2 != set2v or setting3 != set3v or setting4 != set4v or setting5 != set5v): print printfirst + "setSkinSetting5" + space2 + set1 + space + set2 + space + set3 + space + set4 + space + set5 + space3
	'''---------------------------'''
	
def calculate(addon,set1,custom):
	'''------------------------------
	---RETURN-CALCULATE-NUMBER-------
	------------------------------'''	
	getsetting_custom          = xbmcaddon.Addon(addon).getSetting
	setsetting_custom          = xbmcaddon.Addon(addon).setSetting
	
	set1v = getsetting_custom(set1)
	set1v = int(set1v)
	
	if custom == '1': set1v += 1
	elif custom == '2': set1v += -1
		
	set1v = str(set1v)
	setsetting_custom(set1, set1v)
	
	return set1v
	'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''	
	print printfirst + "calculate" + space + addon + space + set1 + space2 + set1v
	'''---------------------------'''

def setAddon_Version(admin):
	'''------------------------------
	---CHECK-FOR-ADDON-UPDATE-2------
	------------------------------'''
	if Addon_Version != addonVersion:
		setAddon_UpdateLog(admin, Addon_Version)
		setsetting('Addon_Version',addonVersion)
		'''---------------------------'''	
		
		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		print printfirst + "setAddon_Version" + space2 + "Addon_Version" + space2 + Addon_Version + " - " + addonVersion
		'''---------------------------'''
	
def setAddon_UpdateLog(admin, Addon_Version):	
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	header = '[COLOR=Yellow]' + addonString(304).encode('utf-8') + " - " + addonVersion + '[/COLOR]'
	'''---------------------------'''
	log = open(addonPath + "/" + 'changelog.txt', 'r')
	message2 = log.read()
	log.close()
	message2S = str(message2)
	message3 = message2[80:8000]
	message3.replace("'", '')
	message3.replace(",", ' ')
	message3S = str(message3)
	if header != "":
		w = TextViewer_Dialog('DialogTextViewer.xml', addonPath, header=header, text=message2)
		w.doModal()	
	else: header = ""
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "setAddon_UpdateLog"
	'''---------------------------'''
	
'''------------------------------
---CUSTOM------------------------
------------------------------'''

class TextViewer_Dialog(xbmcgui.WindowXMLDialog):
    ACTION_PREVIOUS_MENU = [9, 92, 10]

    def __init__(self, *args, **kwargs):
        xbmcgui.WindowXMLDialog.__init__(self)
        self.text = kwargs.get('text')
        self.header = kwargs.get('header')

    def onInit(self):
        self.getControl(1).setLabel(self.header)
        self.getControl(5).setText(self.text)

    def onAction(self, action):
        if action in self.ACTION_PREVIOUS_MENU:
            self.close()

    def onClick(self, controlID):
        pass

    def onFocus(self, controlID):
        pass
		
		
def replace_word(infile,old_word,new_word):
    if not os.path.isfile(infile):
        print ("Error on replace_word, not a regular file: "+infile)
        sys.exit(1)

    f1=open(infile,'r').read()
    f2=open(infile,'w')
    m=f1.replace(old_word,new_word)
    f2.write(m)

def stringtodate(dt_str, dt_func):
	from datetime import datetime
	#dt_str = '9/24/2010 5:03:29 PM'
	#dt_func = '%m/%d/%Y %I:%M:%S %p'
	try:
		dt_obj = datetime.strptime(dt_str, dt_func)
		return dt_obj
	except:
		notification("stringtodate_ERROR!","sys.exit()","",5000)
		sys.exit()

