# -*- coding: utf-8 -*-
import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os

from variables import *
from shared_modules import *
if "plugin." in addonID: from shared_modules3 import *
'''---------------------------'''

def CATEGORIES():
	'''------------------------------
	---MAIN--------------------------
	------------------------------'''
	addDir(addonString(41).encode('utf-8'),'',101,addonMediaPath + "41.png",addonString(141).encode('utf-8'),'1',"")
	addDir(addonString(42).encode('utf-8'),'',102,addonMediaPath + "42.jpg",addonString(142).encode('utf-8'),'1',"")
	addDir(addonString(44).encode('utf-8'),'',104,addonMediaPath + "44.png",addonString(144).encode('utf-8'),'1',"")
	addDir(addonString(45).encode('utf-8'),'',105,addonMediaPath + "45.jpg",addonString(145).encode('utf-8'),'1',"")
	addDir(addonString(46).encode('utf-8'),'',106,addonMediaPath + "46.png",addonString(146).encode('utf-8'),'1',"")
	addDir(addonString(47).encode('utf-8'),'',107,addonMediaPath + "47.jpg",addonString(147).encode('utf-8'),'1',"")
	addDir(addonString(48).encode('utf-8'),'',108,addonMediaPath + "48.jpg",addonString(148).encode('utf-8'),'1',"")
	addDir(addonString(49).encode('utf-8'),'',109,addonMediaPath + "49.jpg",addonString(149).encode('utf-8'),'1',"")
	if General_TrustedOnly == "false": addDir(addonString(43).encode('utf-8'),'',111,addonMediaPath + "42.jpg",addonString(143).encode('utf-8'),'1',"")
	
	
	
	
	'''many sources'''
	#YOUsubs('UC5RJ8so5jivihrnHB5qrV_Q')
	setsetting_custom1(addonID,'Current_View',50)
	'''------------------------------
	---וואלה-VOD!--------------------
	------------------------------'''
	
	
	#if OFF_9 != "true": addDir(addonString(22).encode('utf-8'),'plugin://plugin.video.wallaNew.video/?mode=1&module=wallavod&name=%d7%99%d7%9c%d7%93%d7%99%d7%9d&url=englishName%3dkids',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300',addonString(110).encode('utf-8'),'1',"")
	#if OFF_9 != "true": addDir('קלסיקלטת','plugin://plugin.video.wallaNew.video/?mode=1&module=338&name=קלסיקלטת&url=http://vod.walla.co.il/channel/338/clasicaletet',8,'https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcTYE2VT8CR2O31MsqAhdaydYrqrCD--HCCdGcs7blBn3Zh92Kwq','','1',"")
	#if OFF_10 != "true": addDir('ניק','plugin://plugin.video.wallaNew.video/?mode=1&module=nick&name=ניק&url=http://nick.walla.co.il/',8,'http://www.karmieli.co.il/sites/default/files/images/nico.jpg','','1',"")
	#if OFF_11 != "true": addDir('גוניור','plugin://plugin.video.wallaNew.video/?mode=1&module=junior&name=גוניור&url=http://junior.walla.co.il/',8,'http://upload.wikimedia.org/wikipedia/he/1/19/%D7%A2%D7%A8%D7%95%D7%A5_%D7%92%27%D7%95%D7%A0%D7%99%D7%95%D7%A8.jpg','','1',"")
	#if OFF_13 != "true": addDir('וואלה ילדים','plugin://plugin.video.wallaNew.video/?mode=1&module=wallavod&name=י%d7%99%d7%9c%d7%93%d7%99%d7%9d&url=englishName%3dkids',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300','','1',"")
	'''---------------------------'''
	

'''1=SONGS, 2=SHOWS, 3=LITTLE, 4=TVSHOWS, 5=MOVIES, 6=?, 7=BABY, 8=?, 9=OTHERS'''
def CATEGORIES101(admin):
	'''שירים לילדים בעברית 1'''
	addDir(addonString(57).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "1" + space5 + addonString(16).encode('utf-8'),'UCfm5IpcgGCooON4Mm2vq40A',9,'http://i.ytimg.com/i/fm5IpcgGCooON4Mm2vq40A/1.jpg?v=52fcd974',addonString(116).encode('utf-8'),'1',"")
	'''שירים לילדים בעברית 2 - חינוכית'''
	addDir(addonString(57).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "2" + space5 + addonString(39).encode('utf-8'),'23music',9,addonMediaPath + "92.jpg",addonString(139).encode('utf-8'),'1',"")
	'''שירים לילדים בעברית 3 - ייס'''
	addDir(addonString(57).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "3" + space5 + addonString(21).encode('utf-8'),'PLF11AD94724D37E02',13,'http://static.wixstatic.com/media/96e157_2b95d7111507dcbbf4d07a346b1a08bf.jpg_srz_261_263_85_22_0.50_1.20_0.00_jpg_srz',addonString(121).encode('utf-8'),'1',"")
	'''שירים לילדים בעברית 4 - דיסני'''
	addDir(addonString(57).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "4" + space5 + addonString(38).encode('utf-8'),'plugin://plugin.video.youtube/channel/UC6QxAhInaZ79pTg7wi3ZF-Q/',8,'http://i.ytimg.com/i/6QxAhInaZ79pTg7wi3ZF-Q/1.jpg?v=78ea3c',addonString(138).encode('utf-8'),'1',"")
	'''שירים לילדים בעברית 5'''
	addDir(addonString(57).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "5",'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%a9%d7%99%d7%a8%d7%99%d7%9d%20(19)&url=genre%3dkids%26genreId%3d7450',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300',addonString(197).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''שירים לילדים בעברית 6'''
	addDir(addonString(57).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "6",'PLErYJg2XgxyVYzsbPxH2dzhlWLs9sWGTa',13,'http://erezdvd.co.il/sites/default/files/imagecache/product_full/products/numi-numi.jpg',addonString(128).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''שירים לילדים באנגלית 1 - פשוט ללמוד אנגלית'''
	addDir(addonString(57).encode('utf-8') + space + addonString(201).encode('utf-8') + space + "1" + space5 + addonString(55).encode('utf-8'),'UCLsooMJoIpl_7ux2jvdPB-Q',9,'http://yt3.ggpht.com/-nHzSx4QKfsY/AAAAAAAAAAI/AAAAAAAAAAA/o_0k7TejOiI/s88-c-k-no/photo.jpg',addonString(155).encode('utf-8'),'1',"")
	
	'''שירים לילדים באנגלית 3 - ילדים 123'''
	addDir(addonString(57).encode('utf-8') + space + addonString(201).encode('utf-8') + space + "3" + space5 + addonString(53).encode('utf-8'),'UCtgpDqkeOToveUgh8igrvXQ',9,'http://yt3.ggpht.com/-g_tUdVsQVnU/AAAAAAAAAAI/AAAAAAAAAAA/KqZGxwkomOo/s88-c-k-no/photo.jpg',addonString(153).encode('utf-8'),'1',"")
	'''שירים לילדים באנגלית 4 - הופלה קידס'''
	addDir(addonString(57).encode('utf-8') + space + addonString(201).encode('utf-8') + space + "4" + space5 + addonString(52).encode('utf-8'),'UC3djj8jS0370cu_ghKs_Ong',9,'http://yt3.ggpht.com/-sETONHncMk4/AAAAAAAAAAI/AAAAAAAAAAA/joBxW-hyTA4/s88-c-k-no/photo.jpg',addonString(152).encode('utf-8'),'1',"")
	'''שירים לילדים באנגלית 5 - צאוצאו'''
	addDir(addonString(57).encode('utf-8') + space + addonString(201).encode('utf-8') + space + "5" + space5 + addonString(50).encode('utf-8'),'UCBnZ16ahKA2DZ_T5W0FPUXg',9,'http://yt3.ggpht.com/-QHPC9emY_8c/AAAAAAAAAAI/AAAAAAAAAAA/03fPGkHcBbk/s88-c-k-no/photo.jpg',addonString(151).encode('utf-8'),'1',"")
	'''---------------------------'''
	
	'''סיפורים בעברית 1'''
	addDir(addonString(58).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "1",'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%a1%d7%99%d7%a4%d7%95%d7%a8%d7%99%d7%9d%20(5)&url=genre%3dkids%26genreId%3d7451',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300',addonString(198).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''סיפורים בעברית 2'''
	addDir(addonString(58).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "2",'PL74E72320D1F7932C',13,'http://www.tipa.co.il/images/contentImages/images/books/sipor.jpg',addonString(171).encode('utf-8'),'1',"")
	'''---------------------------'''
	
	'''שירים וסיפורים לילדים באנגלית 1 - אנגלית זה כיף'''
	addDir(addonString(41).encode('utf-8') + space + addonString(201).encode('utf-8') + space + "1" + space5 + addonString(61).encode('utf-8'),'UC43wDpoNIpAK2NYfMz1m0Ow',9,'http://yt3.ggpht.com/-vviGyJGiPjE/AAAAAAAAAAI/AAAAAAAAAAA/kfJgGMxLQTw/s88-c-k-no/photo.jpg',addonString(161).encode('utf-8'),'1',"")
	'''שירים וסיפורים לילדים באנגלית 2'''
	addDir(addonString(41).encode('utf-8') + space + addonString(201).encode('utf-8') + space + "2" + space5 + addonString(59).encode('utf-8'),'UC-qWJlvaPME3MWvrY-yjXeA',9,'http://yt3.ggpht.com/-Wk6NXGS1pAk/AAAAAAAAAAI/AAAAAAAAAAA/nBondFZLttw/s88-c-k-no/photo.jpg',addonString(159).encode('utf-8'),'1',"")
	'''---------------------------'''
	setsetting_custom1(addonID,'Current_View',50)
	
def CATEGORIES102(admin):
	'''הצגות לילדים 1'''
	addDir(addonString(42).encode('utf-8') + space + "1",'',10201,'http://www.ashops.co.il/Shops/shop_271/products/557/picture_317.jpg',addonString(110).encode('utf-8'),'1',"")
	
	'''הצגות לילדים 2'''
	addDir(addonString(42).encode('utf-8') + space + "2",'PL-_BcMXVkasoc7J02igHv1yGCaWPxK4NA',13,'http://upload.wikimedia.org/wikipedia/he/thumb/f/fc/%D7%A1%D7%A4%D7%A8_%D7%94%D7%92%27%D7%95%D7%A0%D7%92%D7%9C_%D7%9E%D7%97%D7%96%D7%9E%D7%A8.jpg/220px-%D7%A1%D7%A4%D7%A8_%D7%94%D7%92%27%D7%95%D7%A0%D7%92%D7%9C_%D7%9E%D7%97%D7%96%D7%9E%D7%A8.jpg',addonString(110).encode('utf-8'),'1',"")
	'''מיכל הקטנה'''
	addDir(addonString(42).encode('utf-8') + space + "3" + space5 + addonString(17).encode('utf-8'),'UCPCJS9igpTu7COLmoDeMKXQ',9,addonMediaPath + "37.jpg",addonString(117).encode('utf-8'),'1',"")
	'''סבא טוביה'''
	addDir(addonString(42).encode('utf-8') + space + "4" + space5 + addonString(19).encode('utf-8'),'plugin://plugin.video.youtube/channel/UCu4cSBULTvIKZ-tIqojGzxA/',8,'http://yt3.ggpht.com/--gG5kz68N_k/AAAAAAAAAAI/AAAAAAAAAAA/37Cr6jMJSCg/s88-c-k-no/photo.jpg',addonString(119).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''פסטיגל'''
	addDir(addonString(37).encode('utf-8') + space + "1",'UCKs_S8Uo5rLCNhlSanFpfFQ',9,'http://i.ytimg.com/i/Ks_S8Uo5rLCNhlSanFpfFQ/1.jpg?v=5410081a',addonString(137).encode('utf-8'),'1',"")
	'''פסטיגל 2'''
	addDir(addonString(37).encode('utf-8') + space + "2",'UCTxlaUXzxohVekL_Zym-hsw',9,addonMediaPath + "37.jpg",addonString(137).encode('utf-8'),'1',"")
	'''פסטיגל 3'''
	addDir(addonString(37).encode('utf-8') + space + "3",'UC8z6QWcSpDfeHY0sni4IDwA',9,'http://yt3.ggpht.com/-2Nux9ubjSCA/AAAAAAAAAAI/AAAAAAAAAAA/P8I968rchgE/s88-c-k-no/photo.jpg',addonString(137).encode('utf-8'),'1',"")
	'''---------------------------'''
	
	'''---------------------------'''
	setsetting_custom1(addonID,'Current_View',50)
	
def CATEGORIES104(admin):
	'''סדרות לילדים בעברית 1'''
	addDir(addonString(44).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "1",'UCl0jQT2Cj5brTRt5azL5E6g',9,'http://yt3.ggpht.com/-Sc-GjwGeiBs/AAAAAAAAAAI/AAAAAAAAAAA/DV9puDGf7nI/s88-c-k-no/photo.jpg',addonString(112).encode('utf-8'),'1',"")   
	'''סדרות לילדים בעברית 2'''
	addDir(addonString(44).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "2",'plugin://plugin.video.sdarot.tv/?mode=2&module=http%3a%2f%2fwww.sdarot.wf%2fseries%2fgenre%2f7%d7%90%d7%a0%d7%99%d7%9e%d7%a6%d7%99%d7%94&name=%d7%90%d7%a0%d7%99%d7%9e%d7%a6%d7%99%d7%94&url=all-heb&quot;',8,'http://www.hometheater.co.il/files/(40143)_icon.png',addonString(194).encode('utf-8'),'1',"58")   
	'''סדרות לילדים בעברית 3'''
	addDir(addonString(44).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "3",'UCDfoEu-jaKsjNL6Fl0h5PUQ',9,'http://yt3.ggpht.com/-sgYlsKP54oM/AAAAAAAAAAI/AAAAAAAAAAA/Ie9pRPV0QLo/s88-c-k-no/photo.jpg',addonString(114).encode('utf-8'),'1',"")   
	'''סדרות לילדים בעברית 4'''
	addDir(addonString(44).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "4",'UCnToIWbMbc9VehbtjTBBnRw',9,addonMediaPath + "95.png",addonString(195).encode('utf-8'),'1',"")	
	'''סדרות לילדים בעברית 5'''
	addDir(addonString(44).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "5",'plugin://plugin.video.hotVOD.video/?mode=5&name=%20HOT%20VOD%20YOUNG&url=http%3a%2f%2fhot.ynet.co.il%2fhome%2f0%2c7340%2cL-7449%2c00.html',8,'http://i28.tinypic.com/20o8lt.jpg',addonString(136).encode('utf-8'),'1',"")	
	'''---------------------------'''
	
	'''סדרות לילדים בעברית / אנגלית 1'''
	addDir(addonString(44).encode('utf-8') + space + addonString(200).encode('utf-8') + space4 + addonString(201).encode('utf-8') + space + "1",'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%a1%d7%93%d7%a8%d7%95%d7%aa%20(31)&url=genre%3dkids%26genreId%3d7447',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300',addonString(199).encode('utf-8'),'1',"")
	'''---------------------------'''
	
	'''סופר סטרייקה'''
	addDir(addonString(70).encode('utf-8'),'PLU6_PRY_7y1TQMr67fJ6WC2mzkqtVyU3B',13,'http://www.musicaneto.com/wp-content/uploads/2015/03/6246725.jpg',addonString(170).encode('utf-8'),'1',"")
	
	'''דורימון'''
	addDir(addonString(71).encode('utf-8'),'PL95CWWe9DuaJ6xtv1V8ZxDvoG_cB3z4bc',13,'http://www.animation-animagic.com/img/conteudo/2632008151425.jpg',addonString(171).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''הדרדסים'''
	addDir(addonString(74).encode('utf-8'),'PLo3vmw8N0knb9tZuIy7AR9fMPTUzr1oiI',13,'http://f.nanafiles.co.il/upload/Xternal/IsraBlog/73/34/75/753473/misc/23130510.jpg',addonString(174).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''ערוץ קופיקו'''
	addDir(addonString(34).encode('utf-8'),'UCCktKuBGZ1kHifzp9Mxu6Eg',9,'http://upload.wikimedia.org/wikipedia/he/f/fc/Kofiko.jpg',addonString(134).encode('utf-8'),'1',"")
	'''---------------------------'''
	
	'''ערוץ גאליס 1''' '''צריך לסנן להראות רק פרקים מלאים'''
	#if OFF_20 != "true": addDir(addonString(56).encode('utf-8') + space + "1",'UC1ZvZmYKkigob8Vg7MSgqjg',9,'http://yt3.ggpht.com/-2NPlgdL7mU8/AAAAAAAAAAI/AAAAAAAAAAA/ch9GzL2fOlM/s88-c-k-no/photo.jpg',addonString(156).encode('utf-8'),'1',"")
	
	#'''סדרות לילדים'''
	#seriestvheb1 = 'ערוצי סדרות א'
	#if OFF_17 != "true": addDir(addonString(44).encode('utf-8') + space + "10",seriestvheb1.decode('utf-8'),9,"https://yt3.ggpht.com/-hbyD79o9YWk/AAAAAAAAAAI/AAAAAAAAAAA/gOv2DB9cLC4/s100-c-k-no/photo.jpg",addonString(93).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''סדרות לילדים באנגלית 1'''
	addDir(addonString(44).encode('utf-8') + space + addonString(201).encode('utf-8') + space + "1",'plugin://plugin.video.supercartoons/?mode=400&page=1',8,'https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcQQoKkxPt4MxnzTqM-ChAH7My_OdIZQJ2U6CoXIeDzOkdMBaG8G',addonString(130).encode('utf-8'),'1',"58")
	'''---------------------------'''
	'''סדרות לילדים באנגלית 2'''
	addDir(addonString(44).encode('utf-8') + space + addonString(201).encode('utf-8') + space + "2",'https://dl.dropboxusercontent.com/s/cwcptnocx310g00/Merry_Melodies.plx',7,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSmzwydiY6V_l5sE_ed7Rf66G6B8Ug2p7ajn4uPAhH2NYpDVMNBUQ','','1',"")
	'''test'''
	#addDir("test",'http://www.navixtreme.com/wiilist/all.plx?page=4',7,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSmzwydiY6V_l5sE_ed7Rf66G6B8Ug2p7ajn4uPAhH2NYpDVMNBUQ','','1',"")
	'''הפנתר הורוד באנגלית 1'''
	addDir(addonString(13).encode('utf-8') + space + addonString(201).encode('utf-8') + space + "1",'PinkPanthersShow',9,'http://i.ytimg.com/i/1fIyfhQtm1fSljyKBf2uKA/1.jpg?v=5041a378',addonString(113).encode('utf-8'),'1',"")
	'''הפנתר הורוד באנגלית 2'''
	addDir(addonString(13).encode('utf-8') + space + addonString(201).encode('utf-8') + space + "2",'UCFeUyPY6W8qX8w2o6oSiRmw',9,'http://yt3.ggpht.com/-lwlGXn90heE/AAAAAAAAAAI/AAAAAAAAAAA/FmCv96eMMNE/s88-c-k-no/photo.jpg',addonString(113).encode('utf-8'),'1',"")
	'''---------------------------'''
	setsetting_custom1(addonID,'Current_View',50)
	
def CATEGORIES105(admin):
	'''------------------------------
	---checksites--------------------
	------------------------------'''
	'''plugin.video.seretil'''
	check_seretil_me = ""
	if systemplatformwindows: output = cmd('ping seretil.me -n 1',"Connected2")
	else: output = bash('ping -W 1 -w 1 -4 -q seretil.me',"Connected")
	if (not systemplatformwindows and ("1 packets received" in output or not "100% packet loss" in output)) or (systemplatformwindows and ("Received = 1" in output or not "100% loss" in output)): check_seretil_me = "true"
	'''---------------------------'''
	
	'''plugin.video.10qtv'''
	check_10q_tv = ""
	if systemplatformwindows: output = cmd('ping 10q.tv -n 1',"Connected2")
	else: output = bash('ping -W 1 -w 1 -4 -q 10q.tv',"Connected")
	if (not systemplatformwindows and ("1 packets received" in output or not "100% packet loss" in output)) or (systemplatformwindows and ("Received = 1" in output or not "100% loss" in output)): check_10q_tv = "true"
	'''---------------------------'''
	
	if General_TrustedOnly == "false": addDir('[COLOR=Red]' + addonString(11).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "2" + '[/COLOR]','plugin://plugin.video.seretil/?mode=211&name=%20%d7%90%d7%95%d7%a1%d7%a3%20%d7%a1%d7%a8%d7%98%d7%99%d7%9d%20%d7%9e%d7%93%d7%95%d7%91%d7%91%d7%99%d7%9d&url=http%3a%2f%2fseretil.me%2f%25D7%2590%25D7%2595%25D7%25A1%25D7%25A3-%25D7%25A1%25D7%25A8%25D7%2598%25D7%2599%25D7%259D-%25D7%259E%25D7%2593%25D7%2595%25D7%2591%25D7%2591%25D7%2599%25D7%259D%2f',8,'http://blog.tapuz.co.il/seretilNET/images/3745375_1.jpg',addonString(196).encode('utf-8'),'1',"58")
	if General_TrustedOnly == "false": addDir('[COLOR=Red]' + addonString(11).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "3" + '[/COLOR]','plugin://plugin.video.seretil/?mode=211&name=%d7%90%d7%95%d7%a1%d7%a3%20%d7%9e%d7%a1%d7%a4%d7%a8%202%20%d7%a1%d7%a8%d7%98%d7%99%d7%9d%20%d7%9e%d7%93%d7%95%d7%91%d7%91%d7%99%d7%9d&url=http%3a%2f%2fseretil.me%2f%25D7%2590%25D7%2595%25D7%25A1%25D7%25A3-%25D7%2592%25D7%2593%25D7%2595%25D7%259C-%25D7%25A9%25D7%259C-%25D7%25A1%25D7%25A8%25D7%2598%25D7%2599%25D7%259D-%25D7%259E%25D7%25A6%25D7%2595%25D7%2599%25D7%25A8%25D7%2599%25D7%259D%25D7%259E%25D7%2593%25D7%2595%25D7%2591%25D7%2591%25D7%2599%25D7%259D%2f',8,'http://blog.tapuz.co.il/seretilNET/images/3745375_1.jpg',addonString(196).encode('utf-8'),'1',"58")
	'''---------------------------'''
	'''סרטים מצוירים בעברית 1'''
	#if check_seretil_me == "true": addDir(addonString(11).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "1",'plugin://plugin.video.seretil/?mode=4&name=%d7%9e%d7%93%d7%95%d7%91%d7%91%d7%99%d7%9d%20%d7%a8%d7%90%d7%a9%d7%99&url=http%3a%2f%2fseretil.me%2fcategory%2f%25D7%25A1%25D7%25A8%25D7%2598%25D7%2599%25D7%259D-%25D7%259E%25D7%2593%25D7%2595%25D7%2591%25D7%2591%25D7%2599%25D7%259D%2fpage1%2f',8,'http://blog.tapuz.co.il/seretilNET/images/3745375_1.jpg',addonString(111).encode('utf-8'),'1',"58")
	'''סרטים מצוירים בעברית / באנגלית 1'''
	addDir(addonString(11).encode('utf-8') + space + addonString(200).encode('utf-8') + space4 + addonString(201).encode('utf-8') + space + "1",'plugin://plugin.video.gozlan.me/?mode=1&name=%d7%a1%d7%a8%d7%98%d7%99%20%d7%90%d7%a0%d7%99%d7%9e%d7%a6%d7%99%d7%94&url=http%3a%2f%2fanonymouse.org%2fcgi-bin%2fanon-www.cgi%2fhttp%3a%2f%2fgozlan.co%2f%2fsearch.html%3fg%3d%25D7%2590%25D7%25A0%25D7%2599%25D7%259E%25D7%25A6%25D7%2599%25D7%2594',8,'http://ftp.acc.umu.se/mirror/addons.superrepo.org/v5/addons/plugin.video.gozlan.me/icon.png',addonString(110).encode('utf-8'),'1',"58")
	'''סרטים מצוירים בעברית / באנגלית 2'''
	addDir(addonString(11).encode('utf-8') + space + addonString(200).encode('utf-8') + space4 + addonString(201).encode('utf-8') + space + "2",'plugin://plugin.video.gozlan.me/?mode=1&name=%d7%a1%d7%a8%d7%98%d7%99%20%d7%9e%d7%a9%d7%a4%d7%97%d7%94&url=http%3a%2f%2fanonymouse.org%2fcgi-bin%2fanon-www.cgi%2fhttp%3a%2f%2fgozlan.co%2f%2fsearch.html%3fg%3d%25D7%259E%25D7%25A9%25D7%25A4%25D7%2597%25D7%2594',8,'http://ftp.acc.umu.se/mirror/addons.superrepo.org/v5/addons/plugin.video.gozlan.me/icon.png',addonString(110).encode('utf-8'),'1',"58")
	'''סרטים מצוירים בעברית / באנגלית 3'''
	#if check_seretil_me == "true": addDir(addonString(11).encode('utf-8') + space + addonString(200).encode('utf-8') + space4 + addonString(201).encode('utf-8') + space + "3",'plugin://plugin.video.seretil/?mode=4&name=%d7%90%d7%a0%d7%99%d7%9e%d7%a6%d7%99%d7%94%20-%d7%9c%d7%90%20%d7%94%d7%9b%d7%9c%20%d7%9e%d7%93%d7%95%d7%91%d7%91&url=http%3a%2f%2fseretil.me%2fcategory%2f%25D7%2590%25D7%25A0%25D7%2599%25D7%259E%25D7%25A6%25D7%2599%25D7%2594%2fpage1%2f',8,'http://blog.tapuz.co.il/seretilNET/images/3745375_1.jpg',addonString(110).encode('utf-8'),'1',"58")
	'''סרטים מצוירים בעברית / באנגלית 1'''
	addDir(addonString(11).encode('utf-8') + space + addonString(200).encode('utf-8') + space4 + addonString(201).encode('utf-8') + space + "4",'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%a1%d7%a8%d7%98%d7%99%d7%9d%20(37)&url=genre%3dkids%26genreId%3d7449',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300',addonString(189).encode('utf-8'),'1',"")
	'''סרטים מצוירים בעברית / באנגלית 2'''
	addDir(addonString(11).encode('utf-8') + space + addonString(200).encode('utf-8') + space4 + addonString(201).encode('utf-8') + space + "5",'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%9e%d7%a9%d7%a4%d7%97%d7%94%20%d7%95%d7%99%d7%9c%d7%93%d7%99%d7%9d%20(42)&url=genre%3dmovies%26genreId%3d6261',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300',addonString(110).encode('utf-8'),'1',"")
	'''---------------------------'''
	
	'''סרטים מצוירים בעברית / באנגלית 6'''
	if check_10q_tv: addDir(addonString(11).encode('utf-8') + space + addonString(200).encode('utf-8') + space4 + addonString(201).encode('utf-8') + space + "6",'plugin://plugin.video.10qtv/?mode=6&name=אנימציה&url=http://www.10q.tv/board/filmy/animciha/5',8,'http://mirror.cinosure.com/superrepo/v5/addons/plugin.video.10qtv/icon.png',addonString(110).encode('utf-8'),'1',"")
	'''סרטים מצוירים בעברית / באנגלית 7'''
	if check_10q_tv: addDir(addonString(11).encode('utf-8') + space + addonString(200).encode('utf-8') + space4 + addonString(201).encode('utf-8') + space + "7",'plugin://plugin.video.10qtv/?mode=6&name=%d7%9e%d7%a9%d7%a4%d7%97%d7%94&url=http%3a%2f%2fwww.10q.tv%2fboard%2ffilmy%2fmshfhha%2f17',8,'http://mirror.cinosure.com/superrepo/v5/addons/plugin.video.10qtv/icon.png',addonString(110).encode('utf-8'),'1',"")
	'''---------------------------'''

	setsetting_custom1(addonID,'Current_View',50)
	
def CATEGORIES106(admin):
	'''ערוץ לולי'''
	addDir(addonString(33).encode('utf-8'),'UCcYc90JDakyeXGeZgPL1ejA',9,'http://yt3.ggpht.com/-n8_yk3MKYEk/AAAAAAAAAAI/AAAAAAAAAAA/0lOK__EwCtg/s88-c-k-no/photo.jpg',addonString(133).encode('utf-8'),'1',"")
	'''תכנים לפעוטות בעברית 1'''
	addDir(addonString(46).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "1",'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%a4%d7%a2%d7%95%d7%98%d7%95%d7%aa%20(46)&url=genre%3dkids%26genreId%3d7448',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300',addonString(110).encode('utf-8'),'1',"")
	'''בייבי אוריינטל'''
	addDir(addonString(28).encode('utf-8'),'PLpnRNlRK18UaUnOabh_ZysDsOY3QLvjkd',13,addonMediaPath + "19.jpg",addonString(110).encode('utf-8'),'1',"")
	'''בייבי איינשטיין'''
	addDir(addonString(20).encode('utf-8'),'PLlBpB13l5PDCndYQPS4PHw5ElfKZMhgCE',13,'http://d202m5krfqbpi5.cloudfront.net/books/1170326163l/46377.jpg',addonString(120).encode('utf-8'),'1',"") #TerrapinStation5
	'''ערוץ בייבי'''
	addDir(addonString(31).encode('utf-8'),'UCj10fKNd5h64J_M9YIQu0Zw',9,'http://yt3.ggpht.com/-RYFi0L82fh4/AAAAAAAAAAI/AAAAAAAAAAA/1hhzmsuRybc/s88-c-k-no/photo.jpg',addonString(131).encode('utf-8'),'1',"")
	'''אוצר מילים עם נוני'''
	addDir(addonString(73).encode('utf-8'),'PLErYJg2XgxyXmgk6cyROtlJh2g-Fk_T6n',13,'http://i.ytimg.com/vi/m67adbe1SOg/0.jpg',addonString(173).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''לולה בייבי'''
	addDir(addonString(54).encode('utf-8'),'UCOYUFFxT50nvDaRj5Mn5XNg',9,'http://yt3.ggpht.com/-C9HFu_35bmk/AAAAAAAAAAI/AAAAAAAAAAA/O5-pgwvceRI/s88-c-k-no/photo.jpg',addonString(154).encode('utf-8'),'1',"")
	'''---------------------------'''
	setsetting_custom1(addonID,'Current_View',50)
	
def CATEGORIES107(admin):
	'''יובל המבולבל'''
	addDir(addonString(29).encode('utf-8'),'UC0r3m54hCOvyG47jzz08X2Q',9,'http://yt3.ggpht.com/-FHcf2Rxu08A/AAAAAAAAAAI/AAAAAAAAAAA/dxzE2ng3uXI/s88-c-k-no/photo.jpg',addonString(129).encode('utf-8'),'1',"")
	'''ערוץ הופ!'''
	addDir(addonString(32).encode('utf-8'),'UClZXqxeY540_Epab3WDHFGw',9,'http://yt3.ggpht.com/-A6Z6Bj0Y5os/AAAAAAAAAAI/AAAAAAAAAAA/k-1dO4Dm0m8/s88-c-k-no/photo.jpg',addonString(132).encode('utf-8'),'1',"")
	'''הופ ילדות ישראלית'''
	addDir(addonString(35).encode('utf-8'),'UCfNjGgy-3XfTzgWoGMt_QOw',9,'http://yt3.ggpht.com/-9bhXN_82zr8/AAAAAAAAAAI/AAAAAAAAAAA/AkRUBufsblk/s88-c-k-no/photo.jpg',addonString(135).encode('utf-8'),'1',"")
	'''ניק ג'וניור ישראל'''
	addDir(addonString(64).encode('utf-8'),'UCQWDQwBdFVOPjvBy6mgqUQQ',9,'http://yt3.ggpht.com/-jsb5s9cfdsk/AAAAAAAAAAI/AAAAAAAAAAA/pgREig-fcTE/s88-c-k-no/photo.jpg',addonString(164).encode('utf-8'),'1',"")
	'''---------------------------'''
	
	'''קטנטנים בעברית 1'''
	addDir(addonString(47).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "1",'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%97%d7%93%d7%a9%d7%99%d7%9d%20(20)&url=genre%3dkids%26genreId%3d7623',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300',addonString(110).encode('utf-8'),'1',"")
	'''קטנטנים בעברית 2'''
	#addDir(addonString(47).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "2",'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%97%d7%99%d7%a0%d7%95%d7%9b%d7%99%20(34)&url=genre%3dkids%26genreId%3d7452',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300',addonString(110).encode('utf-8'),'1',"")
	'''קטנטנים בעברית 3'''
	#addDir(addonString(47).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "3",'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%94%d7%a4%d7%a2%d7%9c%d7%94%20(4)&url=genre%3dkids%26genreId%3d7453',8,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300',addonString(110).encode('utf-8'),'1',"")
	'''קטנטנים בעברית 4'''
	addDir(addonString(47).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "4",'UC0GgioZ1XWa9xNJJH66h7rg',9,'http://yt3.ggpht.com/-2NPlgdL7mU8/AAAAAAAAAAI/AAAAAAAAAAA/ch9GzL2fOlM/s88-c-k-no/photo.jpg',addonString(136).encode('utf-8'),'1',"")
	'''קטנטנים בעברית 5'''
	addDir(addonString(47).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "5",'plugin://plugin.video.wallaNew.video/?mode=1&module=nickjr&name=ניקלאודיון גוניור&url=http://nickjr.walla.co.il/',8,'http://www.imanoga.co.il/wp-content/uploads/2012/06/646457567.jpg',addonString(110).encode('utf-8'),'1',"50")
	'''---------------------------'''
	'''הנסיכה סופייה'''
	#addDir(addonString(46).encode('utf-8'),'',46,addonMediaPath + "46.png",addonString(146).encode('utf-8'),'1',"")
	addDir(addonString(67).encode('utf-8') + space + addonString(200).encode('utf-8'),'disneyjuniorisrael',9,'http://upload.wikimedia.org/wikipedia/he/a/a4/%D7%94%D7%A0%D7%A1%D7%99%D7%9B%D7%94_%D7%A1%D7%95%D7%A4%D7%99%D7%94.png',addonString(167).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''הלו קיטי'''
	addDir(addonString(72).encode('utf-8'),'PL-_BcMXVkaspyjwz7S5Hs_Rgih0F1d8_d',13,'http://www.ligdol.co.il/Upload/hello%20kitty285.jpg',addonString(172).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''סמי הכבאי'''
	addDir(addonString(75).encode('utf-8'),'PL-PL_TbWUH2U7KmZtYRZlJtxzmYFP_m81vSk',13,'http://www.ligdol.co.il/Upload/hello%20kitty285.jpg',addonString(175).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''מיקי כוכבת הילדים'''
	addDir(addonString(68).encode('utf-8') + space + addonString(200).encode('utf-8'),'UCYyLC-CDRRbbwRmw7vOw_BQ',9,'http://yt3.ggpht.com/-LQQaGMJh2g0/AAAAAAAAAAI/AAAAAAAAAAA/KebzcCn-y_Y/s88-c-k-no/photo.jpg',addonString(168).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''מיכל כלפון-צמח'''
	addDir(addonString(69).encode('utf-8') + space + addonString(200).encode('utf-8'),'UC64wDQFgTq9RpI1P8_p-SxA',9,'http://yt3.ggpht.com/-4Rd1GQEZnaM/AAAAAAAAAAI/AAAAAAAAAAA/pfQtiUaNjng/s88-c-k-no/photo.jpg',addonString(169).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''ערוץ החיות באנגלית'''
	addDir(addonString(65).encode('utf-8') + space + addonString(201).encode('utf-8'),'UCS6hLNMMXi77SajUIvKGx5g',9,'http://yt3.ggpht.com/-9wTC-JCukjc/AAAAAAAAAAI/AAAAAAAAAAA/EqtzN1DW6HA/s88-c-k-no/photo.jpg',addonString(165).encode('utf-8'),'1',"")
	'''סי בייביס באנגלית'''
	addDir(addonString(63).encode('utf-8') + space + addonString(201).encode('utf-8'),'UC0fXNmjDoC7ckPyT6qM8Urw',9,'http://yt3.ggpht.com/-lrofuJsz1c8/AAAAAAAAAAI/AAAAAAAAAAA/8YJ0rAktf_o/s88-c-k-no/photo.jpg',addonString(163).encode('utf-8'),'1',"")
	'''רחוב סומסום באנגלית'''
	addDir(addonString(62).encode('utf-8') + space + addonString(201).encode('utf-8'),'UCoookXUzPciGrEZEXmh4Jjg',9,'http://yt3.ggpht.com/-Udx0C3ZTHUg/AAAAAAAAAAI/AAAAAAAAAAA/3BE1yYHQccs/s88-c-k-no/photo.jpg',addonString(162).encode('utf-8'),'1',"")
	'''יו-גאבה-גאבה באנגלית'''
	addDir(addonString(60).encode('utf-8') + space + addonString(201).encode('utf-8'),'UCxezak0GpjlCenFGbJ2mpog',9,'http://yt3.ggpht.com/-DCqlRFygCMs/AAAAAAAAAAI/AAAAAAAAAAA/OmWJ9YLZviE/s88-c-k-no/photo.jpg',addonString(160).encode('utf-8'),'1',"")
	'''---------------------------'''
	setsetting_custom1(addonID,'Current_View',50)
	
def CATEGORIES108(admin):
	'''ערוץ הילדים'''
	addDir(addonString(15).encode('utf-8') + space + "1",'UCOFp2_GttW3ljCuOc7r4l7g',9,'http://yt3.ggpht.com/-87JARv-G_rg/AAAAAAAAAAI/AAAAAAAAAAA/X9aVp9A1UiQ/s88-c-k-no/photo.jpg',addonString(150).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''חינוכית 1'''
	addDir(addonString(39).encode('utf-8') + space + "1",'23tv',9,addonMediaPath + "39.png",addonString(139).encode('utf-8'),'1',"")
	'''חינוכית 2'''
	addDir(addonString(39).encode('utf-8') + space + "2",'UCYFLZdLRZGnmKQBH6RB8IjA',9,addonMediaPath + "39.png",addonString(139).encode('utf-8'),'1',"")
	'''חינוכית 3'''
	addDir(addonString(39).encode('utf-8') + space + "3",'UC_fUfLFo31WTFZPxgr1EcLA',9,addonMediaPath + "39.png",addonString(139).encode('utf-8'),'1',"")
	'''---------------------------'''
	
	setsetting_custom1(addonID,'Current_View',50)
	
def CATEGORIES109(admin):
	'''קטנטנים בהולנדית 1'''
	addDir(addonString(47).encode('utf-8') + space + addonString(202).encode('utf-8') + space + "1",'UCMf-gZNpJSPq80r9e22wl9A',9,'http://yt3.ggpht.com/-BXNeRxPOFpU/AAAAAAAAAAI/AAAAAAAAAAA/3DZSjgkhfJM/s88-c-k-no/photo.jpg',addonString(110).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''קטנטנים באוקראינית 1'''
	addDir(addonString(47).encode('utf-8') + space + addonString(203).encode('utf-8') + space + "1",'UCZAL3xoDj13SeJGTFhq00Tw',9,'http://yt3.ggpht.com/-TrrOJ-NiNys/AAAAAAAAAAI/AAAAAAAAAAA/lhx315yY5gs/s88-c-k-no/photo.jpg',addonString(110).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''שירים בצרפתית 1'''
	addDir(addonString(57).encode('utf-8') + space + addonString(204).encode('utf-8') + space + "1",'comptines',9,'https://yt3.ggpht.com/-MT6ThcO_qNI/AAAAAAAAAAI/AAAAAAAAAAA/GDibk7v0-FA/s100-c-k-no/photo.jpg',addonString(110).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''קטנטנים בצרפתית 1'''
	addDir(addonString(47).encode('utf-8') + space + addonString(204).encode('utf-8') + space + "1",'ssebastienn',9,'https://yt3.ggpht.com/-dhcbXAt2vto/AAAAAAAAAAI/AAAAAAAAAAA/hCIp6-YvL6w/s100-c-k-no/photo.jpg',addonString(188).encode('utf-8'),'1',"")
	'''---------------------------'''
	'''שירים ברוסית 1'''
	addDir(addonString(57).encode('utf-8') + space + addonString(205).encode('utf-8') + space + "1",'PLJgmMSdWwadtTK4JzHhl5N5YR49ZVcGTK',13,'http://www.mapsofworld.com/images/world-countries-flags/russian-federation-flag.gif',addonString(110).encode('utf-8'),'1',"")
	'''---------------------------'''
	
	setsetting_custom1(addonID,'Current_View',50)
	
def CATEGORIES103(admin):
	setsetting_custom1(addonID,'Current_View',50)

def CATEGORIES10201(name, iconimage, desc):
	'''הופעות חיות'''
	YOULink('גיגיגיגונת קלטת ילדים', 'tKDm79jqRcI', 'http://erezdvd.co.il/sites/default/files/imagecache/product_full/products/369504.jpg','')
	YOULink('לירן הקוסם מהאגדות', 'kNS4xMdPIos', 'http://i.ytimg.com/vi/5gN4SMO8EfE/maxresdefault.jpg',addonString(110).encode('utf-8'))
	YOULink('גינת השטוזים', 'o20-0VygrsE','http://www.avivim-hafazot.co.il/uploadimages/188382.jpg',addonString(110).encode('utf-8'))
	#YOULink('מיקי ופונץ', '9rGV96uhqPw',addonString(110).encode('utf-8'))
	YOULink('יניב המגניב', 'f9s_aunAElY', 'http://img.mako.co.il/2013/07/22/kids_yaniv_hamagniv_.jpg',addonString(110).encode('utf-8'))
	YOULink('בילבי', 'sHMEnVpDJR8', 'http://i.ytimg.com/vi/2mxOiPccxOs/maxresdefault.jpg',addonString(110).encode('utf-8'))
	YOULink('עליבאבא וארבעים השודדים', 'gxgvTe3kPGY', 'http://i.ytimg.com/vi/EMtHOrNBXKU/hqdefault.jpg',addonString(110).encode('utf-8'))
	YOULink('שורום זורום', '9rGV96uhqPw', 'http://www.tipa.co.il/images/contentImages/images/dvd/shorom.jpg',addonString(110).encode('utf-8'))
	YOULink('אי המטמון', 'Cmd0VxJmmBA', 'http://images.mouse.co.il/storage/0/e/ggg--Matmon.jpg',addonString(110).encode('utf-8'))
	YOULink('שלגיה והצייד', '0rPEJ-kD1dc', 'http://www.dossinet.me/coverage_pics/1b5d66af0d230ff716d50f07fd6defc0.jpg',addonString(110).encode('utf-8'))
	YOULink('עליסה בארץ הפלאות', 'Cmd0VxJmmBA', 'http://images.mouse.co.il/storage/3/0/b--alice.jpg',addonString(110).encode('utf-8'))	
	YOULink('גינת הפלאים של רינת', 'PUL2C9mEAKQ', 'http://www.booknet.co.il/imgs/site/prod/7290013274434b.jpg',addonString(110).encode('utf-8'))
	#YOULink('משחקי הפסטיגל 2015', 'd2953353ab9e8', 'http://www.ligdol.co.il/Upload/pestigal2014_poster.jpg',addonString(110).encode('utf-8'))
	#YOULink('גאליס המופע', 'a6f7eacf00f28', 'http://up389.siz.co.il/up1/znmi3xqzndjg.jpg',addonString(110).encode('utf-8'))
	#YOULink('דוד חיים', 'a5c04e985cccb', 'http://www.myfirsthomepage.co.il/mfhp/tv/image/haim1.jpg',addonString(110).encode('utf-8')) #NOT WORKING!
	YOULink('2 דוד חיים', 'X3j6mQ9VgLI', 'http://www.nmcunited.co.il/Images/dynamic/movies/Dod-Haim2.jpg',addonString(110).encode('utf-8'))
	YOULink('ילד פלא', 'e5c134277697c', 'http://tzavta.co.il/images/siteCont/Content_233.2463.jpg',addonString(110).encode('utf-8'))
	YOULink('הפיגמות - המחזמר', 'YOs5zhvXUf8', 'http://img.tapuz.co.il/forums/22604478.jpg',addonString(110).encode('utf-8'))
	YOULink('האסופית', 'i5yQxLraENk', 'http://static.flatplanet.tv/movies/112055.jpg',addonString(110).encode('utf-8'))
	YOULink('מרקו', 'XgnCNCt71d8', 'http://www.ykp.co.il/cd_halev.jpg',addonString(110).encode('utf-8'))
	YOULink('רובין הוד', '6nZk0H89jDQ', 'http://erezdvd.co.il/sites/default/files/imagecache/product_full/products/14810.jpg',addonString(110).encode('utf-8'))
	YOULink('ספר הגונגל', 'TlWVoNz_B3o', 'http://images.mouse.co.il/storage/3/7/ggg--book20090908_2343750_0..jpg',addonString(110).encode('utf-8'))
	YOULink('פיטר פן - הראל סקעת', 'gTuMB5sz8pY', 'http://i48.tinypic.com/f5ceuq.jpg',addonString(110).encode('utf-8'))
	YOULink('אלאדין ויסמין', 'sVCYRfk3Wcc', 'http://www.tipa.co.il/images/contentImages/images/TV/al.jpg',addonString(110).encode('utf-8'))
	YOULink('סינדרלה - בר רפאלי', 'snr9wxyEzpA', 'http://afisha.israelinfo.ru/pictures/19949.jpg',addonString(110).encode('utf-8'))
	YOULink('תום סוייר והקלברי פין', 'kbzPyZV3cck', 'https://i.ytimg.com/vi/7w75Dc0ofT0/hqdefault.jpg',addonString(110).encode('utf-8'))
	YOULink('לא יאומן כי יסופר', '-ihwgBW3sVs', 'http://simania.co.il/bookimages/covers90/906630.jpg',addonString(110).encode('utf-8'))
	YOULink('עמי ותמי', '8d6a2e7a3cd54', 'http://www.tivon.co.il/vault/Zoar/amitami-B.jpg',addonString(110).encode('utf-8'))
	#YOULink('גיבורי האור 2', 'http://shorte.st/strackable/b4e6b9af7b276c4c1d8fa25950f5ef81/vod.k11.co.il/1/1/http://www.novamov.com/video/8d6a2e7a3cd54',addonString(110).encode('utf-8'))
	YOULink('גיבורי האור', 'nwlo00FHCRc', 'http://www.booknet.co.il/imgs/site/prod/7294276219850b.jpg',addonString(110).encode('utf-8'))
	YOULink('גיבורי האור - הדור הבא', '8422a40355d7c', 'http://4.bp.blogspot.com/-RmcNjqbNlAM/U99_hg0AyrI/AAAAAAAAD9Q/HJWmitLdwWw/s1600/%D7%92%D7%99%D7%91%D7%95%D7%A8%D7%99+%D7%94%D7%90%D7%95%D7%A8+%D7%97%D7%A0%D7%95%D7%9B%D7%94+2014+%D7%9B%D7%A8%D7%98%D7%99%D7%A1%D7%99%D7%9D.jpg',addonString(110).encode('utf-8'))
	YOULink('101 כלבים דלמטים', '020c8c5ebfe70', 'http://www.pashbar.co.il/pictures/show_big_0712083001297352431.jpg',addonString(110).encode('utf-8'))
	YOULink('יובל המבולבל - המסע אל הכוכב', '6UrdISJBBC4', 'http://www.avivim-hafazot.co.il/uploadimages/642148.jpg',addonString(110).encode('utf-8'))
	YOULink('יובל המבולבל - מסביב לזמן', '920d18542f05a', 'http://i.ytimg.com/vi/1Gsa64WsXmA/maxresdefault.jpg',addonString(110).encode('utf-8'))
	YOULink('יובל המבולבל - כוכב המשאלות', 'C2Rm4IuVWNQ', 'http://www.ashops.co.il/Shops/shop_271/products/557/picture_317.jpg',addonString(110).encode('utf-8'))
	YOULink('יובל המבולבל - נווה עצלנות', '99c23afc06d1a', 'http://3.bp.blogspot.com/-E10YgfqBuBc/VHMtJRkqz3I/AAAAAAAAZAI/3tjwSCO3MQo/s1600/3432d1bb8951834d8c2c74446f069d4b.jpg',addonString(110).encode('utf-8'))
	YOULink('הדרקון המתוק שלי', 'd6b387a31efcf', 'http://www.heichalpt.co.il/wp-content/uploads/2014/10/%D7%94%D7%93%D7%A8%D7%A7%D7%95%D7%9F-%D7%94%D7%9E%D7%AA%D7%95%D7%A7-%D7%A9%D7%9C%D7%99.jpg',addonString(110).encode('utf-8'))
	
	setsetting_custom1(addonID,'Current_View',58)