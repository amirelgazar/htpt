#!/bin/bash
SETTINGS=$HOME/.xbmc/userdata/addon_data/plugin.video.genesis/settings.xml

###VAR SWITCHABLE###
AUTOPLAY='"autoplay" value='
AUTOPLAYLIBRARY='"autoplay_library" value='
PLAYBACKINFO='"playback_info" value='

###VAR GENERAL###
T='"true"'
F='"false"'
ALL='"[^ ]*"'
NUM1='"1"'
NUM0='"0"'

sed -i "s/$AUTOPLAY$F/$AUTOPLAY$T/g" $SETTINGS ###AUTOPLAY ADDON ON###
sed -i "s/$AUTOPLAYLIBRARY$F/$AUTOPLAYLIBRARY$T/g" $SETTINGS ###AUTOPLAY LIBRARY ON###
sed -i "s/$PLAYBACKINFO$F/$PLAYBACKINFO$T/g" $SETTINGS ###DETAILS ON###