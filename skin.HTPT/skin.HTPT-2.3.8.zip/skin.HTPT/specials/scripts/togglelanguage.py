import xbmc, xbmcgui
import json
#import simplejson as json

admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
togglelanguage = xbmc.getInfoLabel('Skin.HasSetting(ToggleLanguage)')
#smartsearch = xbmc.getCondVisibility('Container(250).HasFocus(161)')
smartsearch = xbmc.getCondVisibility('Control.HasFocus(161)')
custom1125 = xbmc.getCondVisibility('Window.IsVisible(Custom1125.xml)')
dialogsubtitles = xbmc.getCondVisibility('Window.IsVisible(DialogSubtitles.xml)')
dialogkeyboard = xbmc.getCondVisibility('Window.IsVisible(DialogKeyboard.xml)')
class hebrewkeyboard:
	if dialogkeyboard and togglelanguage:
		input = xbmc.getInfoLabel('Control.GetLabel(310)')
		togglelanguage = xbmc.getInfoLabel('Skin.HasSetting(ToggleLanguage)')
		togglelanguageinput = xbmc.getInfoLabel('Skin.String(ToggleLanguageInput)')
		new = ""
		if xbmc.getCondVisibility('Control.HasFocus(650)'): new = xbmc.getInfoLabel('Control.GetLabel(650)')
		if xbmc.getCondVisibility('Control.HasFocus(660)'): new = xbmc.getInfoLabel('Control.GetLabel(660)')
		if xbmc.getCondVisibility('Control.HasFocus(670)'): new = xbmc.getInfoLabel('Control.GetLabel(670)')
		if xbmc.getCondVisibility('Control.HasFocus(680)'): new = xbmc.getInfoLabel('Control.GetLabel(680)')
		if xbmc.getCondVisibility('Control.HasFocus(690)'): new = xbmc.getInfoLabel('Control.GetLabel(690)')
		if xbmc.getCondVisibility('Control.HasFocus(702)'): new = xbmc.getInfoLabel('Control.GetLabel(702)')
		if xbmc.getCondVisibility('Control.HasFocus(710)'): new = xbmc.getInfoLabel('Control.GetLabel(710)')
		if xbmc.getCondVisibility('Control.HasFocus(720)'): new = xbmc.getInfoLabel('Control.GetLabel(720)')
		if xbmc.getCondVisibility('Control.HasFocus(730)'): new = xbmc.getInfoLabel('Control.GetLabel(730)')
		if xbmc.getCondVisibility('Control.HasFocus(740)'): new = xbmc.getInfoLabel('Control.GetLabel(740)')
		if xbmc.getCondVisibility('Control.HasFocus(750)'): new = xbmc.getInfoLabel('Control.GetLabel(750)')
		if xbmc.getCondVisibility('Control.HasFocus(760)'): new = xbmc.getInfoLabel('Control.GetLabel(760)')
		if xbmc.getCondVisibility('Control.HasFocus(770)'): new = xbmc.getInfoLabel('Control.GetLabel(770)')
		if xbmc.getCondVisibility('Control.HasFocus(780)'): new = xbmc.getInfoLabel('Control.GetLabel(780)')
		if xbmc.getCondVisibility('Control.HasFocus(790)'): new = xbmc.getInfoLabel('Control.GetLabel(790)')
		if xbmc.getCondVisibility('Control.HasFocus(800)'): new = xbmc.getInfoLabel('Control.GetLabel(800)')
		if xbmc.getCondVisibility('Control.HasFocus(810)'): new = xbmc.getInfoLabel('Control.GetLabel(810)')
		if xbmc.getCondVisibility('Control.HasFocus(820)'): new = xbmc.getInfoLabel('Control.GetLabel(820)')
		if xbmc.getCondVisibility('Control.HasFocus(830)'): new = xbmc.getInfoLabel('Control.GetLabel(830)')
		if xbmc.getCondVisibility('Control.HasFocus(840)'): new = xbmc.getInfoLabel('Control.GetLabel(840)')
		if xbmc.getCondVisibility('Control.HasFocus(850)'): new = xbmc.getInfoLabel('Control.GetLabel(850)')
		if xbmc.getCondVisibility('Control.HasFocus(860)'): new = xbmc.getInfoLabel('Control.GetLabel(860)')
		if xbmc.getCondVisibility('Control.HasFocus(870)'): new = xbmc.getInfoLabel('Control.GetLabel(870)')
		if xbmc.getCondVisibility('Control.HasFocus(880)'): new = xbmc.getInfoLabel('Control.GetLabel(880)')
		if xbmc.getCondVisibility('Control.HasFocus(890)'): new = xbmc.getInfoLabel('Control.GetLabel(890)')
		if xbmc.getCondVisibility('Control.HasFocus(900)'): new = xbmc.getInfoLabel('Control.GetLabel(900)')
		if xbmc.getCondVisibility('Control.HasFocus(901)'): new = xbmc.getInfoLabel('Control.GetLabel(901)')
		if xbmc.getCondVisibility('Control.HasFocus(32)'): new = (' ')
		if xbmc.getCondVisibility('Control.HasFocus(312)'):
			xbmc.executebuiltin('Skin.SetString(ToggleLanguageInput,)')
			xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"","done":false}}')
			new = xbmc.getInfoLabel('Control.GetLabel(310)')
			if admin: xbmc.executebuiltin('Notification(Admin (312),'+ togglelanguageinput +' -> '+ new +',3000)')
		
		else:
			# tip from http://stackoverflow.com/questions/1038824
			def strip_right(text, suffix):
				if not text.endswith(suffix):
					return text
				# else
				return text[:len(text)-len(suffix)]
			end = input + new
			end2 = str(end)
			#end2 = end
			def rreplace(s, old, new):
				try:
					place = s.rindex(old)
					return ''.join((s[:place],new,s[place+len(old):]))
				except ValueError:
					return s
			stripr = strip_right(end, new)
			if admin: xbmc.executebuiltin('Notification(Admin (s2), '+ stripr +',2000)')
			#end2 = input[::-1].replace(input[::-1],new[::-1],1)[::-1]
			#end = new + input #togglelanguageinput
			#text = end
			#xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ togglelanguageinput +''+ new +'","done":false}}')
			#xbmc.executebuiltin('Skin.SetString(ToggleLanguageInput, '+ input +''+ new +')')
			xbmc.executebuiltin('Skin.SetString(ToggleLanguageInput, '+ end +')')
			xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ end2 +'","done":false}}')
			if admin: xbmc.executebuiltin('Notification(Admin (End),'+ input +' -> '+ new +',5000)')
			#if xbmc.getCondVisibility('Control.HasFocus(300)'):
				#input = 		
class smartsubsearch:
	if dialogsubtitles:
		if admin: xbmc.executebuiltin('Notification(Admin,smartsubsearch,1000)')
		isTV = 'false'
		isMovie = 'false'
		input = 'N/A'
		tvshowtitle = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
		season = xbmc.getInfoLabel('VideoPlayer.Season')
		episode = xbmc.getInfoLabel('VideoPlayer.Episode')
		title = xbmc.getInfoLabel('VideoPlayer.Title')
		year = xbmc.getInfoLabel('VideoPlayer.Year')
		country = xbmc.getInfoLabel('VideoPlayer.Country')
		tagline = xbmc.getInfoLabel('VideoPlayer.Tagline')
		if tvshowtitle != "" and season != "" and episode != "": isTV = 'true'
		elif title != "" and (year != "" or country != "" or tagline != ""): isMovie = 'true'
		xbmc.sleep(40)
		'''tvshow is playing'''
		if isTV == 'true':
			seasonN = int(season)
			episodeN = int(episode)
			if seasonN < 10 and episodeN < 10: input = tvshowtitle + " " + 'S0' + season + 'E0' + episode
			if seasonN > 10 and episodeN > 10: input = tvshowtitle + " " + 'S' + season + 'E' + episode
			if seasonN > 10 and episodeN < 10: input = tvshowtitle + " " + 'S' + season + 'E0' + episode
			if seasonN < 10 and episodeN > 10: input = tvshowtitle + " " + 'S0' + season + 'E' + episode
		'''movie is playing'''
		if not isTV == 'true' and isMovie == 'true': input = title + " " + year
		xbmc.sleep(1000)
		xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ input +'","done":false}}')
	#else:
		#if admin: xbmc.executebuiltin('Notification(Admin,NO smartsubsearch,1000)')
	
class smartkeyboard:
	if custom1125:
		#if admin: xbmc.executebuiltin('Notification(Admin,custom1125,1000)')
		input = xbmc.getInfoLabel('Control.GetLabel(310)')
		smartkeyboardhistory = xbmc.getCondVisibility('Control.HasFocus(201)')
		smartkeyboardpaste = xbmc.getCondVisibility('Control.HasFocus(204)')
		'''history button'''
		if smartkeyboardhistory:
			'''variable'''
			smartkeyboardHN = xbmc.getInfoLabel('Skin.String(smartkeyboardHN)')
			smartkeyboardH1 = xbmc.getInfoLabel('Skin.String(smartkeyboardH1)')
			smartkeyboardH2 = xbmc.getInfoLabel('Skin.String(smartkeyboardH2)')
			smartkeyboardH3 = xbmc.getInfoLabel('Skin.String(smartkeyboardH3)')
			smartkeyboardH4 = xbmc.getInfoLabel('Skin.String(smartkeyboardH4)')
			smartkeyboardH5 = xbmc.getInfoLabel('Skin.String(smartkeyboardH5)')
			'''execute'''
			xbmc.executebuiltin('Action(Close)')
			xbmc.sleep(200)
			#xbmc.executebuiltin('Action(
			if admin: xbmc.executebuiltin('Notification(Admin,smartkeyboardhistory,1000)')
			if smartkeyboardHN == '1': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH1 +'","done":false}}')
			if smartkeyboardHN == '2': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH2 +'","done":false}}')
			if smartkeyboardHN == '3': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH3 +'","done":false}}')
			if smartkeyboardHN == '4': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH4 +'","done":false}}')
			if smartkeyboardHN == '5': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH5 +'","done":false}}')
			xbmc.executebuiltin('SetFocus(3000)')
		if smartkeyboardpaste:
			'''variable'''
			smartkeyboardPN = xbmc.getInfoLabel('Skin.String(smartkeyboardPN)')
			smartkeyboardC1 = xbmc.getInfoLabel('Skin.String(smartkeyboardC1)')
			smartkeyboardC2 = xbmc.getInfoLabel('Skin.String(smartkeyboardC2)')
			smartkeyboardC3 = xbmc.getInfoLabel('Skin.String(smartkeyboardC3)')
			smartkeyboardC4 = xbmc.getInfoLabel('Skin.String(smartkeyboardC4)')
			smartkeyboardC5 = xbmc.getInfoLabel('Skin.String(smartkeyboardC5)')
			'''execute'''
			xbmc.executebuiltin('Action(Close)')
			xbmc.sleep(200)
			if admin: xbmc.executebuiltin('Notification(Admin,smartkeyboardpaste,1000)')
			if smartkeyboardPN == '1': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC1 +'","done":false}}')
			if smartkeyboardPN == '2': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC2 +'","done":false}}')
			if smartkeyboardPN == '3': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC3 +'","done":false}}')
			if smartkeyboardPN == '4': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC4 +'","done":false}}')
			if smartkeyboardPN == '5': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC5 +'","done":false}}')
			xbmc.executebuiltin('SetFocus(3000)')