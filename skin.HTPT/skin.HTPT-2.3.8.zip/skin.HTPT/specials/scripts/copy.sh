#!/bin/bash
#cp_launcher=$HOME/.xbmc/addons/skin.HTPT/specials/scripts/copy/launcher
#launcher_cp=$HOME/.xbmc/userdata/addon_data/plugin.program.advanced.launcher
#FILESIZE=`du -k "$cp_userdata/guisettings.xml" | cut -f1`
#FILESIZE_C=`ls $cp_userdata/guisettings2.xml -s | grep -i "$FILESIZE" | wc -l`
#echo $FILESIZE $FILESIZE_C

USERDATA_PATH=$HOME/.xbmc/userdata
USERDATA_PATH2=$HOME/.xbmc/addons/skin.HTPT/specials/scripts/copy/userdata
GUISETTINGS_FILE_CON1=`cat $USERDATA_PATH/guisettings.xml | grep -i "<skin>skin.HTPT</skin>" | wc -l`
GUISETTINGS_FILE2_CON1=`cat $USERDATA_PATH2/guisettings.xml | grep -i "<skin>skin.HTPT</skin>" | wc -l`
GUISETTINGS_FILE3_CON1=`cat $USERDATA_PATH2/guisettings2.xml | grep -i "<skin>skin.HTPT</skin>" | wc -l`

if [ $GUISETTINGS_FILE_CON1 -eq 0 ]; then
	echo Error: GUISETTINGS_FILE_CON1!
	if [ $GUISETTINGS_FILE2_CON1 -eq 0 ]; then
		echo Error: GUISETTINGS_FILE2_CON1!
		if [ $GUISETTINGS_FILE3_CON1 -eq 0 ]; then
			echo Error: GUISETTINGS_FILE3_CON1!
			systemctl stop xbmc.service
		else
			echo Copy: $USERDATA_PATH2/guisettings2.xml '->' $USERDATA_PATH/guisettings.xml
			cp -f $USERDATA_PATH2/guisettings2.xml $USERDATA_PATH/guisettings.xml
		fi
	else
		echo Copy: $USERDATA_PATH2/guisettings.xml '->' $USERDATA_PATH/guisettings.xml
		cp -f $USERDATA_PATH2/guisettings.xml $USERDATA_PATH/guisettings.xml
	fi
	#sleep 5
	#echo systemctl start
	#systemctl start xbmc.service
	sleep 1 && echo killall && killall -9 xbmc.bin
	
else
	if [ $GUISETTINGS_FILE2_CON1 -eq 0 ]; then
		echo Error: GUISETTINGS_FILE2_CON1!!
	else
		echo Old Backup: guisettings2.xml
		cp -f $USERDATA_PATH2/guisettings.xml $USERDATA_PATH2/guisettings2.xml
	fi
	echo New Backup: guisettings.xml
	cp -f $USERDATA_PATH/guisettings.xml $USERDATA_PATH2/guisettings.xml
fi

USERDATA_FILE1_CON1=`du -k "$USERDATA_PATH2/advancedsettings.xml" | cut -f1`
USERDATA_FILE1_CON2=`ls $USERDATA_PATH/advancedsettings.xml -s | grep -i "$USERDATA_FILE1_CON1" | wc -l`
if [ $USERDATA_FILE1_CON2 -eq 0 ]; then
	echo Error: advancedsettings.xml
	echo Copy: advancedsettings.xml
	cp -f $USERDATA_PATH2/advancedsettings.xml $USERDATA_PATH/advancedsettings.xml
fi

USERDATA_FILE2_CON1=`du -k "$USERDATA_PATH2/sources.xml" | cut -f1`
USERDATA_FILE2_CON2=`ls $USERDATA_PATH/sources.xml -s | grep -i "$USERDATA_FILE2_CON1" | wc -l`
if [ $USERDATA_FILE2_CON2 -eq 0 ]; then
	echo Error: sources.xml
	echo Copy: sources.xml
	cp -f $USERDATA_PATH2/sources.xml $USERDATA_PATH/sources.xml
fi

KEYMAPS_PATH=$HOME/.xbmc/userdata/keymaps
KEYMAPS_PATH2=$HOME/.xbmc/addons/skin.HTPT/specials/scripts/copy/keymaps
#cp $cp_launcher/* $launcher_cp/
cp $KEYMAPS_PATH2/* $KEYMAPS_PATH/
#cp $USERDATA_PATH2/* $USERDATA_PATH/

