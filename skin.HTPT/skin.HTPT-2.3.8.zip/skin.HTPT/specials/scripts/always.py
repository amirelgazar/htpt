import xbmc
import os, sys
import subprocess

systemplatformwindows = xbmc.getCondVisibility('system.platform.windows')
count = 0
while (count == 0 or count > 0): # and (not xbmc.abortRequested)
	'''SKIN SETTINGS'''
	net = xbmc.getInfoLabel('Skin.HasSetting(Net)')
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	validation = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION)')
	validation2 = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION2)')
	autoviewoff = xbmc.getInfoLabel('Skin.HasSetting(AutoViewoff)')
	widget = xbmc.getInfoLabel('Skin.HasSetting(Widget)')
	myhtpt2 = xbmc.getInfoLabel('Skin.HasSetting(myHTPT2)')
	homebuttonsrunning = xbmc.getInfoLabel('Skin.HasSetting(homebuttonsrunning)')
	connected = xbmc.getInfoLabel('Skin.HasSetting(Connected)')
	connected2 = xbmc.getInfoLabel('Skin.HasSetting(Connected2)')
	connected3 = xbmc.getInfoLabel('Skin.HasSetting(Connected3)')
	'''?'''
	systemtime2 = xbmc.getInfoLabel('System.Time(ss)')
	def bash(bashCommand,bashname):
		'''run BASH commands'''
		if not systemplatformwindows:
			process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
			output = process.communicate()[0]
			if bashname == "Connected":
				#xbmc.executebuiltin('Skin.SetString(Test,'+ output +')')
				if "1 packets transmitted" in output:
					if not connected: xbmc.executebuiltin('Skin.ToggleSetting(Connected)')
				else:
					if connected: xbmc.executebuiltin('Skin.ToggleSetting(Connected)')
			if bashname == "Connected2":
				#xbmc.executebuiltin('Skin.SetString(Test,'+ output +')')
				if not "packets:0" in output and "inet addr" in output:
					if not connected2: xbmc.executebuiltin('Skin.ToggleSetting(Connected2)')
				else:
					if connected2: xbmc.executebuiltin('Skin.ToggleSetting(Connected2)')
			if bashname == "Connected3":
				#xbmc.executebuiltin('Skin.SetString(Test,'+ output +')')
				if not "packets:0" in output and "inet addr" in output:
					if not connected3: xbmc.executebuiltin('Skin.ToggleSetting(Connected3)')
				else:
					if connected3: xbmc.executebuiltin('Skin.ToggleSetting(Connected3)')
			if bashname == "myHTPT2":
				#xbmc.executebuiltin('Skin.SetString(Test,'+ output +')')
				#xbmc.executebuiltin('Skin.SetString(Test,'+ countS +')')
				if not "/var/media/" in output and "inet addr" in output:
					if not myhtpt2: xbmc.executebuiltin('Skin.ToggleSetting(myHTPT2)')
				else:
					if myhtpt2: xbmc.executebuiltin('Skin.ToggleSetting(myHTPT2)')

	class main:
		#if count >= 60: count = 0
		xbmc.sleep(1000)
		count = count + 1
		countS = str(count)
		if not systemplatformwindows:
			bash('ping -W 1 -w 1 -4 -q www.google.co.il',"Connected")
			if count == 59: bash('ifconfig wlan0',"Connected2")
			if count == 60: bash('ifconfig eth0',"Connected3")
			bash('df -h | grep -i "/var/media/" | wc -l',"myHTPT2")
		if count == 60: xbmc.executebuiltin('Notification(Admin,'+ systemtime2 +',1000)')
		xbmc.executebuiltin('Skin.SetString(Test,'+ countS +')')