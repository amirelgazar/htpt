#!/bin/bash
SETTINGS=$HOME/.xbmc/userdata/addon_data/plugin.video.genesis/settings.xml

###VAR SWITCHABLE###
AUTOPLAY='"autoplay" value='
AUTOPLAYLIBRARY='"autoplay_library" value='
PLAYBACKINFO='"playback_info" value='

###VAR GENERAL###
T='"true"'
F='"false"'
ALL='"[^ ]*"'
NUM1='"1"'
NUM0='"0"'

sed -i "s/$AUTOPLAY$T/$AUTOPLAY$F/g" $SETTINGS ###AUTOPLAY ADDON OFF###
sed -i "s/$AUTOPLAYLIBRARY$T/$AUTOPLAYLIBRARY$F/g" $SETTINGS ###AUTOPLAY LIBRARY OFF###
sed -i "s/$PLAYBACKINFO$T/$PLAYBACKINFO$F/g" $SETTINGS ###DETAILS OFF###