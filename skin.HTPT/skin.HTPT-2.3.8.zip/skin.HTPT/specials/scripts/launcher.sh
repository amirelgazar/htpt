#!/bin/bash
cp_launcher=$HOME/.xbmc/addons/skin.HTPT/specials/scripts/copy/launcher
launcher_cp=$HOME/.xbmc/userdata/addon_data/plugin.program.advanced.launcher

filename=launchers.xml
filesize=`du -k "$cp_launcher/$filename" | cut -f1`
launcher_grep=`ls $launcher_cp/$filename -s | grep -i "$filesize" | wc -l`

if [ $launcher_grep -eq 0 ]; then
	cp $cp_launcher/* $launcher_cp/
	echo "launcher_grep ($launcher_grep)" && echo "$filename = $filesize bytes."
	sleep 1
fi
###BLUETOOTH TEST###
#modprobe btusb #Load the generic bluetooth driver, if not already loaded
#systemctl start bluetooth #To start the bluetooth systemd service
#systemctl enable bluetooth #To enable the bluetooth service at boot time

#test1 = echo -e bluetoothctl | bluetoothctl
#val=$(cut -d " " -f3 $test1)
#echo test1
#echo $val
#test2 = `test1 | grep -i "xx_xx_xx_xx_xx_xx" | wc -l`
#echo test2
#sleep 1
#echo -e nquit
#echo -e 'power on\nconnect \t \nquit' | bluetoothctl
#devices = echo -e 'power on\nconnect \t \nquit' | bluetoothctl | grep -o 'name=[^ ,]\+' | wc -l

#quit
#devices
#devices =' grep
#devices =`devices | grep -i "xx_xx_xx_xx_xx_xx" | wc -l`

#echo awk '{print $3}`


#echo "eth0 ($LAN2) --> Turned on!"

#cp $HOME/.xbmc/addons/skin.HTPT/specials/scripts/copy/keymaps/* $HOME/.xbmc/userdata/keymaps/
#cp $HOME/.xbmc/addons/skin.HTPT/specials/scripts/copy/userdata/* $HOME/.xbmc/userdata/
#BACKUP=$HOME/.xbmc/addons/skin.HTPT/specials/launchers.xml
#RESTORE=$HOME/.xbmc/userdata/addon_data/plugin.program.advanced.launcher/
#
#cp $BACKUP $RESTORE