import xbmc, os, subprocess, sys
admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
systemplatformwindows = xbmc.getCondVisibility('system.platform.windows')

def toggleautoplay(run):
	autoplaysd = xbmc.getInfoLabel('Skin.HasSetting(AutoPlaySD)')
	connectionstatus2 = xbmc.getInfoLabel('Skin.String(ConnectionStatus2)')
	if run == 'on':
		if admin: xbmc.executebuiltin('Notification(Admin genesis5.sh,AutoPlay ON,2000)')
		if not systemplatformwindows: os.system('sh /storage/.xbmc/addons/skin.HTPT/specials/scripts/genesis5.sh')
	if run == 'off':
		if admin: xbmc.executebuiltin('Notification(Admin genesis4.sh,AutoPlay OFF,2000)')
		elif connectionstatus2 == '5': xbmc.executebuiltin('Notification($LOCALIZE[79495],,2000)')
		elif connectionstatus2 == '4' and autoplaysd: xbmc.executebuiltin('Notification($LOCALIZE[79495],,2000)')
		if not systemplatformwindows: os.system('sh /storage/.xbmc/addons/skin.HTPT/specials/scripts/genesis4.sh')
class start:
	autoplaypause = xbmc.getInfoLabel('Skin.HasSetting(AutoPlayPause)')
	if autoplaypause: toggleautoplay('off')
	if not autoplaypause: toggleautoplay('on')
	