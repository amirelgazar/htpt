#!/bin/bash
SETTINGS=$HOME/.xbmc/userdata/addon_data/plugin.video.youtube/settings.xml

###VAR SOURCES###
STORESEARCHS='"store_searches" value='

###VAR FIX -BOOLEAN###
SEARCH='"search" value='
SUBSCRIPTIONS='"subscriptions" value='

###VAR FIX -STRINGS###
SAFESEARCH='"safe_search" value='
DOWNLOADPATH='"download_path" value='

###VAR GENERAL###
T='"true"'
F='"false"'
DPATH='"special://userdata/myHTPT/downloads/"'
ALL='"[^ ]*"'
A1='"1"'
EMPTY='""'
###SED MAIN###
sed -i "s|$STORESEARCHS$ALL|$STORESEARCHS$EMPTY|g" $SETTINGS
###SED FIX###
sed -i "s|$SAFESEARCH$ALL|$SAFESEARCH$DPATH|g" $SETTINGS
sed -i "s|$DOWNLOADPATH$ALL|$DOWNLOADPATH$A1|g" $SETTINGS

sed -i "s/$SEARCH$F/$SEARCH/$T/g" $SETTINGS
sed -i "s/$SUBSCRIPTIONS$F/$SUBSCRIPTIONS/$T/g" $SETTINGS

