#!/bin/sh
ADDON_DIR=$HOME/.xbmc/addons/emulator.retroarch
LD_LIBRARY_PATH=$ADDON_DIR/lib
chmod +x $ADDON_DIR/bin/*
export LD_LIBRARY_PATH
###VAR CON###
DAY=`(date +%a)`
HOUR=`(date +%H)`
echo $DAY $HOUR >> /storage/autostart.log
$HOME/.xbmc/addons/skin.HTPT/specials/scripts/copy.sh
$HOME/.xbmc/addons/skin.HTPT/specials/scripts/genesis.sh
$HOME/.xbmc/addons/skin.HTPT/specials/scripts/genesis1.sh
$HOME/.xbmc/addons/skin.HTPT/specials/scripts/genesis2.sh
#$HOME/.xbmc/addons/skin.HTPT/specials/scripts/genesis5.sh ###IN homebuttons.py###
#killall eventlircd
#ir-keytable -s rc0 -p NEC -t
#You can see if autostart.sh is executed from /var/log/messages file.