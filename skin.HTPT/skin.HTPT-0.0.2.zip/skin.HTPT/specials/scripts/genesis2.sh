#!/bin/bash
SETTINGS=$HOME/.xbmc/userdata/addon_data/plugin.video.genesis/settings.xml
###VAR SOURCES###
CLICKPLAYTV='"clickplay_tv" value='
EINTHUSAN='"einthusan" value='
HDLORD='"hdlord" value='
ICEFILMS='"icefilms" value='
ICEFILMSTV='"icefilms_tv" value='
ISTREAMHD='"istreamhd" value='
ISTREAMHDTV='"istreamhd_tv" value='
IWATCHONLINE='"iwatchonline" value='
IWATCHONLINETV='"iwatchonline_tv" value='
MUCHMOVIES='"muchmovies" value='
MOVIESTORM='"moviestorm" value='
MOVIESTORMTV='"moviestorm_tv" value='
MOVIESHD='"movieshd" value='
MOVIE25='"movie25" value='
MOVIETUBE='"movietube" value='
MOVIETV='"movietv" value='
MOVIETVTV='"movietv_tv" value='
MYVIDEOLINKS='"myvideolinks" value='
NITER='"niter" value='
PRIMEWIRE='"primewire" value='
PRIMEWIRETV='"primewire_tv" value='
POPCORNERED='"popcornered" value='
PUTLOCKERTV='"putlocker_tv" value='
SHUSHTV='"shush_tv" value='
SIMPLYMOVIES='"simplymovies" value='
SIMPLYMOVIESTV='"simplymovies_tv" value='
VKBOX='"vkbox" value='
VKBOXTV='"vkbox_tv" value='
WATCHSERIESTV='"watchseries_tv" value='
YIFY='"yify" value='
YOURFLIX='"yourflix" value='

###VAR GENERAL###
T='"true"'
F='"false"'

ALL='"[^ ]*"'
NUM1='"1"'
NUM0='"0"'

###VAR CON###
DAY=`(date +%a)`
HOUR=`(date +%H)`

###GET USER ID###
GUI='/storage/.xbmc/userdata/guisettings.xml'
FIND1='>[^ ]*<' ###?###
FINDIN=$GUI
FINDWHAT='"skin.HTPT.ID"'
FINDLINE=`find $FINDIN -type f -exec grep $FINDWHAT /dev/null {} \;`
FINDEXACT=`echo $FINDLINE | grep -o '>[^ ]*<' | sed 's/[<>]//g'`
ID='"'$FINDEXACT'"'
IDP='"gkalni"'
echo ID: $ID '('$FINDEXACT')'

###GET RealDebrid###
GUI='/storage/.xbmc/userdata/guisettings.xml'
FIND1='>[^ ]*<' ###?###
FINDIN=$GUI
FINDWHAT='"RealDebrid"'
FINDLINE=`find $FINDIN -type f -exec grep $FINDWHAT /dev/null {} \;`
FINDEXACT=`echo $FINDLINE | grep -o '>[^ ]*<' | sed 's/[<>]//g'`
REALDEBRID='"'$FINDEXACT'"'
echo RealDebrid: $REALDEBRID '('$FINDEXACT')'

if [ $HOUR -gt 03 ] && [ $HOUR -le 12 ]; then
	TIMEZONE=A
else
	if [ $HOUR -gt 11 ] && [ $HOUR -le 20 ]; then
		TIMEZONE=B
	else
		if [ $HOUR -gt 19 ] || [ $HOUR -le 04 ]; then
			TIMEZONE=C
		fi
	fi
fi
echo DAY: $DAY '|' HOUR: $HOUR '|' TIMEZONE: $TIMEZONE

###MAIN###
if [ $REALDEBRID == $F ]; then
	if [ $TIMEZONE == "A" ]; then
		echo ACTIVATING REALDEBRID ON TIMEZONE!
		sed -i "s/$REALDEDRIDUSER$E/$REALDEDRIDUSER$ID/g" $SETTINGS
		sed -i "s/$REALDEDRIDPASS$E/$REALDEDRIDPASS$IDP/g" $SETTINGS
	else
		echo DEACTIVATING REALDEBRID ON TIMEZONE!
		sed -i "s/$REALDEDRIDUSER$ALL/$REALDEDRIDUSER$E/g" $SETTINGS
		sed -i "s/$REALDEDRIDPASS$ALL/$REALDEDRIDPASS$E/g" $SETTINGS
	fi
fi

if [ $DAY == "Thu" ]; then
	if [ $TIMEZONE == "A" ]; then
		echo Thu '|' A
	else
		if [ $TIMEZONE == "B" ]; then
			echo Thu '|' B
		else
			if [ $TIMEZONE == "C" ]; then
				echo Thu '|' C
			fi
		fi
	fi
fi

if [ $DAY == "Fri" ]; then
	if [ $TIMEZONE == "A" ]; then
		echo Fri '|' A
	else
		if [ $TIMEZONE == "B" ]; then
			echo Fri '|' B
		else
			if [ $TIMEZONE == "C" ]; then
				echo Fri '|' C
			fi
		fi
	fi
fi

if [ $DAY == "Sat" ]; then
	if [ $TIMEZONE == "A" ]; then
		echo Sat '|' A
	else
		if [ $TIMEZONE == "B" ]; then
			echo Sat '|' B
		else
			if [ $TIMEZONE == "C" ]; then
				echo Sat '|' C
			fi
		fi
	fi
fi

if [ $DAY == "Sun" ]; then
	if [ $TIMEZONE == "A" ]; then
		echo Sun '|' A
	else
		if [ $TIMEZONE == "B" ]; then
			echo Sun '|' B
		else
			if [ $TIMEZONE == "C" ]; then
				echo Sun '|' C
			fi
		fi
	fi
fi
###SOURCES ON/OFF###
#sed -i "s/$CLICKPLAYTV$T/$CLICKPLAYTV$F/g" $SETTINGS
#sed -i "s/$EINTHUSAN$T/$EINTHUSAN$F/g" $SETTINGS
#sed -i "s/$HDLORD$T/$HDLORD$F/g" $SETTINGS
#sed -i "s/$ICEFILMS$T/$ICEFILMS$F/g" $SETTINGS
#sed -i "s/$ICEFILMSTV$T/$ICEFILMSTV$F/g" $SETTINGS
#sed -i "s/$ISTREAMHD$T/$ISTREAMHD$F/g" $SETTINGS
#sed -i "s/$ISTREAMHDTV$T/$ISTREAMHDTV$F/g" $SETTINGS
#sed -i "s/$IWATCHONLINE$T/$IWATCHONLINE$F/g" $SETTINGS
#sed -i "s/$IWATCHONLINETV$T/$IWATCHONLINETV$F/g" $SETTINGS
#sed -i "s/$MUCHMOVIES$T/$MUCHMOVIES$F/g" $SETTINGS
#sed -i "s/$MOVIESTORM$T/$MOVIESTORM$F/g" $SETTINGS
#sed -i "s/$MOVIESTORMTV$T/$MOVIESTORMTV$F/g" $SETTINGS
#sed -i "s/$MOVIESHD$T/$MOVIESHD$F/g" $SETTINGS
#sed -i "s/$MOVIE25$T/$MOVIE25$F/g" $SETTINGS
#sed -i "s/$MOVIETUBE$T/$MOVIETUBE$F/g" $SETTINGS
#sed -i "s/$MOVIETV$T/$MOVIETV$F/g" $SETTINGS
#sed -i "s/$MOVIETVTV$T/$MOVIETVTV$F/g" $SETTINGS
#sed -i "s/$MYVIDEOLINKS$T/$MYVIDEOLINKS$F/g" $SETTINGS
#sed -i "s/$NITER$T/$NITER$F/g" $SETTINGS
#sed -i "s/$POPCORNERED$T/$POPCORNERED$F/g" $SETTINGS
#sed -i "s/$PRIMEWIRE$T/$PRIMEWIRE$F/g" $SETTINGS
#sed -i "s/$PUTLOCKERTV$T/$PUTLOCKERTV$F/" $SETTINGS
#sed -i "s/$PUTLOCKERTV$F/$PUTLOCKERTV$T/" $SETTINGS
#sed -i "s/$PRIMEWIRETV$T/$PRIMEWIRETV$F/g" $SETTINGS
#sed -i "s/$SHUSHTV$T/$SHUSHTV$F/g" $SETTINGS
#sed -i "s/$VKBOX$T/$VKBOX$F/g" $SETTINGS
#sed -i "s/$VKBOXTV$T/$VKBOXTV$F/g" $SETTINGS
#sed -i "s/$SIMPLYMOVIES$T/$SIMPLYMOVIES$F/g" $SETTINGS
#sed -i "s/$SIMPLYMOVIESTV$T/$SIMPLYMOVIESTV$F/" $SETTINGS
#sed -i "s/$WATCHSERIESTV$T/$WATCHSERIESTV$F/" $SETTINGS
#sed -i "s/$YIFY$T/$YIFY$F/" $SETTINGS
#sed -i "s/$YOURFLIX$T/$YOURFLIX$F/" $SETTINGS
