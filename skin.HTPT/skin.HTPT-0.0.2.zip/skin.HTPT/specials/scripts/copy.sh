#!/bin/bash

USERDATA_PATH=$HOME/.xbmc/userdata
USERDATA_PATH2=$HOME/.xbmc/addons/skin.HTPT/specials/scripts/copy/userdata
USERDATA_PATH3=$HOME/.xbmc/userdata/addon_data/skin.HTPT/userdata

if [ ! -d "$USERDATA_PATH3" ]; then
	echo CREATING USERDATA_PATH3
	mkdir -p $USERDATA_PATH3
fi

VALIDATION2='"skin.HTPT.VALIDATION2">'
T='true'
F='false'
VALIDATION2=`cat $USERDATA_PATH/guisettings.xml | grep -i $VALIDATION2$F | wc -l`
GUISETTINGS_FILE_CON1=`cat $USERDATA_PATH/guisettings.xml | grep -i "<skin>skin.HTPT</skin>" | wc -l`
GUISETTINGS_FILE2_CON1=`cat $USERDATA_PATH3/guisettings.xml | grep -i "<skin>skin.HTPT</skin>" | wc -l`
GUISETTINGS_FILE3_CON1=`cat $USERDATA_PATH3/guisettings2.xml | grep -i "<skin>skin.HTPT</skin>" | wc -l`

if [ $GUISETTINGS_FILE_CON1 -eq 0 ]; then
	echo Error: GUISETTINGS_FILE_CON1!
	if [ $GUISETTINGS_FILE2_CON1 -eq 0 ]; then
		echo Error: GUISETTINGS_FILE2_CON1!
		if [ $GUISETTINGS_FILE3_CON1 -eq 0 ]; then
			echo Error: GUISETTINGS_FILE3_CON1!
			cp -f $USERDATA_PATH2/guisettings3.xml $USERDATA_PATH/guisettings.xml
			#systemctl stop xbmc.service
		else
			echo Copy: $USERDATA_PATH3/guisettings2.xml '->' $USERDATA_PATH/guisettings.xml
			cp -f $USERDATA_PATH3/guisettings2.xml $USERDATA_PATH/guisettings.xml
		fi
	else
		echo Copy: $USERDATA_PATH3/guisettings.xml '->' $USERDATA_PATH/guisettings.xml
		cp -f $USERDATA_PATH3/guisettings.xml $USERDATA_PATH/guisettings.xml
	fi
	#sleep 5
	#echo systemctl start
	#systemctl start xbmc.service
	sleep 1 && echo killall && killall -9 xbmc.bin
	
else
	if [ $GUISETTINGS_FILE2_CON1 -eq 0 ]; then
		echo Error: GUISETTINGS_FILE2_CON1!!
	else
		echo Old Backup: guisettings2.xml
		cp -f $USERDATA_PATH3/guisettings.xml $USERDATA_PATH3/guisettings2.xml
	fi
	if [ $VALIDATION2 -eq 1 ]; then
		echo New Backup: guisettings.xml
		cp -f $USERDATA_PATH/guisettings.xml $USERDATA_PATH3/guisettings.xml
	else
		echo ERROR: VALIDATION2!!! CANT CREATE NEW BACKUP $VALIDATION2
	fi
fi

SKIN_PATH=/storage/.xbmc/addons/skin.HTPT
SERVICE_PATH=/storage/.xbmc/addons/service.HTPT
SKIN_FOLDER_SIZE=`du $SKIN_PATH/ -s | awk {'print $1'}`
if [ $GUISETTINGS_FILE_CON1 -eq 0 ] && [ $SKIN_FOLDER_SIZE -le 50000 ] || [ $GUISETTINGS_FILE_CON1 -eq 0 ] && [ ! -d "$SKIN_PATH" ]; then
	echo ERROR: SKIN FOLDER '(GUI/SIZE/EMPTY)'
	ls $HOME/.xbmc/addons/packages/skin.HTPT* -r | awk {'print $1'} | tee /storage/skinpackage.log
	SKIN_FILE1=`head -1 skinpackage.log`
	SKIN_FILE1_SIZE=`du $SKIN_FILE1 -s | awk {'print $1'}`
	SKIN_FILE2=`sed -n 2p skinpackage.log`
	SKIN_FILE2_SIZE=`du $SKIN_FILE2 -s | awk {'print $1'}`
	SKIN_FILE3=`sed -n 3p skinpackage.log`
	SKIN_FILE3_SIZE=`du $SKIN_FILE3 -s | awk {'print $1'}`
	
	if [ $SKIN_FILE3_SIZE -gt 50000 ] && [ -f SKIN_FILE3 ]; then
		echo EXTRACTING SKIN_FILE3
		unzip -o -q $SKIN_FILE3 -d /storage/.xbmc/addons/
		rm $SKIN_FILE3
	else
		if [ $SKIN_FILE2_SIZE -gt 50000 ] && [ -f SKIN_FILE2 ]; then
			echo EXTRACTING SKIN_FILE2
			unzip -o -q $SKIN_FILE2 -d /storage/.xbmc/addons/
			rm $SKIN_FILE2
		else
			if [ $SKIN_FILE1_SIZE -gt 50000 ] && [ -f SKIN_FILE1 ]; then
				echo EXTRACTING SKIN_FILE1
				unzip -o -q $SKIN_FILE1 -d /storage/.xbmc/addons/
				#rm $SKIN_FILE1
			else
				echo ERROR: NO ZIP FILES TO EXTRACT!!!
				#SKIN_FILE4=`ls $SERVICE_PATH/specials/scripts/copy/skin.HTPT*.zip -r | awk {'print $1'}`
				#echo EXTRACTING FROM service.HTPT
				#unzip -o -q $SKIN_FILE4 -d /storage/.xbmc/addons/
			fi
		fi		
	fi	
	
	sleep 1 && echo killall && killall -9 xbmc.bin
fi

if [ ! -d "$SERVICE_PATH" ]; then
	echo ERROR: SERVICE_PATH EMPTY!
	SERVICE_FILE4=`ls $SKIN_PATH/specials/scripts/copy/service.HTPT*.zip -r | awk {'print $1'}`
	echo EXTRACTING FROM skin.HTPT
	unzip -o -q $SERVICE_FILE4 -d /storage/.xbmc/addons/
fi
	
#FILENAME=advancedsettings.xml
#FILE1_PATH=$USERDATA_PATH2
#FILE2_PATH=$USERDATA_PATH
#FILE3_PATH=$USERDATA_PATH3
#FILE1_DATE=`date +%H:%M:%S -r "$FILE1_PATH/$FILENAME"`
#FILE2_DATE=`date +%H:%M:%S -r "$FILE2_PATH/$FILENAME"`
#echo $FILE1_DATE
#echo $FILE2_DATE
#if [ $FILE1_DATE != $FILE2_DATE ] && [ ! -f $USERDATA_PATH3 ]; then
	#echo COPY: $FILENAME
	#cp -f $FILE1_PATH/$FILENAME $FILE2_PATH/$FILENAME
#fi


if [ -d "$SKIN_PATH" ]; then
	CUSTOM_PATH=$HOME/.xbmc/userdata/addon_data/skin.HTPT

	FILENAME=advancedsettings.xml
	if [ ! -f $CUSTOM_PATH/userdata/$FILENAME ]; then
		FILE1_PATH=$USERDATA_PATH2
		FILE2_PATH=$USERDATA_PATH
		echo COPY: $FILENAME
		cp -f $FILE1_PATH/$FILENAME $FILE2_PATH/$FILENAME
	fi

	FILENAME=sources.xml
	if [ ! -f $CUSTOM_PATH/userdata/$FILENAME ]; then
		FILE1_PATH=$USERDATA_PATH2
		FILE2_PATH=$USERDATA_PATH
		echo COPY: $FILENAME
		cp -f $FILE1_PATH/$FILENAME $FILE2_PATH/$FILENAME
	fi

	KEYMAPS_PATH=$HOME/.xbmc/userdata/keymaps
	KEYMAPS_PATH2=$HOME/.xbmc/addons/skin.HTPT/specials/scripts/copy/keymaps
	cp $KEYMAPS_PATH2/* $KEYMAPS_PATH/

	FILENAME=remote.sh
	if [ ! -f $CUSTOM_PATH/userdata/$FILENAME ]; then
		FILE1_PATH=$SKIN_PATH/specials/scripts
		FILE2_PATH=$USERDATA_PATH3
		echo COPY: $FILENAME
		cp -f $FILE1_PATH/$FILENAME $FILE2_PATH/$FILENAME
	fi
fi