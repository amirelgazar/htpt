#!/bin/bash
import xbmc
import os, subprocess

admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
systemplatformwindows = xbmc.getCondVisibility('system.platform.windows')
if admin:
	xbmc.executebuiltin('Notification(Admin,softrestart + reloadkeymaps,2000)')
	xbmc.executebuiltin('Action(reloadkeymaps)')
	xbmc.sleep(500)
#if not systemplatformwindows: os.system('sh /storage/.xbmc/addons/skin.HTPT/specials/scripts/softrestart.sh')
class main:
	def bash(bashCommand,bashname):
		process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
		output = process.communicate()[0]
		#if bashname == "Connected":
			#xbmc.executebuiltin('Skin.SetString(Test,'+ output +')')
			#if "1 packets transmitted" in output:
				#if not connected: xbmc.executebuiltin('Skin.ToggleSetting(Connected)')
			#else:
				#if connected: xbmc.executebuiltin('Skin.ToggleSetting(Connected)')
	bash('killall -9 xbmc.bin','killall')