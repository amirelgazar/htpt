#!/bin/bash

SKIN_PATH=$HOME/.xbmc/addons/skin.HTPT
SKIN2_PATH=$HOME/.xbmc/userdata/addon_data/skin.HTPT

FILENAME=autostart.sh
FILE1_PATH=$SKIN_PATH/specials/scripts/copy/config
FILE2_PATH=$HOME/.config
echo COPY: $FILENAME
cp -f $FILE1_PATH/$FILENAME $FILE2_PATH/$FILENAME

FILENAME=samba.conf
echo COPY: $FILENAME
cp -f $FILE1_PATH/$FILENAME $FILE2_PATH/$FILENAME