import xbmc, xbmcgui
 
#get actioncodes from https://github.com/xbmc/xbmc/blob/master/xbmc/guilib/Key.h
ACTION_PREVIOUS_MENU = 10
 
class MyClass(xbmcgui.Window):
  def __init__(self):
    self.strActionInfo = xbmcgui.ControlLabel(100, 120, 200, 200, '', 'font13', '0xFFFF00FF')
    self.addControl(self.strActionInfo)
    self.strActionInfo.setLabel('Push BACK')
 
  def onAction(self, action):
    if action == ACTION_PREVIOUS_MENU:
      self.goodbye()
 
  def goodbye(self):
    dialog = xbmcgui.Dialog()
    if dialog.yesno("message", "do you want to leave?"):
      self.close()
 
mydisplay = MyClass()
mydisplay .doModal()
del mydisplay