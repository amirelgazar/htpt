# -*- coding: utf-8 -*-
#import xbmc, os, subprocess, sys
#import xbmc, xbmcgui, xbmcaddon
import xbmc, xbmcgui, xbmcaddon
import subprocess, os, sys
import xbmcplugin
import urllib
import urllib2
import re

from variables import *
from shared_modules import *
from shared_modules3 import addDir
from shared_modules4 import guikeeper

def mode0(admin, name, printpoint):
	TypeError = "" ; extra = ""
	try:
		systemmemorytotal2 = systemmemorytotal.replace("MB","")
		if systemmemorytotal2 >= 384: pass
		else:
			printpoint = printpoint + "9"
			dialogok("Memory Warning!", "Your hardware don't have enough memory ram" + "(" + str(systemmemorytotal2) + ")", "Make sure you have atleast 384MB of free memory ram.","")
		extra = extra + newline + "systemmemorytotal2" + space2 + str(systemmemorytotal2)
	except Exception, TypeError: 
		extra = extra + newline + "TypeError" + space2 + str(TypeError)
		dialogok("Memory Warning!", "Unable to obtain required hardware information.", "Make sure you have atleast a total of 1GB of memory ram.","")
	
	printpoint = printpoint + installaddon2(admin, 'repository.htpt', update=True)
	if not "8" in printpoint and not "9" in printpoint: printpoint = printpoint + installaddon2(admin, 'service.htpt', update=True)
	if not "8" in printpoint and not "9" in printpoint: printpoint = printpoint + installaddon2(admin, 'script.htpt.debug', update=True)
	'''---------------------------'''
	
	if not "8" in printpoint and not "9" in printpoint:
		if "5" in printpoint:
			notification("PROCEEDING PLEASE WAIT...","","",2000)
			xbmc.sleep(1000)
			printpoint = printpoint + "7"
			'''---------------------------'''
	
		CATEGORIES(servicehtpt_Skin_Name, skinnamestr)
		xbmcplugin.endOfDirectory(int(sys.argv[1]))
		'''---------------------------'''
	
	print printfirst + name + "_LV" + printpoint + space + extra
	return printpoint
	
def CATEGORIES(servicehtpt_Skin_Name, skinnamestr):
	if servicehtpt_Skin_Name == "": servicehtpt_Skin_Name = "?"
	addon = 'skin.htpt'
	if xbmc.getCondVisibility('System.HasAddon('+ addon +')') and os.path.exists(addons_path + addon):
		if servicehtpt_Skin_Name == addon or skinnamestr == addon:
			addDir(addonString(11),'',21,htptinstallmedia_path + 'bin.png',addonString(101),'1',500) #הסרת מערכת
			if Skin_Suspend == "false": addDir(addonString(12),'',22,htptinstallmedia_path + 'linkbroken.png',addonString(102),'1',500) #השהיית מערכת
			'''---------------------------'''
			if admin and not admin2:
				addDir("Test7",'',7,htptinstallmedia_path + 'caa2.png','','1',500) #Test
		else:
			try: addDir(addonString(13),'',23,htptinstallmedia_path + 'htpt.png',addonString(103),'1',500) #כניסה ל-HTPT
			except: pass
			'''---------------------------'''
	else:
		addDir(addonString(10),'',20,htptinstallmedia_path + 'software.png',addonString(100),'1',500) #התקנת מערכת
		'''---------------------------'''
		
	addon = 'script.htpt.debug'
	if xbmc.getCondVisibility('System.HasAddon('+ addon +')') and os.path.exists(addons_path + addon):
		addDir(addonString(14),'',14,htptinstallmedia_path + 'help.png',addonString(104),'1',500) #עזרה
	
	#xbmc.executebuiltin('Container.Refresh')

def setUserID(admin, addonID, User_ID, idstr, htpt_a1, htpt_a2):
	'''------------------------------
	---APPLY-USER-ID-----------------
	------------------------------'''
	#from shared_variables import htpt_a1, htpt_a2
	name = 'APPLY-USER-ID' ; printpoint = ""
	idstr_len = len(idstr)
	pvalue = checkID(admin, idstr, 'ID')
	pvalue_len = len(pvalue)
	pvalue2 = User_ID
	pvalue2_len = len(pvalue2)
	if (not htpt_a1 in idstr or (idstr_len != 11 and not htpt_a2 in id9str)):
		printpoint = printpoint + "1"
		if "htptuser" in idstr: printpoint = printpoint + "5"
		elif admin3 or "finalmakerr" in idstr: printpoint = printpoint + "5"
		else:
			if htpt_a1 in pvalue and pvalue_len == 11: setSkinSetting("0",'ID',pvalue) ; printpoint = printpoint + "2"
			elif htpt_a1 in pvalue2 and pvalue2_len == 11: setSkinSetting("0",'ID',pvalue2) ; printpoint = printpoint + "3"
			else:
				printpoint = printpoint + "4"
				returned, value = getRandom("0", min=1000000, max=7000000, percent=50)
				setSkinSetting("0",'ID',htpt_a1 + str(value))
				if addonID == 'script.htpt.install': setsetting('User_ID',htpt_a1 + str(value))
				else: setsetting_custom1(addonID,'User_ID',htpt_a1 + str(value))
				'''---------------------------'''		
	else: printpoint = printpoint + "5"
	
	if "5" in printpoint:
		if addonID == 'script.htpt.install': setsetting('User_ID',idstr) ; printpoint = printpoint + "7"
		else: setsetting_custom1(addonID,'User_ID',idstr) ; printpoint = printpoint + "7?"
		'''---------------------------'''	
		
		
	print printfirst + name + "_LV" + printpoint + space + "addonID" + space2 + str(addonID) + space + "User_ID" + space2 + str(User_ID) + space + "idstr" + space2 + str(idstr) + newline + \
		"idstr_len" + space2 + str(idstr_len) + space + "pvalue_len" + space2 + str(pvalue_len) + space + "pvalue2_len" + space2 + str(pvalue2_len) + newline + \
		"htpt_a1" + space2 + str(htpt_a1) + space + "htpt_a2" + space2 + str(htpt_a2)
		
def setUserID2(admin, addonID, User_ID2, id2str):
	printpoint = ""
	try:
		'''------------------------------
		---APPLY-USER-ID2----------------
		------------------------------'''
		name = 'APPLY-USER-ID2'
		
		if 1 + 1 == 3: #STRINGTODATE BUG!
			#import datetime as dt
			#from datetime import datetime
			#User_ID2D = stringtodate(User_ID2, '%Y-%m-%d')
			id2strD = stringtodate(id2str, '%Y-%m-%d')
			
			if User_ID2D == "error" and (id2strD != "error" and id2strD != ""): setsetting_custom1('script.htpt.install', 'User_ID2', id2str)
			elif (User_ID2D != "error" and User_ID2D != "") and id2strD == "error": setSkinSetting('0', 'ID2', User_ID2)
			elif User_ID2D == "error" and id2strD == "error":
				setSkinSetting('0', 'ID2', datenowS)
				setsetting_custom1('script.htpt.install', 'User_ID2', datenowS)
				'''---------------------------'''
			elif User_ID2D != "error" and id2strD != "error":
				if User_ID2D == "" and id2strD == "":
					setSkinSetting("0",'ID2', datenowS)
					setsetting_custom1(addonID, 'User_ID2', datenowS)
					'''---------------------------'''
				elif User_ID2D < id2strD: setSkinSetting("0",'ID2',User_ID2)
				elif User_ID2D > id2strD: setsetting_custom1(addonID, 'User_ID2', id2str)
			else: printpoint = printpoint + "6"
			'''---------------------------'''
		else:
			if User_ID2 == "" and id2str == "":
				printpoint = printpoint + "2"
				setSkinSetting("0",'ID2', datenowS)
				if addonID == 'script.htpt.install': setsetting('User_ID2', datenowS)
				else: setsetting_custom1(addonID, 'User_ID2', datenowS)
					
			elif User_ID2 == "":
				printpoint = printpoint + "3"
				if addonID == 'script.htpt.install': setsetting('User_ID2', id2str)
				else: setsetting_custom1(addonID, 'User_ID2', id2str)
			elif id2str == "": setSkinSetting("0",'ID2', User_ID2)
			else:
				User_ID2_ = User_ID2.replace("-", "")
				id2str_ = id2str.replace("-", "")
				if int(User_ID2_) > int(id2str_):
					printpoint = printpoint + "5"
					if addonID == 'script.htpt.install': setsetting('User_ID2', id2str)
					else: setsetting_custom1(addonID, 'User_ID2', id2str)
				elif int(User_ID2_) < int(id2str_): setSkinSetting("0",'ID2', User_ID2)
				else: printpoint = printpoint + "6"
				'''---------------------------'''
	except Exception, TypeError: print printfirst + name + space + "TypeError" + space2 + str(TypeError)
	
def mode20(name, printpoint, backupname, backuppath):
	'''------------------------------
	---INSTALL-BUTTON----------------
	------------------------------'''
	if not systemplatformwindows and not systemplatformlinux and not systemplatformlinuxraspberrypi: dialogok(addonString(97),addonString(96) + space2, "1. OpenELEC[CR]2. Windows","")
	else:
		#id40str = xbmc.getInfoLabel('Skin.HasSetting(ID40)')
		#verrorstr = xbmc.getInfoLabel('$VAR[VERROR]')
		
		
		
		if servicehtpt_Skin_Name != 'skin.htpt' and skinnamestr != 'skin.htpt':
			try:
				printpoint = printpoint + mode0(admin, name, printpoint)
				returned = dialogkeyboard(User_ID1, localize(1014) + space + "(" + addonString(17) + ")", 0, '1', 'User_ID1', 'script.htpt.install') #ID1
			except: returned = 'ok'
		else: returned = 'ok'
		
		if returned == 'skip':
			notification_common("8")
			printpoint = printpoint + "8"
		else:
			'''---------------------------'''
			
			if servicehtpt_Skin_Name != 'skin.htpt' and skinnamestr != 'skin.htpt':
				dialogok(addonString(93), addonString(94), "", "") #Backup Current System
				CreateZip(userdata_path.encode('utf-8'), backuppath + backupname2, filteron=['guisettings.xml'], filteroff=[], level=0, append=False, ZipFullPath=True, temp=False)
			
				if os.path.exists(backuppath + backupname + ".zip"):
					backupdate = getFileAttribute(1, backuppath + backupname + ".zip")
					returned = dialogyesno("Backup file present!", "There is already backup file made on" + space2 + '[CR]' + '[B]' + str(backupdate) + '[/B]' + ".[CR]" + "Would you like to continue with the previous backup?")
					if returned == 'ok': printpoint = printpoint + "2"
			else: printpoint = printpoint + "2"
			
			if not "2" in printpoint:
				notification(addonString(93), ".", "", 1000)
				
				setSkinSetting("1",'ShowDialog',"true")
				dp = xbmcgui.DialogProgress()
				dp.create("HTPT Backup", "Starting", " ")
				dp.update(0,"Starting"," ")
				'''---------------------------'''
				if not dp.iscanceled(): CreateZip(userdata_path.encode('utf-8'), backuppath + backupname, filteron=['advancedsettings.xml', 'sources.xml', 'keymaps'], filteroff=[], level=0, append=False, ZipFullPath=True, temp=True)
				dp.update(10,"Starting."," ")
				if not dp.iscanceled() and not systemplatformwindows: CreateZip(emulators_path, backuppath + backupname, filteroff=['retroarch'], append=True, ZipFullPath=True, temp=True)
				dp.update(20,"Starting.."," ")
				
				if not dp.iscanceled() and not systemplatformwindows: CreateZip(config_path, backuppath + backupname, filteron=['samba.conf', 'autostart.sh'], level=0, append=False, ZipFullPath=True, temp=True)
				dp.update(30,"Starting..."," ")
				'''ADDONS ONLY'''
				dp.update(40,"Addons"," ")
				if not dp.iscanceled(): CreateZip(addons_path.encode('utf-8'), backuppath + backupname, filteron=['repository.lambda', 'repository.xbmc-israel', 'script.favourites', 'repository.unofficial.addon.pro', 'repository.xbmcadult', 'repository.xunitytalk', 'repository.superrepo.org.helix.all', 'repository.pulsarunofficial'], filteroff=[], append=True, ZipFullPath=True, temp=True)
				'''ADDONS'''
				dp.update(60,"Addons."," ")
				if not dp.iscanceled(): CreateZip(addons_path.encode('utf-8'), backuppath + backupname, filteron=['script.openelec.rpi.config', 'plugin.video.hotVOD.video', 'plugin.video.p2p-streams', 'plugin.video.10qtv', 'plugin.video.vdubt', 'plugin.program.advanced.launcher', 'weather.yahoo', 'metadata.universal', 'metadata.common.impa.com', 'metadata.common.movieposterdb.com', 'metadata.common.ofdb.de', 'metadata.common.port.hu', 'metadata.common.rt.com', 'plugin.video.genesis', 'plugin.video.bestofyoutube_com', 'service.skin.widgets'], filteroff=[], append=True, ZipFullPath=True, temp=True)
				'''USERDATA ADDONS'''
				dp.update(80,"Addons.."," ")
				if not dp.iscanceled(): returned = CreateZip(addondata_path.encode('utf-8'), backuppath + backupname, filteron=['script.openelec.rpi.config', 'plugin.video.hotVOD.video', 'plugin.video.p2p-streams', 'plugin.video.10qtv', 'plugin.video.vdubt', 'plugin.program.advanced.launcher', 'weather.yahoo', 'metadata.universal', 'plugin.video.genesis', 'plugin.video.bestofyoutube_com', 'service.skin.widgets'], filteroff=[], append=True, ZipFullPath=True, temp=True)
				'''USERDATA ONLY ADDONS'''
				dp.update(90,"Addons..."," ")
				if not dp.iscanceled(): returned = CreateZip(addondata_path.encode('utf-8'), backuppath + backupname, filteron=['metadata.tvdb.com', 'plugin.video.israelive', 'plugin.video.youtube'], filteroff=[], append="End", ZipFullPath=True, temp=True)
				
				
				if dp.iscanceled(): printpoint = printpoint + "8"
				setSkinSetting("1",'ShowDialog',"false")
				dp.close
			
			if "8" in printpoint: dialogok('$LOCALIZE[16200]', '$LOCALIZE[114]!', "", "") #Operation was aborted, Installation failed
			else:
				if returned != 'ok' and servicehtpt_Skin_Name != 'skin.htpt' and skinnamestr != 'skin.htpt':
					returned = dialogyesno("Backup Failed", "Proceed without backup? + '[CR]' + 'You should choose no :)')")
					if returned == 'ok': printpoint = printpoint + "4"
					else: notification_common("9")
					'''---------------------------'''
				else: printpoint = printpoint + "4"
				'''---------------------------'''
					
				if "4" in printpoint:
					if not "8" in printpoint and not "9" in printpoint: printpoint = printpoint + installaddon2(admin, 'script.htpt.debug', update=False)
					if not "8" in printpoint and not "9" in printpoint: printpoint = printpoint + installaddon2(admin, 'service.htpt.fix', update=False)
					if not "8" in printpoint and not "9" in printpoint: printpoint = printpoint + installaddon2(admin, 'script.htpt.homebuttons', update=False)
					if not "8" in printpoint and not "9" in printpoint: printpoint = printpoint + installaddon2(admin, 'script.htpt.smartbuttons', update=False)
					if not "8" in printpoint and not "9" in printpoint: printpoint = printpoint + installaddon2(admin, 'script.htpt.remote', update=False)
					if not "8" in printpoint and not "9" in printpoint: printpoint = printpoint + installaddon2(admin, 'script.htpt.refresh', update=False)
					if not "8" in printpoint and not "9" in printpoint: printpoint = printpoint + installaddon2(admin, 'script.htpt.widgets', update=False)
					if not "8" in printpoint and not "9" in printpoint: printpoint = printpoint + installaddonP(admin, 'metadata.universal')
					if not "8" in printpoint and not "9" in printpoint: printpoint = printpoint + installaddon2(admin, 'metadata.common.imdb.com', update=False)
					if not "8" in printpoint and not "9" in printpoint: printpoint = printpoint + installaddon2(admin, 'skin.htpt', update=True)
					'''---------------------------'''
						
				if "5" in printpoint:
					xbmc.executebuiltin("UpdateLocalAddons")
					xbmc.sleep(2000)
					'''---------------------------'''
				
				if (not "8" in printpoint and not "9" in printpoint) or (servicehtpt_Skin_Name == 'skin.htpt' and skinnamestr != 'skin.htpt'):
					'''------------------------------
					---INSTALLATION-SUCCESSFULLY-----
					------------------------------'''
					htptversion = xbmc.getInfoLabel('System.AddonVersion(skin.htpt)')
					printpoint = printpoint + "7"
					'''---------------------------'''
					setsetting('User_ID2', datenowS)
					setsetting('Skin_Installed', "true")
					if os.path.exists(skininstalledtxt): copyfiles(skininstalledtxt, home_path) #GAL TEST THIS!
					setsetting_custom1('script.htpt.debug','ModeOn_20',"true")
					setsetting_custom1('service.htpt.fix','Fix_5',"true")
					setsetting_custom1('service.htpt.fix','Fix_6',"true")
					setsetting_custom1('service.htpt.fix','Fix_100',"true")
					setsetting_custom1('service.htpt.fix','Fix_101',"true")
					#setsetting_custom1('service.htpt','Skin_Name',"skin.htpt")
					'''---------------------------'''
					if servicehtpt_Skin_Name != 'skin.htpt' and skinnamestr != 'skin.htpt':
						xbmc.executebuiltin('ReplaceWindow(0)')
						xbmc.sleep(1000)
						dialogok(addonString(91), addonString(92) % (htptversion), "", "")
						#xbmc.sleep(1000)
						#guikeeper(admin, guicheck="", guiread="") #GAL TEST THIS
						xbmc.sleep(500)
						killall(admin, custom="1")
					#os.system('sh /storage/.kodi/addons/service.htpt/specials/scripts/copyskin.sh')
					'''---------------------------'''
					#xbmc.sleep(1000)
					#bash('pgrep kodi.bin | xargs kill -SIGSTOP && killall -9 kodi.bin && sleep 1 && pgrep kodi.bin | xargs kill -SIGCONT',"SOFT-RESTART")
					#xbmc.executebuiltin('XBMC.Reset()')
					'''---------------------------'''
				
				else:
					if "55" in printpoint: extra = addonString(85) + '[CR]' + addonString(84)
					else: extra = ""
					if not "8" in printpoint: dialogok('$LOCALIZE[113]', str257 + space + printpoint, extra, "")
			
		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		print printfirst + name + "_LV" + printpoint + space + "idstr" + space2 + idstr + space + "id40str" + space2 + id40str + space + "MAC" + space2 + macstr
		'''---------------------------'''

def mode21(name, printpoint, backupname, backupname2, backuppath):
	'''------------------------------
	---UNINSTALL-BUTTON--------------
	------------------------------'''
	
	returned = dialogyesno(addonString(11),addonString(98))
	if returned == 'ok':
		'''------------------------------
		---REMOVE------------------------
		------------------------------'''
		if not systemplatformwindows and not systemplatformlinux and not systemplatformlinuxraspberrypi: dialogok("Uninstall isn't available for your OS!","", addonString(80),"")
		else:
			if os.path.exists(backuppath + backupname + ".zip"):
				backupsize = getFileAttribute(2, backuppath + backupname + ".zip")
				try:
					if int(backupsize) > 24000: pass
					else: printpoint = printpoint + "b"
				except Exception, TypeError:
					printpoint = printpoint + "b"
			else:
				printpoint = printpoint + "b"
				
			notification("Removing",'Please Wait',"",10000)
			setSkinSetting("1",'ShowDialog',"true")
			dp = xbmcgui.DialogProgress()
			dp.create("HTPT Uninstaller", "Removing Scripts", " ")
			'''---------------------------'''
			
			if not admin: removefiles(os.path.join(config_path, 'samba.conf'))
			removefiles(os.path.join(config_path, 'autostart.sh'))
			'''---------------------------'''
			removefiles('/storage/*.log')
			#removefiles(skin_userdata_path)
			removefiles(os.path.join(config_path, 'sources.xml'))
			'''---------------------------'''
			dp.update(10,"Removing Scripts."," ")
			removefiles(os.path.join(userdata_path, 'advancedsettings.xml'))
			removefiles(os.path.join(userdata_path, 'sources.xml'))
			'''---------------------------'''
			removefiles(keymaps_path)
			'''---------------------------'''
			if not systemplatformwindows: 
				bash('mount -o remount,rw /flash','mount flash')
				removefiles('/flash/oemsplash.png')
				'''---------------------------'''
			dp.update(20,"Removing Scripts.."," ")
			removefiles(emulators_path)
			dp.update(30,"Removing Scripts..."," ")
			'''------------------------------
			---USERDATA+PACKAGE--------------
			------------------------------'''
			addonsL = []
			
			addonsL.append('plugin.video.israelive')
			addonsL.append('plugin.video.youtube')
			addonsL.append('metadata.tvdb.com')
			'''---------------------------'''
			dp.update(50,"Removing HTPT Addons"," ")
			removeaddons(addonsL,"23")
			'''---------------------------'''
			
			'''------------------------------
			---ALL---------------------------
			------------------------------'''
			addonsL = []
			
			addonsL.append('repository.xunitytalk')
			addonsL.append('repository.xbmc-israel')
			addonsL.append('repository.pulsarunofficial')
			addonsL.append('script.favourites')
			addonsL.append('repository.unofficial.addon.pro')
			addonsL.append('repository.xbmcadult')
			addonsL.append('repository.xunitytalk')
			addonsL.append('repository.superrepo.org.helix.all')
			addonsL.append('plugin.program.advanced.launcher')
			addonsL.append('plugin.video.genesis')
			addonsL.append('metadata.universal') ; addonsL.append('metadata.common.port.hu') ; addonsL.append('metadata.common.ofdb.de') ; addonsL.append('metadata.common.movieposterdb.com') ; addonsL.append('metadata.common.impa.com') ; addonsL.append('metadata.common.rt.com')
			addonsL.append('browser.chromium-browser')
			addonsL.append('plugin.video.bestofyoutube_com')
			addonsL.append('screensaver.randomtrailers')
			addonsL.append('screensaver.picture.slideshow')
			addonsL.append('script.moviequiz')
			addonsL.append('script.moviequiz')
			addonsL.append('emulator.retroarch')
			addonsL.append('service.htpt.fix')
			addonsL.append('script.openelec.rpi.config')
			addonsL.append('plugin.video.hotVOD.video')
			addonsL.append('plugin.video.p2p-streams')
			addonsL.append('plugin.video.10qtv')
			addonsL.append('plugin.video.vdubt')
			addonsL.append('repository.lambda')
			#addonsL.append('repository.htpt')
			addonsL.append('plugin.video.htpt.gopro')
			addonsL.append('plugin.video.htpt.kids')
			addonsL.append('plugin.video.htpt.music')
			'''---------------------------'''
			dp.update(60,"Removing HTPT Addons."," ")
			removeaddons(addonsL,"123")
			'''---------------------------'''
			addonsL = []
			addonsL.append('script.htpt.debug')
			addonsL.append('script.htpt.emu')
			addonsL.append('script.htpt.homebuttons')
			addonsL.append('script.htpt.smartbuttons')
			addonsL.append('script.htpt.refresh')
			addonsL.append('script.htpt.remote')
			addonsL.append('script.htpt.widgets')
			
			dp.update(70,"Removing HTPT Addons.."," ")
			removeaddons(addonsL,"123")
			'''---------------------------'''
			setsetting('User_ID', 'old')
			setSkinSetting('0', 'Skin_Name', "")
			'''---------------------------'''
			addonsL = []
			addonsL.append('skin.htpt')
			addonsL.append('service.htpt')
			
			dp.update(80,"Removing HTPT Addons..."," ")
			try: removeaddons(addonsL,"123")
			except Exception, TypeError:
				print "Uninstall htpt.service/skin - TypeError(1): " + str(TypeError)
				try: removeaddons(addonsL,"123")
				except Exception, TypeError: print "Uninstall htpt.service/skin - TypeError(2): " + str(TypeError)
				'''---------------------------'''
			from variables import *
			if systemhasaddon_htptdebug: xbmc.executebuiltin('RunScript(script.htpt.debug,,?mode=21)')
			dp.update(90,"Almost Done!","Please Wait")
			
			if os.path.exists(backuppath + backupname + ".zip"):
				notification("Using Restore point", "From Last Backup", "", 4000)
				ExtractAll(backuppath + backupname + ".zip", restorepath)
			
			if os.path.exists(backuppath + backupname2 + ".zip"):
				returned = dialogyesno(addonString(87) % ('guisettings.xml'), addonString(86))
				if returned == 'ok':
					notification("Using Restore point", "From Last Backup", "", 4000)
					printpoint = printpoint + "3"
				else: pass
			

			dp.close
			
			dialogok(addonString(83),"","","")
			
				
			
			xbmc.executebuiltin("UpdateLocalAddons")
			xbmc.executebuiltin('ReplaceWindow(0)')
			
			xbmc.sleep(1000)
			if "3" in printpoint: ExtractAll(backuppath + backupname2 + ".zip", restorepath)
			killall(admin, custom="1")
			#bash('pgrep kodi.bin | xargs kill -SIGSTOP && killall -9 kodi.bin && sleep 1 && pgrep kodi.bin | xargs kill -SIGCONT',"SOFT-RESTART")
			'''---------------------------'''
	else:
		notification_common("9")
		'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + name + "_LV" + printpoint
	'''---------------------------'''
	
def mode22(name, printpoint):
	'''------------------------------
	---SUSPEND-BUTTON----------------
	------------------------------'''
	setsetting('Skin_Suspend',"true")
	setSkinSetting("1",'Skin_Suspend',"true")
	
	xbmc.executebuiltin('ActivateWindow(AppearanceSettings)')
	xbmc.sleep(1000)
	if xbmc.getCondVisibility('System.IdleTime(1)') and xbmc.getInfoLabel('System.CurrentControl') == str166.encode('utf-8'):
		xbmc.executebuiltin('Action(Select)') ; xbmc.sleep(40) ; xbmc.executebuiltin('Action(Down)') ; xbmc.sleep(40) ; xbmc.executebuiltin('Action(Select)') ; xbmc.sleep(200) ; xbmc.executebuiltin('Action(Down)')
	dialogok('[COLOR=Yellow]'+'$LOCALIZE[78955]'+'[/COLOR]','$LOCALIZE[78954]','$LOCALIZE[78953]',"")
	'''---------------------------'''
	
def mode23(name, printpoint):
	'''------------------------------
	---ENTER-HTPT-BUTTON-------------
	------------------------------'''
	printpoint = printpoint + installaddon2(admin, 'script.htpt.smartbuttons', update=True)
	if Skin_Suspend == "true": setsetting('Skin_Suspend',"false")
	#xbmc.executebuiltin('ReloadSkin()')
	killall(admin, custom="1")
	#if not systemplatformwindows: os.system('sh /storage/.kodi/addons/service.htpt/specials/scripts/copyskin.sh')
	#xbmc.executebuiltin('RunScript(script.htpt.smartbuttons,,?mode=50)')
	#UnloadSkin()
	'''---------------------------'''

def mode24(name, printpoint):
	'''------------------------------
	---MAIN-SKIN---------------------
	------------------------------'''
	list = ['-> (Exit)', 'HTPT', 'OTHER']
	if Skin_Default != "0" and Skin_Default != "1" and Skin_Default != "2":
		list.remove(list[0])
	
	returned, value = dialogselect('$LOCALIZE[74433]',list,0)
	
	if returned == -1: printpoint = printpoint + "9"
	elif returned == 0: printpoint = printpoint + "8"
	else: printpoint = printpoint + "7"
		
	if "7" in printpoint or value == 'HTPT':
		if value != "":
			setSkinSetting('0', 'Skin_Default', value)
			setsetting_custom1('script.htpt.install','Skin_Default', value)
			notification("Your default skin is:", str(value), "", 2000)	
	
	print printfirst + name + "_LV" + printpoint + space + "list" + space2 + str(list) + space + "returned" + space2 + str(returned)
	'''---------------------------'''
	