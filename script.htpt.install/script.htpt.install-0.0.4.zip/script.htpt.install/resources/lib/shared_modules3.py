import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os,random
import json

from variables import *
#from modules import *
from shared_modules import *

'''plugins'''
def addDir(name, url, mode, iconimage, desc, num, viewtype):
	url2 = url
	if '$LOCALIZE' in name or '$ADDON' in name: name = xbmc.getInfoLabel(name)
	if '$LOCALIZE' in desc or '$ADDON' in desc: desc = xbmc.getInfoLabel(desc)
	
	try: name = name.encode('utf-8')
	except: pass
	
	try: desc = desc.encode('utf-8')
	except: pass
	
	url = str(url)
	desc = str(desc)
	
	if mode == 17: name = '[COLOR=Green]' + name + '[/COLOR]'
	elif mode == 5: name = '[COLOR=Yellow]' + name + '[/COLOR]'
	elif mode == 8: name = '[COLOR=White2]' + name + '[/COLOR]'
	
	if mode >= 10000: u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&desc="+urllib.quote_plus(desc)+"&num="+urllib.quote_plus(num)+"&viewtype="+str(viewtype)
	else: u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&desc="+urllib.quote_plus(desc)+"&num="+urllib.quote_plus(num)+"&viewtype="+str(viewtype)
	
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": desc} )
	menu = []
	#ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	if viewtype != "":
		#notification("testt","","",1000)
		#setsetting_custom1(addonID,'Current_View',viewtype)
		pass
		'''---------------------------'''
	if admin: print printfirst + "addDir" + space2 + newline + "addonID" + space2 + str(addonID) + newline + "name" + space2 + str(name) + newline + "url " + space2 + str(url) + newline + "url2" + space2 + str(url2) + newline + "mode" + space2 + str(mode) + newline + "iconimage" + space2 + str(iconimage) + newline + "desc" + space2 + str(desc) + newline + "num" + space2 + str(num)
	if addonID == 'script.htpt.install':
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok
	if mode == 4:
		'''------------------------------
		---play_video/2------------------
		------------------------------'''
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok
		'''---------------------------'''
	elif mode == 5:
		'''------------------------------
		---PlayMultiVideos-(list)--------
		------------------------------'''
		print "baa" + newline + "%5b%27shuffle%3dtrue%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2819037%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx99%5cxd7%5cx99%5cxd7%5cxa4%5cxd7%5cxaa%20%5cxd7%5cxa9%5cxd7%5cx9c%20%5cxd7%5cx93%5cxd7%5cxa5%20%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20-%20%5cxd7%5cx97%5cxd7%5cx9c%5cxd7%5cxa7%201%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2819043%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx99%5cxd7%5cx99%5cxd7%5cxa4%5cxd7%5cxaa%20%5cxd7%5cxa9%5cxd7%5cx9c%20%5cxd7%5cx93%5cxd7%5cxa5%20%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20-%20%5cxd7%5cx97%5cxd7%5cx9c%5cxd7%5cxa7%202%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2819050%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx99%5cxd7%5cx99%5cxd7%5cxa4%5cxd7%5cxaa%20%5cxd7%5cxa9%5cxd7%5cx9c%20%5cxd7%5cx93%5cxd7%5cxa5%20%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20-%20%5cxd7%5cx97%5cxd7%5cx9c%5cxd7%5cxa7%203%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2817560%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx91%5cxd7%5cxa9%5cxd7%5cx94%20%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20%5cxd7%5cxa9%5cxd7%5cx9c%5cxd7%5cx95%5cxd7%5cx9d%20%5cxd7%5cxa2%5cxd7%5cx9c%20%5cxd7%5cx99%5cxd7%5cxa9%5cxd7%5cxa8%5cxd7%5cx90%5cxd7%5cx9c%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2817583%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx91%5cxd7%5cxa9%5cxd7%5cx94%20%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20%5cxd7%5cx95%5cxd7%5cx97%5cxd7%5cx91%5cxd7%5cxa8%5cxd7%5cx99%5cxd7%5cx9d%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2817533%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx91%5cxd7%5cxa9%5cxd7%5cx94%20%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20%5cxd7%5cx91%5cxd7%5cx92%5cxd7%5cx9f%20%5cxd7%5cx94%5cxd7%5cx90%5cxd7%5cx95%5cxd7%5cxaa%5cxd7%5cx99%5cxd7%5cx95%5cxd7%5cxaa%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2820067%26mode%3d10%26name%3d%5cxd7%5cx91%5cxd7%5cx90%20%5cxd7%5cx9c%5cxd7%5cx99%20%5cxd7%5cx9e%5cxd7%5cxa1%5cxd7%5cx99%5cxd7%5cx91%5cxd7%5cx94%20%5cxd7%5cx9c%5cxd7%5cx99%26module%3dwallavod%27%5d" + newline + url
		if admin:
			#menu.append(('[COLOR=Green]' + str79525.encode('utf-8') + '[/COLOR]', "XBMC.RunPlugin(plugin://plugin.video.htpt.kids/?&mode=5&url=%s)"% (url)))
			menu.append(('[COLOR=Purple]' + str79522.encode('utf-8') + '[/COLOR]', "XBMC.Container.Update(plugin://%s/?num&iconimage=''&mode=6&name=''&url=%s)"% (addonID, url)))
			#menu.append(('[COLOR=Purple]' + str79522.encode('utf-8') + '[/COLOR]', "XBMC.Container.Update(plugin://plugin.video.htpt.kids/?&mode=5&url="+url+")"))
			#menu.append(('[COLOR=Green]' + str79525.encode('utf-8') + '[/COLOR]', "XBMC.RunPlugin(plugin://"+addonID+"/?iconimage="+iconimage+"&mode=5&name="+name+"&num="+num+"&url="+url+")"))
			#menu.append(('[COLOR=Green]' + str79525.encode('utf-8') + '[/COLOR]', "XBMC.RunPlugin(plugin://plugin.video.htpt.kids/?iconimage=http%3a%2f%2fmsc.wcdn.co.il%2fw-2-1%2fw-300%2f768225-54.jpg&mode=5&name=%d7%94%d7%9b%d7%91%d7%a9%d7%94%20%d7%a9%d7%95%d7%a9%d7%a0%d7%94&num=1&url=%5b%27shuffle%3dtrue%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2819037%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx99%5cxd7%5cx99%5cxd7%5cxa4%5cxd7%5cxaa%20%5cxd7%5cxa9%5cxd7%5cx9c%20%5cxd7%5cx93%5cxd7%5cxa5%20%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20-%20%5cxd7%5cx97%5cxd7%5cx9c%5cxd7%5cxa7%201%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2819043%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx99%5cxd7%5cx99%5cxd7%5cxa4%5cxd7%5cxaa%20%5cxd7%5cxa9%5cxd7%5cx9c%20%5cxd7%5cx93%5cxd7%5cxa5%20%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20-%20%5cxd7%5cx97%5cxd7%5cx9c%5cxd7%5cxa7%202%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2819050%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx99%5cxd7%5cx99%5cxd7%5cxa4%5cxd7%5cxaa%20%5cxd7%5cxa9%5cxd7%5cx9c%20%5cxd7%5cx93%5cxd7%5cxa5%20%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20-%20%5cxd7%5cx97%5cxd7%5cx9c%5cxd7%5cxa7%203%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2817560%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx91%5cxd7%5cxa9%5cxd7%5cx94%20%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20%5cxd7%5cxa9%5cxd7%5cx9c%5cxd7%5cx95%5cxd7%5cx9d%20%5cxd7%5cxa2%5cxd7%5cx9c%20%5cxd7%5cx99%5cxd7%5cxa9%5cxd7%5cxa8%5cxd7%5cx90%5cxd7%5cx9c%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2817583%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx91%5cxd7%5cxa9%5cxd7%5cx94%20%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20%5cxd7%5cx95%5cxd7%5cx97%5cxd7%5cx91%5cxd7%5cxa8%5cxd7%5cx99%5cxd7%5cx9d%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2817533%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx91%5cxd7%5cxa9%5cxd7%5cx94%20%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20%5cxd7%5cx91%5cxd7%5cx92%5cxd7%5cx9f%20%5cxd7%5cx94%5cxd7%5cx90%5cxd7%5cx95%5cxd7%5cxaa%5cxd7%5cx99%5cxd7%5cx95%5cxd7%5cxaa%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2820067%26mode%3d10%26name%3d%5cxd7%5cx91%5cxd7%5cx90%20%5cxd7%5cx9c%5cxd7%5cx99%20%5cxd7%5cx9e%5cxd7%5cxa1%5cxd7%5cx99%5cxd7%5cx91%5cxd7%5cx94%20%5cxd7%5cx9c%5cxd7%5cx99%26module%3dwallavod%27%5d&viewtype=50)"))
			#menu.append(('[COLOR=Green]' + str79525.encode('utf-8') + '[/COLOR]', "XBMC.RunPlugin(plugin://"+addonID+"/?&mode=5&url=%5b%27shuffle%3dtrue%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2819037%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx99%5cxd7%5cx99%5cxd7%5cxa4%5cxd7%5cxaa%20%5cxd7%5cxa9%5cxd7%5cx9c%20%5cxd7%5cx93%5cxd7%5cxa5%20%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20-%20%5cxd7%5cx97%5cxd7%5cx9c%5cxd7%5cxa7%201%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2819043%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx99%5cxd7%5cx99%5cxd7%5cxa4%5cxd7%5cxaa%20%5cxd7%5cxa9%5cxd7%5cx9c%20%5cxd7%5cx93%5cxd7%5cxa5%20%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20-%20%5cxd7%5cx97%5cxd7%5cx9c%5cxd7%5cxa7%202%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2819050%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx99%5cxd7%5cx99%5cxd7%5cxa4%5cxd7%5cxaa%20%5cxd7%5cxa9%5cxd7%5cx9c%20%5cxd7%5cx93%5cxd7%5cxa5%20%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20-%20%5cxd7%5cx97%5cxd7%5cx9c%5cxd7%5cxa7%203%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2817560%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx91%5cxd7%5cxa9%5cxd7%5cx94%20%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20%5cxd7%5cxa9%5cxd7%5cx9c%5cxd7%5cx95%5cxd7%5cx9d%20%5cxd7%5cxa2%5cxd7%5cx9c%20%5cxd7%5cx99%5cxd7%5cxa9%5cxd7%5cxa8%5cxd7%5cx90%5cxd7%5cx9c%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2817583%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx91%5cxd7%5cxa9%5cxd7%5cx94%20%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20%5cxd7%5cx95%5cxd7%5cx97%5cxd7%5cx91%5cxd7%5cxa8%5cxd7%5cx99%5cxd7%5cx9d%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2817533%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx91%5cxd7%5cxa9%5cxd7%5cx94%20%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20%5cxd7%5cx91%5cxd7%5cx92%5cxd7%5cx9f%20%5cxd7%5cx94%5cxd7%5cx90%5cxd7%5cx95%5cxd7%5cxaa%5cxd7%5cx99%5cxd7%5cx95%5cxd7%5cxaa%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2820067%26mode%3d10%26name%3d%5cxd7%5cx91%5cxd7%5cx90%20%5cxd7%5cx9c%5cxd7%5cx99%20%5cxd7%5cx9e%5cxd7%5cxa1%5cxd7%5cx99%5cxd7%5cx91%5cxd7%5cx94%20%5cxd7%5cx9c%5cxd7%5cx99%26module%3dwallavod%27%5d)"))
			liz.addContextMenuItems(items=menu, replaceItems=True)
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok
		'''---------------------------'''
	elif mode == 6:
		'''------------------------------
		---ListMultiVideos-(play)--------
		------------------------------'''
		print "baa" + newline + "%5b%27shuffle%3dtrue%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2819037%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx99%5cxd7%5cx99%5cxd7%5cxa4%5cxd7%5cxaa%20%5cxd7%5cxa9%5cxd7%5cx9c%20%5cxd7%5cx93%5cxd7%5cxa5%20%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20-%20%5cxd7%5cx97%5cxd7%5cx9c%5cxd7%5cxa7%201%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2819043%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx99%5cxd7%5cx99%5cxd7%5cxa4%5cxd7%5cxaa%20%5cxd7%5cxa9%5cxd7%5cx9c%20%5cxd7%5cx93%5cxd7%5cxa5%20%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20-%20%5cxd7%5cx97%5cxd7%5cx9c%5cxd7%5cxa7%202%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2819050%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx99%5cxd7%5cx99%5cxd7%5cxa4%5cxd7%5cxaa%20%5cxd7%5cxa9%5cxd7%5cx9c%20%5cxd7%5cx93%5cxd7%5cxa5%20%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20-%20%5cxd7%5cx97%5cxd7%5cx9c%5cxd7%5cxa7%203%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2817560%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx91%5cxd7%5cxa9%5cxd7%5cx94%20%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20%5cxd7%5cxa9%5cxd7%5cx9c%5cxd7%5cx95%5cxd7%5cx9d%20%5cxd7%5cxa2%5cxd7%5cx9c%20%5cxd7%5cx99%5cxd7%5cxa9%5cxd7%5cxa8%5cxd7%5cx90%5cxd7%5cx9c%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2817583%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx91%5cxd7%5cxa9%5cxd7%5cx94%20%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20%5cxd7%5cx95%5cxd7%5cx97%5cxd7%5cx91%5cxd7%5cxa8%5cxd7%5cx99%5cxd7%5cx9d%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2817533%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx91%5cxd7%5cxa9%5cxd7%5cx94%20%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20%5cxd7%5cx91%5cxd7%5cx92%5cxd7%5cx9f%20%5cxd7%5cx94%5cxd7%5cx90%5cxd7%5cx95%5cxd7%5cxaa%5cxd7%5cx99%5cxd7%5cx95%5cxd7%5cxaa%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2820067%26mode%3d10%26name%3d%5cxd7%5cx91%5cxd7%5cx90%20%5cxd7%5cx9c%5cxd7%5cx99%20%5cxd7%5cx9e%5cxd7%5cxa1%5cxd7%5cx99%5cxd7%5cx91%5cxd7%5cx94%20%5cxd7%5cx9c%5cxd7%5cx99%26module%3dwallavod%27%5d" + newline + url
		if admin:
			menu.append(('[COLOR=Green]' + str79525.encode('utf-8') + '[/COLOR]', "XBMC.RunPlugin(plugin://plugin.video.htpt.kids/?&mode=5&url=%s)"% (url2)))
			#menu.append(('[COLOR=Green]' + str79525.encode('utf-8') + '[/COLOR]', "XBMC.RunPlugin(plugin://"+addonID+"/?iconimage="+iconimage+"&mode=5&name="+name+"&num="+num+"&url="+url+")"))
			#menu.append(('[COLOR=Green]' + str79525.encode('utf-8') + '[/COLOR]', "XBMC.RunPlugin(plugin://plugin.video.htpt.kids/?iconimage=http%3a%2f%2fmsc.wcdn.co.il%2fw-2-1%2fw-300%2f768225-54.jpg&mode=5&name=%d7%94%d7%9b%d7%91%d7%a9%d7%94%20%d7%a9%d7%95%d7%a9%d7%a0%d7%94&num=1&url=%5b%27shuffle%3dtrue%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2819037%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx99%5cxd7%5cx99%5cxd7%5cxa4%5cxd7%5cxaa%20%5cxd7%5cxa9%5cxd7%5cx9c%20%5cxd7%5cx93%5cxd7%5cxa5%20%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20-%20%5cxd7%5cx97%5cxd7%5cx9c%5cxd7%5cxa7%201%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2819043%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx99%5cxd7%5cx99%5cxd7%5cxa4%5cxd7%5cxaa%20%5cxd7%5cxa9%5cxd7%5cx9c%20%5cxd7%5cx93%5cxd7%5cxa5%20%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20-%20%5cxd7%5cx97%5cxd7%5cx9c%5cxd7%5cxa7%202%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2819050%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx99%5cxd7%5cx99%5cxd7%5cxa4%5cxd7%5cxaa%20%5cxd7%5cxa9%5cxd7%5cx9c%20%5cxd7%5cx93%5cxd7%5cxa5%20%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20-%20%5cxd7%5cx97%5cxd7%5cx9c%5cxd7%5cxa7%203%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2817560%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx91%5cxd7%5cxa9%5cxd7%5cx94%20%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20%5cxd7%5cxa9%5cxd7%5cx9c%5cxd7%5cx95%5cxd7%5cx9d%20%5cxd7%5cxa2%5cxd7%5cx9c%20%5cxd7%5cx99%5cxd7%5cxa9%5cxd7%5cxa8%5cxd7%5cx90%5cxd7%5cx9c%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2817583%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx91%5cxd7%5cxa9%5cxd7%5cx94%20%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20%5cxd7%5cx95%5cxd7%5cx97%5cxd7%5cx91%5cxd7%5cxa8%5cxd7%5cx99%5cxd7%5cx9d%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2817533%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx91%5cxd7%5cxa9%5cxd7%5cx94%20%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20%5cxd7%5cx91%5cxd7%5cx92%5cxd7%5cx9f%20%5cxd7%5cx94%5cxd7%5cx90%5cxd7%5cx95%5cxd7%5cxaa%5cxd7%5cx99%5cxd7%5cx95%5cxd7%5cxaa%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2820067%26mode%3d10%26name%3d%5cxd7%5cx91%5cxd7%5cx90%20%5cxd7%5cx9c%5cxd7%5cx99%20%5cxd7%5cx9e%5cxd7%5cxa1%5cxd7%5cx99%5cxd7%5cx91%5cxd7%5cx94%20%5cxd7%5cx9c%5cxd7%5cx99%26module%3dwallavod%27%5d&viewtype=50)"))
			#menu.append(('[COLOR=Green]' + str79525.encode('utf-8') + '[/COLOR]', "XBMC.RunPlugin(plugin://"+addonID+"/?&mode=5&url=%5b%27shuffle%3dtrue%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2819037%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx99%5cxd7%5cx99%5cxd7%5cxa4%5cxd7%5cxaa%20%5cxd7%5cxa9%5cxd7%5cx9c%20%5cxd7%5cx93%5cxd7%5cxa5%20%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20-%20%5cxd7%5cx97%5cxd7%5cx9c%5cxd7%5cxa7%201%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2819043%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx99%5cxd7%5cx99%5cxd7%5cxa4%5cxd7%5cxaa%20%5cxd7%5cxa9%5cxd7%5cx9c%20%5cxd7%5cx93%5cxd7%5cxa5%20%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20-%20%5cxd7%5cx97%5cxd7%5cx9c%5cxd7%5cxa7%202%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2819050%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx99%5cxd7%5cx99%5cxd7%5cxa4%5cxd7%5cxaa%20%5cxd7%5cxa9%5cxd7%5cx9c%20%5cxd7%5cx93%5cxd7%5cxa5%20%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20-%20%5cxd7%5cx97%5cxd7%5cx9c%5cxd7%5cxa7%203%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2817560%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx91%5cxd7%5cxa9%5cxd7%5cx94%20%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20%5cxd7%5cxa9%5cxd7%5cx9c%5cxd7%5cx95%5cxd7%5cx9d%20%5cxd7%5cxa2%5cxd7%5cx9c%20%5cxd7%5cx99%5cxd7%5cxa9%5cxd7%5cxa8%5cxd7%5cx90%5cxd7%5cx9c%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2817583%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx91%5cxd7%5cxa9%5cxd7%5cx94%20%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20%5cxd7%5cx95%5cxd7%5cx97%5cxd7%5cx91%5cxd7%5cxa8%5cxd7%5cx99%5cxd7%5cx9d%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2817533%26mode%3d10%26name%3d%5cxd7%5cx94%5cxd7%5cx9b%5cxd7%5cx91%5cxd7%5cxa9%5cxd7%5cx94%20%5cxd7%5cxa9%5cxd7%5cx95%5cxd7%5cxa9%5cxd7%5cxa0%5cxd7%5cx94%20%5cxd7%5cx91%5cxd7%5cx92%5cxd7%5cx9f%20%5cxd7%5cx94%5cxd7%5cx90%5cxd7%5cx95%5cxd7%5cxaa%5cxd7%5cx99%5cxd7%5cx95%5cxd7%5cxaa%26module%3dwallavod%27%2c%20%27%26custom%3dplugin%3a%2f%2fplugin.video.wallaNew.video%2f%3furl%3ditem_id%253D2820067%26mode%3d10%26name%3d%5cxd7%5cx91%5cxd7%5cx90%20%5cxd7%5cx9c%5cxd7%5cx99%20%5cxd7%5cx9e%5cxd7%5cxa1%5cxd7%5cx99%5cxd7%5cx91%5cxd7%5cx94%20%5cxd7%5cx9c%5cxd7%5cx99%26module%3dwallavod%27%5d)"))
			liz.addContextMenuItems(items=menu, replaceItems=True)
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		return ok
		'''---------------------------'''
	elif mode == 12:
		'''------------------------------
		---View-Playlist-----------------
		------------------------------'''
		#url=urllib.unquote(url)
		#menu.append(('[COLOR=Purple]' + str79522.encode('utf-8') + '[/COLOR]', "XBMC.Container.Update(plugin://plugin.video.htpt.kids/?num&iconimage=''&mode=13&name=''&url=%s)"% (url)))
		menu.append(('[COLOR=Purple]' + str79522.encode('utf-8') + '[/COLOR]', "XBMC.Container.Update(plugin://%s/?num&iconimage=''&mode=13&name=''&url=%s)"% (addonID, url)))
		liz.addContextMenuItems(items=menu, replaceItems=True)
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok
		'''---------------------------'''
	elif mode == 9:
		'''------------------------------
		---TV-MODE-----------------------
		------------------------------'''
		menu.append(('[COLOR=Green]' + str79525.encode('utf-8') + '[/COLOR]', "XBMC.RunPlugin(plugin://%s/?num&iconimage=''&mode=15&name=''&url=%s)"% (addonID, url)))
		liz.addContextMenuItems(items=menu, replaceItems=True)
		#ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok
		'''---------------------------'''
	elif mode == 8:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
		return ok
		'''---------------------------'''
	elif mode == 11 or mode == 15:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok
		'''---------------------------'''
	elif mode == 13:
		menu.append(('[COLOR=Yellow]' + str79520.encode('utf-8') + '[/COLOR]', "XBMC.RunPlugin(plugin://%s/?num&iconimage=''&mode=12&name=''&url=%s)"% (addonID, url)))
		liz.addContextMenuItems(items=menu, replaceItems=True)
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok
		'''---------------------------'''
	elif mode == 17:
		'''------------------------------
		---TV-MODE-2---------------------
		------------------------------'''
		if not admin: liz.addContextMenuItems(items=menu, replaceItems=True)
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		return ok
		'''---------------------------'''
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok
	'''---------------------------'''

def addVideoLink(name, url, mode, iconimage='DefaultFolder.png', summary = ''):
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + name
	#u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode="+ str(mode) #SPOTIFY/BESTOFYOUTUBE
	liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote(name), "Plot": urllib.unquote(summary)})    
	liz.setProperty('IsPlayable', 'true')
	ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
	if admin: print printfirst + "addVideoLink" + space + "ok" + space2 + str(ok)
	'''---------------------------'''
	return ok
		
def addLink(name,url,iconimage,desc,viewtype):
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": desc})
	liz.setProperty("IsPlayable","true")
	
	if "plugin://plugin.video.youtube/playlist/" in url: ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)
	else: ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
	
	if admin: print printfirst + "addLink" + space + "ok" + space2 + str(ok) + space + "name" + space2 + str(name) + space + "url" + space2 + str(url)
	'''---------------------------'''
	return ok
	
def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
				params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
					param[splitparams[0]]=splitparams[1]
							
	return param

def ListLive(url):
	#addDir('[COLOR=Yellow]' + str79520.encode('utf-8') + '[/COLOR]',url,12,addonMediaPath + "190.png",str79526.encode('utf-8'),'1',"") #Quick-Play
	link = OPEN_URL(url)
	link=unescape(link)
	print printfirst + "link" + space2 + link
	matches1=re.compile('pe=(.*?)#',re.I+re.M+re.U+re.S).findall(link)
	#print str(matches1[0]) + '\n'
	for match in matches1 :
		#print "match=" + str(match)
		match=match+'#'
		if match.find('playlist') != 0 :
			'''------------------------------
			---url---------------------------
			------------------------------'''
			regex='name=(.*?)URL=(.*?)#'
			matches=re.compile(regex,re.I+re.M+re.U+re.S).findall(match)
			#print str(matches)
			for name,url in matches:
				thumb=''
				i=name.find('thumb')
				i2=name.find('description')
				if i>0:
					thumb=name[i+6:]
					name=name[0:i]
					description = name[i2+11:]
					print printfirst + "name" + space2 + name + space + "thumb" + space2 + thumb + space + "description" + space2 + description
		#print url
				addLink('[COLOR yellow]'+ name+'[/COLOR]',url,thumb,description,"")  
			
		else:
			'''------------------------------
			---.plx--------------------------
			------------------------------'''
			regex='name=(.*?)URL=(.*?).plx'
			matches=re.compile(regex,re.I+re.M+re.U+re.S).findall(match)
			for name,url in matches:
				thumb=''
				i=name.find('thumb')
				i2=name.find('description')
				if i>0:
					thumb=name[i+6:]
					name=name[0:i]
					description = name[i2+11:]
				url=url+'.plx'
				if name.find('Radio') < 0 :
					addDir('[COLOR blue]'+name+'[/COLOR]',url,7,thumb,description,'1',"")
					
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "ListLive" + space2 + "matches1" + space2 + str(matches1) + space
	'''---------------------------'''
	
def ListPlaylist(playlistid, page):
	try:
		pageN = int(page)
		if pageN < 1: pageN = 1
		'''---------------------------'''
	except:
		pageN = 1
		'''---------------------------'''
	pageS = str(page)
	'''---------------------------'''
	pagesizeN = 40
	pagesizeS = str(pagesizeN)
	'''---------------------------'''
	if pageN <= 1: indexN = 1
	else: indexN = pageN * pagesizeN - pagesizeN
	indexS = str(indexN)
	'''---------------------------'''
	url='https://gdata.youtube.com/feeds/api/playlists/' + playlistid + '?alt=json&max-results=' + pagesizeS + '&start-index=' + indexS
	murl='http://gdata.youtube.com/feeds/api/playlists/' + playlistid + '?&max-results=' + pagesizeS + '&start-index='+indexS
	#print "test this" + space2 + "playlistid" + space2 + str(playlistid) + space + "url" + space2 + url + space + "page" + space2 + str(page)
	link = OPEN_URL(url)
	prms=json.loads(link)
	
	'''---------------------------'''
	#addDir('[COLOR=Yellow]' + str79520.encode('utf-8') + '[/COLOR]',url,11,"special://skin/media/DefaultPlaylist.png",str79526.encode('utf-8'),'1',"") #Quick-Play
	addDir('[COLOR=Yellow]' + str79520.encode('utf-8') + '[/COLOR]',murl,11,"special://skin/media/DefaultPlaylist.png",str79526.encode('utf-8'),'1',"") #Quick-Play
	'''---------------------------'''
	validS = "" #URLS
	duplicatesN = 0 #DUPLICATES
	invalidN = 0
	invalidS = "" #DELETES/PRIVATE
	'''---------------------------'''
	exceptN = 0
	numOfItems=int(prms['feed'][u'openSearch$totalResults'][u'$t']) #if bigger than pagesize needs to add more result
	totalpagesN = (numOfItems / pagesizeN) + 1
	'''---------------------------'''

	i = 0
	while i < pagesizeN and not xbmc.abortRequested: #h<numOfItems
		
		#print "i" + space2 + str(i) + space + "duplicatesN" + space2 + str(duplicatesN)
		try:
			urlPlaylist= str(prms['feed'][u'entry'][i][ u'media$group'][u'media$player'][0][u'url'])
			match=re.compile('www.youtube.com/watch\?v\=(.*?)\&f').findall(urlPlaylist)
			finalurl="plugin://plugin.video.youtube/play/?video_id="+match[0]+"&hd=1"
			title= str(prms['feed'][u'entry'][i][ u'media$group'][u'media$title'][u'$t'].encode('utf-8')).decode('utf-8')
			thumb =str(prms['feed'][u'entry'][i][ u'media$group'][u'media$thumbnail'][2][u'url'])
			desc = str(prms['feed'][u'entry'][i][ u'media$group'][u'media$description'][u'$t'].encode('utf-8')).decode('utf-8')
			if not finalurl in validS and not "Deleted video" in title and not "Private video" in title:
				addLink(title,finalurl,thumb,desc,"")
				validS = validS + space + finalurl
				'''---------------------------'''
			else:
				if "Deleted video" in title or "Private video" in title:
					invalidN = invalidN + 1
					invalidS = PlayListGain3 + space + finalurl
				elif finalurl in validS:
					duplicatesN = duplicatesN + 1
					#if admin: print "finalurl_Duplicate" + space2 + finalurl
					'''---------------------------'''
		except:
			exceptN = exceptN + 1
			'''---------------------------'''
		i = i + 1
	numOfItems2 = numOfItems - invalidN - duplicatesN - exceptN
	totalpagesN = (numOfItems2 / pagesizeN) + 1

	nextpage = pageN + 1
	nextpageS = str(nextpage)
	
	#url='https://gdata.youtube.com/feeds/api/playlists/'+playlistid+'?alt=json&max-results=40&start-index=2'
	#addDir('[COLOR=Yellow]' + str79521.encode('utf-8') + '[/COLOR]',playlistid,9,"special://skin/media/icons/se.png",str79528.encode('utf-8'),'25',"") #More Results
	#if totalpagesN > pageN: addDir('[COLOR=Yellow]' + str79521.encode('utf-8') + '[/COLOR]','plugin://plugin.video.youtube/playlist/'+playlistid+'/',13,"special://skin/media/DefaultPlaylist.png",str79528.encode('utf-8'),nextpageS,"") #More Results
	if totalpagesN > pageN: addDir('[COLOR=Yellow]' + str33078.encode('utf-8') + '[/COLOR]',playlistid,13,"special://skin/media/DefaultVideo2.png",str79528.encode('utf-8'),nextpageS,"") #Next Page
	
	setsetting_custom1(addonID,'Current_View','50')
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "ListPlaylist" + space + "i" + space2 + str(i) + space + "numOfItems" + space2 + str(numOfItems) + space + "numOfItems2" + space2 + str(numOfItems2) + space + "exceptN" + space2 + str(exceptN) + space + "invalidN" + space2 + str(invalidN) + space + "duplicatesN" + space2 + str(duplicatesN)
	if admin: print printfirst + "ListPlaylist" + space + "playlistid" + space2 + playlistid + space + "page" + space2 + pageS + " / " + str(totalpagesN) + space + "pagesize" + space2 + str(pagesizeN)
	if admin and validS != "": print printfirst + "ListPlaylist" + space + "validS" + space2 + str(validS)
	if admin and invalidS != "": print printfirst + "ListPlaylist" + space + "invalidS" + space2 + str(invalidS)
	'''---------------------------'''

def ListPlaylist2(playlistid, page, viewtype):
	default = 'plugin://plugin.video.youtube/'
	update_view('plugin://plugin.video.youtube/playlist/' + playlistid + '/', viewtype)
	'''---------------------------'''
	
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    '''---------------------------'''
    return link

def play_video(url):
	#xbmc.executebuiltin('PlayMedia(plugin://plugin.video.youtube/play/?video_id='+ url +')')
	#match=re.compile("http\://www.youtube.com/watch\?v\=([^\&]+)\&.+?<media\:descriptio[^>]+>([^<]+)</media\:description>.+?<media\:thumbnail url='([^']+)'.+?<media:title type='plain'>(.+?)/media:title>").findall(link)
	url='https://gdata.youtube.com/feeds/api/videos/'+ url +''
	#url='https://gdata.youtube.com/feeds/api/videos/'+ url +'' + '?alt=json'
	#url='plugin://plugin.video.youtube/play/?video_id='+ url +''
	link = OPEN_URL(url)
	if admin: print printfirst + "play_video" + space + "link" + space2 + link
	if admin: print printfirst + "play_video" + space + "url" + space2 + url
	prms=json.loads(link)
	
	match=re.compile('www.youtube.com/watch\?v\=(.*?)\&f').url
	finalurl="plugin://plugin.video.youtube/play/?video_id="+match[0]+"&hd=1"
	title= str(prms['feed'][u'entry'][i][ u'media$group'][u'media$title'][u'$t'].encode('utf-8')).decode('utf-8')
	thumb =str(prms['feed'][u'entry'][i][ u'media$group'][u'media$thumbnail'][2][u'url'])
	description = str(prms['feed'][u'entry'][i][ u'media$group'][u'media$description'][u'$t'].encode('utf-8')).decode('utf-8')
	addLink(title,finalurl,thumb,description,"")
	#xbmc.Player(xbmc.PLAYER_CORE_MPLAYER).play(pl)

def play_video2(url):
	
	if 'plugin.video.wallaNew.video' in url: xbmc.executebuiltin('PlayMedia('+ url +')')
	else:
		xbmc.executebuiltin('PlayMedia(plugin://plugin.video.youtube/play/?video_id='+ url +')')
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "play_video2" + space + "url" + space2 + str(url)
	'''---------------------------'''
	
def MultiVideos(mode, name, url, iconimage, desc, num, viewtype):
	printpoint = "" ; i = 0 ; i2 = 0 ; extra = "" ; desc = str(desc)
	pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
	pl.clear()
	playlist = []
	
	url2 = url.replace("['","")
	url2 = url2.replace("']","")
	url2 = url2.replace("'","")
	url2 = url2.replace("' ","'")
	url2 = url2.replace("'',","")
	url2 = url2.replace(" &custom","&custom")
	url2 = url2.replace(" &wallaNew","&wallaNew")
	url2 = url2.replace(" &sdarot","&sdarot")
	url2 = url2.replace(" &seretil","&seretil")
	url2 = url2.replace(" &hotVOD","&hotVOD")
	
	url2 = url2.replace(" &youtube_ch","&youtube_ch")
	url2 = url2.replace(" &youtube_pl","&youtube_pl")
	url2 = url2.replace(" &youtube_id","&youtube_id")
	#url2 = url2.replace(",","")
	
	url2a = url2
	url2 = url2.split(',')
	if General_TVModeShuffle == "true" and mode == 5:
		printpoint = printpoint + "0"
		random.shuffle(url2)
		
	if admin: print "url_first_check" + space2 + newline + "url " + space2 + str(url) + newline + "url2a" + space2 + str(url2a) + newline + "url2" + space2 + str(url2)

	returned = get_types(url)
	for x in url2:
		x = str(x) ; finalurl = ""
		x = x.replace("[","")
		x = x.replace(",","")
		x = x.replace("'","")
		x = x.replace("]","")
		if x not in playlist and x != "":
			i += 1
			if mode == 5:
				if "&custom=" in x:
					x = x.replace("&custom=","")
					finalurl=x
					'''---------------------------'''
				elif "&wallaNew=" in x:
					x = x.replace("&wallaNew=","")
					if "item_id" in x: finalurl="plugin://plugin.video.wallaNew.video/?url="+x+"&mode=10&module=wallavod"
					'''---------------------------'''
				elif "&sdarot=" in x:
					x = x.replace("&sdarot=","")
					#finalurl="plugin://plugin.video.sdarot.tv/?mode=4&"+x
					'''---------------------------'''
				elif "&seretil=" in x:
					x = x.replace("&seretil=","")
					#finalurl="plugin://plugin.video.sdarot.tv/?mode=4&"+x
					'''---------------------------'''
				elif "&hotVOD=" in x:
					x = x.replace("&hotVOD=","")
					if "FCmmAppVideoApi_AjaxItems" in x:
						finalurl="plugin://plugin.video.hotVOD.video/?url="+x+"&mode=4"
						'''---------------------------'''
				elif "&youtube_ch=" in x:
					#i2 += 1
					x = x.replace("&youtube_ch=","")
					#finalurl="plugin://plugin.video.youtube/play/?playlist_id='+x+'"
					'''---------------------------'''
				elif "&youtube_pl=" in x:
					#i2 += 1
					x = x.replace("&youtube_pl=","")
					#finalurl="plugin://plugin.video.youtube/play/?playlist_id='+x+'"
					'''---------------------------'''
				elif "&youtube_id=" in x:
					x = x.replace("&youtube_id=","")
					finalurl="plugin://plugin.video.youtube/play/?video_id="+x+"&hd=1"
					'''---------------------------'''
					
				if admin: extra = extra + newline + str(i) + space2 + finalurl
				'''---------------------------'''
				#title= str(prms['feed'][u'entry'][i][ u'media$group'][u'media$title'][u'$t'].encode('utf-8')).decode('utf-8')
				#thumb =str(prms['feed'][u'entry'][i][ u'media$group'][u'media$thumbnail'][2][u'url'])
				#description = str(prms['feed'][u'entry'][i][ u'media$group'][u'media$description'][u'$t'].encode('utf-8')).decode('utf-8')
				if finalurl != "":
					pl.add(finalurl)
					playlist.append(finalurl)
					if not "3" in printpoint:
						printpoint = printpoint + "3"
						xbmc.Player(xbmc.PLAYER_CORE_MPLAYER).play(pl)
						'''---------------------------'''
						
			elif mode == 6:
				if "/playlists" in x:
					addDir(name + space + str(i), x, 9, iconimage, addonString(192).encode('utf-8'), num, viewtype)
					'''---------------------------'''
					
				elif "&youtube_ch=" in x:
					x = x.replace("&youtube_ch=","")
					addDir(name + space + str(i), x, 9, iconimage, addonString(192).encode('utf-8'), num, viewtype)
					'''---------------------------'''
				elif "&youtube_pl=" in x:
					i2 += 1
					x = x.replace("&youtube_pl=","")
					addDir(name + space + str(i), x, 13, iconimage, addonString(192).encode('utf-8'), num, viewtype)
					'''---------------------------'''
				elif "&youtube_id=" in x:
					x = x.replace("&youtube_id=","")
					addDir(name + space + str(i), x, 4, iconimage, desc, num, viewtype)
					'''---------------------------'''
					
				else:
					if "&wallaNew=" in x:
						x = x.replace("&wallaNew=","")
						if "item_id" in x: z = '10'
						elif "seriesId" in x: z = '5'
						elif "seasonId" in x: z = '3'
						elif "genreId" in x: z = '2'
						else: z = '10'
						addDir(name + space + str(i), "plugin://plugin.video.wallaNew.video/?url="+x+"&mode="+z+"&module=wallavod", 8, iconimage, desc, num, viewtype)
						#addLink(name + space + str(i), "plugin://plugin.video.wallaNew.video/?url="+x+"&mode="+z+"&module=wallavod", iconimage, desc, viewtype)
						'''---------------------------'''
					elif "&sdarot=" in x:
						x = x.replace("&sdarot=","")
						if "episode_id=" in url: z = '4'
						elif "season_id" in url: z = '5'
						else: z = '3'
						addDir(name + space + str(i), "plugin://plugin.video.sdarot.tv/?mode="+z+"&series_name=''&image="+iconimage+"&name="+name+"&"+x, 8, iconimage, desc, num, viewtype)
						'''---------------------------'''
					elif "&seretil=" in x:
						x = x.replace("&seretil=","")
						if "?mode=211&url=http%3a%2f%2fseretil.me" in x: name2 = '[COLOR=Red]' + name + space + str(i) + '[/COLOR]'
						else: name2 = name + space + str(i)
						addDir(name2, "plugin://plugin.video.seretil/"+x, 8, iconimage, desc, num, viewtype)
						'''---------------------------'''
					elif "&hotVOD=" in x:
						x = x.replace("&hotVOD=","")
						if "TopSeriesPlayer" in x: z = '3&module=%2fCmn%2fApp%2fVideo%2fCmmAppVideoApi_AjaxItems%2f0%2c13776%2c'
						elif "FCmmAppVideoApi_AjaxItems" in x: z = '4'
						else: z = '3&module=%2fCmn%2fApp%2fVideo%2fCmmAppVideoApi_AjaxItems%2f0%2c13776%2c'
						addDir(name + space + str(i), "plugin://plugin.video.hotVOD.video/?mode="+z+"&url="+x, 8, iconimage, desc, num, viewtype)
						'''---------------------------'''	
						
					elif "&custom=" in x:
						x = x.replace("&custom=","")
						addLink(name + space + str(i), x, iconimage, desc, viewtype)
						'''---------------------------'''
					else: addLink(name + space + str(i), x, iconimage, desc, viewtype)
			
	if mode == 5 and playlist == []:
		notification('$LOCALIZE[75063]','$LOCALIZE[75064]',"",2000)
		#xbmc.executebuiltin('RunScript('+addonID+'/?mode=6&name='+name+'&url='+url+'&iconimage='+str(iconimage)+'&desc='+desc+'&num='+str(num)+'&viewtype='+str(viewtype)+')')
		#MultiVideos(6, name, url, iconimage, desc, num, viewtype)
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "MultiVideos_LV" + printpoint + space + "mode" + space2 + str(mode) + space + "i" + space2 + str(i) + space + "returned(type)" + space2 + returned + space + "url" + space2 + str(url) + space + "url2" + space2 + str(url2) + space + "pl" + space2 + str(pl) + space + "playlist" + space2 + str(playlist) + extra
	'''---------------------------'''
	
def PlayPlayList(playlistid):
	printpoint = ""
	url='https://gdata.youtube.com/feeds/api/playlists/'+playlistid+'?alt=json&max-results=40'
	link = OPEN_URL(url)
	prms=json.loads(link)

	playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
	playlist.clear()
	playlist1 = []
	numOfItems=int(prms['feed'][u'openSearch$totalResults'][u'$t']) #if bigger than 40 needs  to add more result
	
	j=1
	h=1
	pages = (numOfItems //50)+1
	while  j<= pages:
		link=OPEN_URL(url)
		prms=json.loads(link)
		i=0
		while i< 50  and  h<numOfItems :
			try:
				urlPlaylist= str(prms['feed'][u'entry'][i][ u'media$group'][u'media$player'][0][u'url'])
				match=re.compile('www.youtube.com/watch\?v\=(.*?)\&f').findall(urlPlaylist)
				#finalurl="plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid="+match[0]+"&hd=1"
				finalurl="plugin://plugin.video.youtube/play/?video_id="+match[0]+"&hd=1"
				title= str(prms['feed'][u'entry'][i][ u'media$group'][u'media$title'][u'$t'].encode('utf-8')).decode('utf-8')
				thumb =str(prms['feed'][u'entry'][i][ u'media$group'][u'media$thumbnail'][2][u'url'])
				liz = xbmcgui.ListItem(title, iconImage="DefaultVideo.png", thumbnailImage=thumb)
				liz.setInfo( type="Video", infoLabels={ "Title": title} )
				liz.setProperty("IsPlayable","true")
				playlist1.append((finalurl ,liz))
			except:
				pass
			if playlist1 != [] and not "3" in printpoint:
				for blob ,liz in playlist1:
					try:
						if blob:
							playlist.add(blob,liz)
							xbmc.Player(xbmc.PLAYER_CORE_MPLAYER).play(playlist)
							printpoint = printpoint + "3"
							xbmc.sleep(2000)
					except:
						printpoint = printpoint + "4"
				
				
			i=i+1
			h=h+1

		j=j+1
		url='https://gdata.youtube.com/feeds/api/playlists/'+playlistid+'?alt=json&max-results=50&start-index='+str (j*50-49)
	random.shuffle(playlist1)
	for blob ,liz in playlist1:
		try:
			if blob:
				playlist.add(blob,liz)
		except:
			pass
	notification_common("15")
	playlist.shuffle()
	
	#xbmc.Player(xbmc.PLAYER_CORE_MPLAYER).play(playlist)

#https://gdata.youtube.com/feeds/api/users/polosoft/playlists (gets playlist fro, user) https://gdata.youtube.com/feeds/api/users/polosoft/playlists?alt=json
#https://gdata.youtube.com/feeds/api/playlists/PLN0EJVTzRDL_53Jz8bhZl4m3UtkY2btbV?max-results=50?alt=json  (gets items in playlist)
#https://gdata.youtube.com/feeds/api/playlists/PLN0EJVTzRDL_53Jz8bhZl4m3UtkY2btbV?max-results=50&alt=json
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "PlayPlayList_LV" + printpoint + space + "playlistid" + space2 + playlistid + space + "numOfItems" + space2 + str(numOfItems) + space + "playlist1" + space2 + str(playlist1)
	'''---------------------------'''

def PlayPlayList2(playlistid):
	default = 'plugin://plugin.video.youtube/'
	default2 = 'play/?playlist_id='

	xbmc.executebuiltin('PlayMedia(plugin://plugin.video.youtube/play/?playlist_id='+ playlistid +')')
	#addLink("",'plugin://plugin.video.youtube/play/?playlist_id=' + playlistid,"","","")
	#xbmc.executebuiltin('RunPlugin(plugin://plugin.video.youtube/play/?playlist_id='+ playlistid +'&order=default)')
	#plugin://plugin.video.youtube/playlist/PL4RuBaWCIgHrFNTIP37qBS254y7-2r9e4/
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "PlayPlayList2" + space + "playlistid" + space2 + str(playlistid)
	'''---------------------------'''

def PlayPlayList3(playlistid):
	default = 'plugin://plugin.video.youtube/'
	default2 = 'play/?playlist_id='
	update_view(default + default2 + playlistid + '/', viewtype)
	
def PlaylistsFromUser(user):
	url='https://gdata.youtube.com/feeds/api/users/'+user+ '/playlists?alt=json&max-results=50'
	link = OPEN_URL(url)
	prms=json.loads(link)
	TotalPlaylists=int(prms['feed'][u'openSearch$totalResults'][u'$t'])
	j=1
	h=1
	lst=[]
	pages= (TotalPlaylists//50)  +1
	while  j<=pages :
		link = OPEN_URL(url)
		prms=json.loads(link)
		i=0
		while h<TotalPlaylists +1  and i<50:
			thumb=''
			try:
				playlistid=str(prms['feed'][u'entry'][i][u'yt$playlistId'][u'$t'])
				title=str(prms['feed'][u'entry'][i][u'title'][u'$t'].encode('utf-8'))
				thumb=str(prms['feed'][u'entry'][i][u'media$group'][u'media$thumbnail'][2][u'url'])
			except:
				pass
			i=i+1
			h=h+1
			lst.append((playlistid,title,thumb))
		j=j+1
		url='https://gdata.youtube.com/feeds/api/users/'+user+ '/playlists?alt=json&max-results=50&start-index='+str (j*50-49)
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "PlaylistsFromUser" + space2 + user + space + "TotalPlaylists" + space2 + str(TotalPlaylists) + space + "url" + space2 + url #"link" + space2 + link
	'''---------------------------'''
	return lst
	
def RanFromPlayList(playlistid):
	random.seed()
	url='https://gdata.youtube.com/feeds/api/playlists/'+playlistid+'?alt=json&max-results=50'
	link = OPEN_URL(url)
	prms=json.loads(link)
	numOfItems=int(prms['feed'][u'openSearch$totalResults'][u'$t']) #if bigger than 50 needs  to add more result
	if numOfItems >1 :
		link = OPEN_URL(url)
		prms=json.loads(link)
		if numOfItems>49:
			numOfItems=49
		i=random.randint(1, numOfItems-1)
		#print str (len(prms['feed'][u'entry']))  +"and i="+ str(i)
		try:
			urlPlaylist= str(prms['feed'][u'entry'][i][ u'media$group'][u'media$player'][0][u'url'])
			match=re.compile('www.youtube.com/watch\?v\=(.*?)\&f').findall(urlPlaylist)
			finalurl="plugin://plugin.video.youtube/play/?video_id="+match[0]+"&hd=1" #finalurl="plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid="+match[0]+"&hd=1"
			title= str(prms['feed'][u'entry'][i][ u'media$group'][u'media$title'][u'$t'].encode('utf-8')).decode('utf-8')
			thumb =str(prms['feed'][u'entry'][i][ u'media$group'][u'media$thumbnail'][2][u'url'])
			desc= str(prms['feed'][u'entry'][i][ u'media$group'][u'media$description'][u'$t'].encode('utf-8')).decode('utf-8')
		except :
			 return "","","",""  # private video from youtube
		'''liz = xbmcgui.ListItem(title, iconImage="DefaultVideo.png", thumbnailImage=thumb)
		liz.setInfo( type="Video", infoLabels={ "Title": title} )
		liz.setProperty("IsPlayable","true")
		pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
		pl.clear()
		pl.add(finalurl, liz)'''
		#xbmc.Player(xbmc.PLAYER_CORE_MPLAYER).play(pl)
		return finalurl,title,thumb,desc
	else:
		return "","","",""

def SeasonsFromShow(showApiUrl):
	#print showApiUrl
	resultJSON = json.loads(OPEN_URL(showApiUrl))
	seasons=resultJSON['feed']['entry']
	for i in range (0, len(seasons)) :
		#print seasons[i].keys()
		#print seasons[i]['title']['$t']
		for index,item in  enumerate(seasons[i]['gd$feedLink']) :
			if item['countHint'] !=0:
				resultJSON = json.loads(OPEN_URL( seasons[i]['gd$feedLink'][index]['href']+'&alt=json'))
				for  j in range (0, len(resultJSON['feed']['entry'])) :
					title= str(resultJSON['feed'][u'entry'][j][ u'media$group'][u'media$title'][u'$t'].encode('utf-8')).decode('utf-8')
					thumb =str(resultJSON['feed'][u'entry'][j][ u'media$group'][u'media$thumbnail'][-1][u'url'])
					episode_num=resultJSON['feed']['entry'][j]['yt$episode']['number']
					url= resultJSON['feed']['entry'][j]['link'][0]['href']
					match=re.compile('www.youtube.com/watch\?v\=(.*?)\&f').findall(url)
					#finalurl="plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid="+match[0]+"&hd=1"
					finalurl="plugin://plugin.video.youtube/play/?video_id="+match[0]+"&hd=1"
					addLink(title+' '+episode_num ,finalurl,thumb,'',"")
					
def setView(content, viewType, containerfolderpath2):
	'''set content type so library shows more views and info'''
	autoview = xbmc.getInfoLabel('Skin.HasSetting(AutoView)')
	
	if content:
		xbmcplugin.setContent(int(sys.argv[1]), content)
	if viewType == None:
		if containerfolderpath2 == 'plugin://' + addonID + "/": viewType = 50
		elif viewType == None: pass
		elif content == 'episodes': viewType = 50
		elif content == 'seasons': viewType = 50
		elif content == 'tvshows': viewType = 58
		elif content == 'movies': viewType = 58
		

	if General_AutoView == "true" and autoview and viewType != None:
		xbmc.executebuiltin("Container.SetViewMode(%s)" % viewType )
		'''---------------------------'''
	# set sort methods - probably we don't need all of them
    #xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    #xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    #xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
    #xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
    #xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
    #xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
    #xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "content" + space2 + str(content) + space + "viewType" + space2 + str(viewType) + space + "containerfolderpath2" + space2 + containerfolderpath2
	'''---------------------------'''

def ShowFromUser(user):
	'''reads  user names from my subscriptions'''
	murl='https://gdata.youtube.com/feeds/api/users/'+user+'/shows?alt=json&start-index=1&max-results=50&v=2'
	resultJSON = json.loads(OPEN_URL(murl))
	shows=resultJSON['feed']['entry']
	#print shows[1]
	hasNext= True
	while hasNext:
		shows=resultJSON['feed']['entry']
		for  i in range (0, len(shows)) :
			showApiUrl=shows[i]['link'][1]['href']
			showApiUrl=showApiUrl[:-4]+'/content?v=2&alt=json'
			showName=shows[i]['title']['$t'].encode('utf-8')
			image= shows[i]['media$group']['media$thumbnail'][-1]['url']
			addDir(showName,showApiUrl,14,image,'','1',"")
		hasNext= resultJSON['feed']['link'][-1]['rel'].lower()=='next'
		if hasNext:
			resultJSON = json.loads(OPEN_URL(resultJSON['feed']['link'][-1]['href']))
			
def TVMode_check(admin, url, playlists):
	printpoint = ""
	returned = ""
	if General_TVModeDialog == "true":
		printpoint = printpoint + "1"
		#list = [40,41,42,43,44,45,46,47,48,49]
		#for i in list:
		#if "mode=" + str(i) in containerfolderpath: #or (i == 40 and containerfolderpath == "plugin://" + addonID + "/")
		#if admin: print printfirst + "YOUList-General_TVModeDialog" + space + "i" + space2 + str(i) + space + containerfolderpath
		printpoint = printpoint + "3"
		countl = 0
		for space in playlists:
			countl += 1
		countlS = str(countl)
		if playlists==[] or countl > 1:  #no playlists on  youtube channel
			'''------------------------------
			---PLAYLIST->-1------------------
			------------------------------'''
			printpoint = printpoint + "5"
			returned = dialogyesno(str79523.encode('utf-8'),str79524.encode('utf-8'))
			if returned == "ok": returned = TvMode(url)
			'''---------------------------'''
		else: printpoint = printpoint + "8"
				
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "TVMode_check_LV" + printpoint
	'''---------------------------'''
	return returned

def TvMode2(mode, name, url, iconimage, desc, num, viewtype):
	returned = ""
	if General_TVModeDialog == "true":
		returned = dialogyesno(str79523.encode('utf-8'),str79524.encode('utf-8'))
	
	if returned == "ok": mode = 5
	else: mode = 6
	
	MultiVideos(mode, name, url, iconimage, desc, num, viewtype)
	
	return mode
	
def TvMode(user):
	printpoint = ""
	returned = ""
	try: playlists=PlaylistsFromUser(user)
	except: playlists = []
	if playlists == []:  #no playlists on  youtube channel
		from default import CATEGORIES
		dialog = xbmcgui.Dialog()
		ok = dialog.ok('HTPT', addonString(302).encode('utf-8'))
		CATEGORIES()
	#print "str is" +  str(random.choice(playlists)[0])
	else:
		count = 0
		while count < 10 and xbmc.Player().isPlayingVideo() and not xbmc.abortRequested:
			xbmc.sleep(100)
			count += 1
			if count == 1: xbmc.executebuiltin('Action(Stop)')
		pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
		pl.clear()
		dp= xbmcgui.DialogProgress()
		dp.create('HTPT',"")
		PlayListGain = "" #URLS
		PlayListGain2 = 0 #DUPLICATES
		PlayListGain3 = "" #DELETES
		count = 0
		while count <= 40 and not "9" in printpoint and not xbmc.abortRequested:
			for i in range (1,41):  #40  RANDOM PROGRAMS IN TV MODE
				count += 1
				countS = str(count)
				if count == 1: dp.update(i*50, str79529.encode('utf-8'), "")
				else: dp.close()
				#print str (playlists)
				ran=str(random.choice(playlists)[0])
				finalurl,title,thumb,desc= RanFromPlayList(ran)
				liz = xbmcgui.ListItem(title, iconImage="DefaultVideo.png", thumbnailImage=thumb)
				liz.setInfo( type="Video", infoLabels={ "Title": title} )
				liz.setProperty("IsPlayable","true")
				
				if not finalurl in PlayListGain and not "Deleted video" in title: pl.add(finalurl, liz)
				elif "Deleted video" in title: PlayListGain3 = PlayListGain3 + space + finalurl
				else:
					PlayListGain2 = PlayListGain2 + 1
					if PlayListGain2 > 10:
						playlistlength = xbmc.getInfoLabel('Playlist.Length(video)')
						notification(addonString(305).encode('utf-8') % (str(playlistlength), str(PlayListGain2)),addonString(306).encode('utf-8'),"",4000)
						printpoint = printpoint + "9"
						#sys.exit()
						'''---------------------------'''
				PlayListGain = PlayListGain + space + finalurl
				if count == 1:
					dp.update(100, str79529.encode('utf-8'), "")
					xbmc.Player(xbmc.PLAYER_CORE_MPLAYER).play(pl)
					count2 = 0
					while count2 < 10 and not xbmc.Player().isPlayingVideo() and not xbmc.abortRequested:
						xbmc.sleep(500)
						count2 += 1
						xbmc.sleep(500)
						'''---------------------------'''
				elif not xbmc.Player().isPlayingVideo(): printpoint = printpoint + "9" #sys.exit(1)
		playlistlength = xbmc.getInfoLabel('Playlist.Length(video)')
		playlistlengthN = int(playlistlength)
        if xbmc.Player().isPlayingVideo() and playlistlengthN > 5:
            printpoint = printpoint + "7"
            PlayListGain2S = str(PlayListGain2)
            notification(addonString(305).encode('utf-8') % (playlistlength, PlayListGain2S),addonString(306).encode('utf-8'),"",4000)
            print printfirst + "PlayListGain_" + countS + space + PlayListGain2S + space + "Duplicated Not Added!"
			#xbmc.Player(xbmc.PLAYER_CORE_MPLAYER).play(pl)
            '''---------------------------'''
			
        print printfirst + "TvMode" + space2 + "count" + space2 + countS + space + "PlayListGain2S" + space + PlayListGain2S + space + "PlayListGain3" + space2 + PlayListGain3
		
	if "7" in printpoint: returned = "ok"
	'''---------------------------'''
	return returned
	
def update_view(url, viewtype):
    ok=True
    setsetting_custom1(addonID, 'Current_View', viewtype)
    xbmc.executebuiltin('XBMC.Container.Update(%s)' % url )
    if admin: print printfirst + "update_view" + space2 + "url" + space2 + str(url) + space + "viewtype" + space2 + str(viewtype)
    return ok

def unescape(text):
	try:            
		rep = {"&nbsp;": " ",
			   "\n": "",
			   "\t": "",
			   "\r":"",
			   "&#39;":"",
			   "&quot;":"\""
			   }
		for s, r in rep.items():
			text = text.replace(s, r)
			
		# remove html comments
		text = re.sub(r"<!--.+?-->", "", text)    
			
	except TypeError:
		pass

	return text
	
def YOULink(mname, url, thumb, desc):
	if not "UKY3scPIMd8" in url or admin:
		ok=True
		url = "plugin://plugin.video.youtube/play/?video_id="+url
		#url='https://gdata.youtube.com/feeds/api/videos/'+url+'?alt=json&max-results=50' #TEST
		liz=xbmcgui.ListItem(mname, iconImage="DefaultVideo.png", thumbnailImage=thumb)
		liz.setInfo( type="Video", infoLabels={ "Title": mname, "Plot": desc } )
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
		if admin: print printfirst + "YOULink" + space + "url" + space2 + str(url) + space + "mname" + space2 + mname
		return ok
	
def YOULinkAll(url):
	dp = xbmcgui.DialogProgress()
	dp.create(addonName ,addonString(4).encode('utf-8'))
	dp.update(0)
	dp.update(0, "", str79520.encode('utf-8'))
	pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
	pl.clear()
	link = OPEN_URL(url)
	match=re.compile("http\://www.youtube.com/watch\?v\=([^\&]+)\&.+?<media\:descriptio[^>]+>([^<]+)</media\:description>.+?<media\:thumbnail url='([^']+)'.+?<media:title type='plain'>(.+?)/media:title>").findall(link)
	playlist = []
	nItem = len(match)

	for nurl,desc,thumb,rname in match:
		rname=rname.replace('<','')
		#finalurl= "plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid="+nurl+"&hd=1"
		finalurl= "plugin://plugin.video.youtube/play/?video_id="+nurl+"&hd=1"
		liz = xbmcgui.ListItem(rname, iconImage="DefaultVideo.png", thumbnailImage=thumb)
		liz.setInfo( type="Video", infoLabels={ "Title": rname, "Plot": desc}) #NEW UNTESTED!!! (PLOT...)
		liz.setProperty("IsPlayable","true")
		playlist.append((finalurl ,liz))
		progress = len(playlist) / float(nItem) * 100  
		dp.update(int(progress), str79520.encode('utf-8'),rname)
		#dp.update(i*5, str79529.encode('utf-8'), "")
		if dp.iscanceled():
			return

	
	for blob ,liz in playlist:
		try:
			if blob:
				if not 'UKY3scPIMd8' in blob:
					pl.add(blob,liz)
		except:
			pass
	dp.close()
	xbmc.Player(xbmc.PLAYER_CORE_MPLAYER).play(pl)

def urlcheck(url, ping=False):
	import urllib2
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	name = "urlcheck" ; printpoint = "" ; returned = "" ; extra = ""
	
	
	try:
		urllib2.urlopen(url)
		printpoint = printpoint + "7"
		
	except urllib2.HTTPError, e: 
		extra = extra + newline + str(e.code) + space + str(e)
		printpoint = printpoint + "8"
	except urllib2.URLError, e:
		extra = extra + newline + str(e.args) + space + str(e)
		printpoint = printpoint + "9"
	
	if not "7" in printpoint:
		if ping == True:
			if systemplatformwindows: output = cmd('ping '+url+' -n 1',"Connected2")
			else: output = bash('ping -W 1 -w 1 -4 -q '+url+'',"Connected")
			if (not systemplatformwindows and ("1 packets received" in output or not "100% packet loss" in output)) or (systemplatformwindows and ("Received = 1" in output or not "100% loss" in output)): printpoint = printpoint + "7"
	
	if "UKY3scPIMd8" in url: printpoint = printpoint + "6"
	elif "7" in printpoint: returned = "ok"
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin or addonID == 'script.htpt.install': print printfirst + name + "_LV" + printpoint + space + "url" + space2 + url + space + "ping" + space2 + str(ping) + space + extra
	'''---------------------------'''
	return returned
	
def YOUList2(name, url, iconimage, desc, num, viewtype):
	returned = ""
	#playlists=PlaylistsFromUser(url)
	
	
	#TVMode_check(admin, url, playlists)
	if General_TVModeDialog != "true" or returned != "ok":
		#url2='plugin://plugin.video.youtube/channel/'+url+'/'
		#link = OPEN_URL('http://youtube.com/channel/'+url+'')
		
		default = 'http://www.youtube.com/'
		url1 = 'channel/' + url + '/'
		url2 = 'user/' + url + '/'
		returned1 = urlcheck(default + url1)
		returned2 = urlcheck(default + url2)
		
		default2 = 'plugin://plugin.video.youtube/'
		
		#print "543-link1" + space2 + link
		#print "543-link2" + space2 + link2
		#update_view('plugin://plugin.video.youtube/channel/'+url+'/', viewtype)
		if returned1 == 'ok': update_view(default2 + url1, viewtype)
		elif returned2 == 'ok': update_view(default2 + url2, viewtype)
		#xbmc.executebuiltin('XBMC.Container.Update(%s)' % url2 )
		'''---------------------------'''
		
def YOUList(name, url, iconimage, desc, num):
	returned = ""
	printpoint = ""
	try:
		playlists = PlaylistsFromUser(url)
		returned = TVMode_check(admin, url, playlists)
	except: printpoint = printpoint + "8"
				
	if General_TVModeDialog != "true" or returned != "ok":
		if num == "" or num == None: num = '1'
		numN = int(num)
		num3N = 1
		'''---------------------------'''
		murl='http://gdata.youtube.com/feeds/api/users/'+url+'/uploads?&max-results=50&start-index='+num
		#murl='https://gdata.youtube.com/feeds/users/'+url+'/uploads?&max-results=50&start-index='+num
		print printfirst + "murl" + space2 + murl
		link=OPEN_URL(murl)
		#print link
		if addonID == 'plugin.video.htpt.gopro' or addonID == 'plugin.video.htpt.music': addDir('[COLOR=Yellow]' + str79525.encode('utf-8') + '[/COLOR]',url,15,"special://skin/media/DefaultRecentlyAddedEpisodes.png",str79524.encode('utf-8'),'1',"") #TV Mode
		else: addDir('[COLOR=Yellow]' + str79520.encode('utf-8') + '[/COLOR]',murl,11,"special://skin/media/DefaultPlaylist.png",str79526.encode('utf-8'),'1',"") #Quick-Play
		
		match=re.compile("http\://www.youtube.com/watch\?v\=([^\&]+)\&.+?<media\:descriptio[^>]+>([^<]+)</media\:description>.+?<media\:thumbnail url='([^']+)'.+?<media:title type='plain'>(.+?)/media:title>").findall(link)
		
		if not "8" in printpoint:
			for playlistid,title,thumb, in playlists:
				'''PlayList'''
				if num == '1':
					num3N += 1
					numN += 1
					#num = str(numN)
					addDir('[COLOR=Yellow2]' + title + '[/COLOR]',playlistid,12,thumb,str79527.encode('utf-8'),num,"")
					#addDir(title + '[COLOR=Yellow]' + addonString(7).encode('utf-8') + space2 + '[/COLOR]',playlistid,12,thumb,'',num,"")
					#print "123 " + playlistid
		
		if 1 + 1 == 3:
			for nurl,desc,thumb,rname in match:
				'''Media'''
				if (num == '1' and num3N < 8) or (num != '1' and num3N < 40):
					rname=rname.replace('<','')
					num3N += 1
					numN += 1
					#num = str(numN)
					YOULink(rname, nurl, thumb, desc)
					#addLink(rname, nurl, thumb, desc,"")
		
		'''Show More Results'''
		if (num == '1' and num3N <= 8): num2N = int(num) + num3N
		else: num2N = int(num) + 40
		num2 = str(num2N)
		num3 = str(num3N)

		if admin or num == '1' or num3N == 40:
			'''TEMP SOLUTION'''
			#addDir('[COLOR=Yellow]' + str79521.encode('utf-8') + '[/COLOR]',url,9,"special://skin/media/icons/se.png",str79528.encode('utf-8'),num2,"")
			if addonID == 'plugin.video.htpt.music': addDir('[COLOR=Yellow]' + str79521.encode('utf-8') + '[/COLOR]','plugin://plugin.video.youtube/user/'+url+'/',8,"special://skin/media/DefaultPlaylist.png",str79528.encode('utf-8'),num2,"") #More Results
			else: addDir('[COLOR=Yellow]' + str79521.encode('utf-8') + '[/COLOR]','plugin://plugin.video.youtube/channel/'+url+'/',8,"special://skin/media/DefaultPlaylist.png",str79528.encode('utf-8'),num2,"") #More Results
			#addDir(name,'plugin://plugin.video.youtube/channel/'+url+'/',8,"","","","")
			#addDir(name,'plugin://plugin.video.youtube/video_id/'+nurl+'/',8,"","","","")
		setsetting_custom1(addonID,'Current_View','default')
		
		
		if admin: print printfirst + "YOUList_LV" + printpoint + " " + "num/2/3" + space2 + num + " / " + num2 + " / " + num3 + space + "returned" + space2 + returned + space + "name" + space2 + str(name) + space + "url" + space2 + url
		if admin: print printfirst + "YOUList" + space + "link" + space2 + str(link)
		if admin: print printfirst + "YOUList" + space + "match" + space2 + str(match)
		#if admin: print printfirst + "YOUList" + space + "nurl" + space2 + str(nurl) + space + "desc" + space2 + str(desc) + space + "thumb" + space2 + str(thumb) + space + "rname" + space2 + str(rname)

def YOUsubs(user):
	murl='http://gdata.youtube.com/feeds/api/users/'+user+'/subscriptions?alt=json&start-index=1&max-results=50'
	resultJSON = json.loads(OPEN_URL(murl))
	feed=resultJSON['feed']['entry']
	for i in range (0, len(feed)) :
		image=str(feed[i]['media$thumbnail']['url'])
		name = feed[i]['title']['$t'].replace('Activity of:','').encode('utf-8')
		url=feed[i]['yt$channelId']['$t'].encode('utf-8')
		addDir(name,url,9,image,'1','1',"")
	setsetting_custom1(addonID,'Current_View','default')
	
def pluginend(admin):
	from modules import *
	printpoint = ""
	
	'''------------------------------
	---params------------------------
	------------------------------'''
	params=get_params()
	url=None
	name=None
	mode=None
	iconimage=None
	desc=None
	num=None
	viewtype=None
	'''---------------------------'''
	try: url=urllib.unquote_plus(params["url"])
	except: pass
	try: name=urllib.unquote_plus(params["name"])
	except: pass
	try: iconimage=urllib.unquote_plus(params["iconimage"])
	except: pass
	try: mode=int(params["mode"])
	except: pass
	try: desc=urllib.unquote_plus(params["desc"])
	except: pass
	
	try: num=urllib.unquote_plus(params["num"])
	except: pass
	try: viewtype=int(params["viewtype"])
	except: pass
	'''---------------------------'''

	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	nameS = str(name)
	descS = str(desc)
	try: IconImageS = str(IconImage)
	except: IconImageS = "None"
	'''---------------------------'''
	if admin: print printfirst + "pluginend" + space + "mode" + space2 + str(mode) + space + "url" + space2 + str(url) + space + "name" + space2 + nameS + space + "IconImage" + space2 + IconImageS + space + "desc" + space2 + descS + "viewtype" + space2 + str(viewtype) + newline + "params" + space2 + str(params)
	'''---------------------------'''

	'''------------------------------
	---MODES-LIST--------------------
	------------------------------'''
	if mode == None or (url == None or len(url)<1) and mode < 100: 
		CATEGORIES()
		#notification("Test",Addon_Version,"",2000)
		try:
			getsetting('Addon_Update')
			getsetting('Addon_Version')
			getsetting('Addon_UpdateDate')
			getsetting('Addon_UpdateLog')
			checkAddon_Update(admin, Addon_Update, Addon_Version, Addon_UpdateDate, Addon_UpdateLog)
		except:
			printpoint = printpoint + "2"
			'''---------------------------'''
	
	#1-99 = COMMANDS
	elif mode == 1:
		#print ""+url
		Choose_series(url)
	elif mode == 2:
		series_land(url)
	elif mode == 3:
		play_episode(url)
	elif mode == 4:
		#play_video(url) #API V3 issues
		play_video2(url)
	elif mode == 5:
		MultiVideos(mode, name, url, iconimage, desc, num, viewtype)
	elif mode == 6:
		MultiVideos(mode, name, url, iconimage, desc, num, viewtype)
	elif mode == 7:
		ListLive(url)
	elif mode == 8:
		update_view(url, viewtype)
	elif mode == 9:
		#YOUList(name, url, iconimage, desc, num)
		YOUList2(name, url, iconimage, desc, num, viewtype)
	elif mode == 10:
		YOUsubs(url)
	elif mode == 11:
		YOULinkAll(url)
	elif mode == 12:
		#PlayPlayList(url)
		PlayPlayList2(url)
	elif mode == 13:
		#ListPlaylist(url, num)
		ListPlaylist2(url, num, viewtype)
	elif mode == 14:       
		SeasonsFromShow(url)
	elif mode == 15:
		TvMode(url)
	elif mode == 16:       
		ShowFromUser(url)
	elif mode == 17:
		mode = TvMode2(mode, name, url, iconimage, desc, num, viewtype)
	#101-999 = SUB-CATEGORIES1
	elif mode == 101:
		CATEGORIES101(admin)
	elif mode == 102: 
		CATEGORIES102(admin)
	elif mode == 103:       
		CATEGORIES103(admin)
	elif mode == 104:       
		CATEGORIES104(admin)
	elif mode == 105:    
		CATEGORIES105(admin)
	elif mode == 106:       
		CATEGORIES106(admin)
	elif mode == 107:       
		CATEGORIES107(admin)
	elif mode == 108:       
		CATEGORIES108(admin)
	elif mode == 109:       
		CATEGORIES109(admin)
	
	elif mode == 111:
		CATEGORIES111(admin)
	elif mode == 112: 
		CATEGORIES112(admin)
	elif mode == 113:       
		CATEGORIES113(admin)
	elif mode == 114:       
		CATEGORIES114(admin)
	elif mode == 115:    
		CATEGORIES115(admin)
	elif mode == 116:       
		CATEGORIES116(admin)
	elif mode == 117:       
		CATEGORIES117(admin)
	elif mode == 118:       
		CATEGORIES118(admin)
	elif mode == 119:       
		CATEGORIES119(admin)
		
	elif mode == 121:
		CATEGORIES121(admin)
	elif mode == 122: 
		CATEGORIES122(admin)
	elif mode == 123:       
		CATEGORIES123(admin)
	elif mode == 124:       
		CATEGORIES124(admin)
	elif mode == 125:    
		CATEGORIES125(admin)
	elif mode == 126:       
		CATEGORIES126(admin)
	elif mode == 127:       
		CATEGORIES127(admin)
	elif mode == 128:       
		CATEGORIES128(admin)
	elif mode == 129:       
		CATEGORIES129(admin)
	
	elif mode == 131:
		CATEGORIES131(admin)
	elif mode == 132: 
		CATEGORIES132(admin)
	elif mode == 133:       
		CATEGORIES133(admin)
	elif mode == 134:       
		CATEGORIES134(admin)
	elif mode == 135:    
		CATEGORIES135(admin)
	elif mode == 136:       
		CATEGORIES136(admin)
	elif mode == 137:       
		CATEGORIES137(admin)
	elif mode == 138:       
		CATEGORIES138(admin)
	elif mode == 139:       
		CATEGORIES139(admin)
	
	#10101+ = SUB-CATEGORIES2
	elif mode == 10101:
		CATEGORIES10101(name, iconimage, desc)
	elif mode == 10102:
		CATEGORIES10102(name, iconimage, desc)
	elif mode == 10103:
		CATEGORIES10103(name, iconimage, desc)
	elif mode == 10104:
		CATEGORIES10104(name, iconimage, desc)
	elif mode == 10105:
		CATEGORIES10105(name, iconimage, desc)
	elif mode == 10106:
		CATEGORIES10106(name, iconimage, desc)
	elif mode == 10107:
		CATEGORIES10107(name, iconimage, desc)
	elif mode == 10108:
		CATEGORIES10108(name, iconimage, desc)
	elif mode == 10109:
		CATEGORIES10109(name, iconimage, desc)
		
	elif mode == 10201:
		CATEGORIES10201(name, iconimage, desc)
	elif mode == 10202:
		CATEGORIES10202(name, iconimage, desc)
	elif mode == 10203:
		CATEGORIES10203(name, iconimage, desc)
	elif mode == 10204:
		CATEGORIES10204(name, iconimage, desc)
	elif mode == 10205:
		CATEGORIES10205(name, iconimage, desc)
	elif mode == 10206:
		CATEGORIES10206(name, iconimage, desc)
	elif mode == 10207:
		CATEGORIES10207(name, iconimage, desc)
	elif mode == 10208:
		CATEGORIES10208(name, iconimage, desc)
	elif mode == 10209:
		CATEGORIES10209(name, iconimage, desc)
	
	elif mode == 10401:
		CATEGORIES10401(name, iconimage, desc)
	elif mode == 10402:
		CATEGORIES10402(name, iconimage, desc)
	elif mode == 10403:
		CATEGORIES10403(name, iconimage, desc)
	elif mode == 10404:
		CATEGORIES10405(name, iconimage, desc)
	elif mode == 10406:
		CATEGORIES10406(name, iconimage, desc)
	elif mode == 10407:
		CATEGORIES10407(name, iconimage, desc)
	elif mode == 10408:
		CATEGORIES10408(name, iconimage, desc)
	elif mode == 10409:
		CATEGORIES10409(name, iconimage, desc)
	elif mode == 10410:
		CATEGORIES10410(name, iconimage, desc)
	elif mode == 10411:
		CATEGORIES10411(name, iconimage, desc)
	elif mode == 10412:
		CATEGORIES10412(name, iconimage, desc)
	elif mode == 10413:
		CATEGORIES10413(name, iconimage, desc)
	elif mode == 10414:
		CATEGORIES10414(name, iconimage, desc)
	elif mode == 10415:
		CATEGORIES10415(name, iconimage, desc)
	elif mode == 10416:
		CATEGORIES10416(name, iconimage, desc)
	elif mode == 10417:
		CATEGORIES10417(name, iconimage, desc)
	elif mode == 10418:
		CATEGORIES10418(name, iconimage, desc)
	elif mode == 10419:
		CATEGORIES10419(name, iconimage, desc)
	elif mode == 10420:
		CATEGORIES10420(name, iconimage, desc)
	elif mode == 10421:
		CATEGORIES10421(name, iconimage, desc)
	elif mode == 10422:
		CATEGORIES10422(name, iconimage, desc)
	elif mode == 10423:
		CATEGORIES10423(name, iconimage, desc)
	elif mode == 10424:
		CATEGORIES10424(name, iconimage, desc)
	elif mode == 10425:
		CATEGORIES10425(name, iconimage, desc)
	elif mode == 10426:
		CATEGORIES10426(name, iconimage, desc)
	elif mode == 10427:
		CATEGORIES10427(name, iconimage, desc)
	elif mode == 10428:
		CATEGORIES10428(name, iconimage, desc)
	elif mode == 10429:
		CATEGORIES10429(name, iconimage, desc)
	elif mode == 10430:
		CATEGORIES10430(name, iconimage, desc)
		
	else: notification("?","","",1000)
	
	if mode != 17 and mode != 5: xbmcplugin.endOfDirectory(int(sys.argv[1]))
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "pluginend_LV" + printpoint
	'''---------------------------'''
	return url, name, mode, iconimage, desc, num, viewtype
	
	
def pluginend2(admin, url, containerfolderpath, viewtype):
	printpoint = "" ; count = 0 ; countmax = 10 ; containerfolderpath2 = "" ; url = str(url)
	returned_Dialog, returned_Header, returned_Message = checkDialog(admin)
	
	#xbmc.sleep(1000) #TIME FOR DIALOGBUSY
	if "plugin.video.10qtv" in url: countmax = 40
	
	while (count < countmax and (returned_Dialog == "dialogbusyW" or returned_Dialog == "dialogprogressW")) or (count < 2 and returned_Dialog == "") and not xbmc.abortRequested:
		count += 1
		if count == 1: printpoint = printpoint + "1"
		xbmc.sleep(500)
		returned_Dialog, returned_Header, returned_Message = checkDialog(admin)
		'''---------------------------'''
		
	if count < countmax:
		printpoint = printpoint + "2"
		if count == 0: xbmc.sleep(1000)
		else: xbmc.sleep(500)
		containerfolderpath2 = xbmc.getInfoLabel('Container.FolderPath')
		if containerfolderpath != containerfolderpath2: #GAL CHECK THIS! #containerfolderpath2 == "plugin://"+addonID+"/"
			printpoint = printpoint + "4"
			setView('', viewtype, containerfolderpath2)
			'''---------------------------'''

	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "pluginend2_LV" + printpoint + space + "count" + space2 + str(count) + space + "Current_View" + space2 + Current_View + space + "returned_Dialog" + space2 + returned_Dialog + space + "containerfolderpath/2" + newline + str(containerfolderpath) + newline + str(containerfolderpath2) + newline + "url" + space2 + str(url)
	'''---------------------------'''