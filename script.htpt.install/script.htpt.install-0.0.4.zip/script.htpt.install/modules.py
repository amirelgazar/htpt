# -*- coding: utf-8 -*-
#import xbmc, os, subprocess, sys
#import xbmc, xbmcgui, xbmcaddon
import xbmc, xbmcgui, xbmcaddon
import subprocess, os, sys
import xbmcplugin
import urllib
import urllib2
import re

from variables import *
from shared_modules import *
from shared_modules3 import addDir


def CATEGORIES(servicehtpt_Skin_Name):
	
	addon = 'skin.htpt'
	if xbmc.getCondVisibility('System.HasAddon('+ addon +')') and os.path.exists(addons_path + addon):
		if servicehtpt_Skin_Name == addon:
			addDir(addonString(11),'',21,htptinstallmedia_path + 'bin.png',addonString(101),'1',500) #הסרת מערכת
			if Skin_Suspend == "false": addDir(addonString(12),'',22,htptinstallmedia_path + 'linkbroken.png',addonString(102),'1',500) #השהיית מערכת
			'''---------------------------'''
		else:
			addDir(addonString(13),'',23,htptinstallmedia_path + 'htpt.png',addonString(103) % (servicehtpt_Skin_Name),'1',500) #כניסה ל-HTPT
			'''---------------------------'''
	else:
		addDir(addonString(10),'',20,htptinstallmedia_path + 'software.png',addonString(100),'1',500) #התקנת מערכת
		'''---------------------------'''
	
	if admin and not admin2: addDir("Test7",'',7,htptinstallmedia_path + 'caa2.png','','1',500) #Test
	#xbmc.executebuiltin('Container.Refresh')
	
def mode20(name, printpoint, backupname, backuppath):
	'''------------------------------
	---INSTALL-BUTTON----------------
	------------------------------'''
	#id40str = xbmc.getInfoLabel('Skin.HasSetting(ID40)')
	#verrorstr = xbmc.getInfoLabel('$VAR[VERROR]')
	
	returned = dialogkeyboard(User_ID1, '$LOCALIZE[1014]', 0, '1', 'User_ID1', 'script.htpt.install') #ID1
	'''---------------------------'''
	#datenowS = datewnowS.replace("-",
	dialogok(addonString(93), addonString(94), "", "") #Backup Current System
	
	notification(addonString(93), ".", "", 1000)
	CreateZip(userdata_path.encode('utf-8'), backuppath + backupname2, filteron=['guisettings.xml'], filteroff=[], level=0, append=False, ZipFullPath=True, temp=False)
	'''---------------------------'''
	CreateZip(config_path, backuppath + backupname, filteron=['samba.conf', 'autostart.sh'], level=0, append=False, ZipFullPath=True, temp=True)
	CreateZip(emulators_path, backuppath + backupname, filteroff=['retroarch'], append=True, ZipFullPath=True, temp=True)
	notification(addonString(93), "..", "", 1000)
	CreateZip(userdata_path.encode('utf-8'), backuppath + backupname, filteron=['advancedsettings.xml', 'sources.xml', 'keymaps'], filteroff=[], level=0, append=True, ZipFullPath=True, temp=True)
	notification(addonString(93), "..", "", 1000)
	returned = CreateZip(addondata_path, backuppath + backupname, filteron=['plugin.video.genesis', 'plugin.program.advanced.launcher', 'metadata.universal', 'metadata.tvdb.com'], filteroff=[], append="End", ZipFullPath=True, temp=True)
		
	if returned != 'ok':
		returned = dialogyesno("Backup Failed", "Proceed without backup?")
		if returned == 'ok': printpoint = printpoint + "4"
		else: notification_common("9")
		'''---------------------------'''
	else: printpoint = printpoint + "4"
		
	if "4" in printpoint:
		printpoint = printpoint + installaddon2(admin, 'script.htpt.debug', update=False)
		printpoint = printpoint + installaddon2(admin, 'service.htpt.fix', update=False)
		printpoint = printpoint + installaddon2(admin, 'script.htpt.homebuttons', update=False)
		printpoint = printpoint + installaddon2(admin, 'script.htpt.smartbuttons', update=False)
		printpoint = printpoint + installaddon2(admin, 'script.htpt.remote', update=False)
		printpoint = printpoint + installaddon2(admin, 'script.htpt.refresh', update=False)
		printpoint = printpoint + installaddon2(admin, 'skin.htpt', update=True)

	if "5" in printpoint:
		xbmc.executebuiltin("UpdateLocalAddons")
		xbmc.sleep(2000)
		'''---------------------------'''
	
	if not "9" in printpoint:
		'''------------------------------
		---INSTALLATION-SUCCESSFULLY-----
		------------------------------'''
		htptversion = xbmc.getInfoLabel('System.AddonVersion(skin.htpt)')
		printpoint = printpoint + "7"
		'''---------------------------'''
		setSkinSetting("1",'ID40',"true")
		setsetting('User_ID2', datenowS)
		setsetting('Skin_Installed', "true")
		
		xbmc.executebuiltin('ReplaceWindow(0)')
		xbmc.sleep(500)
			
		dialogok(addonString(91), addonString(92) % (htptversion), "", "")
		xbmc.sleep(1000)
		os.system('sh /storage/.kodi/addons/service.htpt/specials/scripts/copyskin.sh')
		'''---------------------------'''
		xbmc.sleep(1000)
		bash('pgrep kodi.bin | xargs kill -SIGSTOP && killall -9 kodi.bin && sleep 1 && pgrep kodi.bin | xargs kill -SIGCONT',"SOFT-RESTART")
		xbmc.sleep(1000)
		xbmc.executebuiltin('XBMC.Reset()')
		'''---------------------------'''
	
	else: dialogok(str257 + space + "1071", '$LOCALIZE[113]', "", "")
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + name + "_LV" + printpoint + space + "idstr" + space2 + idstr + space + "id40str" + space2 + id40str + space + "MAC" + space2 + macstr
	'''---------------------------'''

def mode21(name, printpoint, backupname, backupname2, backuppath):
	'''------------------------------
	---UNINSTALL-BUTTON--------------
	------------------------------'''
	
	returned = dialogyesno(addonString(11),addonString(98))
	if returned == 'ok':
		'''------------------------------
		---REMOVE------------------------
		------------------------------'''
		if systemplatformwindows: dialogok("Uninstall isn't available for Windows platform!","","","")
		else:
			if systemhasaddon_htptdebug: xbmc.executebuiltin('RunScript(script.htpt.debug,,?mode=21)')
			notification("Removing",'Please Wait',"",10000)
			'''---------------------------'''
			#bash('rm -rf '+config_path+'samba.conf','samba.conf')
			bash('rm -rf '+config_path+'autostart.sh','autostart.sh')
			'''---------------------------'''
			bash('rm -rf '+emulators_path+'',"emulators")
			bash('rm -rf /storage/*.log',"logs")
			bash('rm -rf '+addondata_path+'plugin.program.advanced.launcher/launchers.xml','launchers.xml')
			bash('rm -rf '+addondata_path+'skin.htpt/video/','skin.htpt/video/')
			bash('rm -rf '+addondata_path+'skin.htpt/music/','skin.htpt/music/')
			'''---------------------------'''
			bash('rm -rf '+userdata_path+'advancedsettings.xml','advancedsettings.xml')
			bash('rm -rf '+userdata_path+'sources.xml','sources.xml')
			'''---------------------------'''
			bash('rm -rf '+keymaps_path+'','keymaps')
			'''---------------------------'''
			bash('mount -o remount,rw /flash','mount flash')
			bash('rm -rf /flash/oemsplash.png','flash-remove')
			
			'''------------------------------
			---USERDATA+PACKAGE--------------
			------------------------------'''
			addonsL = []
			
			addonsL.append('plugin.video.genesis')
			addonsL.append('plugin.video.israelive')
			addonsL.append('plugin.video.p2p-streams')
			addonsL.append('plugin.video.youtube')
			addonsL.append('metadata.universal')
			addonsL.append('metadata.tvdb.com')
			'''---------------------------'''
			removeaddons(addonsL,"23")
			'''---------------------------'''
			
			'''------------------------------
			---ALL---------------------------
			------------------------------'''
			addonsL = []
			
			addonsL.append('browser.chromium-browser')
			addonsL.append('service.skin.widgets')
			addonsL.append('screensaver.randomtrailers')
			addonsL.append('screensaver.picture.slideshow')
			addonsL.append('script.moviequiz')
			addonsL.append('script.htpt.debug')
			addonsL.append('script.htpt.emu')
			addonsL.append('script.htpt.homebuttons')
			addonsL.append('script.htpt.smartbuttons')
			addonsL.append('script.htpt.refresh')
			addonsL.append('emulator.retroarch')
			addonsL.append('script.htpt.remote')
			addonsL.append('service.htpt.fix')
			addonsL.append('repository.htpt')
			addonsL.append('plugin.video.htpt.gopro')
			addonsL.append('plugin.video.htpt.kids')
			addonsL.append('plugin.video.htpt.music')
			'''---------------------------'''
			removeaddons(addonsL,"123")
			'''---------------------------'''
			from variables import *
			
			if os.path.exists(backuppath + backupname + ".zip"):
				notification("Using Restore point", "From Last Backup", "", 4000)
				ExtractAll(backuppath + backupname + ".zip", restorepath)
			
			if os.path.exists(backuppath + backupname2 + ".zip"):
				returned = dialogyesno(addonString(87) % ('guisettings.xml'), addonString(86))
				if returned == 'ok':
					notification("Using Restore point", "From Last Backup", "", 4000)
					ExtractAll(backuppath + backupname2 + ".zip", restorepath)
				else: pass
			
			dialogok("Uninstall Complete!","","","")
			try:
				removeaddons('skin.htpt',"13")
				removeaddons('service.htpt',"123")
			except Exception, TypeError: print "Uninstall htpt.service/skin - TypeError: " + str(TypeError)
			xbmc.executebuiltin("UpdateLocalAddons")
			xbmc.executebuiltin('ReplaceWindow(0)')
			
			xbmc.sleep(1000)
			bash('pgrep kodi.bin | xargs kill -SIGSTOP && killall -9 kodi.bin && sleep 1 && pgrep kodi.bin | xargs kill -SIGCONT',"SOFT-RESTART")
			'''---------------------------'''
	else:
		notification_common("9")
		'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + name + "_LV" + printpoint
	'''---------------------------'''
	
def mode22(name, printpoint):
	'''------------------------------
	---SUSPEND-BUTTON----------------
	------------------------------'''
	setsetting('Skin_Suspend',"true")
	setSkinSetting("1",'Skin_Suspend',"true")
	notification("..","","",1000)
	xbmc.sleep(1000)
	skinsuspend = xbmc.getInfoLabel('Skin.HasSetting(Skin_Suspend)')
	notification("...","","",1000)
	if not skinsuspend: notification("Error 1040","","",1000)
	else:
		xbmc.executebuiltin('ActivateWindow(AppearanceSettings)')
		xbmc.sleep(1000)
		if xbmc.getCondVisibility('System.IdleTime(1)') and xbmc.getInfoLabel('System.CurrentControl') == str166.encode('utf-8'):
			xbmc.executebuiltin('Action(Select)') ; xbmc.sleep(40) ; xbmc.executebuiltin('Action(Down)') ; xbmc.sleep(40) ; xbmc.executebuiltin('Action(Select)') ; xbmc.sleep(200) ; xbmc.executebuiltin('Action(Down)')
		dialogok('[COLOR=Yellow]'+'$LOCALIZE[78955]'+'[/COLOR]','$LOCALIZE[78954]','$LOCALIZE[78953]',"")
		'''---------------------------'''
	
def mode23(name, printpoint):
	'''------------------------------
	---ENTER-HTPT-BUTTON-------------
	------------------------------'''
	if Skin_Suspend == "true": setsetting('Skin_Suspend',"false")
	#xbmc.executebuiltin('ReloadSkin()')
	if not systemplatformwindows: os.system('sh /storage/.kodi/addons/service.htpt/specials/scripts/copyskin.sh')
	#xbmc.executebuiltin('RunScript(script.htpt.smartbuttons,,?mode=50)')
	#UnloadSkin()
	'''---------------------------'''
	
