
import xbmc
import os, sys
#import subprocess
#import xbmcgui, xbmcaddon
	
from variables import *
from modules import *
from shared_modules3 import get_params, urlcheck
#url, name, mode, iconimage, desc, num, viewtype = pluginend(admin)

'''---------------------------'''
try: params=get_params()
except Exception, TypeError: pass
mode=None
'''---------------------------'''
try: mode=int(params["mode"])
except: pass
'''---------------------------'''

setGeneral_ScriptON("0", General_ScriptON, str(mode))
if servicehtpt_Skin_Name != "skin.htpt":
	setSkinSetting("1",'Admin',"false")
	setSkinSetting("1",'Admin2',"false")
	'''---------------------------'''

if mode == None:
	'''------------------------------
	---MAIN-MENU---------------------
	------------------------------'''
	name = 'MAIN-MENU' ; printpoint = ""
	
	printpoint = printpoint + installaddon2(admin, 'repository.htpt', update=True)
	if not "8" in printpoint and not "9" in printpoint: printpoint = printpoint + installaddon2(admin, 'service.htpt', update=True)
	if not "8" in printpoint and not "9" in printpoint: printpoint = printpoint + installaddon2(admin, 'script.htpt.debug', update=True)
	'''---------------------------'''
	
	if not "9" in printpoint:
		if "5" in printpoint:
			notification("PROCEEDING PLEASE WAIT...","","",2000)
			xbmc.sleep(1000)
			printpoint = printpoint + "7"
			'''---------------------------'''
	
		CATEGORIES(servicehtpt_Skin_Name)
		xbmcplugin.endOfDirectory(int(sys.argv[1]))
		'''---------------------------'''

elif mode == 7:
	pass
	'''------------------------------
	---TEST-BUTTON-------------------
	------------------------------'''
	if not os.path.exists(addondata_path + "skin.htpt") or not os.path.exists(os.path.join(addondata_path,'skin.htpt','video')) or not os.path.exists(os.path.join(addondata_path,'skin.htpt','music')):
		file = "Media.zip"
		DownloadFile("https://www.dropbox.com/s/4vpc9sp2t8vg2zd/Media.zip?dl=1", file, temp_path, addondata_path, silent=True)
	printpoint = printpoint + installaddon2(admin, 'script.htpt.debug', update=False)
	printpoint = printpoint + installaddon2(admin, 'service.htpt.fix', update=False)
	printpoint = printpoint + installaddon2(admin, 'script.htpt.homebuttons', update=False)
	printpoint = printpoint + installaddon2(admin, 'script.htpt.smartbuttons', update=False)
	printpoint = printpoint + installaddon2(admin, 'script.htpt.remote', update=False)
	printpoint = printpoint + installaddon2(admin, 'script.htpt.refresh', update=False)
	printpoint = printpoint + installaddon2(admin, 'script.htpt.widgets', update=False)
	printpoint = printpoint + installaddon2(admin, 'skin.htpt', update=True)
	
elif mode == 14:
	'''------------------------------
	---HELP-BUTTON-------------------
	------------------------------'''
	xbmc.executebuiltin('RunScript(script.htpt.debug,,?mode=1)')
	'''---------------------------'''
	
elif mode == 20:
	'''------------------------------
	---INSTALL-BUTTON----------------
	------------------------------'''
	name = 'INSTALL-BUTTON'
	mode20(name, printpoint, backupname, backuppath)
	'''---------------------------'''

elif mode == 21:
	'''------------------------------
	---UNINSTALL-BUTTON--------------
	------------------------------'''
	name = 'UNINSTALL-BUTTON'
	mode21(name, printpoint, backupname, backupname2, backuppath)
	'''---------------------------'''

elif mode == 22:
	'''------------------------------
	---SUSPEND-BUTTON----------------
	------------------------------'''
	name = 'SUSPEND-BUTTON'
	mode22(name, printpoint)
	'''---------------------------'''

elif mode == 23:
	'''------------------------------
	---ENTER-HTPT-BUTTON-------------
	------------------------------'''
	name = 'ENTER-HTPT-BUTTON'
	mode23(name, printpoint)
	'''---------------------------'''

elif mode == 27:
	'''------------------------------
	---STARTUP-APPLY-----------------
	------------------------------'''
	name = 'STARTUP-APPLY'
	printpoint = ""
	idstr_len = len(idstr)
	
	if (Skin_Installed == "true" or os.path.exists(skininstalledtxt2) or not str74485.encode('utf-8') in idstr or User_ID2 != "" or (idstr_len != "11" and not str79041 in id9str)) and not admin3:
		setSkinSetting("1",'ID40',"true") #ID40
		if not id40str: xbmc.sleep(1000)
		id40str = xbmc.getInfoLabel('Skin.HasSetting(ID40)')
		printpoint = printpoint + "1"
		
	if (User_ID2 != datenowS and id2str != datenowS) and os.path.exists(addons_path + 'skin.htpt'):
		setsetting('Skin_Suspend',"false")
		if servicehtpt_Skin_Name == "skin.htpt": setSkinSetting("1",'Skin_Suspend',"false")
		printpoint = printpoint + "2"
		'''---------------------------'''
	else:
		setsetting('Skin_Suspend',"true")
		if servicehtpt_Skin_Name == "skin.htpt": setSkinSetting("1",'Skin_Suspend',"true")
		printpoint = printpoint + "3"
		'''---------------------------'''
		
	if servicehtpt_Skin_Name == "skin.htpt":
		
		setUserID(admin, User_ID, idstr, htpt_a1, htpt_a2)
		
		setUserID2(admin, User_ID2, id2str)
		
		
		if Skin_Installed == "true" or os.path.exists(skininstalledtxt2):
			setsetting('Skin_FirstBoot', "true")
			if os.path.exists(skininstalledtxt2) and Skin_Installed != "true":
				setsetting('Skin_Installed', "true")
				setsetting('User_ID2', datenowS)
				'''---------------------------'''
			addons = ['service.htpt.fix', 'script.htpt.smartbuttons']
			for addon in addons:
				if xbmc.getCondVisibility('System.HasAddon('+ addon +')') and os.path.exists(addons_path + addon): printpoint = printpoint + "6"
				else: printpoint = printpoint + "9"
				'''---------------------------'''
			
			if not "9" in printpoint:
				printpoint = printpoint + "7"
				if User_ID1 != id1str and User_ID1 != "": setSkinSetting("0",'ID1',User_ID1)
				setsetting_custom1('service.htpt.fix','Fix_5',"true")
				setsetting_custom1('service.htpt.fix','Fix_100',"true")
				setsetting_custom1('service.htpt.fix','Fix_101',"true")
				'''---------------------------'''
				xbmc.executebuiltin('RunScript(script.htpt.smartbuttons,,?mode=59)')
				dialogok("Choose your country", "This option will effect the whole system!", "You may change this setting at anytime.", "")
				returned = dialogyesno('$LOCALIZE[76177]', '$LOCALIZE[76178]', yes=True)
				if returned == 'ok': setSkinSetting("1",'AllowDebug',"true")
				else: setSkinSetting("1",'AllowDebug',"false")
				notification('$LOCALIZE[76179]',"","",2000)
				'''---------------------------'''
				returned = dialogyesno('$LOCALIZE[79516]', '$LOCALIZE[79608]')
				if returned == 'ok': setSkinSetting("1",'CustomGUI',"true")
				else: setSkinSetting("1",'CustomGUI',"false")
				notification('$LOCALIZE[76179]',"","",2000)
				'''---------------------------'''
				addon = 'script.htpt.debug'
				if xbmc.getCondVisibility('System.HasAddon('+ addon +')') and os.path.exists(addons_path + addon): xbmc.executebuiltin('RunScript(script.htpt.debug,,?mode=20)')
				
				
				dialogok(addonString(89), addonString(82), addonString(88), "") #Installation almost done!
				#xbmc.executebuiltin('RunScript(service.htpt.fix,,?mode=3)')
				xbmc.sleep(200) ; startupW = xbmc.getCondVisibility('Window.IsVisible(Startup.xml)')
				if xbmc.getCondVisibility('Control.HasFocus(8)') + startupW: xbmc.executebuiltin('Action(Select)')
				'''---------------------------'''
				xbmc.sleep(4000)
				xbmc.executebuiltin('Action(reloadkeymaps)')
				setsetting('Skin_Installed', "false")
				if os.path.exists(skininstalledtxt2):
					if systemplatformwindows: cmd('DEL '+skininstalledtxt2+' /F /Q >NUL', 'Skin_Installed.txt')
					else: bash('rm -rf '+skininstalledtxt2+'', 'Skin_Installed.txt')
					'''---------------------------'''
		elif Skin_FirstBoot != "false":
			setsetting_custom1('script.htpt.debug','ModeOn_20',"true")
			setsetting('Skin_FirstBoot', "false")
			'''---------------------------'''
		else: pass
			
			
		if id40str:
			printpoint = printpoint + "8"
			'''---------------------------'''
			'''idstr = USERNAME EN , id1str = USERNAME HE, id2str = INSTALLATION DATE, id3str = WARRENTY END, id4str = ADDRESS, id5str = TELEPHONE NUMBER, id6str = PAYMENT TERMS,
			id7str = QUESTION, id8str = TECHNICAL NAME, id9str = CODE RED, id10str = HTPT'S MODEL, ID11 = MAC1, ID12 = MAC2'''
			if id1str == "":
				 if User_ID1 != "": setSkinSetting("0",'ID1',User_ID1)
				 else: returned = dialogkeyboard(id1str, '$LOCALIZE[1014]', 0, '1', 'ID1', '') #ID1
			if id3str == "": setSkinSetting("0",'ID3',"None") #ID3
			if id6str == "": setSkinSetting("0",'ID6',"None") #ID6
			if id7str != "": setSkinSetting("0",'ID7',"") #ID7
			if id8str == "": setSkinSetting("0",'ID8',"None") #ID8
			if id9str != "": setSkinSetting("0",'ID9',"") #ID9
			if id10str == "": setSkinSetting("0",'ID10','UNKNOWN') #ID10
			'''---------------------------'''
			if mac1str == "" or admin and not systemplatformwindows:
				MAC1_ = bash("ifconfig -a | grep -e 'eth' | awk {'print $5'}","LAN MAC")
				if MAC1_ != "":
					MAC1_ = MAC1_.replace("\n","")
					setSkinSetting("0",'MAC1',MAC1_)
					'''---------------------------'''
			if mac2str == "":
				MAC2_ = bash("ifconfig -a | grep -e 'wlan' | awk {'print $5'}","WLAN MAC")
				MAC2_ = MAC2_.replace("\n","")
				setSkinSetting("0",'MAC2',MAC2_)
				'''---------------------------'''
			#if connected3 == "true" and connected2 != "true": 
				#if macstr != mac1str or mac1str == "" or verrorstr == "7020": setSkinSetting("0",'MAC1',macstr)
				'''---------------------------'''
		else: printpoint = printpoint + "9"
		'''---------------------------'''
	
#xbmc.executebuiltin('Container.Refresh')
#xbmc.executebuiltin('Container.Update')
if TypeError != "": extra = space + "TypeError" + space2 + str(TypeError)
print printfirst + "default.py_LV" + printpoint + space + "mode" + space2 + str(mode) + space + "name" + space2 + str(name) + extra
setGeneral_ScriptON("1", General_ScriptON, str(mode))


#pluginend2(admin, containerfolderpath, viewtype)