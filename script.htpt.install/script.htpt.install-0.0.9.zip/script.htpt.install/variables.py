'''------------------------------
---shared_variables--------------
------------------------------'''
import xbmc, xbmcaddon, sys, os


currentPath          = xbmcaddon.Addon('script.htpt.install').getAddonInfo("path")
containerfolderpath = xbmc.getInfoLabel('Container.FolderPath') ; printpoint3 = ""
if not 'script.htpt.install' in containerfolderpath and xbmc.getCondVisibility('System.HasAddon(service.htpt)'):
	servicehtptPath          = xbmcaddon.Addon('service.htpt').getAddonInfo("path")
	sharedlibDir = os.path.join(servicehtptPath, 'resources', 'lib', 'shared')
	if os.path.exists(sharedlibDir):
		sys.path.insert(0, sharedlibDir)
		printpoint3 = printpoint3 + "7"
		'''---------------------------'''
	else: printpoint3 = printpoint3 + "9"

if printpoint3 != "7":
	currentlibDir = os.path.join(currentPath, 'resources', 'lib')
	sys.path.insert(0, currentlibDir)
	'''---------------------------'''
from shared_variables import *
print "script.htpt.install-variables_LV" + printpoint3 + space + "containerfolderpath" + space2 + str(containerfolderpath)
'''---------------------------'''	

getsetting         = xbmcaddon.Addon().getSetting
setsetting         = xbmcaddon.Addon().setSetting
addonName          = xbmcaddon.Addon().getAddonInfo("name")
addonString        = xbmcaddon.Addon().getLocalizedString
addonID          = xbmcaddon.Addon().getAddonInfo("id")
addonPath          = xbmcaddon.Addon().getAddonInfo("path")
addonVersion          = xbmcaddon.Addon().getAddonInfo("version")

printfirst = addonName + ": !@# "
'''---------------------------'''
General_ScriptON = getsetting('General_ScriptON')
'''---------------------------'''
Skin_Suspend = getsetting('Skin_Suspend')
Skin_Installed = getsetting('Skin_Installed')
Skin_FirstBoot = getsetting('Skin_FirstBoot')
'''---------------------------'''
User_ID = getsetting('User_ID')
User_ID1 = getsetting('User_ID1')
User_ID2 = getsetting('User_ID2')
User_ID2_ = getsetting('User_ID2_')
User_ID4 = getsetting('User_ID4')
User_ID5 = getsetting('User_ID5')
'''---------------------------'''

printpoint = ""
TypeError = ""
extra = ""
name = ""
backupname = "htpt_backup"
backupname2 = "htpt_backup2"
backuppath = home_path
#backupfullpath = os.path.join(backuppath, backupname) #UNUSED HOMEPATH//
#backupfullpath2 = os.path.join(backuppath, backupname2) #UNUSED HOMEPATH//
if systemplatformwindows: restorepath = home_path
else: restorepath = '/storage/'
currentcopydir = os.path.join(currentPath, 'specials', 'scripts', 'copy', '')
htptinstallmedia_path = os.path.join(currentPath,'resources', 'media', '')
htptintalledcopy_path = os.path.join(addonPath, 'specials', 'scripts', 'copy','')
skininstalledtxt = os.path.join(htptintalledcopy_path, 'Skin_Installed.txt')

scriptxbmcbackup_remote_path_2_ = "special://userdata/addon_data/skin.htpt/userdata/backup/" #temp