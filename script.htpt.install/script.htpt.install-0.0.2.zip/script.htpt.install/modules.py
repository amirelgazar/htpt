# -*- coding: utf-8 -*-
#import xbmc, os, subprocess, sys
#import xbmc, xbmcgui, xbmcaddon
import xbmc, xbmcgui, xbmcaddon
import subprocess, os, sys
import xbmcplugin
import urllib
import urllib2
import re

from variables import *
from shared_modules import *
from shared_modules3 import addDir


def CATEGORIES(servicehtpt_Skin_Name):
	
	addon = 'skin.htpt'
	if xbmc.getCondVisibility('System.HasAddon('+ addon +')') and os.path.exists(addons_path + addon):
		if servicehtpt_Skin_Name == addon:
			addDir(addonString(11),'',21,htptinstallmedia_path + 'bin.png',addonString(101),'1',500) #הסרת מערכת
			if Skin_Suspend == "false": addDir(addonString(12),'',22,htptinstallmedia_path + 'linkbroken.png',addonString(102),'1',500) #השהיית מערכת
			'''---------------------------'''
		else:
			addDir(addonString(13),'',23,htptinstallmedia_path + 'htpt.png',addonString(103) % (servicehtpt_Skin_Name),'1',500) #כניסה ל-HTPT
			'''---------------------------'''
	else:
		addDir(addonString(10),'',20,htptinstallmedia_path + 'software.png',addonString(100),'1',500) #התקנת מערכת
		'''---------------------------'''
	
	if admin and not admin2: addDir("Test7",'',7,htptinstallmedia_path + 'caa2.png','','1',500) #Test
	#xbmc.executebuiltin('Container.Refresh')
	
def mode20(name, printpoint, backupname, backuppath):
	'''------------------------------
	---INSTALL-BUTTON----------------
	------------------------------'''
	#id40str = xbmc.getInfoLabel('Skin.HasSetting(ID40)')
	#verrorstr = xbmc.getInfoLabel('$VAR[VERROR]')
	
	returned = dialogkeyboard(User_ID1, '$LOCALIZE[1014]', 0, '1', 'User_ID1', 'script.htpt.install') #ID1
	'''---------------------------'''
	#datenowS = datewnowS.replace("-",
	dialogok(addonString(93), addonString(94), "", "") #Backup Current System
	
	notification(addonString(93), ".", "", 1000)
	CreateZip(userdata_path.encode('utf-8'), backuppath + backupname2, filteron=['guisettings.xml'], filteroff=[], level=0, append=False, ZipFullPath=True, temp=False)
	'''---------------------------'''
	CreateZip(config_path, backuppath + backupname, filteron=['samba.conf', 'autostart.sh'], level=0, append=False, ZipFullPath=True, temp=True)
	CreateZip(emulators_path, backuppath + backupname, filteroff=['retroarch'], append=True, ZipFullPath=True, temp=True)
	notification(addonString(93), "..", "", 1000)
	CreateZip(userdata_path.encode('utf-8'), backuppath + backupname, filteron=['advancedsettings.xml', 'sources.xml', 'keymaps'], filteroff=[], level=0, append=True, ZipFullPath=True, temp=True)
	notification(addonString(93), "..", "", 1000)
	returned = CreateZip(addondata_path, backuppath + backupname, filteron=['plugin.video.genesis', 'plugin.program.advanced.launcher', 'metadata.universal', 'metadata.tvdb.com'], filteroff=[], append="End", ZipFullPath=True, temp=True)
		
	if returned != 'ok':
		returned = dialogyesno("Backup Failed", "Proceed without backup?")
		if returned == 'ok': printpoint = printpoint + "4"
		else: notification_common("9")
		'''---------------------------'''
	else: printpoint = printpoint + "4"
		
	if "4" in printpoint:
		
		addon = 'script.htpt.debug'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')') and os.path.exists(addons_path + addon): printpoint = printpoint + "7"
		else:
			if os.path.exists(addons_path + addon): removeaddons(addon, "123")
			url = findVersion(gh1+gh2+addon+'/'+addon+'-', Ver='0.1.17')
				
			if url != "":
				DownloadFile(url, addon+".zip", packages_path, addons_path, silent=True)
				if os.path.exists(addons_path + addon): printpoint = printpoint + "5"
				else: printpoint = printpoint + "9" ; notification_common("9")
				'''---------------------------'''
			else: printpoint = printpoint + "9"
		
		addon = 'service.htpt.fix'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')') and os.path.exists(addons_path + addon): printpoint = printpoint + "7"
		else:
			if os.path.exists(addons_path + addon): removeaddons(addon, "23")
			url = findVersion(gh1+gh2+addon+'/'+addon+'-', Ver='0.1.27')
				
			if url != "":
				DownloadFile(url, addon+".zip", packages_path, addons_path, silent=True)
				if os.path.exists(addons_path + addon): printpoint = printpoint + "5"
				else: printpoint = printpoint + "9" ; notification_common("9")
				'''---------------------------'''
			else: printpoint = printpoint + "9"
		
		addon = 'script.htpt.homebuttons'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')') and os.path.exists(addons_path + addon): printpoint = printpoint + "7"
		else:
			if os.path.exists(addons_path + addon): removeaddons(addon, "23")
			url = findVersion(gh1+gh2+addon+'/'+addon+'-', Ver='0.1.22')
				
			if url != "":
				DownloadFile(url, addon+".zip", packages_path, addons_path, silent=True)
				if os.path.exists(addons_path + addon): printpoint = printpoint + "5"
		
		addon = 'script.htpt.smartbuttons'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')') and os.path.exists(addons_path + addon): printpoint = printpoint + "7"
		else:
			if os.path.exists(addons_path + addon): removeaddons(addon, "23")
			url = findVersion(gh1+gh2+addon+'/'+addon+'-', Ver='0.0.4')
				
			if url != "":
				DownloadFile(url, addon+".zip", packages_path, addons_path, silent=True)
				if os.path.exists(addons_path + addon): printpoint = printpoint + "5"
		
		addon = 'script.htpt.remote'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')') and os.path.exists(addons_path + addon): printpoint = printpoint + "7"
		else:
			if os.path.exists(addons_path + addon): removeaddons(addon, "23")
			url = findVersion(gh1+gh2+addon+'/'+addon+'-', Ver='0.1.4')
				
			if url != "":
				DownloadFile(url, addon+".zip", packages_path, addons_path, silent=True)
				if os.path.exists(addons_path + addon): printpoint = printpoint + "5"
			
		addon = 'script.htpt.refresh'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')') and os.path.exists(addons_path + addon): printpoint = printpoint + "7"
		else:
			if os.path.exists(addons_path + addon): removeaddons(addon, "23")
			url = findVersion(gh1+gh2+addon+'/'+addon+'-', Ver='0.1.25')
				
			if url != "":
				DownloadFile(url, addon+".zip", packages_path, addons_path, silent=True)
				if os.path.exists(addons_path + addon): printpoint = printpoint + "5"
				
		addon = 'skin.htpt'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')') and os.path.exists(addons_path + addon): printpoint = printpoint + "7"
		else:
			if os.path.exists(addons_path + addon): removeaddons(addon, "13")
			url = findVersion(gh1+gh2+addon+'/'+addon+'-', Ver='0.1.20')
				
			if url != "":
				DownloadFile(url, addon+".zip", packages_path, addons_path, silent=True)
				if os.path.exists(addons_path + addon): printpoint = printpoint + "5"
				else: printpoint = printpoint + "9" ; notification_common("9")
				'''---------------------------'''
			else: printpoint = printpoint + "9"

	if "5" in printpoint:
		xbmc.executebuiltin("UpdateLocalAddons")
		xbmc.sleep(2000)
		'''---------------------------'''
	
	if not "9" in printpoint:
		'''------------------------------
		---INSTALLATION-SUCCESSFULLY-----
		------------------------------'''
		addon = 'script.htpt.debug'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')') and os.path.exists(addons_path + addon): xbmc.executebuiltin('RunScript(script.htpt.debug,,?mode=20)')
		htptversion = xbmc.getInfoLabel('System.AddonVersion(skin.htpt)')
		printpoint = printpoint + "7"
		'''---------------------------'''
		setSkinSetting("1",'ID40',"true")
		setsetting('User_ID2', datenowS)
		setsetting('Skin_Installed', "true")
		
		xbmc.executebuiltin('ReplaceWindow(0)')
		xbmc.sleep(500)
		dialogok(addonString(91), addonString(92) % (htptversion), "", "")
		if not systemplatformwindows:
			notification(".","","",1000)
			os.system('sh /storage/.kodi/addons/service.htpt/specials/scripts/copyonce.sh')
			os.system('sh /storage/.kodi/addons/service.htpt/specials/scripts/copy2.sh')
			notification("..","","",1000)
			xbmc.sleep(1000)
			notification("...","","",1000)
			os.system('sh /storage/.kodi/addons/service.htpt/specials/scripts/copyskin.sh')
			'''---------------------------'''
		xbmc.sleep(1000)
		bash('pgrep kodi.bin | xargs kill -SIGSTOP && killall -9 kodi.bin && sleep 1 && pgrep kodi.bin | xargs kill -SIGCONT',"SOFT-RESTART")
		xbmc.sleep(1000)
		xbmc.executebuiltin('XBMC.Reset()')
		'''---------------------------'''
	
	else: dialogok(str257 + space + "1071", '$LOCALIZE[113]', "", "")
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + name + "_LV" + printpoint + space + "idstr" + space2 + idstr + space + "id40str" + space2 + id40str + space + "MAC" + space2 + macstr
	'''---------------------------'''

def mode21(name, printpoint, backupname, backupname2, backuppath):
	'''------------------------------
	---UNINSTALL-BUTTON--------------
	------------------------------'''
	
	returned = dialogyesno(addonString(11),addonString(98))
	if returned == 'ok':
		'''------------------------------
		---REMOVE------------------------
		------------------------------'''
		if systemplatformwindows: dialogok("Uninstall isn't available for Windows platform!","","","")
		else:
			if systemhasaddon_htptdebug: xbmc.executebuiltin('RunScript(script.htpt.debug,,?mode=21)')
			notification("Removing",'Please Wait',"",10000)
			'''---------------------------'''
			#bash('rm -rf '+config_path+'samba.conf','samba.conf')
			bash('rm -rf '+config_path+'autostart.sh','autostart.sh')
			'''---------------------------'''
			bash('rm -rf '+emulators_path+'',"emulators")
			bash('rm -rf /storage/*.log',"logs")
			bash('rm -rf '+addondata_path+'plugin.program.advanced.launcher/launchers.xml','launchers.xml')
			'''---------------------------'''
			bash('rm -rf '+userdata_path+'advancedsettings.xml','advancedsettings.xml')
			bash('rm -rf '+userdata_path+'sources.xml','sources.xml')
			'''---------------------------'''
			bash('rm -rf '+keymaps_path+'','keymaps')
			'''---------------------------'''
			
			'''------------------------------
			---USERDATA+PACKAGE--------------
			------------------------------'''
			addonsL = []
			
			addonsL.append('plugin.video.genesis')
			addonsL.append('plugin.video.israelive')
			addonsL.append('plugin.video.p2p-streams')
			addonsL.append('plugin.video.youtube')
			addonsL.append('metadata.universal')
			addonsL.append('metadata.tvdb.com')
			'''---------------------------'''
			removeaddons(addonsL,"23")
			'''---------------------------'''
			
			'''------------------------------
			---ALL---------------------------
			------------------------------'''
			addonsL = []
			
			addonsL.append('emulator.retroarch')
			addonsL.append('browser.chromium-browser')
			addonsL.append('service.skin.widgets')
			addonsL.append('screensaver.randomtrailers')
			addonsL.append('screensaver.picture.slideshow')
			addonsL.append('script.moviequiz')
			
			addonsL.append('script.htpt.debug')
			addonsL.append('script.htpt.emu')
			addonsL.append('script.htpt.homebuttons')
			addonsL.append('script.htpt.smartbuttons')
			addonsL.append('script.htpt.refresh')
			addonsL.append('script.htpt.remote')
			addonsL.append('service.htpt.fix')
			addonsL.append('plugin.video.htpt.gopro')
			addonsL.append('plugin.video.htpt.kids')
			addonsL.append('plugin.video.htpt.music')
			addonsL.append('skin.htpt')
			addonsL.append('service.htpt')
			'''---------------------------'''
			removeaddons(addonsL,"123")
			'''---------------------------'''
			from variables import *
			
			if os.path.exists(backuppath + backupname + ".zip"):
				notification("Using Restore point", "From Last Backup", "", 4000)
				ExtractAll(backuppath + backupname + ".zip", home_path)
			
			if os.path.exists(backuppath + backupname2 + ".zip"):
				returned = dialogyesno(addonString(87) % ('guisettings.xml'), addonString(86))
				if returned == 'ok':
					notification("Using Restore point", "From Last Backup", "", 4000)
					ExtractAll(backuppath + backupname2 + ".zip", home_path)
				else: pass
			
			xbmc.executebuiltin("UpdateLocalAddons")
			dialogok("Uninstall Complete!","","","")
			xbmc.executebuiltin('ReplaceWindow(0)')
			xbmc.sleep(1000)
			bash('pgrep kodi.bin | xargs kill -SIGSTOP && killall -9 kodi.bin && sleep 1 && pgrep kodi.bin | xargs kill -SIGCONT',"SOFT-RESTART")
			'''---------------------------'''
	else:
		notification_common("9")
		'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + name + "_LV" + printpoint
	'''---------------------------'''
	
def mode22(name, printpoint):
	'''------------------------------
	---SUSPEND-BUTTON----------------
	------------------------------'''
	setsetting('Skin_Suspend',"true")
	setSkinSetting("1",'Skin_Suspend',"true")
	notification("..","","",1000)
	xbmc.sleep(1000)
	skinsuspend = xbmc.getInfoLabel('Skin.HasSetting(Skin_Suspend)')
	notification("...","","",1000)
	if not skinsuspend: notification("Error 1040","","",1000)
	else:
		xbmc.executebuiltin('ActivateWindow(AppearanceSettings)')
		xbmc.sleep(1000)
		if xbmc.getCondVisibility('System.IdleTime(1)') and xbmc.getInfoLabel('System.CurrentControl') == str166.encode('utf-8'):
			xbmc.executebuiltin('Action(Select)') ; xbmc.sleep(40) ; xbmc.executebuiltin('Action(Down)') ; xbmc.sleep(40) ; xbmc.executebuiltin('Action(Select)') ; xbmc.sleep(200) ; xbmc.executebuiltin('Action(Down)')
		dialogok('[COLOR=Yellow]'+'$LOCALIZE[78955]'+'[/COLOR]','$LOCALIZE[78954]','$LOCALIZE[78953]',"")
		'''---------------------------'''
	
def mode23(name, printpoint):
	'''------------------------------
	---ENTER-HTPT-BUTTON-------------
	------------------------------'''
	if Skin_Suspend == "true": setsetting('Skin_Suspend',"false")
	#xbmc.executebuiltin('ReloadSkin()')
	if not systemplatformwindows: os.system('sh /storage/.kodi/addons/service.htpt/specials/scripts/copyskin.sh')
	#xbmc.executebuiltin('RunScript(script.htpt.smartbuttons,,?mode=50)')
	#UnloadSkin()
	'''---------------------------'''
	
