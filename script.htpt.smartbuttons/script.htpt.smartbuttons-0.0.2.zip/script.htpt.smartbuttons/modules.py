#import xbmc, os, subprocess, sys
#import xbmc, xbmcgui, xbmcaddon
import xbmc, xbmcgui, xbmcaddon
import subprocess, os, sys
#import datetime, time
from variables import *
from shared_modules import *

def mode0(admin):
	'''------------------------------
	---TEST--------------------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	value = []
	value.append("copylibrarydir" + space2 + copylibrarydir + newline)
	value.append("library_path" + space2 + library_path + newline)
	
	print printfirst + "mode0-test: "  + str(value)
	'''---------------------------'''
	
def mode1(admin):
	'''------------------------------
	---SMART-KEYBOARD-SAVE-VALUE-----
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	if General_ScriptON != "true":
		'''---------------------------'''
		printpoint = printpoint + "1"
		heading = xbmc.getInfoLabel('Control.GetLabel(311)')
		#keyboard = xbmc.Keyboard(Current_Input,heading,int(Current_Option))
		#input = keyboard.getText()
		#setsetting_custom1('script.htpt.smartkeyboard','Current_Input',input)
		#setGeneral_ScriptON("0", General_ScriptON, str(mode))
		'''---------------------------'''
		input = dialogkeyboard(Current_Input, heading, 0, '1', "", "")
		#keyboard = xbmc.Keyboard()
		#input = keyboard.getText()
		#input = "test"
		setsetting_custom1('script.htpt.smartkeyboard','Current_Input',input)
		setsetting_custom1('script.htpt.smartkeyboard','Current_Option',0)
		'''------------------------------
		---SMART-KEYBOARD-SAVE-VALUE-----
		------------------------------'''
		if input != "skip":
			printpoint = printpoint + "2"
			setSkinSetting("0", 'smartkeyboardH0', input)
			xbmc.sleep(1000) #time to set setting
			if not input in smartkeyboardHL:
				'''------------------------------
				---NEW-VALUE---------------------
				------------------------------'''
				printpoint = printpoint + "3"
				setSkinSetting("0", 'smartkeyboardH5', smartkeyboardH4)
				setSkinSetting("0", 'smartkeyboardH4', smartkeyboardH3)
				setSkinSetting("0", 'smartkeyboardH3', smartkeyboardH2)
				setSkinSetting("0", 'smartkeyboardH2', smartkeyboardH1)
				setSkinSetting("0", 'smartkeyboardH1', input)
				'''---------------------------'''
			else:
				'''------------------------------
				---EXIST-VALUE-------------------
				------------------------------'''
				printpoint = printpoint + "4"
				if input != smartkeyboardH1:
					if input == smartkeyboardH2:
						printpoint = printpoint + "5"
						setSkinSetting("0", 'smartkeyboardH1', input)
						setSkinSetting("0", 'smartkeyboardH2', smartkeyboardH1)
						'''---------------------------'''
					elif input == smartkeyboardH3:
						printpoint = printpoint + "6"
						setSkinSetting("0", 'smartkeyboardH1', input)
						setSkinSetting("0", 'smartkeyboardH3', smartkeyboardH1)
						'''---------------------------'''
					elif input == smartkeyboardH4:
						printpoint = printpoint + "7"
						setSkinSetting("0", 'smartkeyboardH1', input)
						setSkinSetting("0", 'smartkeyboardH4', smartkeyboardH1)
						'''---------------------------'''
					elif input == smartkeyboardH5:
						printpoint = printpoint + "8"
						setSkinSetting("0", 'smartkeyboardH1', input)
						setSkinSetting("0", 'smartkeyboardH5', smartkeyboardH1)
						'''---------------------------'''
					else: printpoint = printpoint + "9"
				else: printpoint = printpoint + "9"
				'''---------------------------'''
		
		setsetting_custom1('script.htpt.smartkeyboard','Current_Input',"")
		setsetting_custom1('script.htpt.smartkeyboard','Current_Option',0)

	'''---------------------------'''
	#setGeneral_ScriptON("1", General_ScriptON, str(mode))
	'''---------------------------'''

def mode2(admin):
	'''------------------------------
	---SMART-KEYBOARD-COPY-----------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	printpoint = printpoint + "1"
	#keyboard.doModal()
	#input2 = keyboard.getText()
	#notification("input2: " + input2,"input: " + input,"",2000)
	setSkinSetting("0", "smartkeyboardC" + smartkeyboardPN, Current_Input)
	'''---------------------------'''

def mode3(admin):
	'''------------------------------
	---SMART-KEYBOARD-HISTORY--------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	import json
	xbmc.executebuiltin('Action(Close)')
	xbmc.sleep(200)
	if smartkeyboardHN == '1': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH1 +'","done":false}}')
	if smartkeyboardHN == '2': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH2 +'","done":false}}')
	if smartkeyboardHN == '3': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH3 +'","done":false}}')
	if smartkeyboardHN == '4': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH4 +'","done":false}}')
	if smartkeyboardHN == '5': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH5 +'","done":false}}')
	xbmc.executebuiltin('SetFocus(3000)')
	'''---------------------------'''

def mode4(admin):
	'''------------------------------
	---SMART-KEYBOARD-PASTE----------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	import json
	xbmc.executebuiltin('Action(Close)')
	xbmc.sleep(200)
	if smartkeyboardPN == '1': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC1 +'","done":false}}')
	if smartkeyboardPN == '2': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC2 +'","done":false}}')
	if smartkeyboardPN == '3': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC3 +'","done":false}}')
	if smartkeyboardPN == '4': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC4 +'","done":false}}')
	if smartkeyboardPN == '5': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC5 +'","done":false}}')
	xbmc.executebuiltin('SetFocus(3000)')
	'''---------------------------'''
	
def mode5(admin):
	'''------------------------------
	---?--------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	'''---------------------------'''

def mode8(admin):
	'''------------------------------
	---SMART-SUBTITLE-SEARCH---------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	import json
	xbmc.executebuiltin('SendClick(160)')
	input = ""
	isTV = 'false'
	isMovie = 'false'
	'''---------------------------'''
	
	#if scripthtptrefresh_Current_M_T != "" and scripthtptrefresh_Current_Name != "": input = scripthtptrefresh_Current_Name
	if videoplayertvshowtitle != "" and videoplayerseason != "" and videoplayerepisode != "": isTV = 'true'
	elif videoplayertitle != "" and (videoplayeryear != "" or videoplayercountry != "" or videoplayertagline != ""): isMovie = 'true'
	'''---------------------------'''
	if isMovie == 'true': input = videoplayertitle + space + videoplayeryear + space + videoplayervideoresolution + space + videoplayervideocodec
	elif videoplayertitle != "": input = videoplayertitle
	elif isTV == 'true':
		seasonN = int(videoplayerseason)
		episodeN = int(videoplayerepisode)
		if seasonN < 10 and episodeN < 10: input = videoplayertvshowtitle + " " + 'S0' + videoplayerseason + 'E0' + videoplayerepisode
		if seasonN > 10 and episodeN > 10: input = videoplayertvshowtitle + " " + 'S' + videoplayerseason + 'E' + videoplayerepisode
		if seasonN > 10 and episodeN < 10: input = videoplayertvshowtitle + " " + 'S' + videoplayerseason + 'E0' + videoplayerepisode
		if seasonN < 10 and episodeN > 10: input = videoplayertvshowtitle + " " + 'S0' + videoplayerseason + 'E' + videoplayerepisode
		'''---------------------------'''
	dialogkeyboard = xbmc.getCondVisibility('Window.IsVisible(DialogKeyboard.xml)')
	count = 0
	while count < 10 and not dialogkeyboard and not xbmc.abortRequested:
		count += 1
		xbmc.sleep(100)
		dialogkeyboard = xbmc.getCondVisibility('Window.IsVisible(DialogKeyboard.xml)')
		'''---------------------------'''
	if count < 10: xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ input +'","done":false}}')
	'''---------------------------'''
	print printfirst + "dialogsubtitles: " + "videoplayertvshowtitle = " + videoplayertvshowtitle + " | videoplayerseason = " + videoplayerseason + " | videoplayerepisode = " + videoplayerepisode + " | videoplayertitle = " + videoplayertitle + " | videoplayeryear = " + videoplayeryear + " | videoplayertitle = " + videoplayertitle + space + "playertitle =" + playertitle + space + "VideoCodec" + space2 + videoplayervideocodec + space + "VideoResolution" + space2 + videoplayervideoresolution
	'''---------------------------'''
	
def mode10(admin):
	'''------------------------------
	---LIVE-TV-BUTTON----------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	if connected:
		printpoint = ""
		if livetvbutton2:
			name = "livetvbutton2"
			xbmc.executebuiltin('ActivateWindow(TVChannels)')
			xbmc.sleep(1000)
			mypvrchannels = xbmc.getCondVisibility('Window.IsVisible(MyPVRChannels.xml)')
			count = 0
			while count < 10 and not mypvrchannels and not xbmc.abortRequested:
				xbmc.sleep(100)
				count += 1
				mypvrchannels = xbmc.getCondVisibility('Window.IsVisible(MyPVRChannels.xml)')
				xbmc.sleep(100)
			if mypvrchannels:
				containerfoldername = xbmc.getInfoLabel('Container.FolderName')
				containernumitems = xbmc.getInfoLabel('Container.NumItems')
				if int(containernumitems) < 2: printpoint = printpoint + "8"
				elif containerfoldername != str19287.encode('utf-8'): dialogok('[COLOR=Yellow]' + '$LOCALIZE[19051]' + '[/COLOR]', str79548 % (containernumitems), str79549, "")

			else: printpoint = printpoint + "9"
			if "8" in printpoint or "9" in printpoint:
				xbmc.executebuiltin('RunAddon(plugin.video.israelive)')
				dialogkaitoastW = xbmc.getCondVisibility('Window.IsVisible(DialogKaiToast.xml)')
				count = 0
				while count < 10 and not dialogkaitoastW and not xbmc.abortRequested:
					count += 1
					xbmc.sleep(200)
					dialogkaitoastW = xbmc.getCondVisibility('Window.IsVisible(DialogKaiToast.xml)')
				if count == 10:
					xbmc.executebuiltin('RunScript(script.htpt.smartbuttons,,?mode=10)')
			
		else:
			if livetvbutton: name = "livetvbutton"
			else: name = "livetvcustom"
			returned = ActivateWindow("0", 'plugin.video.israelive', 'plugin://plugin.video.israelive/', 1, wait=True)
			#returned = ActivateWindow("1", 'plugin.video.israelive', 'plugin://plugin.video.israelive/', 1, wait=True)
			if returned == "ok":
				printpoint = printpoint + "1"
				pass
			containernumitems = xbmc.getInfoLabel('Container.NumItems')
			containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
			systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
			
		if admin: print printfirst + name + "_LV" + printpoint + "containernumitems" + space2 + containernumitems + space + "containerfolderpath" + space2 + containerfolderpath
	else: notification_common("5")
	'''---------------------------'''

def mode12(admin):
	'''------------------------------
	---UPDATE-LIVE-TV-PVR------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	if connected:
		notification("UPDATE-LIVE-TV-PVR","","",1000)
		if not systemplatformwindows:
			bash('rm -rf /storage/.kodi/userdata/addon_data/plugin.video.israelive',"plugin.video.israelive - userdata folder")
			bash('rm -rf /storage/.kodi/userdata/Database/Epg8.db',"Epg8.db")
		xbmc.sleep(1000)
		xbmc.executebuiltin('RunScript(plugin.video.israelive,,mode=32)') #Update IPTVSimple settings
		xbmc.sleep(500)
		xbmc.executebuiltin('RunScript(plugin.video.israelive,,mode=34)') #REFRESH ALL SETTINGS
		'''---------------------------'''
	else: notification_common("5")
	'''---------------------------'''
	
def mode15(name):
	'''------------------------------
	---SPORT-1-LIVE------------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	returned = supportcheck(name, ["A","B"])
	if connected and returned == "ok":
		printpoint = ""
		count = ""
		systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
		returned = ActivateWindow("1", 'plugin.video.vdubt', 'plugin://plugin.video.vdubt/', 0, wait=True)
		if returned == "ok2":
			printpoint = printpoint + "1"
			systemcurrentcontrol = findin_systemcurrentcontrol("0","[..]",100,'Action(PageUp)','')
			systemcurrentcontrol = findin_systemcurrentcontrol("0","[..]",100,'Action(PageUp)','Action(Down)')
			systemcurrentcontrol = findin_systemcurrentcontrol("1","LIVE SPORTS",100,'','Action(Select)')
			xbmc.sleep(500)
			dialogbusyW = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
			containernumitems = xbmc.getInfoLabel('Container.NumItems')
			count = 0
			while count < 10 and (dialogbusyW or containernumitems != "0") and not xbmc.abortRequested:
				count += 1
				xbmc.sleep(200)
				dialogbusyW = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
				containernumitems = xbmc.getInfoLabel('Container.NumItems')
				systemidle1 = xbmc.getCondVisibility('System.IdleTime(1)')
				if dialogbusyW and systemidle1: xbmc.sleep(500)
				'''---------------------------'''
			systemcurrentcontrol = findin_systemcurrentcontrol("0","[..]",100,'','Action(Down)')
			if systemcurrentcontrol == "[..]":
				container50listitem2label = xbmc.getInfoLabel('Container(50).ListItem(1).Label')
				if not "LIVE Sports 24/7" in container50listitem2label:
					'''------------------------------
					---NO-LIVE-MATCHS----------------
					------------------------------'''
					dialogok(addonString(41).encode('utf-8'),addonString(39).encode('utf-8') + space2,addonString(38).encode('utf-8'),"")
					'''---------------------------'''
				else:
					'''------------------------------
					---LIVE-MATCHS-FOUND!------------
					------------------------------'''
					dialogok(addonString(40).encode('utf-8'),addonString(42).encode('utf-8') + '[CR]' + '[COLOR=Yellow]' + "LIVE FOOTBALL" + '[/COLOR]',"","")
					'''---------------------------'''
		if admin: print printfirst + "mode15_LV" + printpoint + space + "systemcurrentcontrol" + space2 + systemcurrentcontrol + space + "count" + space2 + str(count)
	elif not connected: notification_common("5")
	'''---------------------------'''
	
def mode16(admin, name):
	'''------------------------------
	---SPORT-2-LIVE------------------
	------------------------------'''
	printpoint = ""
	returned = supportcheck(name, ["A","B"])
	if connected and returned == "ok":
		returned = ActivateWindow("1", 'plugin.video.p2p-streams', 'plugin://plugin.video.p2p-streams/?iconimage=C%3a%5cUsers%5cgal%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.p2p-streams%5cresources%5ccore%5cparsers%5clivefootballws%5cicon.png&mode=401&name=Livefootball.ws&parser=livefootballws&url=https%3a%2f%2fcode.google.com%2fp%2fp2p-strm%2f', 0, wait=True)
		if returned == "ok":
			printpoint = printpoint + "1"
			systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
			systemcurrentcontrol = findin_systemcurrentcontrol("0","[..]",100,'Action(PageUp)','')
			systemcurrentcontrol = findin_systemcurrentcontrol("0","[..]",100,'Action(PageUp)','Action(Down)')
			xbmc.sleep(500)
			containernumitems = xbmc.getInfoLabel('Container.NumItems')
			
			if not "(Online)" in xbmc.getInfoLabel('Container(50).ListItem(0).Label') and not "ONLINE" in xbmc.getInfoLabel('Container(50).ListItem(1).Label'):
				'''------------------------------
				---NO-LIVE-MATCHS----------------
				------------------------------'''
				dialogok(addonString(41).encode('utf-8'),addonString(39).encode('utf-8') + space2,addonString(38).encode('utf-8'),"")
				'''---------------------------'''
			else:
				'''------------------------------
				---LIVE-MATCHS-FOUND!------------
				------------------------------'''
				dialogok(addonString(40).encode('utf-8'),addonString(42).encode('utf-8') + '[CR]' + '[COLOR=Yellow]' + "LIVE FOOTBALL" + '[/COLOR]',"","")
				'''---------------------------'''
				
		'''---------------------------'''
	else: notification_common("5")
	'''---------------------------'''

def mode40(admin):
	'''------------------------------
	---Skin.ResetSettings------------
	------------------------------'''
	returned = ""
	skinsettingsW = xbmc.getCondVisibility('Window.IsVisible(SkinSettings.xml)')
	if skinsettingsW: returned = dialogyesno(addonString(37).encode('utf-8'), addonString(36).encode('utf-8'))
	if returned == 'ok' and skinsettingsW:
		'''------------------------------
		---DELETE-USER-FILES-------------
		------------------------------'''
		Clean_Library("10")
		Clean_Library("11")
		Clean_Library("12")
		Clean_Library("13")
	
	if returned == 'ok' or not skinsettingsW:	
		xbmc.executebuiltin('Skin.ResetSettings')
		notification_common("2")
		xbmc.sleep(4000)
		
		'''------------------------------
		---Apply-USER-IDS----------------
		------------------------------'''
		setSkinSetting5("0",'ID',idstr,'ID1',id1str,'ID2',id2str,'ID3',id3str,'ID4',id4str)
		setSkinSetting5("0",'ID5',id5str,'ID6',id6str,'ID7',id7str,'ID8',id8str,'ID9',id9str)
		setSkinSetting5("0",'ID10',id10str,'ID11',id11str,'ID12',id12str,'ID60',id60str,'',"")
		setSkinSetting5("0",'MAC',macstr,'MAC1',mac1str,'MAC2',mac2str,'',"",'MAC5',mac5str)
		setSkinSetting5("0",'fixip',fixip,'',"",'TrialDate',trialdate,'TrialDate2',trialdate2,'',"")
		setSkinSetting5("1",'Trial',trial,'Trial2',trial2,'',"",'',"",'',"")
		'''---------------------------'''
		setSkinSetting5("1",'Account1_Active',Account1_Active,'Account2_Active',Account2_Active,'Account3_Active',Account3_Active,'Account4_Active',Account4_Active,'Account5_Active',Account5_Active)
		setSkinSetting5("1",'',"",'',"",'',"",'',"",'Account10_Active',Account10_Active)
		setSkinSetting5("0",'Account1_Period',Account1_Period,'Account2_Period',Account2_Period,'Account3_Period',Account3_Period,'Account4_Period',Account4_Period,'Account5_Period',Account5_Period)
		setSkinSetting5("0",'Account6_Period',Account6_Period,'Account7_Period',Account7_Period,'Account8_Period',Account8_Period,'Account9_Period',Account9_Period,'Account10_Period',Account10_Period)
		'''---------------------------'''
		setSkinSetting5("0",'Account1_EndDate',Account1_EndDate,'Account2_EndDate',Account2_EndDate,'Account3_EndDate',Account3_EndDate,'Account4_EndDate',Account4_EndDate,'Account5_EndDate',Account5_EndDate)
		setSkinSetting5("0",'Account6_EndDate',Account6_EndDate,'Account7_EndDate',Account7_EndDate,'Account8_EndDate',Account8_EndDate,'Account9_EndDate',Account9_EndDate,'Account10_EndDate',Account10_EndDate)
		'''---------------------------'''
		
		'''------------------------------
		---Apply-PREFERED-SETTINGS-------
		------------------------------'''
		setSkinSetting5("0",'MusicLink',"Albums",'moviesestartup',"1",'tvshowsestartup',"1",'',"",'',"") #SKIN SETTINGS
		'''---------------------------'''
		setSkinSetting5("1",'myHTPT2',"true",'ShowClock',"true",'Backgrounds2',"true",'Genre',"true",'Rating',"true") #SKIN SETTINGS
		setSkinSetting5("1",'AutoView',"true",'StartUpMusic',"true",'AutoPlaySD',"true",'ShowDVDCases',"true",'ShowFileInfo',"true") #SKIN SETTINGS
		setSkinSetting5("1",'ShowTopVideoInformation',"true",'AutoShutdown',"true",'',"",'',"",'',"") #SKIN SETTINGS
		setSkinSetting5("1",'hidetest',"true",'',"",'',"",'3dmovs',"true",'',"") #HOMEBUTTONS
		'''---------------------------'''
		
		'''------------------------------
		---Widgets-----------------------
		------------------------------'''
		setSkinSetting("1",'widget',"true")
		setSkinSetting5("1",'',"",'MoviesShelfWL',"true",'TVShelf_Watchlist',"true",'',"",'',"") #GENERAL
		setSkinSetting5("1",'YouTube.21',"true",'YouTube.23',"true",'YouTube.26',"true",'YouTube.30',"true",'',"") #YOUTUBE
		setSkinSetting5("1",'GoPro.24',"true",'GoPro.25',"true",'GoPro.26',"true",'GoPro.30',"true",'',"") #GOPRO
		setSkinSetting5("1",'IsraelTV.21',"true",'IsraelTV.23',"true",'IsraelTV.30',"true",'',"",'',"") #IsraelTV
		'''---------------------------'''
		
	if skinsettingsW: returned = dialogyesno(addonString(35).encode('utf-8'), addonString(36).encode('utf-8'))
	if returned == 'ok' or not skinsettingsW:
		'''------------------------------
		---RESET-ADDONS-SETTINGS---------
		------------------------------'''
		if skinsettingsW: dialogok('USERDATA DELETED!','[CR]' + 'THERE IS NO WAY BACK NOW...',"","")
		if not systemplatformwindows:
			addonsL = []
			addonsL.append('script.htpt.homebuttons')
			addonsL.append('script.htpt.emu')
			addonsL.append('service.htpt')
			addonsL.append('plugin.video.htpt.kids')
			addonsL.append('plugin.video.htpt.music')
			addonsL.append('plugin.video.htpt.gopro')
			addonsL.append('script.htpt.smartbuttons')
			addonsL.append('plugin.video.p2p-streams')
			addonsL.append('plugin.program.advanced.launcher')
			addonsL.append('plugin.video.genesis')
			addonsL.append('plugin.video.youtube')
			'''---------------------------'''
			if admin:
				addonsL.append('script.htpt.remote')
				addonsL.append('script.htpt.fix')
				addonsL.append('script.htpt.debug')
				'''---------------------------'''
			removeaddons(addonsL,"23")
			'''---------------------------'''
		else:
			'''------------------------------
			---Apply-CURRENT-USER-SETTINGS---
			------------------------------'''
			setSkinSetting5("0",'MusicLink',musiclinkstr,'StartUpMusic',startupmusicstr,'',"",'',"",'',"") #SKIN SETTINGS
			setSkinSetting5("1",'Adult',adult,'Adult2',adult2,'',"",'',"",'',"") #SKIN SETTINGS
			'''---------------------------'''
	elif skinsettingsW: notification_common("9")
	
def mode50(admin):
	'''------------------------------
	---SOFT-RESTART------------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	setsetting_custom1('script.htpt.debug','General_ScriptON',"true")
	setsetting_custom1('script.htpt.debug','ModeOn_7',"true")
	setsetting_custom1('script.htpt.debug','ModeTime_7',datenowS + "__" + timenow2S)
	xbmc.sleep(1000)
	bash('pgrep kodi.bin | xargs kill -SIGSTOP && killall -9 kodi.bin && sleep 1 && pgrep kodi.bin | xargs kill -SIGCONT',"SOFT-RESTART")
	'''---------------------------'''

def mode51(admin):
	'''------------------------------
	---RESTART-----------------------
	------------------------------'''
	setsetting_custom1('script.htpt.debug','General_ScriptON',"true")
	setsetting_custom1('script.htpt.debug','ModeOn_8',"true")
	setsetting_custom1('script.htpt.debug','ModeTime_8',datenowS + "__" + timenow2S)
	xbmc.sleep(1000)
	xbmc.executebuiltin('XBMC.Reset()')
	#bash('pgrep kodi.bin | xargs kill -SIGSTOP && killall -9 kodi.bin && sleep 1 && pgrep kodi.bin | xargs kill -SIGCONT',"SOFT-RESTART")
	'''---------------------------'''

def mode52(admin):
	'''------------------------------
	---SUSPEND-----------------------
	------------------------------'''
	setsetting_custom1('script.htpt.debug','General_ScriptON',"true")
	setsetting_custom1('script.htpt.debug','ModeOn_4',"true")
	setsetting_custom1('script.htpt.debug','ModeTime_4',datenowS + "__" + timenow2S)
	xbmc.sleep(1000)
	xbmc.executebuiltin('XBMC.Suspend()')
	#bash('pgrep kodi.bin | xargs kill -SIGSTOP && killall -9 kodi.bin && sleep 1 && pgrep kodi.bin | xargs kill -SIGCONT',"SOFT-RESTART")
	'''---------------------------'''

def mode53(admin):
	'''------------------------------
	---POWEROFF----------------------
	------------------------------'''
	setsetting_custom1('script.htpt.debug','ModeTime_10',datenowS + "__" + timenow2S)
	xbmc.executebuiltin('RunScript(script.htpt.debug,,?mode=10)')
	notification('$LOCALIZE[13016]','$LOCALIZE[31407]',"",4000)
	xbmc.sleep(4000)
	notification(startupmessage2,id1str,"",5000)
	xbmc.sleep(1000)
	if not systemplatformwindows: xbmc.executebuiltin('XBMC.Powerdown()')
	#bash('pgrep kodi.bin | xargs kill -SIGSTOP && killall -9 kodi.bin && sleep 1 && pgrep kodi.bin | xargs kill -SIGCONT',"SOFT-RESTART")
	'''---------------------------'''

def mode55(admin):
	'''------------------------------
	---LibraryData-------------------
	------------------------------'''
	from variables import *
	if not systemplatformwindows:
		Afolders_count, Afolders_count2, Afiles_count = bash_count(copymoviesdir+'*')
		Bfolders_count, Bfolders_count2, Bfiles_count = bash_count(copytvshowsdir+'*')
		Cfolders_count, Cfolders_count2, Cfiles_count = bash_count(movies_path+'*')
		Dfolders_count, Dfolders_count2, Dfiles_count = bash_count(tvshows_path+'*')
		'''---------------------------'''
		setsetting_custom1(addonID,'LibraryData_RemoteMoviesFiles',Afolders_count2)
		setsetting_custom1(addonID,'LibraryData_RemoteTvshowsFiles',Bfolders_count2)
		setsetting_custom1(addonID,'LibraryData_LocalMoviesFiles',Cfolders_count2)
		setsetting_custom1(addonID,'LibraryData_LocalTvshowsFiles',Dfolders_count2)
		'''---------------------------'''
		LibraryData_RemoteMoviesFiles2 = getsetting('LibraryData_RemoteMoviesFiles')
		LibraryData_RemoteTvshowsFiles2 = getsetting('LibraryData_RemoteTvshowsFiles')
		if LibraryData_RemoteMoviesFiles != LibraryData_RemoteMoviesFiles2 or LibraryData_RemoteTvshowsFiles != LibraryData_RemoteTvshowsFiles2 or librarydataremotedatestr == "":
			notification(str24068.encode('utf-8') + space5 + datenowS,str79577.encode('utf-8'),"",4000) #Update available, Update Movies and Tvshows library
			setSkinSetting("0", 'LibraryData_RemoteDate', datenowS)
			'''---------------------------'''
		if admin: print printfirst + "LibraryData" + space + "Afolders_count2" + space2 + Afolders_count2 + space + "Bfolders_count2" + space2 + Bfolders_count2 + newline + "LibraryData_RemoteMoviesFiles/2" + space2 + LibraryData_RemoteMoviesFiles + space4 + LibraryData_RemoteMoviesFiles2 + space + "LibraryData_RemoteTvshowsFiles/2" + space2 + LibraryData_RemoteTvshowsFiles + space4 + LibraryData_RemoteTvshowsFiles2
		
def mode56(admin, name):
	'''------------------------------
	---LibrarySync-------------------
	------------------------------'''
	from variables import *
	printpoint = ""
	TypeError = ""
	
	try: LibraryData_RemoteMoviesFiles = int(LibraryData_RemoteMoviesFiles)
	except Exception, TypeError: LibraryData_RemoteMoviesFiles = 0
	try: LibraryData_RemoteTvshowsFiles = int(LibraryData_RemoteTvshowsFiles)
	except Exception, TypeError: LibraryData_RemoteTvshowsFiles = 0
	try: LibraryData_LocalMoviesFiles = int(LibraryData_LocalMoviesFiles)
	except Exception, TypeError: LibraryData_LocalMoviesFiles = 0
	try: LibraryData_LocalTvshowsFiles = int(LibraryData_LocalTvshowsFiles)
	except Exception, TypeError: LibraryData_LocalTvshowsFiles = 0
	Remotevslocal1 = LibraryData_RemoteMoviesFiles - LibraryData_LocalMoviesFiles
	Remotevslocal2 = LibraryData_RemoteTvshowsFiles - LibraryData_LocalTvshowsFiles
	'''---------------------------'''
	
	'''------------------------------
	---CHECK-FOR-LibrarySync_ON------
	------------------------------'''
	if librarydataremotedatestr != "":
		printpoint = printpoint + "0"
		if (Remotevslocal1 + Remotevslocal2) > 0 or librarydataremotedatestr != librarydatalocaldatestr or librarydatalocaldatestr == "":
			printpoint = printpoint + "1"
			if librarydatalocaldatestr == "" and librarydataremotedatestr == librarydatalocaldatestr: setSkinSetting("0", 'LibraryData_LocalDate', librarydatalocaldatestr + "*")
	elif librarydataremotedatestr != "" and librarydataremotedatestr == librarydatalocaldatestr and (Remotevslocal1 + Remotevslocal2) <= 0:
		printpoint = printpoint + "2"
		if skinsettingsW: notification('$LOCALIZE[79578]', '$LOCALIZE[79579]',"",4000) #The library already synced		
	elif not systemplatformwindows:
		printpoint = printpoint + "9"
		notification_common("17")
		'''---------------------------'''
	#if librarydataremotedatestr == librarydataremotedate2str: setSkinSetting("0", 'LibraryData_LocalDate', librarydataremotedate2str + "?")
	if "1" in printpoint:
		'''------------------------------
		---CONTINUE----------------------
		------------------------------'''
		returned, value = getRandom("0",percent=40)
		if skinsettingsW or admin or returned == "ok":
			'''------------------------------
			---CONTINUE----------------------
			------------------------------'''
			printpoint = printpoint + "3"
			if librarydatalocaldatestr != "": option = str24056.encode('utf-8') % (librarydatalocaldatestr)
			else: option = '$LOCALIZE[79580]'
			returned = dialogyesno('[COLOR=Yellow]' + str79577.encode('utf-8') + '[/COLOR]',str24068.encode('utf-8') + ', ' + str12354.encode('utf-8') + '[CR]' + option)
			if returned == "ok":
				'''------------------------------
				---CONTINUE----------------------
				------------------------------'''
				printpoint = printpoint + "7"
				bash('cp -rf '+ copylibrarydir +'* '+ library_path +'',"LibrarySync")
				xbmc.sleep(1000)
				setSkinSetting("0", 'LibraryData_LocalDate', librarydataremotedatestr)
				containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
				libraryisscanningvideo = xbmc.getCondVisibility('Library.IsScanningVideo')
				if not libraryisscanningvideo: xbmc.executebuiltin('UpdateLibrary(video)')
				if not admin:
					if Remotevslocal1 < 0: Remotevslocal1 = 0
					if Remotevslocal2 < 0: Remotevslocal2 = 0
					'''---------------------------'''
				dialogok('[COLOR=Yellow]' + str79577 + '[/COLOR]' + '[CR]' + str79072, str79584 % (str(Remotevslocal1),str(Remotevslocal2)), "", "")
				'''---------------------------'''
			else: notification_common("9")

	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if TypeError != "": print printfirst + "LibrarySync" + space + "TypeError" + space2 + str(TypeError)
	if admin: print printfirst + "LibrarySync_LV" + printpoint + space + "Remotevslocal1" + space2 + str(Remotevslocal1) + space + "Remotevslocal2" + space2 + str(Remotevslocal2)
	'''---------------------------'''
	
def mode100(admin, name):
	'''------------------------------
	---?---------------
	------------------------------'''
	pass
	'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	pass
	'''---------------------------'''
	