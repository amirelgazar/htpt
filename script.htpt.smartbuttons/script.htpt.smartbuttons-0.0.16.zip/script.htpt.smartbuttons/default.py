import xbmc
import os, sys
import subprocess
import xbmcgui, xbmcaddon

print "log1"

from variables import *
from modules import *
from shared_modules3 import get_params

print "log2"
printpoint = ""
'''---------------------------'''
try: params=get_params()
except Exception, TypeError: notification_common("18")
#name=None
mode=None
'''---------------------------'''
#try: name=urllib.unquote_plus(params["name"])
#except: pass
try: mode=int(params["mode"])
except: pass
'''---------------------------'''

class main:
	setGeneral_ScriptON("0", General_ScriptON, str(mode))
	
	if mode == 0:
		'''------------------------------
		---TEST--------------------------
		------------------------------'''
		mode0(admin)
		'''---------------------------'''
		
	elif mode == 1:
		'''------------------------------
		---SMART-KEYBOARD-SAVE-VALUE-----
		------------------------------'''
		mode1(admin)
		'''---------------------------'''
		
	elif mode == 2:
		'''------------------------------
		---SMART-KEYBOARD-COPY-----------
		------------------------------'''
		mode2(admin)
		'''---------------------------'''
		
	elif mode == 3:
		'''------------------------------
		---SMART-KEYBOARD-HISTORY--------
		------------------------------'''
		mode3(admin)
		'''---------------------------'''
		
	elif mode == 4:
		'''------------------------------
		---SMART-KEYBOARD-PASTE----------
		------------------------------'''
		mode4(admin)
		'''---------------------------'''
	
	elif mode == 8:
		'''------------------------------
		---SMART-SUBTITLE-SEARCH---------
		------------------------------'''
		mode8(admin)
		'''---------------------------'''
	
	elif mode == 9:
		'''------------------------------
		---SEMI-AUTO-SUBTITLE-FIND-------
		------------------------------'''
		name = 'SEMI-AUTO-SUBTITLE-FIND'
		mode9(admin, name, scripthtptrefresh_Current_Year, scripthtptrefresh_Current_M_T)
		'''---------------------------'''
		
	elif mode == 10:
		'''------------------------------
		---LIVE-TV-BUTTON----------------
		------------------------------'''
		mode10(admin)
		'''---------------------------'''
	elif mode == 12:
		'''------------------------------
		---UPDATE-LIVE-TV-PVR------------
		------------------------------'''
		mode12(admin)
		'''---------------------------'''
	elif mode == 15:
		'''------------------------------
		---SPORT-1-LIVE------------------
		------------------------------'''
		name = "SPORT-1-LIVE"
		mode15(name)
		'''---------------------------'''
	elif mode == 16:
		'''------------------------------
		---SPORT-2-LIVE------------------
		------------------------------'''
		name = "SPORT-2-LIVE"
		mode16(admin, name)
		'''---------------------------'''
	
	elif mode == 30:
		'''------------------------------
		---HTPT-CHANNEL------------------
		------------------------------'''
		name = "HTPT-CHANNEL"
		mode30(admin, name)
		'''---------------------------'''	
	
	elif mode == 39:
		'''------------------------------
		---Reset-Network-Settings--------
		------------------------------'''
		name = "Reset-Network-Settings"
		mode39(admin, name)
		'''---------------------------'''
		
	elif mode == 40:
		'''------------------------------
		---Skin.ResetSettings------------
		------------------------------'''
		mode40(admin)
		'''---------------------------'''
	
	elif mode == 41:
		'''------------------------------
		---Network-Settings--------------
		------------------------------'''
		if systemplatformwindows: cmd('rundll32.exe van.dll,RunVAN','Network')
		else: oewindow('Network')
		'''---------------------------'''
		
	elif mode == 42:
		'''------------------------------
		---FORMAT------------------------
		------------------------------'''
		name = 'FORMAT'
		mode42(admin, name, mac5str)
		'''---------------------------'''
	
	elif mode == 43:
		'''------------------------------
		---CONFIGURATE-SCRAPERS----------
		------------------------------'''
		setsetting_custom1('service.htpt.fix','Fix_100',"true")
		setsetting_custom1('service.htpt.fix','Fix_101',"true")
		xbmc.executebuiltin('RunScript(service.htpt.fix,,?mode=3)')
		xbmc.executebuiltin('ActivateWindow(0)')
		'''---------------------------'''
	
	elif mode == 44:
		'''------------------------------
		----OverClock-Your-PI------------
		------------------------------'''
		name = 'OverClock-Your-PI'
		mode44(admin, name)
		'''---------------------------'''
	
	elif mode == 45:
		'''------------------------------
		---STABILITY-TEST----------------
		------------------------------'''
		name = 'STABILITY-TEST'
		mode45(admin, name)
		'''---------------------------'''
	
	elif mode == 46:
		'''------------------------------
		---OVERCLOCKING------------------
		------------------------------'''
		name = 'OVERCLOCKING'
		mode46(admin,name)
		'''---------------------------'''
	elif mode == 49:
		'''------------------------------
		---SCRAPER-FIX-------------------
		------------------------------'''
		name = 'SCRAPER-FIX'
		mode49(admin, name)
		'''---------------------------'''
		
	elif mode == 50:
		'''------------------------------
		---SOFT-RESTART------------------
		------------------------------'''
		mode50(admin)
		'''---------------------------'''
	
	elif mode == 51:
		'''------------------------------
		---RESTART-----------------------
		------------------------------'''
		mode51(admin)
		'''---------------------------'''
	
	elif mode == 52:
		'''------------------------------
		---SUSPEND-----------------------
		------------------------------'''
		mode52(admin)
		'''---------------------------'''
	
	elif mode == 53:
		'''------------------------------
		---POWEROFF----------------------
		------------------------------'''
		mode53(admin)
		'''---------------------------'''
	
	elif mode == 54:
		'''------------------------------
		---QUIT--------------------------
		------------------------------'''
		mode54(admin)
		'''---------------------------'''
		
	elif mode == 55:
		'''------------------------------
		---LibraryData-------------------
		------------------------------'''
		mode55(admin)
		'''---------------------------'''
		
	elif mode == 56:
		'''------------------------------
		---LibrarySync-------------------
		------------------------------'''
		name = "LibrarySync"
		mode56(admin, name, LibraryData_RemoteMoviesFiles, LibraryData_RemoteTvshowsFiles, LibraryData_LocalMoviesFiles, LibraryData_LocalTvshowsFiles, librarydataremotedatestr)
		'''---------------------------'''
	
	elif mode == 59:
		'''------------------------------
		---Choose-Country----------------
		------------------------------'''
		name = 'Choose-Country'
		mode59(admin, name, printpoint)
		'''---------------------------'''
		
	elif mode == 60:
		'''------------------------------
		---Remove-Skin-------------------
		------------------------------'''
		dialogok('$LOCALIZE[79595]','$LOCALIZE[79596]','$LOCALIZE[79598]',"")
		#notification_common("9")
		#xbmc.executebuiltin('Dialog.Close(selectdialog)')
		'''---------------------------'''
	
	elif mode == 63:
		'''------------------------------
		---Texture-Cache-Removal---------
		------------------------------'''
		name = 'Texture-Cache-Removal'
		mode63(admin, name)
		'''---------------------------'''
	
	elif mode == 64:
		'''------------------------------
		---?--------------------
		------------------------------'''
		pass
		'''---------------------------'''
		
	elif mode == 70:
		'''------------------------------
		---ExtendedInfo------------------
		------------------------------'''
		name = 'ExtendedInfo'
		mode70(admin, name)
		'''---------------------------'''
		
	elif mode == 94:
		'''------------------------------
		---TRAKT-TV-BUTTON---------------
		------------------------------'''
		mode94(admin)
		'''---------------------------'''

	elif mode == 95:
		'''------------------------------
		---SDAROT-TV-BUTTON--------------
		------------------------------'''
		mode95(admin)
		'''---------------------------'''

	elif mode == 96:
		'''------------------------------
		---NOOBROOM-BUTTON---------------
		------------------------------'''
		mode96(admin)
		'''---------------------------'''
		
	elif mode == 97:
		'''------------------------------
		---PREMIUMIZE-BUTTON-------------
		------------------------------'''
		mode97(admin)
		'''---------------------------'''

	elif mode == 98:
		'''------------------------------
		---MOVREEL-BUTTON----------------
		------------------------------'''
		mode98(admin)
		'''---------------------------'''

	elif mode == 99:
		'''------------------------------
		---REALDEBRID-BUTTON-------------
		------------------------------'''
		mode99(admin)
		'''---------------------------'''		
		
	elif mode == 100:
		'''------------------------------
		---STARTUP-TRIGGER---------------
		------------------------------'''
		name = "STARTUP-TRIGGER"
		mode100(admin, name)
		'''---------------------------'''	
	
	elif mode == 200:
		'''------------------------------
		---TRANSPERANCY-SELECTED-ICON----
		------------------------------'''
		name = "TRANSPERANCY-SELECTED-ICON"
		mode200(admin, name, printpoint)
		'''---------------------------'''	
	
	elif mode == 201:
		'''------------------------------
		---RESET-TO-DEFAULT--------------
		------------------------------'''
		name = "RESET-TO-DEFAULT"
		mode201(admin, name, printpoint)
		'''---------------------------'''
	
	elif mode == 202:
		'''------------------------------
		---CHOOSE-COLORS-2---------------
		------------------------------'''
		name = "CHOOSE-COLORS-2"
		mode202(admin, name, printpoint)
		'''---------------------------'''
	else: printpoint = printpoint + "9"

	setGeneral_ScriptON("1", General_ScriptON, str(mode))
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if TypeError != "": print printfirst + "Default.py" + space + "TypeError" + space2 + str(TypeError)
	#print printfirst + "default.py" + space + "mode" + space2 + str(mode) + space + "LV" + space2 + printpoint + space + "General_ScriptON" + space2 + General_ScriptON + newline + "output" + space2 + output
	
	'''---------------------------'''
	