import xbmc
import os, sys
import subprocess
import xbmcgui, xbmcaddon

from variables import *
from modules import *
from shared_modules3 import get_params

printpoint = ""
'''---------------------------'''
params=get_params()
url=None
name=None
mode=None
iconimage=None
desc=None
num=None
'''---------------------------'''
try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try: mode=int(params["mode"])
except: pass
try: num=urllib.unquote_plus(params["num"])
except: pass
'''---------------------------'''

class main:
	setGeneral_ScriptON("0", General_ScriptON, str(mode))
	
	if mode == 1:
		'''------------------------------
		---SMART-KEYBOARD-SAVE-VALUE-----
		------------------------------'''
		if General_ScriptON != "true":
			'''---------------------------'''
			printpoint = printpoint + "1"
			heading = xbmc.getInfoLabel('Control.GetLabel(311)')
			#keyboard = xbmc.Keyboard(Current_Input,heading,int(Current_Option))
			#input = keyboard.getText()
			#setsetting_custom1('script.htpt.smartkeyboard','Current_Input',input)
			#setGeneral_ScriptON("0", General_ScriptON, str(mode))
			'''---------------------------'''
			input = dialogkeyboard(Current_Input, heading, 0, '1', "", "")
			#keyboard = xbmc.Keyboard()
			#input = keyboard.getText()
			#input = "test"
			setsetting_custom1('script.htpt.smartkeyboard','Current_Input',input)
			setsetting_custom1('script.htpt.smartkeyboard','Current_Option',0)
			'''------------------------------
			---SMART-KEYBOARD-SAVE-VALUE-----
			------------------------------'''
			if input != "skip":
				printpoint = printpoint + "2"
				setSkinSetting("0", 'smartkeyboardH0', input)
				xbmc.sleep(1000) #time to set setting
				if not input in smartkeyboardHL:
					'''------------------------------
					---NEW-VALUE---------------------
					------------------------------'''
					printpoint = printpoint + "3"
					setSkinSetting("0", 'smartkeyboardH5', smartkeyboardH4)
					setSkinSetting("0", 'smartkeyboardH4', smartkeyboardH3)
					setSkinSetting("0", 'smartkeyboardH3', smartkeyboardH2)
					setSkinSetting("0", 'smartkeyboardH2', smartkeyboardH1)
					setSkinSetting("0", 'smartkeyboardH1', input)
					'''---------------------------'''
				else:
					'''------------------------------
					---EXIST-VALUE-------------------
					------------------------------'''
					printpoint = printpoint + "4"
					if input != smartkeyboardH1:
						if input == smartkeyboardH2:
							printpoint = printpoint + "5"
							setSkinSetting("0", 'smartkeyboardH1', input)
							setSkinSetting("0", 'smartkeyboardH2', smartkeyboardH1)
							'''---------------------------'''
						elif input == smartkeyboardH3:
							printpoint = printpoint + "6"
							setSkinSetting("0", 'smartkeyboardH1', input)
							setSkinSetting("0", 'smartkeyboardH3', smartkeyboardH1)
							'''---------------------------'''
						elif input == smartkeyboardH4:
							printpoint = printpoint + "7"
							setSkinSetting("0", 'smartkeyboardH1', input)
							setSkinSetting("0", 'smartkeyboardH4', smartkeyboardH1)
							'''---------------------------'''
						elif input == smartkeyboardH5:
							printpoint = printpoint + "8"
							setSkinSetting("0", 'smartkeyboardH1', input)
							setSkinSetting("0", 'smartkeyboardH5', smartkeyboardH1)
							'''---------------------------'''
						else: printpoint = printpoint + "9"
					else: printpoint = printpoint + "9"
					'''---------------------------'''
			
			setsetting_custom1('script.htpt.smartkeyboard','Current_Input',"")
			setsetting_custom1('script.htpt.smartkeyboard','Current_Option',0)

		'''---------------------------'''
		#setGeneral_ScriptON("1", General_ScriptON, str(mode))
		'''---------------------------'''
		
	elif mode == 2:
		'''------------------------------
		---SMART-KEYBOARD-COPY-----------
		------------------------------'''
		printpoint = printpoint + "1"
		#keyboard.doModal()
		#input2 = keyboard.getText()
		#notification("input2: " + input2,"input: " + input,"",2000)
		setSkinSetting("0", "smartkeyboardC" + smartkeyboardPN, Current_Input)
		'''---------------------------'''
		
	elif mode == 3:
		'''------------------------------
		---SMART-KEYBOARD-HISTORY--------
		------------------------------'''
		import json
		xbmc.executebuiltin('Action(Close)')
		xbmc.sleep(200)
		if smartkeyboardHN == '1': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH1 +'","done":false}}')
		if smartkeyboardHN == '2': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH2 +'","done":false}}')
		if smartkeyboardHN == '3': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH3 +'","done":false}}')
		if smartkeyboardHN == '4': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH4 +'","done":false}}')
		if smartkeyboardHN == '5': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH5 +'","done":false}}')
		xbmc.executebuiltin('SetFocus(3000)')
		'''---------------------------'''
		
	elif mode == 4:
		'''------------------------------
		---SMART-KEYBOARD-PASTE----------
		------------------------------'''
		import json
		xbmc.executebuiltin('Action(Close)')
		xbmc.sleep(200)
		if smartkeyboardPN == '1': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC1 +'","done":false}}')
		if smartkeyboardPN == '2': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC2 +'","done":false}}')
		if smartkeyboardPN == '3': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC3 +'","done":false}}')
		if smartkeyboardPN == '4': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC4 +'","done":false}}')
		if smartkeyboardPN == '5': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC5 +'","done":false}}')
		xbmc.executebuiltin('SetFocus(3000)')
		'''---------------------------'''
	
	elif mode == 8:
		'''------------------------------
		---SMART-SUBTITLE-SEARCH---------
		------------------------------'''
		import json
		xbmc.executebuiltin('SendClick(160)')
		input = ""
		isTV = 'false'
		isMovie = 'false'
		'''---------------------------'''
		
		#if scripthtptrefresh_Current_M_T != "" and scripthtptrefresh_Current_Name != "": input = scripthtptrefresh_Current_Name
		if videoplayertvshowtitle != "" and videoplayerseason != "" and videoplayerepisode != "": isTV = 'true'
		elif videoplayertitle != "" and (videoplayeryear != "" or videoplayercountry != "" or videoplayertagline != ""): isMovie = 'true'
		'''---------------------------'''
		if isMovie == 'true': input = videoplayertitle + space + videoplayeryear + space + videoplayervideoresolution + space + videoplayervideocodec
		elif videoplayertitle != "": input = videoplayertitle
		elif isTV == 'true':
			seasonN = int(videoplayerseason)
			episodeN = int(videoplayerepisode)
			if seasonN < 10 and episodeN < 10: input = videoplayertvshowtitle + " " + 'S0' + videoplayerseason + 'E0' + videoplayerepisode
			if seasonN > 10 and episodeN > 10: input = videoplayertvshowtitle + " " + 'S' + videoplayerseason + 'E' + videoplayerepisode
			if seasonN > 10 and episodeN < 10: input = videoplayertvshowtitle + " " + 'S' + videoplayerseason + 'E0' + videoplayerepisode
			if seasonN < 10 and episodeN > 10: input = videoplayertvshowtitle + " " + 'S0' + videoplayerseason + 'E' + videoplayerepisode
			'''---------------------------'''
		dialogkeyboard = xbmc.getCondVisibility('Window.IsVisible(DialogKeyboard.xml)')
		count = 0
		while count < 10 and not dialogkeyboard and not xbmc.abortRequested:
			count += 1
			xbmc.sleep(100)
			dialogkeyboard = xbmc.getCondVisibility('Window.IsVisible(DialogKeyboard.xml)')
			'''---------------------------'''
		if count < 10: xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ input +'","done":false}}')
		'''---------------------------'''
		print printfirst + "dialogsubtitles: " + "videoplayertvshowtitle = " + videoplayertvshowtitle + " | videoplayerseason = " + videoplayerseason + " | videoplayerepisode = " + videoplayerepisode + " | videoplayertitle = " + videoplayertitle + " | videoplayeryear = " + videoplayeryear + " | videoplayertitle = " + videoplayertitle + space + "playertitle =" + playertitle + space + "VideoCodec" + space2 + videoplayervideocodec + space + "VideoResolution" + space2 + videoplayervideoresolution
		'''---------------------------'''
		
	else: printpoint = printpoint + "9"

	setGeneral_ScriptON("1", General_ScriptON, str(mode))
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "default.py" + space + "mode" + space2 + str(mode) + space + "LV" + space2 + printpoint + space + "General_ScriptON" + space2 + General_ScriptON
	'''---------------------------'''
	