import xbmc, xbmcgui, xbmcaddon
import os, sys
#import subprocess

xbmc.sleep(10000)

from variables import *
from modules import *

class ResetSettings:
	setsetting('Addon_ServiceON',"true")
	setsetting('General_ScriptON',"false")
	setsetting('Subtitle_Search',"")
	setsetting('Subtitle_Service',"")
	'''---------------------------'''

while servicehtpt_Skin_Name == 'N/A' or servicehtpt_Skin_Name != 'skin.htpt' and not xbmc.abortRequested:
	xbmc.sleep(10000)
	addon = 'service.htpt'
	if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
		getsetting_servicehtpt = xbmcaddon.Addon(addon).getSetting
		servicehtpt_Skin_Name = getsetting_servicehtpt('Skin_Name')
		'''---------------------------'''
		
class Startup:
	if servicehtpt_Skin_Name == "skin.htpt" and scripthtptinstall_Skin_Installed != "true" and scripthtptinstall_Skin_Suspend != "true":
		printpoint = printpoint + "1"
		xbmc.executebuiltin('RunScript('+ addonID +',,?mode=55)')
		'''---------------------------'''
	
class exit:
	if admin: notification(addonID + space + "service.py","Clean Exit","",5000)
	setsetting('Addon_ServiceON',"false")
	sys.exit()



count = 0
while count == 0 and not xbmc.abortRequested:
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	dialogbusyW = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
	dialogokW = xbmc.getCondVisibility('Window.IsVisible(DialogOk.xml)')
	dialogprogressW = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
	dialogselectW = xbmc.getCondVisibility('Window.IsVisible(DialogSelect.xml)')
	dialogtextviewerW = xbmc.getCondVisibility('Window.IsVisible(DialogTextViewer.xml)')
	dialogyesnoW = xbmc.getCondVisibility('Window.IsVisible(DialogYesNo.xml)')
	custom1191W = xbmc.getCondVisibility('Window.IsVisible(Custom1191.xml)')
	startupW = xbmc.getCondVisibility('Window.IsVisible(Startup.xml)')
	homeW = xbmc.getCondVisibility('Window.IsVisible(Home.xml)')
	if homeW and not dialogprogressW and not dialogokW and not dialogbusyW and not dialogtextviewerW and not dialogyesnoW and not startupW and not custom1191W:
		if count == 0: mode56(admin)
		count += 1
		xbmc.sleep(5000)
		'''---------------------------'''
	else:	
		if admin: xbmc.sleep(5000)
		else: xbmc.sleep(10000)
		'''---------------------------'''
	if admin: print printfirst + "service.py" + space + "count" + space2 + str(count)

