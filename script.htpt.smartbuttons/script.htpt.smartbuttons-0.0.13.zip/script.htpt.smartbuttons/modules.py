#import xbmc, os, subprocess, sys
#import xbmc, xbmcgui, xbmcaddon
import xbmc, xbmcgui, xbmcaddon
import subprocess, os, sys
#import datetime, time
from variables import *
from shared_modules import *

def mode0(admin):
	'''------------------------------
	---TEST--------------------------
	------------------------------'''
	#admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	#value = []
	#value.append("copylibrarydir" + space2 + copylibrarydir + newline)
	#value.append("library_path" + space2 + library_path + newline)
	
	#print printfirst + "mode0-test: "  + str(value)
	'''---------------------------'''
	
	#xbmc.executebuiltin('RunScript(service.htpt.fix,,?mode=13)')
	#mode64(admin, "1")
	
	#systemmemorytotal2 = systemmemorytotal.replace("MB","")
	
	#print systemmemorytotal2
	#Skin_Name2 = cmd('find "<skin>" '+userdata_path+'guisetings.xml',"GUI1") #UNTESTED
	#output = cmd('find "<skin>" '+userdata_path+'guisettings.xml',"GUI1") #UNTESTED
	#Skin_Name2 = CleanString(output, filter=['----------', userdata_path + 'guisettings.xml', '<skin>', '</skin>'])
	
	#print "Skin_Name22" + space + Skin_Name2 + newline + "userdata_path" + space2 + userdata_path
	'''---------------------------'''
	#setSkinSetting('0', 'TopVideoInformation4', 'special://thumbnails/http%3a%2f%2fthetvdb.com%2fbanners%2fposters%2f74845-2.jpg')
	
	#echo executing copy.sh from skin && sleep 1 && echo killall && killall -9 kodi.bin && sed -i "s/$SKIN$ALL/$SKIN$SKIN_/g" $GUI && sed -i "s/$SKIN2$ALL/$SKIN$SKIN_/g" $GUI
	#xbmc.executebuiltin('RunScript(script.htpt.smartbuttons,,?mode=50)') ; xbmc.sleep(1000)
	#autoexec_path = os.path.join(userdata_path, 'Autoexec.py')
	
	#xbmc.executebuiltin('RunScript('+autoexec_path+')')
	#removefiles(guisettings_file)
	#copyfiles(guisettings2_file, guisettings_file, chmod="", mount=False)
	#import shutil
	#shutil.copyfile(guisettings_file, guisettings4_file)
	#from shared_modules4 import *
	#guiset(admin, guiread="")
	
	printpoint = installaddon2(admin, 'metadata.common.imdb.com', update=False)
	#shutil.copyfile(guisettings4_file, guisettings_file) ; killall(admin)
	#copyfiles(guisettings2_file, guisettings_file, chmod="", mount=False)
	
	#image://http%3a%2f%2fthetvdb.com%2fbanners%2fposters%2f74845-2.jpg/
	#ExtractAll("E:\\4P.zip", 'E:\\')
	'''---------------------------'''
	#xbmc.executebuiltin('RunScript(script.extendedinfo,info=extendedactorinfo,name=Dwayne)')
	#xbmc.executebuiltin('RunScript(script.htpt.smartbuttons,,?mode=100)')
	#mode55(admin)
	#systemtemperatureunits = xbmc.getInfoLabel('System.TemperatureUnits')
	#if xbmc.getCondVisibility('SubString(System.TemperatureUnits,F)'): notification(systemtemperatureunits, "yes", "", 2000)
	#sgbsubtitlespauseonsearch = xbmc.getCondVisibility('System.GetBool(subtitles.pauseonsearch)')
	#notification(str(sgbsubtitlespauseonsearch), "", "", 1000)
	'''---------------------------'''
	#playlistid = 'PLPWc8VdaIIsDcjHMTBavJG-Rm8p0wvvW_'
	#xbmc.executebuiltin('RunScript(script.extendedinfo,info=youtubeplaylist,id=PLPWc8VdaIIsDcjHMTBavJG-Rm8p0wvvW_)')
	#xbmc.executebuiltin('PlayMedia(plugin://plugin.video.youtube/play/?playlist_id='+playlistid+')')
	'''---------------------------'''
	
	if 1 + 1 == 3:
		backupname = "htpt_backup"
		backupname2 = "htpt_backup2"
		backuppath = home_path
		if systemplatformwindows: restorepath = home_path
		else: restorepath = '/storage'
		ExtractAll(backuppath + backupname + ".zip", restorepath)
	
	
	
	'''---------------------------'''
	
	
	'''---------------------------'''
	
	
	'''---------------------------'''
	
	#xbmc.executebuiltin('RunScript(script.htpt.refresh,,?mode=3)')
	if 1+ 1 == 3:
		if systemplatformwindows: infile = "Z:/addons/plugin.video.sdarot.tv/sdarottv.py"
		else: infile = "/storage/.kodi/addons/plugin.video.sdarot.tv/sdarottv.py"
		old_word = "finalVideoUrl,VID = getFinalVideoUrl(series_id,season_id,epis,silent=True)"
		new_word = "finalVideoUrl,VID = getFinalVideoUrl(series_id,season_id,epis,silent=False)"
		replace_word(infile,old_word,new_word)
		#xbmc.executebuiltin('ActivateWindow(10025,special://home/addons)')
		#xbmc.executebuiltin('PlayMedia(plugin://plugin.video.youtube/play/?video_id=gnZuo0he5kk)')
	pass
	#notification(xbmc.getInfoLabel('System.ProfileName'),"","",5000)
	#xbmc.executebuiltin('Action(PageUp)')
	#xbmc.sleep(500)
	#xbmc.executebuiltin('Control.SetFocus(2)')
	#xbmc.executebuiltin('ActivateWindow(10025,special://userdata/library/,return)')
	#cmd('xcopy '+htptservicecopy_path+'manual\\advancedsettings.xml '+userdata_path+' /s /i /y >NUL','advancedsettings.xml')
	#print xbmc.getInfoLabel('System.TotalSpace')
	
	#xbmc.executebuiltin('RunScript(service.htpt.fix,,?mode=40)')
	#ExtractAll("D:\\rom\\Arcade\\_GEAR.rar","C:\\")
	#ExtractAll("C:\\_1P.tar","C:\\")
	#ExtractAll("C:\\_1P.7z","C:\\_1P")
	#Clean_Library("10")
	#xbmc.executebuiltin('RunScript(plugin.video.genesis,,?action=library_imdb_watchlist)')
	#Clean_Library("1")
	

	
	
	#xbmc.executebuiltin('RunScript(service.htpt.fix,,?mode=20)')
	#xbmc.executebuiltin('RunScript(script.htpt.smartbuttons,,?mode=0)')
	#xbmc.executebuiltin('RunScript(screensaver.picture.slideshow)')
	#xbmc.executebuiltin('RunScript(service.htpt.fix,,?mode=12)')

	#from commondownloader import *
	#returned = doDownload("https://docs.google.com/uc?export=download&id=0B3SUm7A8M6ctNTRhQ21jYUw0ZVk", "C:\\test3.zip", "google", "", "", "")
	#from commondownloader import *
	#doDownload("https://www.dropbox.com/s/zz2se5mfpmt5wbn/Sega%20Master%20System.zip?dl=1", "C:\\test2.zip", 'Media', "", "", "")
	#dialogok("download done","","","")
	#import urllib2
	#import urllib, urllib2, os, sys

	###The pydrive package download
	###page='https://pypi.python.org/packages/source/P/PyDrive/PyDrive-1.0.0.tar.gz'
	###request=urllib.urlretrieve(page, "C:\\" + "pydrive.tar.gz") #pydrive.tar.gz
	###if os.path.exists(os.path.join("C:\\","pydrive.tar.gz")): #os.path.dirname
		###print "YUP THE FILE EXISTS"
		###notification("yes!","","",2000)
	###else:
		###print "nope"			#response = urllib2.urlopen('https://drive.google.com/file/d/0B3SUm7A8M6ctNTRhQ21jYUw0ZVk/view?usp=sharing')
	#html = response.read()
	#f=open("1", 'w')
	#f.write(html)
	#f.close()
	#from downloader import *
	#download("https://www.dropbox.com/s/kxwmwbnjf7f040j/skin.htpt.zip?dl=1", "c:\\test.zip", dp = None) #temp_path #https://drive.google.com/file/d/0B3SUm7A8M6ctNTRhQ21jYUw0ZVk/view?usp=sharing
	
	#DownloadFile("https://drive.google.com/uc?export=download&id=0B3SUm7A8M6ctNTRhQ21jYUw0ZVk", "Media", "C:\\", "C:\\1")
	#systemmemorytotal2 = systemmemorytotal.replace("MB","")
	#notification(systemmemorytotal2,"","",10000)
	#content = ReadList('/storage/shutdown.log')
	#print "HERE" + space2 + newline + str(content)
	#returned, value = getRandom("0",percent=10)
	#if returned == "ok": notification("yeyeye","","",4000)
		
	#xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.genesis/?action=library_imdb_watchlist,return)')
	#removeaddons(['plugin.program.advanced.launcher', 'script.htpt.emu', 'tools.lm_sensors', 'debug.tools.smem', 'screensaver.randomtrailers'],"12")
	#addon = 'plugin.program.advanced.launcher'
	#output = bash('ls '+addons_path+''+ addon +'/',"script.htpt.emu")
	#output = bash('ls '+addondata_path+''+ addon +'/',"script.htpt.emu")
	#output = bash('rm -rf '+addondata_path+''+ addon +'/',addon)
	#print output
	#dp = dialogprogress("",0,"heading","line1","line2","line3")
	#xbmc.sleep(2000)
	#dp = dialogprogress(dp, 10,"heading","line1","line2","line3")
	#xbmc.sleep(2000)
	#dp = dialogprogress(dp, 100,"heading","line1","line2","line3")
	#xbmc.sleep(2000)
	
	'''---------------------------'''
	#print printfirst + space + "test2button" + space2 + az
	'''---------------------------'''
	
	'''---------------------------'''
	
def mode1(admin):
	'''------------------------------
	---SMART-KEYBOARD-SAVE-VALUE-----
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	if General_ScriptON != "true":
		'''---------------------------'''
		printpoint = printpoint + "1"
		heading = xbmc.getInfoLabel('Control.GetLabel(311)')
		#keyboard = xbmc.Keyboard(Current_Input,heading,int(Current_Option))
		#input = keyboard.getText()
		#setsetting_custom1('script.htpt.smartkeyboard','Current_Input',input)
		#setGeneral_ScriptON("0", General_ScriptON, str(mode))
		'''---------------------------'''
		input = dialogkeyboard(Current_Input, heading, 0, '1', "", "")
		#keyboard = xbmc.Keyboard()
		#input = keyboard.getText()
		#input = "test"
		setsetting_custom1('script.htpt.smartkeyboard','Current_Input',input)
		setsetting_custom1('script.htpt.smartkeyboard','Current_Option',0)
		'''------------------------------
		---SMART-KEYBOARD-SAVE-VALUE-----
		------------------------------'''
		if input != "skip":
			printpoint = printpoint + "2"
			setSkinSetting("0", 'smartkeyboardH0', input)
			xbmc.sleep(1000) #time to set setting
			if not input in smartkeyboardHL:
				'''------------------------------
				---NEW-VALUE---------------------
				------------------------------'''
				printpoint = printpoint + "3"
				setSkinSetting("0", 'smartkeyboardH5', smartkeyboardH4)
				setSkinSetting("0", 'smartkeyboardH4', smartkeyboardH3)
				setSkinSetting("0", 'smartkeyboardH3', smartkeyboardH2)
				setSkinSetting("0", 'smartkeyboardH2', smartkeyboardH1)
				setSkinSetting("0", 'smartkeyboardH1', input)
				'''---------------------------'''
			else:
				'''------------------------------
				---EXIST-VALUE-------------------
				------------------------------'''
				printpoint = printpoint + "4"
				if input != smartkeyboardH1:
					if input == smartkeyboardH2:
						printpoint = printpoint + "5"
						setSkinSetting("0", 'smartkeyboardH1', input)
						setSkinSetting("0", 'smartkeyboardH2', smartkeyboardH1)
						'''---------------------------'''
					elif input == smartkeyboardH3:
						printpoint = printpoint + "6"
						setSkinSetting("0", 'smartkeyboardH1', input)
						setSkinSetting("0", 'smartkeyboardH3', smartkeyboardH1)
						'''---------------------------'''
					elif input == smartkeyboardH4:
						printpoint = printpoint + "7"
						setSkinSetting("0", 'smartkeyboardH1', input)
						setSkinSetting("0", 'smartkeyboardH4', smartkeyboardH1)
						'''---------------------------'''
					elif input == smartkeyboardH5:
						printpoint = printpoint + "8"
						setSkinSetting("0", 'smartkeyboardH1', input)
						setSkinSetting("0", 'smartkeyboardH5', smartkeyboardH1)
						'''---------------------------'''
					else: printpoint = printpoint + "9"
				else: printpoint = printpoint + "9"
				'''---------------------------'''
		
		setsetting_custom1('script.htpt.smartkeyboard','Current_Input',"")
		setsetting_custom1('script.htpt.smartkeyboard','Current_Option',0)

	'''---------------------------'''
	#setGeneral_ScriptON("1", General_ScriptON, str(mode))
	'''---------------------------'''

def mode2(admin):
	'''------------------------------
	---SMART-KEYBOARD-COPY-----------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	printpoint = printpoint + "1"
	#keyboard.doModal()
	#input2 = keyboard.getText()
	#notification("input2: " + input2,"input: " + input,"",2000)
	setSkinSetting("0", "smartkeyboardC" + smartkeyboardPN, Current_Input)
	'''---------------------------'''

def mode3(admin):
	'''------------------------------
	---SMART-KEYBOARD-HISTORY--------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	import json
	xbmc.executebuiltin('Action(Close)')
	xbmc.sleep(200)
	if smartkeyboardHN == '1': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH1 +'","done":false}}')
	if smartkeyboardHN == '2': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH2 +'","done":false}}')
	if smartkeyboardHN == '3': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH3 +'","done":false}}')
	if smartkeyboardHN == '4': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH4 +'","done":false}}')
	if smartkeyboardHN == '5': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardH5 +'","done":false}}')
	xbmc.executebuiltin('SetFocus(3000)')
	'''---------------------------'''

def mode4(admin):
	'''------------------------------
	---SMART-KEYBOARD-PASTE----------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	import json
	xbmc.executebuiltin('Action(Close)')
	xbmc.sleep(200)
	if smartkeyboardPN == '1': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC1 +'","done":false}}')
	if smartkeyboardPN == '2': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC2 +'","done":false}}')
	if smartkeyboardPN == '3': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC3 +'","done":false}}')
	if smartkeyboardPN == '4': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC4 +'","done":false}}')
	if smartkeyboardPN == '5': xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ smartkeyboardC5 +'","done":false}}')
	xbmc.executebuiltin('SetFocus(3000)')
	'''---------------------------'''
	
def mode5(admin):
	'''------------------------------
	---?--------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	'''---------------------------'''

def mode8(admin):
	'''------------------------------
	---SMART-SUBTITLE-SEARCH---------
	------------------------------'''
	import json
	name = 'SMART-SUBTITLE-SEARCH'
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	extra = newline + ""
	input = ""
	isTV = 'false'
	isMovie = 'false'
	printpoint = ""
	TypeError = ""
	TypeError2 = ""
	listL = ["0","1"]
	
	'''------------------------------
	---MOVIE/TV----------------------
	------------------------------'''
	if scripthtptrefresh_Current_M_T in listL:
		if scripthtptrefresh_Current_M_T == "0": isMovie = 'true'
		elif scripthtptrefresh_Current_M_T == "1": isTV = 'true'
		'''---------------------------'''
	else:
		if (videoplayertvshowtitle != "" and videoplayerseason != "" and videoplayerepisode != "") or scripthtptrefresh_Current_M_T == "1": isTV = 'true'
		elif (videoplayertitle != "" and (videoplayeryear != "" or videoplayercountry != "" or videoplayertagline != "")) or scripthtptrefresh_Current_M_T == "0": isMovie = 'true'
		'''---------------------------'''
		
	xbmc.executebuiltin('SendClick(160)')

	'''------------------------------
	---INPUT-------------------------
	------------------------------'''
	
	if scripthtptrefresh_Current_M_T in listL and scripthtptrefresh_Current_Name != "":
		try:
			hebtest = scripthtptrefresh_Current_Name.decode('utf-8')
			#setSkinSetting("1","Test",hebtest)
			print hebtest
			printpoint = printpoint + "1"
			'''---------------------------'''
		except Exception, TypeError: TypeError2 = str(TypeError2) + str(TypeError)
	else: extra = extra + space + "Current_M_T" + space2 + str(scripthtptrefresh_Current_M_T)
	
	if not "1" in printpoint:
		try:
			if isMovie == "true": hebtest = videoplayertitle.decode('utf-8')
			elif isTV == "true": hebtest = videoplayertvshowtitle.decode('utf-8')
			#setSkinSetting("1","Test",hebtest)
			print hebtest
			printpoint = printpoint + "2"
			'''---------------------------'''
		except Exception, TypeError:
			TypeError2 = str(TypeError2) + str(TypeError)
			try:
				hebtest = playertitle.decode('utf-8')
				#setSkinSetting("1","Test",hebtest)
				print hebtest
				printpoint = printpoint + "3"
				'''---------------------------'''
			except Exception, TypeError:
				TypeError2 = str(TypeError2) + str(TypeError)
				printpoint = printpoint + "9"
	
	if "1" in printpoint: input = scripthtptrefresh_Current_Name
	elif "2" in printpoint:
		if isMovie == 'true': input = videoplayertitle + space + videoplayeryear # + space + videoplayervideoresolution #+ space + videoplayervideocodec
		elif isTV == 'true':
			try: seasonN = int(videoplayerseason)
			except: seasonN = ""
			try: episodeN = int(videoplayerepisode)
			except: episodeN = ""
			if seasonN == "" or episodeN == "" or videoplayertvshowtitle == "": input = videoplayertitle
			elif seasonN < 10 and episodeN < 10: input = videoplayertvshowtitle + " " + 'S0' + videoplayerseason + 'E0' + videoplayerepisode
			elif seasonN > 10 and episodeN > 10: input = videoplayertvshowtitle + " " + 'S' + videoplayerseason + 'E' + videoplayerepisode
			elif seasonN > 10 and episodeN < 10: input = videoplayertvshowtitle + " " + 'S' + videoplayerseason + 'E0' + videoplayerepisode
			elif seasonN < 10 and episodeN > 10: input = videoplayertvshowtitle + " " + 'S0' + videoplayerseason + 'E' + videoplayerepisode
			'''---------------------------'''
	elif "3" in printpoint: input = playertitle
	'''---------------------------'''
	if "3" in printpoint or "9" in printpoint:
		input = ""
		notification('$LOCALIZE[75099]','$LOCALIZE[75098]',"",2000)
		'''---------------------------'''
	
	dialogkeyboard = xbmc.getCondVisibility('Window.IsVisible(DialogKeyboard.xml)')
	count = 0
	while count < 10 and not dialogkeyboard and not xbmc.abortRequested:
		count += 1
		xbmc.sleep(100)
		dialogkeyboard = xbmc.getCondVisibility('Window.IsVisible(DialogKeyboard.xml)')
		'''---------------------------'''
	if count < 10: xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"'+ input +'","done":false}}')
	'''---------------------------'''
	if TypeError2 != "": extra = newline + extra + space + "TypeError" + space2 + str(TypeError2)
	print printfirst + name + "_LV" + printpoint + space + "videoplayertvshowtitle = " + videoplayertvshowtitle + " | videoplayerseason = " + videoplayerseason + " | videoplayerepisode = " + videoplayerepisode + " | videoplayertitle = " + videoplayertitle + " | videoplayeryear = " + videoplayeryear + " | videoplayertitle = " + videoplayertitle + space + "playertitle =" + playertitle + space + "VideoCodec" + space2 + videoplayervideocodec + space + "VideoResolution" + space2 + videoplayervideoresolution + extra
	'''---------------------------'''

def setSubHisotry(admin, DialogSubtitles, DialogSubtitles2):
	dialogsubtitlesna1 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA1)')
	dialogsubtitlesna2 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA2)')
	dialogsubtitlesna3 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA3)')
	dialogsubtitlesna4 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA4)')
	dialogsubtitlesna5 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA5)')
	dialogsubtitlesna6 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA6)')
	dialogsubtitlesna7 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA7)')
	dialogsubtitlesna8 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA8)')
	dialogsubtitlesna9 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA9)')
	dialogsubtitlesna10 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA10)')
	
	if DialogSubtitles2 != "":
		if dialogsubtitlesna1 == "": setSkinSetting("0",'DialogSubtitlesNA1',DialogSubtitles2)
		elif dialogsubtitlesna2 == "": setSkinSetting("0",'DialogSubtitlesNA2',DialogSubtitles2)
		elif dialogsubtitlesna3 == "": setSkinSetting("0",'DialogSubtitlesNA3',DialogSubtitles2)
		elif dialogsubtitlesna4 == "": setSkinSetting("0",'DialogSubtitlesNA4',DialogSubtitles2)
		elif dialogsubtitlesna5 == "": setSkinSetting("0",'DialogSubtitlesNA5',DialogSubtitles2)
		elif dialogsubtitlesna6 == "": setSkinSetting("0",'DialogSubtitlesNA6',DialogSubtitles2)
		elif dialogsubtitlesna7 == "": setSkinSetting("0",'DialogSubtitlesNA7',DialogSubtitles2)
		elif dialogsubtitlesna8 == "": setSkinSetting("0",'DialogSubtitlesNA8',DialogSubtitles2)
		elif dialogsubtitlesna9 == "": setSkinSetting("0",'DialogSubtitlesNA9',DialogSubtitles2)
		elif dialogsubtitlesna10 == "": setSkinSetting("0",'DialogSubtitlesNA10',DialogSubtitles2)
	
	xbmc.sleep(1000)
	setCurrent_Subtitle(admin)
	'''---------------------------'''

def setCurrent_Subtitle(admin):
	dialogsubtitles2 = xbmc.getInfoLabel('Skin.String(DialogSubtitles2)')
	dialogsubtitlesna1 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA1)')
	dialogsubtitlesna2 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA2)')
	dialogsubtitlesna3 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA3)')
	dialogsubtitlesna4 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA4)')
	dialogsubtitlesna5 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA5)')
	dialogsubtitlesna6 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA6)')
	dialogsubtitlesna7 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA7)')
	dialogsubtitlesna8 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA8)')
	dialogsubtitlesna9 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA9)')
	dialogsubtitlesna10 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA10)')
	'''---------------------------'''
	setsetting_custom1('script.htpt.refresh','Current_Subtitle',dialogsubtitles2)
	setsetting_custom1('script.htpt.refresh','Current_Subtitle1',dialogsubtitlesna1)
	setsetting_custom1('script.htpt.refresh','Current_Subtitle2',dialogsubtitlesna2)
	setsetting_custom1('script.htpt.refresh','Current_Subtitle3',dialogsubtitlesna3)
	setsetting_custom1('script.htpt.refresh','Current_Subtitle4',dialogsubtitlesna4)
	setsetting_custom1('script.htpt.refresh','Current_Subtitle5',dialogsubtitlesna5)
	setsetting_custom1('script.htpt.refresh','Current_Subtitle6',dialogsubtitlesna6)
	setsetting_custom1('script.htpt.refresh','Current_Subtitle7',dialogsubtitlesna7)
	setsetting_custom1('script.htpt.refresh','Current_Subtitle8',dialogsubtitlesna8)
	setsetting_custom1('script.htpt.refresh','Current_Subtitle9',dialogsubtitlesna9)
	setsetting_custom1('script.htpt.refresh','Current_Subtitle10',dialogsubtitlesna10)
	'''---------------------------'''
	addon = 'script.htpt.refresh'
	if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
		getsetting_scripthtptrefresh       = xbmcaddon.Addon(addon).getSetting
		'''---------------------------'''
		scripthtptrefresh_Current_Subtitle = getsetting_scripthtptrefresh('Current_Subtitle')
		'''---------------------------'''
	else:
		scripthtptrefresh_Current_Subtitle = ""
		'''---------------------------'''
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + space + "setCurrent_Subtitle" + space2 + scripthtptrefresh_Current_Subtitle + space + "(" + dialogsubtitles2 + ")"
	'''---------------------------'''
	
def mode9(admin, name, Current_Year, Current_M_T):
	'''------------------------------
	---SEMI-AUTO-SUBTITLE-FIND-------
	------------------------------'''
	from variables import yearnowS
	dialogsubtitles2 = xbmc.getInfoLabel('Skin.String(DialogSubtitles2)')
	dialogsubtitlesna1 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA1)')
	dialogsubtitlesna2 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA2)')
	dialogsubtitlesna3 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA3)')
	dialogsubtitlesna4 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA4)')
	dialogsubtitlesna5 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA5)')
	dialogsubtitlesna6 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA6)')
	dialogsubtitlesna7 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA7)')
	dialogsubtitlesna8 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA8)')
	dialogsubtitlesna9 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA9)')
	dialogsubtitlesna10 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA10)')
	subL = [dialogsubtitles2, dialogsubtitlesna1, dialogsubtitlesna2, dialogsubtitlesna3, dialogsubtitlesna4, dialogsubtitlesna5, dialogsubtitlesna6, dialogsubtitlesna7, dialogsubtitlesna8, dialogsubtitlesna9, dialogsubtitlesna10]
	listL = ['Subscenter.org', 'Subtitle.co.il', 'OpenSubtitles.org', 'Torec']
	Subtitle_Service = getsetting('Subtitle_Service')
	dialogsubtitlesW = xbmc.getCondVisibility('Window.IsVisible(DialogSubtitles.xml)')
	container120numitems = 0
	tip = "true"
	count = 0
	count2 = 0 #container120numitems
	countidle = 0
	'''---------------------------'''
	while countidle < 40 and dialogsubtitlesW and not xbmc.abortRequested:
		'''------------------------------
		---VARIABLES---------------------
		------------------------------'''
		dialogsubtitlesW = xbmc.getCondVisibility('Window.IsVisible(DialogSubtitles.xml)')
		if dialogsubtitlesW:
			container120numitems2 = container120numitems
			container120numitems = xbmc.getInfoLabel('Container(120).NumItems') #DialogSubtitles
			try: container120numitems = int(container120numitems)
			except: container120numitems = ""
			'''---------------------------'''
			controlhasfocus120 = xbmc.getCondVisibility('Control.HasFocus(120)') #MAIN
			controlhasfocus150 = xbmc.getCondVisibility('Control.HasFocus(150)') #SIDE
			controlgetlabel100 = xbmc.getInfoLabel('Control.GetLabel(100)') #DialogSubtitles Service Name
			controlgroup70hasfocus0 = xbmc.getCondVisibility('ControlGroup(70).HasFocus(0)') #OSD BUTTONS
			'''---------------------------'''
			systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
			container120listitemlabel2 = xbmc.getInfoLabel('Container(120).ListItem.Label2')
			'''---------------------------'''
			
		Subtitle_Search = getsetting('Subtitle_Search')
		dialogsubtitles = xbmc.getInfoLabel('Skin.String(DialogSubtitles)')
		dialogkeyboardW = xbmc.getCondVisibility('Window.IsVisible(DialogKeyboard.xml)')
		playerpaused = xbmc.getCondVisibility('Player.Paused')
		'''---------------------------'''
		systemidle1 = xbmc.getCondVisibility('System.IdleTime(1)')
		systemidle3 = xbmc.getCondVisibility('System.IdleTime(3)')
		systemidle7 = xbmc.getCondVisibility('System.IdleTime(7)')
		systemidle40 = xbmc.getCondVisibility('System.IdleTime(40)')
		'''---------------------------'''
		
		if controlhasfocus120 and container120numitems > 0 and count2 != 0: count2 = 0
		
		if not dialogkeyboardW and container120numitems != "" and controlgetlabel100 != "":
			
			if count == 0 and Subtitle_Service != "" and Subtitle_Service != controlgetlabel100 and controlgetlabel100 != "":
				'''------------------------------
				---Last_SubService---------------
				------------------------------'''
				if controlhasfocus120: xbmc.executebuiltin('Action(Left)')
				systemcurrentcontrol = findin_systemcurrentcontrol("0",Subtitle_Service,40,'Action(Down)','')
				systemcurrentcontrol = findin_systemcurrentcontrol("0",Subtitle_Service,40,'Action(Down)','')
				systemcurrentcontrol = findin_systemcurrentcontrol("0",Subtitle_Service,40,'Action(Down)','')
				systemcurrentcontrol = findin_systemcurrentcontrol("0",Subtitle_Service,40,'Action(Down)','')
				systemcurrentcontrol = findin_systemcurrentcontrol("0",Subtitle_Service,100,'Action(Down)','Action(Select)')
				'''---------------------------'''
					
			elif controlhasfocus120 and container120numitems > 0:
				if (container120listitemlabel2 in subL or container120listitemlabel2 == dialogsubtitles2):
					if container120numitems2 != container120numitems:
						'''------------------------------
						---Last_SubService---------------
						------------------------------'''
						count3 = 0
						while count3 < 5 and systemidle1 and not xbmc.abortRequested:
							count3 += 1
							container120listitemlabel2 = xbmc.getInfoLabel('Container(120).ListItem.Label2')
							systemidle1 = xbmc.getCondVisibility('System.IdleTime(1)')
							if (container120listitemlabel2 in subL or container120listitemlabel2 == dialogsubtitles2): xbmc.executebuiltin('Action(Down)')
							xbmc.sleep(100)
							'''---------------------------'''
							
					elif tip == "true" and countidle == 3:
						if container120listitemlabel2 == dialogsubtitles2: notification('$LOCALIZE[78947]',dialogsubtitles2,"",3000)
						elif container120listitemlabel2 in subL: notification('$LOCALIZE[78949]',dialogsubtitles2,"",3000)
						
						tip = "false"
						'''---------------------------'''
				
			elif controlhasfocus150 and container120numitems == 0:
				count2 += 1
				
				if countidle >= 1 and count2 == 1:
					'''------------------------------
					---LOOKING-FOR-SUBTITLE----------
					------------------------------'''
					notification('$LOCALIZE[78952]',"","",4000)
					'''---------------------------'''
				
				elif countidle > 3 and count2 == 7 and systemcurrentcontrol == controlgetlabel100:
					'''------------------------------
					---REFRESH-----------------------
					------------------------------'''
					if controlgetlabel100 == "Subtitle.co.il": xbmc.sleep(1000)
					notification('$LOCALIZE[78951]',"","",2000)
					systemcurrentcontrol = findin_systemcurrentcontrol("0",controlgetlabel100,40,'Action(Down)','')
					systemcurrentcontrol = findin_systemcurrentcontrol("0",controlgetlabel100,40,'Action(Down)','')
					systemcurrentcontrol = findin_systemcurrentcontrol("0",controlgetlabel100,40,'Action(Down)','')
					systemcurrentcontrol = findin_systemcurrentcontrol("0",controlgetlabel100,40,'Action(Down)','')
					systemcurrentcontrol = findin_systemcurrentcontrol("0",controlgetlabel100,40,'Action(Down)','')
					systemcurrentcontrol = findin_systemcurrentcontrol("0",controlgetlabel100,100,'Action(Down)','Action(Select)')
					'''---------------------------'''
					
				elif countidle > 5 and count2 >= 13 and controlgetlabel100 != "":
					'''------------------------------
					---CHANGE-SUBTITLE-SERVICE-------
					------------------------------'''
					notification('$LOCALIZE[78950]',"","",2000)
					if controlgetlabel100 in listL: listL.remove(controlgetlabel100) #listL = 
					
					systemcurrentcontrol = findin_systemcurrentcontrol("2",listL,40,'Action(Down)','')
					systemcurrentcontrol = findin_systemcurrentcontrol("2",listL,100,'Action(Down)','')
					systemcurrentcontrol = findin_systemcurrentcontrol("2",listL,200,'Action(Down)','Action(Select)')
					
					count2 = 0
					'''---------------------------'''
		
		dialogsubtitlesW = xbmc.getCondVisibility('Window.IsVisible(DialogSubtitles.xml)')
		if dialogsubtitlesW:
			if not controlgroup70hasfocus0 and not sgbsubtitlespauseonsearch:
				if systemidle3 and playerpaused: xbmc.executebuiltin('Action(Play)')
				elif not systemidle3 and not playerpaused: xbmc.executebuiltin('Action(Pause)')
				'''---------------------------'''
			xbmc.sleep(1000)
			'''---------------------------'''
			count += 1
			if systemidle1: countidle += 1
			else: countidle = 0
			'''---------------------------'''
		
	if count > 20 and count < 100 and count2 > 20 and Current_Year == yearnowS and Current_M_T == "0":
		'''------------------------------
		---NEW-MOVIE---------------------
		------------------------------'''
		notification('$LOCALIZE[78944]','$LOCALIZE[78948]',"",4000)
		'''---------------------------'''
	
	systemidle1 = xbmc.getCondVisibility('System.IdleTime(1)')
	systemidle7 = xbmc.getCondVisibility('System.IdleTime(7)')
	
	if systemidle1 and not systemidle7:
		'''------------------------------
		---SET-NEW-SUBTITLE--------------
		------------------------------'''
		dialogsubtitles = xbmc.getInfoLabel('Skin.String(DialogSubtitles)')
		setSkinSetting("0",'DialogSubtitles2',dialogsubtitles)
		if dialogsubtitles2 != "": setSubHisotry(admin, dialogsubtitles, dialogsubtitles2)
		if Subtitle_Service != controlgetlabel100 and controlgetlabel100 != "": setsetting_custom1('script.htpt.smartbuttons','Subtitle_Service',controlgetlabel100)
		'''---------------------------'''
		
	if dialogsubtitlesW: xbmc.executebuiltin('Dialog.Close(subtitlesearch)')
	setSkinSetting("0",'DialogSubtitles',"")
	playerpaused = xbmc.getCondVisibility('Player.Paused')
	if playerpaused: xbmc.executebuiltin('Action(Play)')
	'''---------------------------'''
	
	if dialogsubtitlesna6 and not dialogsubtitlesna7:
		'''------------------------------
		---SHOW-TIPS---------------------
		------------------------------'''
		playerpaused = xbmc.getCondVisibility('Player.Paused')
		if not playerpaused: xbmc.executebuiltin('Action(Pause)')
		header = '[COLOR=Yellow]' + xbmc.getInfoLabel('$LOCALIZE[78946]') + '[/COLOR]'
		message2 = xbmc.getInfoLabel('$LOCALIZE[78945]')
		w = TextViewer_Dialog('DialogTextViewer.xml', "", header=header, text=message2)
		w.doModal()
		'''---------------------------'''
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + name + space + "count/2" + space2 + str(count) + space4 + str(count2) + space + "countidle" + space2 + str(countidle) + space + "controlgetlabel100" + space2 + str(controlgetlabel100) + space + "controlhasfocus120" + space2 + str(controlhasfocus120) + space + "controlhasfocus150" + space2 + str(controlhasfocus150) + space + "container120numitems/2" + space2 + str(container120numitems) + space4 + str(container120numitems2) + newline + "listL" + space2 + str(listL) + space + "Subtitle_Search" + space2 + str(Subtitle_Search) + space + "Subtitle_Service" + space2 + str(Subtitle_Service) + newline + "systemcurrentcontrol" + space2 + str(systemcurrentcontrol) + space + space + "container120listitemlabel2" + space2 + str(container120listitemlabel2) + space + "subL" + space2 + str(subL) + space + "playerpaused" + space2 + str(playerpaused)
	'''---------------------------'''

def mode10(admin):
	'''------------------------------
	---LIVE-TV-BUTTON----------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	if connected:
		printpoint = ""
		if livetvbutton2:
			name = "livetvbutton2"
			xbmc.executebuiltin('ActivateWindow(TVChannels)')
			xbmc.sleep(1000)
			mypvrchannels = xbmc.getCondVisibility('Window.IsVisible(MyPVRChannels.xml)')
			count = 0
			while count < 10 and not mypvrchannels and not xbmc.abortRequested:
				xbmc.sleep(100)
				count += 1
				mypvrchannels = xbmc.getCondVisibility('Window.IsVisible(MyPVRChannels.xml)')
				xbmc.sleep(100)
			if mypvrchannels:
				containerfoldername = xbmc.getInfoLabel('Container.FolderName')
				containernumitems = xbmc.getInfoLabel('Container.NumItems')
				if int(containernumitems) < 2: printpoint = printpoint + "8"
				elif containerfoldername != str19287.encode('utf-8'): dialogok('[COLOR=Yellow]' + '$LOCALIZE[19051]' + '[/COLOR]', str79548 % (containernumitems), str79549, "")

			else: printpoint = printpoint + "9"
			if "8" in printpoint or "9" in printpoint:
				xbmc.executebuiltin('RunAddon(plugin.video.israelive)')
				dialogkaitoastW = xbmc.getCondVisibility('Window.IsVisible(DialogKaiToast.xml)')
				count = 0
				while count < 10 and not dialogkaitoastW and not xbmc.abortRequested:
					count += 1
					xbmc.sleep(200)
					dialogkaitoastW = xbmc.getCondVisibility('Window.IsVisible(DialogKaiToast.xml)')
				if count == 10:
					xbmc.executebuiltin('RunScript(script.htpt.smartbuttons,,?mode=10)')
			
		else:
			if livetvbutton: name = "livetvbutton"
			else: name = "livetvcustom"
			returned = ActivateWindow("0", 'plugin.video.israelive', 'plugin://plugin.video.israelive/', 1, wait=True)
			if not "ok" in returned:
				printpoint = printpoint + "6"
				returned = ActivateWindow("1", 'plugin.video.israelive', 'plugin://plugin.video.israelive/', 1, wait=True)
			if "ok" in returned:
				printpoint = printpoint + "7"
				pass
			containernumitems = xbmc.getInfoLabel('Container.NumItems')
			containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
			systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
			
		if admin: print printfirst + name + "_LV" + printpoint + space + "containernumitems" + space2 + containernumitems + space + "containerfolderpath" + space2 + containerfolderpath
	else: notification_common("5")
	'''---------------------------'''

def mode12(admin):
	'''------------------------------
	---UPDATE-LIVE-TV-PVR------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	if connected:
		notification("UPDATE-LIVE-TV-PVR","","",1000)

		path = os.path.join(addondata_path, 'plugin.video.israelive', '')
		removefiles(path)
		path = os.path.join(database_path, 'Epg8.db')
		removefiles(path)
		xbmc.sleep(1000)
		xbmc.executebuiltin('RunScript(plugin.video.israelive,,mode=32)') #Update IPTVSimple settings
		xbmc.sleep(500)
		xbmc.executebuiltin('RunScript(plugin.video.israelive,,mode=34)') #REFRESH ALL SETTINGS
		'''---------------------------'''
	else: notification_common("5")
	'''---------------------------'''
	
def mode15(name):
	'''------------------------------
	---SPORT-1-LIVE------------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	if connected:
		printpoint = ""
		count = ""
		systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
		returned = ActivateWindow("1", 'plugin.video.vdubt', 'plugin://plugin.video.vdubt/', 0, wait=True)
		if "ok" in returned:
			printpoint = printpoint + "1"
			systemcurrentcontrol = findin_systemcurrentcontrol("0","[..]",0,'Action(PageUp)','')
			systemcurrentcontrol = findin_systemcurrentcontrol("0","[..]",100,'Action(PageUp)','Action(Down)')
			xbmc.sleep(100)
			notification(systemcurrentcontrol, "", "" ,2000)
			systemcurrentcontrol = findin_systemcurrentcontrol("1","Live",40,'Action(Down)','Action(Select)')
			systemcurrentcontrol = findin_systemcurrentcontrol("1","Live Sports",40,'Action(Down)','Action(Select)')
			xbmc.sleep(500)
			dialogbusyW = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
			containernumitems = xbmc.getInfoLabel('Container.NumItems')
			count = 0
			while count < 10 and (dialogbusyW or containernumitems != "0") and not xbmc.abortRequested:
				count += 1
				xbmc.sleep(200)
				dialogbusyW = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
				containernumitems = xbmc.getInfoLabel('Container.NumItems')
				systemidle1 = xbmc.getCondVisibility('System.IdleTime(1)')
				if dialogbusyW and systemidle1: xbmc.sleep(500)
				'''---------------------------'''
			systemcurrentcontrol = findin_systemcurrentcontrol("0","[..]",100,'','Action(Down)')
			if systemcurrentcontrol == "[..]":
				container50listitem2label = xbmc.getInfoLabel('Container(50).ListItem(1).Label')
				if not "LIVE Sports 24/7" in container50listitem2label:
					'''------------------------------
					---NO-LIVE-MATCHS----------------
					------------------------------'''
					dialogok(localize(78918), localize(78916) + space2, localize(78920),"")
					'''---------------------------'''
				else:
					'''------------------------------
					---LIVE-MATCHS-FOUND!------------
					------------------------------'''
					dialogok(localize(78917), localize(78919) + '[CR]' + '[COLOR=Yellow]' + "LIVE FOOTBALL" + '[/COLOR]',"","")
					'''---------------------------'''
		if admin: print printfirst + "mode15_LV" + printpoint + space + "systemcurrentcontrol" + space2 + systemcurrentcontrol + space + "count" + space2 + str(count)
	elif not connected: notification_common("5")
	'''---------------------------'''
	
def mode16(admin, name):
	'''------------------------------
	---SPORT-2-LIVE------------------
	------------------------------'''
	printpoint = ""
	if connected:
		addon = 'plugin.video.p2p-streams'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			'''------------------------------
			---plugin.video.p2p-streams------
			------------------------------'''
			printpoint = printpoint + "1"
			addonsettings2(addon,'ace-debug',"false",'save',"false",'parser_sync',"true",'run_a_python_script',"http://bit.ly/allparsers",'russian_translation',"true")
			addonsettings2(addon,'addon_history',"true",'items_per_page',"20",'autoconfig',"true",'timezone_new',"496",'hide_porn',"true")
			addonsettings2(addon,'',"",'',"",'',"",'',"",'',"")
			addonsettings2(addon,'',"",'',"",'',"",'',"",'',"")
			
			parser_path = os.path.join(addondata_path, 'plugin.video.p2p-streams', 'parser' ,'')
			folders_count, folders_count2, files_count = bash_count(parser_path)
			if int(files_count) < 7:
				printpoint = printpoint + "2"
				xbmc.executebuiltin('XBMC.RunPlugin(plugin://plugin.video.p2p-streams/?mode=404&name=p2p&url=p2p)')
				import json
				dialogkeyboardW = xbmc.getCondVisibility('Window.IsVisible(DialogKeyboard.xml)')
				count = 0
				while count < 10 and not dialogkeyboardW and not xbmc.abortRequested:
					dialogkeyboardW = xbmc.getCondVisibility('Window.IsVisible(DialogKeyboard.xml)')
					xbmc.sleep(1000)
					count += 1
					'''---------------------------'''
				if count < 10:
					xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.SendText","id":976575931,"params":{"text":"http://bit.ly/allparsers","done":false}}')
					xbmc.sleep(100)
					xbmc.executebuiltin('Action(Select)')
					'''---------------------------'''
				else: xbmc.executebuiltin('Action(Back)')
			else: printpoint = printpoint + "3"
			returned = ActivateWindow("1", 'plugin.video.p2p-streams', 'plugin://plugin.video.p2p-streams/?iconimage=C%3a%5cUsers%5cgal%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.p2p-streams%5cresources%5ccore%5cparsers%5clivefootballws%5cicon.png&mode=401&name=Livefootball.ws&parser=livefootballws&url=https%3a%2f%2fcode.google.com%2fp%2fp2p-strm%2f', 0, wait=True)
			
			if "ok" in returned:
				printpoint = printpoint + "4"
				systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
				systemcurrentcontrol = findin_systemcurrentcontrol("0","[..]",100,'Action(PageUp)','')
				systemcurrentcontrol = findin_systemcurrentcontrol("0","[..]",100,'Action(PageUp)','Action(Down)')
				xbmc.sleep(500)
				containernumitems = xbmc.getInfoLabel('Container.NumItems')
				
				if not "(Online)" in xbmc.getInfoLabel('Container(50).ListItem(0).Label') and not "ONLINE" in xbmc.getInfoLabel('Container(50).ListItem(1).Label'):
					'''------------------------------
					---NO-LIVE-MATCHS----------------
					------------------------------'''
					dialogok(localize(78918), localize(78916) + space2, localize(78920),"")
					'''---------------------------'''
				else:
					'''------------------------------
					---LIVE-MATCHS-FOUND!------------
					------------------------------'''
					dialogok(addonString(40).encode('utf-8'),localize(78919) + '[CR]' + '[COLOR=Yellow]' + "LIVE FOOTBALL" + '[/COLOR]',"","")
					'''---------------------------'''
					
			else: printpoint = printpoint + "6"
			'''---------------------------'''
		else:
			#if "A" in id10str or "B" in id10str:
			printpoint = printpoint + "8"
			installaddon(admin, addon, "")
			'''---------------------------'''
		
	else: notification_common("5")
	'''---------------------------'''
	if admin: print printfirst + name + "_LV" + printpoint + space
def mode30(admin, name):
	'''------------------------------
	---HTPT-CHANNEL------------------
	------------------------------'''
	
	xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.youtube/channel/UCcYT8oPT83Yuw4_GUZ3mMFg/)')			
	print "123" + space + skinlog_file
	if os.path.exists(skinlog_file):
		log = open(skinlog_file, 'r')
		message = log.read()
		log.close()
		diaogtextviewer('[COLOR=Yellow]' + htptskinversion + '[/COLOR]' + str75687 + "-", message)
		'''---------------------------'''
	
def mode40(admin):
	'''------------------------------
	---Skin.ResetSettings------------
	------------------------------'''
	returned = ""
	skinsettingsW = xbmc.getCondVisibility('Window.IsVisible(SkinSettings.xml)')
	if skinsettingsW: returned = dialogyesno(localize(74554) , localize(74556))
	if returned == 'ok' and skinsettingsW:
		'''------------------------------
		---DELETE-USER-FILES-------------
		------------------------------'''
		Clean_Library("10")
		Clean_Library("11")
		Clean_Library("12")
		Clean_Library("13")
	
	if returned == 'ok' or not skinsettingsW:	
		xbmc.executebuiltin('Skin.ResetSettings')
		notification_common("2")
		xbmc.sleep(4000)
		
		'''------------------------------
		---Apply-USER-IDS----------------
		------------------------------'''
		setSkinSetting5("0",'ID',idstr,'ID1',id1str,'ID2',id2str,'ID3',id3str,'ID4',id4str)
		setSkinSetting5("0",'ID5',id5str,'ID6',id6str,'ID7',id7str,'ID8',id8str,'ID9',id9str)
		setSkinSetting5("0",'ID10',id10str,'ID11',id11str,'ID12',id12str,'ID60',id60str,'',"")
		setSkinSetting5("0",'MAC',macstr,'MAC1',mac1str,'MAC2',mac2str,'',"",'MAC5',mac5str)
		setSkinSetting5("0",'fixip',fixip,'',"",'TrialDate',trialdate,'TrialDate2',trialdate2,'Country',countrystr)
		setSkinSetting5("1",'Trial',trial,'Trial2',trial2,'ID40',id40str,'',"",'',"")
		'''---------------------------'''
		setSkinSetting5("1",'Account1_Active',Account1_Active,'Account2_Active',Account2_Active,'Account3_Active',Account3_Active,'Account4_Active',Account4_Active,'Account5_Active',Account5_Active)
		setSkinSetting5("1",'',"",'',"",'',"",'',"",'Account10_Active',Account10_Active)
		setSkinSetting5("0",'Account1_Period',Account1_Period,'Account2_Period',Account2_Period,'Account3_Period',Account3_Period,'Account4_Period',Account4_Period,'Account5_Period',Account5_Period)
		setSkinSetting5("0",'Account6_Period',Account6_Period,'Account7_Period',Account7_Period,'Account8_Period',Account8_Period,'Account9_Period',Account9_Period,'Account10_Period',Account10_Period)
		'''---------------------------'''
		setSkinSetting5("0",'Account1_EndDate',Account1_EndDate,'Account2_EndDate',Account2_EndDate,'Account3_EndDate',Account3_EndDate,'Account4_EndDate',Account4_EndDate,'Account5_EndDate',Account5_EndDate)
		setSkinSetting5("0",'Account6_EndDate',Account6_EndDate,'Account7_EndDate',Account7_EndDate,'Account8_EndDate',Account8_EndDate,'Account9_EndDate',Account9_EndDate,'Account10_EndDate',Account10_EndDate)
		'''---------------------------'''
		setSkinSetting5("0",'LibraryData_RemoteDate',librarydataremotedatestr,'LibraryData_LocalDate',librarydatalocaldatestr,'',"",'',"",'',"")
		'''---------------------------'''
		
		'''------------------------------
		---Apply-PREFERED-SETTINGS-------
		------------------------------'''
		setSkinSetting5("0",'MusicLink',"Albums",'moviesestartup',"1",'tvshowsestartup',"1",'',"",'',"") #SKIN SETTINGS
		'''---------------------------'''
		setSkinSetting5("1",'myHTPT2',"true",'ShowClock',"true",'Backgrounds2',"true",'Genre',"true",'Rating',"true") #SKIN SETTINGS
		setSkinSetting5("1",'AutoView',"true",'StartUpMusic',"true",'AutoPlaySD',"true",'ShowDVDCases',"true",'ShowFileInfo',"true") #SKIN SETTINGS
		setSkinSetting5("1",'ShowTopVideoInformation',"true",'AutoShutdown',"true",'AllowDebug',"true",'FullFanartTopVideoInformation',"false",'',"") #SKIN SETTINGS
		setSkinSetting5("1",'hidetest',"true",'',"",'',"",'3dmovs',"true",'',"") #HOMEBUTTONS
		'''---------------------------'''
		
		'''------------------------------
		---Widgets-----------------------
		------------------------------'''
		setSkinSetting("1",'Widget',"true")
		setSkinSetting5("1",'',"",'MoviesShelfWL',"true",'TVShelf_Watchlist',"true",'',"",'',"") #GENERAL
		setSkinSetting5("1",'YouTube.21',"true",'YouTube.23',"true",'YouTube.26',"true",'YouTube.30',"true",'',"") #YOUTUBE
		setSkinSetting5("1",'GoPro.24',"true",'GoPro.25',"true",'GoPro.26',"true",'GoPro.30',"true",'',"") #GOPRO
		setSkinSetting5("1",'IsraelTV.21',"true",'',"",'IsraelTV.30',"true",'',"",'',"") #IsraelTV
		'''---------------------------'''
		
		'''------------------------------
		---performance-------------------
		------------------------------'''
		listL = ["C", "D"]
		if id10str in listL: setSkinSetting("1",'Performance',"true")
		'''---------------------------'''
		
	if skinsettingsW: returned = dialogyesno(localize(74557), localize(74556))
	if returned == 'ok' and skinsettingsW:
		'''------------------------------
		---RESET-ADDONS-SETTINGS---------
		------------------------------'''
		if skinsettingsW: dialogok('USERDATA DELETED!','[CR]' + 'THERE IS NO WAY BACK NOW...',"","")
		if not admin3:
			addonsL = []
			addonsL.append('script.htpt.homebuttons')
			addonsL.append('script.htpt.emu')
			addonsL.append('service.htpt')
			addonsL.append('plugin.video.htpt.kids')
			addonsL.append('plugin.video.htpt.music')
			addonsL.append('plugin.video.htpt.gopro')
			addonsL.append('script.htpt.smartbuttons')
			addonsL.append('plugin.video.p2p-streams')
			addonsL.append('plugin.program.advanced.launcher')
			addonsL.append('plugin.video.genesis')
			addonsL.append('plugin.video.youtube')
			'''---------------------------'''
			if admin:
				addonsL.append('script.htpt.remote')
				addonsL.append('script.htpt.fix')
				addonsL.append('script.htpt.debug')
				'''---------------------------'''
			removeaddons(addonsL,"23")
			'''---------------------------'''
		else:
			'''------------------------------
			---Apply-CURRENT-USER-SETTINGS---
			------------------------------'''
			setSkinSetting5("0",'MusicLink',musiclinkstr,'StartUpMusic',startupmusicstr,'',"",'',"",'',"") #SKIN SETTINGS
			setSkinSetting5("1",'Adult',adult,'Adult2',adult2,'',"",'',"",'',"") #SKIN SETTINGS
			'''---------------------------'''
	elif skinsettingsW: notification_common("9")

def mode42(admin, name, mac5str):
	'''------------------------------
	---FORMAT------------------------
	------------------------------'''
	printpoint = ""
	returned = dialogyesno('FORMAT YOUR DEVICE TOOL','CHOOSE YES TO PROCEED')
	if returned == 'ok':
		'''asking for a password'''
		returned = dialogkeyboard(mac5str,"Enter Password",5,'1','MAC5',"")
		if returned != 'skip':
			xbmc.sleep(1000)
			mac5str = xbmc.getInfoLabel('Skin.String(MAC5)')
			if mac5str != "":
				if mac5str == str70000:
					printpoint = printpoint + "7"
					notification("FORMAT WILL START IN 10 MIN!","REBOOT ASAP FOR CANCELING THE PROCESS!","",10000)
					'''---------------------------'''
				elif mac5str != str70000:
					printpoint = printpoint + "8"
					notification('$LOCALIZE[12342]',"BE SURE YOU KNOW WHAT YOU ARE DOING!!!","",10000)
					setSkinSetting("1",'ADMIN',"false")
					setSkinSetting("0",'ID9',"FTOOL")
					xbmc.executebuiltin('ReplaceWindow(Startup.xml)')
					xbmc.executebuiltin('RunScript(script.htpt.debug,,?mode=13)')
					'''---------------------------'''
					
	elif mac5str: xbmc.executebuiltin('Skin.SetString(MAC5,)')
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + name + "_LV" + printpoint + space + "mac5str" + space2 + str(mac5str) + space + " ( " + returned + " ) "
	'''---------------------------'''

def mode44(admin, name):
	'''------------------------------
	---OVERCLOCK---------------------
	------------------------------'''
	if not systemplatformlinuxraspberrypi and not admin3: notification_common("22")
	else:
		printpoint = ""
		setSkinSetting("0",'OverClockLevel', scriptopenelecrpiconfigoverclock_preset)
		list = ['-> (Exit)','Status','OverClocking'] #,'Stability Test'
		
		returned, value = dialogselect('$LOCALIZE[74433]',list,0)

		if returned == -1:
			printpoint = printpoint + "9"
			#notification_common("9")
		elif returned == 0: printpoint = printpoint + "8"
		elif returned == 1:
			'''------------------------------
			---STATUS------------------------
			------------------------------'''
			config_file = '/flash/config.txt'
			if not os.path.exists(config_file): dialogok("config.txt is missing!", "" ,"" ,"")
			else:
				output = catfile('/flash/config.txt')
				diaogtextviewer(config_file, output)
				'''---------------------------'''
		elif returned == 2: mode46(admin, 'OVERCLOCKING')
		#elif returned == 3: xbmc.executebuiltin('RunScript(script.htpt.smartbuttons,,?mode=45)')

def mode45(admin, name):
	'''------------------------------
	---STABILITY-TEST----------------
	------------------------------'''
	#bash('
	os.system('sh /storage/.kodi/addons/skin.htpt/specials/scripts/stabilitytest.sh')
	#xbmc

def mode46(admin,name):
	'''------------------------------
	---OVERCLOCKING------------------
	------------------------------'''
	printpoint = ""
	addon = 'script.openelec.rpi.config'
	if not xbmc.getCondVisibility('System.HasAddon('+ addon +')'): installaddon(admin, addon, "")
	else: xbmc.executebuiltin('RunScript('+addon+')')
	
	
def mode49(admin, name):
	'''------------------------------
	---SCRAPER-FIX-------------------
	------------------------------'''
	setsetting_custom1('service.htpt.fix','Fix_100',"true")
	setsetting_custom1('service.htpt.fix','Fix_101',"true")
	
	xbmc.executebuiltin('ActivateWindow(0)')
	xbmc.sleep(500)
	notification_common("2")
	xbmc.executebuiltin('RunScript(service.htpt.fix,,?mode=3)')	
	
	
def mode50(admin):
	'''------------------------------
	---SOFT-RESTART------------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	setsetting_custom1('script.htpt.debug','General_ScriptON',"true")
	setsetting_custom1('script.htpt.debug','ModeOn_7',"true")
	setsetting_custom1('script.htpt.debug','ModeTime_7',datenowS + "__" + timenow2S)
	killall(admin, custom="1")
	
	#xbmc.sleep(5000)
	#xbmc.executebuiltin('XBMC.Reset()')
	'''---------------------------'''

def mode51(admin):
	'''------------------------------
	---RESTART-----------------------
	------------------------------'''
	setsetting_custom1('script.htpt.debug','General_ScriptON',"true")
	setsetting_custom1('script.htpt.debug','ModeOn_8',"true")
	setsetting_custom1('script.htpt.debug','ModeTime_8',datenowS + "__" + timenow2S)
	#xbmc.sleep(1000)
	#xbmc.executebuiltin('XBMC.Reset()')
	killall(admin, custom="r")
	'''---------------------------'''

def mode52(admin):
	'''------------------------------
	---SUSPEND-----------------------
	------------------------------'''
	setsetting_custom1('script.htpt.debug','General_ScriptON',"true")
	setsetting_custom1('script.htpt.debug','ModeOn_4',"true")
	setsetting_custom1('script.htpt.debug','ModeTime_4',datenowS + "__" + timenow2S)
	xbmc.sleep(1000)
	xbmc.executebuiltin('XBMC.Suspend()')
	'''---------------------------'''

def mode53(admin):
	'''------------------------------
	---POWEROFF----------------------
	------------------------------'''
	setsetting_custom1('script.htpt.debug','ModeTime_10',datenowS + "__" + timenow2S)
	xbmc.executebuiltin('RunScript(script.htpt.debug,,?mode=10)')
	notification('$LOCALIZE[13016]','$LOCALIZE[31407]',"",4000)
	xbmc.sleep(1000)
	xbmc.sleep(3000)
	notification(startupmessage2,id1str,"",5000)
	xbmc.sleep(1000)
	killall(admin, custom="s")
	if not systemplatformwindows: xbmc.executebuiltin('XBMC.Powerdown()')
	'''---------------------------'''

def mode54(admin):
	'''------------------------------
	---QUIT--------------------------
	------------------------------'''
	#from shared_modules4 import *
	#setsetting_custom1('script.htpt.debug','ModeTime_10',datenowS + "__" + timenow2S)
	#xbmc.executebuiltin('RunScript(script.htpt.debug,,?mode=10)')
	#notification('$LOCALIZE[13016]','$LOCALIZE[31407]',"",4000)
	#guiset(admin, guiread)
	xbmc.sleep(500)
	killall(admin, custom="")
	#notification(startupmessage2,id1str,"",5000)
	'''---------------------------'''


def mode55(admin):
	'''------------------------------
	---LibraryData-------------------
	------------------------------'''
	#from variables import * #GAL TEST THIS!
	if os.path.exists(copydir + "library.zip"):
		notification("Looking for remote files","Please Wait","",10000)
		ExtractAll(copydir + "library.zip", copydir)
		notification("Comparing remote to local files","Please Wait.","",4000)
		path = os.path.join(copydir,'library.zip')
		removefiles(path)
		xbmc.sleep(500)
	elif admin: print printfirst + copydir + "library.zip"
	
	if not admin3 or 1 + 1 == 2:
		Afolders_count, Afolders_count2, Afiles_count = bash_count(copymoviesdir+'*')
		Bfolders_count, Bfolders_count2, Bfiles_count = bash_count(copytvshowsdir+'*')
		Cfolders_count, Cfolders_count2, Cfiles_count = bash_count(movies_path+'*')
		Dfolders_count, Dfolders_count2, Dfiles_count = bash_count(tvshows_path+'*')
		'''---------------------------'''
		setsetting_custom1(addonID,'LibraryData_RemoteMoviesFiles',Afolders_count2)
		setsetting_custom1(addonID,'LibraryData_RemoteTvshowsFiles',Bfolders_count2)
		setsetting_custom1(addonID,'LibraryData_LocalMoviesFiles',Cfolders_count2)
		setsetting_custom1(addonID,'LibraryData_LocalTvshowsFiles',Dfolders_count2)
		'''---------------------------'''
		LibraryData_RemoteMoviesFiles2 = getsetting('LibraryData_RemoteMoviesFiles')
		LibraryData_RemoteTvshowsFiles2 = getsetting('LibraryData_RemoteTvshowsFiles')
		if LibraryData_RemoteMoviesFiles != LibraryData_RemoteMoviesFiles2 or LibraryData_RemoteTvshowsFiles != LibraryData_RemoteTvshowsFiles2 or librarydataremotedatestr == "":
			notification(str24068.encode('utf-8') + space5 + datenowS,str79577.encode('utf-8'),"",4000) #Update available, Update Movies and Tvshows library
			setSkinSetting("0", 'LibraryData_RemoteDate', datenowS)
			'''---------------------------'''
		if admin: print printfirst + "LibraryData" + space + "Afolders_count2" + space2 + Afolders_count2 + space + "Bfolders_count2" + space2 + Bfolders_count2 + newline + \
		"LibraryData_RemoteMoviesFiles/2" + space2 + LibraryData_RemoteMoviesFiles + space4 + LibraryData_RemoteMoviesFiles2 + space + "LibraryData_RemoteTvshowsFiles/2" + space2 + LibraryData_RemoteTvshowsFiles + space4 + LibraryData_RemoteTvshowsFiles2

	xbmc.executebuiltin('RunScript(script.htpt.smartbuttons,,?mode=56)')
	
def mode56(admin, name, LibraryData_RemoteMoviesFiles, LibraryData_RemoteTvshowsFiles, LibraryData_LocalMoviesFiles, LibraryData_LocalTvshowsFiles, librarydataremotedatestr):
	'''------------------------------
	---LibrarySync-------------------
	------------------------------'''
	#from variables import * #GAL TEST THIS!
	printpoint = "" ; TypeError = ""
	
	try: LibraryData_RemoteMoviesFiles = int(LibraryData_RemoteMoviesFiles)
	except Exception, TypeError: LibraryData_RemoteMoviesFiles = 0
	try: LibraryData_RemoteTvshowsFiles = int(LibraryData_RemoteTvshowsFiles)
	except Exception, TypeError: LibraryData_RemoteTvshowsFiles = 0
	try: LibraryData_LocalMoviesFiles = int(LibraryData_LocalMoviesFiles)
	except Exception, TypeError: LibraryData_LocalMoviesFiles = 0
	try: LibraryData_LocalTvshowsFiles = int(LibraryData_LocalTvshowsFiles)
	except Exception, TypeError: LibraryData_LocalTvshowsFiles = 0
	Remotevslocal1 = LibraryData_RemoteMoviesFiles - LibraryData_LocalMoviesFiles
	Remotevslocal2 = LibraryData_RemoteTvshowsFiles - LibraryData_LocalTvshowsFiles
	'''---------------------------'''
	
	'''------------------------------
	---CHECK-FOR-LibrarySync_ON------
	------------------------------'''
	if librarydataremotedatestr != "":
		printpoint = printpoint + "0"
		if (Remotevslocal1 + Remotevslocal2) > 0 or librarydataremotedatestr != librarydatalocaldatestr or librarydatalocaldatestr == "":
			printpoint = printpoint + "1"
			if librarydatalocaldatestr == "" and librarydataremotedatestr == librarydatalocaldatestr: setSkinSetting("0", 'LibraryData_LocalDate', librarydatalocaldatestr + "*")
		else: notification("Your library is up to date!", "", "", 2000)
	elif librarydataremotedatestr != "" and librarydataremotedatestr == librarydatalocaldatestr and (Remotevslocal1 + Remotevslocal2) <= 0:
		printpoint = printpoint + "2"
		if skinsettingsW: notification('$LOCALIZE[79578]', '$LOCALIZE[79579]',"",4000) #The library already synced		
	else:
		printpoint = printpoint + "9"
		#notification_common("17")
		'''---------------------------'''
	#if librarydataremotedatestr == librarydataremotedate2str: setSkinSetting("0", 'LibraryData_LocalDate', librarydataremotedate2str + "?")
	if "1" in printpoint:
		'''------------------------------
		---CONTINUE----------------------
		------------------------------'''
		returned, value = getRandom("0",percent=40)
		if skinsettingsW or admin or "special://userdata/library/movies/" or "special://userdata/library/tvshows/" or returned == "ok":
			'''------------------------------
			---CONTINUE----------------------
			------------------------------'''
			printpoint = printpoint + "3"
			if librarydatalocaldatestr != "": option = str24056.encode('utf-8') % (librarydatalocaldatestr)
			else: option = '$LOCALIZE[79580]'
			
			dialogyesnoW = xbmc.getCondVisibility('Window.IsVisible(DialogYesNo.xml)')
			while dialogyesnoW and not xbmc.abortRequested:
				xbmc.sleep(2500)
				dialogyesnoW = xbmc.getCondVisibility('Window.IsVisible(DialogYesNo.xml)')
				xbmc.sleep(2500)
				
			returned = dialogyesno('[COLOR=Yellow]' + str79577.encode('utf-8') + '[/COLOR]',str24068.encode('utf-8') + ', ' + str12354.encode('utf-8') + '[CR]' + option)
			if "ok" in returned:
				'''------------------------------
				---CONTINUE----------------------
				------------------------------'''
				printpoint = printpoint + "7"
				copyfiles(os.path.join(copylibrarydir, '*'), library_path)
				xbmc.sleep(1000)
				setSkinSetting("0", 'LibraryData_LocalDate', librarydataremotedatestr)
				containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
				libraryisscanningvideo = xbmc.getCondVisibility('Library.IsScanningVideo')
				if not libraryisscanningvideo: xbmc.executebuiltin('UpdateLibrary(video)')
				if not admin:
					if Remotevslocal1 < 0: Remotevslocal1 = 0
					if Remotevslocal2 < 0: Remotevslocal2 = 0
					'''---------------------------'''
				dialogok(localize(79577) + '[CR]' + localize(79072), str79584 % (str(Remotevslocal1),str(Remotevslocal2)), "", "", line1c="Yellow")
				'''---------------------------'''
			else: notification_common("9")

	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if TypeError != "": print printfirst + "LibrarySync" + space + "TypeError" + space2 + str(TypeError)
	if admin: print printfirst + "LibrarySync_LV" + printpoint + space + "Remotevslocal1" + space2 + str(Remotevslocal1) + space + "Remotevslocal2" + space2 + str(Remotevslocal2)
	'''---------------------------'''

def mode59(admin, name, printpoint):
	'''------------------------------
	---Choose-Country----------------
	------------------------------'''
	
	list = ['-> (Exit)', 'Israel', 'Foreign (English)']
	if scripthtptinstall_Skin_Installed == "true" or countrystr == "": list.remove(list[0])
	
	returned, value = dialogselect('$LOCALIZE[74433]',list,0)
	
	if returned == -1: printpoint = printpoint + "9"
	elif returned == 0: printpoint = printpoint + "8"
	else: printpoint = printpoint + "7"
		
	if "7" in printpoint or countrystr == "" or scripthtptinstall_Skin_Installed == "true":
		if value != "": setSkinSetting('0', 'Country', value)
		else: value = 'Israel'
		if value == "Israel": xbmc.executebuiltin('SetGUILanguage(Hebrew)')
		elif "Foreign" in value: xbmc.executebuiltin('SetGUILanguage(English)')
		xbmc.sleep(1000)
		setAutoSettings("3")
		dialogok("Your current country is: "+value+"", "The system will change all contents and settings in order to fit your choosen country!", "Please note this feature is WIP and may not work at all atm..", "")	
	
	print printfirst + name + "_LV" + printpoint + space + "list" + space2 + str(list) + space + "returned" + space2 + str(returned)

def mode60(admin, name):
	'''------------------------------
	---Remove-Skin-------------------
	------------------------------'''
	pass
	'''---------------------------'''
def mode63(admin, name):
	'''------------------------------
	---Texture-Cache-Removal---------
	------------------------------'''
	pass
	'''---------------------------'''

def mode64(admin, name):
	'''------------------------------
	---?--------------------
	------------------------------'''
	pass
	'''---------------------------'''
	
def mode70(admin, name):
	'''------------------------------
	---ExtendedInfo------------------
	------------------------------'''
	addon = 'script.extendedinfo' ; input = "" ; input2 = 'name' ; printpoint = "" ; container50listitemlabel2 = "" ; dialogselectsources7 = xbmc.getInfoLabel('Skin.String(DialogSelectSources7)') ; dialogselectsources7_ = ""
	if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
		if dialogselectsources7 != "" and dialogselectW:
			printpoint = printpoint + "1"
			xbmc.executebuiltin('dialog.close(selectdialog)')
			xbmc.sleep(500)
			if dialogselectsources7 == listitemdirector:
				printpoint = printpoint + "2"
				name = name + space2 + "Director"
				input = dialogselectsources7
				if input != "":
					printpoint = printpoint + "3"
					input2 = 'director'
					xbmc.executebuiltin('RunScript('+addon+',info=directormovies,'+input2+'='+input+')')
				else: printpoint = printpoint + "4"
			else:
				printpoint = printpoint + "5"
				name = name + space2 + "Actors"
				dialogselectsources7_ = find_string(dialogselectsources7, dialogselectsources7[:1], xbmc.getInfoLabel('$LOCALIZE[20347]'))
				str20347_len = len(xbmc.getInfoLabel('$LOCALIZE[20347]'))
				dialogselectsources7_ = dialogselectsources7_[:-str20347_len]
				input = dialogselectsources7_
				if input != "":
					xbmc.executebuiltin('RunScript('+addon+',info=extendedactorinfo,'+input2+'='+input+')')
		else:
			name = name + space2 + "Movie Info"
			printpoint = printpoint + "1"
			if listitemtvshowtitle != "":
				printpoint = printpoint + "2"
				input = listitemtvshowtitle
				if 1 + 1 == 3:
					try: listitemdbidN = int(listitemdbid)
					except: listitemdbidN = ""
					if listitemdbidN != "":
						printpoint = printpoint + "3"
						input = listitemdbid
						input2 = 'dbid'
					else: input = listitemtvshowtitle
			elif listitemtitle != "": input = listitemtitle
			elif listitemlabel != "": input = listitemlabel
			'''---------------------------'''
			
			if input != "":
				#RunScript(script.extendedinfo,info=extendedinfo,name=MOVIENAME)
				#xbmc.executebuiltin('RunScript(script.extendedinfo,info=extendedinfo,name=MOVIENAME')
				xbmc.executebuiltin('RunScript('+addon+',info=extendedinfo,'+input2+'='+input+')')
				count = 0 ; dialogvideonfoEW = xbmc.getCondVisibility('Window.IsVisible(script-ExtendedInfo Script-DialogVideoInfo.xml)')
				while count < 10 and not dialogvideonfoEW and not xbmc.abortRequested:
					count += 1
					xbmc.sleep(500)
					dialogvideonfoEW = xbmc.getCondVisibility('Window.IsVisible(script-ExtendedInfo Script-DialogVideoInfo.xml)')
				if count < 10: printpoint = printpoint + "7"
				else: printpoint = printpoint + "9"
			else:
				printpoint = printpoint + "8"
				notification_common("17")
				'''---------------------------'''
	else:
		printpoint = printpoint + "9"
		installaddon(admin, addon, "")
	if admin: print printfirst + name + "_LV" + printpoint + space + "input" + space2 + input + space + space + "input2" + space2 + input2 + space + newline + "INFO" + space2 + "listitemlabel" + space2 + listitemlabel + newline + "listitemtvshowtitle" + space2 + listitemtvshowtitle + newline + "listitemtitle" + space2 + listitemtitle + newline + "listitemimdbnumber" + space2 + listitemimdbnumber + newline + "listitemdbid" + space2 + listitemdbid + newline + "containerfolderpath" + space2 + containerfolderpath + newline + "dialogselectsources7" + space2 + dialogselectsources7 + space + "dialogselectsources7_" + space2 + str(dialogselectsources7_) + newline + "listitemdirector" + space2 + listitemdirector
	'''---------------------------'''
	
def mode100(admin, name):
	'''------------------------------
	---STARTUP-TRIGGER---------------
	------------------------------'''
	printpoint = "" ; dialogtextviewerW = xbmc.getCondVisibility('Window.IsVisible(DialogTextViewer.xml)')
	while dialogtextviewerW and not xbmc.abortRequested:
		xbmc.sleep(1000)
		dialogtextviewerW = xbmc.getCondVisibility('Window.IsVisible(DialogTextViewer.xml)')
		'''---------------------------'''

	setAutoSettings("0")
	xbmc.sleep(500)
	'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + name + "_LV" + printpoint
	'''---------------------------'''

def mode200(admin, name, printpoint):
	'''------------------------------
	---TRANSPERANCY-SELECTED-ICON----
	------------------------------'''
	list = ['-> (Exit)', 'default', '10', '20', '30', '40', '50', '60', '70', '80', '90', '100']
	
	container50hasfocus210 = xbmc.getCondVisibility('Container(50).HasFocus(210)') #Selected Icon
	container50hasfocus250 = xbmc.getCondVisibility('Container(50).HasFocus(250)') #Main background
	container50hasfocus254 = xbmc.getCondVisibility('Container(50).HasFocus(254)') #TopInformationOverlay
	container50hasfocus256 = xbmc.getCondVisibility('Container(50).HasFocus(256)') #TopVideoInformationOverlay
	container50hasfocus265 = xbmc.getCondVisibility('Container(50).HasFocus(265)') #TopMainBackgroundOverlay
	container50hasfocus270 = xbmc.getCondVisibility('Container(50).HasFocus(270)') #LeftMenuOverlay
	container50hasfocus273 = xbmc.getCondVisibility('Container(50).HasFocus(273)') #BottomMenuOverlay
	container50hasfocus276 = xbmc.getCondVisibility('Container(50).HasFocus(276)') #CenterMenuOverlay
	
	if not container50hasfocus210 and not container50hasfocus250 and not container50hasfocus254 and not container50hasfocus256 and not container50hasfocus265 and not container50hasfocus270 and not container50hasfocus273 and not container50hasfocus276: returned = 'skip'
	else: returned, value = dialogselect('$LOCALIZE[74433]',list,0)
	
	if returned == -1: printpoint = printpoint + "9"
	elif returned == 0: printpoint = printpoint + "8"
	else: printpoint = printpoint + "7"
	
	if "7" in printpoint:
		if container50hasfocus210:
			if value == 'default': setSkinSetting('0', 'IconOverlayButton', "")
			elif value != "": setSkinSetting('0', 'IconOverlayButton', value)
			else: value = '40'
		elif container50hasfocus250:
			if value == 'default': setSkinSetting('0', 'MainBackgroundOverlay', "")
			elif value != "": setSkinSetting('0', 'MainBackgroundOverlay', value)
			else: value = '40'
		elif container50hasfocus254:
			if value == 'default': setSkinSetting('0', 'TopInformationOverlay', "")
			elif value != "": setSkinSetting('0', 'TopInformationOverlay', value)
			else: value = '70'
		elif container50hasfocus256:
			if value == 'default': setSkinSetting('0', 'TopVideoInformationOverlay', "")
			elif value != "": setSkinSetting('0', 'TopVideoInformationOverlay', value)
			else: value = '70'
		elif container50hasfocus265:
			if value == 'default': setSkinSetting('0', 'TopMainBackgroundOverlay', "")
			elif value != "": setSkinSetting('0', 'TopMainBackgroundOverlay', value)
			else: value = '70'
		elif container50hasfocus270:
			if value == 'default': setSkinSetting('0', 'LeftMenuOverlay', "")
			elif value != "": setSkinSetting('0', 'LeftMenuOverlay', value)
			else: value = '70'
		elif container50hasfocus273:
			if value == 'default': setSkinSetting('0', 'BottomMenuOverlay', "")
			elif value != "": setSkinSetting('0', 'BottomMenuOverlay', value)
			else: value = '70'
		elif container50hasfocus276:
			if value == 'default': setSkinSetting('0', 'CenterMenuOverlay', "")
			elif value != "": setSkinSetting('0', 'CenterMenuOverlay', value)
			else: value = '70'
			
		notification(".","","",1000)
		xbmc.sleep(200)
		xbmc.executebuiltin('Action(Back)')
		xbmc.sleep(800)
		notification("..","","",1000)
		xbmc.sleep(200)
		xbmc.executebuiltin('ReloadSkin()')
	
	print printfirst + name + "_LV" + printpoint + space + "list" + space2 + str(list) + space + "returned" + space2 + str(returned) + space + "value" + space2 + str(value)
	'''---------------------------'''

def mode201(admin, name, printpoint):
	'''------------------------------
	---RESET-TO-DEFAULT--------------
	------------------------------'''
	container50hasfocus299 = xbmc.getCondVisibility('Container(50).HasFocus(299)') #BUTTONS
	
	if not container50hasfocus299: returned = 'skip'
	else: list = ['-> (Exit)', localize(10035) + space + "(" + localize(593) + ")", localize(590) + space + "(" + localize(593) + ")", \
	localize(74840) + space + "(" + localize(78219) + ")", localize(74840) + space + localize(590) + space + "(" + localize(78219) + ")", \
	localize(74840) + space + "(" + localize(593) + ")", localize(74840) + space + localize(590) + space + "(" + localize(593) + ")", \
	localize(10035) + space + localize(78215) + space + "(" + localize(593) + ")", localize(10035) + space + localize(78215) + space + localize(590) + space + "(" + localize(593) + ")"]
	
	returned, value = dialogselect(localize(74433),list,0)
	
	if returned == -1: printpoint = printpoint + "9"
	elif returned == 0: printpoint = printpoint + "8"
	else: printpoint = printpoint + "7"
		
	if "7" in printpoint and not "8" in printpoint and not "9" in printpoint:
		if returned == 1: printpoint = printpoint + "ACEG" #RESET-ALL
		elif returned == 2: printpoint = printpoint + "BDFH" #RANDOM-ALL
		elif returned == 3: printpoint = printpoint + "C" #RESET-BUTTONS-COLORS
		elif returned == 4: printpoint = printpoint + "D" #RANDOM-BUTTONS-COLORS
		elif returned == 5: printpoint = printpoint + "CE" #RESET-ALL-COLORS
		elif returned == 6: printpoint = printpoint + "DF" #RANDOM-ALL-COLORS
		elif returned == 7: printpoint = printpoint + "G" #RESET-ALL-TRANSPERANCY
		elif returned == 8: printpoint = printpoint + "H" #RANDOM-ALL-TRANSPERANCY
			
		notification(".","","",1000)
		xbmc.sleep(200)
		xbmc.executebuiltin('Action(Back)')
		xbmc.sleep(800)
		notification("..","","",1000)
		xbmc.sleep(200)
		xbmc.executebuiltin('ReloadSkin()')
	
	if "A" in printpoint:	
		setSkinSetting5('0', 'IconOverlayButton', '', '', "", '', "", '', "", '', "")
		setSkinSetting5('1', 'SelectionMarker', 'false', 'SelectionMarker2', 'false', 'ShadowButton', 'false', 'OverlayButton', 'false', '', "")
		'''---------------------------'''
	
	if "B" in printpoint:
		returned1, value1 = getRandom("0", min=0, max=100, percent=50)
		returned2, value2 = getRandom("0", min=0, max=100, percent=50)
		returned3, value3 = getRandom("0", min=0, max=100, percent=50)
		returned4, value4 = getRandom("0", min=0, max=100, percent=50)
		returned5, value5 = getRandom("0", min=0, max=100, percent=50)
					
		if returned1 == 'ok': value1 = "true"
		else: value1 = "false"
		if returned2 == 'ok': value2 = "true"
		else: value2 = "false"
		if returned3 == 'ok': value3 = "true"
		else: value3 = "false"
		if returned4 == 'ok': value4 = "true"
		else: value4 = "false"
		if returned5 == 'ok': value5 = "true"
		else: value5 = "false"
			
		setSkinSetting5('1', 'SelectionMarker', value1, 'SelectionMarker2', value2, 'ShadowButton', value3, 'OverlayButton', value4, '', "")
		'''---------------------------'''
		
	if "C" in printpoint:
		value1 = 'overlay'
		setSkinSetting5('0', 'color340', value1, 'color341', value1, 'color342', value1, 'color343', value1, 'color344', value1)
		setSkinSetting5('0', 'color320', value1, 'color321', value1, 'color345', value1, 'color507', value1, 'color323', value1)
		setSkinSetting5('0', 'color351', value1, 'color327', value1, 'color325', value1, 'color508', value1, 'color322', value1)
		setSkinSetting5('0', 'color324', value1, 'color331', value1, 'color330', value1, 'color352', value1, 'color355', value1)
		setSkinSetting5('0', 'color357', value1, '', "", '', "", '', "", '', "")
		setSkinSetting5('0', 'color401', value1, 'color402', value1, 'color403', value1, 'color404', value1, 'color405', value1)
		setSkinSetting5('0', 'color601', value1, 'color602', value1, 'color603', value1, 'color604', value1, 'color605', value1)
		setSkinSetting5('0', 'color346', value1, 'color348', value1, 'color349', value1, '', "", '', "")
		'''---------------------------'''
	
	if "D" in printpoint:
		returned, value1 = getRandom("0", min=0, max=70, percent=50)
		returned, value2 = getRandom("0", min=0, max=70, percent=50)
		returned, value3 = getRandom("0", min=0, max=70, percent=50)
		returned, value4 = getRandom("0", min=0, max=70, percent=50)
		returned, value5 = getRandom("0", min=0, max=70, percent=50)
		listL = [value1, value2, value3, value4, value5]
		count = 0
		for value in listL:
			count += 1
			if value > 0 and value <= 5: value = 'overlay'
			elif value > 5 and value <= 10: value = 'base'
			elif value > 10 and value <= 15: value = 'lightblue'
			elif value > 15 and value <= 20: value = 'red'
			elif value > 20 and value <= 25: value = 'green'
			elif value > 25 and value <= 30: value = 'bluegray'
			elif value > 30 and value <= 35: value = 'progcolor'
			elif value > 35 and value <= 40: value = 'purple'
			elif value > 40 and value <= 45: value = 'teak'
			elif value > 45 and value <= 50: value = 'darkorange'
			elif value > 50 and value <= 55: value = 'darkblue'
			elif value > 55 and value <= 60: value = 'darkgreen'
			elif value > 60 and value <= 65: value = 'lightyellow'
			elif value > 65 and value <= 70: value = 'pink'
			
			if count == 1: value1 = value
			elif count == 2: value2 = value
			elif count == 3: value3 = value
			elif count == 4: value4 = value
			elif count == 5: value5 = value
			
		
		setSkinSetting5('0', 'color340', value1, 'color341', value2, 'color342', value3, 'color343', value4, 'color344', value5)
		setSkinSetting5('0', 'color320', value1, 'color321', value2, 'color345', value3, 'color507', value4, 'color323', value5)
		setSkinSetting5('0', 'color351', value1, 'color327', value2, 'color325', value3, 'color508', value4, 'color322', value5)
		setSkinSetting5('0', 'color324', value1, 'color331', value2, 'color330', value3, 'color352', value4, 'color355', value5)
		setSkinSetting5('0', 'color357', value1, '', "", '', "", '', "", '', "")
		setSkinSetting5('0', 'color401', value1, 'color402', value2, 'color403', value3, 'color404', value4, 'color405', value5)
		setSkinSetting5('0', 'color601', value1, 'color602', value2, 'color603', value3, 'color604', value4, 'color605', value5)
		setSkinSetting5('0', 'color346', value1, 'color348', value2, 'color349', value3, '', "", '', "")
		'''---------------------------'''
	
	if "E" in printpoint:
		setSkinSetting5('0', 'TopInformationColor', "", 'TopInformationColor_', "", 'TopVideoInformationColor', "", 'TopVideoInformationColor_', "", '', "")
		'''---------------------------'''

	if "F" in printpoint:
		returned, value1 = getRandom("0", min=0, max=50, percent=50)
		returned, value2 = getRandom("0", min=0, max=50, percent=50)
		returned, value3 = getRandom("0", min=0, max=50, percent=50)
		returned, value4 = getRandom("0", min=0, max=50, percent=50)
		returned, value5 = getRandom("0", min=0, max=50, percent=50)
		listL = [value1, value2, value3, value4, value5]
		count = 0
		for value in listL:
			count += 1
			if value > 0 and value <= 5:
				value = ''
				value_ = 'Default'
			if value > 5 and value <= 10:
				value = 'A0'
				value_ = 'None'
			if value > 10 and value <= 15:
				value = 'A1'
				value_ = localize(762)
			if value > 15 and value <= 20:
				value = 'A2'
				value_ = localize(13343)
			if value > 20 and value <= 25:
				value = 'A3'
				value_ = localize(79151)
			if value > 25 and value <= 30:
				value = 'A4'
				value_ = localize(79152)
			if value > 30 and value <= 35:
				value = 'A5'
				value_ = localize(766)
			if value > 35 and value <= 40:
				value = 'A6'
				value_ = localize(767)
			if value > 40 and value <= 45:
				value = 'A7'
				value_ = localize(743)
			if value > 45 and value <= 50:
				value = 'A8'
				value_ = localize(353)
			
			if count == 1: value1 = value ; value1_ = value_
			elif count == 2: value2 = value ; value2_ = value_
			elif count == 3: value3 = value ; value3_ = value_
			elif count == 4: value4 = value ; value4_ = value_
			elif count == 5: value5 = value ; value5_ = value_
			
		
		setSkinSetting5('0', 'TopInformationColor', value1, 'TopInformationColor_', value1_, 'TopVideoInformationColor', value2, 'TopVideoInformationColor_', value2_, '', "")
		'''---------------------------'''
		
	if "G" in printpoint:
		setSkinSetting5('0', 'IconOverlayButton', "", 'TopMainBackgroundOverlay', "", '', "", '', "", '', "") #BUTTONS
		setSkinSetting5('0', '', "", '', "", 'LeftMenuOverlay', "", 'BottomMenuOverlay', "", 'CenterMenuOverlay', "") #MENU
		setSkinSetting5('0', 'TopVideoInformationOverlay', "", 'TopMainBackgroundOverlay', "", 'TopInformationOverlay', "", '', "", '', "") #OTHERS
		'''---------------------------'''
		
	if "H" in printpoint:
		returned, value1 = getRandom("0", min=0, max=55, percent=50)
		returned, value2 = getRandom("0", min=0, max=55, percent=50)
		returned, value3 = getRandom("0", min=0, max=55, percent=50)
		returned, value4 = getRandom("0", min=0, max=55, percent=50)
		returned, value5 = getRandom("0", min=0, max=55, percent=50)
		listL = [value1, value2, value3, value4, value5]
		count = 0
		for value in listL:
			count += 1
			if value > 0 and value <= 5: value = ''
			elif value > 5 and value <= 10: value = '10'
			elif value > 10 and value <= 15: value = '20'
			elif value > 15 and value <= 20: value = '30'
			elif value > 20 and value <= 25: value = '40'
			elif value > 25 and value <= 30: value = '50'
			elif value > 30 and value <= 35: value = '60'
			elif value > 35 and value <= 40: value = '70'
			elif value > 40 and value <= 45: value = '80'
			elif value > 45 and value <= 50: value = '90'
			elif value > 50 and value <= 55: value = '100'
			
			if count == 1: value1 = str(value)
			elif count == 2: value2 = str(value)
			elif count == 3: value3 = str(value)
			elif count == 4: value4 = str(value)
			elif count == 5: value5 = str(value)
			'''---------------------------'''
		
		setSkinSetting5('0', 'IconOverlayButton', value1, 'TopMainBackgroundOverlay', value2, '', "", '', "", '', "") #BUTTONS
		setSkinSetting5('0', '', "", '', "", 'LeftMenuOverlay', value1, 'BottomMenuOverlay', value2, 'CenterMenuOverlay', value3) #MENU
		setSkinSetting5('0', 'TopVideoInformationOverlay', value1, 'TopMainBackgroundOverlay', value2, 'TopInformationOverlay', value3, '', "", '', "") #OTHERS
		'''---------------------------'''
		
	print printfirst + name + "_LV" + printpoint + space + "list" + space2 + str(list) + space + "returned" + space2 + str(returned)
	'''---------------------------'''

def mode202(admin, name, printpoint):
	'''------------------------------
	---CHOOSE-COLORS-2---------------
	------------------------------'''
	container50hasfocus253 = xbmc.getCondVisibility('Container(50).HasFocus(253)') #TopInformationColor
	container50hasfocus255 = xbmc.getCondVisibility('Container(50).HasFocus(255)') #TopVideoInformationColor
	x = xbmc.getInfoLabel('Container(9003).ListItem(0).Label')
	x2 = xbmc.getInfoLabel('Container(9003).ListItemNoWrap(0).Property(colorID)')
	y = xbmc.getInfoLabel('Container(9003).ListItemNoWrap(0).Property(color)')
	listitempropertycolor = xbmc.getInfoLabel('ListItem.Property(color)')
	if skinsettingsW and container50hasfocus253:
		printpoint = printpoint + "1"
		setSkinSetting('0', 'TopInformationColor', x2)
		if x2 != "": setSkinSetting('0', 'TopInformationColor_', x)
		else: setSkinSetting('0', 'TopInformationColor_', "")
		notification(localize(78020) + space + localize(78019), x, "", 2000)
		xbmc.executebuiltin('SetFocus(50)')
		'''---------------------------'''
	if skinsettingsW and container50hasfocus255:
		printpoint = printpoint + "1"
		setSkinSetting('0', 'TopVideoInformationColor', x2)
		if x2 != "": setSkinSetting('0', 'TopVideoInformationColor_', x)
		else: setSkinSetting('0', 'TopVideoInformationColor_', "")
		notification(localize(78020) + space + localize(20159), x, "", 2000)
		xbmc.executebuiltin('SetFocus(50)')
		'''---------------------------'''
			
	else: printpoint = printpoint + "9"
	print printfirst + name + "_LV" + printpoint + space + "x" + space2 + str(x) + space + "x2" + space2 + str(x2) + space + "y" + space2 + str(y)
	'''---------------------------'''
	
def mode63(admin, name):
	'''------------------------------
	---Texture-Cache-Removal---------
	------------------------------'''
	returned = dialogyesno("Are you sure?", "Doing so will delete your database and thumbnails folder!")
	if returned == "ok":
		dp = xbmcgui.DialogProgress()
		dp.create("HTPT Texture-Cache-Removal", "Removing Datebase", " ")
		removefiles(database_path)
		dp.update(20,"Removing Thumbnails"," ")
		removefiles(thumbnails_path)
		dp.update(90,str79072.encode('utf-8')," ")
		setsetting_custom1('service.htpt.fix','Fix_100',"true")
		setsetting_custom1('service.htpt.fix','Fix_101',"true")
		xbmc.sleep(1000)
		dp.update(100,str79072.encode('utf-8')," ")
		dp.close
		dialogok("Reboot Required!", "Click OK", "", "")
		xbmc.executebuiltin('RunScript(script.htpt.smartbuttons,,?mode=50)')
		
	else: notification_common("9")		
def mode94(admin):
	if systemhasaddon_genesis:
		'''------------------------------
		---TRAKT-TV-BUTTON---------------
		------------------------------'''
		account_button('TRAKT TV','plugin.video.genesis', 'trakt_user', 'trakt_password', trakt_user, trakt_password, 'Account10_Active', '', '', Account10_Active, "N/A", "N/A", "")
		'''---------------------------'''

def mode95(admin):
	if systemhasaddon_sdarottv:
		'''------------------------------
		---SDAROT-TV-BUTTON--------------
		------------------------------'''
		account_button('SDAROT TV','plugin.video.sdarot.tv', 'username', 'user_password', sdarottv_user, sdarottv_password, 'Account2_Active', 'Account2_Period', 'Account2_EndDate', Account2_Active, Account2_Period, Account2_EndDate, "")
		'''---------------------------'''

def mode96(admin):
	if systemhasaddon_genesis:
		'''------------------------------
		---NOOBROOM-BUTTON---------------
		------------------------------'''
		notification_common("10")
		#account_button('NOOBROOM','plugin.video.genesis', 'noobroom_mail', 'noobroom_password', noobroom_mail, noobroom_password, 'Account5_Active', 'Account5_Period', 'Account5_EndDate', Account5_Active, Account5_Period, Account5_EndDate, "")
		'''---------------------------'''
		
def mode97(admin):
	if systemhasaddon_genesis:
		'''------------------------------
		---PREMIUMIZE-BUTTON-------------
		------------------------------'''
		notification_common("10")
		#account_button('PREMIUMIZE','plugin.video.genesis', 'premiumize_user', 'premiumize_password', premiumize_user, premiumize_password, 'Account4_Active', 'Account4_Period', 'Account4_EndDate', Account4_Active, Account4_Period, Account4_EndDate, "")
		'''---------------------------'''

def mode98(admin):
	if systemhasaddon_genesis:
		'''------------------------------
		---MOVREEL-BUTTON----------------
		------------------------------'''
		notification_common("10")
		#account_button('MOVREEL','plugin.video.genesis', 'movreel_user', 'movreel_password', movreel_user, movreel_password, 'Account3_Active', 'Account3_Period', 'Account3_EndDate', Account3_Active, Account3_Period, Account3_EndDate, "")
		'''---------------------------'''

def mode99(admin):
	if systemhasaddon_genesis:
		'''------------------------------
		---REALDEBRID-BUTTON-------------
		------------------------------'''
		account_button('REALDEBRID','plugin.video.genesis', 'realdedrid_user', 'realdedrid_password', realdedrid_user, realdedrid_password, 'Account1_Active', 'Account1_Period', 'Account1_EndDate', Account1_Active, Account1_Period, Account1_EndDate, "")
		'''---------------------------'''		

def account_button(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, custom):
	getsetting_addon         = xbmcaddon.Addon(addon).getSetting
	setsetting_addon         = xbmcaddon.Addon(addon).setSetting
	#setsetting_custom1(addon,set1,set1v)
	printpoint = ""
	'''---------------------------'''
	if skinsetting:
		'''------------------------------
		---DIALOG-YESNO-USER+PASS--------
		------------------------------'''
		returned = dialogyesno(localize(79483), localize(79484) + '[CR]' + addonString(73).encode('utf-8') % (username))
		if returned == 'ok':
			'''------------------------------
			---DIALOG-KEYBOARD-USER----------
			------------------------------'''
			printpoint = printpoint + "1"
			if 'htpt' in username: username = ""
			returned = dialogkeyboard(username,'$LOCALIZE[20142]',0,'3',usernameS,addon)
			if returned == 'skip':
				notification_common("3")
				printpoint = printpoint + "8"
				'''---------------------------'''
			else:
				'''------------------------------
				---DIALOG-KEYBOARD-PASS----------
				------------------------------'''
				printpoint = printpoint + "2"
				returned = dialogkeyboard(password,'$LOCALIZE[15052]',1,'3',passwordS,addon)
				if returned == 'skip':
					notification('$LOCALIZE[257]',addonString(69).encode('utf-8'),"",2000)
					printpoint = printpoint + "8"
				else:
					printpoint = printpoint + "3"
					'''---------------------------'''
		'''------------------------------
		---DIALOG-YES-NO-PERIOD----------
		------------------------------'''
		if not "8" in printpoint and skinsetting2 != "N/A":
			returned = dialogyesno(localize(79482), addonString(71).encode('utf-8') % (skinsetting2))
			if returned == 'ok':
				printpoint = printpoint + "4"
				returned, set1v = dialognumeric(0, localize(12393),skinsetting2,'2',skinsetting2S,"")
				if returned == 'skip': notification('$LOCALIZE[257]',addonString(69).encode('utf-8'),"",2000)
				else:
					printpoint = printpoint + "5"
					
		if printpoint == "" or "8" in printpoint:
			'''------------------------------
			---DIALOG-YES-NO-TURNOFF---------
			------------------------------'''
			returned = dialogyesno(localize(79479), addonString(73).encode('utf-8') % (username))
			if returned == 'ok':
				setSkinSetting("1", skinsettingS, "false")
				setSkinSetting("0", skinsetting2S, "")
				setSkinSetting("0", skinsetting3S, "")
				setsetting_custom1(addon,usernameS,"")
				setsetting_custom1(addon,passwordS,"")
				'''---------------------------'''
			else:
				notification_common("9")
				'''---------------------------'''
				
		if ("1" in printpoint and "3" in printpoint) or ("4" in printpoint and "5" in printpoint):
			'''------------------------------
			---DIALOG-OK-ACCOUNT-EDITED------
			------------------------------'''
			xbmc.sleep(500)
			skinsetting = xbmc.getInfoLabel('Skin.HasSetting('+ skinsettingS +')')
			skinsetting2 = xbmc.getInfoLabel('Skin.String('+ skinsetting2S +')')
			username = getsetting_addon(usernameS)
			password = getsetting_addon(passwordS)
			'''---------------------------'''
			
			if name == "REALDEBRID":
				'''------------------------------
				---REALDEBRID--------------------
				------------------------------'''
				dialogok(addonString(56).encode('utf-8') % ('[COLOR=Yellow]' + name + '[/COLOR]'),addonString(73).encode('utf-8') % (username),addonString(61).encode('utf-8') % (password),addonString(71).encode('utf-8') % (skinsetting2))
				dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + localize(79485) + space2 + localize(305), localize(79604) + space2, localize(79603), localize(79602))
				set_accountdate(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, "0")
				'''---------------------------'''
				
			elif name == "SDAROT TV":
				'''------------------------------
				---SDAROT-TV---------------------
				------------------------------'''
				dialogok(addonString(56).encode('utf-8') % ('[COLOR=Yellow]' + name + '[/COLOR]'),addonString(73).encode('utf-8') % (username),addonString(61).encode('utf-8') % (password),addonString(71).encode('utf-8') % (skinsetting2))
				dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + localize(79485) + space2 + localize(305), localize(79604) + space2, addonString(87).encode('utf-8'),addonString(88).encode('utf-8'))
				set_accountdate(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, "0")
				'''---------------------------'''
			
			elif name == "TRAKT TV":
				'''------------------------------
				---TRAKT-TV----------------------
				------------------------------'''
				dialogok(addonString(56).encode('utf-8') % ('[COLOR=Yellow]' + name + '[/COLOR]'),addonString(73).encode('utf-8') % (username),addonString(61).encode('utf-8') % (password),"")
				dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + localize(79485) + space2 + localize(305), localize(79604) + space2, localize(78914), localize(78915))
				'''---------------------------'''	

	else:
		'''------------------------------
		---DIALOG-YES-NO-HAVE-ACCOUNT?---
		------------------------------'''
		returned = dialogyesno(addonString(57).encode('utf-8') % (name), localize(79481))
		if returned == 'ok':
			'''------------------------------
			---DIALOG-KEYBOARD-USER----------
			------------------------------'''
			if admin or not 'htpt' in username: input = username
			else: input = ""
			returned = dialogkeyboard(input,'$LOCALIZE[20142]',0,'3',usernameS,addon)
			if returned == 'skip': pass
			else:
				'''------------------------------
				---DIALOG-KEYBOARD-PASS----------
				------------------------------'''
				returned = dialogkeyboard(password,'$LOCALIZE[15052]',1,'3',passwordS,addon)
				if returned == 'skip': pass
				else:
					'''------------------------------
					---DIALOG-NUMERIC--PERIOD--------
					------------------------------'''
					if skinsetting2 != "N/A": returned, value = dialognumeric(0, localize(12393),"30",'2',skinsetting2S,"")
					else: returned = 'ok'
					if returned == 'skip': pass
					else:
						'''------------------------------
						---DIALOG-OK-ACCOUNT-ON-------
						------------------------------'''
						setSkinSetting("1", skinsettingS, "true")
						xbmc.sleep(500)
						skinsetting = xbmc.getInfoLabel('Skin.HasSetting('+ skinsettingS +')')
						skinsetting2 = xbmc.getInfoLabel('Skin.String('+ skinsetting2S +')')
						skinsetting3 = xbmc.getInfoLabel('Skin.String('+ skinsetting3S +')')
						username = getsetting_addon(usernameS)
						password = getsetting_addon(passwordS)
						'''---------------------------'''
						
						if name == "REALDEBRID":
							'''------------------------------
							---REALDEBRID--------------------
							------------------------------'''
							dialogok(addonString(56).encode('utf-8') % ('[COLOR=Yellow]' + name + '[/COLOR]'),addonString(73).encode('utf-8') % (username),addonString(61).encode('utf-8') % (password),addonString(71).encode('utf-8') % (skinsetting2))
							dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + localize(79485) + space2 + localize(305), localize(79604) + space2, localize(79603), localize(79602))
							set_accountdate(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, "0")
							'''---------------------------'''
							
						elif name == "SDAROT TV":
							'''------------------------------
							---SDAROT-TV---------------------
							------------------------------'''
							dialogok(addonString(56).encode('utf-8') % ('[COLOR=Yellow]' + name + '[/COLOR]'),addonString(73).encode('utf-8') % (username),addonString(61).encode('utf-8') % (password),addonString(71).encode('utf-8') % (skinsetting2))
							dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + localize(79485) + space2 + localize(305), localize(79604) + space2, addonString(87).encode('utf-8'),addonString(88).encode('utf-8'))
							set_accountdate(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, "0")
							'''---------------------------'''
						
						elif name == "TRAKT TV":
							'''------------------------------
							---TRAKT-TV----------------------
							------------------------------'''
							dialogok(addonString(56).encode('utf-8') % ('[COLOR=Yellow]' + name + '[/COLOR]'),addonString(73).encode('utf-8') % (username),addonString(61).encode('utf-8') % (password),"")
							dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + localize(79485) + space2 + localize(305), localize(79604) + space2, localize(85), localize(78915))
							'''---------------------------'''
							
			if returned == 'skip':
				'''------------------------------
				---DIALOG-NOTIFICATION-TURNOFF---
				------------------------------'''
				notification('$LOCALIZE[257]',addonString(69).encode('utf-8'),"",2000)
				setSkinSetting("1", skinsettingS, "false")
				setSkinSetting("0", skinsetting2S, "")
				setSkinSetting("0", skinsetting3S, "")
				setsetting_custom1(addon,usernameS,"")
				setsetting_custom1(addon,passwordS,"")
				'''---------------------------'''
		else:
			'''------------------------------
			---DIALOG-OK-SIGNUP-INFO---------
			------------------------------'''
			if name == "REALDEBRID": dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + 'https://real-debrid.com/', localize(79480), '[CR]' + localize(79477),'[CR]' + localize(79476))
			elif name == "SDAROT TV": dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + 'http://sdarot.wf/', localize(79480), '[CR]' + localize(78912),'[CR]' + localize(78913))
			elif name == "TRAKT TV": dialogok('[COLOR=Yellow]' + name + '[/COLOR]' + '[CR]' + 'http://trakt.tv/', localize(79480), '[CR]' + addonString(89).encode('utf-8'),"")
			'''---------------------------'''
	
	if name == "REALDEBRID":
		'''------------------------------
		---urlresolver-------------------
		------------------------------'''
		if systemhasaddon_urlresolver: addonsettings2('script.module.urlresolver','RealDebridResolver_login',"true",'RealDebridResolver_enabled',"true",'RealDebridResolver_priority',"101",'RealDebridResolver_username',username,'RealDebridResolver_password',password)
		'''---------------------------'''
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "account_button LV_" + printpoint + space2 + name + space + addon + space3
	'''---------------------------'''

def set_accountdate(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, custom):
	'''------------------------------
	---CALCULATE-END-DATES-----------
	------------------------------'''
	printpoint = "" ; custom1172W = xbmc.getCondVisibility('Window.IsVisible(Custom1172.xml)')
	try: numberN = int(skinsetting2)
	except: numberN = 0
	
	
	if skinsetting3 != "":
		#notification("test",skinsetting3,"",2000)
		dateleft = stringtodate(skinsetting3,'%Y-%m-%d')
		dateleft2 = str(dateleft)
		dateleft2S = str(dateleft2)
		datenow2 = stringtodate(datenowS,'%Y-%m-%d')
		number2 = dateleft - datenow2
		number2S = str(number2)
		if "day," in number2S: number2S = number2S.replace(" day, 0:00:00","",1)
		elif "days," in number2S: number2S = number2S.replace(" days, 0:00:00","",1)
		else: number2S = "0"
		if admin: notification("number2S:" + number2S,"","",2000)
		number2N = int(number2S)
	else:
		number2S = "0"
		number2N = int(number2S)
	if number2N < 0: 
		number2S = "0"
		number2N = int(number2S)
		'''---------------------------'''
	
	if custom == "0":
		'''------------------------------
		---MANUAL-SET--------------------
		------------------------------'''
		import datetime as dt
		dateafter2 = datenow + dt.timedelta(days=numberN)
		dateafter2S = str(dateafter2)
		#setsetting(skinsetting3, dateafter2S)
		setSkinSetting("0", skinsetting3S, dateafter2S)
		'''---------------------------'''
		
		'''---------------------------'''
	if custom == "1":
		'''------------------------------
		---AUTO-SET----------------------
		------------------------------'''
		
		'''---------------------------'''
		if skinsetting2 != "" or skinsetting3 != "": setSkinSetting("0", skinsetting2S, number2S)
		'''---------------------------'''
		
		if skinsetting and (username == "" or password == ""):
			'''------------------------------
			---NO-USERNAME-OR-PASSWORD-------
			------------------------------'''
			if number2N > 0 and number2N < 7: dialogok(localize(75204) + '[CR]' + '[COLOR=Yellow]' + name + '[/COLOR]',"",addonString(73).encode('utf-8') % (username) + '[CR]' + addonString(71).encode('utf-8') % (number2S),"")
			'''---------------------------'''
			
			'''------------------------------
			---DIALOG-YESNO-REMAKE-----------
			------------------------------'''
			returned = dialogyesno(localize(75202) + space + name,localize(75206) + '[CR]' + localize(75205) + '[CR]' + addonString(73).encode('utf-8') % (username))
			if returned == "ok": printpoint = printpoint + "3"
			else: printpoint = printpoint + "4"
			'''---------------------------'''
			
		elif skinsetting and number2N < 7:
			'''------------------------------
			---PERIOD-ABOUT-TO-END-----------
			------------------------------'''
			if number2N > 0 and number2N < 7: dialogok(localize(75200) + '[CR]' + '[COLOR=Yellow]' + name + '[/COLOR]',"",addonString(73).encode('utf-8') % (username) + '[CR]' + addonString(71).encode('utf-8') % (number2S),"")
			elif skinsetting and number2N == 0: dialogok(localize(75201) + '[CR]' + '[COLOR=Yellow]' + name + '[/COLOR]',"",addonString(73).encode('utf-8') % (username) + '[CR]' + addonString(71).encode('utf-8') % (number2S),"")
			'''---------------------------'''
			
			'''------------------------------
			---DIALOG-YESNO-REMAKE-----------
			------------------------------'''
			returned = dialogyesno(localize(75202) + space + name,localize(75203) + '[CR]' + addonString(73).encode('utf-8') % (username))
			if returned == "ok": printpoint = printpoint + "5"
			else: printpoint = printpoint + "6"
			'''---------------------------'''
	
		elif not skinsetting and number2N > 0:
			'''------------------------------
			---SETTING-SHOULD-BE-ON?---------
			------------------------------'''
			pass
			
		if "3" in printpoint or "5" in printpoint:
			'''------------------------------
			---USER-SET-SETTINGS-------------
			------------------------------'''
			custom1172W = xbmc.getCondVisibility('Window.IsVisible(Custom1172.xml)')
			if not custom1172W: xbmc.executebuiltin('ActivateWindow(1172)')
			'''---------------------------'''
			count = 0
			while count < 40 and not custom1172W and not xbmc.abortRequested:
				'''------------------------------
				---custom1172W-PENDING---------
				------------------------------'''
				xbmc.sleep(40)
				count += 1
				custom1172W = xbmc.getCondVisibility('Window.IsVisible(Custom1172.xml)')
				'''---------------------------'''
				
			if custom1172W:
				'''------------------------------
				---custom1172W-TRUE------------
				------------------------------'''
				xbmc.executebuiltin('Control.SetFocus(100,1)')
				xbmc.executebuiltin('Control.SetFocus(50,1)')
				xbmc.executebuiltin('Action(PageUp)')
				xbmc.sleep(40)
				'''---------------------------'''
				count = 0
				systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
				while count < 10 and not name in systemcurrentcontrol and not xbmc.abortRequested:
					'''------------------------------
					---systemcurrentcontrol=name-----
					------------------------------'''
					count += 1
					systemcurrentcontrol = findin_systemcurrentcontrol("1",name,40,'Action(Down)',"")
					if admin: print printfirst + space + "set_accountdate" + space2 + "systemcurrentcontrol=name" + space2 + systemcurrentcontrol + " != " + name + space3
					'''---------------------------'''
			
			if name == 'REALDEBRID': account_button(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, custom)
			elif name == 'SDAROT TV': account_button(name, addon, usernameS, passwordS, username, password, skinsettingS, skinsetting2S, skinsetting3S, skinsetting, skinsetting2, skinsetting3, custom)
			'''---------------------------'''
		
		elif custom1172W and (number2N == 0 or "4" in printpoint):
			'''------------------------------
			---SETTING-OFF-------------------
			------------------------------'''
			setSkinSetting("1", skinsettingS, "false")
			setSkinSetting("0", skinsetting2S, "")
			setSkinSetting("0", skinsetting3S, "")
			notification(addonString(57).encode('utf-8') % (name) + space + str79046.encode('utf-8'),"","",4000)
			'''---------------------------'''
			
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin and custom == "1": print printfirst + "set_accountdate" + space + "name" + space2 + name + space + skinsetting + space + skinsetting2 + space + "number2S" + space2 + number2S + space + custom + space3
	'''---------------------------'''

def setAutoSettings(custom, addonid2=""):
	
	countrystr = xbmc.getInfoLabel('Skin.String(Country)')
	
	if custom == "0":
		'''------------------------------
		---INSTALL-ADDONS----------------
		------------------------------'''
		if scripthtptinstall_Skin_FirstBoot == "true": notification("Installing additional addons", "Please Wait!", "", 10000)
		addon = 'plugin.video.pulsar'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')') and 1 + 1 == 3:
			'''------------------------------
			---plugin.video.pulsar-----------
			------------------------------'''
			#addonsettings2(addon,'max_upload_rate',"",'max_download_rate',"",'',"",'',"",'',"")
			'''---------------------------'''
			
			#addon = 'script.pulsar.btjunkie-mc'
			#if not xbmc.getCondVisibility('System.HasAddon('+ addon +')'): installaddon(admin, addon, "")
			addon = 'script.pulsar.KickAssTorrents'
			if not xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
				installaddon(admin, addon, "")
				if xbmc.getCondVisibility('System.HasAddon('+ addon +')'): notification("Provider Installed!", addon, "", 2000)
			#addon = 'script.pulsar.extratorrent-mc'
			#if not xbmc.getCondVisibility('System.HasAddon('+ addon +')'): installaddon(admin, addon, "")
			#addon = 'script.pulsar.omg'
			#if not xbmc.getCondVisibility('System.HasAddon('+ addon +')'): installaddon(admin, addon, "")
			#addon = 'script.pulsar.yourbittorrent-mc'
			#if not xbmc.getCondVisibility('System.HasAddon('+ addon +')'): installaddon(admin, addon, "")
			#addon = 'script.pulsar.torrenthound-mc'
			#if not xbmc.getCondVisibility('System.HasAddon('+ addon +')'): installaddon(admin, addon, "")
			addon = 'script.pulsar.yify-mc'
			if not xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
				installaddon(admin, addon, "")
				if xbmc.getCondVisibility('System.HasAddon('+ addon +')'): notification("Provider Installed!", addon, "", 2000)
			addon = 'script.pulsar.thepiratebay-mc'
			if not xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
				installaddon(admin, addon, "")
				if xbmc.getCondVisibility('System.HasAddon('+ addon +')'): notification("Provider Installed!", addon, "", 2000)
			#addon = 'script.pulsar.publichd-mc'
			#if not xbmc.getCondVisibility('System.HasAddon('+ addon +')'): installaddon(admin, addon, "")
			#addon = 'script.pulsar.magnetdl-mc'
			#if not xbmc.getCondVisibility('System.HasAddon('+ addon +')'): installaddon(admin, addon, "")
			#addon = 'script.pulsar.oldpiratebay-mc'
			#if not xbmc.getCondVisibility('System.HasAddon('+ addon +')'): installaddon(admin, addon, "")
			#addon = 'script.pulsar.kickass-mc'
			#if not xbmc.getCondVisibility('System.HasAddon('+ addon +')'): installaddon(admin, addon, "")
			#addon = 'script.pulsar.h33t-mc'
			#if not xbmc.getCondVisibility('System.HasAddon('+ addon +')'): installaddon(admin, addon, "")
			#addon = 'script.pulsar.eztv-mc'
			#if not xbmc.getCondVisibility('System.HasAddon('+ addon +')'): installaddon(admin, addon, "")
			#addon = 'script.pulsar.torrentz-mc'
			#if not xbmc.getCondVisibility('System.HasAddon('+ addon +')'): installaddon(admin, addon, "")
			'''---------------------------'''
		else: pass #installaddon(admin, addon, "")
		
		addon = 'script.htpt.debug'
		if not xbmc.getCondVisibility('System.HasAddon('+ addon +')'): installaddon2(admin, addon, "")
		
		addon = 'script.htpt.refresh'
		if not xbmc.getCondVisibility('System.HasAddon('+ addon +')'): installaddon2(admin, addon, "")
		
		addon = 'script.htpt.remote'
		if not xbmc.getCondVisibility('System.HasAddon('+ addon +')'): installaddon2(admin, addon, "")
			
		addon = 'script.htpt.smartbuttons'
		if not xbmc.getCondVisibility('System.HasAddon('+ addon +')'): installaddon2(admin, addon, "")
		
		addon = 'service.htpt.fix'
		if not xbmc.getCondVisibility('System.HasAddon('+ addon +')'): installaddon2(admin, addon, "")
		
		addon = 'script.htpt.widgets'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			addonsettings2(addon,'plot_enable',"true",'recommended_enable',"true",'randomitems_enable',"true",'randomitems_method',"1",'randomitems_seasonfolders',"false")
			addonsettings2(addon,'randomitems_time',"60",'randomitems_unplayed',"true",'recentitems_enable',"true",'recentitems_homeupdate',"false",'recentitems_unplayed',"true")
			setsetting_custom1(addon, 'recommended_enable', "true")
			'''---------------------------'''
		else: installaddon2(admin, addon, "")
				
		
		addon = 'metadata.universal'
		if not xbmc.getCondVisibility('System.HasAddon('+ addon +')') or not os.path.exists(addons_path + addon):
			printpoint3 = installaddonP(admin, addon)
			if "9" in printpoint3:
				pass
				#notification("Trying to Install addon.", "You may want to reboot if failed!", "", 10000)
				#installaddon(admin, addon, "") ; xbmc.sleep(1000)
				'''---------------------------'''
		
		addon = 'service.subtitles.subtitle'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			'''------------------------------
			---service.subtitles.subtitle----
			------------------------------'''
			if not id40str: addonsettings2(addon,'SUBemail',idstr + "@gmail.com",'SUBpassword',idpstr,'',"",'',"",'',"")
			path = os.path.join(addondata_path, addon, 'cookiejar.txt')
			removefiles(path)
			path = os.path.join(addondata_path, addon, 'temp', '')
			removefiles(path)
			'''---------------------------'''
		elif countrystr == "Israel": installaddon(admin, addon, "")
		
		addon = 'script.favourites'
		if not xbmc.getCondVisibility('System.HasAddon('+ addon +')'): installaddon(admin, addon, "")
		
		addon = 'service.subtitles.opensubtitles'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			'''------------------------------
			-service.subtitles.opensubtitles-
			------------------------------'''
			if not id40str: addonsettings2(addon,'OSuser',idstr + "@gmail.com",'OSpass',idpstr,'',"",'',"",'',"")
			path = os.path.join(addondata_path, addon, 'temp', '')
			removefiles(path)
			'''---------------------------'''
		else: installaddon(admin, addon, "")
		
		if not systemplatformwindows:
			addon = 'repository.unofficial.addon.pro'
			if not xbmc.getCondVisibility('System.HasAddon('+ addon +')') and xbmc.getCondVisibility('System.HasAddon(service.openelec.settings)'): installaddon(admin, addon, "")
		
		addon = 'service.subtitles.subscenter'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			'''------------------------------
			---service.subtitles.subscenter--
			------------------------------'''
			addonsettings2(addon,'',"",'',"",'',"",'',"",'',"")
			path = os.path.join(addondata_path, addon, 'temp', '')
			removefiles(path)
			'''---------------------------'''
		elif countrystr == "Israel": installaddon(admin, addon, "")
		
		addon = 'service.subtitles.torec'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			'''------------------------------
			---service.subtitles.torec-------
			------------------------------'''
			addonsettings2(addon,'',"",'',"",'',"",'',"",'',"")
			path = os.path.join(addondata_path, addon, 'temp', '')
			removefiles(path)
			'''---------------------------'''
		elif countrystr == "Israel": installaddon(admin, addon, "")
		
		
		
		if 1 + 1 == 3:
			addon = 'script.tv.show.next.aired'
			if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
				'''------------------------------
				---script.tv.show.next.aired-----
				------------------------------'''
				xbmc.executebuiltin('RunScript(script.tv.show.next.aired,silent=True)')
				xbmc.executebuiltin('RunScript(script.tv.show.next.aired,backend=True)')
				addonsettings2(addon,'',"",'',"",'',"",'',"",'',"")
				'''---------------------------'''
			else:
				pass
				'''---------------------------'''
		
			
		'''------------------------------
		---script.htpt.homebuttons-------
		------------------------------'''	
		dialogtextviewerW = xbmc.getCondVisibility('Window.IsVisible(DialogTextViewer.xml)')
		while dialogtextviewerW and not xbmc.abortRequested:
			xbmc.sleep(1000)
			dialogtextviewerW = xbmc.getCondVisibility('Window.IsVisible(DialogTextViewer.xml)')
			'''---------------------------'''
		set_accountdate('REALDEBRID','plugin.video.genesis', 'realdedrid_user', 'realdedrid_password', realdedrid_user, realdedrid_password, 'Account1_Active', 'Account1_Period', 'Account1_EndDate', Account1_Active, Account1_Period, Account1_EndDate, "1")
		set_accountdate('SDAROT TV','plugin.video.sdarot.tv', 'username', 'user_password', sdarottv_user, sdarottv_password, 'Account2_Active', 'Account2_Period', 'Account2_EndDate', Account2_Active, Account2_Period, Account2_EndDate, "1")
		'''---------------------------'''
	
	elif custom == "1":
		pass
	
	elif custom == "3":
		'''------------------------------
		---SETTING-ADDONS-BY-COUNTRY-----
		------------------------------'''
		libraryisscanningvideo = xbmc.getCondVisibility('Library.IsScanningVideo')
		if libraryisscanningvideo: xbmc.executebuiltin('UpdateLibrary(video)')
		
		addon = 'metadata.universal'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			if addonid2 == "" or addonid2 == addon:
				if not id40str or countrystr == "Israel":
					addonsettings2(addon,'imdbsearchlanguage',"he-il",'tmdbplotlanguage',"he",'tmdbsetlanguage',"he",'tmdbtaglinelanguage',"he",'tmdbthumblanguage',"he")
					addonsettings2(addon,'tmdbtitlelanguage',"he",'',"",'imdbakatitles',"Israel",'tmdbgenreslanguage',"he",'',"")
					'''---------------------------'''
				elif countrystr == "": pass
				elif "Foreign" in countrystr:
					addonsettings2(addon,'imdbsearchlanguage',"None",'tmdbplotlanguage',"en",'tmdbsetlanguage',"en",'tmdbtaglinelanguage',"en",'tmdbthumblanguage',"en")
					addonsettings2(addon,'tmdbtitlelanguage',"None",'',"",'imdbakatitles',"Keep Original",'tmdbgenreslanguage',"en",'',"")
					'''---------------------------'''
				addonsettings2(addon,'TrailerQ',"1080p",'countrysource',"themoviedb.org",'creditssource',"themoviedb.org",'fanarttvfanart',"true",'imdbcertcountry',"USA")
				addonsettings2(addon,'imdbthumbs',"true",'plotsource',"themoviedb.org",'studiosource',"themoviedb.org",'taglinesource',"themoviedb.org",'titlesource',"themoviedb.org")
				addonsettings2(addon,'tmdbtags',"themoviedb.org",'trakttvtrailer',"true",'',"",'',"",'tmdbtrailerlanguage',"en")
				
		addon = 'metadata.tvdb.com'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')') and os.path.exists(addons_path + addon):
			if addonid2 == "" or addonid2 == addon:
				if not id40str or countrystr == "Israel": setsetting_custom1(addon, 'language',"he")
				elif countrystr == "": pass
				elif "Foreign" in countrystr: setsetting_custom1(addon, 'language',"en")
				addonsettings2(addon,'RatingS',"IMDb",'absolutenumber',"false",'dvdorder',"false",'fallback',"true",'fanart',"true")
				'''---------------------------'''
			
		addon = 'metadata.themoviedb.org'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')') and os.path.exists(addons_path + addon):
			if addonid2 == "" or addonid2 == addon:
				if not id40str or countrystr == "Israel": setsetting_custom1(addon, 'language',"he")
				elif countrystr == "": pass
				elif "Foreign" in countrystr: setsetting_custom1(addon, 'language',"en")
				addonsettings2(addon,'certprefix',"Rated",'fanart',"true",'keeporiginaltitle',"false",'tmdbcertcountry',"us",'trailer',"true")
				addonsettings2(addon,'RatingS',"IMDb",'TrailerQ',"1080p",'',"",'',"",'',"")
				'''---------------------------'''
		
		addon = 'plugin.video.youtube'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			if addonid2 == "" or addonid2 == addon:
				if not id40str or countrystr == "Israel": setsetting_custom1(addon, 'youtube.language',"iw-IL")
				elif countrystr == "": pass
				elif "Foreign" in countrystr: setsetting_custom1(addon, 'youtube.language',"en-US")
				addonsettings2(addon,'kodion.view.override',"true",'kodion.video.quality',"4",'kodion.view.default',"50",'kodion.view.episodes',"58",'kodion.search.size',"4")
				addonsettings2(addon,'kodion.setup_wizard',"false",'youtube.folder.disliked_videos.show',"false",'',"",'kodion.fanart.show',"false",'youtube.folder.sign.in.show',"true")
				addonsettings2(addon,'kodion.content.max_per_page',"7",'',"",'',"",'',"",'',"")
				path = os.path.join(addondata_path, addon, 'kodion', 'cache.sqlite')
				removefiles(path)
				'''---------------------------'''
		
		addon = 'plugin.video.sdarot.tv'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			if addonid2 == "" or addonid2 == addon:
				addonsettings('SDAROT TV', 'plugin.video.sdarot.tv', 'Account2_Active', 'Account2_Period', 'username','user_password', "", "", "", "")
				addonsettings2(addon,'DEBUG',"false",'cache',"24",'domain',"http://www.sdarot.wf",'',"",'',"")
				path = os.path.join(addondata_path, 'plugin.video.sdarot.tv', 'sdarot-cookiejar.txt')
				removefiles(path)
				'''---------------------------'''
			
		addon = 'plugin.video.vdubt'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			if addonid2 == "" or addonid2 == addon:
				addonsettings2(addon,'parental',"true",'sort',"false",'auto-view',"true",'default',"50",'movies',"50")
				'''---------------------------'''
		
		addon = 'plugin.video.israelive'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			if addonid2 == "" or addonid2 == addon:
				if sgbpvrmanagerenabled: addonsettings2(addon,'autoIPTV',"0",'useIPTV',"true",'',"",'',"",'',"")
				else: addonsettings2(addon,'autoIPTV',"1",'useIPTV',"false",'',"",'',"",'',"")
				addonsettings2(addon,'',"",'useEPG',"true",'StreramProtocol',"1",'forceRemoteDefaults',"true",'StreramsMethod',"0")
				addonsettings2(addon,'catColor',"chartreuse",'useEPG',"true",'chColor',"yellow",'prColor',"floralwhite",'timesColor',"none")
				#setsetting_custom1(addon,remoteSettingsUrl,"")
				'''---------------------------'''
				
	elif custom == "4":
		'''------------------------------
		---SETTING-GENERAL-ADDONS--------
		------------------------------'''
		
		addon = 'plugin.video.bestofyoutube_com'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			if addonid2 == "" or addonid2 == addon:
				addonsettings2(addon,'filter',"true",'filterRating',"90",'filterThreshold',"40",'forceViewMode',"true",'viewMode',"58")
				'''---------------------------'''
		
		addon = 'screensaver.picture.slideshow'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			if addonid2 == "" or addonid2 == addon:
				'''------------------------------
				--screensaver.picture.slideshow--
				------------------------------'''
				addonsettings2(addon,'cache',"false",'create',"",'date',"",'effect',"2",'iptc',"false")
				addonsettings2(addon,'label',"0",'level',"100",'music',"false",'scale',"false",'random',"true")
				addonsettings2(addon,'type',"0",'path',"",'',"",'',"",'time',"10")
				'''---------------------------'''
			
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "setAutoSettings" + space + "custom" + space2 + custom + space + "addonid2" + space2 + str(addonid2)
	'''---------------------------'''

	