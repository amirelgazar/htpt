#!/bin/bash
SETTINGS=$HOME/.xbmc/userdata/addon_data/plugin.video.genesis/settings.xml

###VAR SWITCHABLE###
AUTOPLAYHD='"autoplay_hd" value='

###VAR GENERAL###
T='"true"'
F='"false"'
ALL='"[^ ]*"'
NUM1='"1"'


###SED FIX###
sed -i "s/$AUTOPLAYHD$T/$AUTOPLAYHD$F/g" $SETTINGS ###AUTOPLAY HD SOURCES ON###