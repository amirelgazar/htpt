
#import os
###INFORMATION###
#xbmcLang = xbmc.getLanguage(0)
#if xbmcLang != "he":
	#xbmcLang = "en"
#xbmc.getCondVisibility( 'Window.IsVisible(movieinformation)' )	
#if xbmc.getInfoLabel('Skin.HasSetting(Admin)') != "":
# ???  if not xbmc.Player().isPlayingVideo():   |   xbmcgui.getCurrentWindowId() == 10000:

#################################################
import xbmc, os, subprocess, sys
#systemidle = xbmc.getGlobalIdleTime()
istv2 = xbmc.getInfoLabel('VideoPlayer.Season') != "" and xbmc.getInfoLabel('VideoPlayer.TVShowTitle') != ""
ismovie2 = xbmc.getCondVisibility('VideoPlayer.Content(movies)') or xbmc.getInfoLabel('VideoPlayer.Tagline') != "" or xbmc.getInfoLabel('VideoPlayer.Country') != "" or xbmc.getInfoLabel('VideoPlayer.Year') != ""
systemidle3 = xbmc.getCondVisibility('System.IdleTime(3)')
admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
refresh = xbmc.getCondVisibility('Control.HasFocus(9092)')
playerhasvideo = xbmc.getCondVisibility('Player.HasVideo')
systemplatformwindows = xbmc.getCondVisibility('system.platform.windows')
'''Windows'''
home = xbmc.getCondVisibility('Window.IsVisible(0)') or xbmc.getCondVisibility('Window.Previous(0)')
myvideonav = xbmc.getCondVisibility('Window.IsVisible(MyVideoNav.xml)')
systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
homestart = xbmc.getCondVisibility('Window.IsVisible(Home.xml)')
librarystart = xbmc.getCondVisibility('Window.IsVisible(MyVideoNav.xml)')
videofullscreen = xbmc.getCondVisibility('Window.IsVisible(VideoFullScreen.xml)')
dialogvideoinfo = xbmc.getCondVisibility('Window.IsVisible(DialogVideoInfo.xml)')
'''strings'''
dialogselectsources3 = xbmc.getInfoLabel('Skin.String(DialogSelectSources3)')
cancelstr = xbmc.getInfoLabel('$LOCALIZE[222]')
playerpaused = xbmc.getCondVisibility('Player.Paused')
dialogselectsources = 'false'
dialogselectsources2 = 'false'
refreshtv = 'false'
refreshmovie = 'false'
playbackended = 'false'
dialogsubtitles2 = xbmc.getInfoLabel('Skin.String(DialogSubtitles2)')
dialogsubtitlesna1 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA1)')
dialogsubtitlesna2 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA2)')
dialogsubtitlesna3 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA3)')
dialogsubtitlesna4 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA4)')
dialogsubtitlesna5 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA5)')
dialogsubtitlesna6 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA6)')
dialogsubtitlesna7 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA7)')
dialogsubtitlesna8 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA8)')
dialogsubtitlesna9 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA9)')
dialogsubtitlesna10 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA10)')
'''Others'''
videoplayerhassubtitles = xbmc.getCondVisibility('VideoPlayer.HasSubtitles')
customvar = xbmc.getInfoLabel('Skin.String(CustomVAR)')
smooth = "?"
autoplaysd = xbmc.getInfoLabel('Skin.HasSetting(AutoPlaySD)')
linkstart = "false"
autoplaycheck = "?"
'''class'''
def refreshrunnings(run):
	'''check if this script is already running'''
	refreshrunnings = xbmc.getInfoLabel('Skin.HasSetting(refreshrunnings)')
	if run == 'run':
		if not refreshrunnings and not refresh:
			xbmc.executebuiltin('Skin.ToggleSetting(refreshrunnings)')
			#xbmc.executebuiltin('StopScript(service.skin.widgets)')
			#if admin: xbmc.executebuiltin('Notification(Admin: refreshrunnings,-AUTO ON,1000)')
		if refreshrunnings:
			dialogselect = xbmc.getCondVisibility('Window.IsVisible(DialogSelect.xml)')
			playerhasvideo = xbmc.getCondVisibility('Player.HasVideo')
			count = 0
			while count < 5 and not xbmc.abortRequested:
				xbmc.sleep(500)
				count += 1
				countS = str(count)
				if not playerhasvideo and (dialogselect or refresh):
					count = 7
					xbmc.sleep(40)
				if admin and count != 7: xbmc.executebuiltin('Notification(Admin: refreshrunnings,-BLOCK ('+ countS +'),200)')
				if count == 5: sys.exit()
				if count == 7:
					if refresh or dialogselect: xbmc.executebuiltin('Notification(Admin: refreshrunnings,-ALLOWED,200)')
	if run == 'end':
		count = 0
		while not refreshrunnings and count < 3 and not refresh and not xbmc.abortRequested:
			xbmc.sleep(500)
			count += 1
			countS = str(count)
			if admin: xbmc.executebuiltin('Notification(Admin: refreshrunnings,-MANUAL OFF on 3 ('+ countS +'),500)')
			refreshrunnings = xbmc.getInfoLabel('Skin.HasSetting(refreshrunnings)')
		if refreshrunnings:
			#xbmc.executebuiltin('RunScript(service.skin.widgets)')
			xbmc.executebuiltin('Skin.ToggleSetting(refreshrunnings)')
			#if admin: xbmc.executebuiltin('Notification(Admin: refreshrunnings,-AUTO OFF ,1000)')
			sys.exit()
def clearskinstrings(run):
	'''variables'''
	autoplaypause = xbmc.getInfoLabel('Skin.HasSetting(AutoPlayPause)')
	autoplaysd = xbmc.getInfoLabel('Skin.HasSetting(AutoPlaySD)')
	connectionstatus2 = xbmc.getInfoLabel('Skin.String(ConnectionStatus2)')
	countwait = xbmc.getInfoLabel('Skin.String(CountWait)')
	dialogselectsources = xbmc.getInfoLabel('Skin.String(DialogSelectSources)')
	'''actions'''
	if dialogsubtitles2: xbmc.executebuiltin('Skin.SetString(DialogSubtitles2,)')
	if dialogsubtitlesna1: xbmc.executebuiltin('Skin.SetString(DialogSubtitlesNA1,)')
	if dialogsubtitlesna2: xbmc.executebuiltin('Skin.SetString(DialogSubtitlesNA2,)')
	if dialogsubtitlesna3: xbmc.executebuiltin('Skin.SetString(DialogSubtitlesNA3,)')
	if dialogsubtitlesna4: xbmc.executebuiltin('Skin.SetString(DialogSubtitlesNA4,)')
	if dialogsubtitlesna5: xbmc.executebuiltin('Skin.SetString(DialogSubtitlesNA5,)')
	if dialogsubtitlesna6: xbmc.executebuiltin('Skin.SetString(DialogSubtitlesNA6,)')
	if dialogsubtitlesna7: xbmc.executebuiltin('Skin.SetString(DialogSubtitlesNA7,)')
	if dialogsubtitlesna8: xbmc.executebuiltin('Skin.SetString(DialogSubtitlesNA8,)')
	if dialogsubtitlesna9: xbmc.executebuiltin('Skin.SetString(DialogSubtitlesNA9,)')
	if dialogsubtitlesna10: xbmc.executebuiltin('Skin.SetString(DialogSubtitlesNA10,)')
	'''resume autoplay check'''
	if autoplaypause:
		if admin: xbmc.executebuiltin('Admin,Notification($LOCALIZE[79089],1000)')
		xbmc.executebuiltin('Skin.ToggleSetting(AutoPlayPause)')
		if connectionstatus2 > 3:
			if admin: xbmc.executebuiltin('Notification(Admin genesis5.sh,resume autoplay,2000)')
			if not systemplatformwindows: os.system('sh /storage/.xbmc/addons/skin.HTPT/specials/scripts/genesis5.sh')
	if countwait: xbmc.executebuiltin('Skin.SetString(CountWait,)')
	'''prevent bug with autoplay'''
	if (connectionstatus2 == 5 or (connectionstatus2 == 4 and autoplaysd)) and not autoplaypause and not dialogselectsources:
		xbmc.executebuiltin('Skin.SetString(DialogSelectSources2,)')
		xbmc.executebuiltin('Skin.SetString(DialogSelectSources5,)')
	if not homestart: xbmc.executebuiltin('Skin.SetString(DialogSelectSources3,)')
	xbmc.executebuiltin('Skin.SetString(DialogSelectSources,)')
		
		
def bash(bashCommand,bashname):
	'''run BASH commands'''
	if not systemplatformwindows:
		process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
		output = process.communicate()[0]
		connected = xbmc.getInfoLabel('Skin.HasSetting(Connected)')
		if bashname == "Connected":
			connected = xbmc.getInfoLabel('Skin.HasSetting(Connected)')
			xbmc.executebuiltin('Skin.SetString(Test3,'+ output +')')
			if "1 packets transmitted" in output:
				if not connected: xbmc.executebuiltin('Skin.ToggleSetting(Connected)')
			else:
				if connected:
					xbmc.executebuiltin('Skin.ToggleSetting(Connected)')
					xbmc.executebuiltin('Notification($LOCALIZE[79111],$LOCALIZE[79112],5000)')
				
def connectionstatus(run):
	connectionstatus2 = xbmc.getInfoLabel('Skin.String(ConnectionStatus2)')
	connectionstatus2p = connectionstatus2
	connectionstatus2N = int(connectionstatus2)
	customvar = xbmc.getInfoLabel('Skin.String(CustomVAR)')
	'''ConnectionStatus reduce'''
	if run == 'reduce':
		if playerhasvideo:
			if connectionstatus2 == '0': xbmc.executebuiltin('Notification($LOCALIZE[79500],$LOCALIZE[79514],5000)') #RESET ROUTER
			if customvar != '5' and connectionstatus2 > '0': xbmc.executebuiltin('Notification($LOCALIZE[79504],$LOCALIZE[79511],7000,misc/logo/logo9.png)') #NITUV LO TAKIN
			if customvar == '5' and connectionstatus2 > '0': xbmc.executebuiltin('Notification($LOCALIZE[79502],$LOCALIZE[79501],10000,misc/logo/logo9.png)') #HOMES BESHART ZEH
		if connectionstatus2N > 0: connectionstatus2N += -1
		connectionstatus2 = str(connectionstatus2N)
		xbmc.executebuiltin('Skin.SetString(ConnectionStatus2,'+ connectionstatus2 +')')
		if admin: xbmc.executebuiltin('Notification(Admin,ConnectionStatus2: '+ connectionstatus2p +' -> '+ connectionstatus2 +',3000)')
	'''ConnectionStatus increase'''
	if run == 'increase':
		if connectionstatus2N < 5: connectionstatus2N += 1
		connectionstatus2 = str(connectionstatus2N)
		xbmc.executebuiltin('Skin.SetString(ConnectionStatus2,'+ connectionstatus2 +')')
		if admin: xbmc.executebuiltin('Notification(Admin,ConnectionStatus2: '+ connectionstatus2p +' -> '+ connectionstatus2 +',2000)')
	'''genesis.sh'''
	if (connectionstatus2p == '4' and connectionstatus2 == '5'):
		xbmc.executebuiltin('Notification($LOCALIZE[79492],$LOCALIZE[79499])')
		if not autoplaysd:
			'''Activate AutoPlay'''
			if admin: xbmc.executebuiltin('Notification(Admin genesis5.sh,Activate AutoPlay '+ connectionstatus2p +' -> '+ connectionstatus2 +',2000)')
			if not systemplatformwindows: os.system('sh /storage/.xbmc/addons/skin.HTPT/specials/scripts/genesis5.sh')
		else:
			'''Deactivate AutoPlay SD'''
			if admin: xbmc.executebuiltin('Notification(Admin genesis7.sh,Deactivate AutoPlay SD '+ connectionstatus2p +' -> '+ connectionstatus2 +',2000)')
			if not systemplatformwindows: os.system('sh /storage/.xbmc/addons/skin.HTPT/specials/scripts/genesis7.sh')
	if (connectionstatus2p == '5' and connectionstatus2 == '4'):
		if not autoplaysd:
			'''Disable AutoPlay'''
			if admin: xbmc.executebuiltin('Notification(Admin genesis4.sh,Disable AutoPlay '+ connectionstatus2p +' -> '+ connectionstatus2 +',2000)')
			if not systemplatformwindows: os.system('sh /storage/.xbmc/addons/skin.HTPT/specials/scripts/genesis4.sh')
		else:
			'''Activate AutoPlay SD'''
			if admin: xbmc.executebuiltin('Notification(Admin genesis8.sh,Activate AutoPlay SD '+ connectionstatus2p +' -> '+ connectionstatus2 +',2000)')
			if not systemplatformwindows: os.system('sh /storage/.xbmc/addons/skin.HTPT/specials/scripts/genesis8.sh')
	if (connectionstatus2p == '4' and connectionstatus2 == '3'):
		if autoplaysd:
			'''Disable AutoPlay'''
			if admin: xbmc.executebuiltin('Notification(Admin genesis4.sh,Disable AutoPlay '+ connectionstatus2p +' -> '+ connectionstatus2 +',2000)')
			if not systemplatformwindows: os.system('sh /storage/.xbmc/addons/skin.HTPT/specials/scripts/genesis4.sh')
def ddialogyesno(run):
	dialogyesno = xbmc.getCondVisibility('Window.IsVisible(DialogYesNo.xml)')
	if admin: count = 0
	if dialogyesno:
		while 1 and dialogyesno and not xbmc.abortRequested:
			xbmc.sleep(100)
			if admin: count += 1
			if admin and count == 1 and run == 'run1': xbmc.executebuiltin('Notification(Admin,while dialogyesno1,1000)')
			if admin and count == 1 and run == 'run2': xbmc.executebuiltin('Notification(Admin,while dialogyesno2,1000)')
			dialogyesno = xbmc.getCondVisibility('Window.IsVisible(DialogYesNo.xml)')
			xbmc.sleep(40)
		xbmc.sleep(1000)
def ddialogkeyboard(run):
	dialogkeyboard = xbmc.getCondVisibility('Window.IsVisible(DialogKeyboard.xml)')
	dialogprogress = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
	dialogselectsources2 = xbmc.getInfoLabel('Skin.String(DialogSelectSources2)')
	'''force wait for dialogkeyboard'''
	count = 0
	while count < 5 and dialogprogress and ('TVRELEASE' in dialogselectsources2 or '180UPLOAD' in dialogselectsources2 or 'HUGEFILES' in dialogselectsources2 or 'TVRELEASE' in dialogselectsources2) and not dialogkeyboard and not xbmc.abortRequested:
		xbmc.sleep(1000)
		count += 1
		if admin and count == 1: xbmc.executebuiltin('Notification(Admin,force wait for dialogkeyboard,1000)')
		dialogkeyboard = xbmc.getCondVisibility('Window.IsVisible(DialogKeyboard.xml)')
		dialogprogress = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
	if admin: count = 0
	if dialogkeyboard:
		while 1 and dialogkeyboard and not xbmc.abortRequested:
			xbmc.sleep(500)
			count += 1
			if admin and count == 1: xbmc.executebuiltin('Notification(Admin,while dialogkeyboard,1000)')
			dialogkeyboard = xbmc.getCondVisibility('Window.IsVisible(DialogKeyboard.xml)')
			xbmc.sleep(40)
		xbmc.sleep(1000)
		customvar = xbmc.getInfoLabel('Skin.String(CustomVAR)')
		if customvar != '1': xbmc.executebuiltin('Skin.SetString(CustomVAR,2)')

def videoosdauto(run):
	videoosd = xbmc.getCondVisibility('Window.IsVisible(VideoOSD.xml)')
	systemidle10 = xbmc.getCondVisibility('System.IdleTime(10)')
	if videoosd and systemidle10:
		subtitleosdbutton = xbmc.getCondVisibility('Control.HasFocus(703)')
		videoplayerhassubtitles = xbmc.getCondVisibility('VideoPlayer.HasSubtitles')
		if not subtitleosdbutton or not videoplayerhassubtitles:
			if admin: xbmc.executebuiltin('Notification(Admin,videoosdauto,1000)')
			xbmc.executebuiltin('Dialog.Close(VideoOSD.xml)')
		else:
			systemidle20 = xbmc.getCondVisibility('System.IdleTime(20)')
			if systemidle20: xbmc.executebuiltin('Dialog.Close(VideoOSD.xml)')
def exitbuggedsources(run):
	dialogselectsources = xbmc.getInfoLabel('Skin.String(DialogSelectSources)')
	if ('BILLIONUPLOADS' in dialogselectsources):
		if admin: xbmc.executebuiltin('Notification(Admin,exitbuggedsources ('+ dialogselectsources +'))')
		clearskinstrings('run')
		xbmc.sleep(1000)
		refreshrunnings('end')
class start:
	'''execute one time at start'''
	refreshrunnings('run')
	#dialogprogress = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
	#dialogselect = xbmc.getCondVisibility('Window.IsVisible(DialogSelect.xml)')
	#genesis = xbmc.getCondVisibility('SubString(Control.GetLabel(1),Genesis)')
	if not xbmc.Player().isPlayingVideo(): # or ((dialogprogress or dialogselect) and genesis)
		linkstart = 'true'
		customvar = xbmc.getInfoLabel('Skin.String(CustomVAR)')
		if customvar:
			if admin: xbmc.executebuiltin('Notification(Admin,CustomVAR Clear ('+ customvar +'),1000)')
			xbmc.executebuiltin('Skin.SetString(CustomVAR,)')
			xbmc.sleep(500)
			customvar = xbmc.getInfoLabel('Skin.String(CustomVAR)')
		dialogbusy = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
		dialogprogress = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
		dialogselect = xbmc.getCondVisibility('Window.IsVisible(DialogSelect.xml)')
		dialogyesno = xbmc.getCondVisibility('Window.IsVisible(DialogYesNo.xml)')
		'''while dialogprogress'''
		if admin: count = 0
		while 1 and dialogprogress and not dialogselect and not dialogyesno and not dialogbusy and customvar != '1' and not xbmc.abortRequested:
			xbmc.sleep(100)
			if admin and count != 11: count += 1
			if admin and count == 10: xbmc.executebuiltin('Notification(Admin,while dialogprogress,1000)') 
			customvar = xbmc.getInfoLabel('Skin.String(CustomVAR)')
			dialogselect = xbmc.getCondVisibility('Window.IsVisible(DialogSelect.xml)')
			dialogprogress = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
			dialogyesno = xbmc.getCondVisibility('Window.IsVisible(DialogYesNo.xml)')
		if dialogselect:
			'''while dialogselect'''
			dialogselect = xbmc.getCondVisibility('Window.IsVisible(DialogSelect.xml)')
			autoplaycheck = 'manual'
			if admin: count = 0
			while 1 and dialogselect and not xbmc.abortRequested:
				xbmc.sleep(100)
				if admin: count += 1
				if admin and count == 1: xbmc.executebuiltin('Notification(Admin,while dialogselect,1000)')
				dialogselect = xbmc.getCondVisibility('Window.IsVisible(DialogSelect.xml)')
				xbmc.sleep(40)
			'''quick cancel'''
			xbmc.sleep(70)
			dialogok = xbmc.getCondVisibility('Window.IsVisible(DialogOk.xml)')
			if dialogok:
				if admin: xbmc.executebuiltin('Notification(Admin,quick cancel)')
				xbmc.executebuiltin('Skin.SetString(CustomVar,1)')
			else: xbmc.sleep(500)
		else: xbmc.sleep(1000)
		'''prepare for stream'''
		dialogbusy = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
		dialogok = xbmc.getCondVisibility('Window.IsVisible(DialogOk.xml)')
		dialogprogress = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
		systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
		if (systemcurrentcontrol == cancelstr or dialogprogress or dialogbusy) and not dialogok and not xbmc.abortRequested:
			linkstart = 'true'
			count = 0
			while count < 20 and (systemcurrentcontrol == cancelstr or dialogprogress or dialogbusy) and not dialogok and not xbmc.abortRequested:
				if admin and count == 1: xbmc.executebuiltin('Notification(Admin,prepare for stream *('+ systemcurrentcontrol +',1000)')
				count += 1
				countS = str(count)
				xbmc.sleep(200)
				dialogbusy = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
				dialogok = xbmc.getCondVisibility('Window.IsVisible(DialogOk.xml)')
				dialogprogress = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
				playerhasvideo = xbmc.getCondVisibility('Player.HasVideo')
				systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
				customvar = xbmc.getInfoLabel('Skin.String(CustomVAR)')
				if admin: xbmc.executebuiltin('Skin.SetString(Test,'+ dialogselectsources +' ('+ countS +'))')
				'''while dialogyesno1'''
				ddialogyesno('run1')
				if count == 1 and customvar != '1':
					dialogselectsources = xbmc.getInfoLabel('Skin.String(DialogSelectSources)')
					dialogselectsources2 = xbmc.getInfoLabel('Skin.String(DialogSelectSources2)')
					#dialogselectsources2p = xbmc.getInfoLabel('Skin.String(DialogSelectSources2)')
					xbmc.sleep(50)
					xbmc.executebuiltin('Skin.SetString(DialogSelectSources2,'+ dialogselectsources +')')
					if admin: xbmc.executebuiltin('Notification(Admin DialogSelectSources:,'+ dialogselectsources +',1000)')
					#if admin: xbmc.executebuiltin('Skin.SetString(Test2,'+ dialogselectsources +' ('+ countS +'))')
					#if admin: xbmc.executebuiltin('Skin.SetString(Test2,prepare for stream ('+ countS +') '+ dialogselectsources +')')
					''''''
					dialogselectsources3 = xbmc.getInfoLabel('Skin.String(DialogSelectSources3)')
					dialogselectsources5 = xbmc.getInfoLabel('Skin.String(DialogSelectSources5)')
					#dialogselectsources5p = dialogselectsources5
					xbmc.executebuiltin('Skin.SetString(DialogSelectSources5, '+ dialogselectsources3 +')')
					xbmc.executebuiltin('Skin.SetString(CustomVAR,4)')
					'''exit bugged sources'''
					#exitbuggedsources('run')
					''''''
				if (count == 15 or playerhasvideo) and customvar != '1':
					if 'VK' in dialogselectsources or 'ORORO' in dialogselectsources:
						if admin: xbmc.executebuiltin('Notification(Admin,customvar = 4,1000)')
						xbmc.executebuiltin('Skin.SetString(CustomVAR,5)')
					else:
						xbmc.executebuiltin('Skin.SetString(CustomVAR,...)')
			'''wait for dialogprogress to reappear'''
			if (count < 20 and customvar != '1') and not dialogok and not xbmc.abortRequested:
				xbmc.executebuiltin('Notification(Admin,wait for dialogprogress to reappear,1000)')
				if not dialogprogress: xbmc.sleep(3000)
				if not dialogok: xbmc.sleep(1000)
			'''while dialogkeyboard'''
			ddialogkeyboard('run')
		'''waiting for video'''
		count = 0.1
		dialogbusy = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
		dialogprogress = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
		if (systemcurrentcontrol == cancelstr or dialogprogress or dialogbusy) and not dialogok and not playerhasvideo and customvar != '1':
			linkstart = 'true'
			while 1 and (systemcurrentcontrol == cancelstr or dialogprogress or dialogbusy) and not dialogok and not playerhasvideo and customvar != '1' and not xbmc.abortRequested:
				if admin and count == 0.1: xbmc.executebuiltin('Notification(Admin,waiting for video,1000)')
				xbmc.sleep(100)
				count += 0.1
				countS = str(count)
				dialogbusy = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
				dialogprogress = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
				playerhasvideo = xbmc.getCondVisibility('Player.HasVideo')
				dialogok = xbmc.getCondVisibility('Window.IsVisible(DialogOk.xml)')
				customvar = xbmc.getInfoLabel('Skin.String(CustomVAR)')
				if (customvar != '1' and customvar != '3'):
					xbmc.executebuiltin('Skin.SetString(CountWait,'+ countS +')')
					'''slow connection'''
					if countS == '15.0' and autoplaycheck == 'manual':
						if systemcurrentcontrol == cancelstr:
							if admin: xbmc.executebuiltin('Notification(Admin,slow connection,1000)')
							xbmc.executebuiltin('Action(Select)')
							xbmc.sleep(500)
							xbmc.executebuiltin('Skin.SetString(CustomVAR,3)')
						else:
							if admin: xbmc.executebuiltin('Notification(Admin,slow connection - NOT cancel!,1000)')
				'''while dialogyesno2'''
				ddialogyesno('run2')
			if not playerhasvideo: xbmc.sleep(500)
			#if (customvar != '1' and not dialogok): xbmc.sleep(1000)
			'''playerhasvideo'''
			playerhasvideo = xbmc.getCondVisibility('Player.HasVideo')
			if playerhasvideo:
				playerpaused = xbmc.getCondVisibility('Player.Paused')
				if admin and playerpaused: xbmc.executebuiltin('Notification(Admin,playerhasvideo+playerpaused,1000)')
				if admin: xbmc.executebuiltin('Notification(Admin,playerhasvideo,1000)')
				xbmc.sleep(200)
				if playerpaused: xbmc.executebuiltin('Action(Play)')
				linkstart = 'true'
		'''quick manual cancel'''
		if customvar == '1' and not dialogok and not playerhasvideo: # or xbmc.abortRequested
			if admin: xbmc.executebuiltin('Notification(Admin,quick manual cancel,1000)')
			dialogbusy = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
			dialogok = xbmc.getCondVisibility('Window.IsVisible(DialogOk.xml)')
			dialogprogress = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
			playerhasvideo = xbmc.getCondVisibility('Player.HasVideo')
			if dialogprogress:
				xbmc.executebuiltin('Dialog.Close(progressdialog,true)')
				xbmc.executebuiltin('StopScript(plugin.video.genesis)')
				xbmc.sleep(1000)
				if not dialogok and not playerhasvideo:
					clearskinstrings('run')
					refreshrunnings('end')
			#if dialogbusy: xbmc.executebuiltin('Dialog.Close(busydialog,true)')
		'''*reduce and/or exit'''
		#dialogok = xbmc.getCondVisibility('Window.IsVisible(DialogOk.xml)')
		if dialogok and not playerhasvideo:
			customvar = xbmc.getInfoLabel('Skin.String(CustomVAR)')
			if admin: xbmc.executebuiltin('Skin.SetString(Test,dialogok)')
			if customvar != '1':
				if customvar == '5': connectionstatus('reduce')
				elif autoplaycheck != 'manual': connectionstatus('reduce')
			if admin: xbmc.executebuiltin('Notification(Admin,*reduce and/or exit,1000)')
			clearskinstrings('run')
			refreshrunnings('end')
	'''class istvmovie2'''
	if xbmc.Player().isPlayingVideo():
		'''istv2 or ismovie2'''
		#if admin: xbmc.executebuiltin('Notification(Admin,istv2 or ismovie2,1000)')
		count = 0
		while 1 and count < 4 and playerhasvideo and not xbmc.abortRequested:
			xbmc.sleep(500)
			count += 1
			countS = str(count)
			playerpaused = xbmc.getCondVisibility('Player.Paused')
			if playerpaused and count == 1: xbmc.executebuiltin('Action(Play)')
			if not playerpaused and count > 1: xbmc.executebuiltin('Action(Pause)')
			istv2 = xbmc.getInfoLabel('VideoPlayer.Season') != "" and xbmc.getInfoLabel('VideoPlayer.TVShowTitle') != ""
			ismovie2 = xbmc.getCondVisibility('VideoPlayer.Content(movies)') or xbmc.getInfoLabel('VideoPlayer.Tagline') != "" or xbmc.getInfoLabel('VideoPlayer.Country') != "" or xbmc.getInfoLabel('VideoPlayer.Year') != ""
			playerhasvideo = xbmc.getCondVisibility('Player.HasVideo')
			
			if (istv2 or ismovie2):
				if count > 1:
					if admin and istv2: xbmc.executebuiltin('Notification(Admin,istv2 ('+ countS +'),1000)')
					if admin and ismovie2: xbmc.executebuiltin('Notification(Admin,ismovie2 ('+ countS +'),1000)')
					count = 5
					#if dialogvideoinfo: xbmc.executebuiltin('Action(FullScreen)')
			'''stoping script'''
			if count == 3 and not istv2 and not ismovie2 or not playerhasvideo:
				if admin: xbmc.executebuiltin('Notification(Admin,stoping script,2000)')
				clearskinstrings('run')
				refreshrunnings('end')
	'''class autoplayplus:'''
	'''Tweak and Test the connection'''
	connectionstatus2 = xbmc.getInfoLabel('Skin.String(ConnectionStatus2)')
	if admin and linkstart != 'true' and connectionstatus2 != '5' and not autoplaysd: xbmc.executebuiltin('Notification(Admin,linkstart != true,2000)')
	elif admin and linkstart != 'true' and connectionstatus2 != '5' and connectionstatus2 != '4' and autoplaysd: xbmc.executebuiltin('Notification(Admin,linkstart != true,2000)')
	if xbmc.Player().isPlayingVideo() and (linkstart == 'true' or connectionstatus2 == '5' or (connectionstatus2 == '4' and autoplaysd)):
		xbmc.executebuiltin('Notification($LOCALIZE[79054],$LOCALIZE[79062],2000)')
		playerhasvideo = xbmc.getCondVisibility('Player.HasVideo')
		count = 0
		while count < 5 and playerhasvideo and not xbmc.abortRequested:
			xbmc.sleep(1000)
			count += 1
			countS = str(count)
			playercache = xbmc.getInfoLabel('Player.CacheLevel')
			playerpaused = xbmc.getCondVisibility('Player.Paused')
			playerhasvideo = xbmc.getCondVisibility('Player.HasVideo')
			if not playerpaused: xbmc.executebuiltin('Action(Pause)')
			if admin: xbmc.executebuiltin('Notification(Admin,'+ playercache +' ('+ countS +'),1000)')
			if playerhasvideo:			
				if count > 2 and playercache == '100':
					smooth = 'true'
					count = 7
				if playercache != '100' and count == 5:
					xbmc.executebuiltin('Notification($LOCALIZE[79054] $LOCALIZE[20177],$LOCALIZE[79505],2000)')
					smooth = 'false?'
					if playerpaused: xbmc.executebuiltin('Action(Play)')
			else:
				clearskinstrings('run')
				refreshrunnings('end')
			xbmc.sleep(40)
		'''connectionstatus up/down'''
		if smooth == 'false?':
			xbmc.executebuiltin('Notification($LOCALIZE[79505],$LOCALIZE[20186],10000)')
			count = 0
			while count < 5 and playerhasvideo and not xbmc.abortRequested:
				xbmc.sleep(1000)
				count += 1
				countS = str(count)
				playercache = xbmc.getInfoLabel('Player.CacheLevel')
				playerpaused = xbmc.getCondVisibility('Player.Paused')
				playerhasvideo = xbmc.getCondVisibility('Player.HasVideo')
				if count == 1: xbmc.executebuiltin('Action(FastForward)')
				if count == 3:
					xbmc.executebuiltin('Action(Rewind)')
					if not playerpaused: xbmc.executebuiltin('Action(Pause)')
				if count == 5:
					xbmc.executebuiltin('Action(SmallStepBack)')
					if admin: xbmc.executebuiltin('Notification(admin,'+ playercache +' (not 100),2000)')
					if playercache != '100':
						smooth = 'false'
						
					if playerpaused and playercache == '100': xbmc.executebuiltin('Action(Play)')
		if smooth == 'true':
			playerpaused = xbmc.getCondVisibility('Player.Paused')
			if playerpaused: xbmc.executebuiltin('Action(Play)')
			if playercache == '100': xbmc.executebuiltin('Notification($LOCALIZE[79054] $LOCALIZE[20177],$LOCALIZE[79068],2000)')
			xbmc.sleep(2000)
			videoplayerhassubtitles = xbmc.getCondVisibility('VideoPlayer.HasSubtitles')
			xbmc.sleep(100)
			if not videoplayerhassubtitles: xbmc.executebuiltin('ActivateWindow(subtitlesearch)')
			connectionstatus('increase')
		if smooth == 'false': connectionstatus('reduce')
	'''class refreshW:'''
	if xbmc.Player().isPlayingVideo():
		refreshtv = 'false'
		refreshmovie = 'false'
		istv2 = xbmc.getInfoLabel('VideoPlayer.Season') != "" and xbmc.getInfoLabel('VideoPlayer.TVShowTitle') != ""
		ismovie2 = xbmc.getCondVisibility('VideoPlayer.Content(movies)') or xbmc.getInfoLabel('VideoPlayer.Tagline') != "" or xbmc.getInfoLabel('VideoPlayer.Country') != "" or xbmc.getInfoLabel('VideoPlayer.Year') != ""
		if admin: xbmc.executebuiltin('Notification(Admin refreshW,-execute many times,1000)')
		'''execute many times'''
		count = 0
		while 1 and xbmc.Player().isPlayingVideo() and not xbmc.abortRequested:
			xbmc.sleep(1000)
			count += 1
			countS = str(count)
			if systemplatformwindows: xbmc.sleep(40)
			if not systemplatformwindows: bash('ping -W 1 -w 1 -4 -q www.google.co.il',"Connected")
			'''video osd auto close'''
			videoosdauto('run')
			'''rerun script'''
			dialogprogress = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
			dialogselect = xbmc.getCondVisibility('Window.IsVisible(DialogSelect.xml)')
			genesis = xbmc.getCondVisibility('SubString(Control.GetLabel(1),Genesis)')
			playerhasvideo = xbmc.getCondVisibility('Player.HasVideo')
			playerpaused = xbmc.getCondVisibility('Player.Paused')
			if (dialogprogress or dialogselect) and genesis:
				if admin: xbmc.executebuiltin('Notification(Admin,rerun script,1000)')
				xbmc.executebuiltin('Action(Stop)')
				clearskinstrings('run')
				refreshrunnings('end')
				
			if playerhasvideo and not playerpaused:
				admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
				if count == 120 or (admin and count > 7):
					if admin: xbmc.executebuiltin('Notification(Admin,count = '+ countS +',1000)')
					count = 0
					playertime = xbmc.getInfoLabel("Player.Time(hh)") + xbmc.getInfoLabel("Player.Time(mm)")
					playertime2 = xbmc.getInfoLabel("Player.TimeRemaining(hh)") + xbmc.getInfoLabel("Player.TimeRemaining(mm)")
					#playertime3 = xbmc.getInfoLabel("Player.FinishTime(hh)") + xbmc.getInfoLabel("Player.FinishTime(mm)")
					#playerduration = xbmc.getInfoLabel("Player.Duration(hh)") + xbmc.getInfoLabel("Player.Duration(mm)")
					if istv2:
						if refreshtv != 'true' and playertime > playertime2:
							if admin: xbmc.executebuiltin('Notification(Admin,RefreshTV ON: '+ playertime +' > '+ playertime2 +',1000)')
							refreshtv = 'true'
						if refreshtv == 'true' and playertime < playertime2:
							if admin: xbmc.executebuiltin('Notification(Admin,RefreshTV OFF: '+ playertime +' < '+ playertime2 +',1000)')
							refreshtv = 'false' 
					if ismovie2:
						if refreshmovie != 'true' and playertime > playertime2:
							if admin: xbmc.executebuiltin('Notification(Admin,RefreshMovie ON: '+ playertime +' > '+ playertime2 +',1000)')
							refreshmovie = 'true'
						if refreshmovie == 'true' and playertime < playertime2:
							if admin: xbmc.executebuiltin('Notification(Admin,RefreshMovie OFF: '+ playertime +' < '+ playertime2 +',1000)')
							refreshmovie = 'false'
				'''counter dialogselect bug!!!'''
				if (refreshtv == 'true' or refreshmovie == 'true'):
					playertime3 = xbmc.getInfoLabel("Player.TimeRemaining(hh)") + xbmc.getInfoLabel("Player.TimeRemaining(mm)") + xbmc.getInfoLabel("Player.TimeRemaining(ss)")
					playertime3N = int(playertime3)
					playlistlength = xbmc.getInfoLabel('Playlist.Length(video)')
					playlistlengthN = int(playlistlength)
					playlistposition = xbmc.getInfoLabel('Playlist.Position(video)')
					playlistpositionN = int(playlistposition)
					if admin: playertime3S = str(playertime3N)
					if admin and playertime3N > 10 and playertime3N < 30 and (homestart or linkstart == 'false'): xbmc.executebuiltin('Notification(Admin,counter-bug: '+ playertime3S +'(10) '+ playlistposition +'/'+ playlistlength +' ('+ countS +'),1000)')
					'''reset script if playlist detected'''
					if playertime3N < 15 and playlistpositionN < playlistlengthN and playlistlengthN > 1:
						refreshrunnings2 = xbmc.getInfoLabel('Skin.HasSetting(refreshrunnings)')
						if refreshrunnings2:
							if admin: xbmc.executebuiltin('Notification(Admin,reset script if playlist detected,2000)')
							clearskinstrings('run')
							refreshrunnings('end')
					'''end the script without bugs'''
					if playertime3N < 10 and not playlistpositionN < playlistlengthN and (homestart or linkstart == 'false'):
						if admin: xbmc.executebuiltin('Notification(Admin,counter dialogselect bug!!! ('+ countS +'),2000)')
						playbackended = 'true'
						xbmc.sleep(1000)
						xbmc.executebuiltin('Action(Pause)')
						xbmc.sleep(500)
						xbmc.executebuiltin('Action(Stop)')
						xbmc.sleep(500)
						#xbmc.executebuiltin('Dialog.Close(all,true)')
				
	'''is not playing video'''
	if not xbmc.Player().isPlayingVideo():
		dialogok = xbmc.getCondVisibility('Window.IsVisible(DialogOk.xml)')
		if admin and not dialogok: xbmc.executebuiltin('Notification(Admin,is not playing video,1000)')
		if admin and dialogok: xbmc.executebuiltin('Notification(Admin,Wait for dialogok to unload,200)')
		'''Wait for dialogok to unload'''
		while 1 and dialogok and not playerhasvideo and not xbmc.abortRequested:
			xbmc.sleep(200)
			dialogok = xbmc.getCondVisibility('Window.IsVisible(DialogOk.xml)')
			playerhasvideo = xbmc.getCondVisibility('Player.HasVideo')
		clearskinstrings('run')
		'''def refreshlibrary(run):'''
		if refreshtv == 'true' or refreshmovie == 'true' or refresh:
			'''refresh'''
			if (refreshtv == 'true' or refresh) and not myvideonav:
				xbmc.executebuiltin('ActivateWindow(VideoLibrary,TVShowTitles)')
				xbmc.executebuiltin('Notification($LOCALIZE[79067] $LOCALIZE[73120],$LOCALIZE[20186],4000)')
			elif refreshmovie == 'true' and not myvideonav:
				xbmc.executebuiltin('ActivateWindow(Videos,MovieTitles)')
				xbmc.executebuiltin('Notification($LOCALIZE[79067] $LOCALIZE[71030],$LOCALIZE[20186],4000)')		
			'''genesis script by days'''
			if not systemplatformwindows:
				if admin: xbmc.executebuiltin('Notification(Admin,genesis1.sh,1000)')
				os.system('sh /storage/.xbmc/addons/skin.HTPT/specials/scripts/genesis1.sh')
				xbmc.sleep(1000)
				if admin: xbmc.executebuiltin('Notification(Admin,genesis2.sh,1000)')
				os.system('sh /storage/.xbmc/addons/skin.HTPT/specials/scripts/genesis2.sh')
			'''time for marking as watch'''
			if refreshmovie == 'false':
				xbmc.sleep(1000)
				xbmc.executebuiltin('Container.Refresh')
				xbmc.sleep(1000)
			if admin: xbmc.executebuiltin('Skin.SetString(Test2,RunScript(service.skin.widgets))')
			xbmc.executebuiltin('RunScript(service.skin.widgets)')
			xbmc.sleep(500)
			if refreshtv == 'true' or refresh:
				xbmc.sleep(1200)
				if homestart:
					'''focusing tvshows widget'''
					xbmc.executebuiltin('ReplaceWindow(0)')
					xbmc.sleep(200)
					xbmc.executebuiltin('Control.SetFocus(2)')
					xbmc.executebuiltin('Action(Up)')
					xbmc.executebuiltin('Action(Up)')
					'''check if refresh has occur'''
					xbmc.sleep(500)
					home = xbmc.getCondVisibility('Window.IsVisible(0)')
					dialogselectsources3 = xbmc.getInfoLabel('Skin.String(DialogSelectSources3)')
					dialogselectsources5 = xbmc.getInfoLabel('Skin.String(DialogSelectSources5)')
					xbmc.sleep(40)
					if dialogselectsources3 == dialogselectsources5 and refreshtv == 'true' and playbackended == 'true' and home and homestart:
						if admin: xbmc.executebuiltin('Notification(Admin,check if refresh has occur,1000)')
						#xbmc.executebuiltin('Action(Up)')
						#systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
						xbmc.executebuiltin('Control.SetFocus(9092)')
						xbmc.executebuiltin('Action(Select)')
					else:
						if admin: xbmc.executebuiltin('Skin.SetString(Test,'+ dialogselectsources3 +' / '+ dialogselectsources5 +' | playbackended: '+ playbackended +')')
			elif refreshmovie == 'true':
				if admin: xbmc.executebuiltin('Notification(Admin,RefreshMovie,2000)')
				xbmc.sleep(1000)
				if homestart:
					'''focusing movie widget'''
					xbmc.executebuiltin('ReplaceWindow(0)')
					xbmc.sleep(200)
					xbmc.executebuiltin('Control.SetFocus(1)')
					xbmc.executebuiltin('Action(Up)')
					xbmc.executebuiltin('Action(Up)')
	refreshrunnings('end')