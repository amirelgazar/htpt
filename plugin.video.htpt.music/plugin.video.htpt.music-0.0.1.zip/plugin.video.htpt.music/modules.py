# -*- coding: utf-8 -*-
import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os

from variables import *
from shared_modules import *
if "plugin." in addonID: from shared_modules3 import *
'''---------------------------'''

def CATEGORIES():
	'''------------------------------
	---MAIN--------------------------
	------------------------------'''
	addDir(addonString(41).encode('utf-8'),'',41,"http://www.havalevi.com/wp-content/uploads/2013/02/%D7%96%D7%9E%D7%A8%D7%99%D7%9D-%D7%99%D7%A9%D7%A8%D7%90%D7%9C%D7%99%D7%9D.png",addonString(141).encode('utf-8'),'1',"") #Israeli Music
	
	
	
	
	setsetting_custom1(addonID,'Current_View',50)

def CATEGORIES1(admin):
	'''------------------------------
	---Israeli-Music-----------------
	------------------------------'''
	'''דודו אהרון'''
	addDir(addonString(51).encode('utf-8'),'DuduAharonOfficiaI',9,'https://yt3.ggpht.com/-0orZ08za-yw/AAAAAAAAAAI/AAAAAAAAAAA/5axG6k56St4/s100-c-k-no/photo.jpg',addonString(151).encode('utf-8'),'1',"")
	
	'''עומר אדם'''
	addDir(addonString(52).encode('utf-8'),'OmerAdamOfficial',9,'https://i.ytimg.com/i/o4y7A6EF2tZ1Q2Oxx64HNQ/mq1.jpg?v=520b5fde',addonString(152).encode('utf-8'),'1',"")
	
	'''פאר טסי'''
	addDir(addonString(53).encode('utf-8'),'peertasimizrahi',9,'https://yt3.ggpht.com/-XdArdL_W374/AAAAAAAAAAI/AAAAAAAAAAA/phGLZNk8iwU/s100-c-k-no/photo.jpg',addonString(153).encode('utf-8'),'1',"")
	
	'''הפרויקט של רביבו'''
	addDir(addonString(54).encode('utf-8'),'TheRevivoProject',9,'https://yt3.ggpht.com/-BaUmBFct4Y4/AAAAAAAAAAI/AAAAAAAAAAA/LRtzMW2AeBg/s100-c-k-no/photo.jpg',addonString(154).encode('utf-8'),'1',"")
	
	'''משה פרץ'''
	addDir(addonString(55).encode('utf-8'),'MoshePerezOfficial',9,'https://i.ytimg.com/i/0ebT4a-IyuY61X8py3nzsg/mq1.jpg?v=52124db3',addonString(155).encode('utf-8'),'1',"")
	
	'''ליאור נרקיס'''
	addDir(addonString(56).encode('utf-8'),'LiorNarkisOfficial',9,'https://yt3.ggpht.com/-rty-RitLrSM/AAAAAAAAAAI/AAAAAAAAAAA/yjXa3UqBrlk/s100-c-k-no/photo.jpg',addonString(156).encode('utf-8'),'1',"")
	
	'''מושיק עפיה'''
	addDir(addonString(57).encode('utf-8'),'MoshikAfiaOfficial',9,'https://yt3.ggpht.com/-4IayEL0C0Rs/AAAAAAAAAAI/AAAAAAAAAAA/kEV66on9DOM/s100-c-k-no/photo.jpg',addonString(157).encode('utf-8'),'1',"")
	
	'''שלומי שבת'''
	addDir(addonString(58).encode('utf-8'),'shlomishabatofficiaI',9,'https://i.ytimg.com/i/GaHPMv8YIv_0HfRDQQ44cA/mq1.jpg?v=af5444',addonString(158).encode('utf-8'),'1',"")
	
	'''אייל גולן'''
	addDir(addonString(59).encode('utf-8'),'EyalGolanOfficial',9,'https://yt3.ggpht.com/-PV5wpA_XiiY/AAAAAAAAAAI/AAAAAAAAAAA/XCOsoSqKASA/s100-c-k-no/photo.jpg',addonString(159).encode('utf-8'),'1',"")
	
	'''שלמה ארצי'''
	addDir(addonString(60).encode('utf-8'),'ShlomoArtziOfficial',9,'https://i.ytimg.com/i/QHzG2gtNfXp4yo6_I46eCw/mq1.jpg?v=50f54e25',addonString(160).encode('utf-8'),'1',"")
	
	'''עידן רייכל'''
	addDir(addonString(61).encode('utf-8'),'idanraichelofficial',9,'https://yt3.ggpht.com/-vsBWN1RBQuk/AAAAAAAAAAI/AAAAAAAAAAA/SWZEbbG5oUY/s100-c-k-no/photo.jpg',addonString(161).encode('utf-8'),'1',"")
	
	'''שרית חדד'''
	addDir(addonString(62).encode('utf-8'),'SaritHadadOfficial',9,'https://i.ytimg.com/i/0m-czKbg-tL7J61RDdU1rg/mq1.jpg?v=54ac3da1',addonString(162).encode('utf-8'),'1',"")
	
	'''משינה'''
	addDir(addonString(63).encode('utf-8'),'Mashinaofficial',9,'https://i.ytimg.com/i/HLMP6lold_s1cFfiLg4t6g/mq1.jpg?v=51b9bb69',addonString(163).encode('utf-8'),'1',"")
	
	'''מאיה בוסקילה'''
	addDir(addonString(64).encode('utf-8'),'mayabos',9,'https://yt3.ggpht.com/-5PEvWjlVLN4/AAAAAAAAAAI/AAAAAAAAAAA/tNQGMUjQfxE/s100-c-k-no/photo.jpg',addonString(164).encode('utf-8'),'1',"")
	
	'''עברי לידר'''
	addDir(addonString(65).encode('utf-8'),'IvriLiderOfficial',9,'http://media.shironet.mako.co.il/media/performers/heb/0/764/profile/764_t275.jpg?rnd=58',addonString(165).encode('utf-8'),'1',"")
	
	'''נתן גושן'''
	addDir(addonString(66).encode('utf-8'),'NathanGoshenOfficial',9,'https://i.ytimg.com/i/Bh-trCMk-XPOP7WgAdkpPg/mq1.jpg?v=54d87328',addonString(166).encode('utf-8'),'1',"")
	
	'''קובי פרץ'''
	addDir(addonString(67).encode('utf-8'),'KobiPeretzOfficial',9,'https://i.ytimg.com/i/GYqX6zfso91VDawbH_Nukw/mq1.jpg?v=4f5f486f',addonString(167).encode('utf-8'),'1',"")
	
	'''חיים משה'''
	addDir(addonString(68).encode('utf-8'),'haimmosheoffical',9,'https://yt3.ggpht.com/-XFcsxvNUq7I/AAAAAAAAAAI/AAAAAAAAAAA/_8oeTUlYMAg/s100-c-k-no/photo.jpg',addonString(168).encode('utf-8'),'1',"")
	
	'''דודו אהרון'''
	addDir(addonString(69).encode('utf-8'),'RamiKleinshteinMusic',9,'https://yt3.ggpht.com/-w0s7cBy2UZM/AAAAAAAAAAI/AAAAAAAAAAA/imwGV27TLck/s100-c-k-no/photo.jpg',addonString(169).encode('utf-8'),'1',"")
	
	setsetting_custom1(addonID,'Current_View',58)