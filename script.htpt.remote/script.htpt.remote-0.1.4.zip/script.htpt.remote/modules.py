import xbmc, xbmcgui, xbmcaddon
import subprocess, os, sys
from variables import *
from shared_modules import *

def setIR_Support(IR_Support):
	name = 'setIR_Support' ; output = "" ; admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	if not systemplatformwindows:
		output = bash('ir-keytable','ir-keytable')
		if "No such file or directory" in output or output == "":
			setsetting('IR_Support','false')
			IR_Support = 'false'
		else:
			setsetting('IR_Support','true')
			IR_Support = 'true'
	
	if admin: print	printfirst + name + space + "output" + space2 + str(output)
	
	return IR_Support