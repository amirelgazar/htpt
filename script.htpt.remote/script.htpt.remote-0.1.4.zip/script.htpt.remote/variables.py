'''------------------------------
---shared_variables--------------
------------------------------'''
import xbmcaddon, sys, os
servicehtptPath          = xbmcaddon.Addon('service.htpt').getAddonInfo("path")
sharedlibDir = os.path.join(servicehtptPath, 'resources', 'lib', 'shared')
sys.path.insert(0, sharedlibDir)
from shared_variables import *
'''---------------------------'''
#libDir = os.path.join(addonPath, 'resources', 'lib')
#sys.path.insert(0, libDir)

getsetting         = xbmcaddon.Addon().getSetting
setsetting         = xbmcaddon.Addon().setSetting
addonName          = xbmcaddon.Addon().getAddonInfo("name")
addonString        = xbmcaddon.Addon().getLocalizedString
addonID          = xbmcaddon.Addon().getAddonInfo("id")
addonPath          = xbmcaddon.Addon().getAddonInfo("path")
addonVersion          = xbmcaddon.Addon().getAddonInfo("version")

printfirst = addonName + ": !@# "
'''triggers'''
admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
remotebutton = xbmc.getCondVisibility('Container(50).HasFocus(81)') or xbmc.getInfoLabel('ListItem.Label') == addonName or (xbmc.getCondVisibility('Window.IsVisible(Settings.xml)') and xbmc.getInfoLabel('System.CurrentControl') == addonString(1).encode('utf-8'))

# (xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(102)'))
#systemidle40 = xbmc.getCondVisibility('System.IdleTime(40)')

printpoint = ""


'''ADDON SETTINGS'''
remote_type = getsetting('remote_type')
remote_type_temp = getsetting('remote_type_temp')
General_ScriptON = getsetting('General_ScriptON')
IR_Support = getsetting('IR_Support')
test_time = getsetting('test_time')
lastdate = getsetting('lastdate')
irtype = xbmc.getInfoLabel('Skin.String(IRtype)')

#if admin: xbmc.executebuiltin('Notification(admin,'+ curtrigger +',2000)')