#!/usr/bin/python
import xbmc, sys, xbmcaddon
import xbmcgui, os

getsetting             = xbmcaddon.Addon().getSetting
setsetting             = xbmcaddon.Addon().setSetting
addonName              = xbmcaddon.Addon().getAddonInfo("name")
addonString            = xbmcaddon.Addon().getLocalizedString
addonPath              = xbmcaddon.Addon().getAddonInfo("path")

printfirst = addonName + ": !@# "
space = " "
space2 = ": "
systemplatformwindows = xbmc.getCondVisibility('system.platform.windows')

def bash(bashCommand,bashname):
	'''run BASH commands'''
	import subprocess
	if not systemplatformwindows:
		process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
		output = process.communicate()[0]

		print printfirst + bashname + ": " + output	
		return output

def dialogselect(heading, list, autoclose):
	'''------------------------------
	---DIALOG-SELECT-----------------
	------------------------------'''
	dialog = xbmcgui.Dialog()
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	
	returned = dialog.select(heading,list,autoclose)
	returned = str(returned)
	
	print printfirst + heading + "( " + returned + " )"
	return returned
	'''---------------------------'''
	
def dialogkeyboard(input, heading, option, custom, addonsetting, addonsetting2):
	'''------------------------------
	---DIALOG-KEYBOARD---------------
	------------------------------'''
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	dialog = xbmcgui.Dialog()
	keyboard = xbmc.Keyboard(input,heading,option)
	keyboard.doModal()
	returned = 'skip'
	if (keyboard.isConfirmed()):
		input2 = keyboard.getText()
		if custom == '1' and input2 != "": returned = 'ok'
		if custom == '2' and input2 == input: returned = 'ok'
		if custom == '3':
			if input2 != input and input2 != "" and option == 0: xbmc.executebuiltin('Notification('+ heading +': '+ input2 +',,4000)')
			if input2 != "": returned = 'ok'
			
		if option == 0: print printfirst + heading + space2 + input2 + " ( " + returned + " )"
		elif option != 0: print printfirst + heading + space2 + "*******" + " ( " + returned + " )"
	if returned == 'ok':
		returned == input2
		if addonsetting2 == "0": setsetting(addonsetting, input2)
		elif addonsetting2 == 'genesis':
			setsetting_genesis          = xbmcaddon.Addon('plugin.video.genesis').setSetting
			setsetting_genesis(addonsetting, input2)
	return returned
	'''---------------------------'''
	
def dialognumeric(type,heading,input,custom,addonsetting):
	'''type: 0 = #, 1 = DD/MM/YYYY, 2 = HH:MM, 3 = #.#.#.#, message2 = heading, message1 = content'''
	input = int(input)
	returned = 'skip'
	try:
		if int(input) > 001000000 and int(input) < 9999999999 and input != "": input = str(input)
	except TypeError:
		input = 0
		print printfirst + "dialognumeric " + "except TypeError (1)"
	input = str(input)
	input2 = xbmcgui.Dialog().numeric(type, heading, input)
	try:
		if input2 != "": input2 = int(input2)
	except TypeError:
		xbmc.executebuiltin('Notification($LOCALIZE[257],$LOCALIZE[31406],2000)')
		sys.exit()
	if custom == '0':
		try:
			if input2 > 001000000 and input2 < 9999999999: returned = 'ok'
			elif input2 < 001000000 or input2 > 9999999999: returned = 'skip0'
		except TypeError:
			returned = 'skip'
	if custom == '1':
		if input2 != "": returned = 'ok'
	#if type == '2' and input == message1: returned = 'ok'
	
	input = str(input)
	input2 = str(input2)
	print printfirst + heading + space2 + input2 + "( " + returned + " )"
	if returned == 'ok':
		returned == input
		setsetting(addonsetting, input2)
	return returned
	
def dialogyesno(heading,line1):
	'''------------------------------
	---DIALOG-YESNO------------------
	------------------------------'''
	dialog = xbmcgui.Dialog()
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	if '$LOCALIZE' in line1 or '$ADDON' in line1: line1 = xbmc.getInfoLabel(line1)
	returned = 'skip'
	if dialog.yesno(heading,line1): returned = 'ok'
	
	print printfirst + heading + "( " + returned + " )"
	return returned
	'''---------------------------'''
	
def dialogok(heading,line1,line2,line3):
	'''------------------------------
	---DIALOG-OK---------------------
	------------------------------'''
	dialog = xbmcgui.Dialog()
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	if '$LOCALIZE' in line1 or '$ADDON' in line1: line1 = xbmc.getInfoLabel(line1)
	if '$LOCALIZE' in line2 or '$ADDON' in line2: line2 = xbmc.getInfoLabel(line2)
	if '$LOCALIZE' in line3 or '$ADDON' in line3: line3 = xbmc.getInfoLabel(line3)
	heading = str(heading)
	line1 = str(line1)
	line2 = str(line2)
	line3 = str(line3)
	dialog.ok(heading,line1,line2,line3)
	
	print printfirst + heading + space2 + line1 + space2 + line2 + space2 + line3
	'''---------------------------'''

def dialogselect(heading, list, autoclose):
	'''------------------------------
	---DIALOG-SELECT-----------------
	------------------------------'''
	dialog = xbmcgui.Dialog()
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	
	returned = dialog.select(heading,list,autoclose)
	returned = str(returned)
	
	print printfirst + heading + "( " + returned + " )"
	return returned
	'''---------------------------'''
	
def calculate(type,value,addonsetting):
	value = int(value)
	if type == '1':
		value += 1
	value = str(value)
	setsetting(addonsetting, value)

def changeset(type,value,addonsetting):
	import datetime
	timenow = datetime.date.today()
	timenow = str(timenow)
	print printfirst + value + ", " + timenow
	if type == '1':
		if value != timenow: setsetting(addonsetting, timenow)

		
def irkeytable(filename):
	filepath = addonPath + "/resources/remotes/" + filename
	print filepath
	if filename == 'samsung' or filename == 'lg' or filename == 'philips' or filename == 'toshiba': type = "nec,rc-6"
	
	#elif filename == 'philips':
	#os.system("date")
	#f = os.popen('date')
	#now = f.read()
	#a = os.system("ir-keytable -p type -w filepath -D 700 -P 200")
	#subprocess.call(["ir-keytable", "-p", "nec,rc-6", "-w ", filepath, "-D 700 -P 200"])
	os.system('sh /storage/.kodi/addons/script.htpt.remote/remote.sh')
	bash('ir-keytable -p nec,rc-6 -w /storage/.kodi/addons/script.htpt.remote/resources/remotes/samsung -D 700 -P 200',"ir-keytable")
	#subprocess.call(["ir-keytable -p nec,rc-6 -w /storage/.kodi/addons/script.htpt.remote/resources/remotes/samsung -D 700 -P 200"])
	xbmc.executebuiltin('Notification(news,1,2000)')
	#print a
	#ir-keytable -p $REMOTE_TYPE -w $REMOTES_PATH/$REMOTE_FILE -D 700 -P 200

	'''triggers'''
admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
remotebutton = xbmc.getCondVisibility('Container(50).HasFocus(81)') or xbmc.getInfoLabel('ListItem.Label') == addonName or (xbmc.getCondVisibility('Window.IsVisible(Settings.xml)') and xbmc.getInfoLabel('System.CurrentControl') == addonString(1).encode('utf-8'))

# (xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(102)'))
#systemidle40 = xbmc.getCondVisibility('System.IdleTime(40)')

home = xbmc.getCondVisibility('Window.IsVisible(0)')
validation = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION)')
''''''



'''ADDON SETTINGS'''
remote_type = getsetting('remote_type')
remote_type_temp = getsetting('remote_type_temp')
test_time = getsetting('test_time')
lastdate = getsetting('lastdate')
irtype = xbmc.getInfoLabel('Skin.String(IRtype)')
xbmc.executebuiltin('Skin.SetString(IRtype,'+ remote_type +')')
#if admin: xbmc.executebuiltin('Notification(admin,'+ curtrigger +',2000)')

''''''
class main:
	if remote_type == "":
		dialogok(addonString(1).encode('utf-8'),addonString(25).encode('utf-8'),'[CR]' + addonString(20).encode('utf-8'),"")
		if irtype: xbmc.executebuiltin('Skin.SetString(IRtype,)')
	if remotebutton or remote_type == "":
		print printfirst + "irtypebutton"
		list0 = 'samsung'
		list1 = 'lg'
		list2 = 'philips'
		list3 = 'toshiba'
		list4 = 'pilot'
		input = remote_type
		returned = dialogselect(addonString(11).encode('utf-8'),[list0, list1, list2, list3, list4],0)
		returned = int(returned)
		if returned == -1:
			xbmc.executebuiltin('Notification($LOCALIZE[31406],$LOCALIZE[79223],2000)') #HAPEULA BUTLA, LO BUTZHU SINUHIM
			if not remotebutton: dialogok(addonString(1).encode('utf-8'),'$LOCALIZE[31406]','[CR]' + addonString(23).encode('utf-8'),"")
		else:
			'''new setting'''
			if returned == 0: input2 = list0
			elif returned == 1: input2 = list1
			elif returned == 2: input2 = list2
			elif returned == 3: input2 = list3
			elif returned == 4: input2 = list4
			
			setsetting('remote_type_temp',input2)
			xbmc.executebuiltin('Skin.SetString(IRtype,'+ input2 +')')
			if not systemplatformwindows: os.system('sh /storage/.kodi/addons/script.htpt.remote/remote.sh')
			dialogok(addonString(20).encode('utf-8'),addonString(21).encode('utf-8') + space2 + input2,addonString(22).encode('utf-8') + space + "(" + test_time + ")","")
			count = 0
			while count < 10 and not xbmc.abortRequested:
				xbmc.sleep(1000)
				count += 1
				if count == 10:
					returned = dialogyesno(addonString(30).encode('utf-8'),addonString(21).encode('utf-8') + space2 + input2)
					if returned == 'ok':
						xbmc.executebuiltin('Notification('+ addonString(21).encode('utf-8') +' '+ space2 +' '+ input2 +' ,,5000)')
						setsetting('remote_type',input2)
						changeset('1',lastdate,'lastdate')
					else:
						xbmc.executebuiltin('Notification($LOCALIZE[31406],$LOCALIZE[79223],2000)')
						xbmc.executebuiltin('Skin.SetString(IRtype,'+ input +')')
						if not remotebutton: dialogok(addonString(1).encode('utf-8'),'$LOCALIZE[31406]','[CR]' + addonString(23).encode('utf-8'),"")
		
	else:
		''''''
		import datetime
		timenow = datetime.date.today()
		timenow = str(timenow)
		if not validation and remote_type != "":
			if not systemplatformwindows: os.system('sh /storage/.kodi/addons/script.htpt.remote/remote.sh')
			print printfirst + "remote.sh; remote type: " + remote_type
			if home and timenow == lastdate:
				dialogok(addonString(1).encode('utf-8'),addonString(24).encode('utf-8'),'[CR]' + addonString(23).encode('utf-8'),"")
	setsetting('remote_type_temp',"")
	
	sys.exit()