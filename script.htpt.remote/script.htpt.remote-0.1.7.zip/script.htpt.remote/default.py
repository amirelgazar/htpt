#!/usr/bin/python
import xbmc, sys, xbmcaddon
import xbmcgui, os

from variables import *
from modules import *

IR_Support = setIR_Support(IR_Support)

if IR_Support != "true":
	dialogok('$LOCALIZE[79501]', str74543.encode('utf-8') % ("IR"), str74542.encode('utf-8'),'')
	sys.exit()
setGeneral_ScriptON("0", General_ScriptON, "")

xbmc.executebuiltin('Skin.SetString(IRtype,'+ remote_type +')')

class main:
	if remote_type == "":
		printpoint = printpoint + "1"
		dialogok(localize(79221), localize(74824),'[CR]' + localize(74829),"")
		if irtype: xbmc.executebuiltin('Skin.SetString(IRtype,)')
	if remotebutton or remote_type == "":
		printpoint = printpoint + "2"
		list = ['None', 'samsung', 'lg', 'philips', 'toshiba', 'pilot', ''] #sharp
		input = remote_type
		returned, value = dialogselect(localize(79610), list,0)

		if returned == -1:
			printpoint = printpoint + "9"
			if not remotebutton: dialogok(localize(79221), localize(31406), "", localize(74828))
		elif returned == 0:
			printpoint = printpoint + "8"
			dialogok(localize(79221) + space + localize(1223), localize(78288), "", localize(78984))
			setsetting('remote_type', 'None')
			setSkinSetting("0", 'IRtype', 'None')
			setsetting('lastdate', datenowS)
			bash('ir-keytable -c', 'Old keytable cleared')
		else:
			'''------------------------------
			---NEW-REMOTE-TEST---------------
			------------------------------'''
			printpoint = printpoint + "3"
			input2 = value
			
			setsetting('remote_type_temp',input2)
			setSkinSetting("0", 'IRtype', input2)
			'''---------------------------'''
			if not systemplatformwindows: os.system('sh /storage/.kodi/addons/script.htpt.remote/remote.sh')
			dialogok(localize(74829), localize(74827) + space2 + input2, localize(74826) + space + "(" + test_time + ")","")
			'''---------------------------'''
			try: test_time == "10" or test_time == "20" or test_time == "30"
			except Exception, TypeError: test_time = "10"
			
			count = 0
			while count < int(test_time) and not xbmc.abortRequested:
				count += 1
				notification(localize(74826) + space2 + test_time + space4 + str(count),"","",1000)
				xbmc.sleep(1000)
				if count == 10:
					printpoint = printpoint + "5"
					returned = dialogyesno(localize(74823), localize(74827) + space2 + input2)
					if returned == 'ok':
						'''------------------------------
						---NEW-REMOTE-CHOOSEN------------
						------------------------------'''
						printpoint = printpoint + "6"
						notification(localize(74827) + space2 + input2,"","",4000)
						setsetting('remote_type',input2)
						setsetting('lastdate',datenowS)
						'''---------------------------'''
						
					else:
						'''------------------------------
						---KEEP-PREVIOUS-REMOTE----------
						------------------------------'''
						printpoint = printpoint + "7"
						xbmc.executebuiltin('Notification($LOCALIZE[31406],$LOCALIZE[79223],2000)')
						xbmc.executebuiltin('Skin.SetString(IRtype,'+ input +')')
						if not remotebutton: dialogok(localize(79221), localize(31406),'[CR]' + localize(74828),"")
						'''---------------------------'''
		
	else:
		if not validation and remote_type != "":
			printpoint = printpoint + "8"
			if not systemplatformwindows: os.system('sh /storage/.kodi/addons/script.htpt.remote/remote.sh')
			print printfirst + "remote.sh; remote type: " + remote_type
			if homeW and datenowS == lastdate:
				dialogok(localize(79221), localize(74825),'[CR]' + localize(74828),"")
				
	setsetting('remote_type_temp',"")
	xbmc.sleep(1000)
	if systemplatformlinux or systemplatformlinuxraspberrypi:
		remote_type = getsetting('remote_type')
		if remote_type != "None": os.system('sh /storage/.kodi/addons/script.htpt.remote/remote.sh')
	
	remote_type2 = getsetting('remote_type')
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "default.py_LV" + printpoint + space + "remote_type" + space2 + remote_type + space5 + remote_type2
	'''---------------------------'''
	
setGeneral_ScriptON("1", General_ScriptON, "")