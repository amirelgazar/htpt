#!/usr/bin/python
import xbmc, sys, xbmcaddon
import xbmcgui, os

from variables import *
from modules import *

IR_Support = setIR_Support(IR_Support)

if IR_Support != "true":
	dialogok('$LOCALIZE[79501]', str74543.encode('utf-8') % ("IR"), str74542.encode('utf-8'),'')
	sys.exit()
setGeneral_ScriptON("0", General_ScriptON, "")

xbmc.executebuiltin('Skin.SetString(IRtype,'+ remote_type +')')

class main:
	if remote_type == "":
		printpoint = printpoint + "1"
		dialogok(addonString(1).encode('utf-8'),addonString(25).encode('utf-8'),'[CR]' + addonString(20).encode('utf-8'),"")
		if irtype: xbmc.executebuiltin('Skin.SetString(IRtype,)')
	if remotebutton or remote_type == "":
		printpoint = printpoint + "2"
		list = ['samsung','lg','philips','toshiba','pilot',''] #sharp
		input = remote_type
		returned, value = dialogselect(addonString(11).encode('utf-8'),list,0)

		if returned == -1:
			printpoint = printpoint + "9"
			if not remotebutton: dialogok(addonString(1).encode('utf-8'),'$LOCALIZE[31406]','[CR]' + addonString(23).encode('utf-8'),"")
		else:
			'''------------------------------
			---NEW-REMOTE-TEST---------------
			------------------------------'''
			printpoint = printpoint + "3"
			input2 = value
			
			setsetting('remote_type_temp',input2)
			xbmc.executebuiltin('Skin.SetString(IRtype,'+ input2 +')')
			'''---------------------------'''
			if not systemplatformwindows: os.system('sh /storage/.kodi/addons/script.htpt.remote/remote.sh')
			dialogok(addonString(20).encode('utf-8'),addonString(21).encode('utf-8') + space2 + input2,addonString(22).encode('utf-8') + space + "(" + test_time + ")","")
			'''---------------------------'''
			count = 0
			while count < 10 and not xbmc.abortRequested:
				count += 1
				notification(addonString(22) + space2 + "10" + space4 + str(count),"","",1000)
				xbmc.sleep(1000)
				if count == 10:
					printpoint = printpoint + "5"
					returned = dialogyesno(addonString(30).encode('utf-8'),addonString(21).encode('utf-8') + space2 + input2)
					if returned == 'ok':
						'''------------------------------
						---NEW-REMOTE-CHOOSEN------------
						------------------------------'''
						printpoint = printpoint + "6"
						notification(addonString(21) + space2 + input2,"","",4000)
						setsetting('remote_type',input2)
						setsetting('lastdate',datenowS)
						'''---------------------------'''
						
					else:
						'''------------------------------
						---KEEP-PREVIOUS-REMOTE----------
						------------------------------'''
						printpoint = printpoint + "7"
						xbmc.executebuiltin('Notification($LOCALIZE[31406],$LOCALIZE[79223],2000)')
						xbmc.executebuiltin('Skin.SetString(IRtype,'+ input +')')
						if not remotebutton: dialogok(addonString(1).encode('utf-8'),'$LOCALIZE[31406]','[CR]' + addonString(23).encode('utf-8'),"")
						'''---------------------------'''
		
	else:
		if not validation and remote_type != "":
			printpoint = printpoint + "8"
			if not systemplatformwindows: os.system('sh /storage/.kodi/addons/script.htpt.remote/remote.sh')
			print printfirst + "remote.sh; remote type: " + remote_type
			if homeW and datenowS == lastdate:
				dialogok(addonString(1).encode('utf-8'),addonString(24).encode('utf-8'),'[CR]' + addonString(23).encode('utf-8'),"")
				
	setsetting('remote_type_temp',"")
	xbmc.sleep(1000)
	if not systemplatformwindows: os.system('sh /storage/.kodi/addons/script.htpt.remote/remote.sh')
	
	remote_type2 = getsetting('remote_type')
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "default.py_LV" + printpoint + space + "remote_type" + space2 + remote_type + space5 + remote_type2
	'''---------------------------'''
	
setGeneral_ScriptON("1", General_ScriptON, "")