import xbmc, xbmcgui
import os, sys
import subprocess
import xbmcaddon

'''OTHERS'''
xbmc.sleep(5000)
from variables import *
from modules import *

class startup:
	setsetting('General_ScriptON','false')
	
	while servicehtpt_Skin_Name == 'N/A' or servicehtpt_Skin_Name != 'skin.htpt' and not xbmc.abortRequested:
		xbmc.sleep(10000)
		addon = 'service.htpt'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			getsetting_servicehtpt = xbmcaddon.Addon(addon).getSetting
			servicehtpt_Skin_Name = getsetting_servicehtpt('Skin_Name')
			'''---------------------------'''
	IR_Support = setIR_Support(IR_Support)
	if IR_Support == "":
		IR_Support = getsetting('IR_Support')
		if IR_Support == "false": dialogok('$LOCALIZE[79607]', '$LOCALIZE[79606]', '', '')
		elif IR_Support == "true": dialogok('$LOCALIZE[79607]', '$LOCALIZE[79605]', '', '')
	
	if IR_Support == "true":
		count = 0
		while count < 40 and not xbmc.abortRequested:
			xbmc.sleep(10000)
			admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
			homeW = xbmc.getCondVisibility('Window.IsVisible(Home.xml)')
			systemidle10 = xbmc.getCondVisibility('System.IdleTime(10)')
			returned_Dialog, returned_Header, returned_Message = checkDialog(admin)

			if returned_Dialog == "" and homeW and systemidle10:
				xbmc.executebuiltin('RunScript(script.htpt.remote)')
				count = 40
				xbmc.sleep(1000)
