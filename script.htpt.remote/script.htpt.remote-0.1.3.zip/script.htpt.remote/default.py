#!/usr/bin/python
import xbmc, sys, xbmcaddon
import xbmcgui, os

from variables import *
from modules import *

xbmc.executebuiltin('Skin.SetString(IRtype,'+ remote_type +')')

''''''
class main:
	if remote_type == "":
		dialogok(addonString(1).encode('utf-8'),addonString(25).encode('utf-8'),'[CR]' + addonString(20).encode('utf-8'),"")
		if irtype: xbmc.executebuiltin('Skin.SetString(IRtype,)')
	if remotebutton or remote_type == "":
		print printfirst + "irtypebutton"
		list0 = 'samsung'
		list1 = 'lg'
		list2 = 'philips'
		list3 = 'toshiba'
		list4 = 'pilot'
		input = remote_type
		returned, value = dialogselect(addonString(11).encode('utf-8'),[list0, list1, list2, list3, list4],0)
		returned = int(returned)
		if returned == -1:
			xbmc.executebuiltin('Notification($LOCALIZE[31406],$LOCALIZE[79223],2000)') #HAPEULA BUTLA, LO BUTZHU SINUHIM
			if not remotebutton: dialogok(addonString(1).encode('utf-8'),'$LOCALIZE[31406]','[CR]' + addonString(23).encode('utf-8'),"")
		else:
			'''new setting'''
			if returned == 0: input2 = list0
			elif returned == 1: input2 = list1
			elif returned == 2: input2 = list2
			elif returned == 3: input2 = list3
			elif returned == 4: input2 = list4
			
			setsetting('remote_type_temp',input2)
			xbmc.executebuiltin('Skin.SetString(IRtype,'+ input2 +')')
			if not systemplatformwindows: os.system('sh /storage/.kodi/addons/script.htpt.remote/remote.sh')
			dialogok(addonString(20).encode('utf-8'),addonString(21).encode('utf-8') + space2 + input2,addonString(22).encode('utf-8') + space + "(" + test_time + ")","")
			count = 0
			while count < 10 and not xbmc.abortRequested:
				xbmc.sleep(1000)
				count += 1
				if count == 10:
					returned = dialogyesno(addonString(30).encode('utf-8'),addonString(21).encode('utf-8') + space2 + input2)
					if returned == 'ok':
						xbmc.executebuiltin('Notification('+ addonString(21).encode('utf-8') +' '+ space2 +' '+ input2 +' ,,5000)')
						setsetting('remote_type',input2)
						changeset('1',lastdate,'lastdate')
					else:
						xbmc.executebuiltin('Notification($LOCALIZE[31406],$LOCALIZE[79223],2000)')
						xbmc.executebuiltin('Skin.SetString(IRtype,'+ input +')')
						if not remotebutton: dialogok(addonString(1).encode('utf-8'),'$LOCALIZE[31406]','[CR]' + addonString(23).encode('utf-8'),"")
		
	else:
		''''''
		import datetime
		timenow = datetime.date.today()
		timenow = str(timenow)
		if not validation and remote_type != "":
			if not systemplatformwindows: os.system('sh /storage/.kodi/addons/script.htpt.remote/remote.sh')
			print printfirst + "remote.sh; remote type: " + remote_type
			if home and timenow == lastdate:
				dialogok(addonString(1).encode('utf-8'),addonString(24).encode('utf-8'),'[CR]' + addonString(23).encode('utf-8'),"")
	setsetting('remote_type_temp',"")
	
	sys.exit()