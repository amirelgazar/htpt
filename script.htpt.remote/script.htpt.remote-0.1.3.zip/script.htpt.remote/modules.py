#import xbmc, os, subprocess, sys
#import xbmc, xbmcgui, xbmcaddon
import xbmc, xbmcgui, xbmcaddon
import subprocess, os, sys
#import datetime, time
from variables import *
from shared_modules import *
#from shared_modules2 import *
#from modules2 import *

def changeset(type,value,addonsetting):
	import datetime
	timenow = datetime.date.today()
	timenow = str(timenow)
	print printfirst + value + ", " + timenow
	if type == '1':
		if value != timenow: setsetting(addonsetting, timenow)

		
def irkeytable(filename):
	filepath = addonPath + "/resources/remotes/" + filename
	print filepath
	if filename == 'samsung' or filename == 'lg' or filename == 'philips' or filename == 'toshiba': type = "nec,rc-6"
	
	#elif filename == 'philips':
	#os.system("date")
	#f = os.popen('date')
	#now = f.read()
	#a = os.system("ir-keytable -p type -w filepath -D 700 -P 200")
	#subprocess.call(["ir-keytable", "-p", "nec,rc-6", "-w ", filepath, "-D 700 -P 200"])
	os.system('sh /storage/.kodi/addons/script.htpt.remote/remote.sh')
	bash('ir-keytable -p nec,rc-6 -w /storage/.kodi/addons/script.htpt.remote/resources/remotes/samsung -D 700 -P 200',"ir-keytable")
	#subprocess.call(["ir-keytable -p nec,rc-6 -w /storage/.kodi/addons/script.htpt.remote/resources/remotes/samsung -D 700 -P 200"])
	xbmc.executebuiltin('Notification(news,1,2000)')
	#print a
	#ir-keytable -p $REMOTE_TYPE -w $REMOTES_PATH/$REMOTE_FILE -D 700 -P 200

