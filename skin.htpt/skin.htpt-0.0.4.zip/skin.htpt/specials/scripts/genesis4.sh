#!/bin/bash
SETTINGS=$HOME/.xbmc/userdata/addon_data/plugin.video.genesis/settings.xml

###VAR SWITCHABLE###
AUTOPLAYHD='"autoplay_hd" value='
AUTOPLAY='"autoplay" value='
AUTOPLAYLIBRARY='"autoplay_library" value='
PLAYBACKINFO='"playback_info" value='

###VAR GENERAL###
T='"true"'
F='"false"'
ALL='"[^ ]*"'
NUM5='"5"'
NUM4='"4"'
NUM3='"3"'
NUM2='"2"'
NUM1='"1"'
NUM0='"0"'

###GET ConnectionStatus2###
GUI='/storage/.xbmc/userdata/guisettings.xml'
FIND1='>[^ ]<' ###?###
FINDIN=$GUI
FINDWHAT='ConnectionStatus2"'
FINDLINE=`find $FINDIN -type f -exec grep $FINDWHAT /dev/null {} \;`
FINDEXACT=`echo $FINDLINE | grep -o '>[^ ]*<' | sed 's/[<>]//g'`
CONNECTIONSTATUS2='"'$FINDEXACT'"'
echo ConnectionStatus2: $CONNECTIONSTATUS2 '('$FINDEXACT')'

###GET AutoPlaySD###
GUI='/storage/.xbmc/userdata/guisettings.xml'
FIND1='>[^ ]<' ###?###
FINDIN=$GUI
FINDWHAT='AutoPlaySD"'
FINDLINE=`find $FINDIN -type f -exec grep $FINDWHAT /dev/null {} \;`
FINDEXACT=`echo $FINDLINE | grep -o '>[^ ]*<' | sed 's/[<>]//g'`
AUTOPLAYSD='"'$FINDEXACT'"'
echo AutoPlaySD: $AUTOPLAYSD '('$FINDEXACT')'

###GET AutoPlayPause###
GUI='/storage/.xbmc/userdata/guisettings.xml'
FIND1='>[^ ]<' ###?###
FINDIN=$GUI
FINDWHAT='AutoPlayPause"'
FINDLINE=`find $FINDIN -type f -exec grep $FINDWHAT /dev/null {} \;`
FINDEXACT=`echo $FINDLINE | grep -o '>[^ ]*<' | sed 's/[<>]//g'`
AUTOPLAYPAUSE='"'$FINDEXACT'"'
echo AutoPlayPause: $AUTOPLAYPAUSE '('$FINDEXACT')'

if [ $CONNECTIONSTATUS2 == $NUM5 ] && [ $AUTOPLAYPAUSE == $F ]; then
	echo Activate AutoPlay HD
	sed -i "s/$AUTOPLAYHD$F/$AUTOPLAYHD$T/g" $SETTINGS ###AUTOPLAY HD SOURCES ON###
	sed -i "s/$AUTOPLAY$F/$AUTOPLAY$T/g" $SETTINGS ###AUTOPLAY ADDON ON###
	sed -i "s/$AUTOPLAYLIBRARY$F/$AUTOPLAYLIBRARY$T/g" $SETTINGS ###AUTOPLAY LIBRARY ON###
	sed -i "s/$PLAYBACKINFO$F/$PLAYBACKINFO$T/g" $SETTINGS ###DETAILS ON###
fi

if [ $CONNECTIONSTATUS2 == $NUM4 ] && [ $AUTOPLAYSD == $T ] && [ $AUTOPLAYPAUSE == $F ]; then
	echo Activate AutoPlay SD
	sed -i "s/$AUTOPLAYHD$T/$AUTOPLAYHD$F/g" $SETTINGS ###AUTOPLAY HD SOURCES ON###
	sed -i "s/$AUTOPLAY$F/$AUTOPLAY$T/g" $SETTINGS ###AUTOPLAY ADDON ON###
	sed -i "s/$AUTOPLAYLIBRARY$F/$AUTOPLAYLIBRARY$T/g" $SETTINGS ###AUTOPLAY LIBRARY ON###
	sed -i "s/$PLAYBACKINFO$F/$PLAYBACKINFO$T/g" $SETTINGS ###DETAILS ON###
else
	if [ $CONNECTIONSTATUS2 == $NUM4 ] || [ $CONNECTIONSTATUS2 == $NUM3 ] || [ $AUTOPLAYPAUSE == $T ]; then
		echo Deactivate AutoPlay
		sed -i "s/$AUTOPLAYHD$T/$AUTOPLAYHD$F/g" $SETTINGS ###AUTOPLAY HD SOURCES ON###
		sed -i "s/$AUTOPLAY$T/$AUTOPLAY$F/g" $SETTINGS ###AUTOPLAY ADDON OFF###
		sed -i "s/$AUTOPLAYLIBRARY$T/$AUTOPLAYLIBRARY$F/g" $SETTINGS ###AUTOPLAY LIBRARY OFF###
		sed -i "s/$PLAYBACKINFO$T/$PLAYBACKINFO$F/g" $SETTINGS ###DETAILS OFF###
	fi
fi
