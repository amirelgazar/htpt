#!/bin/bash

pgrep xbmc.bin | xargs kill -SIGSTOP
#Uncomment this below if you have any issues

#$ADDON_DIR/bin/retroarch -c $ADDON_FILES/config/retroarch.cfg $EXTRAFLAG -L $ADDON_CORES/$1_libretro.so "$2" &

while [ pgrep xbmc.bin | xargs kill -SIGSTOP ];do
    usleep 200000
done;
#systemctl start xbmc.service
pgrep xbmc.bin | xargs kill -SIGCONT