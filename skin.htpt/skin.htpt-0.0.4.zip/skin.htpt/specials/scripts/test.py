import xbmc, xbmcgui
 
#get actioncodes from https://github.com/xbmc/xbmc/blob/master/xbmc/guilib/Key.h

xbmc.executebuiltin('RunScript(script.toolbox,info=textviewer,header="SOME_HEADER",text="SOME_TEXT")')
#xbmc.executebuiltin('ActivateWindow(DialogTextViewer.xml)')
#dialog = xbmcgui.Dialog()
#dialog.textviewer(" My message title", "message")
sys.exit()
ACTION_PREVIOUS_MENU = 10
ACTION_SELECT_ITEM = 7
systemtime = xbmc.getInfoLabel('System.Time(HH:MM:SS)')
xbmc.executebuiltin('Skin.SetString(Test3,'+ systemtime +')')
class MyClass(xbmcgui.Window):
  def __init__(self):
    self.message('you pushed A')
 
  def message(self, message):
    dialog = xbmcgui.Dialog()
    dialog.ok(" My message title", message)
 
mydisplay = MyClass()
