#!/bin/sh
ADDON_DIR=$HOME/.xbmc/addons/emulator.retroarch
LD_LIBRARY_PATH=$ADDON_DIR/lib
#chmod 644 $HOME/.config/autostart.sh ###ORIGNAL 644?###
#chmod +x $HOME/.config/autostart.sh ###ORIGNAL 644?###
chmod +x $ADDON_DIR/bin/*
SKIN_PATH=$HOME/.xbmc/addons/skin.htpt
SERVICE_PATH=/storage/.xbmc/addons/service.htpt
chmod +x $SKIN_PATH/specials/scripts/*
chmod +x $SERVICE_PATH/specials/scripts/*
export LD_LIBRARY_PATH
$HOME/.xbmc/addons/skin.htpt/specials/scripts/remote.sh
$HOME/.xbmc/addons/skin.htpt/specials/scripts/copy.sh

#killall eventlircd
#ir-keytable -s rc0 -p NEC -t
#You can see if autostart.sh is executed from /var/log/messages file.
echo `(date)` >> /storage/autostart.log