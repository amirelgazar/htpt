import xbmc, xbmcgui
 
#get actioncodes from https://github.com/xbmc/xbmc/blob/master/xbmc/guilib/Key.h
ACTION_PREVIOUS_MENU = 10
 
class MyClass(xbmcgui.Window):
  def __init__(self):
    self.strActionInfo = xbmcgui.ControlLabel(100, 120, 200, 200, '', 'font13', '0xFFFF00FF')
    self.addControl(self.strActionInfo)
    self.strActionInfo.setLabel('Push BACK to quit')
    self.button0 = xbmcgui.ControlButton(350, 500, 80, 30, "HELLO")
    self.addControl(self.button0)
    self.setFocus(self.button0)
 
  def onAction(self, action):
    if action == ACTION_PREVIOUS_MENU:
      self.close()
 
  def onControl(self, control):
    if control == self.button0:
      self.message('you pushed the button')
 
  def message(self, message):
    dialog = xbmcgui.Dialog()
    dialog.ok(" My message title", message)
 
mydisplay = MyClass()
mydisplay .doModal()
del mydisplay