#!/bin/bash
import xbmc, xbmcgui
import os

admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
systemplatformwindows = xbmc.getCondVisibility('system.platform.windows')
if admin: xbmc.executebuiltin('Notification(Admin,softsuspend,2000)')
if not systemplatformwindows: os.system('sh /storage/.xbmc/addons/skin.htpt/specials/scripts/softsuspend.sh')