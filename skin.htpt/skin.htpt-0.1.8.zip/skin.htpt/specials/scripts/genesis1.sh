#!/bin/bash
SETTINGS=$HOME/.kodi/userdata/addon_data/plugin.video.genesis/settings.xml
###VAR SOURCES###
CLICKPLAYTV='"clickplay_tv" value='
EINTHUSAN='"einthusan" value='
GTG='"g2g" value='
HDLORD='"hdlord" value='
ICEFILMS='"icefilms" value='
ICEFILMSTV='"icefilms_tv" value='
ISTREAMHD='"istreamhd" value='
ISTREAMHDTV='"istreamhd_tv" value='
IWATCHONLINE='"iwatchonline" value='
IWATCHONLINETV='"iwatchonline_tv" value='
MUCHMOVIES='"muchmovies" value='
MOVIESTORM='"moviestorm" value='
MOVIESTORMTV='"moviestorm_tv" value='
MOVIESHD='"movieshd" value='
MOVIE25='"movie25" value='
MOVIETUBE='"movietube" value='
MOVIETUBETV='"movietube_tv" value='
MOVIETV='"movietv" value='
MOVIETVTV='"movietv_tv" value='
MYVIDEOLINKS='"myvideolinks" value='
NITER='"niter" value='
PRIMEWIRE='"primewire" value='
PRIMEWIRETV='"primewire_tv" value='
POPCORNERED='"popcornered" value='
PUTLOCKERTV='"putlocker_tv" value='
SHUSHTV='"shush_tv" value='
SIMPLYMOVIES='"simplymovies" value='
SIMPLYMOVIESTV='"simplymovies_tv" value='
SWEFLIX='"sweflix" value='
VIEW47='"view47" value='
VKBOX='"vkbox" value='
VKBOXTV='"vkbox_tv" value='
WATCHSERIESTV='"watchseries_tv" value='
WSO='"wso" value='
WSOTV='"wso_tv" value='
YIFY='"yify" value='
YOURFLIX='"yourflix" value='


###VAR PRIORITY SD###
HOST1='"host1" value='
HOST2='"host2" value='
HOST3='"host3" value='
HOST4='"host4" value='
HOST5='"host5" value='
HOST6='"host6" value='
HOST7='"host7" value='
HOST8='"host8" value='
HOST9='"host9" value='
HOST10='"host10" value='
HOST11='"host11" value='
HOST12='"host12" value='
HOST13='"host13" value='
HOST14='"host14" value='
HOST15='"host15" value='
HOST16='"host16" value='
HOST17='"host17" value='
HOST18='"host18" value='
HOST19='"host19" value='
HOST20='"host20" value='

###VAR PRIORITY HD###
HOSTHD1='"hosthd1" value='
HOSTHD2='"hosthd2" value='
HOSTHD3='"hosthd3" value='
HOSTHD4='"hosthd4" value='
HOSTHD5='"hosthd5" value='
HOSTHD6='"hosthd6" value='
HOSTHD7='"hosthd7" value='
HOSTHD8='"hosthd8" value='
HOSTHD9='"hosthd9" value='
HOSTHD10='"hosthd10" value='
HOSTHD11='"hosthd11" value='
HOSTHD12='"hosthd12" value='
HOSTHD13='"hosthd13" value='
HOSTHD14='"hosthd14" value='
HOSTHD15='"hosthd15" value='
HOSTHD16='"hosthd16" value='
HOSTHD17='"hosthd17" value='
HOSTHD18='"hosthd18" value='
HOSTHD19='"hosthd19" value='
HOSTHD20='"hosthd20" value='

###HOSTS LIST###
CLOUDYVIDEOS='"Cloudyvideos"'
VK='"VK"'
VIDBULL='"Vidbull"'
MIGHTYUPLOAD='"Mightyupload"'
MOVSHARE='"Movshare"'
PROMPTFILE='"Promptfile"'
VODLOCKER='"Vodlocker"'
PLAYED='"Played"'
GORILLAVID='"Gorillavid"'
BESTREAMS='"Bestreams"'
BILLIONSUPLOADS='"Billionuploads"'
DIVXSTAGE='"Divxstage"'
MOVIETV='"MovieTV"'
GVIDEO='"GVideo"'
ORORO='"Ororo"'
STREAMIN='"Streamin"'
GRIFTHOST='"Grifthost"'
ISHARED='"iShared"'
CMRFILE='"Mrfile"'
MOVREEL='"Movreel"'
VVIDS='"V-vids"'
HUGEFILES='"Hugefiles"'
UPLOAD180='"180upload"'
FILECLOUD='"Filecloud"'
UPLOADROCKET='"Uploadrocket"'
KINGFILES='"Kingfiles"'
POPCORNERED='"Popcornered"'
YOURFLIX='"Yourflix"'
MUCHMOVIES='"Muchmovies"'
HDLORD='"HDlord"'
VIDEOMEGA='"Videomega"'
NITER='"Niter"'
YIFY='"YIFY"'
EINTHUSAN='"Einthusan"'
MOVZAP='"Movzap"'
MAILRU='"Mailru"'
THEFILE='"Thefile"'

###VAR GENERAL###
T='"true"'
F='"false"'

ALL='"[^ ]*"'
NUM1='"1"'
NUM0='"0"'

###SOURCES###
sed -i "s/$CLICKPLAYTV$F/$CLICKPLAYTV$T/g" $SETTINGS
sed -i "s/$EINTHUSAN$F/$EINTHUSAN$T/g" $SETTINGS
sed -i "s/$GTG$F/$GTG$T/g" $SETTINGS
sed -i "s/$HDLORD$F/$HDLORD$T/g" $SETTINGS
sed -i "s/$ICEFILMS$F/$ICEFILMS$T/g" $SETTINGS
sed -i "s/$ICEFILMSTV$F/$ICEFILMSTV$T/g" $SETTINGS
sed -i "s/$ISTREAMHD$F/$ISTREAMHD$T/g" $SETTINGS
sed -i "s/$ISTREAMHDTV$F/$ISTREAMHDTV$T/g" $SETTINGS
sed -i "s/$IWATCHONLINE$F/$IWATCHONLINE$T/g" $SETTINGS
sed -i "s/$IWATCHONLINETV$F/$IWATCHONLINETV$T/g" $SETTINGS
sed -i "s/$MUCHMOVIES$F/$MUCHMOVIES$T/g" $SETTINGS
sed -i "s/$MOVIESTORM$F/$MOVIESTORM$T/g" $SETTINGS
sed -i "s/$MOVIESTORMTV$F/$MOVIESTORMTV$T/g" $SETTINGS
sed -i "s/$MOVIESHD$F/$MOVIESHD$T/g" $SETTINGS
sed -i "s/$MOVIE25$F/$MOVIE25$T/g" $SETTINGS
sed -i "s/$MOVIETUBE$F/$MOVIETUBE$T/g" $SETTINGS
sed -i "s/$MOVIETUBETV$F/$MOVIETUBETV$T/g" $SETTINGS
sed -i "s/$MOVIETV$F/$MOVIETV$T/g" $SETTINGS
sed -i "s/$MOVIETVTV$F/$MOVIETVTV$T/g" $SETTINGS
sed -i "s/$MYVIDEOLINKS$F/$MYVIDEOLINKS$T/g" $SETTINGS
sed -i "s/$NITER$F/$NITER$T/g" $SETTINGS
sed -i "s/$POPCORNERED$F/$POPCORNERED$T/g" $SETTINGS
sed -i "s/$PRIMEWIRE$F/$PRIMEWIRE$T/g" $SETTINGS
sed -i "s/$PUTLOCKERTV$F/$PUTLOCKERTV$T/" $SETTINGS
sed -i "s/$PRIMEWIRETV$F/$PRIMEWIRETV$T/g" $SETTINGS
sed -i "s/$SHUSHTV$F/$SHUSHTV$T/g" $SETTINGS
sed -i "s/$VKBOX$F/$VKBOX$T/g" $SETTINGS
sed -i "s/$VKBOXTV$F/$VKBOXTV$T/g" $SETTINGS
sed -i "s/$SIMPLYMOVIES$F/$SIMPLYMOVIES$T/g" $SETTINGS
sed -i "s/$SIMPLYMOVIESTV$F/$SIMPLYMOVIESTV$T/g" $SETTINGS
sed -i "s/$WATCHSERIESTV$F/$WATCHSERIESTV$T/g" $SETTINGS
sed -i "s/$YIFY$F/$YIFY$T/g" $SETTINGS
sed -i "s/$YOURFLIX$F/$YOURFLIX$T/g" $SETTINGS

###VAR PRIORITY SD###
sed -i "s|$HOST1$ALL|$HOST1$ORORO|g" $SETTINGS
sed -i "s|$HOST2$ALL|$HOST2$MOVIETV|g" $SETTINGS
sed -i "s|$HOST3$ALL|$HOST3$ISHARED|g" $SETTINGS
sed -i "s|$HOST4$ALL|$HOST4$STREAMIN|g" $SETTINGS
sed -i "s|$HOST5$ALL|$HOST5$THEFILE|g" $SETTINGS
sed -i "s|$HOST6$ALL|$HOST6$VK|g" $SETTINGS
#sed -i "s|$HOST7$ALL|$HOST7$VK|g" $SETTINGS
#sed -i "s|$HOST8$ALL|$HOST8$VK|g" $SETTINGS
#sed -i "s|$HOST9$ALL|$HOST9$VK|g" $SETTINGS
#sed -i "s|$HOST10$ALL|$HOST10$VK|g" $SETTINGS
#sed -i "s|$HOST11$ALL|$HOST11$VK|g" $SETTINGS

###VAR PRIORITY HD###
sed -i "s|$HOSTHD1$ALL|$HOSTHD2$GVIDEO|g" $SETTINGS
sed -i "s|$HOSTHD2$ALL|$HOSTHD2$NITER|g" $SETTINGS
sed -i "s|$HOSTHD3$ALL|$HOSTHD3$POPCORNERED|g" $SETTINGS
sed -i "s|$HOSTHD4$ALL|$HOSTHD4$MUCHMOVIES|g" $SETTINGS
sed -i "s|$HOSTHD5$ALL|$HOSTHD5$YOURFLIX|g" $SETTINGS
sed -i "s|$HOSTHD6$ALL|$HOSTHD6$HDLORD|g" $SETTINGS
sed -i "s|$HOSTHD7$ALL|$HOSTHD7$VIDEOMEGA|g" $SETTINGS
sed -i "s|$HOSTHD8$ALL|$HOSTHD8$YIFY|g" $SETTINGS
sed -i "s|$HOSTHD9$ALL|$HOSTHD9$EINTHUSAN|g" $SETTINGS
sed -i "s|$HOSTHD10$ALL|$HOSTHD10$VK|g" $SETTINGS
sed -i "s|$HOSTHD11$ALL|$HOSTHD11$MOVREEL|g" $SETTINGS