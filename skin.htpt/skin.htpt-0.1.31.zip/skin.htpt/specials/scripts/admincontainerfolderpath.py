
#import os
###INFORMATION###
#xbmcLang = xbmc.getLanguage(0)
#if xbmcLang != "he":
	#xbmcLang = "en"
#xbmc.getCondVisibility( 'Window.IsVisible(movieinformation)' )	
#if xbmc.getInfoLabel('Skin.HasSetting(Admin)') != "":
# ???  if not xbmc.Player().isPlayingVideo():   |   xbmcgui.getCurrentWindowId() == 10000:

#################################################
import xbmc
#import subprocess,os
admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')

test = xbmc.getInfoLabel('Skin.String(Test)')
test2 = xbmc.getInfoLabel('Skin.String(Test2)')
containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
systemcurrentwindow = xbmc.getInfoLabel('System.CurrentWindow')
###PATH###
class main:
	if admin: xbmc.executebuiltin('Notification(Admin,'+ containerfolderpath +',1000)')
	xbmc.executebuiltin('Skin.SetString(test,'+ containerfolderpath +')')
	xbmc.executebuiltin('Skin.SetString(test2,'+ systemcurrentwindow +')')