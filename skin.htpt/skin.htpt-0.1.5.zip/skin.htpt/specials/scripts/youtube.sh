#!/bin/bash
USERDATA_PATH=$HOME/.kodi/userdata
SETTINGS=$USERDATA_PATH/addon_data/plugin.video.youtube/settings.xml

###GET USER ID###
GUI='/storage/.kodi/userdata/guisettings.xml'
FINDIN=$GUI
FINDWHAT='"skin.htpt.ID"'
FINDLINE=`find $FINDIN -type f -exec grep $FINDWHAT /dev/null {} \;`
FINDEXACT=`echo $FINDLINE | grep -o '>[^ ]*<' | sed 's/[<>]//g'`
ID='"'$FINDEXACT'"'
ID2='"'$FINDEXACT''
IDP='"gkalni"'
echo ID: $ID '('$FINDEXACT')'

###VAR GENERAL###
E='""'
T='"true"'
F='"false"'
EN='"English"'
HE='"Hebrew"'
ALL='"[^ ]*"'
NUM3='"3"'
NUM2='"2"'
NUM1='"1"'
NUM0='"0"'
NUM24='"24"'
GMAIL='@gmail.com"'

###VAR FIX###
ANNOTATIONS='"annotations" value='
CATEGORIES='"categories" value='
DOMAIN='"contacts" value='
COOKIESSAVED='"cookies_saved" value='
DEBUG='"debug" value='
DISCO='"disco" value='
DOWNLOADPATH='"download_path" value='
DOWNLOADS='"downloads" value='
EXPLORE='"explore" value='
FAVORITES='"favorites" value='
FEEDS='"feeds" value='
FIRSTRUN='"firstrun" value='
HDVIDEOS='"hd_videos" value='
HDVIDEOSDOWNLOAD='"hd_videos_download" value='
HISTORY='"history" value='
LANGCODE='"lang_code" value='
LIKED='"liked" value='
LISTVIEW='"list_view" value='
LIVE='"live" value='
MOVIES='"movies" value='
MUSIC='"music" value='
NOTIFICATION='"notification_length" value='
OAUTH2A='"oauth2_access_token" value='
OAUTH2B='"oauth2_expires_at" value='
OAUTH2C='"oauth2_refresh_token" value='
PERPAGE='"perpage" value='
PLAYLISTS='"playlists" value='
PREFERRED='"preferred" value='
RECOMMENDED='"recommended" value='
REGIONID='"region_id" value='
SAFESEARCH='"safe_search" value='
SAVEDSEARCHES='"saved_searches" value='
SEARCH='"search" value='
SHOWS='"shows" value='
STORESEARCHS='"store_searches" value='
SUBSCRIPTIONS='"subscriptions" value='
TIMEOUT='"timeout" value='
TRAILERS='"trailers" value='
TRANSCODE='"transcode" value='
UPLOADS='"uploads" value='
USERPASSWORD='"user_password" value='
USERNAME='"username" value='
WATCHLATER='"watch_later" value='

###+++###
DOWNLOAD_PATH='"special://userdata/library/downloads/"'

###SED FIX###
sed -i "s/$ANNOTATIONS$T/$ANNOTATIONS$F/g" $SETTINGS
sed -i "s/$CATEGORIES$T/$CATEGORIES$F/g" $SETTINGS
sed -i "s/$DOMAIN$T/$DOMAIN$F/g" $SETTINGS
sed -i "s/$COOKIESSAVED$F/$COOKIESSAVED$T/g" $SETTINGS
sed -i "s/$DEBUG$T/$DEBUG$F/g" $SETTINGS
sed -i "s/$DISCO$T/$DISCO$F/g" $SETTINGS
sed -i "s|$DOWNLOADPATH$ALL|$DOWNLOADPATH$DOWNLOAD_PATH|g" $SETTINGS

YOUTUBE_COOKIE=$USERDATA_PATH/addon_data/service.subtitles.subtitle/cookiejar.txt
if [ -f "$YOUTUBE_COOKIE" ]; then
	rm -f $YOUTUBE_COOKIE
	echo YOUTUBE_COOKIE DELETED
fi