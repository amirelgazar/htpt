#!/bin/bash

USERDATA_PATH=$HOME/.kodi/userdata
USERDATA_PATH2=$HOME/.kodi/addons/skin.htpt/specials/scripts/copy/userdata
USERDATA_PATH3=$HOME/.kodi/userdata/addon_data/skin.htpt/userdata

if [ ! -d "$USERDATA_PATH3" ]; then
	echo CREATING USERDATA_PATH3
	mkdir -p $USERDATA_PATH3
fi

VALIDATION2='"skin.htpt.VALIDATION2">'
T='true'
F='false'
RESET=$F
VALIDATION2=`cat $USERDATA_PATH/guisettings.xml | grep -i $VALIDATION2$F | wc -l`
GUISETTINGS_FILE_CON1=`cat $USERDATA_PATH/guisettings.xml | grep -i "<skin>skin.htpt</skin>" | wc -l`
GUISETTINGS_FILE2_CON1=`cat $USERDATA_PATH3/guisettings.xml | grep -i "<skin>skin.htpt</skin>" | wc -l`
GUISETTINGS_FILE3_CON1=`cat $USERDATA_PATH3/guisettings2.xml | grep -i "<skin>skin.htpt</skin>" | wc -l`

###GET CustomGUI###
GUI='/storage/.kodi/userdata/guisettings.xml'
FIND1='>[^ ]*<' ###?###
FINDIN=$GUI
FINDWHAT='"skin.htpt.CustomGUI"'
FINDLINE=`find $FINDIN -type f -exec grep $FINDWHAT /dev/null {} \;`
FINDEXACT=`echo $FINDLINE | grep -o '>[^ ]*<' | sed 's/[<>]//g'`
CustomGUI='"'$FINDEXACT'"'
echo CustomGUI: $CustomGUI '('$FINDEXACT')'

if [ $GUISETTINGS_FILE_CON1 -eq 0 ]; then
	echo Error: GUISETTINGS_FILE_CON1!
	if [ $GUISETTINGS_FILE2_CON1 -eq 0 ]; then
		echo Error: GUISETTINGS_FILE2_CON1!
		if [ $GUISETTINGS_FILE3_CON1 -eq 0 ]; then
			echo Error: GUISETTINGS_FILE3_CON1!
			cp -f $USERDATA_PATH2/guisettings3.xml $USERDATA_PATH/guisettings.xml
			#systemctl stop xbmc.service
		else
			echo Copy: $USERDATA_PATH3/guisettings2.xml '->' $USERDATA_PATH/guisettings.xml
			cp -f $USERDATA_PATH3/guisettings2.xml $USERDATA_PATH/guisettings.xml
		fi
	else
		echo Copy: $USERDATA_PATH3/guisettings.xml '->' $USERDATA_PATH/guisettings.xml
		cp -f $USERDATA_PATH3/guisettings.xml $USERDATA_PATH/guisettings.xml
	fi
	#sleep 5
	#echo systemctl start
	#systemctl start xbmc.service
	RESET=$T
	#sleep 1 && echo killall && killall -9 kodi.bin
	
else
	if [ $GUISETTINGS_FILE2_CON1 -eq 0 ]; then
		echo Error: GUISETTINGS_FILE2_CON1!!
	else
		echo Old Backup: guisettings2.xml
		cp -f $USERDATA_PATH3/guisettings.xml $USERDATA_PATH3/guisettings2.xml
	fi
	if [ $VALIDATION2 -eq 1 ]; then ###must run before startup.xml (autostart.sh)
		echo New Backup: guisettings.xml
		cp -f $USERDATA_PATH/guisettings.xml $USERDATA_PATH3/guisettings.xml
	else
		echo ERROR: VALIDATION2!!! CANT CREATE NEW BACKUP $VALIDATION2
	fi
fi

SKIN_PATH=/storage/.kodi/addons/skin.htpt
SKIN_FOLDER_SIZE=`du $SKIN_PATH/ -s | awk {'print $1'}`

{ ## SERVICE PATH CHECK
SERVICE_PATH=/storage/.kodi/addons/service.htpt

if [ ! -d "$SERVICE_PATH" ]; then
	echo ERROR: SERVICE_PATH EMPTY!
	SERVICE_FILE=`$HOME/.kodi/addons/packages/service.htpt*`
	ls $SERVICE_FILE -r | awk {'print $1'} | tee /storage/servicepackage.log
	SERVICE_FILE1=`head -1 servicepackage.log`
	SERVICE_FILE1_SIZE=`du $SERVICE_FILE1 -s | awk {'print $1'}`
	SERVICE_FILE2=`sed -n 2p servicepackage.log`
	SERVICE_FILE2_SIZE=`du $SERVICE_FILE2 -s | awk {'print $1'}`
	SERVICE_FILE3=`sed -n 3p servicepackage.log`
	SERVICE_FILE3_SIZE=`du $SERVICE_FILE3 -s | awk {'print $1'}`
	
	if [ $SERVICE_FILE1 -gt 10000 ] && [ -f SERVICE_FILE1 ]; then
		echo EXTRACTING SERVICE_FILE1
		unzip -o -q $SERVICE_FILE1 -d /storage/.kodi/addons/
		rm $SERVICE_FILE1
		
		PERMISSION1=`ls -l /storage/.kodi/addons/service.htpt/specials/scripts/ | awk {'print $1'}`
		chmod +x $SERVICE_PATH/specials/scripts/*
		PERMISSION2=`ls -l /storage/.kodi/addons/service.htpt/specials/scripts/ | awk {'print $1'}`
		echo EXTRACTING COMPLETE! $PERMISSION1 -'>' $PERMISSION2
		RESET=$T
	else
		echo SERVICE_FILE NOT FOUNDS!
	fi

else
	echo SERVICE PATH CHECK --- OK!
fi
}

###GET USER ID10###
GUI='/storage/.kodi/userdata/guisettings.xml'
FIND1='>[^ ]*<' ###?###
FINDIN=$GUI
FINDWHAT='"skin.htpt.ID10"'
FINDLINE=`find $FINDIN -type f -exec grep $FINDWHAT /dev/null {} \;`
FINDEXACT=`echo $FINDLINE | grep -o '>[^ ]*<' | sed 's/[<>]//g'`
ID10='"'$FINDEXACT'"'
echo ID10: $ID10 '('$FINDEXACT')'

if [ $RESET == $T ]; then
	echo RESET = $RESET -'>' killall, sleep4 && sleep 4 && killall -9 kodi.bin
	
else
	
	{ ## ADVANCEDSETTINGS
	if [ -d "$SKIN_PATH" ]; then
		CUSTOM_PATH=$HOME/.kodi/userdata/addon_data/skin.htpt
		FILE1_PATH=$USERDATA_PATH2
		FILE2_PATH=$USERDATA_PATH
		FILENAME=advancedsettings.xml
		FILENAME_A=advancedsettings_A.xml
		FILENAME_B=advancedsettings_B.xml
		FILENAME_C=advancedsettings_C.xml
		FILENAME_D=advancedsettings_D.xml
		
		x=""
		PERMISSION1=`ls -l $FILE2_PATH/$FILENAME | awk {'print $1'}`
		
		if [ $ID10 == '"A"' ] && [ -f $USERDATA_PATH2/$FILENAME_A ]; then
			x=$FILENAME_A
		
		elif [ $ID10 == '"B"' ] && [ -f $USERDATA_PATH2/$FILENAME_B ]; then
			x=$FILENAME_B
			
		elif [ $ID10 == '"C"' ] && [ -f $USERDATA_PATH2/$FILENAME_C ]; then
			x=$FILENAME_C
		
		elif [ $ID10 == '"D"' ] && [ -f $USERDATA_PATH2/$FILENAME_D ]; then
			x=$FILENAME_D
		
		else
			echo INVALID ID10 / FILE IS MISSING - COPY ABORT!
		fi
		
		if [ $x != "" ]; then
			cp -f $FILE1_PATH/$x $FILE2_PATH/$FILENAME
			chmod +x $FILE2_PATH/$FILENAME
			PERMISSION2=`ls -l $FILE2_PATH/$FILENAME | awk {'print $1'}`
			echo COPY: $x - $PERMISSION1 -'>' $PERMISSION2
		
		fi
	fi
	}
	
	KEYMAPS_PATH=$HOME/.kodi/userdata/keymaps
	KEYMAPS_PATH2=$HOME/.kodi/addons/skin.htpt/specials/scripts/copy/keymaps
	cp $KEYMAPS_PATH2/* $KEYMAPS_PATH/
	
	{ ## CustomGUI
	if [ $CustomGUI != '"true"' ]; then
		$HOME/.kodi/addons/skin.htpt/specials/scripts/copygui.sh
		#$HOME/.kodi/addons/service.htpt/specials/scripts/copyfix.sh
		FILENAME=sources.xml
	
		if [ ! -f $CUSTOM_PATH/userdata/$FILENAME ]; then
			FILE1_PATH=$USERDATA_PATH2
			FILE2_PATH=$USERDATA_PATH
			PERMISSION1=`ls -l $FILE2_PATH/$FILENAME | awk {'print $1'}`
			cp -f $FILE1_PATH/$FILENAME $FILE2_PATH/$FILENAME
			chmod +x $FILE2_PATH/$FILENAME
			PERMISSION2=`ls -l $FILE2_PATH/$FILENAME | awk {'print $1'}`
			echo COPY: $FILENAME - $PERMISSION1 -'>' $PERMISSION2
		fi
		
	else
		echo CustomGUI IS TRUE
	fi
	}
	
	sleep 2
fi
