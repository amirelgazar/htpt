#!/bin/bash
SETTINGS=$HOME/.kodi/userdata/addon_data/plugin.video.genesis/settings.xml

###VAR SWITCHABLE###
AUTOPLAY='"autoplay" value='
AUTOPLAYLIBRARY='"autoplay_library" value='

###VAR FIX###
CHECKLIBRARY='"check_library" value='
DOWNLOADS='"downloads" value='
HOSTSELECT='"host_select" value='
IMDBUSER='"imdb_user" value='
#META='"meta" value=' ###REMOVED###
MOVIELIBRARY='"movie_library" value='
PLAYHD='"play_hd" value='
RESUMEPLAYBACK='"resume_playback" value='
ROOTMOVIES='"root_movies" value='
ROOTEPISODESTRAKT='"root_episodes_trakt" value='
ROOTEPISODES='"root_episodes" value='
ROOTCALENDAR='"root_calendar" value='
SERVICEINTERVAL='"service_interval" value='
SERVICELIMIT='"service_limit" value='
SERVICEUPDATE='"service_update" value='
SUBLANG1='"sublang1" value='
SUBLANG2='"sublang2" value='
SUBTITLES='"subtitles" value='
TVLIBRARY='"tv_library" value='
UPDATELIBRARY='"update_library" value='
WATCHEDLIBRARY='"watched_library" value='
#WATCHEDMETAHANDLER='"watched_metahandler" value=' ###REMOVED###
#WATCHEDSYNC='"watched_sync" value=' ###REMOVED###
WATCHEDTRAKT='"watched_trakt" value='

###VAR GENERAL###
E='""'
T='"true"'
F='"false"'
EN='"English"'
HE='"Hebrew"'
TVPATH='"special://userdata/library/tvshows/"'
MOVIEPATH='"special://userdata/library/movies/"'
DOWNLOADSPATH='"special://userdata/library/downloads/"'
IMDBSTRING='"ur42807646"'
ALL='"[^ ]*"'
NUM1='"1"'
NUM0='"0"'
IDTRIAL='"htptuser"'
IDPTRIAL='"ilovehtpt"'
TRIAL='"Trial"'
###VAR USERS###
FURKUSER='"furk_user" value='
FURKPASS='"furk_password" value='
MOVREELUSER='"movreel_user" value='
MOVREELPASS='"movreel_password" value='
REALDEDRIDUSER='"realdedrid_user" value='
REALDEDRIDPASS='"realdedrid_password" value='
TRACKTUSER='"trakt_user" value='
TRACKTPASS='"trakt_password" value='

DATENOW=`(date +%F)`
DATENOW='"'$DATENOW'"'
###GET USER ID###
GUI='/storage/.kodi/userdata/guisettings.xml'
FIND1='>[^ ]*<' ###?###
FINDIN=$GUI
FINDWHAT='"skin.htpt.ID"'
FINDLINE=`find $FINDIN -type f -exec grep $FINDWHAT /dev/null {} \;`
FINDEXACT=`echo $FINDLINE | grep -o '>[^ ]*<' | sed 's/[<>]//g'`
ID='"'$FINDEXACT'"'
IDP='"gkalni"'
echo ID: $ID '('$FINDEXACT')'

###GET RealDebrid###
GUI='/storage/.kodi/userdata/guisettings.xml'
FIND1='>[^ ]*<' ###?###
FINDIN=$GUI
FINDWHAT='"skin.htpt.RealDebrid"'
FINDLINE=`find $FINDIN -type f -exec grep $FINDWHAT /dev/null {} \;`
FINDEXACT=`echo $FINDLINE | grep -o '>[^ ]*<' | sed 's/[<>]//g'`
REALDEBRID='"'$FINDEXACT'"'
echo RealDebrid: $REALDEBRID '('$FINDEXACT')'

###GET RealDebrid 2 ***MODIFIED###
FINDIN=$SETTINGS
FINDWHAT=$REALDEDRIDUSER
FINDLINE=`find $FINDIN -type f -exec grep $FINDWHAT /dev/null {} \;`
FINDEXACT=`echo $FINDLINE | grep -o 'value="[^ ]*"' | grep -o ="[^ ]*" | sed 's/["=]//g' `
REALDEBRID2='"'$FINDEXACT'"'
echo RealDebrid2: $REALDEBRID2 '('$FINDEXACT')'

###GET USER ID9###
GUI='/storage/.kodi/userdata/guisettings.xml'
FINDIN=$GUI
FINDWHAT='"skin.htpt.ID9"'
FINDLINE=`find $FINDIN -type f -exec grep $FINDWHAT /dev/null {} \;`
FINDEXACT=`echo $FINDLINE | grep -o '>[^ ]*<' | sed 's/[<>]//g'`
ID9='"'$FINDEXACT'"'
echo ID9: $ID9 '('$FINDEXACT')'

###GET USER ID2###
GUI='/storage/.kodi/userdata/guisettings.xml'
FINDIN=$GUI
FINDWHAT='"skin.htpt.ID2"'
FINDLINE=`find $FINDIN -type f -exec grep $FINDWHAT /dev/null {} \;`
FINDEXACT=`echo $FINDLINE | grep -o '>[^ ]*<' | sed 's/[<>]//g'`
ID2='"'$FINDEXACT'"'
echo ID2: $ID2 '('$FINDEXACT')'

###SED RealDebrid###
if [ $REALDEBRID == $T ] || [ $ID9 == $TRIAL ] || [ $ID2 == $DATENOW ]; then
	if [ `echo $REALDEBRID2 | grep 'htpt' ` ] && [ $ID != $REALDEBRID2 ] && [ $ID9 != $TRIAL ] && [ $ID2 != $DATENOW ]; then
		sed -i "s/$REALDEDRIDUSER$ALL/$REALDEDRIDUSER$ID/g" $SETTINGS
		sed -i "s/$REALDEDRIDPASS$ALL/$REALDEDRIDPASS$IDP/g" $SETTINGS
		echo REALDEBRID RESET '('$ID != $REALDEBRID2')'
	else
		if [ $ID9 == $TRIAL ] || [ $ID2 == $DATENOW ]; then
			sed -i "s/$REALDEDRIDUSER$ALL/$REALDEDRIDUSER$IDTRIAL/g" $SETTINGS
			sed -i "s/$REALDEDRIDPASS$ALL/$REALDEDRIDPASS$IDPTRIAL/g" $SETTINGS
			echo REALDEBRID TRIAL '('$ID9')' OR DATENOW '('$DATENOW')'
		else
			sed -i "s/$REALDEDRIDUSER$E/$REALDEDRIDUSER$ID/g" $SETTINGS
			sed -i "s/$REALDEDRIDPASS$E/$REALDEDRIDPASS$IDP/g" $SETTINGS
			echo REALDEBRID DEFAULT
		fi
		
	fi
else
	sed -i "s/$REALDEDRIDUSER$ALL/$REALDEDRIDUSER$E/g" $SETTINGS
	sed -i "s/$REALDEDRIDPASS$ALL/$REALDEDRIDPASS$E/g" $SETTINGS
	echo REALDEBRID NONE
fi

###SED USERS###
sed -i "s/$FURKUSER$E/$FURKUSER$ID/g" $SETTINGS
sed -i "s/$FURKPASS$E/$FURKPASS$IDP/g" $SETTINGS
sed -i "s/$MOVREELUSER$E/$MOVREELUSER$ID/g" $SETTINGS
sed -i "s/$MOVREELPASS$E/$MOVREELPASS$IDP/g" $SETTINGS
sed -i "s/$TRACKTUSER$ALL/$TRACKTUSER$ID/g" $SETTINGS
sed -i "s/$TRACKTPASS$ALL/$TRACKTPASS$IDP/g" $SETTINGS
###SED USERS REMOVE###
#sed -i "s/$TRACKTUSER$ALL/$TRACKTUSER$E/g" $SETTINGS
#sed -i "s/$TRACKTPASS$ALL/$TRACKTPASS$E/g" $SETTINGS

###SED FIX###
sed -i "s/$CHECKLIBRARY$F/$CHECKLIBRARY$T/g" $SETTINGS ###AVOID DUPLICATES ON###
sed -i "s|$DOWNLOADS$ALL|$DOWNLOADS$DOWNLOADSPATH|g" $SETTINGS ###FIXED PATH###
sed -i "s|$HOSTSELECT$ALL|$HOSTSELECT$NUM0|g" $SETTINGS ###HOST SELECTION WINDOW = DIALOG###
sed -i "s|$IMDBUSER$ALL|$IMDBUSER$IMDBSTRING|g" $SETTINGS ###FIXED###
sed -i "s|$MOVIELIBRARY$ALL|$MOVIELIBRARY$MOVIEPATH|g" $SETTINGS ###FIXED PATH###
sed -i "s/$PLAYHD$F/$PLAYHD$T/g" $SETTINGS ###DETAILS ON###
sed -i "s/$RESUMEPLAYBACK$F/$RESUMEPLAYBACK$T/g" $SETTINGS ###RESUME ON###
sed -i "s/$ROOTMOVIES$ALL/$ROOTMOVIES$NUM0/g" $SETTINGS ###ROOT LINKS OFF###
sed -i "s/$ROOTEPISODESTRAKT$ALL/$ROOTEPISODESTRAKT$NUM0/g" $SETTINGS ###ROOT LINKS OFF###
sed -i "s/$ROOTEPISODES$ALL/$ROOTEPISODES$NUM0/g" $SETTINGS ###ROOT LINKS OFF###
sed -i "s/$ROOTCALENDAR$ALL/$ROOTCALENDAR$NUM0/g" $SETTINGS ###ROOT LINKS OFF###
sed -i "s|$SERVICEINTERVAL$ALL|$SERVICEINTERVAL$NUM0|g" $SETTINGS ###AUTO UPDATE TIME = 2H###
sed -i "s/$SERVICELIMIT$T/$SERVICELIMIT$F/g" $SETTINGS ###ADD ONLY LAST SEASON (AUTO UPDATE) OFF###
sed -i "s/$SERVICEUPDATE$F/$SERVICEUPDATE$T/g" $SETTINGS ###AUTO UPDATE EPISODES ON###
sed -i "s|$SUBLANG1$ALL|$SUBLANG1$HE|g" $SETTINGS ###AUTO SUB = HEBREW###
sed -i "s|$SUBLANG2$ALL|$SUBLANG2$EN|g" $SETTINGS ###AUTO SUB = ENGLISH###
sed -i "s/$SUBTITLES$F/$SUBTITLES$T/g" $SETTINGS ###AUTO SUB ON###
sed -i "s|$TVLIBRARY$ALL|$TVLIBRARY$TVPATH|g" $SETTINGS ###FIXED PATH###
sed -i "s/$UPDATELIBRARY$F/$UPDATELIBRARY$T/g" $SETTINGS ###FIXED PATH###
sed -i "s/$WATCHEDLIBRARY$F/$WATCHEDLIBRARY$T/g" $SETTINGS ###MARK AS WATCHED ON###
sed -i "s/$WATCHEDTRAKT$F/$WATCHEDTRAKT$T/g" $SETTINGS ###MARK AS WATCHED ON###
#sed -i "s/$META$F/$META$T/g" $SETTINGS ###METADATA ON??? ###REMOVED###
#sed -i "s/$WATCHEDMETAHANDLER$F/$WATCHEDMETAHANDLER$T/g" $SETTINGS ###REMOVED###
#sed -i "s/$WATCHEDSYNC$F/$WATCHEDSYNC$T/g" $SETTINGS ###REMOVED###

CACHE=$HOME/.kodi/userdata/addon_data/plugin.video.genesis/cache.db
rm -f $CACHE