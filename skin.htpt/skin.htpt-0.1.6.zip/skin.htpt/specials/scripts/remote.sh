#!/bin/bash
SKIN_PATH=$HOME/.kodi/addons/skin.htpt
REMOTES_PATH=$SKIN_PATH/specials/scripts/remotes
REMOTE_FILE=samsung
REMOTE_TYPE=nec,rc-6

ir-keytable -p $REMOTE_TYPE -w $REMOTES_PATH/$REMOTE_FILE -D 700 -P 200