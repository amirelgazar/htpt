#!/bin/bash

pgrep kodi.bin | xargs kill -SIGSTOP
#Uncomment this below if you have any issues

#$ADDON_DIR/bin/retroarch -c $ADDON_FILES/config/retroarch.cfg $EXTRAFLAG -L $ADDON_CORES/$1_libretro.so "$2" &

while [ pgrep kodi.bin | xargs kill -SIGSTOP ];do
    usleep 200000
done;
#systemctl start xbmc.service
pgrep kodi.bin | xargs kill -SIGCONT