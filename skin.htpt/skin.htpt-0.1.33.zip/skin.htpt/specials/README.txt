HTPT INSTRUCTIONS:
transfer media files to this folder!