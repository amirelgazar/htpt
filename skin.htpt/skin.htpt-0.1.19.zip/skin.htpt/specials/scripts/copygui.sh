#!/bin/bash
SETTINGS=$HOME/.kodi/userdata/guisettings.xml

###VAR GENERAL###
E='<'
T='true<'
F='false<'
ALL='[^ ]*<'
NUM0='0<'
NUM1='1<'
NUM2='2<'
NUM3='3<'
NUM4='4<'
NUM5='5<'
HTPT='HTPT<'
SKINDEFAULT='SKINDEFAULT<'
###VAR GENERAL###
ENABLEJOYSTICK='<enablejoystick>'
ENABLEMOUSE='<enablemouse>'
HTTPPROXYPORT='<httpproxyport>'
HTTPPROXYPORT2='8080<'
WEBSERVERPORT='<webserverport>'
WEBSERVERNAME='<webserverusername>'
DEVICENAME='<devicename>'
WEBSERVER='<webserver>'
WEBSERVERPASSWORD='<webserverpassword>'
###SET GENERAL###
sed -i "s/$ENABLEJOYSTICK$F/$ENABLEJOYSTICK$T/g" $SETTINGS
sed -i "s/$ENABLEMOUSE$T/$ENABLEMOUSE$F/g" $SETTINGS
sed -i "s/$HTTPPROXYPORT$ALL/$HTTPPROXYPORT$HTTPPROXYPORT2/g" $SETTINGS
sed -i "s/$WEBSERVERPORT$ALL/$WEBSERVERPORT$HTTPPROXYPORT2/g" $SETTINGS
sed -i "s/$WEBSERVERNAME$ALL/$WEBSERVERNAME$HTPT/g" $SETTINGS
sed -i "s/$DEVICENAME$ALL/$DEVICENAME$HTPT/g" $SETTINGS
sed -i "s/$WEBSERVERPASSWORD$ALL/$WEBSERVERPASSWORD$E/g" $SETTINGS

###VAR filelists###
ALLOWFILEDELETION='<allowfiledeletion>'
ALLOWFILEDELETION2='<allowfiledeletion default="true">'
IGNORETHEWHENSORTING='<ignorethewhensorting>'
SHOWADDSOURCEBUTTONS='<showaddsourcebuttons>'
SHOWEXTENSIONS='<showextensions>'
SHOWPARENTDIRITTEMS='<showparentdiritems>'
SHOWHIDDEN='<showhidden>'

###SET filelists###
sed -i "s/$ALLOWFILEDELETION2$F/$ALLOWFILEDELETION$T/g" $SETTINGS
sed -i "s/$IGNORETHEWHENSORTING$F/$IGNORETHEWHENSORTING$T/g" $SETTINGS ###Allows for certain tokens to be ignored during sort operations. For example, with this option enabled, "The Simpsons" would simply be sorted as "Simpsons".###
sed -i "s/$SHOWADDSOURCEBUTTONS$F/$SHOWADDSOURCEBUTTONS$T/g" $SETTINGS ###Enables showing the add source button from root sections of the user interface.
sed -i "s/$SHOWEXTENSIONS$F/$SHOWEXTENSIONS$T/g" $SETTINGS ###Determines the display of the extensions on media files. For example, "You Enjoy Myself.mp3" would be simply be displayed as "You Enjoy Myself".
sed -i "s/$SHOWPARENTDIRITTEMS$F/$SHOWPARENTDIRITTEMS$T/g" $SETTINGS ###Determines the display of the parent folder icon (..).
sed -i "s/$SHOWHIDDEN$T/$SHOWHIDDEN$F/g" $SETTINGS ###Shows hidden files and directories.

###VAR lookandfeel###
SOUNDSKIN='<soundskin>'

###SET lookandfeel###
sed -i "s/$SOUNDSKIN$ALL/$SOUNDSKIN$SKINDEFAULT/g" $SETTINGS ###Allows you to select or disable the sound scheme used in the User Interface. ###Cause Bug - no sound while playing games!

###VAR audiooutput###
STREAMSILENCE='<streamsilence>'
STREAMSILENCE2='<streamsilence default="true">'

###VAR audiooutput2###
GUISOUNDMODE='<guisoundmode>'
GUISOUNDMODE2='<guisoundmode default="true">'

###SET audiooutput###
sed -i "s/$GUISOUNDMODE$ALL/$GUISOUNDMODE$NUM0/g" $SETTINGS
sed -i "s/$GUISOUNDMODE2$ALL/$GUISOUNDMODE$NUM0/g" $SETTINGS
sed -i "s/$STREAMSILENCE$ALL/$STREAMSILENCE$NUM0/g" $SETTINGS
sed -i "s/$STREAMSILENCE2$ALL/$STREAMSILENCE$NUM0/g" $SETTINGS


###VAR VIDEOLIBRARY###
GROUPMOVIESETS='<groupmoviesets>'
SHOWUNWATCHEDPLOTS='<showunwatchedplots>'
UPDATEONSTARTUP='<updateonstartup>'
FLATTENTVSHOWS='<flattentvshows>'
BACKGROUNDUPDATE='<backgroundupdate>'

###SED VIDEOLIBRARY###
sed -i "s/$GROUPMOVIESETS$F/$GROUPMOVIESETS$T/g" $SETTINGS
sed -i "s/$SHOWUNWATCHEDPLOTS$F/$SHOWUNWATCHEDPLOTS$T/g" $SETTINGS
sed -i "s/$UPDATEONSTARTUP$T/$UPDATEONSTARTUP$F/g" $SETTINGS
sed -i "s/$FLATTENTVSHOWS$ALL/$FLATTENTVSHOWS$NUM1/g" $SETTINGS
sed -i "s/$BACKGROUNDUPDATE$T/$BACKGROUNDUPDATE$F/g" $SETTINGS

###VAR pvrmanager###
SYNCCHANNELGROUPS='<syncchannelgroups>'
PLAYMINIMIZED='<playminimized>'
PREVENTUPDATESWHILEPLAYINGTV='<preventupdateswhileplayingtv>'
PREVENTUPDATESWHILEPLAYINGTV2='<preventupdateswhileplayingtv default="true">'
HIDENOINFOAVAILABLE='<hidenoinfoavailable>'
IGNOREDBFORCLIENT='<ignoredbforclient>'
SELECTACTION='<selectaction>'
DAYSTODISPLAY='<daystodisplay>'
DAYSTODISPLAY2='<daystodisplay default="true">'
STARTLAST='<startlast>'
###SED pvrmanager###
sed -i "s/$SYNCCHANNELGROUPS$F/$SYNCCHANNELGROUPS$T/g" $SETTINGS
sed -i "s/$PLAYMINIMIZED$F/$PLAYMINIMIZED$T/g" $SETTINGS
sed -i "s/$PREVENTUPDATESWHILEPLAYINGTV2$F/$PREVENTUPDATESWHILEPLAYINGTV$T/g" $SETTINGS
sed -i "s/$HIDENOINFOAVAILABLE$F/$HIDENOINFOAVAILABLE$T/g" $SETTINGS 
sed -i "s/$IGNOREDBFORCLIENT$T/$IGNOREDBFORCLIENT$F/g" $SETTINGS ###DONT USE DATEBASE EPG###
sed -i "s/$SELECTACTION$ALL/$SELECTACTION$NUM2/g" $SETTINGS ###DEFAULT ACTION ON TVGUIDE###
sed -i "s/$DAYSTODISPLAY$ALL/$DAYSTODISPLAY$NUM2/g" $SETTINGS ###TOTAL DAYS IN TVGUIDE###
sed -i "s/$DAYSTODISPLAY2$ALL/$DAYSTODISPLAY$NUM2/g" $SETTINGS ###TOTAL DAYS IN TVGUIDE###
sed -i "s/$STARTLAST$ALL/$STARTLAST$NUM0/g" $SETTINGS ###LAUNCH LAST CHANNEL ON STARTUP###


###VAR VIDEOSCREEN###
VSYNC='<vsync>'
SCREENMODE='<screenmode>'
SCREENMODE2='00192001080060.00000pstd<'
RESOLUTION='<resolution>'
RESOLUTION2='18<'
###SED VIDEOSCREEN###
sed -i "s/$VSYNC$ALL/$VSYNC$NUM2/g" $SETTINGS
sed -i "s/$SCREENMODE$ALL/$SCREENMODE$SCREENMODE2/g" $SETTINGS
sed -i "s/$RESOLUTION$ALL/$RESOLUTION$RESOLUTION2/g" $SETTINGS

###VAR SUBTITLES1###
TV='<tv>'
MOVIE='<movie>'
PAUSEONSEARCH='<pauseonsearch default="true">'
LANGUAGES='<languages>'
LANGUAGES2='English (US),Hebrew'
DOWNLOADFIRST='downloadfirst default="true">'

###VAR SUBTITLES2###
SUBCENTER='service.subtitles.subscenter<'
OPENSUBTITLES='service.subtitles.opensubtitles<'
SUBTITLES='service.subtitles.subtitle<'
TOREC='service.subtitles.torec<'
PAUSEONSEARCH2='<pauseonsearch>'
HEBREW='Hebrew'
ENGLISH='English (US)'

###SED SUBTITLES###
sed -i "s/$MOVIE$ALL/$MOVIE$SUBCENTER/g" $SETTINGS #MOVIE MAIN
sed -i "s/$TV$ALL/$TV$SUBCENTER/g" $SETTINGS #TV MAIN
#sed -i "s/$MOVIE$ALL/$MOVIE$OPENSUBTITLES/g" $SETTINGS #MOVIE SECONDARY
#sed -i "s/$TV$ALL/$TV$OPENSUBTITLES/g" $SETTINGS #TV SECONDARY
#sed -i "s/$PAUSEONSEARCH$T/$PAUSEONSEARCH2$F/g" $SETTINGS #PAUSE ON SEARCH (OFF)
sed -i "s/$PAUSEONSEARCH2$F/$PAUSEONSEARCH$T/g" $SETTINGS #PAUSE ON SEARCH (ON)

###GET USER SubHebOnly###
GUI='/storage/.kodi/userdata/guisettings.xml'
FIND1='>[^ ]*<' ###?###
FINDIN=$GUI
FINDWHAT='"skin.htpt.SubHebOnly"'
FINDLINE=`find $FINDIN -type f -exec grep $FINDWHAT /dev/null {} \;`
FINDEXACT=`echo $FINDLINE | grep -o '>[^ ]*<' | sed 's/[<>]//g'`
SUBHEBONLY='"'$FINDEXACT'"'
echo SUBHEBONLY: $SUBHEBONLY '('$FINDEXACT')'

if [ $SUBHEBONLY == '"true"' ]; then
	echo LANGUAGE HEBREW ONLY! 
	sed -i "s/$LANGUAGES$LANGUAGES2/$LANGUAGES$HEBREW/g" $SETTINGS #LANGUAGE HEBREW ONLY!
fi

###GET USER ID10###
GUI='/storage/.kodi/userdata/guisettings.xml'
FIND1='>[^ ]*<' ###?###
FINDIN=$GUI
FINDWHAT='"skin.htpt.ID10"'
FINDLINE=`find $FINDIN -type f -exec grep $FINDWHAT /dev/null {} \;`
FINDEXACT=`echo $FINDLINE | grep -o '>[^ ]*<' | sed 's/[<>]//g'`
ID10='"'$FINDEXACT'"'
echo ID10: $ID10 '('$FINDEXACT')'


if [ $ID10 == '"A"' ]; then
	###INTEL NUC 2820###
	###VAR VIDEO ACCELERATION 1###
	RENDERMETHOD='<rendermethod>'
	HQSCALERS='<hqscalers>'
	DECODINGMETHOD='<decodingmethod>'
	USEVAAPI='<usevaapi>'
	USEVAAPIMEPG2='<usevaapimpeg2>'
	USEVAAPIMEPG4='<usevaapimpeg4>'
	USEVAAPIVC1='<usevaapivc1 default="true">'
	PREFERVAAPIRENDER='<prefervaapirender>'
	
	###VAR VIDEO ACCELERATION 2###
	USEVAAPIVC1_='<usevaapivc1>'
	
	###SED VIDEO ACCELERATION###
	#sed -i "s/$RENDERMETHOD$ALL/$RENDERMETHOD$NUM0/g" $SETTINGS #RENDER METHOD
	#sed -i "s/$DECODINGMETHOD$NUM0/$DECODINGMETHOD$NUM1/g" $SETTINGS #DECODING METHOD
	#sed -i "s/$USEVAAPI$F/$USEVAAPI$T/g" $SETTINGS #ALLOW VAAPI
	#sed -i "s/$USEVAAPIMEPG2$F/$USEVAAPIMEPG2$T/g" $SETTINGS #MEPG2
	#sed -i "s/$USEVAAPIMEPG4$F/$USEVAAPIMEPG4$T/g" $SETTINGS #MEPG4
	#sed -i "s/$USEVAAPIVC1$F/$USEVAAPIVC1_$T/g" $SETTINGS #VC1
	#sed -i "s/$PREFERVAAPIRENDER$F/$PREFERVAAPIRENDER$T/g" $SETTINGS #PREFER VAAPI

fi