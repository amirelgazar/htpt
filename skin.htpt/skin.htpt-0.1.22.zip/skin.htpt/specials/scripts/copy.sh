#!/bin/bash

DATENOW=`(date +%F)`
#echo $DATENOW

###GET USER ID###
GUI='/storage/.kodi/userdata/guisettings.xml'
FIND1='>[^ ]*<' ###?###
FINDIN=$GUI
FINDWHAT='"skin.htpt.ID"'
FINDLINE=`find $FINDIN -type f -exec grep $FINDWHAT /dev/null {} \;`
FINDEXACT=`echo $FINDLINE | grep -o '>[^ ]*<' | sed 's/[<>]//g'`
ID=$FINDEXACT
#echo ID: $ID

###GET USER ID10###
GUI='/storage/.kodi/userdata/guisettings.xml'
FIND1='>[^ ]*<' ###?###
FINDIN=$GUI
FINDWHAT='"skin.htpt.ID10"'
FINDLINE=`find $FINDIN -type f -exec grep $FINDWHAT /dev/null {} \;`
FINDEXACT=`echo $FINDLINE | grep -o '>[^ ]*<' | sed 's/[<>]//g'`
ID10=$FINDEXACT
#echo ID10: $ID10

LOGFILE='/storage/copy.log'

exec 3>&1 4>&2
trap 'exec 2>&4 1>&3' 0 1 2 3
exec 1>$LOGFILE 2>&1

echo ----------------------------------------
echo MODEL: $ID10   '|'   DATE: $DATENOW   '|'   USERID: $ID
echo ----------------------------------------

USERDATA_PATH=$HOME/.kodi/userdata
USERDATA_PATH2=$HOME/.kodi/addons/skin.htpt/specials/scripts/copy/userdata
USERDATA_PATH3=$HOME/.kodi/userdata/addon_data/skin.htpt/userdata

if [ ! -d "$USERDATA_PATH3" ]; then
	echo CREATING USERDATA_PATH3
	mkdir -p $USERDATA_PATH3
fi

VALIDATION2='"skin.htpt.VALIDATION2">'
T='true'
F='false'
RESET=$F
VALIDATION2=`cat $USERDATA_PATH/guisettings.xml | grep -i $VALIDATION2$F | wc -l`
GUISETTINGS_FILE_CON1=`cat $USERDATA_PATH/guisettings.xml | grep -i "<skin>skin.htpt</skin>" | wc -l`
GUISETTINGS_FILE2_CON1=`cat $USERDATA_PATH3/guisettings.xml | grep -i "<skin>skin.htpt</skin>" | wc -l`
GUISETTINGS_FILE3_CON1=`cat $USERDATA_PATH3/guisettings2.xml | grep -i "<skin>skin.htpt</skin>" | wc -l`

###GET CustomGUI###
GUI='/storage/.kodi/userdata/guisettings.xml'
FIND1='>[^ ]*<' ###?###
FINDIN=$GUI
FINDWHAT='"skin.htpt.CustomGUI"'
FINDLINE=`find $FINDIN -type f -exec grep $FINDWHAT /dev/null {} \;`
FINDEXACT=`echo $FINDLINE | grep -o '>[^ ]*<' | sed 's/[<>]//g'`
CustomGUI='"'$FINDEXACT'"'
#echo CustomGUI: $CustomGUI '('$FINDEXACT')'

###GET ID40###
GUI='/storage/.kodi/userdata/guisettings.xml'
FIND1='>[^ ]*<' ###?###
FINDIN=$GUI
FINDWHAT='"skin.htpt.ID40"'
FINDLINE=`find $FINDIN -type f -exec grep $FINDWHAT /dev/null {} \;`
FINDEXACT=`echo $FINDLINE | grep -o '>[^ ]*<' | sed 's/[<>]//g'`
ID40=$FINDEXACT
echo ID40: $ID40 '('$FINDEXACT')'

{ #SKIN_CHECK
echo
echo ----------------------------------------
PRINTPOINT=""
if [ $GUISETTINGS_FILE_CON1 -eq 0 ]; then
	echo Error: GUISETTINGS_FILE_CON1!
	PRINTPOINT=$PRINTPOINT\1
	if [ $GUISETTINGS_FILE2_CON1 -eq 0 ]; then
		PRINTPOINT=$PRINTPOINT\2
		if [ $GUISETTINGS_FILE3_CON1 -eq 0 ] && [ $ID40 == 'false' ]; then
			PRINTPOINT=$PRINTPOINT\3
			echo NO BACKUP FOUND!
		else
			PRINTPOINT=$PRINTPOINT\4
			echo Copy: $USERDATA_PATH3/guisettings2.xml '->' $USERDATA_PATH/guisettings.xml
			cp -f $USERDATA_PATH3/guisettings2.xml $USERDATA_PATH/guisettings.xml
			RESET=$T
		fi
	else
		PRINTPOINT=$PRINTPOINT\5
		echo Copy: $USERDATA_PATH3/guisettings.xml '->' $USERDATA_PATH/guisettings.xml
		cp -f $USERDATA_PATH3/guisettings.xml $USERDATA_PATH/guisettings.xml
		RESET=$T
	fi

	
else
	if [ $GUISETTINGS_FILE2_CON1 -eq 0 ]; then
		PRINTPOINT=$PRINTPOINT\6
		echo Error: GUISETTINGS_FILE2_CON1!!
	else
		PRINTPOINT=$PRINTPOINT\7
		echo Old Backup: guisettings2.xml
		cp -f $USERDATA_PATH3/guisettings.xml $USERDATA_PATH3/guisettings2.xml
	fi
	if [ $VALIDATION2 -eq 1 ]; then ###must run before startup.xml (autostart.sh)
		PRINTPOINT=$PRINTPOINT\8
		echo New Backup: guisettings.xml
		cp -f $USERDATA_PATH/guisettings.xml $USERDATA_PATH3/guisettings.xml
	else
		PRINTPOINT=$PRINTPOINT\9
		echo ERROR: VALIDATION2!!! CANT CREATE NEW BACKUP $VALIDATION2
	fi
fi
echo
echo SKIN_CHECK_LV: $PRINTPOINT   '|'   RESET: $RESET
echo ----------------------------------------
}

{ #SERVICE_CHECK
SKIN_PATH=/storage/.kodi/addons/skin.htpt
SKIN_FOLDER_SIZE=`du $SKIN_PATH/ -s | awk {'print $1'}`
SERVICE_PATH=/storage/.kodi/addons/service.htpt
echo
echo ----------------------------------------
PRINTPOINT=""

if [ ! -d "$SERVICE_PATH" ]; then
	PRINTPOINT=$PRINTPOINT\1
	SERVICE_FILE=`$HOME/.kodi/addons/packages/service.htpt*`
	ls $SERVICE_FILE -r | awk {'print $1'} | tee /storage/servicepackage.log
	SERVICE_FILE1=`head -1 servicepackage.log`
	SERVICE_FILE1_SIZE=`du $SERVICE_FILE1 -s | awk {'print $1'}`
	SERVICE_FILE2=`sed -n 2p servicepackage.log`
	SERVICE_FILE2_SIZE=`du $SERVICE_FILE2 -s | awk {'print $1'}`
	SERVICE_FILE3=`sed -n 3p servicepackage.log`
	SERVICE_FILE3_SIZE=`du $SERVICE_FILE3 -s | awk {'print $1'}`
	
	if [ $SERVICE_FILE1 -gt 10000 ] && [ -f SERVICE_FILE1 ]; then
		PRINTPOINT=$PRINTPOINT\2
		echo EXTRACTING SERVICE_FILE1
		unzip -o -q $SERVICE_FILE1 -d /storage/.kodi/addons/
		rm $SERVICE_FILE1
		
		PERMISSION1=`ls -l /storage/.kodi/addons/service.htpt/specials/scripts/ | awk {'print $1'}`
		chmod +x $SERVICE_PATH/specials/scripts/*
		PERMISSION2=`ls -l /storage/.kodi/addons/service.htpt/specials/scripts/ | awk {'print $1'}`
		echo EXTRACTING COMPLETE! $PERMISSION1 -'>' $PERMISSION2
		#RESET=$T
	else
		PRINTPOINT=$PRINTPOINT\3
		echo SERVICE_FILE NOT FOUNDS!
	fi

else
	PRINTPOINT=$PRINTPOINT\7
fi
echo
echo SERVICE_CHECK_LV: $PRINTPOINT
echo ----------------------------------------
}

{ ###SKIN
	ALL='[^ ]*<'
	SKIN='<skin>'
	SKIN2='<skin default="true">'
	SKINHTPT='skin.htpt<'
	###SED
	#sed -i "s/$SKIN$ALL/$SKIN$SKINHTPT/g" $SETTINGS
	#sed -i "s/$SKIN2$ALL/$SKIN$SKINHTPT/g" $SETTINGS
}
	
if [ $RESET == $T ]; then
	
	echo RESET = $RESET -'>' killall, sleep4 && sleep 2 && killall -9 kodi.bin && sed -i "s/$SKIN$ALL/$SKIN$SKINHTPT/g" $GUI && sed -i "s/$SKIN2$ALL/$SKIN$SKINHTPT/g" $GUI
	
else
	{ ## CustomGUI
	if [ $CustomGUI != '"true"' ]; then
		$HOME/.kodi/addons/skin.htpt/specials/scripts/copygui.sh
		#$HOME/.kodi/addons/service.htpt/specials/scripts/copyfix.sh
		
	else
		echo CustomGUI IS TRUE
	fi
	}
	
	sleep 1
fi
