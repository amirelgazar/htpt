service.xbmc.callbacks
======================

Addon service for XBMC to call user defined scripts on specific callbacks such as player starts, stops, etc.