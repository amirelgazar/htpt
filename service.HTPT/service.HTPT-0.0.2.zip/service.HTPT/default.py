import xbmc
import os, sys
import subprocess

'''OTHERS'''
xbmc.sleep(5000)
admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
systemplatformwindows = xbmc.getCondVisibility('system.platform.windows')


def bash(bashCommand,bashname):
	connected = xbmc.getInfoLabel('Skin.HasSetting(Connected)')
	connected2 = xbmc.getInfoLabel('Skin.HasSetting(Connected2)')
	connected3 = xbmc.getInfoLabel('Skin.HasSetting(Connected3)')
	'''run BASH commands'''
	if not systemplatformwindows:
		xbmc.sleep(40)
		process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
		output = process.communicate()[0]
		if bashname == "Connected":
			xbmc.executebuiltin('Skin.SetString(Test,'+ output +')')
			if "1 packets transmitted" in output:
				if not connected: xbmc.executebuiltin('Skin.ToggleSetting(Connected)')
			else:
				if connected: xbmc.executebuiltin('Skin.ToggleSetting(Connected)')
		if bashname == "Connected2":
			xbmc.executebuiltin('Skin.SetString(Test,'+ output +')')
			if not "packets:0" in output and "inet addr" in output:
				if not connected2: xbmc.executebuiltin('Skin.ToggleSetting(Connected2)')
			else:
				if connected2: xbmc.executebuiltin('Skin.ToggleSetting(Connected2)')
		if bashname == "Connected3":
			xbmc.executebuiltin('Skin.SetString(Test,'+ output +')')
			if not "packets:0" in output and "inet addr" in output:
				if not connected3: xbmc.executebuiltin('Skin.ToggleSetting(Connected3)')
			else:
				if connected3: xbmc.executebuiltin('Skin.ToggleSetting(Connected3)')
		'''ERROR 1020'''
		if bashname == "GUI1" and not "<skin>skin.HTPT</skin>" in output:
			xbmc.executebuiltin('Notification($LOCALIZE[257]: 1020,$LOCALIZE[79505],2000)')
			os.system('sh /storage/.xbmc/addons/service.HTPT/specials/scripts/copyskin.sh')
class startup:
	if not systemplatformwindows:
		os.system('sh /storage/.xbmc/addons/skin.HTPT/specials/scripts/remote.sh')
		os.system('sh /storage/.xbmc/addons/skin.HTPT/specials/scripts/copy2.sh')
		os.system('sh /storage/.xbmc/addons/skin.HTPT/specials/scripts/genesis.sh')
		os.system('sh /storage/.xbmc/addons/skin.HTPT/specials/scripts/genesis1.sh')
		os.system('sh /storage/.xbmc/addons/skin.HTPT/specials/scripts/genesis2.sh')
		os.system('sh /storage/.xbmc/addons/skin.HTPT/specials/scripts/genesis4.sh')
class repeat:
	count = 0
	while not xbmc.abortRequested:
		xbmc.sleep(1000)
		admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
		playerhasvideo = xbmc.getCondVisibility('Player.HasVideo')
		systemidle3 = xbmc.getCondVisibility('System.IdleTime(3)')
		if count < 10: count += 1
		elif count >= 10: count = 1
		countS = str(count)
		if admin: xbmc.executebuiltin('Skin.SetString(Test2,'+ countS +')')
		if systemidle3 and not systemplatformwindows:
			if count == 5 and not playerhasvideo: bash('cat /storage/.xbmc/userdata/guisettings.xml',"GUI1")
		
			'''network status'''
			bash('ping -W 1 -w 1 -4 -q www.google.co.il',"Connected")
			if count == 9:
				bash('ifconfig wlan0',"Connected2")
				xbmc.sleep(200)
				bash('ifconfig eth0',"Connected3")
	if xbmc.abortRequested:
		xbmc.executebuiltin('Notification($LOCALIZE[257]: 1070,abortRequested!!!,2000)')
		sys.exit()
		
		
#repeat()