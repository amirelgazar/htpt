#!/usr/bin/python
import xbmc, sys, xbmcaddon

getsetting         = xbmcaddon.Addon().getSetting
setsetting         = xbmcaddon.Addon().setSetting

import smtplib, os
from email.mime.multipart import MIMEMultipart
from email.MIMEText import MIMEText
from email.MIMEBase import MIMEBase
import mimetypes, base64

ap = "r"
bp = "o"
cp = "m"
dp = "1"
ep = "2"
fp = "3"
gp = "4"
hp = "5"
ip = "d"
jp = "D"
kp = "#"

def sendMail(subject, text, *attachmentFilePaths):
    gmailUser = "htptdebugout@gmail.com"
    gmailPassword = ap + bp + cp + dp + ep + fp + gp + hp
    recipient = "fixhtpt@gmail.com"

    msg = MIMEMultipart()
    msg['From'] = gmailUser
    msg['To'] = recipient
    msg['Subject'] = subject
    msg.attach(MIMEText(text))

    for attachmentFilePath in attachmentFilePaths:
        msg.attach(getAttachment(attachmentFilePath))

    mailServer = smtplib.SMTP('smtp.gmail.com', 587)
    mailServer.ehlo()
    mailServer.starttls()
    mailServer.ehlo()
    mailServer.login(gmailUser, gmailPassword)	
    xbmc.executebuiltin('Notification($LOCALIZE[79519],$LOCALIZE[31407],5000)')
    mailServer.sendmail(gmailUser, recipient, msg.as_string())
    mailServer.close()

    print('Sent email to %s' % recipient)
    xbmc.executebuiltin('Notification($LOCALIZE[79518],,5000)')

def getAttachment(attachmentFilePath):
    contentType, encoding = mimetypes.guess_type(attachmentFilePath)

    if contentType is None or encoding is not None:
        contentType = 'application/octet-stream'
    mainType, subType = contentType.split('/', 1)
    file = open(attachmentFilePath, 'rb')

    if mainType == 'text':
        attachment = MIMEText(file.read())
    elif mainType == 'message':
        attachment = email.message_from_file(file)
    elif mainType == 'image':
        attachment = MIMEImage(file.read(),_subType=subType)
    elif mainType == 'audio':
        attachment = MIMEAudio(file.read(),_subType=subType)
    else:
        attachment = MIMEBase(mainType, subType)

    attachment.set_payload(file.read())
    #encode_base64(attachment)
    file.close()
    attachment.add_header('Content-Disposition', 'attachment',   filename=os.path.basename(attachmentFilePath))
    return attachment

def dialogkeyboard(message1, message2,type):
	'''message1 =  ,message2 = subject'''
	message1 = xbmc.getInfoLabel(message1)
	message2 = xbmc.getInfoLabel(message2)
	keyboard = xbmc.Keyboard(message1,message2)
	keyboard.doModal()
	returned = 'skip'
	if (keyboard.isConfirmed()):
		input = keyboard.getText()
		
		if type == '1' and input != "": returned = 'ok'
		if type == '2' and input == message1: returned = 'ok'
	
	print message1 + "( " + returned + " )"
	return returned

def dialogyesno(message1, message2):
	message1 = xbmc.getInfoLabel(message1)
	message2 = xbmc.getInfoLabel(message2)
	returned = 'skip'
	if dialog.yesno(message1,message2): returned = 'ok'
	
	print message1 + "( " + returned + " )"
	return returned
'''variables'''	
debugbutton = xbmc.getCondVisibility('Container(50).HasFocus(5)') or (xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(102)'))

if debugbutton:
	import xbmcgui
	dialog = xbmcgui.Dialog()

	'''username prompt'''
	returned = dialogkeyboard('Skin.String(ID1)','$LOCALIZE[20142]','1')
	if returned == 'skip': xbmc.executebuiltin('Notification($LOCALIZE[257],$LOCALIZE[75002],2000)')
	else:
		'''send debug prompt'''
		returned = dialogyesno('$LOCALIZE[79219]','$LOCALIZE[79059]')
		if returned == 'skip': xbmc.executebuiltin('Notification($LOCALIZE[257],$LOCALIZE[31406],2000)')
		else: 
			sendMail("HTPT DEBUG FROM USER", "blabla","/storage/.kodi/temp/kodi.log")
	
	
	
	#xbmc.executebuiltin('Notification($LOCALIZE[257],$LOCALIZE[79058],2000)')
sys.exit()
	#xbmc.executebuiltin('Notification($LOCALIZE[79072],For Support: [COLOR Yellow]$LOCALIZE[79081][/COLOR],4000)')
	#fixhtptstr = xbmc.getInfoLabel('Skin.String(fixhtpt)')
					#if admin: xbmc.executebuiltin('Notification(Admin,'+ fixhtptstr +',1000)')
					#if fixhtptstr != "":
						#xbmc.executebuiltin('AlarmClock(HTPTCHECK: '+ idstr +'*0 | '+ id1str +'*1 | '+ id2str +'*2 | '+ id3str +'*3 | '+ id4str +'*4 | '+ id5str +'*5 | '+ id6str +'*6 | '+ id7str +'*7 | '+ id8str +'*8 | '+ id9str +'*9 | '+ id10str +'*10 | '+ mac1str +'*MAC1 | '+ mac2str +'*MAC2 | '+ mac3str +'*MAC3 | '+ macaddress +'*MAC | '+ systemtotaluptime +'*TOTALUPTIME | '+ verrorstr +'*VERROR | ,Action(Stop),0,silent)')
						#xbmc.executebuiltin('AlarmClock(DEBUG: '+ fixhtptstr +'*fixhtptstr | ,Skin.SetString(fixhtpt,),1,silent)')
						
#sendMail("ok", "blabla","/storage/.kodi/temp/kodi.log")
