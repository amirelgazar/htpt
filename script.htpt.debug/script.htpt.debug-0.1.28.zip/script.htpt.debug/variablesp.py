'''------------------------------
---shared_variables--------------
------------------------------'''
import xbmcaddon, sys, os

'''------------------------------
---script.htpt.debug-2-----------
------------------------------'''
ap = "r"
bp = "o"
cp = "m"
dp = "1"
ep = "2"
fp = "3"
gp = "4"
hp = "5"
hi = "6"
ip = "d"
jp = "D"
kp = "#"

sendtostr = "htptdebugout@gmail.com"
sendtostr2 = "htptdebugout2@gmail.com"
recipientstr = "fixhtpt@gmail.com"
mystr = ap + bp + cp + dp + ep + fp + gp + hp + hi
mystr2 = ap + bp + cp + dp + ep + fp + gp + hp