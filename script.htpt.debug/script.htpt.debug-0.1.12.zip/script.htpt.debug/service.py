import xbmc, os, subprocess, sys
import xbmcgui, xbmcaddon

from variables import *
from modules import *


def debugtrigger(admin, hasinternet):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	Time_Start = getsetting('Time_Start')
	Time_Pass = getsetting('Time_Pass')
	Time_PassN = int(Time_Pass)
	'''---------------------------'''

	if (hasinternet and not systemplatformwindows) or (systemplatformwindows and idstr == "finalmakerr" and admin):
		'''------------------------------
		---VARIABLES-/-HAS-INTERNET------
		------------------------------'''
		debug10 = getsetting('debug10')
		debug12 = getsetting('debug12')
		debug13 = getsetting('debug13')
		debug14 = getsetting('debug14')
		debug15 = getsetting('debug15')
		debug16 = getsetting('debug16')
		debug17 = getsetting('debug17')
		debug19 = getsetting('debug19')
		#xbmc.sleep(500)
		'''---------------------------'''
		verrorstr = xbmc.getInfoLabel('$VAR[VERROR]')
		startupW = xbmc.getCondVisibility('Window.IsVisible(Startup.xml)')
		'''---------------------------'''
		
		if Time_PassN > 0:
			'''------------------------------
			---TRIGGERS----------------------
			------------------------------'''
			if debug12 == 'true':
				'''------------------------------
				---STARTUP-----------------------
				------------------------------'''
				setsetting_custom1('script.htpt.debug','debug12',"false")
				setsetting_custom1('script.htpt.debug','curtrigger',"12")
				xbmc.executebuiltin('RunScript(script.htpt.debug)')
				'''---------------------------'''
			elif debug13 == 'true':
				'''------------------------------
				---unauthorized------------------
				------------------------------'''
				setsetting_custom1('script.htpt.debug','debug13',"false")
				setsetting_custom1('script.htpt.debug','curtrigger',"13")
				xbmc.executebuiltin('RunScript(script.htpt.debug)')
				'''---------------------------'''
			elif debug14 == 'true' and Time_PassN > 12 and startupW:
				'''------------------------------
				---UpTime-12-&-StartUp-----------
				------------------------------'''
				setsetting_custom1('script.htpt.debug','debug14',"false")
				setsetting_custom1('script.htpt.debug','curtrigger',"14")
				xbmc.executebuiltin('RunScript(script.htpt.debug)')
				'''---------------------------'''
			elif debug15 == 'true' and Time_PassN > 120:
				'''------------------------------
				---UpTime-120--------------------
				------------------------------'''
				setsetting_custom1('script.htpt.debug','debug15',"false")
				setsetting_custom1('script.htpt.debug','curtrigger',"15")
				xbmc.executebuiltin('RunScript(script.htpt.debug)')
				'''---------------------------'''
			elif debug16 == 'true' and Time_PassN > 5 and verrorstr != '7000' and verrorstr != 'NONE':
				'''------------------------------
				---verrorstr-!=-7000-&-NONE------
				------------------------------'''
				setsetting_custom1('script.htpt.debug','debug16',"false")
				setsetting_custom1('script.htpt.debug','curtrigger',"16")
				xbmc.executebuiltin('RunScript(script.htpt.debug)')
				'''---------------------------'''
			elif debug17 == 'true' and Time_PassN > 60:
				'''------------------------------
				---UpTime-60---------------------
				------------------------------'''
				setsetting_custom1('script.htpt.debug','debug17',"false")
				setsetting_custom1('script.htpt.debug','curtrigger',"17")
				xbmc.executebuiltin('RunScript(script.htpt.debug)')
				'''---------------------------'''
			elif debug19 == 'true':
				'''------------------------------
				---?----------------------
				------------------------------'''
				setsetting_custom1('script.htpt.debug','debug19',"false")
				setsetting_custom1('script.htpt.debug','curtrigger',"19")
				xbmc.executebuiltin('RunScript(script.htpt.debug)')
				'''---------------------------'''
				
		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		if Time_PassN == 0 and admin: print printfirst + "debugtrigger" + space2 + "Time_Pass" + space2 + Time_Pass + space3
		if admin: print printfirst + "debugtrigger" + space2 + "debug12" + space2 + debug12 + space3
		'''---------------------------'''
		
class main:
	'''------------------------------
	---STARTUP-----------------------
	------------------------------'''
	setTime_Start(admin)
	setsetting_custom1('script.htpt.debug','Time_Pass',"0")
	setsetting_custom1('script.htpt.debug','issue_description',"")
	addonsettings2('script.htpt.debug','debug10',"true",'debug12',"true",'debug13',"false",'debug14',"true",'debug15',"true")
	addonsettings2('script.htpt.debug','debug16',"true",'debug17',"true",'debug19',"false",'',"",'',"")
	if Date_Last != daynowS: pass
	'''---------------------------'''
	count = 0
	while 1 and not xbmc.abortRequested:
		'''------------------------------
		---SERVICE-LOOP------------------
		------------------------------'''
		count += 1
		xbmc.sleep(30000)
		'''---------------------------'''
		admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
		systeminternetstate = xbmc.getInfoLabel('System.InternetState')
		networkipaddress = xbmc.getInfoLabel('Network.IPAddress')
		connected = xbmc.getInfoLabel('Skin.HasSetting(Connected)')
		hasinternet = systeminternetstate != "" and networkipaddress != "" and (connected or systemplatformwindows)
		'''---------------------------'''
		debugtrigger(admin, hasinternet)
		'''---------------------------'''
		if count == 2:
			SetTime_Pass(admin)
			count = 0
			'''---------------------------'''