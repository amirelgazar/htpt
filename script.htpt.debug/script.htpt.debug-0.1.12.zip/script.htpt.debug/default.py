#!/usr/bin/python
import xbmc, sys, xbmcaddon

from variables import *
from modules import *

def subject(admin):
	'''subject'''
	subject = "UNKNOWN"
	if curtrigger == "":
		if debugbutton:
			'''------------------------------
			---HELP-WINDOW-------------------
			------------------------------'''
			subject = addonString(11) + space2 + idstr + "_" + " (" + service_call_no + ")"
			print printfirst + "subject: " + addonString(11).encode('utf-8') + space2 + idstr + " (" + service_call_no + ")"
			'''---------------------------'''
		elif myprograms and not systemplatformwindows and not admin:
			'''------------------------------
			---PROGRAMS-WINDOW---------------
			------------------------------'''
			subject = addonString(13) + space2 + idstr + "_" + " (" + unauthorized_no + ")"
			print printfirst + "subject: " + addonString(13).encode('utf-8') + space2 + idstr + " (" + unauthorized_no + ")"
			'''---------------------------'''
		elif custom1191 == "poweroff":
			'''------------------------------
			---POWEROFF----------------------
			------------------------------'''
			subject = addonString(18) + space2 + idstr + "_" + " (" + poweroff_no + ")"
			print printfirst + "subject: " + addonString(18).encode('utf-8')
			calculate('script.htpt.debug','poweroff_no','1')
			'''---------------------------'''
		elif Red_Done != "" and Red_LastDate != "":
			'''------------------------------
			---Red_Done----------------------
			------------------------------'''
			subject = addonString(62) + space2 + idstr + "_" + " (" + reddone_no + ")"
			print printfirst + "subject: " + addonString(62).encode('utf-8')
			'''---------------------------'''
		elif Fix_Done != "" and Fix_LastDate != "":
			'''------------------------------
			---Fix_Done----------------------
			------------------------------'''
			subject = addonString(63) + space2 + idstr + "_" + " (" + fixdone_no + ")"
			print printfirst + "subject: " + addonString(63).encode('utf-8')
			'''---------------------------'''
		else:
			if admin: notification("Debug Error","","",1000)
			print printfirst + space + "subject" + space2 + "Debug Error"
			'''---------------------------'''
	elif curtrigger != "":
		if curtrigger == '12':
			'''------------------------------
			---STARTUP-----------------------
			------------------------------'''
			subject = addonString(12) + space2 + idstr + "_" + space + Time_Start + space + " (" + startup_no + ")"
			print printfirst + "subject: " + addonString(12).encode('utf-8')
			calculate('script.htpt.debug','startup_no','1')
			'''---------------------------'''
		elif curtrigger == '13':
			'''------------------------------
			---unauthorized------------------
			------------------------------'''
			subject = addonString(13) + space2 + idstr + "_" + " (" + unauthorized_no + ")"
			print printfirst + "subject: " + addonString(13).encode('utf-8')
			calculate('script.htpt.debug','unauthorized_no','1')
			'''---------------------------'''
		elif curtrigger == '16':
			'''------------------------------
			---verrorstr-!=-7000-&-NONE------
			------------------------------'''
			verrorstr = xbmc.getInfoLabel('$VAR[VERROR]')
			subject = addonString(16) + space2 + idstr + "_" + verrorstr + " (" + error_no + ")"
			print printfirst + "subject: " + addonString(16).encode('utf-8')
			calculate('script.htpt.debug','error_no','1')
			'''---------------------------'''
		elif curtrigger == '14':
			'''------------------------------
			---UpTime-12-&-StartUp-----------
			------------------------------'''
			subject = addonString(14) + space2 + idstr + "_" + " (" + startup12_no + ")"
			print printfirst + "subject: " + addonString(14).encode('utf-8')
			calculate('script.htpt.debug','startup12_no','1')
			'''---------------------------'''
		elif curtrigger == '17':
			'''------------------------------
			---UpTime-60---------------------
			------------------------------'''
			subject = addonString(17) + space2 + idstr + "_" + " (" + uptime60_no + ")"
			print printfirst + "subject: " + addonString(17).encode('utf-8')
			setsetting_custom1('script.htpt.debug','Date_Last',datenowS)
			calculate('script.htpt.debug','uptime60_no','1')
			'''---------------------------'''
		elif curtrigger == '15':
			'''------------------------------
			---UpTime-120--------------------
			------------------------------'''
			subject = addonString(15) + space2 + idstr + "_" + " (" + uptime120_no + ")"
			print printfirst + "subject: " + addonString(15).encode('utf-8')
			calculate('script.htpt.debug','uptime120_no','1')
			'''---------------------------'''
		elif curtrigger == '19':
			'''------------------------------
			---Fix_Done----------------------
			------------------------------'''
			subject = addonString(19) + space2 + idstr + "_" + " (" + fixdone_no + ")"
			print printfirst + "subject: " + addonString(19).encode('utf-8')
			calculate('script.htpt.debug','fixdone_no','1')
			'''---------------------------'''
        #setsetting('curtrigger', "") ###KEEP SERVICE IN SYNC###
	returned = subject
	return returned

def content(admin):
	
	content = "UNKNOWN"
	if curtrigger == "":
		if debugbutton or issue_description != "":
			'''------------------------------
			---HELP-WINDOW-------------------
			------------------------------'''
			content = content1u + content2 + content3 + content4 + content5 + content20
			'''---------------------------'''
		elif myprograms and not systemplatformwindows and not admin:
			'''------------------------------
			---PROGRAMS-WINDOW---------------
			------------------------------'''
			content = content1 + content2 + content3 + content4 + content5 + content20
			'''---------------------------'''
		elif custom1191 == "poweroff":
			'''------------------------------
			---POWEROFF----------------------
			------------------------------'''
			content = content1 + content2 + content3 + content4 + content5
			'''---------------------------'''
		elif Red_Done != "" and Red_LastDate != "":
			'''------------------------------
			---Red_Done----------------------
			------------------------------'''
			content = content1r
			'''---------------------------'''
		elif Fix_Done != "" and Fix_LastDate != "":
			'''------------------------------
			---Fix_Done----------------------
			------------------------------'''
			content = content1f
			'''---------------------------'''	
	elif curtrigger != "":
		if curtrigger == '12':
			'''------------------------------
			---STARTUP-----------------------
			------------------------------'''
			content = content1 + content2 + content3 + content4 + content5 + content20
			'''---------------------------'''
		elif curtrigger == '13':
			'''------------------------------
			---unauthorized------------------
			------------------------------'''
			content = content1 + content2 + content3 + content4 + content5 + content20
			'''---------------------------'''
		elif curtrigger == '16':
			'''------------------------------
			---verrorstr-!=-7000-&-NONE------
			------------------------------'''
			content = content1 + content2 + content3 + content4 + content5 + content20
			'''---------------------------'''
		elif curtrigger == '14':
			'''------------------------------
			---UpTime-12-&-StartUp-----------
			------------------------------'''
			content = content1 + content2 + content3 + content4 + content5 + content20
			'''---------------------------'''
		elif curtrigger == '17':
			'''------------------------------
			---UpTime-60---------------------
			------------------------------'''
			content = content1 + content2 + content3 + content4 + content5 + content20
			'''---------------------------'''
		elif curtrigger == '15':
			'''------------------------------
			---UpTime-120--------------------
			------------------------------'''
			content = content1 + content2 + content3 + content4 + content5 + content20
			'''---------------------------'''
		elif curtrigger == '19':
			'''------------------------------
			---?----------------------
			------------------------------'''
			content = content1 + content2 + content3 + content4 + content5 + content20
			'''---------------------------'''

	returned = content
	return returned
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "content" + space2 + content
	'''---------------------------'''

if debugbutton and issue_description == "":
	'''------------------------------
	---DEBUG-BUTTON-1----------------
	------------------------------'''
	import xbmcgui
	dialog = xbmcgui.Dialog()
	
	'''username prompt'''
	returned = dialogkeyboard(id1str,idnamestr,0,'1','username',"0")
	if returned == 'skip': xbmc.executebuiltin('Notification($LOCALIZE[257],$LOCALIZE[75002],2000)')
	else:
		'''address prompt'''
		if address != "": returned = dialogkeyboard(address,id4namestr,0,'1','address',"0")
		else:
			returned = dialogkeyboard(id4str,id4namestr,0,'1','address',"0")
		if returned == 'skip': xbmc.executebuiltin('Notification($LOCALIZE[257],$LOCALIZE[75002],2000)')
		else:
			'''telephone prompt'''
			try:
				if int(telephone) > 010000000 and int(telephone) < 9999999999: returned = dialognumeric(0,id5namestr,telephone,"0","telephone")
				else:
					returned = dialognumeric(0,id5namestr,id5str,"0","telephone")
			except TypeError:
				xbmc.executebuiltin('Notification(1,1,1000)')
				returned = dialognumeric(0,id5namestr,"0","0","telephone")
				print printfirst + "dialognumeric " + "except TypeError (2)"
			if returned == 'skip': xbmc.executebuiltin('Notification($LOCALIZE[257],$LOCALIZE[75002],2000)')
			elif returned == 'skip0': xbmc.executebuiltin('Notification($LOCALIZE[257],$ADDON[script.htpt.debug 30],2000)')
			elif returned == 'ok':
				'''issue description'''
				returned = dialogkeyboard(issue_description,addonString(44).encode("utf-8"),0,'1','issue_description',"0")
				if returned == 'skip': xbmc.executebuiltin('Notification($LOCALIZE[257],$LOCALIZE[75002],2000)')
				else:
					'''send debug prompt'''
					returned = dialogyesno('$LOCALIZE[79219]','$LOCALIZE[79059]')
					if returned == 'skip': xbmc.executebuiltin('Notification($LOCALIZE[257],$LOCALIZE[31406],2000)')
					elif returned == 'ok':
						'''------------------------------
						---RERUN-SCRIPT-WITH-NEW-VAR-----
						------------------------------'''
						xbmc.executebuiltin('AlarmClock(rerundebug,RunScript(script.htpt.debug),00:00,silent)')
						sys.exit()
							
else:
	'''unknown'''
	subject = subject(admin)
	content = content(admin)
	returned = 'skip'
	if issue_description != "":
		'''------------------------------
		---DEBUG-BUTTON-2----------------
		------------------------------'''
		if not systemplatformwindows:
			#bash('rm -r /storage/.kodi/temp/htptlog.zip && sleep 1 && zip -j9 /storage/.kodi/temp/htptlog.zip /storage/.kodi/temp/kodi.log',"zip")
			#if returned == 'skip': xbmc.executebuiltin('Notification($LOCALIZE[257],COMPRESSED ZIP FAILED!,2000)')
			#else:
			returned = 'skip'
			returned = sendMail(subject, content1u, file1)
			sendMail(subject, content1u, file3)
		elif systemplatformwindows:
			returned = 'skip'
			returned = sendMail(subject, content, file1_w)
			sendMail(subject, content1u, file3_w)
			#sendMail(subject, content1u, guifilewindows)
		
	elif curtrigger != "":
		try:
			if curtrigger == '12':
				'''------------------------------
				---STARTUP-----------------------
				------------------------------'''
				if systemplatformwindows: returned = sendMail(subject, content, file2_w)
				elif not systemplatformwindows: returned = sendMail(subject, content, file2)
				'''---------------------------'''
			elif curtrigger == '13':
				'''------------------------------
				---unauthorized------------------
				------------------------------'''
				if systemplatformwindows: returned = sendMail(subject, content, file3_w)
				elif not systemplatformwindows: returned = sendMail(subject, content, file3)
				'''---------------------------'''
			elif curtrigger == '16':
				'''------------------------------
				---verrorstr-!=-7000-&-NONE------
				------------------------------'''
				if systemplatformwindows: returned = sendMail(subject, content, file1_w)
				elif not systemplatformwindows: returned = sendMail(subject, content, file1)
				'''---------------------------'''
			elif curtrigger == '14':
				'''------------------------------
				---UpTime-12-&-StartUp-----------
				------------------------------'''
				if systemplatformwindows: returned = sendMail(subject, content, file1_w)
				elif not systemplatformwindows: returned = sendMail(subject, content, file1)
				'''---------------------------'''
			elif curtrigger == '17':
				'''------------------------------
				---UpTime-60---------------------
				------------------------------'''
				if systemplatformwindows: returned = sendMail(subject, content, file1_w)
				elif not systemplatformwindows: returned = sendMail(subject, content, file1)
				'''---------------------------'''
			elif curtrigger == '15':
				'''------------------------------
				---UpTime-120--------------------
				------------------------------'''
				if systemplatformwindows: returned = sendMail(subject, content, file1_w)
				elif not systemplatformwindows: returned = sendMail(subject, content, file1)
				'''---------------------------'''
			elif curtrigger == '19':
				'''------------------------------
				---?----------------------
				------------------------------'''
				if systemplatformwindows: returned = sendMail(subject, content, file1_w)
				elif not systemplatformwindows: returned = sendMail(subject, content, file1)
				'''---------------------------'''
		except:
			setsetting_custom1('script.htpt.debug','debug' + curtrigger,"true")	
			'''---------------------------'''
			
	elif curtrigger == "":
		if myprograms and not systemplatformwindows and not admin:
			'''------------------------------
			---PROGRAMS-WINDOW---------------
			------------------------------'''
			if systemplatformwindows: returned = sendMail(subject, content, file1_w)
			elif not systemplatformwindows: returned = sendMail(subject, content, file1)
			'''---------------------------'''
		elif custom1191 == "poweroff":
			'''------------------------------
			---POWEROFF----------------------
			------------------------------'''
			if systemplatformwindows: returned = sendMail(subject, content, file1_w)
			elif not systemplatformwindows: returned = sendMail(subject, content, file1)
			'''---------------------------'''
		elif Red_Done != "" and Red_LastDate != "":
			'''------------------------------
			---Red_Done----------------------
			------------------------------'''
			if systemplatformwindows: returned = sendMail(subject, content, file1_w)
			elif not systemplatformwindows: returned = sendMail(subject, content, file1)
			'''---------------------------'''
		elif Fix_Done != "" and Fix_LastDate != "":
			'''------------------------------
			---Fix_Done----------------------
			------------------------------'''
			if systemplatformwindows: returned = sendMail(subject, content, file1_w)
			elif not systemplatformwindows: returned = sendMail(subject, content, file1)
			'''---------------------------'''
		else:
			'''------------------------------
			---USER-ACTION2------------------
			------------------------------'''
			if systemplatformwindows: returned = sendMail(subject, content, file1_w)
			elif not systemplatformwindows: returned = sendMail(subject, content, file1)
			'''---------------------------'''
			
	if returned != 'ok':
		'''------------------------------
		---PRINT-MAIL-FAILED------------
		------------------------------'''
		print printfirst + "Debug Failed!"
		
		if issue_description != "":
			returned = dialogyesno(addonString(37).encode('utf-8'),addonString(38).encode('utf-8'))
			if returned == 'ok': xbmc.executebuiltin('RunScript(script.htpt.debug)')
			else:
				xbmc.executebuiltin('Notification($LOCALIZE[257],$LOCALIZE[31406],2000)')
				setsetting('issue_description',"")
				'''---------------------------'''
	else:
		'''------------------------------
		---PRINT-MAIL-SUCUESS------------
		------------------------------'''
		print printfirst + "Debug Sent!" + space + curtrigger + space + issue_description
		setsetting('curtrigger', "")
		if issue_description != "":
			xbmc.sleep(1000)
			setsetting('issue_description',"")
			calculate('script.htpt.debug','service_call_no','1')
			dialogok('$LOCALIZE[79518]',addonString(10).encode('utf-8') + space + addonString(9).encode('utf-8') + space2 + service_call_no, addonString(41).encode('utf-8') + space2 + username,addonString(7).encode('utf-8') % (issue_description))
			'''---------------------------'''
		elif Red_Done != "" and Red_LastDate != "":
			xbmc.sleep(1000)
			setsetting_custom1('service.htpt.fix','Red_Done',"")
			#setsetting_custom1('service.htpt.fix','Red_LastDate',"")
			calculate('script.htpt.debug','reddone_no','1')
			'''---------------------------'''
		elif Fix_Done != "" and Fix_LastDate != "":
			xbmc.sleep(1000)
			setsetting_custom1('service.htpt.fix','Fix_Done',"")
			#setsetting_custom1('service.htpt.fix','Fix_LastDate',"")
			calculate('script.htpt.debug','fixdone_no','1')
			'''---------------------------'''	
			
		