import xbmc, os, subprocess, sys
import xbmcgui, xbmcaddon

xbmc.sleep(5000)

from variables import *
from modules import *
	
class resetsettings:
	setsetting('General_ScriptON',"false")
	setsetting('Current_Name',"")
	setsetting('Current_Address',"")
	setsetting('Current_Tel',"")
	setsetting('Current_Issue',"")
	'''---------------------------'''
	if allowdebug:
		setsetting('ModeOn_12',"true")
		#setsetting('ModeOn_13',"false")
		setsetting('ModeOn_14',"true")
		setsetting('ModeOn_15',"true")
		setsetting('ModeOn_16',"true")
		setsetting('ModeOn_17',"true")
		'''---------------------------'''
	setsetting('General_Pass',"0")
	setsetting('General_Start',"0")
	setsetting('Current_Issue',"")
	'''---------------------------'''
	
class main:
	'''------------------------------
	---STARTUP-----------------------
	------------------------------'''
	setGeneral_Start(admin)
	count = 0
	while 1 and not xbmc.abortRequested:
		'''------------------------------
		---SERVICE-LOOP------------------
		------------------------------'''
		count += 1
		xbmc.sleep(30000)
		'''---------------------------'''
		admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
		connected = xbmc.getInfoLabel('Skin.HasSetting(Connected)')
		allowdebug = xbmc.getInfoLabel('Skin.HasSetting(AllowDebug)')
		'''---------------------------'''
		if count == 2:
			SetGeneral_Pass(admin)
			if allowdebug: xbmc.executebuiltin('RunScript(script.htpt.debug,,?mode=100)')
			count = 0
			'''---------------------------'''
	
	if xbmc.abortRequested:
		notification("AbortRequest","","",1500)