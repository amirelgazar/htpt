import xbmc, os, subprocess, sys
import xbmcgui, xbmcaddon

xbmc.sleep(5000)

from variables import *
from modules import *
	
class resetsettings:
	setsetting('General_ServiceON',"true")
	setsetting('General_ScriptON',"false")

	setsetting('User_Issue',"")
	'''---------------------------'''
	if General_AllowDebug == "true":
		setsetting('ModeOn_12',"true")
		#setsetting('ModeOn_13',"false")
		setsetting('ModeOn_14',"true")
		setsetting('ModeOn_15',"true")
		setsetting('ModeOn_16',"true")
		setsetting('ModeOn_17',"true")
		'''---------------------------'''
	setsetting('General_Pass',"0")
	setsetting('General_Start',"0")
	'''---------------------------'''
	
class main:
	'''------------------------------
	---STARTUP-----------------------
	------------------------------'''
	setGeneral_Start(admin)
	setInfo(admin)
	count = 0
	while 1 and not xbmc.abortRequested:
		'''------------------------------
		---SERVICE-LOOP------------------
		------------------------------'''
		count += 1
		xbmc.sleep(30000)
		'''---------------------------'''
		admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
		connected = xbmc.getInfoLabel('Skin.HasSetting(Connected)')
		
		#General_ServiceON = xbmcaddon.Addon('script.htpt.debug').getSetting('General_ServiceON')
		'''---------------------------'''
		if count == 2:
			SetGeneral_Pass(admin)
			if General_AllowDebug == "true" and General_ServiceON == "true": xbmc.executebuiltin('RunScript(script.htpt.debug,,?mode=100)')
			count = 0
			'''---------------------------'''
		
		#print "General_ServiceON" + space2 + str(General_ServiceON)
	if xbmc.abortRequested:
		notification("AbortRequest","","",1500)