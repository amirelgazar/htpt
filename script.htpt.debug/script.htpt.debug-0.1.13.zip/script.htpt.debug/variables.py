'''------------------------------
---shared_variables--------------
------------------------------'''
import xbmcaddon, sys, os
servicehtptPath          = xbmcaddon.Addon('service.htpt').getAddonInfo("path")
sharedlibDir = os.path.join(servicehtptPath, 'resources', 'lib', 'shared')
sys.path.insert(0, sharedlibDir)
from shared_variables import *
'''---------------------------'''
#libDir = os.path.join(addonPath, 'resources', 'lib')
#sys.path.insert(0, libDir)

'''------------------------------
---script.htpt.debug-------------
------------------------------'''
getsetting         = xbmcaddon.Addon().getSetting
setsetting         = xbmcaddon.Addon().setSetting
addonName          = xbmcaddon.Addon().getAddonInfo("name")
addonString        = xbmcaddon.Addon().getLocalizedString
addonID          = xbmcaddon.Addon().getAddonInfo("id")
addonPath          = xbmcaddon.Addon().getAddonInfo("path")
addonVersion          = xbmcaddon.Addon().getAddonInfo("version")

printfirst = addonName + ": !@# "
'''---------------------------'''

service_call = getsetting('service_call')
service_call_no = getsetting('service_call_no')
startup_no = getsetting('startup_no')
startup12_no = getsetting('startup12_no')
error_no = getsetting('error_no')
poweroff_no = getsetting('poweroff_no')
uptime120_no = getsetting('uptime120_no')
reddone_no = getsetting('reddone_no')
fixdone_no = getsetting('fixdone_no')
uptime60_no = getsetting('uptime60_no')
unauthorized_no = getsetting('unauthorized_no')
username = getsetting('username')
address = getsetting('address')
telephone = getsetting('telephone')
curtrigger = getsetting('curtrigger')
issue_description = getsetting('issue_description')
'''---------------------------'''
debug10 = getsetting('debug10')
debug12 = getsetting('debug12')
debug13 = getsetting('debug13')
debug14 = getsetting('debug14')
debug15 = getsetting('debug15')
debug16 = getsetting('debug16')
debug17 = getsetting('debug17')
debug19 = getsetting('debug19')
'''---------------------------'''

'''102'''
Date_Last = getsetting('Date_Last')
Time_Start = getsetting('Time_Start')
Time_Pass = getsetting('Time_Pass')



'''------------------------------
---systemhasaddon----------------
------------------------------'''


if systemhasaddon_htptfix:
	Fix_Done = getsetting_servicehtptfix('Fix_Done')
	Fix_LastDate = getsetting_servicehtptfix('Fix_LastDate')
	Red_Done = getsetting_servicehtptfix('Red_Done')
	Red_LastDate = getsetting_servicehtptfix('Red_LastDate')
	'''---------------------------'''
else:
	Fix_Done = ""
	Fix_LastDate = ""
	Red_Done = ""
	Red_LastDate = ""
	'''---------------------------'''


'''------------------------------
---script.htpt.debug-2-----------
------------------------------'''
ap = "r"
bp = "o"
cp = "m"
dp = "1"
ep = "2"
fp = "3"
gp = "4"
hp = "5"
ip = "d"
jp = "D"
kp = "#"

'''------------------------------
---script.htpt.debug-3-----------
------------------------------'''
file1 = "/storage/.kodi/temp/kodi.log"
file2 = "/storage/.kodi/temp/kodi.old.log"
file3 = "/storage/.kodi/userdata/guisettings.xml"
file1_w = "z:\\kodi.log"
file2_w = "z:\\kodi.old.log"
file3_w = "z:\\userdata\\guisettings.xml"
zipfilewindows = "z:\htptlog.zip"
logpathwindows = "z:\htpt.log", "z:\userdata\guisettings.xml"
files = "Z:\logpath"
#filenames = [os.path.join(files, f) for f in os.listdir(files)]

''''''

'''GET SETTINGS'''






'''------------------------------
---script.htpt.debug-4-----------
------------------------------'''
content1 = '''
---------------------
-------USER-INFO-----
---------------------
USERNAME:          %s (%s) (%s)
---------------------
INSTALLATION DATE: %s
WARRENTY END:      %s
ADDRESS:           %s
TEL:               %s
PAYMENT TERMS:     %s
TECHNICAL NAME:    %s
HTPT MODEL:        %s
---------------------
''' % (idstr, id1str, username, id2str, id3str, id4str, id5str, id6str, id8str, id10str)

content1u = '''
---------------------
-------USER-INFO-----
---------------------
USERNAME:          %s (%s) (%s)
USER WRITE:        %s
SYSTEM UP TIME:    %s min
---------------------
INSTALLATION DATE: %s
WARRENTY END:      %s
ADDRESS:           %s
TEL:               %s
PAYMENT TERMS:     %s
TECHNICAL NAME:    %s
HTPT MODEL:        %s
---------------------
''' % (idstr, id1str, username, issue_description, Time_Pass, id2str, id3str, id4str, id5str, id6str, id8str, id10str)

content1r = '''
---------------------
-------USER-INFO-----
---------------------
USERNAME:          %s (%s) (%s)
RED ALERT ISSUED:  %s
AVAILABLE DATE:    %s

''' % (idstr, id1str, username, Red_Done, Red_LastDate)

content1f = '''
---------------------
-------USER-INFO-----
---------------------
USERNAME:          %s (%s) (%s)
FIXED ISSUED:      %s
AVAILABLE DATE:    %s

''' % (idstr, id1str, username, Fix_Done, Fix_LastDate)

content2 = '''
---------------------
-----TRIAL/TIME------
---------------------
TRIAL DATE:   	   %s - %s
TRIAL 1/2:    	   %s - %s
---------------------
''' % (trialdate, trialdate2, trial, trial2)

content3 = '''
---------------------
-------VERSION-------
---------------------
HTPT VER:          %s
BUILD VER:         %s
HTPT DEBUG VER:    %s
HTPT FIX VER:      %s
HTPT HELP VER:     %s
HTPT EMU VER:      %s
HTPT HOMEBUTTONS   %s
HTPT REFRESH VER:  %s
HTPT REMOTE VER:   %s
HTPT SERVICE VER:  %s
---------------------
''' % (htptversion, buildversion, htptdebugversion, htptfixversion, htpthelpversion, htptemuversion, htpthomebuttonsversion, htptrefreshversion, htptremoteversion, htptserviceversion)

content4 = '''
---------------------
----NETWORK INFO-----
---------------------
LOCAL IP:          %s
GATEWAY:           %s
DHCPADDRESS:       %s
---------------------
''' % (networkipaddress, networkgatewayaddress, dhcpaddress)

content5 = '''
---------------------
--------MISC---------
---------------------
CURRENT CONTROL:   %s
SCREEN RESOLUTION: %s
MAC(1=lan/2=wlan): %s
FREE SPACE:        %s
FIX IP:            %s
---------------------
''' % (systemcurrentcontrol, screenresolution, macstr2, freespace2, fixip)

content20 = '''
---------------------
---ADDONS SETTINGS---
---------------------
israelive_set1     %s
sdarottv_set1      %s
sdarottv_set2/3    %s - %s (%s -%s)
subtitle_set1/2    %s - %s
genesis_set1/2/3   %s - %s - %s
genesis_set4/5/6   %s - %s - %s
genesis_set7/8     %s - %s (%s -%s)
genesis_set9/10    %s - %s
''' % (israelive_set1, sdarottv_user, sdarottv_password, sdarottv_domain, Account2_Active, Account2_Period, subtitle_set1, subtitle_set2, genesis_set1, genesis_set2, genesis_set3, genesis_set4, genesis_set5, genesis_set6, genesis_set7, genesis_set8, Account1_Active, Account1_Period, genesis_set9, genesis_set10)

'''---------------------------'''
	