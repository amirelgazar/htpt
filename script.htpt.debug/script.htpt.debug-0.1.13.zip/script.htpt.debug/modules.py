#import xbmc, os, subprocess, sys
#import xbmc, xbmcgui, xbmcaddon
import xbmc, xbmcgui, xbmcaddon
#import datetime
from variables import *
from shared_modules import *

import smtplib, os
from email.mime.multipart import MIMEMultipart
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage
from email.MIMEBase import MIMEBase
from email import Encoders
import mimetypes, base64

def sendMail2(subject, text, *attachmentFilePaths):
	mailServer = smtplib.SMTP('smtp.gmail.com', 587)
	gmailUser = "htptdebugout@gmail.com"
	gmailPassword = ap + bp + cp + dp + ep + fp + gp + hp
	recipient = "fixhtpt@gmail.com"
	msg = MIMEMultipart()
	msg['From'] = gmailUser
	msg['To'] = recipient
	msg['Subject'] = subject
	#text = text.decode('utf-8')
	#text = text.encode('utf-8')
	msg.attach(MIMEText(text))
	for attachmentFilePath in attachmentFilePaths:
		msg.attach(getAttachment(attachmentFilePath))
	if (loginscreenW or custom1170W or admin) and (file1_w in attachmentFilePaths or file1 in attachmentFilePaths): xbmc.executebuiltin('Notification($ADDON[script.htpt.debug 31],$ADDON[script.htpt.debug 2],1000)')
	if (loginscreenW or custom1170W or admin) and (file1_w in attachmentFilePaths or file1 in attachmentFilePaths): xbmc.executebuiltin('Notification($ADDON[script.htpt.debug 32],$ADDON[script.htpt.debug 2],1000)')
	#mailServer.ehlo()
	mailServer.starttls()
	if (loginscreenW or custom1170W or admin) and (file1_w in attachmentFilePaths or file1 in attachmentFilePaths): xbmc.executebuiltin('Notification($ADDON[script.htpt.debug 33],$ADDON[script.htpt.debug 2],1000)')
	mailServer.ehlo()
	if (loginscreenW or custom1170W or admin) and (file1_w in attachmentFilePaths or file1 in attachmentFilePaths): xbmc.executebuiltin('Notification($ADDON[script.htpt.debug 34],$ADDON[script.htpt.debug 2],1000)')
	mailServer.login(gmailUser, gmailPassword)	
	if (loginscreenW or custom1170W or admin) and (file1_w in attachmentFilePaths or file1 in attachmentFilePaths): xbmc.executebuiltin('Notification($ADDON[script.htpt.debug 35],$ADDON[script.htpt.debug 2],2000)')
	mailServer.sendmail(gmailUser, recipient, msg.as_string())
	if (loginscreenW or custom1170W or admin) and (file1_w in attachmentFilePaths or file1 in attachmentFilePaths): xbmc.executebuiltin('Notification($ADDON[script.htpt.debug 36],$ADDON[script.htpt.debug 2],1000)')
	mailServer.close()
	returned = 'ok'
	return returned
	'''---------------------------'''
		
def sendMail(subject, text, *attachmentFilePaths):
    try:
        mailServer = smtplib.SMTP('smtp.gmail.com', 587)
        gmailUser = "htptdebugout@gmail.com"
        gmailPassword = ap + bp + cp + dp + ep + fp + gp + hp
        recipient = "fixhtpt@gmail.com"
        msg = MIMEMultipart()
        msg['From'] = gmailUser
        msg['To'] = recipient
        msg['Subject'] = subject
        #text = text.decode('utf-8')
        #text = text.encode('utf-8')
        msg.attach(MIMEText(text))
        for attachmentFilePath in attachmentFilePaths:
			msg.attach(getAttachment(attachmentFilePath))
        if (loginscreenW or custom1170W or admin) and (file1_w in attachmentFilePaths or file1 in attachmentFilePaths): xbmc.executebuiltin('Notification($ADDON[script.htpt.debug 31],$ADDON[script.htpt.debug 2],1000)')
        if (loginscreenW or custom1170W or admin) and (file1_w in attachmentFilePaths or file1 in attachmentFilePaths): xbmc.executebuiltin('Notification($ADDON[script.htpt.debug 32],$ADDON[script.htpt.debug 2],1000)')
        #mailServer.ehlo()
        mailServer.starttls()
        if (loginscreenW or custom1170W or admin) and (file1_w in attachmentFilePaths or file1 in attachmentFilePaths): xbmc.executebuiltin('Notification($ADDON[script.htpt.debug 33],$ADDON[script.htpt.debug 2],1000)')
        mailServer.ehlo()
        if (loginscreenW or custom1170W or admin) and (file1_w in attachmentFilePaths or file1 in attachmentFilePaths): xbmc.executebuiltin('Notification($ADDON[script.htpt.debug 34],$ADDON[script.htpt.debug 2],1000)')
        mailServer.login(gmailUser, gmailPassword)	
        if (loginscreenW or custom1170W or admin) and (file1_w in attachmentFilePaths or file1 in attachmentFilePaths): xbmc.executebuiltin('Notification($ADDON[script.htpt.debug 35],$ADDON[script.htpt.debug 2],2000)')
        mailServer.sendmail(gmailUser, recipient, msg.as_string())
        if (loginscreenW or custom1170W or admin) and (file1_w in attachmentFilePaths or file1 in attachmentFilePaths): xbmc.executebuiltin('Notification($ADDON[script.htpt.debug 36],$ADDON[script.htpt.debug 2],1000)')
        mailServer.close()
        returned = 'ok'
        return returned
        '''---------------------------'''
    except:
		try: mailServer.close()
		except: pass
		print printfirst + "sendMail" + space + "TypeError"
		returned = 'skip'
		'''---------------------------'''

def getAttachment(attachmentFilePath):
    contentType, encoding = mimetypes.guess_type(attachmentFilePath)

    if contentType is None or encoding is not None:
        contentType = 'application/octet-stream'
    mainType, subType = contentType.split('/', 1)
    file = open(attachmentFilePath, 'rb')

    if mainType == 'text':
        attachment = MIMEText(file.read())
    elif mainType == 'message':
        attachment = email.message_from_file(file)
    elif mainType == 'image':
        attachment = MIMEImage(file.read(),_subType=subType)
    elif mainType == 'audio':
        attachment = MIMEAudio(file.read(),_subType=subType)
    else:
        attachment = MIMEBase(mainType, subType)

    attachment.set_payload(file.read())
    #encode_base64(attachment)
    file.close()
    attachment.add_header('Content-Disposition', 'attachment',   filename=os.path.basename(attachmentFilePath))
    return attachment
    '''---------------------------'''
	
def setTime_Start(admin):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	Time_Start = getsetting('Time_Start')
	#timenow = datetime.datetime.now()
	#timenowS = timenow.strftime("%H:%M")
	'''---------------------------'''
	setsetting_custom1('script.htpt.debug','Time_Start',timenow2S)
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	Time_Start2 = getsetting('Time_Start')
	print printfirst + "setTime_Start" + space2 + "Time_Start" + space2 + Time_Start + " - " + Time_Start2 + space3
	'''---------------------------'''

def SetTime_Pass(admin):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	Time_Pass = getsetting('Time_Pass')
	'''---------------------------'''
	calculate('script.htpt.debug','Time_Pass','1',"")
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	Time_Pass2 = getsetting('Time_Pass')
	if admin: print printfirst + "setTime_Pass" + space2 + "Time_Pass" + space2 + Time_Pass + " - " + Time_Pass2 + space3
	'''---------------------------'''