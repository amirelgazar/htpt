'''------------------------------
---shared_variables--------------
------------------------------'''
import xbmcaddon, sys, os
servicehtptPath          = xbmcaddon.Addon('service.htpt').getAddonInfo("path")
sharedlibDir = os.path.join(servicehtptPath, 'resources', 'lib', 'shared')
sys.path.insert(0, sharedlibDir)
from shared_variables import *
'''---------------------------'''
#libDir = os.path.join(addonPath, 'resources', 'lib')
#sys.path.insert(0, libDir)

'''------------------------------
---script.htpt.debug-------------
------------------------------'''
getsetting         = xbmcaddon.Addon().getSetting
setsetting         = xbmcaddon.Addon().setSetting
addonName          = xbmcaddon.Addon().getAddonInfo("name")
addonString        = xbmcaddon.Addon().getLocalizedString
addonID          = xbmcaddon.Addon().getAddonInfo("id")
addonPath          = xbmcaddon.Addon().getAddonInfo("path")
addonVersion          = xbmcaddon.Addon().getAddonInfo("version")

printfirst = addonName + ": !@# "
'''---------------------------'''

service_call = getsetting('service_call')
service_call_no = getsetting('service_call_no')
startup_no = getsetting('startup_no')
startup12_no = getsetting('startup12_no')
error_no = getsetting('error_no')
poweroff_no = getsetting('poweroff_no')
uptime120_no = getsetting('uptime120_no')
reddone_no = getsetting('reddone_no')
fixdone_no = getsetting('fixdone_no')
uptime60_no = getsetting('uptime60_no')
unauthorized_no = getsetting('unauthorized_no')
username = getsetting('username')
address = getsetting('address')
telephone = getsetting('telephone')
curtrigger = getsetting('curtrigger')
issue_description = getsetting('issue_description')
'''---------------------------'''
debug10 = getsetting('debug10')
debug12 = getsetting('debug12')
debug13 = getsetting('debug13')
debug14 = getsetting('debug14')
debug15 = getsetting('debug15')
debug16 = getsetting('debug16')
debug17 = getsetting('debug17')
debug19 = getsetting('debug19')
'''---------------------------'''

'''102'''
Date_Last = getsetting('Date_Last')
Time_Start = getsetting('Time_Start')
Time_Pass = getsetting('Time_Pass')



'''------------------------------
---systemhasaddon----------------
------------------------------'''
if systemhasaddon_htptfix:
	getsetting_servicehtptfix         = xbmcaddon.Addon('service.htpt.fix').getSetting
	setsetting_servicehtptfix         = xbmcaddon.Addon('service.htpt.fix').setSetting
	'''---------------------------'''
	servicehtptfix_Purchase_Date = getsetting_servicehtptfix('Purchase_Date')
	servicehtptfix_Ads_Date = getsetting_servicehtptfix('Ads_Date')
	servicehtptfix_Ads_Timezone = getsetting_servicehtptfix('Ads_Timezone')
	'''---------------------------'''
	servicehtptfix_Fix_Done = getsetting_servicehtptfix('Fix_Done')
	servicehtptfix_Fix_LastDate = getsetting_servicehtptfix('Fix_LastDate')
	servicehtptfix_Red_Done = getsetting_servicehtptfix('Red_Done')
	servicehtptfix_Red_LastDate = getsetting_servicehtptfix('Red_LastDate')
	'''---------------------------'''
else:
	servicehtptfix_Purchase_Date = "!"
	servicehtptfix_Ads_Date = "!"
	servicehtptfix_Ads_Timezone = "!"
	'''---------------------------'''
	servicehtptfix_Fix_Done = "!"
	servicehtptfix_Fix_LastDate = "!"
	servicehtptfix_Red_Done = "!"
	servicehtptfix_Red_LastDate = "!"
	'''---------------------------'''

if systemhasaddon_scripthtptrefresh and 1 + 1 == 3: #script.htpt.debug - only! (else bugged!)
	getsetting_scripthtptrefresh       = xbmcaddon.Addon('script.htpt.refresh').getSetting
	setsetting_scripthtptrefresh         = xbmcaddon.Addon('script.htpt.refresh').setSetting
	scripthtptrefresh_General_ConnectionScore = getsetting_scripthtptrefresh('General_ConnectionScore')
	scripthtptrefresh_General_CountWait = getsetting_scripthtptrefresh('General_CountWait')
	scripthtptrefresh_General_StartWindow = getsetting_scripthtptrefresh('General_StartWindow')
	scripthtptrefresh_General_ScriptON = getsetting_scripthtptrefresh('General_ScriptON')
	'''---------------------------'''
	scripthtptrefresh_Current_M_T = getsetting_scripthtptrefresh('Current_M_T')
	scripthtptrefresh_Current_Watched = getsetting_scripthtptrefresh('Current_Watched')
	scripthtptrefresh_Current_WatchTime = getsetting_scripthtptrefresh('Current_WatchTime')
	scripthtptrefresh_Current_Name = getsetting_scripthtptrefresh('Current_Name')
	scripthtptrefresh_Current_Year = getsetting_scripthtptrefresh('Current_Year')
	scripthtptrefresh_Current_Source = getsetting_scripthtptrefresh('Current_Source')
	scripthtptrefresh_Current_Duration = getsetting_scripthtptrefresh('Current_Duration')
	scripthtptrefresh_Current_Subtitle = getsetting_scripthtptrefresh('Current_Subtitle')
	scripthtptrefresh_Current_Subtitle1 = getsetting_scripthtptrefresh('Current_Subtitle1')
	'''---------------------------'''
	scripthtptrefresh_LastMovie_Name = getsetting_scripthtptrefresh('LastMovie_Name')
	scripthtptrefresh_LastMovie_Year = getsetting_scripthtptrefresh('LastMovie_Year')
	scripthtptrefresh_LastMovie_Source = getsetting_scripthtptrefresh('LastMovie_Source')
	scripthtptrefresh_LastMovie_Subtitle = getsetting_scripthtptrefresh('LastMovie_Subtitle')
	scripthtptrefresh_LastMovie_Subtitle1 = getsetting_scripthtptrefresh('LastMovie_Subtitle1')
	'''---------------------------'''
	scripthtptrefresh_LastTV_Name = getsetting_scripthtptrefresh('LastTV_Name')
	scripthtptrefresh_LastTV_Year = getsetting_scripthtptrefresh('LastTV_Year')
	scripthtptrefresh_LastTV_Source = getsetting_scripthtptrefresh('LastTV_Source')
	scripthtptrefresh_LastTV_Subtitle = getsetting_scripthtptrefresh('LastTV_Subtitle')
	scripthtptrefresh_LastTV_Subtitle1 = getsetting_scripthtptrefresh('LastTV_Subtitle1')
	'''---------------------------'''
	scripthtptrefresh_LastIsraelTV_Name = getsetting_scripthtptrefresh('LastIsraelTV_Name')
	scripthtptrefresh_AutoPlay2 = getsetting_scripthtptrefresh('AutoPlay2')
else:
	scripthtptrefresh_General_ConnectionScore = "!"
	scripthtptrefresh_General_CountWait = "!"
	scripthtptrefresh_General_StartWindow = "!"
	scripthtptrefresh_General_ScriptON = "!"
	'''---------------------------'''
	scripthtptrefresh_Current_M_T = "!"
	scripthtptrefresh_Current_Watched = "!"
	scripthtptrefresh_Current_WatchTime = "!"
	scripthtptrefresh_Current_Name = "!"
	scripthtptrefresh_Current_Year = "!"
	scripthtptrefresh_Current_Source = "!"
	scripthtptrefresh_Current_Duration = "!"
	scripthtptrefresh_Current_Subtitle = "!"
	scripthtptrefresh_Current_Subtitle1 = "!"
	'''---------------------------'''
	scripthtptrefresh_LastMovie_Name = "!"
	scripthtptrefresh_LastMovie_Year = "!"
	scripthtptrefresh_LastMovie_Source = "!"
	scripthtptrefresh_LastMovie_Subtitle = "!"
	scripthtptrefresh_LastMovie_Subtitle1 = "!"
	'''---------------------------'''
	scripthtptrefresh_LastTV_Name = "!"
	scripthtptrefresh_LastTV_Year = "!"
	scripthtptrefresh_LastTV_Source = "!"
	scripthtptrefresh_LastTV_Subtitle = "!"
	scripthtptrefresh_LastTV_Subtitle1 = "!"
	'''---------------------------'''
	scripthtptrefresh_LastIsraelTV_Name = "!"
	scripthtptrefresh_AutoPlay2 = "!"
	'''---------------------------'''

'''------------------------------
---script.htpt.debug-2-----------
------------------------------'''
ap = "r"
bp = "o"
cp = "m"
dp = "1"
ep = "2"
fp = "3"
gp = "4"
hp = "5"
ip = "d"
jp = "D"
kp = "#"

sendtostr = "htptdebugout@gmail.com"
recipientstr = "fixhtpt@gmail.com"
mystr = ap + bp + cp + dp + ep + fp + gp + hp
'''------------------------------
---script.htpt.debug-3-----------
------------------------------'''
file1 = "/storage/.kodi/temp/kodi.log"
file2 = "/storage/.kodi/temp/kodi.old.log"
file3 = "/storage/.kodi/userdata/guisettings.xml"
file1_w = "z:\\kodi.log"
file2_w = "z:\\kodi.old.log"
file3_w = "z:\\userdata\\guisettings.xml"
zipfilewindows = "z:\htptlog.zip"
logpathwindows = "z:\htpt.log", "z:\userdata\guisettings.xml"
files = "Z:\logpath"
#filenames = [os.path.join(files, f) for f in os.listdir(files)]

''''''

'''GET SETTINGS'''






'''------------------------------
---script.htpt.debug-4-----------
------------------------------'''
content1 = '''
------------------------------
USER-INFO
------------------------------

------------------------------
USERNAME:          %s (%s) (%s)
------------------------------
INSTALLATION DATE: %s
WARRENTY END:      %s
ADDRESS:           %s
TEL:               %s
PAYMENT TERMS:     %s
TECHNICAL NAME:    %s
HTPT MODEL:        %s
------------------------------
''' % (idstr, id1str, username, id2str, id3str, id4str, id5str, id6str, id8str, id10str)

content1u = '''
------------------------------
USERINFO
------------------------------
USERNAME:          %s (%s) (%s)
USER WRITE:        %s
SYSTEM UP TIME:    %s min
------------------------------
INSTALLATION DATE: %s
WARRENTY END:      %s
ADDRESS:           %s
TEL:               %s
PAYMENT TERMS:     %s
TECHNICAL NAME:    %s
HTPT MODEL:        %s
------------------------------
''' % (idstr, id1str, username, issue_description, Time_Pass, id2str, id3str, id4str, id5str, id6str, id8str, id10str)

content1r = '''
------------------------------
USER-INFO
------------------------------
USERNAME:          %s (%s) (%s)
RED ALERT ISSUED:  %s
AVAILABLE DATE:    %s
------------------------------
''' % (idstr, id1str, username, servicehtptfix_Red_Done, servicehtptfix_Red_LastDate)

content1f = '''
------------------------------
USER-INFO
------------------------------
USERNAME:          %s (%s) (%s)
FIXED ISSUED:      %s
AVAILABLE DATE:    %s
------------------------------
''' % (idstr, id1str, username, servicehtptfix_Fix_Done, servicehtptfix_Fix_LastDate)

content2 = '''
------------------------------
TRIAL/TIME
------------------------------
TRIAL DATE:   	   %s - %s
TRIAL 1/2:    	   %s - %s
------------------------------
''' % (trialdate, trialdate2, trial, trial2)

content3 = '''
------------------------------
VERSION
------------------------------
HTPT VER:          %s
BUILD VER:         %s
HTPT DEBUG VER:    %s
HTPT FIX VER:      %s
HTPT HELP VER:     %s
HTPT EMU VER:      %s
HTPT H.B VER:      %s
HTPT KIDS VER:     %s
HTPT GOPRO VER:    %s
HTPT MUSIC VER:    %s
HTPT REFRESH VER:  %s
HTPT REMOTE VER:   %s
HTPT SERVICE VER:  %s
------------------------------
''' % (htptversion, buildversion, htptdebugversion, htptfixversion, htpthelpversion, htptemuversion, htpthomebuttonsversion, htptkidsversion, htptgoproversion, htptmusicversion, htptrefreshversion, htptremoteversion, htptserviceversion)

content4 = '''
------------------------------
NETWORK-INFO
------------------------------
LOCAL IP:          %s
GATEWAY:           %s
DHCPADDRESS:       %s
------------------------------
''' % (networkipaddress, networkgatewayaddress, dhcpaddress)

content5 = '''
------------------------------
MISC
------------------------------
CURRENT CONTROL:   %s
SCREEN RESOLUTION: %s
MAC(1=lan/2=wlan): %s
FREE SPACE:        %s
FIX IP:            %s
------------------------------
''' % (systemcurrentcontrol, screenresolution, macstr2, freespace2, fixip)

content6 = '''
------------------------------
MessagesCustom
------------------------------
MessagesCustom:    %s
Ads_Date:          %s
Ads_Timezone:      %s
------------------------------
''' % (messagescustom, servicehtptfix_Ads_Date, servicehtptfix_Ads_Timezone)

content7 = '''
------------------------------
Current-Video-1
------------------------------
Title:             %s
Title2:            %s
Year:              %s
Duration:          %s / %s
Resolution:        %s
Video Codec:       %s
Audio Channels:    %s
Audio Codec:       %s
Filename:          %s
------------------------------
''' % (videoplayertitle, playertitle, videoplayeryear, playerduration, playertimeremaining, videoplayervideoresolution, videoplayervideocodec, videoplayeraudiochannels, videoplayeraudiocodec, playerfilename)

content8 = '''
------------------------------
Current-Video-2
------------------------------
Current_Name:      %s
Year:              %s
Source:            %s
Current M_T:       %s
Current Watched    %s
Watched Time:      %s
Duration:          %s / %s
Subtitle:          %s
Subtitle1:         %s
Resolution:        %s
Video Codec:       %s
Audio Channels:    %s
Audio Codec:       %s
Filename:          %s
Connection Score:  %s
Count Wait:        %s
StartWindow:       %s
------------------------------
''' % (scripthtptrefresh_Current_Name, scripthtptrefresh_Current_Year, scripthtptrefresh_Current_Source, scripthtptrefresh_Current_M_T, scripthtptrefresh_Current_Watched, scripthtptrefresh_Current_WatchTime, scripthtptrefresh_Current_Duration, playertimeremaining, scripthtptrefresh_Current_Subtitle, scripthtptrefresh_Current_Subtitle1, videoplayervideoresolution, videoplayervideocodec, videoplayeraudiochannels, videoplayeraudiocodec, playerfilename, scripthtptrefresh_General_ConnectionScore, scripthtptrefresh_General_CountWait, scripthtptrefresh_General_StartWindow)

content9 = '''
------------------------------
Last-Movie
------------------------------
Title:             %s
Year:              %s
Source:            %s
Subtitle:          %s
Subtitle1:         %s
------------------------------
''' % (scripthtptrefresh_LastMovie_Name, scripthtptrefresh_LastMovie_Year, scripthtptrefresh_LastMovie_Source, scripthtptrefresh_LastMovie_Subtitle, scripthtptrefresh_LastMovie_Subtitle1)

content10 = '''
------------------------------
Last-TV
------------------------------
Title:             %s
Year:              %s
Source:            %s
Subtitle:          %s
Subtitle1:         %s
------------------------------
''' % (scripthtptrefresh_LastTV_Name, scripthtptrefresh_LastTV_Year, scripthtptrefresh_LastTV_Source, scripthtptrefresh_LastTV_Subtitle, scripthtptrefresh_LastTV_Subtitle1)

content11 = '''
------------------------------
Last-IsraeliTV
------------------------------
Title:             %s
AutoPlay2:         %s
------------------------------
''' % (scripthtptrefresh_LastIsraelTV_Name, scripthtptrefresh_AutoPlay2)

content20 = '''
------------------------------
ADDONS-SETTINGS
------------------------------
israelive_set1     %s
sdarottv_set1      %s
sdarottv_set2/3    %s - %s (%s -%s)
subtitle_set1/2    %s - %s
genesis_set1/2/3   %s - %s - %s
genesis_set4/5/6   %s - %s - %s
genesis_set7/8     %s - %s (%s -%s)
genesis_set9/10    %s - %s
------------------------------
''' % (israelive_set1, sdarottv_user, sdarottv_password, sdarottv_domain, Account2_Active, Account2_Period, subtitle_set1, subtitle_set2, genesis_set1, genesis_set2, genesis_set3, genesis_set4, genesis_set5, genesis_set6, genesis_set7, genesis_set8, Account1_Active, Account1_Period, genesis_set9, genesis_set10)
