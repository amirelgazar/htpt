import xbmc, xbmcgui
import os, sys
import subprocess
import xbmcaddon

xbmc.sleep(1000)
from variables import *
from modules import *

class resetsettings:
	setsetting_custom1('service.htpt','Time_Pass',"0")
	setsetting_custom1('service.htpt','General_Timer',"0")
	setsetting_custom1('service.htpt','General_CurTrigger',"")
	setsetting_custom1('service.htpt','Skin_UpdateCount',"0")
	setsetting_custom1('service.htpt','Skin_UpdateCount2',"0")
	setsetting_custom1('service.htpt','Skin_UpdateTimer',"0")
	setsetting_custom1('service.htpt','Skin_UpdateLog',"true")
	setsetting_custom1('service.htpt','Skin_Check',"0")
	if not systemplatformwindows:
		setSkinSetting("1",'Connected',"false")
		setSkinSetting("1",'Connected2',"false")
		setSkinSetting("1",'Connected3',"false")	
		'''---------------------------'''
	
class startup:
	Trial(admin)
	'''---------------------------'''
	if not systemplatformwindows:
		os.system('sh /storage/.kodi/addons/service.htpt/specials/scripts/copyskin.sh')
		os.system('sh /storage/.kodi/addons/service.htpt/specials/scripts/copy2.sh')
		os.system('sh /storage/.kodi/addons/service.htpt/specials/scripts/copyonce.sh')
		'''---------------------------'''
		
class main:
	'''------------------------------
	---SERVICE-LOOP------------------
	------------------------------'''
	setTime_Start(admin)
	updateskincheck = 'false'
	count = 0
	while 1 and not xbmc.abortRequested:
		'''------------------------------
		---VARIABLES---------------------
		------------------------------'''
		systeminternetstate = xbmc.getInfoLabel('System.InternetState')
		try: networkipaddress = xbmc.getInfoLabel('Network.IPAddress')
		except: print printfirst + "main_Error_" + "networkipaddress"
		connected = xbmc.getInfoLabel('Skin.HasSetting(Connected)')
		hasinternet = systeminternetstate != "" and networkipaddress != "" and not "169.254." in networkipaddress and (connected or systemplatformwindows)
		
		'''---------------------------'''
		#xbmc.executebuiltin('RunScript(service.htpt)')
		admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
		admin2 = xbmc.getInfoLabel('Skin.HasSetting(Admin2)')
		playerhasvideo = xbmc.getCondVisibility('Player.HasVideo')
		systemidle3 = xbmc.getCondVisibility('System.IdleTime(3)')
		systemidle120 = xbmc.getCondVisibility('System.IdleTime(120)')
		systemidle300 = xbmc.getCondVisibility('System.IdleTime(300)')
		home_aW = xbmc.getCondVisibility('Window.IsActive(0)')
		General_Connected = getsetting('General_Connected')
		General_CurTrigger = getsetting('General_CurTrigger')
		General_Timer = getsetting('General_Timer')
		Time_Start = getsetting('Time_Start')
		Time_Pass = getsetting('Time_Pass')
		htptskinversion = xbmc.getInfoLabel('System.AddonVersion(skin.htpt)')
		Skin_UpdateCount = getsetting('Skin_UpdateCount')
		Skin_UpdateCount2 = getsetting('Skin_UpdateCount2')
		Skin_UpdateTimer = getsetting('Skin_UpdateTimer')
		Skin_UpdateTimerN = int(Skin_UpdateTimer)
		Skin_Update = getsetting('Skin_Update')
		Skin_UpdateDate = getsetting('Skin_UpdateDate')
		Skin_UpdateLog = getsetting('Skin_UpdateLog')
		Skin_Version = getsetting('Skin_Version')
		Skin_Check = getsetting('Skin_Check')
		Ping_Rate = getsetting('Ping_Rate')
		A10 = [10, 20, 30, 40, 50 , 60]
		'''---------------------------'''
		
		'''------------------------------
		---count-------------------------
		------------------------------'''
		if not systemplatformwindows and not systemidle300: xbmc.sleep(50)
		else: xbmc.sleep(1000)
		if count < 60: count += 1
		elif count >= 60:
			count = 1
			'''---------------------------'''
		countS = str(count)
		setsetting('General_Timer',countS)
		if admin and admin2: print printfirst + space + "General_Timer" + space2 + countS
		'''---------------------------'''
			
		if count == 1:
			'''------------------------------
			---SetTime_Pass------------------
			------------------------------'''
			Time_Pass2 = SetTime_Pass(admin, admin2, Time_Pass)
			setsetting('Time_Pass',Time_Pass2)
			'''---------------------------'''
		
		if Skin_UpdateTimer != "0":
			'''------------------------------
			---Skin_UpdateTimer--------------
			------------------------------'''
			Skin_UpdateTimer2 = calculate('service.htpt','Skin_UpdateTimer','2',Skin_UpdateTimer)
			setsetting('Skin_UpdateTimer',Skin_UpdateTimer2)
			'''---------------------------'''
			if Skin_UpdateTimerN == 119: notification(addonString(12).encode('utf-8') + ".", addonString(9).encode('utf-8'),"",1000)
			elif Skin_UpdateTimerN == 118: notification(addonString(12).encode('utf-8') + "..", addonString(9).encode('utf-8'),"",1000)
			elif Skin_UpdateTimerN == 117: notification(addonString(12).encode('utf-8') + "...", addonString(9).encode('utf-8'),"",1000)
			#elif not playerhasvideo and systemidle3 and : 
			'''---------------------------'''
			
		if Skin_UpdateTimer == "0" and Skin_UpdateCount == Skin_UpdateCount2:
			'''------------------------------
			---setSkin_UpdateCount-----------
			------------------------------'''
			setSkin_UpdateCount2(admin, Skin_UpdateCount, Time_Pass)
			'''---------------------------'''
				
		if Skin_UpdateCount2 != Skin_UpdateCount and (systemidle120 or admin or Skin_UpdateCount == "0") and not playerhasvideo and hasinternet:
			'''------------------------------
			---UpdateAddons------------------
			------------------------------'''
			UpdateAddons(admin, Skin_UpdateCount, Skin_UpdateCount2)
			'''---------------------------'''

		if (Skin_Update != "true" and (Skin_UpdateTimerN < 70 or admin) and Skin_UpdateTimerN > 0) or (Skin_Update == "true" and Skin_Version == htptskinversion):
			'''------------------------------
			---Skin_Update-(NEW-ONLY)--------
			------------------------------'''
			setSkin_Update(admin, Skin_Version, htptskinversion, Skin_Update)
			'''---------------------------'''

		if Skin_Update == "true" or Skin_UpdateDate == "":
			'''------------------------------
			---setSkin_UpdateDate-(NEW-ONLY)-
			------------------------------'''
			setSkin_UpdateDate(admin, Skin_Version, htptskinversion, Skin_Update, Skin_UpdateDate)
			'''---------------------------'''
			
		if Skin_Update == "true" or Skin_Version == "":
			'''------------------------------
			---setSkin_Version---------------
			------------------------------'''
			setSkin_Version(admin, Skin_Version, htptskinversion)
			'''---------------------------'''
		
		if Skin_Version == htptskinversion and Skin_UpdateLog == "true" and Skin_UpdateDate != "" and systemidle3 and not playerhasvideo and home_aW:
			'''------------------------------
			---Skin_UpdateLog----------------
			------------------------------'''
			dialogbusyW = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
			dialogokW = xbmc.getCondVisibility('Window.IsVisible(DialogOk.xml)')
			dialogprogressW = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
			dialogselectW = xbmc.getCondVisibility('Window.IsVisible(DialogSelect.xml)')
			dialogtextviewerW = xbmc.getCondVisibility('Window.IsVisible(DialogTextViewer.xml)')
			dialogyesnoW = xbmc.getCondVisibility('Window.IsVisible(DialogYesNo.xml)')
			startupW = xbmc.getCondVisibility('Window.IsVisible(Startup.xml)')
			'''---------------------------'''
			if not dialogbusyW and not dialogokW and not dialogprogressW and not dialogselectW and not dialogtextviewerW and not dialogyesnoW and not startupW:
				import datetime
				datenow = datetime.date.today()
				datenowS = str(datenow)
				if datenowS != "": #PREVENT RANDOM BUG WITH datetime
					setSkin_UpdateLog(admin, Skin_Version, Skin_UpdateDate, datenowS)
					setsetting('Skin_UpdateLog',"false")
					'''---------------------------'''
		
		if count in A10 and not systemplatformwindows:
			'''------------------------------
			---setPing_Rate-(1-5)------------
			------------------------------'''
			Ping_1 = getsetting('Ping_1')
			Ping_2 = getsetting('Ping_2')
			Ping_3 = getsetting('Ping_3')
			Ping_4 = getsetting('Ping_4')
			Ping_5 = getsetting('Ping_5')
			Ping_6 = getsetting('Ping_6')
			Ping_7 = getsetting('Ping_7')
			Ping_8 = getsetting('Ping_8')
			Ping_9 = getsetting('Ping_9')
			Ping_10 = getsetting('Ping_10')
			'''---------------------------'''
			setPing_Rate(admin, admin2, Ping_Rate, Ping_1, Ping_2, Ping_3, Ping_4, Ping_5, Ping_6, Ping_7, Ping_8, Ping_9, Ping_10)
			'''---------------------------'''
			
		'''------------------------------
		---validationstartup-------------
		------------------------------'''
		validationstartup(admin)
		'''---------------------------'''
		
		'''------------------------------
		---videoplayertweak--------------
		------------------------------'''
		videoplayertweak(admin,playerhasvideo)
		'''---------------------------'''
		
		if not systemplatformwindows and not systemidle300:
			'''------------------------------
			---connectioncheck---------------
			------------------------------'''
			connectioncheck(admin,count,systemidle3)
			'''---------------------------'''
			
			'''------------------------------
			---setPing-----------------------
			------------------------------'''
			#setPing(admin,count,systemidle3)
			'''---------------------------'''
		
		'''---------------------------'''
		if systemidle3 and not systemplatformwindows and not playerhasvideo:
			'''------------------------------
			---SKIN-CHECK--------------------
			------------------------------'''
			output = bash('cat /storage/.kodi/userdata/guisettings.xml | grep -e "<skin>"',"GUI1")
			if not "<skin>skin.htpt</skin>" in output and "<skin>" in output:
				Skin_Check2 = calculate('service.htpt','Skin_Check','1',Skin_Check)
				Skin_Check2N = int(Skin_Check2)
				setsetting('Skin_Check', Skin_Check2)
				
				if Skin_Check2N > 2:
					'''------------------------------
					---ERROR-1020--------------------
					------------------------------'''
					xbmc.executebuiltin('Notification($LOCALIZE[257]: 1020,$LOCALIZE[79505],2000)')
					os.system('sh /storage/.kodi/addons/service.htpt/specials/scripts/copyskin.sh')
					setsetting_custom1('service.htpt','Skin_Check',"-10")
					'''---------------------------'''
			elif Skin_Check != "0":
				setsetting('Skin_Check', "0")
			
	if xbmc.abortRequested:
		print printfirst + "Error 1170: AbortRequested!"
		sys.exit()
		'''---------------------------'''
		
		
#repeat()