#import xbmc, os, subprocess, sys
#import xbmc, xbmcgui, xbmcaddon
import xbmc, xbmcgui, xbmcaddon
import datetime
import sys, os

'''---------------------------'''

'''---------------------------'''

'''------------------------------
---DEFAULT-----------------------
------------------------------'''
space = " "
space2 = ": "
space3 = "_"
space4 = " / "
dialog = xbmcgui.Dialog()
systemplatformwindows = xbmc.getCondVisibility('system.platform.windows')
systemidle3 = xbmc.getCondVisibility('System.IdleTime(3)')
systemidle7 = xbmc.getCondVisibility('System.IdleTime(7)')
systemidle10 = xbmc.getCondVisibility('System.IdleTime(10)')
systemidle120 = xbmc.getCondVisibility('System.IdleTime(120)')
systemidle300 = xbmc.getCondVisibility('System.IdleTime(300)')
systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
systemcurrentwindow = xbmc.getInfoLabel('System.CurrentWindow')
'''---------------------------'''

'''------------------------------
---Window.-----------------------
------------------------------'''

custom1115W = xbmc.getCondVisibility('Window.IsVisible(Custom1115.xml)')
custom1124W = xbmc.getCondVisibility('Window.IsVisible(Custom1124.xml)')
custom1125W = xbmc.getCondVisibility('Window.IsVisible(Custom1125.xml)')
custom1132W = xbmc.getCondVisibility('Window.IsVisible(Custom1132.xml)')
custom1170W = xbmc.getCondVisibility('Window.IsVisible(Custom1170.xml)')
custom1170W = xbmc.getCondVisibility('Window.IsVisible(Custom1170.xml)')
custom1191W = xbmc.getInfoLabel('Skin.String(custom1191)')

customhomecustomizerW = xbmc.getCondVisibility('Window.IsVisible(CustomHomeCustomizer.xml)')
dialogbusyW = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
dialogcontentsettingsW = xbmc.getCondVisibility('Window.IsVisible(DialogContentSettings.xml)')
dialogcontextmenuW = xbmc.getCondVisibility('Window.IsVisible(DialogContextMenu.xml)')
dialogfavouritesW = xbmc.getCondVisibility('Window.IsVisible(DialogFavourites.xml)')
dialogkaitoastW = xbmc.getCondVisibility('Window.IsVisible(DialogKaiToast.xml)')
dialogokW = xbmc.getCondVisibility('Window.IsVisible(DialogOk.xml)')
dialogprogressW = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
dialogselectW = xbmc.getCondVisibility('Window.IsVisible(DialogSelect.xml)')
dialogsubtitlesW = xbmc.getCondVisibility('Window.IsVisible(DialogSubtitles.xml)')
dialogtextviewerW = xbmc.getCondVisibility('Window.IsVisible(DialogTextViewer.xml)')
dialogvideoinfoW = xbmc.getCondVisibility('Window.IsVisible(DialogVideoInfo.xml)')
dialogyesnoW = xbmc.getCondVisibility('Window.IsVisible(DialogYesNo.xml)')
filemanagerW = xbmc.getCondVisibility('Window.IsVisible(FileManager.xml)')
loginscreenW = xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)')
loginscreen_aW = xbmc.getCondVisibility('Window.IsActive(LoginScreen.xml)')
mainwindow = xbmc.getCondVisibility('Window.IsVisible(mainWindow.xml)') #OpenELEC
mypicsW = xbmc.getCondVisibility('Window.IsVisible(MyPics.xml)')
myprogramsW = xbmc.getCondVisibility('Window.IsVisible(MyPrograms.xml)')
mymusicnavW = xbmc.getCondVisibility('Window.IsVisible(MyMusicNav.xml)')
myvideonavW = xbmc.getCondVisibility('Window.IsVisible(MyVideoNav.xml)')
myweatherW = xbmc.getCondVisibility('Window.IsVisible(MyWeather.xml)')

homeW = xbmc.getCondVisibility('Window.IsVisible(Home.xml)')
home_pW = xbmc.getCondVisibility('Window.Previous(0)')
home_aW = xbmc.getCondVisibility('Window.IsActive(0)')

settingsW = xbmc.getCondVisibility('Window.IsVisible(Settings.xml)')
settingscategoryW = xbmc.getCondVisibility('Window.IsVisible(SettingsCategory.xml)')
skinsettingsW = xbmc.getCondVisibility('Window.IsVisible(SkinSettings.xml)')
startupW = xbmc.getCondVisibility('Window.IsVisible(Startup.xml)')
startup_aW = xbmc.getCondVisibility('Window.IsActive(Startup.xml)')
startup_pW = xbmc.getCondVisibility('Window.Previous(Startup.xml)')
videofullscreenW = xbmc.getCondVisibility('Window.IsVisible(VideoFullScreen.xml)')
'''---------------------------'''

'''------------------------------
---Skin.HasSetting---------------
------------------------------'''
admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
admin2 = xbmc.getInfoLabel('Skin.HasSetting(Admin2)')
adult = xbmc.getInfoLabel('Skin.HasSetting(Adult)')
adult2 = xbmc.getInfoLabel('Skin.HasSetting(Adult2)')
autoplaysd = xbmc.getInfoLabel('Skin.HasSetting(AutoPlaySD)')
autoplaypause = xbmc.getInfoLabel('Skin.HasSetting(AutoPlay_Pause)')
autoviewoff = xbmc.getInfoLabel('Skin.HasSetting(AutoViewoff)')
connected = xbmc.getInfoLabel('Skin.HasSetting(Connected)')
connected2 = xbmc.getInfoLabel('Skin.HasSetting(Connected2)')
connected3 = xbmc.getInfoLabel('Skin.HasSetting(Connected3)')
homebuttonsrunning = xbmc.getInfoLabel('Skin.HasSetting(homebuttonsrunning)') #TEMP
moviesep = xbmc.getInfoLabel('Skin.HasSetting(moviesep)')
myhtpt2 = xbmc.getInfoLabel('Skin.HasSetting(myHTPT2)')
myhtpt3 = xbmc.getInfoLabel('Skin.HasSetting(myHTPT3)')
realdebrid = xbmc.getInfoLabel('Skin.HasSetting(RealDebrid)') #TEMP
sdarottv = xbmc.getInfoLabel('Skin.HasSetting(SdarotTV)') #TEMP
validation = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION)')
validation2 = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION2)')
validation5 = xbmc.getInfoLabel('Skin.String(VALIDATION5)')
widget = xbmc.getInfoLabel('Skin.HasSetting(Widget)')
'''---------------------------'''

'''------------------------------
---SKIN-STRINGS------------------
------------------------------'''
customvar = xbmc.getInfoLabel('Skin.String(General_CustomVAR)')
listitemtvshowtitlestr = xbmc.getInfoLabel('Skin.String(ListItemTVShowTitle)')
listitemgenrestr = xbmc.getInfoLabel('Skin.String(ListItemGenre)')
listitemdurationstr = xbmc.getInfoLabel('Skin.String(ListItemDuration)')
listitemratingstr = xbmc.getInfoLabel('Skin.String(ListItemRating)')
listitemyearstr = xbmc.getInfoLabel('Skin.String(ListItemYear)')
messagescustom = xbmc.getInfoLabel('Skin.String(MessagesCustom)')
moviesestartup = xbmc.getInfoLabel('Skin.String(moviesestartup)')
musiclinkstr = xbmc.getInfoLabel('Skin.String(MusicLink)')
pingnow = xbmc.getInfoLabel('Skin.String(Ping_Now)')
pingrate = xbmc.getInfoLabel('Skin.String(Ping_Rate)')
settingslevel = xbmc.getInfoLabel('Skin.String(SettingsLevel)')
tvshowsestartup = xbmc.getInfoLabel('Skin.String(tvshowsestartup)')

'''---------------------------'''

'''------------------------------
---LISTITEM-------------
------------------------------'''
listitemtvshowtitle = xbmc.getInfoLabel('ListItem.TVShowTitle')
listitemtitle = xbmc.getInfoLabel('ListItem.Title')
listitemyear = xbmc.getInfoLabel('ListItem.Year')
listitemrating = xbmc.getInfoLabel('ListItem.Rating')
listitemgenre = xbmc.getInfoLabel('ListItem.Genre')
listitemduration = xbmc.getInfoLabel('ListItem.Duration')
listitemseason = xbmc.getInfoLabel('ListItem.Season')
listitemepisode = xbmc.getInfoLabel('ListItem.Episode')
listitempath = xbmc.getInfoLabel('ListItem.Path')
listitemyear = xbmc.getInfoLabel('ListItem.Year')
'''---------------------------'''
