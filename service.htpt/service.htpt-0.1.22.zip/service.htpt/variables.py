'''------------------------------
---shared_variables--------------
------------------------------'''
import xbmcaddon, sys, os
servicehtptPath          = xbmcaddon.Addon('service.htpt').getAddonInfo("path")
sharedlibDir = os.path.join(servicehtptPath, 'resources', 'lib', 'shared')
sys.path.insert(0, sharedlibDir)
from shared_variables import *
'''---------------------------'''
#libDir = os.path.join(addonPath, 'resources', 'lib')
#sys.path.insert(0, libDir)

'''------------------------------
---service.htpt------------------
------------------------------'''
getsetting         = xbmcaddon.Addon().getSetting
setsetting         = xbmcaddon.Addon().setSetting
addonName          = xbmcaddon.Addon().getAddonInfo("name")
addonString        = xbmcaddon.Addon().getLocalizedString
addonPath = xbmcaddon.Addon().getAddonInfo("path").decode("utf-8")

printfirst = addonName + ": !@# "
'''---------------------------'''
General_Connected = getsetting('General_Connected')
General_CurTrigger = getsetting('General_CurTrigger')
General_Timer = getsetting('General_Timer')
Time_Start = getsetting('Time_Start')
Time_Pass = getsetting('Time_Pass')
'''---------------------------'''
Skin_UpdateCount = getsetting('Skin_UpdateCount')
Skin_UpdateCount2 = getsetting('Skin_UpdateCount2')
Skin_UpdateTimer = getsetting('Skin_UpdateTimer')
Skin_Update = getsetting('Skin_Update')
Skin_UpdateDate = getsetting('Skin_UpdateDate')
Skin_UpdateLog = getsetting('Skin_UpdateLog')
Skin_Version = getsetting('Skin_Version')
Skin_Check = getsetting('Skin_Check')
'''---------------------------'''
Ping_Now = getsetting('Ping_Now')
Ping_Rate = getsetting('Ping_Rate')
Ping_1 = getsetting('Ping_1')
Ping_2 = getsetting('Ping_2')
Ping_3 = getsetting('Ping_3')
Ping_4 = getsetting('Ping_4')
Ping_5 = getsetting('Ping_5')
Ping_6 = getsetting('Ping_6')
Ping_7 = getsetting('Ping_7')
Ping_8 = getsetting('Ping_8')
Ping_9 = getsetting('Ping_9')
Ping_10 = getsetting('Ping_10')
'''---------------------------'''




'''------------------------------
---DEFAULT-----------------------
------------------------------'''




'''------------------------------
---ACCOUNTS----------------------
------------------------------'''
Account1_Active = xbmc.getInfoLabel('Skin.HasSetting(Account1_Active)')
Account1_Period = xbmc.getInfoLabel('Skin.String(Account1_Period)')
Account1_EndDate = xbmc.getInfoLabel('Skin.String(Account1_EndDate)')
Account2_Active = xbmc.getInfoLabel('Skin.HasSetting(Account2_Active)')
Account2_Period = xbmc.getInfoLabel('Skin.String(Account2_Period)')
Account2_EndDate = xbmc.getInfoLabel('Skin.String(Account2_EndDate)')

'''------------------------------
---System.-----------------------
------------------------------'''
systeminternetstate = xbmc.getInfoLabel('System.InternetState')
systemuptime = xbmc.getInfoLabel('System.Uptime')
systemtotaluptime = xbmc.getInfoLabel('System.TotalUptime')
systemcputemperature = xbmc.getInfoLabel('System.CPUTemperature')
screenresolution = xbmc.getInfoLabel('System.ScreenResolution')
dhcpaddress = xbmc.getInfoLabel('Network.DHCPAddress')
macaddress = xbmc.getInfoLabel('Network.MacAddress')
systemuptime2 = xbmc.getInfoLabel('System.Uptime') + " / " + xbmc.getInfoLabel('System.TotalUptime') 
freespace2 = xbmc.getInfoLabel('System.TotalSpace') + " / " + xbmc.getInfoLabel('System.FreeSpacePercent')
if xbmc.getCondVisibility('System.HasAddon(service.htpt)'): htptversion = xbmc.getInfoLabel('System.AddonVersion(skin.htpt)') + "+"
elif xbmc.getCondVisibility('!System.HasAddon(service.htpt)'): htptversion = xbmc.getInfoLabel('System.AddonVersion(skin.htpt)') + "-"
buildversion = xbmc.getInfoLabel('System.BuildVersion')
htptdebugversion = xbmc.getInfoLabel('System.AddonVersion(script.htpt.debug)')
htptserviceversion = xbmc.getInfoLabel('system.AddonVersion(service.htpt)')
htpthelpversion = xbmc.getInfoLabel('System.AddonVersion(service.htpt.help)')
htpthomebuttonsversion = xbmc.getInfoLabel('System.AddonVersion(script.htpt.homebuttons)')
htptremoteversion = xbmc.getInfoLabel('System.AddonVersion(script.htpt.remote)')
htptrefreshversion = xbmc.getInfoLabel('System.AddonVersion(script.htpt.refresh)')
htptfixversion = xbmc.getInfoLabel('System.AddonVersion(service.htpt.fix)')
htptskinversion = xbmc.getInfoLabel('System.AddonVersion(skin.htpt)')

'''------------------------------
---DATES-----------------------
------------------------------'''
xbmc.sleep(200)
import datetime
datenow = datetime.date.today()
datenowS = str(datenow)
daynow = datenow.strftime("%a")
daynowS = str(daynow)
timenow = datetime.datetime.now()
timenowS = timenow.strftime("%H:%M")
timenow2 = timenow.strftime("%H:%M")
timenow3 = timenow.strftime("%H")
timenow2S = str(timenow2)
timenow3S = str(timenow3)
timenow3N = int(timenow3S)
#timenow = datenow.strftime("%I:%M:%S %p")
if timenow3N > 03 and timenow3N < 12: timezone = "A"
elif timenow3N > 11 and timenow3N < 20: timezone = "B"
elif timenow3N > 19 or timenow3N < 04: timezone = "C"
if admin: print printfirst + datenowS + space + daynowS + space + timenow2S + space + "timezone: " + timezone

'''------------------------------
---CONTAINER---------------------
------------------------------'''
containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
container120numitems = xbmc.getInfoLabel('Container(120).NumItems') #DialogSubtitles
containernumitems = xbmc.getInfoLabel('Container.NumItems')
viewmode = xbmc.getInfoLabel('Container.Viewmode')



'''------------------------------
---Network.----------------------
------------------------------'''
networkgatewayaddress = xbmc.getInfoLabel('Network.GatewayAddress')
networkipaddress = xbmc.getInfoLabel('Network.IPAddress')
'''------------------------------
---VIDEO-------------------------
------------------------------'''
playerhasvideo = xbmc.getCondVisibility('Player.HasVideo')
playerpaused = xbmc.getCondVisibility('Player.Paused')
videoplayerhassubtitles = xbmc.getCondVisibility('VideoPlayer.HasSubtitles')
playercache = xbmc.getInfoLabel('Player.CacheLevel')
playertitle = xbmc.getInfoLabel('Player.Title')
playerhasmedia = xbmc.getCondVisibility('Player.HasMedia')
'''---------------------------'''	
playertime = xbmc.getInfoLabel("Player.Time(hh)") + xbmc.getInfoLabel("Player.Time(mm)") + xbmc.getInfoLabel("Player.Time(ss)")
playertimeremaining = xbmc.getInfoLabel("Player.TimeRemaining(hh)") + xbmc.getInfoLabel("Player.TimeRemaining(mm)") + xbmc.getInfoLabel("Player.TimeRemaining(ss)")
playerduration = xbmc.getInfoLabel("Player.Duration(hh)") + xbmc.getInfoLabel("Player.Duration(mm)") + xbmc.getInfoLabel("Player.Duration(ss)")

'''---------------------------'''
playlistlength = xbmc.getInfoLabel('Playlist.Length(video)')
playlistlengthN = int(playlistlength)
playlistposition = xbmc.getInfoLabel('Playlist.Position(video)')
playlistpositionN = int(playlistposition)
'''---------------------------'''
videoplayertitle = xbmc.getInfoLabel('VideoPlayer.Title')
videoplayerseason = xbmc.getInfoLabel('VideoPlayer.Season')
videoplayertvshowtitle = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
videoplayeryear = xbmc.getInfoLabel('VideoPlayer.Year')
videoplayertagline = xbmc.getInfoLabel('VideoPlayer.Tagline')
videoplayercountry = xbmc.getInfoLabel('VideoPlayer.Country')
videoplayerseason = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
#videoplayerseason = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
#videoplayerseason = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
#videoplayerseason = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
videoplayercontentMOVIE = xbmc.getCondVisibility('VideoPlayer.Content(movies)')
videoplayercontentTV = xbmc.getCondVisibility('VideoPlayer.Content(tvshows)')
videoplayercontentSEASON = xbmc.getCondVisibility('VideoPlayer.Content(seasons)')
videoplayercontentEPISODE = xbmc.getCondVisibility('VideoPlayer.Content(episodes)')



'''------------------------------
---PATH--------------------------
------------------------------'''
israeltvhome = 'plugin://plugin.video.sdarot.tv/'
videorootpath = 'library://video/'

'''------------------------------
---MIXED-------------------------
------------------------------'''
hasinternet = systeminternetstate != "" and networkipaddress != "" and not "169.254." in networkipaddress and (connected or systemplatformwindows)
'''------------------------------
---CONTROL-----------------------
------------------------------'''
cancelbutton = xbmc.getCondVisibility('Control.HasFocus(10)') and xbmc.getCondVisibility('Window.IsActive(DialogProgress.xml)')
autoplaypausebutton = (xbmc.getCondVisibility('Window.IsVisible(Home.xml)') and xbmc.getCondVisibility('Control.HasFocus(9093)')) or (xbmc.getCondVisibility('Window.IsVisible(MyVideoNav.xml)') and xbmc.getCondVisibility('Control.HasFocus(111)'))
debugbutton = xbmc.getCondVisibility('Container(50).HasFocus(5)') or (xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(102)'))
controlisvisible311 = xbmc.getCondVisibility('Control.IsVisible(311)') or xbmc.getCondVisibility('Control.HasFocus(340)')
controlisvisible311S = str(controlisvisible311)
controlisvisible312 = xbmc.getCondVisibility('Control.IsVisible(312)') or xbmc.getCondVisibility('Control.HasFocus(341)')
controlisvisible312S = str(controlisvisible312)
controlgetlabel100 = xbmc.getInfoLabel('Control.GetLabel(100)') #DialogSubtitles Service Name
var700100 = xbmc.getInfoLabel('Control.GetLabel(700100)')

	
'''------------------------------
---$LOCALIZE--------------------
------------------------------'''
truestr = xbmc.getInfoLabel('$LOCALIZE[20122]')
cancelstr = xbmc.getInfoLabel('$LOCALIZE[222]')
trialstr = xbmc.getInfoLabel('$LOCALIZE[70001]') #Trial
trial2str = xbmc.getInfoLabel('$LOCALIZE[70002]') #TrialRenew
trial3str = xbmc.getInfoLabel('$LOCALIZE[70003]') #TrialEnd (PREVIOUSLY-TrailEnd)
verrorstr = xbmc.getInfoLabel('$VAR[VERROR]')
id6v1str = xbmc.getInfoLabel('$LOCALIZE[70014]')
id6v2str = xbmc.getInfoLabel('$LOCALIZE[70015]')
id6v3str = xbmc.getInfoLabel('$LOCALIZE[70016]')
airplaystr1 = xbmc.getInfoLabel('$LOCALIZE[1273]')
airplaystr2 = 'AirPlay'
airplaystr3 = xbmc.getInfoLabel('$LOCALIZE[1270]')
airplaystr4 = xbmc.getInfoLabel('Skin.String(AirPlay2)')
busystr = xbmc.getInfoLabel('$LOCALIZE[503]')
numinumistr = xbmc.getInfoLabel('$LOCALIZE[79068]')
settingslevelstr1 = xbmc.getInfoLabel('$LOCALIZE[10036]')
settingslevelstr2 = xbmc.getInfoLabel('$LOCALIZE[10037]')
var70000 = xbmc.getInfoLabel('$LOCALIZE[70000]')
todaystr = xbmc.getInfoLabel('$LOCALIZE[33006]')
'''------------------------------
---ID----------------------------
------------------------------'''
'''idstr = USERNAME EN , id1str = USERNAME HE, id2str = INSTALLATION DATE, id3str = WARRENTY END, id4str = ADDRESS, id5str = TELEPHONE NUMBER, id6str = PAYMENT TERMS, id7str = QUESTION, id8str = TECHNICAL NAME, id9str = CODE RED, id10str = HTPT'S MODEL, ID11 = MAC1, ID12 = MAC2'''
idstr = xbmc.getInfoLabel('Skin.String(ID)')
id1str = xbmc.getInfoLabel('Skin.String(ID1)')
id2str = xbmc.getInfoLabel('Skin.String(ID2)')
id3str = xbmc.getInfoLabel('Skin.String(ID3)')
id4str = xbmc.getInfoLabel('Skin.String(ID4)')
id5str = xbmc.getInfoLabel('Skin.String(ID5)')
id6str = xbmc.getInfoLabel('Skin.String(ID6)')
id7str = xbmc.getInfoLabel('Skin.String(ID7)')
id8str = xbmc.getInfoLabel('Skin.String(ID8)')
id9str = xbmc.getInfoLabel('Skin.String(ID9)')
id10str = xbmc.getInfoLabel('Skin.String(ID10)')
id11str = xbmc.getInfoLabel('Skin.String(ID11)')
id12str = xbmc.getInfoLabel('Skin.String(ID12)')
id60str = xbmc.getInfoLabel('Skin.String(ID60)')
''''''
idnamestr = xbmc.getInfoLabel('$LOCALIZE[1014]')
id2namestr = xbmc.getInfoLabel('$LOCALIZE[70010]')
id3namestr = xbmc.getInfoLabel('$LOCALIZE[70011]')
id4namestr = xbmc.getInfoLabel('$LOCALIZE[19115]')
id5namestr = xbmc.getInfoLabel('$LOCALIZE[75006]')
id6namestr = xbmc.getInfoLabel('$LOCALIZE[70012]')
id60namestr = xbmc.getInfoLabel('$LOCALIZE[70012]')
id7namestr = 'Question'
id8namestr = xbmc.getInfoLabel('$LOCALIZE[70013]')
id9namestr = 'CODE RED'
id10namestr = xbmc.getInfoLabel('$LOCALIZE[79031]')
id11namestr = 'MAC1 (LAN)'
id12namestr = 'MAC2 (WLAN)'
''''''
fixip = xbmc.getInfoLabel('Skin.String(fixip)')
trial = xbmc.getInfoLabel('Skin.HasSetting(Trial)')
trial2 = xbmc.getInfoLabel('Skin.HasSetting(Trial2)')
trialdate = xbmc.getInfoLabel('Skin.String(TrialDate)')
trialdate2 = xbmc.getInfoLabel('Skin.String(TrialDate2)')

idtrial = 'htptuser'
#idtrial = 'htptuser27'
idpstr = xbmc.getInfoLabel('$LOCALIZE[79246]')
#idp2str = xbmc.getInfoLabel('$LOCALIZE[79246]')
idp2str = xbmc.getInfoLabel('$LOCALIZE[79247]')

mac1str = xbmc.getInfoLabel('Skin.String(MAC1)')
mac2str = xbmc.getInfoLabel('Skin.String(MAC2)')
mac3str = xbmc.getInfoLabel('Skin.String(MAC3)')
verrorstr = xbmc.getInfoLabel('$VAR[VERROR]')
usb1str = xbmc.getInfoLabel('Skin.String(USB1)')
usb2str = xbmc.getInfoLabel('Skin.String(USB2)')
usb3str = xbmc.getInfoLabel('Skin.String(USB3)')
usb4str = xbmc.getInfoLabel('Skin.String(USB4)')
usb5str = xbmc.getInfoLabel('Skin.String(USB5)')