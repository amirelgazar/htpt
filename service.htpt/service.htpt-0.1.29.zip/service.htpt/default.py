import xbmc
import os, sys
import subprocess
import xbmcgui, xbmcaddon
import json

from variables import *
from modules import *
from shared_modules3 import get_params

printpoint = ""
'''---------------------------'''
params=get_params()
url=None
name=None
mode=None
iconimage=None
desc=None
num=None
'''---------------------------'''
try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try: mode=int(params["mode"])
except: pass
try: num=urllib.unquote_plus(params["num"])
except: pass
'''---------------------------'''

class main:
	'''---------------------------'''
	#setGeneral_ScriptON("0", General_ScriptON, str(mode))
	'''---------------------------'''
	if General_ScriptON != "true":
		if mode == None: pass
		elif mode == 1 or mode == 2 or mode == 3:
			'''------------------------------
			---SMART-KEYBOARD-SAVE-VALUE-----
			------------------------------'''
			printpoint = printpoint + "1"
			heading = xbmc.getInfoLabel('Control.GetLabel(311)')
			input = xbmc.getInfoLabel('Control.GetLabel(312)')
			if mode == 1:
				input2 = dialogkeyboard(input, heading, 0, '1', "", "")
				input2 = str(input2)
				'''------------------------------
				---SMART-KEYBOARD-SAVE-VALUE-----
				------------------------------'''
				if input2 != "skip":
					printpoint = printpoint + "2"
					setSkinSetting("0", 'smartkeyboardH0', input2)
					xbmc.sleep(1000) #time to set setting
					if not input2 in smartkeyboardHL:
						'''------------------------------
						---NEW-VALUE---------------------
						------------------------------'''
						printpoint = printpoint + "3"
						setSkinSetting("0", 'smartkeyboardH5', smartkeyboardH4)
						setSkinSetting("0", 'smartkeyboardH4', smartkeyboardH3)
						setSkinSetting("0", 'smartkeyboardH3', smartkeyboardH2)
						setSkinSetting("0", 'smartkeyboardH2', smartkeyboardH1)
						setSkinSetting("0", 'smartkeyboardH1', smartkeyboardH0)
						'''---------------------------'''
					else:
						'''------------------------------
						---EXIST-VALUE-------------------
						------------------------------'''
						printpoint = printpoint + "4"
						if input2 != smartkeyboardH1:
							if input2 == smartkeyboardH2:
								printpoint = printpoint + "5"
								setSkinSetting("0", 'smartkeyboardH1', input2)
								setSkinSetting("0", 'smartkeyboardH2', smartkeyboardH1)
								'''---------------------------'''
							elif input2 == smartkeyboardH3:
								printpoint = printpoint + "6"
								setSkinSetting("0", 'smartkeyboardH1', input2)
								setSkinSetting("0", 'smartkeyboardH3', smartkeyboardH1)
								'''---------------------------'''
							elif input2 == smartkeyboardH4:
								printpoint = printpoint + "7"
								setSkinSetting("0", 'smartkeyboardH1', input2)
								setSkinSetting("0", 'smartkeyboardH4', smartkeyboardH1)
								'''---------------------------'''
							elif input2 == smartkeyboardH5:
								printpoint = printpoint + "8"
								setSkinSetting("0", 'smartkeyboardH1', input2)
								setSkinSetting("0", 'smartkeyboardH5', smartkeyboardH1)
								'''---------------------------'''
							else: printpoint = printpoint + "9"
						else: printpoint = printpoint + "9"
						'''---------------------------'''
		
			elif mode == 2:
				'''------------------------------
				---SMART-KEYBOARD-COPY-----------
				------------------------------'''
				printpoint = printpoint + "1"
				keyboard.doModal()
				input2 = keyboard.getText()
				notification("input2: " + input2,"input: " + input,"",2000)
				setSkinSetting("0", "smartkeyboardC" + smartkeyboardPN, input2)
		else: printpoint = printpoint + "9"
	
	'''---------------------------'''
	#setGeneral_ScriptON("1", General_ScriptON, str(mode))
	'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "default.py" + space + "mode" + space2 + str(mode) + space + "LV" + space2 + printpoint + space + "General_ScriptON" + space2 + General_ScriptON
	'''---------------------------'''