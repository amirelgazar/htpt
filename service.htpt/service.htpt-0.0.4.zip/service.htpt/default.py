import xbmc, xbmcgui
import os, sys
import subprocess

'''OTHERS'''
systemplatformwindows = xbmc.getCondVisibility('system.platform.windows')

def bash(bashCommand,bashname):
	connected = xbmc.getInfoLabel('Skin.HasSetting(Connected)')
	connected2 = xbmc.getInfoLabel('Skin.HasSetting(Connected2)')
	connected3 = xbmc.getInfoLabel('Skin.HasSetting(Connected3)')
	'''run BASH commands'''
	if not systemplatformwindows:
		xbmc.sleep(40)
		process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
		output = process.communicate()[0]
		if bashname == "Connected":
			xbmc.executebuiltin('Skin.SetString(Test,'+ output +')')
			if "1 packets transmitted" in output:
				if not connected: xbmc.executebuiltin('Skin.ToggleSetting(Connected)')
			else:
				if connected: xbmc.executebuiltin('Skin.ToggleSetting(Connected)')
		if bashname == "Connected2":
			xbmc.executebuiltin('Skin.SetString(Test,'+ output +')')
			if not "packets:0" in output and "inet addr" in output:
				if not connected2: xbmc.executebuiltin('Skin.ToggleSetting(Connected2)')
			else:
				if connected2: xbmc.executebuiltin('Skin.ToggleSetting(Connected2)')
		if bashname == "Connected3":
			xbmc.executebuiltin('Skin.SetString(Test,'+ output +')')
			if not "packets:0" in output and "inet addr" in output:
				if not connected3: xbmc.executebuiltin('Skin.ToggleSetting(Connected3)')
			else:
				if connected3: xbmc.executebuiltin('Skin.ToggleSetting(Connected3)')
		'''ERROR 1020'''
		if bashname == "GUI1" and not "<skin>skin.htpt</skin>" in output:
			xbmc.executebuiltin('Notification($LOCALIZE[257]: 1020,$LOCALIZE[79505],2000)')
			os.system('sh /storage/.xbmc/addons/service.htpt/specials/scripts/copyskin.sh')

def updateskin(run):
	'''check for skin update'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	htptv = xbmc.getInfoLabel('Skin.String(HTPTv)')
	htptc = xbmc.getInfoLabel('System.AddonVersion(skin.htpt)')
	htptu = xbmc.getInfoLabel('Skin.HasSetting(HTPTu)')
	log = open('/storage/.xbmc/temp/xbmc.log', 'r')
	file = log.read()
	count = 0
	while count < 15 and not "FileManager: copy https://raw.githubusercontent.com/htpthtpt/htpt/master/skin.htpt/skin.htpt" in file and not xbmc.abortRequested:
		xbmc.sleep(1000)
		validationstartup('run')
		count += 1
		countS = str(count)
		if admin: xbmc.executebuiltin('Notification(Admin,UpdateSkin ('+ countS +'),1000)')
		log = open('/storage/.xbmc/temp/xbmc.log', 'r')
		file = log.read()
	log.close()
	count = 0
	while count < 10 and "FileManager: copy https://raw.githubusercontent.com/htpthtpt/htpt/" in file and not xbmc.abortRequested:
		xbmc.sleep(500)
		count += 1
		if count == 1:
			xbmc.executebuiltin('Notification($LOCALIZE[79200] '+ htptc +'),$LOCALIZE[20186],7000)')
			if admin: xbmc.executebuiltin('Notification(Admin,HTPTu on (1),1000)')
		if not htptu: xbmc.executebuiltin('Skin.ToggleSetting(HTPTu)')		
		message1 = xbmc.getInfoLabel('$LOCALIZE[79200]') + ' ' + htptc
		message2 = xbmc.getInfoLabel('$LOCALIZE[20186]')
		dialogok = xbmc.getCondVisibility('Window.IsVisible(DialogOk.xml)')
		startup_a = xbmc.getCondVisibility('Window.IsActive(Startup.xml)')
		if not dialogok:
			dialog = xbmcgui.Dialog()
			dialog.ok(message1,message2)		
	if htptv != htptc and not htptu:
		if admin: xbmc.executebuiltin('Notification(Admin,HTPTu on (2),1000)')
		xbmc.executebuiltin('Skin.ToggleSetting(HTPTu)')
def htptv(admin,systemidle3,playerhasvideo):
	if systemidle3 and not playerhasvideo:
		htptv = xbmc.getInfoLabel('Skin.String(HTPTv)')
		htptc = xbmc.getInfoLabel('System.AddonVersion(skin.htpt)')
		htptu = xbmc.getInfoLabel('Skin.HasSetting(HTPTu)')
		validation2 = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION2)')
		if htptu and htptv != htptc and not validation2:
			htptv = xbmc.getInfoLabel('Skin.String(HTPTv)')
			htptc = xbmc.getInfoLabel('System.AddonVersion(skin.htpt)')
			message1 = xbmc.getInfoLabel('$LOCALIZE[79201]') + ' ' + htptc
			#file = open('C:\Users\gal\AppData\Roaming\XBMC\addons\skin.htpt\changelog.txt', 'r')
			if not systemplatformwindows:
				log = open('/storage/.xbmc/addons/skin.htpt/changelog.txt', 'r')
				message2 = log.read()
			else: message2 = xbmc.getInfoLabel('$LOCALIZE[79202]')
			if admin: xbmc.executebuiltin('Notification(Admin,HTPTu off,1000)')
			xbmc.executebuiltin('Skin.ToggleSetting(HTPTu)')
			xbmc.executebuiltin('RunScript(script.toolbox,info=textviewer,header='+ message1 +',text='+ message2 +')')
			#dialog = xbmcgui.Dialog()
			#dialog.ok(message1,message2)
			xbmc.executebuiltin('Skin.SetString(HTPTv,'+ htptc +')')
def validationstartup(admin):
	validation = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION)')
	validation5 = xbmc.getInfoLabel('Skin.String(VALIDATION5)')
	count = 0
	if validation and validation5 != '0' and not xbmc.abortRequested:
		#if admin and count == 1: xbmc.executebuiltin('Notification(Admin,validationstartup)')
		xbmc.sleep(1000)
		startup_a = xbmc.getCondVisibility('Window.IsActive(Startup.xml)')
		loginscreen = xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)')
		validation = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION)')
		validation5 = xbmc.getInfoLabel('Skin.String(VALIDATION5)')
		
		if not startup_a and not loginscreen: xbmc.executebuiltin('ReplaceWindow(Startup.xml)')
class startup:
	if not systemplatformwindows:
		xbmc.executebuiltin('UpdateAddonRepos')
		#xbmc.executebuiltin('UpdateLocalAddons')
		os.system('sh /storage/.xbmc/addons/skin.htpt/specials/scripts/remote.sh')
		os.system('sh /storage/.xbmc/addons/skin.htpt/specials/scripts/copy2.sh')
		os.system('sh /storage/.xbmc/addons/skin.htpt/specials/scripts/genesis.sh')
		os.system('sh /storage/.xbmc/addons/skin.htpt/specials/scripts/genesis1.sh')
		os.system('sh /storage/.xbmc/addons/skin.htpt/specials/scripts/genesis2.sh')
		os.system('sh /storage/.xbmc/addons/skin.htpt/specials/scripts/genesis4.sh')
		updateskin('run')
class repeat:
	updateskincheck = 'false'
	count = 0
	while not xbmc.abortRequested:
		xbmc.sleep(1000)
		admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
		playerhasvideo = xbmc.getCondVisibility('Player.HasVideo')
		systemidle3 = xbmc.getCondVisibility('System.IdleTime(3)')
		if count < 10: count += 1
		elif count >= 10: count = 1
		countS = str(count)
		if admin: xbmc.executebuiltin('Skin.SetString(Test2,'+ countS +')')
		'''actions'''
		htptv(admin,systemidle3,playerhasvideo)
		validationstartup(admin)
		if systemidle3 and not systemplatformwindows:
			if count == 5 and not playerhasvideo: bash('cat /storage/.xbmc/userdata/guisettings.xml',"GUI1")
		
			'''network status'''
			bash('ping -W 1 -w 1 -4 -q www.google.co.il',"Connected")
			if count == 9:
				bash('ifconfig wlan0',"Connected2")
				xbmc.sleep(200)
				bash('ifconfig eth0',"Connected3")
	if xbmc.abortRequested:
		xbmc.executebuiltin('Notification($LOCALIZE[257]: 1070,abortRequested!!!,2000)')
		sys.exit()
		
		
#repeat()