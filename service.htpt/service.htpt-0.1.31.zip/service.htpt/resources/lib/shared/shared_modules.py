import xbmc, xbmcgui, xbmcaddon
import os, subprocess, sys
import fileinput

from variables import *
if admin: from shared_modules2 import *
xbmc.sleep(100)

def CreateZip(src, dst, filteron=[], filteroff=[], level=10000, append=False, ZipFullPath=False, temp=False):

	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	name = 'CreateZip'
	TypeError = "" ; extra = "" ; arcname = "" ; absname = "" ; dirname = "" ; files = "" ; printpoint = "" ; file = "" ; subdirs = "" ; subdir = "" ; temp__ = ".zip"
	if append == False: append_ = "w"
	else: append_ = "a"
	
	if temp == False: temp_ = temp__
	else: temp_ = "_temp.zip"
	
	import zipfile
	zf = zipfile.ZipFile("%s%s" % (dst, temp_), append_, zipfile.ZIP_DEFLATED)
	abs_src = os.path.abspath(src)
	
	for dirname, subdirs, files in os.walk(src):

		printpoint = "" ; extra2 = ""
		
		subdir = dirname.replace(src, "")
		
		try: subdir2 = find_string(subdir, subdir[:1], "/") ; subdir2 = subdir2.replace("/","")
		except: subdir2 = "?"
		
		subdir_level = subdir.count("/")
		
		if not os.path.exists(dst+temp_):
			zf.close()
			dialogok("Error Abort","","","")
			sys.exit()
		
		if subdir_level <= level:
			printpoint = printpoint + "1"
			if filteron == [] or subdir in filteron or subdir == "" or subdir2 in filteron:
				printpoint = printpoint + "2"
				if filteroff == [] or (not subdir in filteroff and not subdir2 in filteroff):
					printpoint = printpoint + "3"
					for filename in files:
						printpoint = printpoint + "4" ; extra2 = extra2 + space + "filename" + space2 + filename
						if filteron == [] or filename in filteron or subdir in filteron or subdir2 in filteron:
							printpoint = printpoint + "5"
							if filteroff == [] or not filename in filteroff:
								printpoint = printpoint + "6"
								absname = os.path.abspath(os.path.join(dirname, filename))
								arcname = absname[len(abs_src) + 1:]
								arcname1dir = find_string(arcname, arcname[:2], "/")
								print 'zipping %s as %s' % (os.path.join(dirname, filename),arcname)
								#if filteron == [] or arcname in filteron:
								#if filteroff == [] or not arcname in filteroff:
								printpoint = printpoint + "7"
								if ZipFullPath == False: zf.write(absname, arcname)
								else: zf.write(absname)
		else: printpoint = printpoint + "9"				
		if admin: print "Admin-Test_LV" + printpoint + space + "dirname" + space2 + str(dirname) + space + "subdir" + space2 + str(subdir) + space + "subdir_level" + space2 + str(subdir_level) + space + "subdir2" + space2 + str(subdir2) + space + "files" + space2 + str(files) + space + "file" + space2 + str(file) + extra2
	
	#except Exception, TypeError:
	#TypeError = str(TypeError) + space + "os.walk(src)" + space2 + str(os.walk(src)) + space + "src" + space2 + str(src) + space + "dirname" + space2 + dirname + space + "files" + space2 + str(files)
	#notification("Error 1050","","",1000)
	#continue

	zf.close()
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if TypeError != "": extra = newline + "TypeError:" + space2 + str(TypeError)
	print printfirst + name + "_LV" + printpoint + space + "src" + space2 + str(src) + space + "dst" + space2 + str(dst) + space + "filteron" + space2 + str(filteron) + space + "filteroff" + space2 + str(filteroff) + space + "level" + space2 + str(level) + space + newline + "arcname" + space2 + str(arcname) + space + "absname" + space2 + str(absname) + space + "abs_src" + space2 + str(abs_src) + space + "dirname" + space2 + str(dirname) + space + "files" + space2 + str(files) + space + "subdirs" + space2 + str(subdirs) + space + "subdir" + space2 + str(subdir) + space + extra
	'''---------------------------'''
	if append == "End" and temp == True:
		xbmc.sleep(500)
		bash('mv -f '+dst+''+temp_+' '+dst+''+temp__+'',"End Zip")
		notification("Zip File Ready!", dst + temp__, "", 2000)
		'''---------------------------'''
		return 'ok'
		
	elif temp != True and append == False: return 'ok'
	
def ExtractAll(source, output):
	name = 'ExtractAll'
	printpoint = ""
	TypeError = ""
	extra = ""
	if ".zip" in source:
		import zipfile
		try:
			zin = zipfile.ZipFile(source, 'r')
			zin.extractall(output)
			zin.close()
			printpoint = printpoint + "7"
		except Exception, TypeError:
			printpoint = printpoint + "9"
	
	elif ".tar" in source:
		import tarfile
		try:
			tar = tarfile.open(source)
			#bash('mv -f '+ source +' '+ output +'',"move tar") #UNTESTED
			tar.extractall(output)
			tar.close()
			printpoint = printpoint + "7"
		except Exception, TypeError:
			printpoint = printpoint + "9"
	
	elif ".7z" in source:
		#NOT WORKING!
		import gzip
		f_in = open(source, 'rb')
		f_out = gzip.open(output, 'wb')
		f_out.writelines(f_in)
		f_out.close()
		f_in.close()
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if TypeError != "": extra = newline + "TypeError:" + space2 + str(TypeError)
	print printfirst + name + "_LV" + printpoint + space + "source" + space2 + source + space + "output" + space2 + output + space + extra
	
	'''---------------------------'''
	if "7" in printpoint: return True
	else: return False
	
def DownloadFile(url, filename, downloadpath, extractpath, silent=False):
	name = 'DownloadFile'
	downloadpath2 = os.path.join(downloadpath, filename)
	
	from commondownloader import *
	
	returned = doDownload(url, downloadpath2, filename, "", "", "", silent)
	
	if returned == "ok":
		#dialogok("download done","","","")
		#urllib.urlretrieve(url, downloadpath2) #, reporthook=dlProgress
		ExtractAll(downloadpath2, extractpath)
	
	try:
		if downloadpath2 != downloadpath: os.remove(downloadpath2)
	except:
		pass
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + name + space + "url" + space2 + url + space + "returned" + space2 + str(returned)
	'''---------------------------'''
	
def addonsettings(name, addon,skinsettingS, skinsetting2S, usernameS, passwordS, set3,opt1,opt2,opt3):
	'''------------------------------
	---SET-USERNAME-AND-PASSWORD-----
	------------------------------'''
	getsetting_custom          = xbmcaddon.Addon(addon).getSetting
	setsetting_custom          = xbmcaddon.Addon(addon).setSetting
	
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	skinsetting = xbmc.getInfoLabel('Skin.HasSetting('+ skinsettingS +')')
	skinsetting2 = xbmc.getInfoLabel('Skin.String('+ skinsetting2S +')')
	#if setting_custom == str20122.encode('utf-8'): setting_custom = "true"
	#else: setting_custom = "false"
	try: skinsetting2N = int(skinsetting2)
	except: skinsetting2N = 0
	username = getsetting_custom(usernameS)
	password = getsetting_custom(passwordS)
	setting3 = getsetting_custom(set3)
	printpoint = ""
	'''---------------------------'''
	if not id40str:
		if (skinsetting or id9str == 'Trial' or id2str == datenowS) and usernameS != "" and passwordS != "":
			if admin: notification("test0","","",1000)
			if ('htpt' in username and not "finalmakerr" in idstr) and idstr != username and id9str != 'Trial' and id2str != datenowS:
				'''------------------------------
				---SET-DEFAULT-------------------
				------------------------------'''
				setsetting_custom(usernameS,idstr)
				setsetting_custom(passwordS,idpstr)
				printpoint = printpoint + "1"
				if admin: notification("test1","","",1000)
				'''---------------------------'''
			elif id9str == 'Trial' or id2str == datenowS:
				'''------------------------------
				---SET-TRIAL---------------------
				------------------------------'''
				setsetting_custom(usernameS,idtrial)
				setsetting_custom(passwordS,idp2str)
				printpoint = printpoint + "2"
				if admin: notification("test2","","",1000)
				'''---------------------------'''
			elif skinsetting and ((username == "" or password == "") or skinsetting2 == "0"):
				'''------------------------------
				---SET-NONE----------------------
				------------------------------'''
				setsetting_custom(usernameS,"")
				setsetting_custom(passwordS,"")
				printpoint = printpoint + "5"
				if admin: notification("test1.2","","",1000)
				'''---------------------------'''
			elif skinsetting:
				'''------------------------------
				---NO-CHANGES--------------------
				------------------------------'''
				printpoint = printpoint + "6"
				if admin: notification("test1.3","","",1000)
				'''---------------------------'''
		else:
			'''------------------------------
			---NO-ACCOUNT-OR-TRIAL-----------
			------------------------------'''
			daynowS = get_daynow(1)
			timezone = get_timenow(1)
			General_TimeZone = getsetting('General_TimeZone')
			if name == 'REALDEBRID' and (daynowS == opt1 or General_TimeZone != opt2):
				'''------------------------------
				---SET-NONE----------------------
				------------------------------'''
				setsetting_custom(usernameS,"")
				setsetting_custom(passwordS,"")
				printpoint = printpoint + "3"
				'''---------------------------'''
			else:
				'''------------------------------
				---SET-DEFAULT-------------------
				------------------------------'''
				setsetting_custom(usernameS,idstr)
				setsetting_custom(passwordS,idpstr)
				printpoint = printpoint + "4"
				'''---------------------------'''
				
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if printpoint == "0": print printfirst + "addonsettings LV_0" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "?"
	if printpoint == "1": print printfirst + "addonsettings LV_1" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "RESET"
	elif printpoint == "2": print printfirst + "addonsettings LV_2" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "Trial / DATENOW"
	elif printpoint == "3": print printfirst + "addonsettings LV_3" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "NONE" + space + "ID: " + idstr + space + "daynowS" + space2 + daynowS + space + "timenow3S" + space2 + timenow3S + space + "datenowS" + space2 + datenowS + space + "timezone" + space2 + timezone
	elif printpoint == "4": print printfirst + "addonsettings LV_4" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "DEFAULT" + space + "ID: " + idstr + space + "timezone" + space2 + timezone
	elif printpoint == "5": print printfirst + "addonsettings LV_5" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "skinsetting2" + space2 + skinsetting2 + "UNREGISTER"
	elif printpoint == "6": print printfirst + "addonsettings LV_6" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "REGISTERED"
	elif printpoint == "": print printfirst + "addonsettings LV_0-Error?"
	'''---------------------------'''
	
def addonsettings2(addon,set1,set1v,set2,set2v,set3,set3v,set4,set4v,set5,set5v):
	'''------------------------------
	---SET-ADDON-SETTING-5-----------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	getsetting_custom          = xbmcaddon.Addon(addon).getSetting
	setsetting_custom          = xbmcaddon.Addon(addon).setSetting

	setting1 = getsetting_custom(set1)
	setting2 = getsetting_custom(set2)
	setting3 = getsetting_custom(set3)
	setting4 = getsetting_custom(set4)
	setting5 = getsetting_custom(set5)
	
	checkChange = "false"
	'''---------------------------'''
	if set1 != "" and set1v != setting1:
		setsetting_custom(set1,set1v)
		if checkChange != "true": checkChange = "true"
	if set2 != "" and set2v != setting2:
		setsetting_custom(set2,set2v)
		if checkChange != "true": checkChange = "true"
	if set3 != "" and set3v != setting3:
		setsetting_custom(set3,set3v)
		if checkChange != "true": checkChange = "true"
	if set4 != "" and set4v != setting4:
		setsetting_custom(set4,set4v)
		if checkChange != "true": checkChange = "true"
	if set5 != "" and set5v != setting5:
		setsetting_custom(set5,set5v)
		if checkChange != "true": checkChange = "true"
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if checkChange == "true": print printfirst + "addonsettings2 " + addon + space + set1 + space2 + set1v + space + set2 + space2 + set2v + space + set3 + space2 + set3v + space + set4 + space2 + set4v + space + set5 + space2 + set5v + space
	'''---------------------------'''

def checkAddon_Update(admin, Addon_Update, Addon_Version, Addon_UpdateDate, Addon_UpdateLog):
	from variables import addonVersion
	#addonVersion          = xbmcaddon.Addon().getAddonInfo("version")
	#reload(addonVersion)
	#notification(addonVersion,"","",5000)
	if "plugin." in addonID:
		setsetting_custom1(addonID,'Addon_UpdateLog',"true")
		Addon_UpdateLog = "true"
		'''---------------------------'''
	if Addon_Update != "true" or (Addon_Update == "true" and Addon_Version == addonVersion):
		'''------------------------------
		---Addon_Update-(NEW-ONLY)--------
		------------------------------'''
		Addon_Update = setAddon_Update(admin, addonVersion, Addon_Version, Addon_Update)
		'''---------------------------'''
	
	if Addon_Update == "true":
		'''------------------------------
		---setAddon_Version---------------
		------------------------------'''
		Addon_Version = setAddon_Version(admin, addonVersion, Addon_Version)
		'''---------------------------'''
		
	if Addon_Update == "true" or Addon_UpdateDate == "":
		'''------------------------------
		---setAddon_UpdateDate-(NEW-ONLY)-
		------------------------------'''
		Addon_UpdateDate = setAddon_UpdateDate(admin, addonVersion, Addon_Version, Addon_Update, Addon_UpdateDate)
		'''---------------------------'''
	
	if Addon_Version == addonVersion and Addon_UpdateLog == "true" and Addon_UpdateDate != "":
		'''------------------------------
		---Addon_UpdateLog----------------
		------------------------------'''
		dialogokW = xbmc.getCondVisibility('Window.IsVisible(DialogOk.xml)')
		dialogselectW = xbmc.getCondVisibility('Window.IsVisible(DialogSelect.xml)')
		dialogprogressW = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
		dialogbusyW = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
		dialogtextviewerW = xbmc.getCondVisibility('Window.IsVisible(DialogTextViewer.xml)')
		startupW = xbmc.getCondVisibility('Window.IsVisible(Startup.xml)')
		custom1191W = xbmc.getCondVisibility('Window.IsVisible(Custom1191.xml)')
		if not dialogokW and not dialogselectW and not dialogprogressW and not dialogbusyW and not startupW and not dialogtextviewerW and not custom1191W:
			from variables import datenowS
			if datenowS != "": #PREVENT RANDOM BUG WITH datetime
				setAddon_UpdateLog(admin, Addon_Version, Addon_UpdateDate, datenowS)
				'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "checkAddon_Update" + space2 + "Addon_Update" + space2 + Addon_Update + space + "Addon_Version" + space2 + Addon_Version + space + "addonVersion" + space2 + addonVersion + space + "Addon_UpdateDate" + space2 + Addon_UpdateDate + space + "Addon_UpdateLog" + space2 + Addon_UpdateLog
	'''---------------------------'''
				
def setAddon_Update(admin, addonVersion, Addon_Version, Addon_Update):
	'''------------------------------
	---CHECK-FOR-FIX-UPDATE----------
	------------------------------'''
	Addon_Update2 = Addon_Update
	if Addon_Version != addonVersion and Addon_Update == "false":
		Addon_Update2 = "true"
		setsetting('Addon_UpdateLog',"true")
		'''---------------------------'''
	else:
		Addon_Update2 = "false"
		'''---------------------------'''
		
	if Addon_Update != Addon_Update2: setsetting('Addon_Update',Addon_Update2)
	'''---------------------------'''
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin and Addon_Update != Addon_Update2: print printfirst + "setAddon_Update" + space2 + Addon_Update + " - " + Addon_Update2
	'''---------------------------'''	
	return Addon_Update2

def setAddon_Version(admin, addonVersion, Addon_Version):
	'''------------------------------
	---CHECK-FOR-ADDON-UPDATE-2------
	------------------------------'''
	Addon_Version2 = Addon_Version
	'''---------------------------'''
	if Addon_Version != addonVersion:
		Addon_Version2 = addonVersion
		setsetting('Addon_Version',Addon_Version2)
		'''---------------------------'''	
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if Addon_Version != addonVersion or admin: print printfirst + "setAddon_Version" + space2 + Addon_Version + " - " + Addon_Version2
	'''---------------------------'''
	return Addon_Version2
		
def setAddon_UpdateDate(admin, addonVersion, Addon_Version, Addon_Update, Addon_UpdateDate):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	from variables import datenowS
	Addon_UpdateDate2 = Addon_UpdateDate
	'''---------------------------'''
	if Addon_UpdateDate != datenowS:
		Addon_UpdateDate2 = datenowS
		setsetting('Addon_UpdateDate',Addon_UpdateDate2)
		'''---------------------------'''

	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if Addon_UpdateDate != datenowS or admin: print printfirst + "setAddon_UpdateDate" + space2 + Addon_UpdateDate + " - " + Addon_UpdateDate2
	'''---------------------------'''
	return Addon_UpdateDate2
	
def setAddon_UpdateLog(admin, Addon_Version, Addon_UpdateDate, datenowS):	
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	from variables import addonName2
	printpoint = ""
	number2S = ""
	datenowD = stringtodate(datenowS,'%Y-%m-%d')
	datedifferenceD = stringtodate(Addon_UpdateDate,'%Y-%m-%d')
	datedifferenceS = str(datedifferenceD)
	if "error" in [datenowD, datedifferenceD]: printpoint = printpoint + "9"
	try:
		number2 = datenowD - datedifferenceD
		number2S = str(number2)
		printpoint = printpoint + "2"
		'''---------------------------'''
	except:
		printpoint = printpoint + "9"
		'''---------------------------'''
	if not "9" in printpoint:
		printpoint = printpoint + "4"
		if "day," in number2S: number2S = number2S.replace(" day, 0:00:00","",1)
		elif "days," in number2S: number2S = number2S.replace(" days, 0:00:00","",1)
		else: number2S = "0"
		if admin: notification("number2S:" + number2S,"","",2000)
		number2N = int(number2S)
		'''---------------------------'''
		#header = '[COLOR=Yellow]' + addonString(304).encode('utf-8') + " - " + addonVersion + '[/COLOR]'
		if number2N == 0: header = '[COLOR=Yellow]' + str79311 % (addonName2) + space + str72101 + " - " + Addon_Version + '[/COLOR]'
		elif number2N == 1: header = '[COLOR=Green]' + str79311 % (addonName2) + space + str72102 + " - " + Addon_Version + '[/COLOR]'
		elif number2N <= 7: header = '[COLOR=Purple]' + str79311 % (addonName2) + space + str72103 + " - " + Addon_Version + '[/COLOR]'
		else: header = ""
		'''---------------------------'''
		log = open(addonPath + "/" + 'changelog.txt', 'r')
		message2 = log.read()
		log.close()
		message2S = str(message2)
		message3 = message2[0:8000]
		message3 = '"' + message3 + '"'
		message3S = str(message3)
		if header != "":
			w = TextViewer_Dialog('DialogTextViewer.xml', "", header=header, text=message2)
			w.doModal()
			'''---------------------------'''
		setsetting('Addon_UpdateLog',"false")
		#setsetting_custom1('service.htpt','Skin_UpdateLog',"false")
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "setAddon_UpdateLog_LV" + printpoint + space2 + "Addon_UpdateDate" + space2 + Addon_UpdateDate + " - " + datenowS + space + "(" + number2S + ")" + space + "Addon_UpdateLog" + space2 + Addon_UpdateLog
	'''---------------------------'''

def bash(bashCommand,bashname):
	'''------------------------------
	---RUN-BASH-COMMANDS-------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	admin2 = xbmc.getInfoLabel('Skin.HasSetting(Admin2)')
	TypeError = ""
	if not systemplatformwindows:
		try:
			#process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
			process = subprocess.Popen(bashCommand,stdout=subprocess.PIPE,shell=True)
			output = process.communicate()[0]
			'''---------------------------'''
		except Exception, TypeError: pass
	
		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		if admin and admin2 or str(TypeError) != "": print printfirst + bashname + space2 + output + newline + "TypeError" + space2 + str(TypeError)
		'''---------------------------'''
		return output

def stringtotime(dt_str, dt_func):
	'''WIP!!!'''
	from datetime import datetime
	import time
	#dt_str = '9/24/2010 5:03:29 PM'
	#dt_func = '%m/%d/%Y %I:%M:%S %p'
	#try:
	dt_obj = datetime.strptime(dt_str, dt_func)
	dt_objS = str(dt_obj)
	if dt_func == '%H':
		#time.struct_time(tm_year=1900, tm_mon=1, tm_mday=1, tm_hour=20, tm_min=0, tm_sec=0, tm_wday=0, tm_yday=1, tm_isdst=-1)
		find = dt_str
		found = find_string(dt_objS, find, "")
		'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "stringtotime" + space + "dt_objS" + space2 + dt_objS + space + "timenow3S" + space2 + timenow3S
	'''---------------------------'''
	
	return dt_obj

def find_string(findin, findwhat, findwhat2):
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	admin2 = xbmc.getInfoLabel('Skin.HasSetting(Admin2)')
	
	findin = str(findin)
	findinL = len(findin)
	findinLS = str(findinL)
	findinLN = int(findinLS)
	findwhat = str(findwhat)
	findwhatL = len(findwhat)
	findwhatLS = str(findwhatL)
	findwhatLN = int(findwhatLS)
	findwhat2 = str(findwhat2)
	findwhat2L = len(findwhat2)
	findwhat2LS = str(findwhat2L)
	findwhat2LN = int(findwhat2LS)
	'''---------------------------'''
	findin_start = findin.find(findwhat, 0, findinL)
	findin_startS = str(findin_start)
	findin_startN = int(findin_startS) + findwhatLN
	findin_startS = str(findin_start)
	'''---------------------------'''
	if findwhat2 == "": findin_end = findin.find(findwhat2, findin_startN, findinL)
	else:
		findin_end = findin.find(findwhat2, findin_startN, findin_startN + findwhatLN)
		if findin_end == -1: findin_end = findin.find(findwhat2, findin_startN, findinL)
	findin_endS = str(findin_end)
	findin_endN = int(findin_endS) + findwhat2LN
	'''---------------------------'''
	findin_startN = int(findin_startS) #SOME KIND OF BUG? BUT WORKING THIS WAY!
	found = findin[findin_startN:findin_endN]
	foundS = str(found)
	'''---------------------------'''
	try:
		foundF = float(foundS)
		found2 = round(foundF)
		found2S = str(found2)
		if ".0" in found2S: found2S = found2S.replace(".0","",1)
	except: pass
	
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin and admin2: print printfirst + "find_string" + space + "findin" + space2 + findin + space + "(" + findinLS + ")" + space + "findwhat" + space2 + findwhat + space + "(" + findwhatLS + ")" + space +  "findin_startS" + space2 + findin_startS + space + "findin_endS" + space2 + findin_endS + space + "findin_start" + space2 + str(findin_start) + space + "findin_startN" + space2 + str(findin_startN) + space + "foundS" + space2 + foundS + space
	'''---------------------------'''
	return foundS
	
def calculate(addon, set1, custom, opt):
	'''------------------------------
	---RETURN-CALCULATE-NUMBER-------
	------------------------------'''
	printpoint = ""
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	admin2 = xbmc.getInfoLabel('Skin.HasSetting(Admin2)')
	getsetting_custom          = xbmcaddon.Addon(addon).getSetting
	setsetting_custom          = xbmcaddon.Addon(addon).setSetting
		
	set1v = getsetting_custom(set1)
	try: set1v = int(set1v)
	except: printpoint = printpoint + "1"
	
	try:
		if custom > 1 or custom < -1: printpoint = printpoint + "3"
	except: pass
	
	if opt != "": set2v = int(opt)
	else: set2v = ""
	'''---------------------------'''
	if custom == '1':
		if not "1" in printpoint: set1v += 1
		if opt != "": set2v += 1
		'''---------------------------'''
	elif custom == '2':
		if not "1" in printpoint: set1v += -1
		if opt != "": set2v += -1
		'''---------------------------'''
	elif "3" in printpoint:
		if not "1" in printpoint: set1v += custom
		if opt != "": set2v += custom
		custom = str(custom) + "*"
		'''---------------------------'''
		
				
	set1v = str(set1v)
	if opt != "": set2v = str(set2v)
	'''---------------------------'''
	if opt != "": setsetting_custom(set1, set2v) #setsetting(set1, set2v) #setsetting_custom1(addon,set1,set2v) #setsetting_custom(set1, set2v)
	else: setsetting_custom(set1, set1v) #setsetting(set1, set1v) #setsetting_custom1(addon,set1,set1v) #setsetting_custom(set1, set1v)
	'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''	
	if admin and admin2: print printfirst + "calculate_LV" + printpoint + space + addon + space + set1 + space + "set1v" + space + set1v + space + "set2v" + space + set2v + space + "custom" + space2 + str(custom)
	if opt != "": return set2v
	else: return set1v
	'''---------------------------'''

def bash_count(path):
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	folders_count = bash('find '+ path +' -type d | wc -l', "folders_count")
	folders_count2 = bash('find '+ path +' -type d -prune | wc -l', "folders_count")
	files_count = bash('find '+ path +' -type f | wc -l', "files_count")
	
	folders_count = int(folders_count)
	folders_count2 = int(folders_count2)
	files_count = int(files_count)
	
	folders_count = str(folders_count)
	folders_count2 = str(folders_count2)
	files_count = str(files_count)
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''	
	if admin: print printfirst + "bash_count" + space + "path" + space2 + path + space + "folders_count" + space2 + folders_count + space + "folders_count2" + space2 + folders_count2 + space + "files_count" + space2 + files_count
	'''---------------------------'''
	
	'''---------------------------'''
	return folders_count, folders_count2, files_count
	
def Clean_Library(type):
	'''---------------------------'''
	manualL = ["9","10","11","12","13"]
	manualL2 = ["downloads", "music", "pictures", "videos", "movies", "tvshows"]
	librarypath = '/storage/.kodi/userdata/library/'
	'''---------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	printpoint = ""
	dirs = ""
	dirsN = 0
	emptydirs = ""
	emptydirsN = 0
	files_count = 0
	folders_count = 0
	pathdir = ""
	TypeError = ""
	'''---------------------------'''
	
	if not systemplatformwindows:
		if type == "1": foldername = 'movies'
		elif type == "2": foldername = 'tvshows'
		elif type == "3": foldername = 'storage'
		elif type == "9": foldername = 'library'
		elif type == "10": foldername = 'downloads'
		elif type == "11": foldername = 'music'
		elif type == "12": foldername = 'pictures'
		elif type == "13": foldername = 'videos'
		else: foldername = ""
		'''---------------------------'''
		
		if foldername == "": path = ""
		elif type == "9": path = "/" + foldername + "/"
		elif type == "3": path = foldername + "/"
		elif type != "3": path = librarypath + foldername + "/"
		else: printpoint = printpoint + "9"
		'''---------------------------'''
		
		if path != "":
			printpoint = printpoint + "1"
			if not os.path.exists(path):
				printpoint = printpoint + "3"
				os.mkdir(path)
			elif os.listdir(path) == []: printpoint = printpoint + "4"
			else:
				printpoint = printpoint + "5"
				folders_count, folders_count2, files_count = bash_count(path)
				try:
					files_count = int(files_count)
					folders_count = int(folders_count)
					folders_count2 = int(folders_count2)
				except Exception, TypeError:
					files_count = 0
					folders_count = 0
					folders_count2 = 0
					TypeError = TypeError + newline + str(TypeError)
				subdirectories = os.listdir(path)
				for dir in subdirectories:
					#dirsN += 1
					pathdir = path + dir
					if os.path.isdir(pathdir) == True:
						if dir[:1] != ".":
							if os.listdir(pathdir) == []:
								emptydirs = emptydirs + space + dir
								emptydirsN += 1
								bash('rmdir ' + "'" + pathdir + "'",pathdir)
								'''---------------------------'''
							else:
								pass
								'''---------------------------'''
						else:
							pass
							'''---------------------------'''
					else:
						pass
						'''---------------------------'''
		else: printpoint = printpoint + "9"
		
		if emptydirsN > 0: notification(str79542.encode('utf-8'),str79543.encode('utf-8') % (type, str(emptydirsN)),"",4000)
		
		if "5" in printpoint and files_count > 0 and foldername != "" and type in manualL:
			'''------------------------------
			---MANUAL-PROMPT-----------------
			------------------------------'''
			pass
			returned = dialogyesno(str79540.encode('utf-8') % (str(files_count), foldername), str79541.encode('utf-8'))
			if returned == 'ok':
				bash('rm -rf '+ path +'*',"Cleanning folder: " + foldername)
				'''---------------------------'''
			else:
				notification_common("9")
				'''---------------------------'''
			
		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		print printfirst + "Clean_Library_" + printpoint + space + "type" + space2 + type + space + "foldername" + space2 + foldername + space + "totalfiles" + space2 + str(files_count) + space + "addonID" + space2 + addonID
		if TypeError != "": print printfirst + "Clean_Library" + space + "TypeError" + space2 + str(TypeError)
		if admin:
			print '---------------------------'
			print printfirst + "path" + space2 + path
			print printfirst + "dirs" + space2 + "(" + str(dirsN) + ")" + space + "folders_count" + space2 + str(folders_count) + space + "folders_count" + space2 + str(folders_count) + space + dirs
			print printfirst + "pathdir" + space2 + pathdir + space
			print printfirst + "emptydirs" + space2 + "(" + str(emptydirsN) + ")" + space + emptydirs
			print '---------------------------'
			'''---------------------------'''
			
def cmd(cmdCommand,cmdname):
	'''------------------------------
	---DEFAULT-----------------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	admin2 = xbmc.getInfoLabel('Skin.HasSetting(Admin2)')
	
	'''run CMD commands'''
	if systemplatformwindows:
		#process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
		#process = subprocess.Popen(cmdCommand,stdout=subprocess.PIPE,shell=True)
		
		#process = subprocess.Popen('cmd.exe' + space + cmdCommand, shell=True)
		#output = process.communicate()[0]

		#process = subprocess.Popen('cmd.exe', stdin = subprocess.PIPE, stdout = subprocess.PIPE)
		#output = process.communicate(cmdCommand)
		
		#output = subprocess.call(["ping", "-c 2", "www.cyberciti.biz"])
		#output = process.communicate()
		
		process = subprocess.Popen(cmdCommand,stdout=subprocess.PIPE,shell=True)
		output = process.communicate()[0]
		
		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		outputS = str(output)
		if admin and admin2: print printfirst + "cmd" + space2 + cmdname + space + cmdCommand + space + "output" + space2 + outputS
		'''---------------------------'''
		return output
		
def copy_rename(old_file_name, new_file_name):
	'''UNUSED'''
	import shutil
	src_dir= os.curdir
	dst_dir= os.path.join(os.curdir , "/storage/")
	src_file = os.path.join(src_dir, old_file_name)
	shutil.copy(src_file,dst_dir)
	
	dst_file = os.path.join(dst_dir, old_file_name)
	new_dst_file_name = os.path.join(dst_dir, new_file_name)
	os.rename(dst_file, new_dst_file_name)

def checkDialog(admin):
	'''------------------------------
	---checkDialog-------------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	dialogbusyW = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
	dialogprogressW = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
	dialogselectW = xbmc.getCondVisibility('Window.IsVisible(DialogSelect.xml)')
	dialogyesnoW = xbmc.getCondVisibility('Window.IsVisible(DialogYesNo.xml)')
	dialogokW = xbmc.getCondVisibility('Window.IsVisible(DialogOK.xml)')
	dialogkaitoastW = xbmc.getCondVisibility('Window.IsVisible(DialogKaiToast.xml)')
	dialogkeyboardW = xbmc.getCondVisibility('Window.IsVisible(DialogKeyboard.xml)')
	dialogsubtitlesW = xbmc.getCondVisibility('Window.IsVisible(DialogSubtitles.xml)')
	videofullscreenW = xbmc.getCondVisibility('Window.IsVisible(VideoFullScreen.xml)')
	'''---------------------------'''
	dialogHeader = ""
	dialogHeaderCustom = ""
	dialogMessage = ""
	dialogMessageCustom = ""
	'''---------------------------'''
	if dialogselectW:
		dialogHeader = xbmc.getInfoLabel('Control.GetLabel(1)') ### Skin.HasSetting(Admin) | !StringCompare(Control.GetLabel(1),Genesis)
		dialogHeaderCustom = xbmc.getInfoLabel('Control.GetLabel(100)') ###CUSTOM
		dialogMessage = ""
		dialogMessageCustom = ""
		returned_Dialog = "dialogselectW"
		'''---------------------------'''
	elif dialogyesnoW:
		dialogHeader = xbmc.getInfoLabel('Control.GetLabel(1)') ###
		dialogHeaderCustom = ""
		dialogMessage = xbmc.getInfoLabel('Control.GetLabel(9)') ###TEXTBOX
		if xbmc.getCondVisibility('!IsEmpty(Control.GetLabel(90))'): dialogMessageCustom = xbmc.getInfoLabel('Control.GetLabel(90)') ###CUSTOM
		else: dialogMessageCustom = ""
		returned_Dialog = "dialogyesnoW"
		'''---------------------------'''
	elif dialogkeyboardW:
		dialogHeader = xbmc.getInfoLabel('Control.GetLabel(311)')
		dialogHeaderCustom = xbmc.getInfoLabel('Control.GetLabel(317)')
		dialogMessage = xbmc.getInfoLabel('Control.GetLabel(312)') ###EDIT
		dialogMessageCustom = "" ###NONE
		returned_Dialog = "dialogkeyboardW"
		'''---------------------------'''
	elif dialogprogressW:
		dialogHeader = xbmc.getInfoLabel('Control.GetLabel(1)')
		dialogHeaderCustom = ""
		dialogMessage = xbmc.getInfoLabel('Control.GetLabel(9)') ###TEXTBOX
		if xbmc.getCondVisibility('Control.IsVisible(90)'): dialogMessageCustom = xbmc.getInfoLabel('Control.GetLabel(90)') ###CUSTOM
		else: dialogMessageCustom = ""
		returned_Dialog = "dialogprogressW"
		'''---------------------------'''
	elif dialogbusyW:
		if xbmc.getCondVisibility('Control.IsVisible(9)'): dialogHeader = xbmc.getInfoLabel('Control.GetLabel(9)') ###NONE
		elif xbmc.getCondVisibility('Control.IsVisible(100)'): dialogHeaderCustom = xbmc.getInfoLabel('Control.GetLabel(100)') ###CUSTOM
		elif xbmc.getCondVisibility('Control.IsVisible(101)'): dialogHeaderCustom = xbmc.getInfoLabel('Control.GetLabel(101)') ###CUSTOM
		dialogMessage = "" ###NONE
		if xbmc.getCondVisibility('!IsEmpty(Control.GetLabel(90))'): dialogMessageCustom = xbmc.getInfoLabel('Control.GetLabel(90)') ###CUSTOM
		returned_Dialog = "dialogbusyW"
		'''---------------------------'''
	elif dialogokW:
		if xbmc.getCondVisibility('Control.IsVisible(1)'): dialogHeader = xbmc.getInfoLabel('Control.GetLabel(1)') ### Skin.HasSetting(Admin) | StringCompare(Control.GetLabel(100),) | StringCompare(Control.GetLabel(1),$LOCALIZE[19240])
		elif xbmc.getCondVisibility('Control.IsVisible(100)'): dialogHeaderCustom = xbmc.getInfoLabel('Control.GetLabel(100)') ###CUSTOM
		if xbmc.getCondVisibility('Control.IsVisible(9)'): dialogMessage = xbmc.getInfoLabel('Control.GetLabel(9)') ###TEXTBOX
		elif xbmc.getCondVisibility('!Control.IsVisible(9)'): dialogMessageCustom = xbmc.getInfoLabel('Control.GetLabel(90)') ###CUSTOM
		returned_Dialog = "dialogokW"
		'''---------------------------'''
	elif dialogsubtitlesW:
		dialogHeader = ""
		dialogHeaderCustom = ""
		dialogMessage = xbmc.getInfoLabel('Container(120).ListItem.Label2') ###FILE NAME
		dialogMessageCustom = xbmc.getInfoLabel('Container(120).ListItem.Label') ###FILE LANGUAGE
		returned_Dialog = "dialogsubtitlesW"
		'''---------------------------'''
	elif videofullscreenW:
		dialogHeader = ""
		dialogHeaderCustom = ""
		dialogMessage = ""
		dialogMessageCustom = ""
		returned_Dialog = "videofullscreenW"
		'''---------------------------'''
	else:
		'''------------------------------
		---NOTHING-SPECIFIC--------------
		------------------------------'''
		dialogHeader = ""
		dialogHeaderCustom = ""
		dialogMessage = ""
		dialogMessageCustom = ""
		returned_Dialog = ""
		'''---------------------------'''
	#elif dialogkaitoastW:
		#if xbmc.getCondVisibility('Control.IsVisible(401)'): dialogHeader = xbmc.getInfoLabel('Control.GetLabel(401)')
		#elif xbmc.getCondVisibility('!Control.IsVisible(401)'): dialogHeaderCustom = xbmc.getInfoLabel('Control.GetLabel(410)')
		#if xbmc.getCondVisibility('Control.IsVisible(402)'): dialogMessage = xbmc.getInfoLabel('Control.GetLabel(402)')
		#elif xbmc.getCondVisibility('Control.IsVisible(420)'): dialogMessageCustom = xbmc.getInfoLabel('Control.GetLabel(420)')
		#returned_Dialog = "dialogkaitoastW"
		#'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if returned_Dialog != "" and admin: print printfirst + "checkDialog" + space + "returned_Dialog" + space2 + "returned_Dialog" + space2 + returned_Dialog + space + "dialogHeader" + space2 + dialogHeader + space3 + "dialogHeaderCustom" + space2 + dialogHeaderCustom + space3 + "dialogMessage" + space2 + dialogMessage + space3 + "dialogMessageCustom" + space2 + dialogMessageCustom + space3
	'''---------------------------'''
	
	'''------------------------------
	---RETURN-END--------------------
	------------------------------'''
	returned_Header = dialogHeader
	returned_Message = dialogMessage
	if returned_Header == "Error occurred": returned_Header = "Sdarot.tv Video"
	'''---------------------------'''
	return returned_Dialog, returned_Header, returned_Message
	'''---------------------------'''

def UserBlock(custom):
	
	if custom == "ON": bash('pgrep kodi.bin | xargs kill -SIGSTOP',"UserBlock-ON")
	else: bash('pgrep kodi.bin | xargs kill -SIGCONT',"UserBlock-OFF")
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if custom != "ON": custom = "OFF"
	print printfirst + space + "UserBlock=" + custom
	'''---------------------------'''
	
def dialogkeyboard(input, heading, option, custom, set1, addon):
	'''option:
    - xbmcgui.INPUT_ALPHANUM (standard keyboard)
    - xbmcgui.INPUT_NUMERIC (format: #)
    - xbmcgui.INPUT_DATE (format: DD/MM/YYYY)
    - xbmcgui.INPUT_TIME (format: HH:MM)
    - xbmcgui.INPUT_IPADDRESS (format: #.#.#.#)
    - xbmcgui.INPUT_PASSWORD (return md5 hash of input, input is masked)
	'''
	if '$LOCALIZE' in heading: heading = xbmc.getInfoLabel(heading)
	dialog = xbmcgui.Dialog()
	keyboard = xbmc.Keyboard(input,heading,option)
	keyboard.doModal()
	returned = 'skip'
	'''---------------------------'''
	if (keyboard.isConfirmed()):
		set1v = keyboard.getText()
		if custom == '1':
			if set1v != "": returned = 'ok'
			else: notification_common("3")
		if custom == '2' and set1v == input: returned = 'ok'
		if custom == '3':
			if set1v != input and set1v != "" and option == 0: xbmc.executebuiltin('Notification('+ heading +': '+ set1v +',,4000)')
			if set1v != "": returned = 'ok'
			'''---------------------------'''
			
		if option == 0: print printfirst + heading + space2 + set1v + " ( " + returned + " )"
		elif option != 0: print printfirst + heading + space2 + "*******" + " ( " + returned + " )"
	if returned == 'ok':
		returned = set1v
		if set1 != "" and addon != "":
			if addon == "0": setsetting(set1, set1v)
			elif addon != "": setsetting_custom1(addon,set1,set1v)
			'''---------------------------'''
		elif set1 != "" and addon == "": setSkinSetting("0",set1,set1v)
	
	'''---------------------------'''
	return returned

def dialognumeric(type,heading,input,custom,set1,addon):
	'''type: 0 = #, 1 = DD/MM/YYYY, 2 = HH:MM, 3 = #.#.#.#, message2 = heading, message1 = content'''
	name = 'dialognumeric'
	returned = "skip"
	TypeError = ""
	if '$LOCALIZE' in heading: heading = xbmc.getInfoLabel(heading)
	if custom == 0:
		try:
			if int(input) > 001000000 and int(input) < 9999999999 and input != "": pass
			else: input = 0
			'''---------------------------'''
		except Exception, TypeError: input = 0

	set1v = xbmcgui.Dialog().numeric(type, heading, str(input))
	
	if set1v == "":
		notification_common("3")
		sys.exit()
		'''---------------------------'''
		
	if custom == '0':
		try:
			if int(set1v) > 001000000 and int(set1v) < 9999999999: returned = 'ok'
			elif int(set1v) < 001000000 or int(set1v) > 9999999999: returned = 'skip0'
			'''---------------------------'''
		except Exception, TypeError:
			returned = 'skip'
			'''---------------------------'''
			
	if custom == '1':
		if set1v != "": returned = 'ok'
		'''---------------------------'''
	if custom == '2':
		if set1v == "": set1v = 0
		elif set1v != 0: returned = 'ok'
		'''---------------------------'''
	
	if returned == 'ok':
		if set1 != "" and addon != "":
			setsetting_custom1(addon,set1,set1v)
			'''---------------------------'''
		elif set1 != "" and addon == "":
			setSkinSetting("0", set1, set1v)
			'''---------------------------'''
			
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + name + space + "heading" + space2 + str(heading) + space + "input" + space2 + str(input) + space5 + str(set1v) + space +  "( " + returned + " )"	
	'''---------------------------'''
	
	'''---------------------------'''
	return returned, input2

def dialogok(heading,line1,line2,line3):
	'''------------------------------
	---DIALOG-OK---------------------
	------------------------------'''
	dialog = xbmcgui.Dialog()
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	if '$LOCALIZE' in line1 or '$ADDON' in line1: line1 = xbmc.getInfoLabel(line1)
	if '$LOCALIZE' in line2 or '$ADDON' in line2: line2 = xbmc.getInfoLabel(line2)
	if '$LOCALIZE' in line3 or '$ADDON' in line3: line3 = xbmc.getInfoLabel(line3)
	try: heading = str(heading.encode('utf-8'))
	except: heading = str(heading)
	try: line1 = str(line1.encode('utf-8'))
	except: line1= str(line1)
	try: line2 = str(line2.encode('utf-8'))
	except: line2 = str(line2)
	try: line3 = str(line3.encode('utf-8'))
	except: line3 = str(line3)

	dialog.ok(heading,line1,line2,line3)
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + heading + space2 + line1 + space2 + line2 + space2 + line3
	'''---------------------------'''


def dialogprogress(id, progress, heading, line1, line2, line3): 
	'''------------------------------
	---DIALOG-OK-***BROKEN***--------
	------------------------------'''
	#try: progressN = int(progress)
	#except Exception, TypeError: progressN = 0
	'''---------------------------'''
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	if '$LOCALIZE' in line1 or '$ADDON' in line1: line1 = xbmc.getInfoLabel(line1)
	if '$LOCALIZE' in line2 or '$ADDON' in line2: line2 = xbmc.getInfoLabel(line2)
	if '$LOCALIZE' in line3 or '$ADDON' in line3: line3 = xbmc.getInfoLabel(line3)
	heading = str(heading.encode('utf-8'))
	line1 = str(line1.encode('utf-8'))
	line2 = str(line2.encode('utf-8'))
	line3 = str(line3.encode('utf-8'))
	
	#notification(str(progress),"","",2000)
	dp = xbmcgui.DialogProgress()
					
	if progress == 0:
		#pDialog.close
		dp.create(heading,line1,line2,line3)
	elif progress == 10: dp.close
	elif progress > 0: dp.update(progressN,line1,line2,line3)
	
	#pDialog = xbmcgui.DialogProgressBG()
	#pDialog.create(heading, line1)
	
	#def dialogprogress(admin, id, action, name, header, line1, line2):
	#id = xbmcgui.DialogProgress( )
	#if action == 0: returned = id.create(name, header, line1, line2)
	#else: returned = ""
	#return returned
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin:
		print printfirst + "dialogprogress" + space2 + heading + space2 + line1 + space2 + line2 + space2 + line3
		try:
			print printfirst + "TypeError" + space2 + str(TypeError)
			'''---------------------------'''
		except:
			pass
			'''---------------------------'''
	return dp
	
def dialogselect(heading, list, autoclose):
	'''------------------------------
	---DIALOG-SELECT-----------------
	------------------------------'''
	'''autoclose = [opt] integer - milliseconds to autoclose dialog. (default=do not autoclose)'''
	printpoint = ""
	dialog = xbmcgui.Dialog()
	if '$LOCALIZE' in heading or '$ADDON' in heading:
		printpoint = printpoint + "1"
		heading = xbmc.getInfoLabel(heading)
	#heading = str(heading).decode('utf-8').encode('utf-8')
	try:
		heading = str(heading).encode('utf-8')
	except:
		printpoint = printpoint + "2"
		try:
			heading = heading.encode('utf-8')
		except:
			printpoint = printpoint + "3"
			
	returned = dialog.select(heading,list,autoclose)
	returned = int(returned)
	
	
	
	#value = value.replace(" ","",1)
	#value = value.decode('utf-8').encode('utf-8')
	#value = str(value).decode('utf-8')
	#value = str(value).decode('utf-8').encode('utf-8')
	#value = value.decode('utf-8').encode('utf-8')
	
	if returned == -1:
		notification_common("9")
		value = ""
	else:
		value = list[returned]
		value = str(value)

	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "dialogselect_LV" + printpoint + space2 + heading + "( " + str(returned) + " )" + space + "value" + space2 + value + space
	return returned, value
	'''---------------------------'''

def diaogtextviewer(header,message):
	if '$LOCALIZE' in header or '$ADDON' in header: header = xbmc.getInfoLabel(header)
	if '$LOCALIZE' in message or '$ADDON' in message: message = xbmc.getInfoLabel(message)
	
	try: header = str(header.encode('utf-8'))
	except: pass
	try: message = str(message.encode('utf-8'))
	except: pass
	
	w = TextViewer_Dialog('DialogTextViewer.xml', "", header=header, text=message)
	w.doModal()
	
def dialogyesno(heading,line1,yes=False):
	'''------------------------------
	---DIALOG-YESNO------------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	if '$LOCALIZE' in line1 or '$ADDON' in line1: line1 = xbmc.getInfoLabel(line1)
	returned = 'skip'
	if yes != False: xbmc.executebuiltin('AlarmClock(yes,Action(Down),0,silent)')
	if dialog.yesno(heading,line1): returned = 'ok'
	
	try: heading = str(heading.encode('utf-8'))
	except: pass
	try: line1 = str(line1.encode('utf-8'))
	except: pass
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "dialogyesno" + space2 + heading + space3 + line1 + "( " + returned + " )"
	'''---------------------------'''
	return returned
	'''---------------------------'''

def findin_controlhasfocus(custom,what,sleep,action,action2):
	'''action = not found | action2 = when found'''
	'''---------------------------'''
	what = str(what)
	custom = str(custom)
	if custom == "0": controlhasfocus = xbmc.getCondVisibility('Control.HasFocus('+ what +')')
	else: controlhasfocus = xbmc.getCondVisibility('ControlGroup('+ custom +').HasFocus('+ what +')')
	
	if (what != "" and not controlhasfocus and action != ""): xbmc.executebuiltin(''+ action +'')
	'''---------------------------'''
	xbmc.sleep(sleep)
	if custom == "0": controlhasfocus = xbmc.getCondVisibility('Control.HasFocus('+ what +')')
	else: controlhasfocus = xbmc.getCondVisibility('ControlGroup('+ custom +').HasFocus('+ what +')')
	#systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
	xbmc.sleep(sleep)
	'''---------------------------'''
	if (what != "" and controlhasfocus and action2 != ""): xbmc.executebuiltin(''+ action2 +'')
	'''---------------------------'''
	return controlhasfocus
	
def findin_systemcurrentcontrol(custom,what,sleep,action,action2):
	'''action = not found | action2 = when found'''
	'''---------------------------'''
	if '$LOCALIZE' in what or '$ADDON' in what: what = xbmc.getInfoLabel(what)
	try: what = what.encode('utf-8')
	except: pass
	
	systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
	if custom == "0" and (what != "" and systemcurrentcontrol != what and action != ""): xbmc.executebuiltin(''+ action +'')
	elif custom == "1" and (what != "" and not what in systemcurrentcontrol and action != ""): xbmc.executebuiltin(''+ action +'')
	elif custom == "2" and (what != "" and systemcurrentcontrol not in what and action != ""): xbmc.executebuiltin(''+ action +'')
	'''---------------------------'''
	xbmc.sleep(sleep)
	systemcurrentcontrol2 = xbmc.getInfoLabel('System.CurrentControl')
	xbmc.sleep(sleep)
	'''---------------------------'''
	if custom == "0" and (what != "" and systemcurrentcontrol2 == what and action2 != ""): xbmc.executebuiltin(''+ action2 +'')
	elif custom == "1" and (what != "" and what in systemcurrentcontrol2 and action2 != ""): xbmc.executebuiltin(''+ action2 +'')
	elif custom == "2" and (what != "" and systemcurrentcontrol2 in what and action2 != ""): xbmc.executebuiltin(''+ action2 +'')
	'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "findin_systemcurrentcontrol" + space + "custom" + space2 + custom + space + "what" + space2 + str(what) + space + "systemcurrentcontrol/2" + space2 + str(systemcurrentcontrol) + space5 + str(systemcurrentcontrol2)
	'''---------------------------'''
	return systemcurrentcontrol2

def get_types(value):
	import types
	returned = str(type(value))
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "get_types" + space + "value" + space2 + str(value) + space + "type" + space2 + returned
	'''---------------------------'''
	
	return returned
	'''---------------------------'''
	
def get_daynow(custom):
	daynow = datenow.strftime("%a")
	daynowS = str(daynow)
	return daynowS
	'''---------------------------'''
	
def refresh_datetime(admin, datenowS_, timenowS_):
	import datetime as dt
	import time
	
	name = 'refresh_datetime'
	
	datenow = dt.date.today()
	datenowS = str(datenow)
	'''---------------------------'''
	dateafter = datenow + dt.timedelta(days=7)
	dateafterS = str(dateafter)
	'''---------------------------'''
	yearnow = datenow.strftime("%Y")
	yearnowS = str(yearnow)
	'''---------------------------'''
	daynow = datenow.strftime("%a")
	daynowS = str(daynow)
	timenow = dt.datetime.now()
	timenowS = str(timenow)
	timenow2 = timenow.strftime("%H:%M")
	timenow2S = str(timenow2)
	timenow2N = int(timenow2S.replace(":","",1)) #GAL CHECK # PAREMTERS WHY?
	timenow3 = timenow.strftime("%H")
	timenow3S = str(timenow3)
	timenow3N = int(timenow3S)
	timenow4 = timenow.strftime("%S")
	timenow4S = str(timenow4)
	'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + name + space + "datenowS/2" + space2 + datenowS_ + space4 + datenowS + space + "timenowS" + space2 + timenowS_ + space4 + timenowS
	'''---------------------------'''
	return datenow, datenowS, dateafter, dateafterS, yearnow, yearnowS, daynow, daynowS, timenowS, timeow2S, timenow3S, timenow4S
	
def getsetting_custom1(addon,set1):
	'''------------------------------
	---GET-ADDON-SETTING-1-----------
	------------------------------'''
	getsetting_custom          = xbmcaddon.Addon(addon).getSetting
	'''---------------------------'''
	returned = getsetting_custom(set1,set1v)
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "getsetting_custom1" + space2 + addon + space + set1
	'''---------------------------'''
	return returned
	'''---------------------------'''

def getRandom(custom, min=0, max=100, percent=50):
	'''------------------------------
	---RANDOM------------------------
	------------------------------'''
	import random
	value = ""
	returned = ""
	printpoint = ""
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	try:
		min = int(min)
		max = int(max)
		percent = int(percent)
	except Exception, TypeError: printpoint = printpoint + "9"
	'''---------------------------
	random.random()
	This prints a random floating point number in the range [0, 1) (that is, between 0 and 1, including 0.0 but always smaller than 1.0).
	randrange(a, b) chooses an integer in the range [a, b).
	uniform(a, b) chooses a floating point number in the range [a, b).
	normalvariate(mean, sdev) samples the normal (Gaussian) distribution.
	------------------------------'''
	
	if not "9" in printpoint:
		'''---------------------------'''
		if custom == "0": value = random.randrange(min,max)
		'''---------------------------'''
		if value <= percent: returned = "ok"
		else: returned = "skip"
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print "getRandom_LV" + printpoint + space + "min" + space2 + str(min) + space + "max" + space2 + str(max) + space + "percent" + space2 + str(percent) + newline + "returned" + space2 + str(returned) + space + "value" + space2 + str(value)
	if "9" in printpoint: print "getRandom_LV" + printpoint + space + "TypeError" + space2 + str(TypeError) 
	'''---------------------------'''
	
	return returned, value
				
def get_timenow(custom):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	import datetime as dt
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	customS = str(custom)
	timenow = dt.datetime.now()
	timenow3 = timenow.strftime("%H")
	timenow3S = str(timenow3)
	timenow3N = int(timenow3)
	timezone = ""
	'''---------------------------'''
	if timenow3N > 03 and timenow3N < 12: timezone = "A"
	elif timenow3N > 11 and timenow3N < 20: timezone = "B"
	elif timenow3N > 19 or timenow3N < 04: timezone = "C"
	
	if custom == 1: returned = timezone
	else: returned = ""
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "get_timenow_" + customS + space + "timenow3S" + space2 + timenow3S + space + "timezone" + space2 + timezone + space
	'''---------------------------'''
	return returned

def installaddon(admin, addonid2, name):
	returned = ""
	printpoint = ""
	if not os.path.exists(xbmc.translatePath("special://home/addons/") + addonid2):
		printpoint = printpoint + "1"
		xbmc.executebuiltin('ActivateWindow(10025,special://userdata/library/,return)')
		notification_common("2")
		xbmc.sleep(2000)
		xbmc.executebuiltin('ActivateWindow(10025,plugin://'+ addonid2 +')')
		xbmc.executebuiltin('Action(Down)')
		xbmc.executebuiltin('Action(Select)')
		xbmc.sleep(1000)
		notification_common("2")
		'''---------------------------'''
		dialogprogressW = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
		count = 0
		count2 = 0
		while count < 40 and (dialogprogressW or count2 > -2) and returned != "skip" and not xbmc.abortRequested:
			count += 1
			xbmc.sleep(500)
			dialogprogressW = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
			xbmc.sleep(500)
			if count == 1:
				returned = "?"
				#notification_common("12")
				printpoint = printpoint + "2"
			if count == 20: printpoint = printpoint + "3"
			if count == 39: printpoint = printpoint + "4"
			if not dialogprogressW: count2 += -1
			elif count2 < 0: count2 += 1
			if count == 40:
				printpoint = printpoint + "5"
				returned = "skip"
				print "error_count=20"
				'''---------------------------'''
		systemidle3 = xbmc.getCondVisibility('System.IdleTime(3)')
		returned = "?"
		if not systemidle3:
			returned = "skip"
			printpoint = printpoint + "6"
			'''---------------------------'''
		elif returned == "?":
			returned = "ok"
			printpoint = printpoint + "7"
			'''---------------------------'''
		else: printpoint = printpoint + "9"
		#xbmc.executebuiltin('Action(Close)')
		xbmc.executebuiltin('Action(Back)')
		'''---------------------------'''
	else: printpoint = printpoint + "8"
	print printfirst + "installaddon_LV" + printpoint + space + "(" + returned + ")"
	'''---------------------------'''
	return returned

def findVersion(url, Ver='0.1.x'):
	from shared_modules3 import urlcheck
	
	Version = Ver.split('.')
	Version1 = Version[0]
	Version2 = Version[1]
	try: Version3 = Version[2]
	except: Version3 = ""
	x_nums = Version.count('x') ; x_nums = int(x_nums) ; num = 1 ; num3 = 40
	if 'x' in Version1: num += 10
	if 'x' in Version2: num += 10
	
	dp = xbmcgui.DialogProgress()
	dp.create("HTPT Version Find", "Starting...", " ")
	
	count = 0 ; count1 = 0 ; count2 = 0 ; count3 = 0 ; returned = ""
	while count < num and returned != 'ok' and not dp.iscanceled() and not xbmc.abortRequested:
		
		if Version1 == 'x' or count1 > 0:
			if Version1 == 'x': Version1 = Version1.replace('x','0')
			elif count1 > 0:
				Version1 = int(Version1)
				Version1 += 1
				'''---------------------------'''
			count1 += 1
		
		if Version2 == 'x' or count2 > 0:
			if Version2 == 'x': Version2 = Version2.replace('x','0')
			elif count2 > 0:
				Version2 = int(Version2)
				Version2 += 1
				'''---------------------------'''
			count2 += 1
				
		if Version3 == 'x': Version3 = Version3.replace('x','0')
		while count3 < num3 and returned != 'ok' and not xbmc.abortRequested:
			returned = urlcheck(url+str(Version1)+"."+str(Version2)+"."+str(Version3)+".zip")
			if returned != 'ok':
				Version3 = int(Version3)
				Version3 += 1
				'''---------------------------'''
			else:
				dp.update(100,"FOUND!!!:" + space + str(Version1)+"."+str(Version2)+"."+str(Version3)," ")
				xbmc.sleep(1000)
				dp.close
				'''---------------------------'''
			progress = (((1+count)*(1+count3))*100/(num*num3))
			
			try:
				#progress = str(progress)
				#progress = float(progress)
				#progress = round(progress)
				#progress = str(progress)
				if ".0" in progress: progress = progress.replace(".0","",1)
				progress = int(progress)
			except: pass

			if count == 0 and count3 == 0: pass
			elif count == 0: dp.update(progress,"Looking for Version:" + space + str(Version1)+"."+str(Version2)+"."+str(Version3)," ")
			count3 += 1
			'''---------------------------'''
		if count3 >= num3: Version3 = 'x' ; count3 = 0
		
		
		count += 1
		
	if dp.iscanceled():	
		dp.close
	
	if returned == 'ok': url2 = url+str(Version1)+"."+str(Version2)+"."+str(Version3)+".zip"
	else: url2 = ""
	print printfirst + "installaddon2" + space + "["+str(count)+"]" + space + "Version" + space2 + str(Version) + space + "Version1/2/3" + space2 + str(Version1) + space4 + str(Version2) + space4 + str(Version3) + space + "returned" + space2 + str(returned) + space + "url2" + space2 + str(url2)
	
	if url2 == "": dialogok(str257 + space + "1070", '$LOCALIZE[113]', "", "")
	return url2
	
def oewindow(name):
	'''------------------------------
	---OpenELEC-Window---------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	xbmc.executebuiltin('RunScript(service.openelec.settings)')
	xbmc.sleep(500)
	mainwindowW = xbmc.getCondVisibility('Window.IsVisible(mainwindow.xml)')
	count = 0
	countbusy = 0
	while count < 20 and not mainwindowW and not xbmc.abortRequested:
		xbmc.sleep(100)
		count += 1
		mainwindowW = xbmc.getCondVisibility('Window.IsVisible(mainwindow.xml)')
		xbmc.sleep(100)
		'''---------------------------'''
	if count < 20:
		
		while mainwindowW and not xbmc.abortRequested:
			xbmc.sleep(100)
			mainwindowW = xbmc.getCondVisibility('Window.IsVisible(mainwindow.xml)')
			systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
			dialogbusyW = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
			count = 0
			while count < 5 and not dialogbusyW and not xbmc.abortRequested:
				count += 1
				xbmc.sleep(40)
				dialogbusyW = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
				if count == 5:
					mainwindowW = xbmc.getCondVisibility('Window.IsVisible(mainwindow.xml)')
					if name == "Bluetooth":
						list1 = [openelec1, openelec2, openelec6] #UP
						list2 = [openelec3, openelec4] #DOWN
						systemcurrentcontrol = findin_systemcurrentcontrol("2",list1,40,'','Action(Up)')
						systemcurrentcontrol = findin_systemcurrentcontrol("2",list2,40,'','Action(Down)')
						systemcurrentcontrol = findin_systemcurrentcontrol("0",openelec5,100,'','Action(Right)')
						'''---------------------------'''
					elif name == "Network":
						systemcurrentcontrol = findin_systemcurrentcontrol("0",openelec1,100,'','Action(Down)')
						systemcurrentcontrol = findin_systemcurrentcontrol("0",openelec4,100,'','Action(Up)')
						systemcurrentcontrol = findin_systemcurrentcontrol("0",openelec5,100,'','Action(Up)')
						systemcurrentcontrol = findin_systemcurrentcontrol("0",openelec6,100,'','Action(Down)')
						'''---------------------------'''
					if countbusy > 0: countbusy += -1
			if dialogbusyW: countbusy += 1
			xbmc.sleep(100)
			systemidle40 = xbmc.getCondVisibility('System.IdleTime(40)')
			if systemidle40 or countbusy >= 15: xbmc.executebuiltin('Action(Close)')
			'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "oewindow" + space + name + space2 + "countbusy" + space2 + str(countbusy)
	'''---------------------------'''
	
def notification(heading, message, icon, time):
	'''------------------------------
	---Show a Notification alert.----
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	'''heading : string - dialog heading | message : string - dialog message. | icon : [opt] string - icon to use. (default xbmcgui.NOTIFICATION_INFO/NOTIFICATION_WARNING/NOTIFICATION_ERROR) | time : [opt] integer - time in milliseconds (default 5000) | sound : [opt] bool - play notification sound (default True)'''
	
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	if '$LOCALIZE' in message or '$ADDON' in message: message = xbmc.getInfoLabel(message)
	
	icon = "misc/logo/logo8.png"
	
	dialog.notification(heading, message, icon, time)
	
	#if "addonString" in heading and not "+" in heading: heading = str(heading.encode('utf-8'))
	if "addonString" in heading: heading = str(heading.encode('utf-8'))
	elif '$LOCALIZE' in heading or '$ADDON' in heading: heading = str(heading)
	if "addonString" in message: message = str(message.encode('utf-8'))
	elif '$LOCALIZE' in message or '$ADDON' in message: message = str(message)
	
	time = str(time)
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin:
		try: print printfirst + "notification" + space2 + heading + space3 + message + space + time
		except: print printfirst + "notification" + "..."
		'''---------------------------'''
		
def removeaddons(addons, custom):
	if not systemplatformwindows:
		forceL = ['plugin.video.p2p-streams', 'script.htpt.smartbuttons', 'script.htpt.emu']
		output = ""
		output2 = ""
		i = 0
		returned = get_types(addons)
		if not "list" in returned: addons = [addons] #addons.append(addons)
		for addon in addons:
			i += 1
				
			path = ""
			path2 = ""
			path3 = ""
			if "1" in custom: path = ''+addons_path+''+ addon +''
			if "2" in custom: path2 = ''+addondata_path+''+ addon +''
			if "3" in custom: path3 = ''+packages_path+''+ addon +'*.zip'
			'''---------------------------'''
			
			if path != "": Afolders_count, Afolders_count2, Afiles_count = bash_count(path+'/*')
			else:
				Afolders_count = 0
				Afiles_count = 0
				'''---------------------------'''
			if path2 != "": Bfolders_count, Bfolders_count2, Bfiles_count = bash_count(path2+'/*')
			else:
				Bfolders_count = 0
				Bfiles_count = 0
				'''---------------------------'''
			if path3 != "": Cfolders_count, Cfolders_count2, Cfiles_count = bash_count(path3)
			else:
				Cfolders_count = 0
				Cfiles_count = 0
				'''---------------------------'''
			
			try:
				if os.listdir(path) == []: path_emptyfolder = "true"
				else: path_emptyfolder = "false"
				path_exist = "true"
				'''---------------------------'''
			except: path_exist = "false"
			try:
				if os.listdir(path2) == []: path2_emptyfolder = "true"
				else: path2_emptyfolder = "false"
				path2_exist = "true"
				'''---------------------------'''
			except: path2_exist = "false"
			
			if path != addons_path and path != addondata_path and path2 != addons_path and path2 != addondata_path and path3 != addons_path and path3 != addondata_path and (int(Afiles_count) < 1000 and int(Bfiles_count) < 1000 and int(Cfiles_count) < 100 or addon in forceL):
				if int(Afiles_count) > 0 or path_exist == "true":
					output = output + newline + str(i) + space2 + Afiles_count + space + "DELETED FROM" + space + path
					bash('rm -rf '+path+'',path)
					'''---------------------------'''
				if int(Bfiles_count) > 0 or path2_exist == "true":
					output = output + newline + str(i) + space2 + Bfiles_count + space + "DELETED FROM" + space + path2
					bash('rm -rf '+path2+'',path)
					'''---------------------------'''
				if int(Cfiles_count) > 0:
					output = output + newline + str(i) + space2 + Cfiles_count + space + "DELETED FROM" + space + path3
					bash('rm -rf '+path3+'',path)
					'''---------------------------'''
			else:
				output2 = output2 + newline + str(i) + space2 + "addon" + space2 + addon + space + "IGNORE"

		'''---------------------------'''
		print printfirst + "removeaddons" + space + "addons" + space2 + str(addons) + space + "custom" + space2 + custom + space + "output" + space2 + output + newline + output2
		'''---------------------------'''

def notification_common(custom):
	if custom == "2": notification('$LOCALIZE[79576]','$LOCALIZE[31407]',"",4000) #processing, please wait
	elif custom == "3": notification('$LOCALIZE[257]','$LOCALIZE[75002]',"",2000) #Error, Not Empty!
	elif custom == "4": notification('$LOCALIZE[79508]','$LOCALIZE[79376]',"",2000) #Check network connection!...
	elif custom == "5": notification('$LOCALIZE[79512]','$LOCALIZE[21451]',"",2000) #Check internet connection!...
	elif custom == "6": notification('$LOCALIZE[70099]',verrorstr,"",2000) #Your Action cause system error no.
	elif custom == "7": notification('$LOCALIZE[79494]','$LOCALIZE[31407]',"",2000) #HODAH NIHNESHET
	elif custom == "8":
		if os.path.exists(addons_path + 'skin.htpt'): notification('$LOCALIZE[31406]',"","",2000) #HAPEULA BUTLA
		else: notification(addonString(47),"","",2000) #HAPEULA BUTLA
	elif custom == "9":
		if os.path.exists(addons_path + 'skin.htpt'): notification('$LOCALIZE[31406]','$LOCALIZE[31412]',"",2000) #HAPEULA BUTLA, LO BUTZHU SINUHIM
		else: notification(addonString(47),addonString(48),"",2000) #HAPEULA BUTLA, LO BUTZHU SINUHIM
	elif custom == "10": notification('$LOCALIZE[79496]','$LOCALIZE[79497]' + "   -   " + '$LOCALIZE[79081]',"",4000) #AFSARUT ZOT NIMZET BEPITHU...
	elif custom == "11": notification('$LOCALIZE[257]', '$LOCALIZE[79078]', "", 1000)   #ERROR | NASE SHENIT KAHET
	elif custom == "12": notification('$LOCALIZE[78959]','$LOCALIZE[31407]',"",7000) #MATKIN HARHAVOT
	elif custom == "13": notification('$LOCALIZE[79072]',"...","",2000) #HAPEULA ISTAIMA BEHATZLAHA!
	elif custom == "14": notification('$LOCALIZE[74999]',"","",2000) #***Automatic Action***
	elif custom == "15":
		playlistlength = xbmc.getInfoLabel('Playlist.Length(video)')
		playlistposition = xbmc.getInfoLabel('Playlist.Position(video)')
		notification('$LOCALIZE[74998]','[COLOR=Yellow]' + playlistposition + space4 + playlistlength + '[/COLOR]',"",2000) #Playlist Done,
	
	elif custom == "16": notification("Downloading Files...","","",4000) #
	
	elif custom == "17": notification('$LOCALIZE[257]','$LOCALIZE[1446]',"",2000) #Error, Unknown
	elif custom == "18": notification('$LOCALIZE[79594]', '', "", 1000)   #
	elif custom == "20": notification('$LOCALIZE[79531]',"","",2000) #The system issued an automatic abort
	elif custom == "21": notification('$LOCALIZE[79505]','$LOCALIZE[31407]',"",4000) #The system is processing for solution...
	elif custom == "100": notification(addonString(46),'[COLOR=Yellow]' + addonString(90) + '[/COLOR]' + space + addonString(2) + space,"",7000) #MVAZEH TIKUN YADANI
	elif custom == "101": notification(addonString(46),'[COLOR=Yellow]' + addonString(91) + '[/COLOR]' + space + addonString(2) + space,"",7000) #MVAZEH TIKUN YADANI

def replaceAll(file,searchExp,replaceExp):
    '''UNUSED?'''
    for line in fileinput.input(file, inplace=1):
        if searchExp in line:
            line = line.replace(searchExp,replaceExp)
        sys.stdout.write(line)

def replaceAll2(file,searchExp,replaceExp):
    '''UNUSED?'''
    for line in fileinput.input(file, inplace=1):
        if searchExp in line:
            line = line.replace(searchExp,replaceExp)
        sys.stdout.write(line)
		#if line == 0:
			#add sys.stdout.write('\n')
			#add sys.stdout.write('import xbmc, xbmcgui, xbmcaddon')

def write_to_file(path, content, append, silent=False): #UNUSED
	'''``r/r+/w/w+/a/a+'''
	try:
		if append:
			f = open(path, 'a')
		else:
			f = open(path, 'w')
		f.write(content)
		f.close()
		return True
	except:
		if not silent:
			print("Could not write to " + path)
		return False

def read_from_file(path, silent=False):
    try:
        f = open(path, 'r')
        r = f.read()
        f.close()
        return str(r)
    except:
        if not silent:
            print("Could not read from " + path)
        return None
		
def regex_from_to(text, from_string, to_string, excluding=True):
    import re
    TypeError = ""
    if excluding:
        try: r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text).group(1)
        except Exception, TypeError:
            r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text)
            if r == None: r = ""
    else:
        try: r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text).group(1)
        except Exception, TypeError:
            r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text)
            if r == None: r = from_string + to_string
	
    
    if admin or TypeError != "": print printfirst + "regex_from_to" + space + "r" + space2 + str(r) + space + "TypeError" + space2 + str(TypeError)
    return str(r)

def regex_get_all(text, start_with, end_with): #UNUSED
    import re
    r = re.findall("(?i)" + start_with + "([\S\s]+?)" + end_with, text)
    return r
	
def replace_word(infile,old_word,new_word):
	if not os.path.isfile(infile):
		print ("Error on replace_word, not a regular file: "+infile)
	else:
		f1=open(infile,'r').read()
		f2=open(infile,'w')
		m=f1.replace(old_word,new_word)
		f2.write(m)

def settingschange(window,systemgetbool,falsetrue,force,string1,string2):
	'''systemgetbool'''
	systemgetbool2 = xbmc.getCondVisibility('System.GetBool('+ systemgetbool +')')
	systemgetbool2str = str(systemgetbool2)
	if systemgetbool2str != falsetrue or force == 'yes':
		if admin: xbmc.executebuiltin('Notification(Admin,settingschange '+ systemgetbool +' ('+ systemgetbool2str +'),10000)')
		xbmc.executebuiltin('ActivateWindow('+ window +')')
		'''Right'''
		systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
		if not string1 in systemcurrentcontrol:
			xbmc.executebuiltin('Action(Right)')
			xbmc.sleep(100)
			systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
			if not string1 in systemcurrentcontrol:
				xbmc.executebuiltin('Action(Right)')
				xbmc.sleep(100)
				systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
				if not string1 in systemcurrentcontrol:
					xbmc.executebuiltin('Action(Right)')
					xbmc.sleep(100)
					systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
					if not string1 in systemcurrentcontrol:
						xbmc.executebuiltin('Action(Right)')
						xbmc.sleep(100)
						systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
		xbmc.sleep(40)
		if string1 in systemcurrentcontrol: xbmc.executebuiltin('Action(Down)')
		
		'''Down'''
		xbmc.sleep(100)
		systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
		if not string2 in systemcurrentcontrol:
			xbmc.executebuiltin('Action(Down)')
			xbmc.sleep(100)
			systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
			if not string2 in systemcurrentcontrol:
				xbmc.executebuiltin('Action(Down)')
				xbmc.sleep(100)
				systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
				if not string2 in systemcurrentcontrol:
					xbmc.executebuiltin('Action(Down)')
					xbmc.sleep(100)
					systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
					if not string2 in systemcurrentcontrol:
						xbmc.executebuiltin('Action(Down)')
						xbmc.sleep(100)
						systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
		xbmc.sleep(40)
		
		'''Select'''
		systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
		if string2 in systemcurrentcontrol:
			xbmc.executebuiltin('Action(Select)')
			xbmc.sleep(100)
			if systemgetbool2 != falsetrue and force == 'yes': xbmc.executebuiltin('Action(Select)')
			systemgetbool2 = xbmc.getCondVisibility('System.GetBool('+ systemgetbool +')')
			if admin: xbmc.sleep(1000)
			if systemgetbool2 != falsetrue and force == 'yes' or force == 'no': xbmc.executebuiltin('Action(Back)')
			if not systemgetbool2: xbmc.executebuiltin('Notification('+ systemcurrentcontrol +',,5000)')
			
def setGeneral_ScriptON(custom, General_ScriptON, mode):
	'''check if this script is already running'''
	homebuttonsrunning = xbmc.getInfoLabel('Skin.HasSetting(homebuttonsrunning)')
	if mode == None: mode = ""
	if not validation2 or addonID == "script.htpt.homebuttons":
		notificationoffL = ["script.htpt.debug","service.htpt.fix"]
		if custom == "0":
			'''------------------------------
			---SCRIPT-START------------------
			------------------------------'''
			if General_ScriptON == "true":
				'''------------------------------
				---General_ScriptON-TRUE->FALSE--
				------------------------------'''
				count = 0
				while (General_ScriptON == "true" and count <= 3) and not xbmc.abortRequested:
					if count > 0 and not startup_aW:
						if not addonID in notificationoffL:
							if count == 1: notification(addonString(119) + ".", "", "", 1000)
							elif count == 2: notification(addonString(119) + "..", "", "", 1000)
							#elif count == 3: notification(addonString(119) + "...", "", "", 1000)
							'''---------------------------'''
					xbmc.sleep(500)
					count += 1
					countS = str(count)
					General_ScriptON = getsetting('General_ScriptON')
					systemidle1 = xbmc.getCondVisibility('System.IdleTime(1)')
					if General_ScriptON != "true" and systemidle1:
						setsetting_custom1(addonID,'General_ScriptON',"true")
						if addonID == "script.htpt.homebuttons": setSkinSetting("1",'homebuttonsrunning',"true")
						count = 5
					else:
						if count == 3 and systemidle1 and mode == "":
							setsetting_custom1(addonID,'General_ScriptON',"false")
							if addonID == "script.htpt.homebuttons": setSkinSetting("1",'homebuttonsrunning',"false")
							if not addonID in notificationoffL and admin: xbmc.executebuiltin('Notification(Admin,count == 3 and systemidle1 '+ countS +',1000)')
						if count > 1 and not systemidle1:
							if not addonID in notificationoffL and admin: xbmc.executebuiltin('Notification(Admin,count > 1 and not systemidle1 '+ countS +',1000)')
							if not admin and not addonID in notificationoffL: notification_common("11")
							sys.exit()
			else:
				'''------------------------------
				---General_ScriptON-FALSE->-TRUE-
				------------------------------'''
				setsetting_custom1(addonID,'General_ScriptON',"true")
				if addonID == "script.htpt.homebuttons": setSkinSetting("1",'homebuttonsrunning',"true")
				if not addonID in notificationoffL and admin: xbmc.executebuiltin('Notification(General_ScriptON == true,start,1000)')
				'''---------------------------'''
				
		elif custom == "1":
			'''------------------------------
			---SCRIPT-END--------------------
			------------------------------'''
			count = 0
			while General_ScriptON != "true" and count < 3 and not xbmc.abortRequested:
				xbmc.sleep(500)
				count += 1
				countS = str(count)
				General_ScriptON = getsetting('General_ScriptON')
				'''---------------------------'''
				
			if General_ScriptON == "true":
				setsetting_custom1(addonID,'General_ScriptON',"false")
				if addonID == "script.htpt.homebuttons": setSkinSetting("1",'homebuttonsrunning',"false")
				if not addonID in notificationoffL and admin: xbmc.executebuiltin('Notification(General_ScriptON == false,end,1000)')
				sys.exit()
				'''---------------------------'''
	
	homebuttonsrunning2 = xbmc.getInfoLabel('Skin.HasSetting(homebuttonsrunning)')
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "setGeneral_ScriptON" + space + "custom" + space2 + custom + space + "General_ScriptON" + space2 + General_ScriptON + space + "mode" + space2 + mode + space + "addonID" + space2 + str(addonID) + space + "homebuttonsrunning/2" + space2 + str(homebuttonsrunning) + space4 + str(homebuttonsrunning2)
	'''---------------------------'''
	
def setSkinSetting(custom,set1,set1v):
	'''------------------------------
	---SET-SKIN-SETTING-1------------
	------------------------------'''
	#from variables import str20122.encode('utf-8')
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	admin2 = xbmc.getInfoLabel('Skin.HasSetting(Admin2)')
	
	if '$LOCALIZE' in set1v or '$ADDON' in set1v: set1v = xbmc.getInfoLabel(set1v)
	''' custom: 0 = Skin.String, 1 = Skin.HasSetting'''
	'''---------------------------'''
	if custom == "0":
		setting1 = xbmc.getInfoLabel('Skin.String('+ set1 +')')
		if setting1 != set1v: xbmc.executebuiltin('Skin.SetString('+ set1 +','+ set1v +')')
		'''---------------------------'''
		
	elif custom == "1":
		setting1 = xbmc.getInfoLabel('Skin.HasSetting('+ set1 +')')
		'''---------------------------'''
		if setting1 == str20122.encode('utf-8') or setting1 == "true": setting1 = "true"
		else: setting1 = "false"
		'''---------------------------'''
		if set1v == str20122.encode('utf-8') or set1v == "true": set1v = "true"
		else: set1v = "false"
		'''---------------------------'''
		if setting1 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set1 +')')
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if setting1 != set1v and admin and admin2: print printfirst + "setSkinSetting" + space3 + custom + space + set1 + space2 + setting1 + " - " + set1v
	'''---------------------------'''

def setSkinSetting5(custom,set1,set1v,set2,set2v,set3,set3v,set4,set4v,set5,set5v):
	'''------------------------------
	---SET-SKIN-SETTING-5------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	''' custom: 0 = Skin.String, 1 = Skin.HasSetting'''
	if custom == "0":
		setting1 = xbmc.getInfoLabel('Skin.String('+ set1 +')')
		setting2 = xbmc.getInfoLabel('Skin.String('+ set2 +')')
		setting3 = xbmc.getInfoLabel('Skin.String('+ set3 +')')
		setting4 = xbmc.getInfoLabel('Skin.String('+ set4 +')')
		setting5 = xbmc.getInfoLabel('Skin.String('+ set5 +')')
		'''---------------------------'''
	elif custom == "1":
		setting1 = xbmc.getInfoLabel('Skin.HasSetting('+ set1 +')')
		setting2 = xbmc.getInfoLabel('Skin.HasSetting('+ set2 +')')
		setting3 = xbmc.getInfoLabel('Skin.HasSetting('+ set3 +')')
		setting4 = xbmc.getInfoLabel('Skin.HasSetting('+ set4 +')')
		setting5 = xbmc.getInfoLabel('Skin.HasSetting('+ set5 +')')
		'''---------------------------'''
		if setting1 == str20122.encode('utf-8') or setting1 == "true": setting1 = "true"
		else: setting1 = "false"
		if setting2 == str20122.encode('utf-8') or setting1 == "true": setting2 = "true"
		else: setting2 = "false"
		if setting3 == str20122.encode('utf-8') or setting1 == "true": setting3 = "true"
		else: setting3 = "false"
		if setting4 == str20122.encode('utf-8') or setting1 == "true": setting4 = "true"
		else: setting4 = "false"
		if setting5 == str20122.encode('utf-8') or setting1 == "true": setting5 = "true"
		else: setting5 = "false"
		'''---------------------------'''
		if set1v == str20122.encode('utf-8') or set1v == "true": set1v = "true"
		else: set1v = "false"
		if set2v == str20122.encode('utf-8') or set1v == "true": set2v = "true"
		else: set2v = "false"
		if set3v == str20122.encode('utf-8') or set1v == "true": set3v = "true"
		else: set3v = "false"
		if set4v == str20122.encode('utf-8') or set1v == "true": set4v = "true"
		else: set4v = "false"
		if set5v == str20122.encode('utf-8') or set1v == "true": set5v = "true"
		else: set5v = "false"
		'''---------------------------'''
	if custom == "0":
		if setting1 != set1v: xbmc.executebuiltin('Skin.SetString('+ set1 +','+ set1v +')')
		if setting2 != set2v: xbmc.executebuiltin('Skin.SetString('+ set2 +','+ set2v +')')
		if setting3 != set3v: xbmc.executebuiltin('Skin.SetString('+ set3 +','+ set3v +')')
		if setting4 != set4v: xbmc.executebuiltin('Skin.SetString('+ set4 +','+ set4v +')')
		if setting5 != set5v: xbmc.executebuiltin('Skin.SetString('+ set5 +','+ set5v +')')
		'''---------------------------'''
	elif custom == "1":
		if setting1 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set1 +')')
		if setting2 != set2v: xbmc.executebuiltin('Skin.ToggleSetting('+ set2 +')')
		if setting3 != set3v: xbmc.executebuiltin('Skin.ToggleSetting('+ set3 +')')
		if setting4 != set4v: xbmc.executebuiltin('Skin.ToggleSetting('+ set4 +')')
		if setting5 != set5v: xbmc.executebuiltin('Skin.ToggleSetting('+ set5 +')')
		'''---------------------------'''
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''	
	if admin and (setting1 != set1v or setting2 != set2v or setting3 != set3v or setting4 != set4v or setting5 != set5v): print printfirst + "setSkinSetting5" + space2 + set1 + space + set2 + space + set3 + space + set4 + space + set5 + space3
	'''---------------------------'''

def setsetting_custom1(addon,set1,set1v):
	'''------------------------------
	---SET-ADDON-SETTING-1-----------
	------------------------------'''
	getsetting_custom          = xbmcaddon.Addon(addon).getSetting
	setsetting_custom          = xbmcaddon.Addon(addon).setSetting
	
	set = getsetting_custom(set1)
	set1v = str(set1v)
	'''---------------------------'''
	if set != set1v:
		setsetting_custom(set1,set1v)
		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		print printfirst + "setsetting_custom1" + space2 + addon + space + set1 + space2 + set1v + space3
		'''---------------------------'''

def supportcheck(name, supported, totalspace=1, Intel=False, silence=False):
	'''------------------------------
	---CHECK-IF-MODEL-IS-SUPPORTED---
	------------------------------'''
	id10str = xbmc.getInfoLabel('Skin.String(ID10)')
	
	try: name = name.encode('utf-8')
	except: pass
	
	try: servicehtptfix_Purchase_TotalSpaceN = int(servicehtptfix_Purchase_TotalSpace)
	except: servicehtptfix_Purchase_TotalSpaceN = 0
	
	supported.append("ADMIN")
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	extra = ""
	printpoint = ""
	returned = ""
	if not id10str in supported and servicehtptfix_Purchase_TotalSpaceN < totalspace or (Intel == True and servicehtptfix_Purchase_Intel == "false"):
		'''------------------------------
		---UNSUPPORT-DEVICE--------------
		------------------------------'''
		printpoint = printpoint + "9"
		if id10str == "": id10str = "?"
		if "?" in id10str: extra = '[CR]' + servicehtptfix_Purchase_Model
		if silence == False: dialogok('$LOCALIZE[79501]',str74540.encode('utf-8') % (id10str) + extra, str74543.encode('utf-8') % (name) ,str74542.encode('utf-8'))
		'''---------------------------'''
	else: printpoint = printpoint + "7"
	
	if "9" in printpoint: returned = "skip"
	else: returned = "ok"
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "supportcheck_LV" + printpoint + space + "name" + space2 + str(name) + space + "supported" + space2 + str(supported) + space + "totalspace" + space2 + str(totalspace) + space + "returned" + space2 + returned
	'''---------------------------'''
	
	'''---------------------------'''
	return returned
	
def datetostring(dt_str):
	TypeError = ""
	printpoint = ""
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	admin2 = xbmc.getInfoLabel('Skin.HasSetting(Admin2)')
	
	
	dt_str2 = str(dt_str)
	dt_str2 = dt_str2.replace("00:00:00","",1)
	dt_str2 = dt_str2.replace("0:00:00","",1)
	dt_str2 = dt_str2.replace(" ","",1)
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin and admin2 or str(TypeError) != "": print printfirst + "datetostring_LV" + printpoint + space + "dt_str" + space2 + dt_str + space + "dt_str2" + space2 + dt_str2
	'''---------------------------'''
	return dt_str2

def getfileID(file):
	fileID = ""
	if file == "Sega Master System.zip": fileID = "c5ingtyhgkwjmx7"
	elif file == "Nintendo 64.zip": fileID = "mwo6jqoey4tnsgx"
	elif file == "TurboGrafx 16.zip": fileID = "0zg9x4uw1hrm8zb"
	elif file == "Sega Genesis.zip": fileID = "b8lph86pb4b5e0l"
	elif file == "Nintendo.zip": fileID = "nt05zl4ygnynxen"
	elif file == "Super Nintendo.zip": fileID = "dficnt390sp2j8w"
	'''---------------------------'''
	return fileID

def stringtodate(dt_str, dt_func):
	from datetime import datetime
	TypeError = ""
	extra = ""
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	admin2 = xbmc.getInfoLabel('Skin.HasSetting(Admin2)')
	printpoint = ""
	count = 0
	dt_str = str(dt_str)
	dt_str = dt_str.replace(" ","",1)
	dt_obj = ""
	#dt_str = '9/24/2010 5:03:29 PM'
	#dt_func = '%m/%d/%Y %I:%M:%S %p'
	if dt_str == "" or dt_func =="":
		printpoint = printpoint + "9"
		if admin: notification("stringtodate_ERROR!","isEMPTY","",1000)
	else:
		while count < 10 and not "7" in printpoint and not xbmc.abortRequested:
			try:
				dt_obj = datetime.strptime(dt_str, dt_func)
				printpoint = printpoint + "7"
			except Exception, TypeError:
				dt_obj = "error"
				if admin: notification("stringtodate_ERROR!","error","",1000)
			count += 1
			xbmc.sleep(500)

	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	dt_objS = str(dt_obj)
	if TypeError != "": extra = newline + "TypeError" + space2 + str(TypeError) + space + "count" + space2 + str(count)
	if admin and admin2 or extra != "": print printfirst + "stringtodate_LV" + printpoint + space + "dt_str" + space2 + dt_str + space + "dt_objS" + space2 + dt_objS + extra
	'''---------------------------'''
	return dt_obj
	
class TextViewer_Dialog(xbmcgui.WindowXMLDialog):
    ACTION_PREVIOUS_MENU = [9, 92, 10]

    def __init__(self, *args, **kwargs):
        xbmcgui.WindowXMLDialog.__init__(self)
        self.text = kwargs.get('text')
        self.header = kwargs.get('header')

    def onInit(self):
        self.getControl(1).setLabel(self.header)
        self.getControl(5).setText(self.text)

    def onAction(self, action):
        if action in self.ACTION_PREVIOUS_MENU:
            self.close()

    def onClick(self, controlID):
        pass

    def onFocus(self, controlID):
        pass

def ActivateWindow(custom, addon, url, return0, wait=True):
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	containernumitems = ""
	printpoint = ""
	count = ""
	if return0 == 0: return0 = ',return'
	else: return0 = ""
	return0 = str(return0)
	
	if custom == "0": xbmc.executebuiltin('RunAddon('+ addon +')')
	elif custom == "1": xbmc.executebuiltin('ActivateWindow(10025,'+ url +' '+ return0 +')')
	
	'''---------------------------'''
	if wait == True:
		printpoint = printpoint + "2"
		containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
		containernumitems = xbmc.getInfoLabel('Container.NumItems')
		count = 0
		while count < 10 and (not addon in containerfolderpath or containernumitems == "0") and not xbmc.abortRequested:
			count += 1
			xbmc.sleep(200)
			containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
			containernumitems = xbmc.getInfoLabel('Container.NumItems')
			systemidle1 = xbmc.getCondVisibility('System.IdleTime(1)')
			if systemidle1: xbmc.sleep(200)
			'''---------------------------'''
		if count < 10:
			if containerfolderpath == url: printpoint = printpoint + "5"
			else: printpoint = printpoint + "7"
		else: printpoint = printpoint + "9"
	else: printpoint = printpoint + "8"
	
	ViewSetFocus(admin)
	print printfirst + "ActivateWindow_LV" + printpoint + space + "addon" + space2 + addon + space + "containernumitems" + space2 + containernumitems + space + "count" + space2 + str(count)
	if "7" in printpoint: return "ok"
	elif "5" in printpoint: return "ok2"
	else: return ""
	
def ViewSetFocus(admin):
	containerviewmode = xbmc.getInfoLabel('Container.Viewmode')
	if containerviewmode == "addonsPT" or containerviewmode == "GeneralPT": viewmode = 50
	elif containerviewmode == "romPT": viewmode = 55
	elif containerviewmode == "IconsPT": viewmode = 58
	elif containerviewmode == "MoviesPT": viewmode = 57
	else: viewmode = ""
	if viewmode != "": xbmc.executebuiltin('Control.SetFocus('+ str(viewmode) +')')
	
	if admin: print printfirst + "ViewSetFocus" + space + "containerviewmode" + space2 + containerviewmode + space + "viewmode" + space2 + str(viewmode)