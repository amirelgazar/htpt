import xbmc, xbmcgui
import os, sys
import subprocess
import xbmcaddon


from variables import *
from modules import *

class resetsettings:
	setsetting_custom1('service.htpt','Time_Delay',"0")
	setsetting_custom1('service.htpt','Time_Pass',"0")
	setsetting_custom1('service.htpt','Time_Shutdown',"")
	setsetting_custom1('service.htpt','General_Timer',"0")
	setsetting_custom1('service.htpt','General_ScriptON',"false")
	setsetting_custom1('service.htpt','Skin_UpdateCount',"0")
	setsetting_custom1('service.htpt','Skin_UpdateCount2',"0")
	setsetting_custom1('service.htpt','Skin_UpdateTimer',"0")
	setsetting_custom1('service.htpt','Skin_UpdateLog',"true")
	setsetting_custom1('service.htpt','Skin_Suspend',"false")
	setsetting_custom1('service.htpt','Skin_Check',"0")
				
	if not systemplatformwindows:
		setSkinSetting("1",'Connected',"false")
		setSkinSetting("1",'Connected2',"false")
		setSkinSetting("1",'Connected3',"false")	
		'''---------------------------'''
		
	if datenowS == "": datenow, datenowS, dateafter, dateafterS, yearnow, yearnowS, daynow, daynowS, timenowS, timeow2S, timenow3S, timenow4S = refresh_datetime(admin, datenowS, timenowS)
	
class startup:
	if not systemplatformwindows:
		if Skin_Name != 'skin.htpt': os.system('sh /storage/.kodi/addons/service.htpt/specials/scripts/copyskin.sh')
		os.system('sh /storage/.kodi/addons/service.htpt/specials/scripts/copy2.sh') ; xbmc.sleep(500)
		os.system('sh /storage/.kodi/addons/service.htpt/specials/scripts/copyonce.sh') ; xbmc.sleep(500)
		'''---------------------------'''
	if scripthtptinstall_User_ID2 != "" or id40str or scripthtptinstall_Skin_Suspend == "true": xbmc.executebuiltin('RunScript(script.htpt.install,,?mode=27)')
	
class main:
	'''------------------------------
	---SERVICE-LOOP------------------
	------------------------------'''
	setTime_Start(admin)
	updateskincheck = 'false'
	count = 0
	while 1 and not xbmc.abortRequested:
		
		'''------------------------------
		---VARIABLES---------------------
		------------------------------'''
		systeminternetstate = xbmc.getInfoLabel('System.InternetState')
		try: networkipaddress = xbmc.getInfoLabel('Network.IPAddress')
		except: print printfirst + "main_Error_" + "networkipaddress"
		connected = xbmc.getInfoLabel('Skin.HasSetting(Connected)')
		'''---------------------------'''
		TypeError = ""
		admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
		admin2 = xbmc.getInfoLabel('Skin.HasSetting(Admin2)')
		playerhasvideo = xbmc.getCondVisibility('Player.HasVideo')
		playerhasmedia = xbmc.getCondVisibility('Player.HasMedia')
		playerpaused = xbmc.getCondVisibility('Player.Paused')
		systemidle3 = xbmc.getCondVisibility('System.IdleTime(3)')
		performance = xbmc.getInfoLabel('Skin.HasSetting(Performance)')
		systemidle120 = xbmc.getCondVisibility('System.IdleTime(120)') #2M
		systemidle540 = xbmc.getCondVisibility('System.IdleTime(540)') #9M
		systemidle600 = xbmc.getCondVisibility('System.IdleTime(600)') #10M
		systemidle900 = xbmc.getCondVisibility('System.IdleTime(900)') #15M
		systemidle1200 = xbmc.getCondVisibility('System.IdleTime(1200)') #20M
		systemidle300 = xbmc.getCondVisibility('System.IdleTime(300)')
		systemidle5400 = xbmc.getCondVisibility('System.IdleTime(5400)') #1.5H
		validation = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION)')
		validation2 = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION2)')
		home_aW = xbmc.getCondVisibility('Window.IsActive(0)')
		'''---------------------------'''
		getsetting         = xbmcaddon.Addon().getSetting
		setsetting         = xbmcaddon.Addon().setSetting
		General_Timer = getsetting('General_Timer')
		try: General_TimerN = int(General_Timer)
		except: General_TimerN = 0
		Time_Delay = getsetting('Time_Delay')
		try: Time_DelayN = int(Time_Delay)
		except Exception, TypeError: Time_DelayN = 0
		Time_Start = getsetting('Time_Start')
		Time_Pass = getsetting('Time_Pass')
		Time_Shutdown = getsetting('Time_Shutdown')
		htptskinversion = xbmc.getInfoLabel('System.AddonVersion(skin.htpt)')
		Skin_UpdateCount = getsetting('Skin_UpdateCount')
		Skin_UpdateCount2 = getsetting('Skin_UpdateCount2')
		Skin_UpdateTimer = getsetting('Skin_UpdateTimer')
		try: Skin_UpdateTimerN = int(Skin_UpdateTimer)
		except: Skin_UpdateTimerN = 0
		Skin_Update = getsetting('Skin_Update')
		Skin_UpdateDate = getsetting('Skin_UpdateDate')
		Skin_UpdateLog = getsetting('Skin_UpdateLog')
		Skin_Version = getsetting('Skin_Version')
		Skin_Check = getsetting('Skin_Check')
		
		if count in A10 and not systemplatformwindows: Skin_Name = setSkin_Name(Skin_Name)
		Ping_Rate = getsetting('Ping_Rate')
		'''---------------------------'''
		Library_UpdateDate = getsetting('Library_UpdateDate')
		Library_CleanDate = getsetting('Library_CleanDate')
		'''---------------------------'''
		
		#if admin and General_TimerN in A10: print printfirst + "VARCHECK1" + space2 + "Skin_UpdateLog" + space2 + Skin_UpdateLog + space + "Time_Pass" + space2 + Time_Pass + space + "General_Timer" + space2 + General_Timer
		#xbmc.executebuiltin('RunScript(service.htpt)')
		'''---------------------------'''
		
		'''------------------------------
		---count-------------------------
		------------------------------'''
		
		if not systemplatformwindows and (not systemidle300 or General_TimerN in A10): xbmc.sleep(50)
		elif systemplatformwindows and (not systemidle300 or General_TimerN in A10): xbmc.sleep(800)
		else: xbmc.sleep(1000)
		if performance: xbmc.sleep(2000)
		'''---------------------------'''
		
		'''------------------------------
		---setGeneral_Timer--------------
		------------------------------'''
		setGeneral_Timer(admin, admin2, General_Timer, count)
		'''---------------------------'''
		
		'''------------------------------
		---setTime_Delay-----------------
		------------------------------'''
		setTime_Delay(admin, admin2, Time_Delay, count, systemidle3, playerhasvideo, playerhasmedia, playerpaused)
		'''---------------------------'''
		
		#if admin and General_TimerN in A10: print printfirst + "VARCHECK2" + space2 + "Skin_UpdateLog" + space2 + Skin_UpdateLog + space + "Time_Pass" + space2 + Time_Pass + space + "General_Timer" + space2 + General_Timer
		
		if General_Timer == "1":
			'''------------------------------
			---SetTime_Pass------------------
			------------------------------'''
			SetTime_Pass(admin, admin2, Time_Pass)
			'''---------------------------'''
		
		if Skin_UpdateTimer != "0":
			'''------------------------------
			---Skin_UpdateTimer--------------
			------------------------------'''
			SetSkin_UpdateTimer(admin, admin2, Skin_UpdateTimer)
			'''---------------------------'''
		
		if Skin_UpdateTimer == "0" and Skin_UpdateCount == Skin_UpdateCount2:
			'''------------------------------
			---setSkin_UpdateCount-----------
			------------------------------'''
			Skin_UpdateCount2 = setSkin_UpdateCount2(admin, Skin_UpdateCount, Time_Pass)
			'''---------------------------'''
				
		if Skin_UpdateCount2 != Skin_UpdateCount and (systemidle120 or admin or Skin_UpdateCount == "0") and not playerhasvideo and connected:
			'''------------------------------
			---UpdateAddons------------------
			------------------------------'''
			UpdateAddons(admin, Skin_UpdateCount, Skin_UpdateCount2)
			'''---------------------------'''

		if (Skin_Update != "true" and (((Skin_UpdateTimerN < 70 or admin) and Skin_UpdateTimerN > 0) or Skin_Version != htptskinversion)) or (Skin_Update == "true" and Skin_Version == htptskinversion):
			'''------------------------------
			---Skin_Update-(NEW-ONLY)--------
			------------------------------'''
			setSkin_Update(admin, Skin_Version, htptskinversion, Skin_Update)
			'''---------------------------'''

		if Skin_Update == "true" or Skin_UpdateDate == "":
			'''------------------------------
			---setSkin_UpdateDate-(NEW-ONLY)-
			------------------------------'''
			setSkin_UpdateDate(admin, Skin_Version, htptskinversion, Skin_Update, Skin_UpdateDate)
			'''---------------------------'''
			
		if Skin_Update == "true" or Skin_Version == "":
			'''------------------------------
			---setSkin_Version---------------
			------------------------------'''
			setSkin_Version(admin, Skin_Version, htptskinversion)
			'''---------------------------'''
		
		if Skin_Version == htptskinversion and Skin_UpdateLog == "true" and Skin_UpdateDate != "" and systemidle3 and not playerhasvideo and home_aW and not validation and not validation2:
			'''------------------------------
			---setSkin_UpdateLog-------------
			------------------------------'''
			printpoint = ""
			dialogbusyW = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
			dialogokW = xbmc.getCondVisibility('Window.IsVisible(DialogOk.xml)')
			dialogprogressW = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
			dialogselectW = xbmc.getCondVisibility('Window.IsVisible(DialogSelect.xml)')
			dialogtextviewerW = xbmc.getCondVisibility('Window.IsVisible(DialogTextViewer.xml)')
			dialogyesnoW = xbmc.getCondVisibility('Window.IsVisible(DialogYesNo.xml)')
			startupW = xbmc.getCondVisibility('Window.IsVisible(Startup.xml)')
			custom1191W = xbmc.getCondVisibility('Window.IsVisible(Custom1191.xml)')
			'''---------------------------'''
			if not dialogbusyW and not dialogokW and not dialogprogressW and not dialogselectW and not dialogtextviewerW and not dialogyesnoW and not startupW and not custom1191W:
				printpoint = printpoint + "1"
				from variables import datenowS
				if datenowS != "": #PREVENT RANDOM BUG WITH datetime
					printpoint = printpoint + "2"
					setSkin_UpdateLog(admin, Skin_Version, Skin_UpdateDate, datenowS, Skin_Name)
					'''---------------------------'''
					
			'''------------------------------
			---PRINT-END---------------------
			------------------------------'''
			if admin and not "2" in printpoint: print printfirst + "setSkin_UpdateLog_LV" + printpoint + space + space2 + Skin_UpdateLog + space + "Time_Start" + space2 + Time_Start
			'''---------------------------'''
		
		if General_TimerN in A10:
			'''------------------------------
			---setPing_Rate-(1-5)------------
			------------------------------'''
			Ping_1 = getsetting('Ping_1')
			Ping_2 = getsetting('Ping_2')
			Ping_3 = getsetting('Ping_3')
			Ping_4 = getsetting('Ping_4')
			Ping_5 = getsetting('Ping_5')
			Ping_6 = getsetting('Ping_6')
			Ping_7 = getsetting('Ping_7')
			Ping_8 = getsetting('Ping_8')
			Ping_9 = getsetting('Ping_9')
			Ping_10 = getsetting('Ping_10')
			'''---------------------------'''
			setPing_Rate(admin, admin2, Ping_Rate, Ping_1, Ping_2, Ping_3, Ping_4, Ping_5, Ping_6, Ping_7, Ping_8, Ping_9, Ping_10)
			'''---------------------------'''
			
		'''------------------------------
		---validationstartup-------------
		------------------------------'''
		validationstartup(admin)
		'''---------------------------'''
		
		'''------------------------------
		---videoplayertweak--------------
		------------------------------'''
		videoplayertweak(admin,playerhasvideo)
		'''---------------------------'''
		
		if Time_DelayN == 10: #TEST
			pass
			#if not validation and not validation2: screensaver(admin, playerhasvideo)
			'''---------------------------'''
		elif Time_DelayN == 20: #TEST
			pass
			#if not validation and not validation2: LibraryUpdate(admin, Library_CleanDate, Library_UpdateDate)
			'''---------------------------'''
			
		if not systemidle300: #not systemidle300:
			'''------------------------------
			---connectioncheck---------------
			------------------------------'''
			connectioncheck(admin, admin2, count, systemidle3)
			'''---------------------------'''
			
			if Time_Shutdown != "":
				dialogokW = xbmc.getCondVisibility('Window.IsVisible(DialogOk.xml)')
				dialogHeader = xbmc.getInfoLabel('Control.GetLabel(1)')
				setsetting_custom1('service.htpt','Time_Shutdown',"")
				if dialogokW and dialogHeader == str79532.encode('utf-8'):
					xbmc.executebuiltin('dialog.close(okdialog)')
					notification_common("8")
			
			'''------------------------------
			---setPing-----------------------
			------------------------------'''
			#setPing(admin,count,systemidle3)
			'''---------------------------'''
		else:
			if General_TimerN in A10: connectioncheck(admin, admin2, count, systemidle3)
			
			if Time_DelayN > 540 and Time_DelayN < 600: #systemidle540 and not systemidle600:
				pass
				'''---------------------------'''
			elif Time_DelayN == 600: #systemidle600 and not systemidle900:
				if not validation and not validation2: screensaver(admin, playerhasvideo)
				'''---------------------------'''
				
			elif Time_DelayN == 900: #systemidle900 and not systemidle1200:
				if not validation and not validation2: LibraryUpdate(admin, Library_CleanDate, Library_UpdateDate)
				'''---------------------------'''
				
			elif Time_DelayN > 5400 and not systemplatformwindows: #systemidle5400 :
				doAutoShutdown(admin, Time_Shutdown, Time_DelayN)
				'''---------------------------'''
					
			elif Skin_Check != "0": Skin_Check = 0
		
		if count < 60: count += 1
		elif count >= 60: count = 1
		'''---------------------------'''
		
		if TypeError != "": print printfirst + "service.py" + space + "TypeError" + space2 + str(TypeError)
		
		addon = 'script.htpt.install'
		if xbmc.getCondVisibility('System.HasAddon('+ addon +')'):
			getsetting_scripthtptinstall         = xbmcaddon.Addon(addon).getSetting
			scripthtptinstall_Skin_Suspend = getsetting_scripthtptinstall('Skin_Suspend')
			'''---------------------------'''
		else: scripthtptinstall_Skin_Suspend = ""
		
		if scripthtptinstall_Skin_Suspend != "true" and not systemplatformwindows and not playerhasvideo:
			if Skin_Name != 'skin.htpt' and Skin_Name != 'N/A':
				Skin_Check2 = calculate('service.htpt','Skin_Check','1',Skin_Check)
				Skin_Check2N = int(Skin_Check2)
				setsetting('Skin_Check', Skin_Check2)

				if Skin_Check2N > 2:
					'''------------------------------
					---ERROR-1020--------------------
					------------------------------'''
					notification(addonString(41), addonString(9), "", 2000)
					setsetting_custom1('service.htpt','Skin_Check',"-10")
					xbmc.sleep(500)
					os.system('sh /storage/.kodi/addons/service.htpt/specials/scripts/copyskin.sh')
					'''---------------------------'''
			
	if xbmc.abortRequested:
		print printfirst + "Error 1170: AbortRequested!"
		sys.exit()
		'''---------------------------'''
		
		
#repeat()