#import xbmc, os, subprocess, sys
#import xbmc, xbmcgui, xbmcaddon
import xbmc, xbmcgui, xbmcaddon
import subprocess, os, sys
#import datetime, time

from variables import *

'''------------------------------
---service.htpt------------------
------------------------------'''
def replace_word(infile,old_word,new_word):
    if not os.path.isfile(infile):
        print ("Error on replace_word, not a regular file: "+infile)
        sys.exit(1)

    f1=open(infile,'r').read()
    f2=open(infile,'w')
    m=f1.replace(old_word,new_word)
    f2.write(m)

def stringtodate(dt_str, dt_func):
	from datetime import datetime
	#dt_str = '9/24/2010 5:03:29 PM'
	#dt_func = '%m/%d/%Y %I:%M:%S %p'
	dt_obj = datetime.strptime(dt_str, dt_func)
	return dt_obj

def updateskin(run):
	'''check for skin update'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	htptv = xbmc.getInfoLabel('Skin.String(HTPTv)')
	htptc = xbmc.getInfoLabel('System.AddonVersion(skin.htpt)')
	htptu = xbmc.getInfoLabel('Skin.HasSetting(HTPTu)')
	if not systemplatformwindows: log = open('/storage/.kodi/temp/kodi.log', 'r')
	elif systemplatformwindows: log = open('Z:\kodi.log', 'r')
	file = log.read()
	count = 0
	while count < 10 and not "FileManager: copy https://raw.githubusercontent.com/htpthtpt/htpt/master/skin.htpt/skin.htpt" in file and not xbmc.abortRequested:
		xbmc.sleep(1000)
		validationstartup('run')
		count += 1
		countS = str(count)
		if admin: xbmc.executebuiltin('Notification(Admin,UpdateSkin ('+ countS +'),1000)')
		if not systemplatformwindows: log = open('/storage/.kodi/temp/kodi.log', 'r')
		elif systemplatformwindows: log = open('Z:\kodi.log', 'r')
		file = log.read()
	log.close()
	count = 0
	while count < 10 and "FileManager: copy https://raw.githubusercontent.com/htpthtpt/htpt/master/skin.htpt/skin.htpt" in file and not xbmc.abortRequested:
		xbmc.sleep(1000)
		count += 1
		if count == 1:
			xbmc.executebuiltin('Notification($LOCALIZE[79200] '+ htptc +'),$LOCALIZE[31407],7000)')
			heading = xbmc.getInfoLabel('$LOCALIZE[79200]') + ' ' + htptc
			dialogok(heading, '$LOCALIZE[31407]', "", "")
		if not htptu: xbmc.executebuiltin('Skin.ToggleSetting(HTPTu)')
		#if count == 10: xbmc.executebuiltin('dialog.close(okdialog)')
			
	if htptv != htptc and not htptu:
		if admin: xbmc.executebuiltin('Notification(Admin,HTPTu on (2),1000)')
		xbmc.executebuiltin('Skin.ToggleSetting(HTPTu)')
	if "FileManager: copy http://raw.github.com/lambda81/lambda-repo/master/plugin.video.genesis/" in file:
		xbmc.executebuiltin('Notification($LOCALIZE[75000],$LOCALIZE[31407],2000)')
		xbmc.sleep(1000)

def htptv(admin,systemidle3,playerhasvideo, home_aW):
	if systemidle3 and not playerhasvideo and home_aW:
		htptv = xbmc.getInfoLabel('Skin.String(HTPTv)')
		htptc = xbmc.getInfoLabel('System.AddonVersion(skin.htpt)')
		htptu = xbmc.getInfoLabel('Skin.HasSetting(HTPTu)')
		validation2 = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION2)')
		if htptu and htptv != htptc and not validation2:
			htptv = xbmc.getInfoLabel('Skin.String(HTPTv)')
			htptc = xbmc.getInfoLabel('System.AddonVersion(skin.htpt)')
			message1 = xbmc.getInfoLabel('$LOCALIZE[79201]') + ' ' + htptc
			if not systemplatformwindows: log = open('/storage/.kodi/addons/skin.htpt/changelog.txt', 'r')
			elif systemplatformwindows: log = open('Z:\\addons\\skin.htpt\\changelog.txt', 'r')
			message2 = log.read()
			log.close()
			xbmc.executebuiltin('RunScript(script.toolbox,info=textviewer,header='+ message1 +',text='+ message2 +')')
			xbmc.executebuiltin('Skin.SetString(MessagesChangeLog,'+ message2 +')')
			if admin: print printfirst + "htptv" + space2 + message2
			xbmc.executebuiltin('Skin.ToggleSetting(HTPTu)')
			#dialog = xbmcgui.Dialog()
			#dialog.ok(message1,message2)
			xbmc.executebuiltin('Skin.SetString(HTPTv,'+ htptc +')')
			xbmc.sleep(1000)

def trial(run,admin):
	trial = xbmc.getInfoLabel('Skin.HasSetting(Trial)')
	trial2 = xbmc.getInfoLabel('Skin.HasSetting(Trial2)')
	trialdate = xbmc.getInfoLabel('Skin.String(TrialDate)')
	trialdate2 = xbmc.getInfoLabel('Skin.String(TrialDate2)')
	trialdate2p = xbmc.getInfoLabel('$LOCALIZE[70000]')
	trialstr = xbmc.getInfoLabel('$LOCALIZE[70001]')
	verrorstr = xbmc.getInfoLabel('$VAR[VERROR]')
	if trialdate and trial:
		if verrorstr == 'NONE':
			dialog = xbmcgui.Dialog()
			if trialdate2 == trialdate2p and trialdate == xbmc.getInfoLabel('System.Date(DD-MM-YY)') and not trial2:
				'''yes'''
				if admin: xbmc.executebuiltin('Notification(Admin,trialdate2 == trialdate2p,1000)')
				'''get date'''
				timenow = datetime.date.today()
				timenow2 = timenow.strftime('%d-%m-%Y')
				timeafter = timenow + datetime.timedelta(days=7)
				timeafter2 = timeafter.strftime('%d-%m-%Y')
				timenow = str(timenow)
				timeafter = str(timeafter)
				'''message'''
				message1 = "Trial Activate?"
				message2 = "Yes/No Required!"
				if dialog.yesno(message1,message2):
					xbmc.executebuiltin('Notification(Trial Start: '+ timenow2 +',Trial End: '+ timeafter2 +',5000)')
					xbmc.executebuiltin('Skin.SetString(TrialDate,'+ timenow +')')
					#xbmc.executebuiltin('Skin.SetString(TrialDate,'+ timenow2 +')')
					xbmc.executebuiltin('Skin.SetString(TrialDate2,'+ timeafter +')')
					#xbmc.executebuiltin('Skin.SetString(TrialDate2,'+ timeafter2 +')')
					xbmc.executebuiltin('Skin.SetString(ID9,'+ trialstr +')')
					if not trial2: xbmc.executebuiltin('Skin.ToggleSetting(Trial2)')
			if trialdate2 != trialdate2p or trial2:
				'''!!!'''
				if admin: xbmc.executebuiltin('Notification(Admin,trialdate2 != trialdate2p,1000)')
				'''message'''
				message1 = "Trial Activate?"
				message2 = "Please Choose NO"
				if dialog.yesno(message1,message2):
					xbmc.executebuiltin('Notification(Trial Failed!,Please Contact HTPT support!,5000)')
					xbmc.executebuiltin('Skin.SetString(ID9,)')
					xbmc.executebuiltin('Skin.SetString(ID7,'+ trialstr +')')
					xbmc.executebuiltin('Skin.SetString(ID3,'+ trialstr +')')
				if trial2: xbmc.executebuiltin('Skin.ToggleSetting(Trial2)')
		else:
			if admin: xbmc.executebuiltin('Notification(Admin,verrorstr != NONE,2000)')
	if trial:
		'''trial detected'''
		xbmc.executebuiltin('Skin.ToggleSetting(Trial)')
		if verrorstr != 'NONE': xbmc.executebuiltin('Skin.SetString(ID9,'+ trialstr +')')
	if not trial and not trial2:
		'''regular'''
		if admin: xbmc.executebuiltin('Notification(Admin,regular,1000)')
		if trialdate: xbmc.executebuiltin('Skin.SetString(TrialDate,)')
		if trialdate2: xbmc.executebuiltin('Skin.SetString(TrialDate2,)')
	if trial2:
		'''strings'''
		trialstr1 = xbmc.getInfoLabel('$LOCALIZE[79211]')
		trialstr2 = xbmc.getInfoLabel('$LOCALIZE[79081]')
		
		'''get date'''
		timenow = datetime.date.today()
		timenow2 = timenow.strftime('%d-%m-%Y')
		timeafter = timenow + datetime.timedelta(days=7)
		timeafter2 = timeafter.strftime('%d-%m-%Y')
		timenow = str(timenow)
		timeafter = str(timeafter)
		if admin and trialdate2 < timenow: xbmc.executebuiltin('Notification(Admin,trial end (1),2000)')
		elif admin and trialdate2 < trialdate: xbmc.executebuiltin('Notification(Admin,trial end (2),2000)')
		elif admin and timeafter < trialdate2: xbmc.executebuiltin('Notification(Admin,trial end (3),2000)')
		elif admin and timenow < trialdate: xbmc.executebuiltin('Notification(Admin,trial end (4),2000)')
		if trialdate2 < timenow or trialdate2 < trialdate or timeafter < trialdate2 or timenow < trialdate:
			'''trial end'''
			xbmc.executebuiltin('Skin.SetString(ID3,TrailEnd)')
			xbmc.executebuiltin('Skin.SetString(ID9,TrailEnd)')
			trialendstr = xbmc.getInfoLabel('$LOCALIZE[79115] $LOCALIZE[79119]')
			trialendstr2 = xbmc.getInfoLabel('$LOCALIZE[79203]')
			dialog = xbmcgui.Dialog()
			message1 = trialendstr + '!'
			message2 = trialendstr2 + '.' + '[CR]' '0547393531'
			if dialog.yesno(message1,message2):
				xbmc.executebuiltin('Notification('+ trialstr1 +','+ trialstr2 +',5000)')
			else:
				xbmc.executebuiltin('Notification('+ trialstr1 +','+ trialstr2 +',5000)')
		if timeafter < trialdate2 or timenow < trialdate:
			xbmc.executebuiltin('Notification(FORMATING DEVICE, PLEASE WAIT...,10000)')
			xbmc.executebuiltin('Skin.ToggleSetting(Trial2)')
			xbmc.executebuiltin('Skin.SetString(ID5,000)')
			xbmc.executebuiltin('Skin.SetString(ID7,000)')

def validationstartup(admin):
	validation = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION)')
	validation5 = xbmc.getInfoLabel('Skin.String(VALIDATION5)')
	count = 0
	if validation and validation5 != '0' and not xbmc.abortRequested:
		#if admin and count == 1: xbmc.executebuiltin('Notification(Admin,validationstartup)')
		xbmc.sleep(1000)
		startup_a = xbmc.getCondVisibility('Window.IsActive(Startup.xml)')
		skinsettings = xbmc.getCondVisibility('Window.IsVisible(SkinSettings.xml)')
		loginscreen = xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)')
		loginscreen_p = xbmc.getCondVisibility('Window.Previous(LoginScreen.xml)')
		validation = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION)')
		validation5 = xbmc.getInfoLabel('Skin.String(VALIDATION5)')
		playerhasmedia = xbmc.getInfoLabel('Player.HasMedia')
		htptlogo = xbmc.getInfoLabel('Player.Filename') == "playHTPT.mp4"
		if not startup_a and not loginscreen and not loginscreen_p and not skinsettings and not htptlogo: xbmc.executebuiltin('ReplaceWindow(Startup.xml)')
		if playerhasmedia and not htptlogo:
			xbmc.executebuiltin('Action(Close)')
			xbmc.executebuiltin('Notification(HTPT AUTHENTICATION FAILED!,FOR SUPPORT: [COLOR Yellow]infohtpt@gmail.com[/COLOR],10000,icons/sc2.png)')

def videoplayertweak(admin,playerhasvideo):
	if playerhasvideo:
		#if admin: xbmc.executebuiltin('Notification(Admin,fix bug with subtitles (1),1000)')
		playerfolderpath = xbmc.getInfoLabel('Player.FolderPath')
		videoplayersubtitlesenabled = xbmc.getInfoLabel('VideoPlayer.SubtitlesEnabled')
		videoplayerhassubtitles = xbmc.getInfoLabel('VideoPlayer.HasSubtitles')
		'''fix bug with subtitles'''
		if videoplayerhassubtitles and videoplayersubtitlesenabled:
			fix = 'no'
			if '.sdarot.w' in playerfolderpath: fix = 'yes'
			elif xbmc.getCondVisibility('!VideoPlayer.Content(Movies)') and xbmc.getCondVisibility('!VideoPlayer.Content(Episodes)') and xbmc.getCondVisibility('IsEmpty(VideoPlayer.Year)') and xbmc.getCondVisibility('IsEmpty(VideoPlayer.Plot)') and xbmc.getCondVisibility('!SubString(Player.Title,S0)') and xbmc.getCondVisibility('!SubString(Player.Title,S1)') and xbmc.getCondVisibility('!SubString(VideoPlayer.Title,TNPB)') and xbmc.getCondVisibility('!SubString(VideoPlayer.Title,Staael)') and xbmc.getCondVisibility('!SubString(Player.Filename,YIFY)'): fix = 'yes'
			if fix == 'yes':
				if admin: xbmc.executebuiltin('Notification(Admin,fix bug with subtitles,1000)')
				xbmc.executebuiltin('Action(ShowSubtitles)')
			
		'''video osd auto close'''
		videoosd = xbmc.getCondVisibility('Window.IsVisible(VideoOSD.xml)')
		systemidle10 = xbmc.getCondVisibility('System.IdleTime(10)')
		if videoosd and systemidle10:
			subtitleosdbutton = xbmc.getCondVisibility('Control.HasFocus(703)')
			if not subtitleosdbutton or not videoplayerhassubtitles:
				if admin: xbmc.executebuiltin('Notification(Admin,videoosdauto,1000)')
				xbmc.executebuiltin('Dialog.Close(VideoOSD.xml)')
			else:
				systemidle20 = xbmc.getCondVisibility('System.IdleTime(20)')
				if systemidle20: xbmc.executebuiltin('Dialog.Close(VideoOSD.xml)')
	
def memkeyboard(admin):
	smartkeyboard = xbmc.getInfoLabel('Skin.HasSetting(smartkeyboard)')
	dialogkeyboard = xbmc.getCondVisibility('Window.IsVisible(DialogKeyboard.xml)')
	systemidle3 = xbmc.getCondVisibility('System.IdleTime(3)')
	count = 0
	while count < 400 and smartkeyboard and dialogkeyboard and not systemidle3:
		xbmc.sleep(100)
		count += 1
		dialogkeyboard = xbmc.getCondVisibility('Window.IsVisible(DialogKeyboard.xml)')
		systemidle3 = xbmc.getCondVisibility('System.IdleTime(3)')
		input = xbmc.getInfoLabel('Control.GetLabel(312)')
		smartkeyboardh0 = xbmc.getInfoLabel('Skin.String(smartkeyboardH0)')
		if input != smartkeyboardh0:
			xbmc.executebuiltin('Skin.SetString(smartkeyboardH0,'+ input +')')
			if admin: xbmc.executebuiltin('Notification(Admin memkeyboard,'+ input +',1000)')
		#xbmc.executebuiltin('Notification(Admin memkeyboard,'+ input +',1000)')
def connectioncheck(admin,count,systemidle3):
	'''network status'''
	mainwindow = xbmc.getCondVisibility('Window.IsVisible(mainWindow.xml)')
	netsettingsbutton = (xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(108)')) or xbmc.getCondVisibility('Container(52).HasFocus(40)') or (xbmc.getCondVisibility('Window.IsVisible(Custom1170.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(10)'))
	#xbmc.sleep(200)
	if systemidle3 and not netsettingsbutton:
		connected = xbmc.getInfoLabel('Skin.HasSetting(Connected)')
		connected2 = xbmc.getInfoLabel('Skin.HasSetting(Connected2)')
		connected3 = xbmc.getInfoLabel('Skin.HasSetting(Connected3)')
		if count == 1 or mainwindow or ((not connected and (connected2 or connected3)) or (connected and not connected2 and not connected3)):
			bash('ifconfig wlan0',"Connected2")
			xbmc.sleep(200)
			bash('ifconfig eth0',"Connected3")
		if count > 1 and (connected2 or connected3):
			#bash('ping -W 1 -w 1 -4 -q www.google.co.il',"Connected")
			returned = bash('ping -W 1 -w 1 -4 -q 8.8.8.8',"Connected")
			xbmc.sleep(200)
			if returned == "false":
				#xbmc.sleep(200)
				bash('ping -W 1 -w 1 -4 -q 8.8.4.4',"Connectedv2")
				
	else:
		if netsettingsbutton and admin: xbmc.executebuiltin('Notification(Admin,Connected2/3 pending...,1000)')
	
'''------------------------------
---CUSTOM------------------------
------------------------------'''



'''------------------------------
---DEFAULT-----------------------
------------------------------'''
def bash(bashCommand,bashname):
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	connected = xbmc.getInfoLabel('Skin.HasSetting(Connected)')
	connected2 = xbmc.getInfoLabel('Skin.HasSetting(Connected2)')
	connected3 = xbmc.getInfoLabel('Skin.HasSetting(Connected3)')
	returned = ""
	'''run BASH commands'''
	if not systemplatformwindows:
		xbmc.sleep(40)
		process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
		output = process.communicate()[0]
		if bashname == "Connected":
			if admin: print printfirst + space + bashname + space2 + output + space + connected
			'''1 packets transmitted, 0 packets received, 100% packet loss'''
			'''1 packets transmitted, 1 packets received, 0% packet loss
			   round-trip min/avg/max = 70.325/70.325/70.325 ms'''
			if ("1 packets received" or "0% packet loss") in output:
				if not connected: xbmc.executebuiltin('Skin.ToggleSetting(Connected)')
			else:
				returned = "false"
		elif bashname == "Connectedv2":
			if admin: print printfirst + space + bashname + space2 + output + space + connected
			'''1 packets transmitted, 0 packets received, 100% packet loss'''
			'''1 packets transmitted, 1 packets received, 0% packet loss
			   round-trip min/avg/max = 70.325/70.325/70.325 ms'''
			if ("1 packets received" or "0% packet loss") in output:
				if not connected: xbmc.executebuiltin('Skin.ToggleSetting(Connected)')
			else:
				print printfirst + space + "disconnected!"
				if connected: xbmc.executebuiltin('Skin.ToggleSetting(Connected)')
		elif bashname == "Connected2":
			xbmc.executebuiltin('Skin.SetString(Test,'+ output +')')
			if not "packets:0" in output and "inet addr" in output:
				if not connected2: xbmc.executebuiltin('Skin.ToggleSetting(Connected2)')
			else:
				if connected2: xbmc.executebuiltin('Skin.ToggleSetting(Connected2)')
		elif bashname == "Connected3":
			xbmc.executebuiltin('Skin.SetString(Test,'+ output +')')
			if not "packets:0" in output and "inet addr" in output:
				if not connected3: xbmc.executebuiltin('Skin.ToggleSetting(Connected3)')
			else:
				if connected3: xbmc.executebuiltin('Skin.ToggleSetting(Connected3)')
		elif bashname == "GUI1" and not "<skin>skin.htpt</skin>" in output:
			'''------------------------------
			---ERROR-1020--------------------
			------------------------------'''
			xbmc.executebuiltin('Notification($LOCALIZE[257]: 1020,$LOCALIZE[79505],2000)')
			os.system('sh /storage/.kodi/addons/service.htpt/specials/scripts/copyskin.sh')
		return returned

def get_daynow(custom):
	daynow = datenow.strftime("%a")
	daynowS = str(daynow)
	return daynowS

def get_timenow(custom):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	customS = str(custom)
	timenow = datetime.datetime.now()
	timenow3 = timenow.strftime("%H")
	timenow3S = str(timenow3)
	timenow3N = int(timenow3)
	'''---------------------------'''
	if timenow3N > 03 and timenow3N < 12: timezone = "A"
	elif timenow3N > 11 and timenow3N < 20: timezone = "B"
	elif timenow3N > 19 or timenow3N < 04: timezone = "C"
	if admin: notification("get_timenow",timenow3S + timezone,"",1000)
	if custom == 1:
		'''------------------------------
		---TIMEZONE----------------------
		------------------------------'''
		return timezone
		'''---------------------------'''
	else:
		return "NONE"
		
def dialogok(heading,line1,line2,line3):
	'''------------------------------
	---DIALOG-OK---------------------
	------------------------------'''
	dialog = xbmcgui.Dialog()
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	if '$LOCALIZE' in line1 or '$ADDON' in line1: line1 = xbmc.getInfoLabel(line1)
	if '$LOCALIZE' in line2 or '$ADDON' in line2: line2 = xbmc.getInfoLabel(line2)
	if '$LOCALIZE' in line3 or '$ADDON' in line3: line3 = xbmc.getInfoLabel(line3)
	#heading = str(heading.encode('utf-8'))
	#line1 = str(line1.encode('utf-8'))
	#line2 = str(line2.encode('utf-8'))
	#line3 = str(line3.encode('utf-8'))

	dialog.ok(heading,line1,line2,line3)
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + heading + space2 + line1 + space2 + line2 + space2 + line3
	'''---------------------------'''

def dialogprogress(heading,line1,line2,line3): 
	'''------------------------------
	---DIALOG-OK-***BROKEN***--------
	------------------------------'''
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	if '$LOCALIZE' in line1 or '$ADDON' in line1: line1 = xbmc.getInfoLabel(line1)
	if '$LOCALIZE' in line2 or '$ADDON' in line2: line2 = xbmc.getInfoLabel(line2)
	if '$LOCALIZE' in line3 or '$ADDON' in line3: line3 = xbmc.getInfoLabel(line3)
	heading = str(heading.encode('utf-8'))
	line1 = str(line1.encode('utf-8'))
	line2 = str(line2.encode('utf-8'))
	line3 = str(line3.encode('utf-8'))
	
	pDialog = xbmcgui.DialogProgress()
	#pDialog.create(heading,line1,line2,line3)
	pDialog.update(10,line1,line2,line3)
	
	#pDialog = xbmcgui.DialogProgressBG()
	#pDialog.create(heading, line1)
	
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "dialogprogress" + space2 + heading + space2 + line1 + space2 + line2 + space2 + line3
	'''---------------------------'''

def dialogselect(heading, list, autoclose):
	'''------------------------------
	---DIALOG-SELECT-----------------
	------------------------------'''
	dialog = xbmcgui.Dialog()
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	
	returned = dialog.select(heading,list,autoclose)
	returned = str(returned)
	
	print printfirst + heading + "( " + returned + " )"
	return returned
	'''---------------------------'''
	
def dialogkeyboard(input, heading, option, custom, addonsetting, addonsetting2):
	''''''
	if '$LOCALIZE' in heading: heading = xbmc.getInfoLabel(heading)
	dialog = xbmcgui.Dialog()
	keyboard = xbmc.Keyboard(input,heading,option)
	keyboard.doModal()
	returned = 'skip'
	if (keyboard.isConfirmed()):
		input2 = keyboard.getText()
		if custom == '1' and input2 != "": returned = 'ok'
		if custom == '2' and input2 == input: returned = 'ok'
		if custom == '3':
			if input2 != input and input2 != "" and option == 0: xbmc.executebuiltin('Notification('+ heading +': '+ input2 +',,4000)')
			if input2 != "": returned = 'ok'
			
		if option == 0: print printfirst + heading + space2 + input2 + " ( " + returned + " )"
		elif option != 0: print printfirst + heading + space2 + "*******" + " ( " + returned + " )"
	if returned == 'ok':
		returned == input2
		if addonsetting2 == "0": setsetting(addonsetting, input2)
		elif 'genesis' in addonsetting2:
			setsetting_genesis          = xbmcaddon.Addon('plugin.video.genesis').setSetting
			setsetting_genesis(addonsetting, input2)
		elif 'sdarot.tv' in addonsetting2:
			setsetting_sdarottv          = xbmcaddon.Addon('plugin.video.sdarot.tv').setSetting
			setsetting_sdarottv(addonsetting, input2)
	return returned

def dialognumeric(type,heading,input,custom,addonsetting):
	'''type: 0 = #, 1 = DD/MM/YYYY, 2 = HH:MM, 3 = #.#.#.#, message2 = heading, message1 = content'''
	if '$LOCALIZE' in heading: heading = xbmc.getInfoLabel(heading)
	try:
		input = int(input)
	except:
		input = 0
	returned = 'skip'
	try:
		if int(input) > 001000000 and int(input) < 9999999999 and input != "": input = str(input)
	except TypeError:
		input = 0
		print printfirst + "dialognumeric " + "except TypeError (1)"
	input = str(input)
	input2 = xbmcgui.Dialog().numeric(type, heading, input)
	try:
		if input2 != "": input2 = int(input2)
	except TypeError:
		xbmc.executebuiltin('Notification($LOCALIZE[257],$LOCALIZE[31406],2000)')
		sys.exit()
	if custom == '0':
		try:
			if input2 > 001000000 and input2 < 9999999999: returned = 'ok'
			elif input2 < 001000000 or input2 > 9999999999: returned = 'skip0'
		except TypeError:
			returned = 'skip'
	if custom == '1':
		if input2 != "": returned = 'ok'
	if custom == '2':
		if input2 == "": input2 = 0
		elif input2 != 0: returned = 'ok'
	#if type == '2' and input == message1: returned = 'ok'
	
	input = str(input)
	input2 = str(input2)
	print printfirst + heading + space2 + input2 + "( " + returned + " )"
	if returned == 'ok':
		if custom != "2":
			returned == input
			setsetting(addonsetting, input2)
		elif custom == "2":
			returned == input
			if returned == "": returned = 0
			setSkinSetting("0", addonsetting, input2)
			#setsetting(addonsetting, input2)
			
	return returned

def dialogyesno(heading,line1):
	'''------------------------------
	---DIALOG-YESNO------------------
	------------------------------'''
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	if '$LOCALIZE' in line1 or '$ADDON' in line1: line1 = xbmc.getInfoLabel(line1)
	returned = 'skip'
	if dialog.yesno(heading,line1): returned = 'ok'
	
	return returned
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "dialogyesno" + space2 + heading + space3 + line1 + "( " + returned + " )"
	'''---------------------------'''

def notification(heading, message, icon, time):
	'''------------------------------
	---Show a Notification alert.----
	------------------------------'''
	'''heading : string - dialog heading | message : string - dialog message. | icon : [opt] string - icon to use. (default xbmcgui.NOTIFICATION_INFO/NOTIFICATION_WARNING/NOTIFICATION_ERROR) | time : [opt] integer - time in milliseconds (default 5000) | sound : [opt] bool - play notification sound (default True)'''
	
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	if '$LOCALIZE' in message or '$ADDON' in message: message = xbmc.getInfoLabel(message)
	
	icon = "misc/logo/logo8.png"
	
	dialog.notification(heading, message, icon, time)
	
	#if "addonString" in heading and not "+" in heading: heading = str(heading.encode('utf-8'))
	if "addonString" in heading: heading = str(heading.encode('utf-8'))
	elif '$LOCALIZE' in heading or '$ADDON' in heading: heading = str(heading)
	if "addonString" in message: message = str(message.encode('utf-8'))
	elif '$LOCALIZE' in message or '$ADDON' in message: message = str(message)
	
	time = str(time)
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if (not "+" in heading and "addonString(" in heading) and (not "+" in message and "addonString(" in message): print printfirst + "notification" + space2 + heading + space3 + message + space + time
	else:
		print printfirst + "notification" + "..."
	'''---------------------------'''

def setsetting_custom1(addon,set1,set1v):
	'''------------------------------
	---SET-ADDON-SETTING-1-----------
	------------------------------'''
	getsetting_custom          = xbmcaddon.Addon(addon).getSetting
	setsetting_custom          = xbmcaddon.Addon(addon).setSetting
	
	set = getsetting_custom(set1)
	'''---------------------------'''
	if set != set1v:
		setsetting_custom(set1,set1v)
		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		print printfirst + "setsetting_custom1" + space2 + addon + space + set1 + space2 + set1v + space3
		'''---------------------------'''
		
def setSkinSetting(custom,set1,set1v):
	'''------------------------------
	---SET-SKIN-SETTING-1------------
	------------------------------'''
	from variables import admin, truestr

	''' custom: 0 = Skin.String, 1 = Skin.HasSetting'''
	'''---------------------------'''
	if custom == "0":
		setting1 = xbmc.getInfoLabel('Skin.String('+ set1 +')')
		setting2 = ""
		if setting1 != set1v: xbmc.executebuiltin('Skin.SetString('+ set1 +','+ set1v +')')
		'''---------------------------'''
		
	elif custom == "1":
		setting2 = xbmc.getInfoLabel('Skin.HasSetting('+ set1 +')')
		if setting2 == truestr: setting1 = "true"
		else:
			setting1 = "false"
		if setting1 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set1 +')')
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if setting1 != set1v or admin: print printfirst + "setSkinSetting" + space3 + custom + space + set1 + space2 + setting1 + " - " + set1v + space3 + "( " + "setting2" + space2 + setting2 + " ) "
	'''---------------------------'''

def setSkinSetting5(custom,set1,set1v,set2,set2v,set3,set3v,set4,set4v,set5,set5v):
	'''------------------------------
	---SET-SKIN-SETTING-5------------
	------------------------------'''
	''' custom: 0 = Skin.String, 1 = Skin.HasSetting'''
	if custom == "0":
		setting1 = xbmc.getInfoLabel('Skin.String('+ set1 +')')
		setting2 = xbmc.getInfoLabel('Skin.String('+ set2 +')')
		setting3 = xbmc.getInfoLabel('Skin.String('+ set3 +')')
		setting4 = xbmc.getInfoLabel('Skin.String('+ set4 +')')
		setting5 = xbmc.getInfoLabel('Skin.String('+ set5 +')')
	elif custom == "1":
		setting1 = xbmc.getInfoLabel('Skin.HasSetting('+ set1 +')')
		setting2 = xbmc.getInfoLabel('Skin.HasSetting('+ set2 +')')
		setting3 = xbmc.getInfoLabel('Skin.HasSetting('+ set3 +')')
		setting4 = xbmc.getInfoLabel('Skin.HasSetting('+ set4 +')')
		setting5 = xbmc.getInfoLabel('Skin.HasSetting('+ set5 +')')
	'''---------------------------'''
	if custom == "0":
		if setting1 != set1v: xbmc.executebuiltin('Skin.SetString('+ set1 +','+ set1v +')')
		if setting2 != set2v: xbmc.executebuiltin('Skin.SetString('+ set2 +','+ set2v +')')
		if setting3 != set3v: xbmc.executebuiltin('Skin.SetString('+ set3 +','+ set3v +')')
		if setting4 != set4v: xbmc.executebuiltin('Skin.SetString('+ set4 +','+ set4v +')')
		if setting5 != set5v: xbmc.executebuiltin('Skin.SetString('+ set5 +','+ set5v +')')
	elif custom == "1":
		if setting1 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set1 +')')
		if setting2 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set2 +')')
		if setting3 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set3 +')')
		if setting4 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set4 +')')
		if setting5 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set5 +')')
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''	
	print printfirst + "setSkinSetting5" + space2 + set1 + space + set2 + space + set3 + space + set4 + space + set5 + space3
	'''---------------------------'''
	
def calculate(addon,set1,custom):
	'''------------------------------
	---RETURN-CALCULATE-NUMBER-------
	------------------------------'''	
	getsetting_custom          = xbmcaddon.Addon(addon).getSetting
	setsetting_custom          = xbmcaddon.Addon(addon).setSetting
	
	set1v = getsetting_custom(set1)
	set1v = int(set1v)
	
	if custom == '1': set1v += 1
	elif custom == '2': set1v += -1
		
	set1v = str(set1v)
	setsetting_custom(set1, set1v)
	
	return set1v
	'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''	
	print printfirst + "calculate" + space + addon + space + set1 + space2 + set1v
	'''---------------------------'''
	
