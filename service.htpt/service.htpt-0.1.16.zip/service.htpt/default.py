import xbmc, xbmcgui
import os, sys
import subprocess
import xbmcaddon

from variables import *
from modules import *

class startup:
	xbmc.executebuiltin('UpdateAddonRepos')
	#xbmc.executebuiltin('UpdateLocalAddons')
	trial('run',admin)
	print printfirst + "startup" + " (1) "
	if not systemplatformwindows:
		print printfirst + "startup" + " (2) "
		os.system('sh /storage/.kodi/addons/service.htpt/specials/scripts/copyskin.sh')
		os.system('sh /storage/.kodi/addons/service.htpt/specials/scripts/copy2.sh')
		os.system('sh /storage/.kodi/addons/service.htpt/specials/scripts/copyonce.sh')
		#os.system('sh /storage/.kodi/addons/service.htpt/specials/scripts/copyemu.sh')
	updateskin('run')
	print printfirst + "startup" + " (3) "
	
class repeat:
	updateskincheck = 'false'
	count = 0
	while not xbmc.abortRequested:
		xbmc.sleep(1000)
		if count < 10: count += 1
		elif count >= 10: count = 1
		'''------------------------------
		---VARIABLES---------------------
		------------------------------'''
		countS = str(count)
		admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
		playerhasvideo = xbmc.getCondVisibility('Player.HasVideo')
		systemidle3 = xbmc.getCondVisibility('System.IdleTime(3)')
		home_aW = xbmc.getCondVisibility('Window.IsActive(0)')
		'''---------------------------'''
		if admin: setsetting('General_Timer',countS)
		'''---------------------------'''
		'''actions'''
		htptv(admin, systemidle3, playerhasvideo, home_aW)
		validationstartup(admin)
		videoplayertweak(admin,playerhasvideo)
		#memkeyboard(admin)
		#if count == 1:
		connectioncheck(admin,count,systemidle3)	
		if systemidle3 and not systemplatformwindows:
			'''system'''
			if count == 5 and not playerhasvideo: bash('cat /storage/.kodi/userdata/guisettings.xml',"GUI1")
	if xbmc.abortRequested:
		print printfirst + "Error 1170: AbortRequested!"
		sys.exit()
		
		
#repeat()