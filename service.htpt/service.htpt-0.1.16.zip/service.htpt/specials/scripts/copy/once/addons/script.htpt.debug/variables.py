#import xbmc, os, subprocess, sys
#import xbmc, xbmcgui, xbmcaddon
import xbmc, xbmcgui, xbmcaddon
import datetime
import sys

'''------------------------------
---script.htpt.debug-------------
------------------------------'''
getsetting         = xbmcaddon.Addon().getSetting
setsetting         = xbmcaddon.Addon().setSetting
addonName           = xbmcaddon.Addon().getAddonInfo("name")
addonString            = xbmcaddon.Addon().getLocalizedString

service_call = getsetting('service_call')
service_call_no = getsetting('service_call_no')
startup_no = getsetting('startup_no')
startup12_no = getsetting('startup12_no')
error_no = getsetting('error_no')
poweroff_no = getsetting('poweroff_no')
uptime120_no = getsetting('uptime120_no')
uptime60_no = getsetting('uptime60_no')
unauthorized_no = getsetting('unauthorized_no')
username = getsetting('username')
address = getsetting('address')
telephone = getsetting('telephone')
curtrigger = getsetting('curtrigger')
issue_description = getsetting('issue_description')
'''102'''
Date_Last = getsetting('Date_Last')
Time_Start = getsetting('Time_Start')
Time_Pass = getsetting('Time_Pass')

'''------------------------------
---DEFAULT-----------------------
------------------------------'''
printfirst = addonName + ": !@# "
space = " "
space2 = ": "
space3 = "_"
dialog = xbmcgui.Dialog()
systemplatformwindows = xbmc.getCondVisibility('system.platform.windows')
systemidle3 = xbmc.getCondVisibility('System.IdleTime(3)')
systemidle10 = xbmc.getCondVisibility('System.IdleTime(10)')
systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')

'''------------------------------
---script.htpt.debug-2-----------
------------------------------'''
ap = "r"
bp = "o"
cp = "m"
dp = "1"
ep = "2"
fp = "3"
gp = "4"
hp = "5"
ip = "d"
jp = "D"
kp = "#"

'''------------------------------
---script.htpt.debug-3-----------
------------------------------'''
file1 = "/storage/.kodi/temp/kodi.log"
file2 = "/storage/.kodi/temp/kodi.old.log"
file3 = "/storage/.kodi/userdata/guisettings.xml"
file1_w = "z:\\kodi.log"
file2_w = "z:\\kodi.old.log"
file3_w = "z:\\userdata\\guisettings.xml"
zipfilewindows = "z:\htptlog.zip"
logpathwindows = "z:\htpt.log", "z:\userdata\guisettings.xml"
files = "Z:\logpath"
#filenames = [os.path.join(files, f) for f in os.listdir(files)]

''''''

'''GET SETTINGS'''
getsetting_israelive          = xbmcaddon.Addon('plugin.video.israelive').getSetting
israelive_set1 = getsetting_israelive('remoteSettingsUrl')
getsetting_sdarottv          = xbmcaddon.Addon('plugin.video.sdarot.tv').getSetting
sdarottv_set1 = getsetting_sdarottv('domain')
sdarottv_set2 = getsetting_sdarottv('username')
sdarottv_set3 = getsetting_sdarottv('user_password')
getsetting_subtitle          = xbmcaddon.Addon('service.subtitles.subtitle').getSetting
subtitle_set1 = getsetting_subtitle('SUBemail')
subtitle_set2 = getsetting_subtitle('SUBpassword')
getsetting_genesis          = xbmcaddon.Addon('plugin.video.genesis').getSetting
genesis_set1 = getsetting_genesis('autoplay_library')
genesis_set2 = getsetting_genesis('autoplay_hd')
genesis_set3 = getsetting_genesis('autoplay')
genesis_set4 = getsetting_genesis('hosthd1')
genesis_set5 = getsetting_genesis('hosthd2')
genesis_set6 = getsetting_genesis('hosthd3')
genesis_set7 = getsetting_genesis('realdedrid_user')
genesis_set8 = getsetting_genesis('realdedrid_password')
genesis_set9 = getsetting_genesis('movie_library')
genesis_set10 = getsetting_genesis('tv_library')

'''------------------------------
---Skin.HasSetting---------------
------------------------------'''
admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
connected = xbmc.getInfoLabel('Skin.HasSetting(Connected)')
connected2 = xbmc.getInfoLabel('Skin.HasSetting(Connected2)')
connected3 = xbmc.getInfoLabel('Skin.HasSetting(Connected3)')
autoplaysd = xbmc.getInfoLabel('Skin.HasSetting(AutoPlaySD)')
autoplaypause = xbmc.getInfoLabel('Skin.HasSetting(AutoPlay_Pause)')
validation = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION)')

'''------------------------------
---System.-----------------------
------------------------------'''
systeminternetstate = xbmc.getInfoLabel('System.InternetState')
systemuptime = xbmc.getInfoLabel('System.Uptime')
systemcputemperature = xbmc.getInfoLabel('System.CPUTemperature')
screenresolution = xbmc.getInfoLabel('System.ScreenResolution')
dhcpaddress = xbmc.getInfoLabel('Network.DHCPAddress')
systemuptime2 = xbmc.getInfoLabel('System.Uptime') + " / " + xbmc.getInfoLabel('System.TotalUptime') 
freespace2 = xbmc.getInfoLabel('System.TotalSpace') + " / " + xbmc.getInfoLabel('System.FreeSpacePercent')
if xbmc.getCondVisibility('System.HasAddon(service.htpt)'): htptversion = xbmc.getInfoLabel('System.AddonVersion(skin.htpt)') + "+"
elif xbmc.getCondVisibility('!System.HasAddon(service.htpt)'): htptversion = xbmc.getInfoLabel('System.AddonVersion(skin.htpt)') + "-"
buildversion = xbmc.getInfoLabel('System.BuildVersion')
htptdebugversion = xbmc.getInfoLabel('System.AddonVersion(script.htpt.debug)')
htptserviceversion = xbmc.getInfoLabel('system.AddonVersion(service.htpt)')
htpthelpversion = xbmc.getInfoLabel('System.AddonVersion(service.htpt.help)')
htpthomebuttonsversion = xbmc.getInfoLabel('System.AddonVersion(script.htpt.homebuttons)')
htptremoteversion = xbmc.getInfoLabel('System.AddonVersion(script.htpt.remote)')
htptrefreshversion = xbmc.getInfoLabel('System.AddonVersion(script.htpt.refresh)')
htptfixversion = xbmc.getInfoLabel('System.AddonVersion(service.htpt.fix)')

'''------------------------------
---ACCOUNTS----------------------
------------------------------'''
Account1_Active = xbmc.getInfoLabel('Skin.HasSetting(Account1_Active)')
Account1_Period = xbmc.getInfoLabel('Skin.String(Account1_Period)')
Account1_EndDate = xbmc.getInfoLabel('Skin.String(Account1_EndDate)')
Account2_Active = xbmc.getInfoLabel('Skin.HasSetting(Account2_Active)')
Account2_Period = xbmc.getInfoLabel('Skin.String(Account2_Period)')
Account2_EndDate = xbmc.getInfoLabel('Skin.String(Account2_EndDate)')


'''------------------------------
---DATES-----------------------
------------------------------'''	
datenow = datetime.date.today()
datenowS = str(datenow)
daynow = datenow.strftime("%a")
daynowS = str(daynow)
timenow = datetime.datetime.now()
timenowS = timenow.strftime("%H:%M")

'''------------------------------
---CONTAINER---------------------
------------------------------'''
containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
container120numitems = xbmc.getInfoLabel('Container(120).NumItems') #DialogSubtitles
'''------------------------------
---Window.-----------------------
------------------------------'''
homeW = xbmc.getCondVisibility('Window.IsVisible(Home.xml)')
myvideonavW = xbmc.getCondVisibility('Window.IsVisible(MyVideoNav.xml)')
startupW = xbmc.getCondVisibility('Window.IsVisible(Startup.xml)')
videofullscreen = xbmc.getCondVisibility('Window.IsVisible(VideoFullScreen.xml)')
dialogvideoinfo = xbmc.getCondVisibility('Window.IsVisible(DialogVideoInfo.xml)')
dialogselectW = xbmc.getCondVisibility('Window.IsVisible(DialogSelect.xml)')
dialogsubtitlesW = xbmc.getCondVisibility('Window.IsVisible(DialogSubtitles.xml)')
loginscreen = xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)')
custom1170 = xbmc.getCondVisibility('Window.IsVisible(Custom1170.xml)')
custom1191 = xbmc.getInfoLabel('Skin.String(custom1191)')
myprograms = xbmc.getCondVisibility('Window.IsVisible(MyPrograms.xml)')
startup = xbmc.getCondVisibility('Window.IsVisible(Startup.xml)')
startup_a = xbmc.getCondVisibility('Window.IsActive(Startup.xml)')


'''------------------------------
---Network.----------------------
------------------------------'''
networkgatewayaddress = xbmc.getInfoLabel('Network.GatewayAddress')
networkipaddress = xbmc.getInfoLabel('Network.IPAddress')
'''------------------------------
---VIDEO-------------------------
------------------------------'''
playerhasvideo = xbmc.getCondVisibility('Player.HasVideo')
playerpaused = xbmc.getCondVisibility('Player.Paused')
videoplayerhassubtitles = xbmc.getCondVisibility('VideoPlayer.HasSubtitles')
playercache = xbmc.getInfoLabel('Player.CacheLevel')
playertitle = xbmc.getInfoLabel('Player.Title')
'''---------------------------'''	
playertime = xbmc.getInfoLabel("Player.Time(hh)") + xbmc.getInfoLabel("Player.Time(mm)") + xbmc.getInfoLabel("Player.Time(ss)")
playertimeremaining = xbmc.getInfoLabel("Player.TimeRemaining(hh)") + xbmc.getInfoLabel("Player.TimeRemaining(mm)") + xbmc.getInfoLabel("Player.TimeRemaining(ss)")
playerduration = xbmc.getInfoLabel("Player.Duration(hh)") + xbmc.getInfoLabel("Player.Duration(mm)") + xbmc.getInfoLabel("Player.Duration(ss)")

'''---------------------------'''
playlistlength = xbmc.getInfoLabel('Playlist.Length(video)')
playlistlengthN = int(playlistlength)
playlistposition = xbmc.getInfoLabel('Playlist.Position(video)')
playlistpositionN = int(playlistposition)
'''---------------------------'''
videoplayertitle = xbmc.getInfoLabel('VideoPlayer.Title')
videoplayerseason = xbmc.getInfoLabel('VideoPlayer.Season')
videoplayertvshowtitle = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
videoplayeryear = xbmc.getInfoLabel('VideoPlayer.Year')
videoplayertagline = xbmc.getInfoLabel('VideoPlayer.Tagline')
videoplayercountry = xbmc.getInfoLabel('VideoPlayer.Country')
videoplayerseason = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
#videoplayerseason = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
#videoplayerseason = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
#videoplayerseason = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
videoplayercontentMOVIE = xbmc.getCondVisibility('VideoPlayer.Content(movies)')
videoplayercontentTV = xbmc.getCondVisibility('VideoPlayer.Content(tvshows)')
videoplayercontentSEASON = xbmc.getCondVisibility('VideoPlayer.Content(seasons)')
videoplayercontentEPISODE = xbmc.getCondVisibility('VideoPlayer.Content(episodes)')

'''------------------------------
---SKIN STRINGS-------------
------------------------------'''
listitemtvshowtitle = xbmc.getInfoLabel('Skin.String(ListItemTVShowTitle)')
listitemseason = xbmc.getInfoLabel('ListItem.Season')
listitemepisode = xbmc.getInfoLabel('ListItem.Episode')
listitemgenre = xbmc.getInfoLabel('Skin.String(ListItemGenre)')
listitemduration = xbmc.getInfoLabel('Skin.String(ListItemDuration)')
listitemrating = xbmc.getInfoLabel('Skin.String(ListItemRating)')
listitemyear = xbmc.getInfoLabel('Skin.String(ListItemYear)')

'''------------------------------
---LISTITEM-------------
------------------------------'''
listitempath = xbmc.getInfoLabel('ListItem.Path')



'''------------------------------
---CUSTOM-------------
------------------------------'''

dialogselectsources = xbmc.getInfoLabel('Skin.String(DialogSelectSources)')
dialogselectsources2 = xbmc.getInfoLabel('Skin.String(DialogSelectSources2)')
dialogselectsources3 = xbmc.getInfoLabel('Skin.String(DialogSelectSources3)')
dialogselectsources5 = xbmc.getInfoLabel('Skin.String(DialogSelectSources5)')

cancelstr = xbmc.getInfoLabel('$LOCALIZE[222]')

dialogsubtitles2 = xbmc.getInfoLabel('Skin.String(DialogSubtitles2)')
dialogsubtitlesna1 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA1)')
dialogsubtitlesna2 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA2)')
dialogsubtitlesna3 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA3)')
dialogsubtitlesna4 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA4)')
dialogsubtitlesna5 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA5)')
dialogsubtitlesna6 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA6)')
dialogsubtitlesna7 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA7)')
dialogsubtitlesna8 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA8)')
dialogsubtitlesna9 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA9)')
dialogsubtitlesna10 = xbmc.getInfoLabel('Skin.String(DialogSubtitlesNA10)')


'''------------------------------
---MIXED-------------------------
------------------------------'''
mac = xbmc.getInfoLabel('Network.MacAddress') + " ( " + xbmc.getInfoLabel('Skin.String(MAC1)') + " / " + xbmc.getInfoLabel('Skin.String(MAC2)') + " )"
istv = (xbmc.getInfoLabel('ListItem.TVShowTitle') != "" and xbmc.getInfoLabel('ListItem.Season') != "" and xbmc.getInfoLabel('ListItem.Episode') != "") or ("videodb://tvshows" in containerfolderpath or "library://video/tvshows" in containerfolderpath)
istvS = str(istv)
ismovie = (xbmc.getInfoLabel('ListItem.Year') != "" or xbmc.getInfoLabel('ListItem.Country') != "" or xbmc.getInfoLabel('ListItem.Tagline') != "") and not istv
ismovieS = str(ismovie)
istv4 = " S" in dialogselectsources3 and " E" in dialogselectsources3
istv4S = str(istv4)
ismovie4 = " (" in dialogselectsources3 and ")" in dialogselectsources3 and not istv4
ismovie4S = str(ismovie4)
istvmoviep = (videoplayertitle in dialogselectsources3 or videoplayertitle in dialogselectsources5)
isgenesis = "videodb://tvshows" in containerfolderpath or "library://video/tvshows" in containerfolderpath or "plugin://plugin.video.genesis/" in containerfolderpath
'''------------------------------
---CONTROL-----------------------
------------------------------'''
cancelbutton = xbmc.getCondVisibility('Control.HasFocus(10)') and xbmc.getCondVisibility('Window.IsActive(DialogProgress.xml)')
autoplaypausebutton = (xbmc.getCondVisibility('Window.IsVisible(Home.xml)') and xbmc.getCondVisibility('Control.HasFocus(9093)')) or (xbmc.getCondVisibility('Window.IsVisible(MyVideoNav.xml)') and xbmc.getCondVisibility('Control.HasFocus(111)'))
debugbutton = xbmc.getCondVisibility('Container(50).HasFocus(5)') or (xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(102)'))
controlisvisible311 = xbmc.getCondVisibility('Control.IsVisible(311)') or xbmc.getCondVisibility('Control.HasFocus(340)')
controlisvisible311S = str(controlisvisible311)
controlisvisible312 = xbmc.getCondVisibility('Control.IsVisible(312)') or xbmc.getCondVisibility('Control.HasFocus(341)')
controlisvisible312S = str(controlisvisible312)
controlgetlabel100 = xbmc.getInfoLabel('Control.GetLabel(100)') #DialogSubtitles Service Name

	
'''------------------------------
---$LOCALIZE--------------------
------------------------------'''
truestr = xbmc.getInfoLabel('$LOCALIZE[20122]')
'''------------------------------
---ID----------------------------
------------------------------'''
'''idstr = USERNAME EN , id1str = USERNAME HE, id2str = INSTALLATION DATE, id3str = WARRENTY END, id4str = ADDRESS, id5str = TELEPHONE NUMBER, id6str = PAYMENT TERMS, id7str = QUESTION, id8str = TECHNICAL NAME, id9str = CODE RED, id10str = HTPT'S MODEL, ID11 = MAC1, ID12 = MAC2'''
idstr = xbmc.getInfoLabel('Skin.String(ID)')
id1str = xbmc.getInfoLabel('Skin.String(ID1)')
id2str = xbmc.getInfoLabel('Skin.String(ID2)')
id3str = xbmc.getInfoLabel('Skin.String(ID3)')
id4str = xbmc.getInfoLabel('Skin.String(ID4)')
id5str = xbmc.getInfoLabel('Skin.String(ID5)')
id6str = xbmc.getInfoLabel('Skin.String(ID6)')
id7str = xbmc.getInfoLabel('Skin.String(ID7)')
id8str = xbmc.getInfoLabel('Skin.String(ID8)')
id9str = xbmc.getInfoLabel('Skin.String(ID9)')
id10str = xbmc.getInfoLabel('Skin.String(ID10)')
id11str = xbmc.getInfoLabel('Skin.String(ID11)')
id12str = xbmc.getInfoLabel('Skin.String(ID12)')
id60str = xbmc.getInfoLabel('Skin.String(ID60)')
''''''
idnamestr = xbmc.getInfoLabel('$LOCALIZE[1014]')
id2namestr = xbmc.getInfoLabel('$LOCALIZE[70010]')
id3namestr = xbmc.getInfoLabel('$LOCALIZE[70011]')
id4namestr = xbmc.getInfoLabel('$LOCALIZE[19115]')
id5namestr = xbmc.getInfoLabel('$LOCALIZE[75006]')
id6namestr = xbmc.getInfoLabel('$LOCALIZE[70012]')
id60namestr = xbmc.getInfoLabel('$LOCALIZE[70012]')
id7namestr = 'Question'
id8namestr = xbmc.getInfoLabel('$LOCALIZE[70013]')
id9namestr = 'CODE RED'
id10namestr = xbmc.getInfoLabel('$LOCALIZE[79031]')
id11namestr = 'MAC1 (LAN)'
id12namestr = 'MAC2 (WLAN)'
''''''
fixip = xbmc.getInfoLabel('Skin.String(fixip)')
trial = xbmc.getInfoLabel('Skin.HasSetting(Trial)')
trial2 = xbmc.getInfoLabel('Skin.HasSetting(Trial2)')
trialdate = xbmc.getInfoLabel('Skin.String(TrialDate)')
trialdate2 = xbmc.getInfoLabel('Skin.String(TrialDate2)')

idtrial = 'htptuser'
#idtrial = 'htptuser27'
idpstr = xbmc.getInfoLabel('$LOCALIZE[79246]')
#idp2str = xbmc.getInfoLabel('$LOCALIZE[79246]')
idp2str = xbmc.getInfoLabel('$LOCALIZE[79247]')


'''------------------------------
---script.htpt.debug-4-----------
------------------------------'''
content1 = '''
---------------------
-------USER-INFO-----
---------------------
USERNAME:          %s (%s) (%s)
---------------------
INSTALLATION DATE: %s
WARRENTY END:      %s
ADDRESS:           %s
TEL:               %s
PAYMENT TERMS:     %s
TECHNICAL NAME:    %s
HTPT MODEL:        %s
---------------------
''' % (idstr, id1str, username, id2str, id3str, id4str, id5str, id6str, id8str, id10str)

content1u = '''
---------------------
-------USER-INFO-----
---------------------
USERNAME:          %s (%s) (%s)
USER WRITE:        %s
SYSTEM UP TIME:    %s min
---------------------
INSTALLATION DATE: %s
WARRENTY END:      %s
ADDRESS:           %s
TEL:               %s
PAYMENT TERMS:     %s
TECHNICAL NAME:    %s
HTPT MODEL:        %s
---------------------
''' % (idstr, id1str, username, issue_description, Time_Pass, id2str, id3str, id4str, id5str, id6str, id8str, id10str)

content2 = '''
---------------------
-----TRIAL/TIME------
---------------------
TRIAL DATE:   	   %s - %s
TRIAL 1/2:    	   %s - %s
---------------------
''' % (trialdate, trialdate2, trial, trial2)

content3 = '''
---------------------
-------VERSION-------
---------------------
HTPT VER:          %s
BUILD VER:         %s
HTPT DEBUG VER:    %s
HTPT FIX VER:      %s
HTPT HELP VER:     %s
HTPT HOMEBUTTONS   %s
HTPT REFRESH VER:  %s
HTPT REMOTE VER:   %s
HTPT SERVICE VER:  %s
---------------------
''' % (htptversion, buildversion, htptdebugversion, htptfixversion, htpthelpversion, htpthomebuttonsversion, htptrefreshversion, htptremoteversion, htptserviceversion)

content4 = '''
---------------------
----NETWORK INFO-----
---------------------
LOCAL IP:          %s
GATEWAY:           %s
DHCPADDRESS:       %s
---------------------
''' % (networkipaddress, networkgatewayaddress, dhcpaddress)

content5 = '''
---------------------
--------MISC---------
---------------------
CURRENT CONTROL:   %s
SCREEN RESOLUTION: %s
MAC(1=lan/2=wlan): %s
FREE SPACE:        %s
FIX IP:            %s
---------------------
''' % (systemcurrentcontrol, screenresolution, mac, freespace2, fixip)

content20 = '''
---------------------
---ADDONS SETTINGS---
---------------------
israelive_set1     %s
sdarottv_set1      %s
sdarottv_set2/3    %s - %s (%s -%s)
subtitle_set1/2    %s - %s
genesis_set1/2/3   %s - %s - %s
genesis_set4/5/6   %s - %s - %s
genesis_set7/8     %s - %s (%s -%s)
genesis_set9/10    %s - %s
''' % (israelive_set1, sdarottv_set1, sdarottv_set2, sdarottv_set3, Account2_Active, Account2_Period, subtitle_set1, subtitle_set2, genesis_set1, genesis_set2, genesis_set3, genesis_set4, genesis_set5, genesis_set6, genesis_set7, genesis_set8, Account1_Active, Account1_Period, genesis_set9, genesis_set10)

'''---------------------------'''
	