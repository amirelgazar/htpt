import xbmc, xbmcgui, xbmcaddon
#import os, subprocess, sys
#from variables import *
#from shared_variables import *
#from shared_modules import *
'''unused'''

#https://gdata.youtube.com/feeds/api/videos/dzbN8WG33Sg/related?v=2

def getsetting_custom1(addon,set1):
	'''------------------------------
	---GET-ADDON-SETTING-1-----------
	------------------------------'''
	getsetting_custom          = xbmcaddon.Addon(addon).getSetting
	'''---------------------------'''
	returned = getsetting_custom(set1,set1v)
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "getsetting_custom1" + space2 + addon + space + set1
	'''---------------------------'''
	return returned
	'''---------------------------'''
	
def dialogprogress(id, progress, heading, line1, line2, line3): 
	'''------------------------------
	---DIALOG-OK-***BROKEN***--------
	------------------------------'''
	#try: progressN = int(progress)
	#except Exception, TypeError: progressN = 0
	'''---------------------------'''
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	if '$LOCALIZE' in line1 or '$ADDON' in line1: line1 = xbmc.getInfoLabel(line1)
	if '$LOCALIZE' in line2 or '$ADDON' in line2: line2 = xbmc.getInfoLabel(line2)
	if '$LOCALIZE' in line3 or '$ADDON' in line3: line3 = xbmc.getInfoLabel(line3)
	heading = str(heading.encode('utf-8'))
	line1 = str(line1.encode('utf-8'))
	line2 = str(line2.encode('utf-8'))
	line3 = str(line3.encode('utf-8'))
	
	#notification(str(progress),"","",2000)
	dp = xbmcgui.DialogProgress()
					
	if progress == 0:
		#pDialog.close
		dp.create(heading,line1,line2,line3)
	elif progress == 10: dp.close
	elif progress > 0: dp.update(progressN,line1,line2,line3)
	
	#pDialog = xbmcgui.DialogProgressBG()
	#pDialog.create(heading, line1)
	
	#def dialogprogress(admin, id, action, name, header, line1, line2):
	#id = xbmcgui.DialogProgress( )
	#if action == 0: returned = id.create(name, header, line1, line2)
	#else: returned = ""
	#return returned
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin:
		print printfirst + "dialogprogress" + space2 + heading + space2 + line1 + space2 + line2 + space2 + line3
		try:
			print printfirst + "TypeError" + space2 + str(TypeError)
			'''---------------------------'''
		except:
			pass
			'''---------------------------'''
	return dp
	
def UserBlock(custom):
	
	if custom == "ON": bash('pgrep kodi.bin | xargs kill -SIGSTOP',"UserBlock-ON")
	else: bash('pgrep kodi.bin | xargs kill -SIGCONT',"UserBlock-OFF")
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if custom != "ON": custom = "OFF"
	print printfirst + space + "UserBlock=" + custom
	'''---------------------------'''
	
def copy_rename(old_file_name, new_file_name):
	import shutil
	src_dir= os.curdir
	dst_dir= os.path.join(os.curdir , "/storage/")
	src_file = os.path.join(src_dir, old_file_name)
	shutil.copy(src_file,dst_dir)
	
	dst_file = os.path.join(dst_dir, old_file_name)
	new_dst_file_name = os.path.join(dst_dir, new_file_name)
	os.rename(dst_file, new_dst_file_name)
	
def stringtotime(dt_str, dt_func):
	from datetime import datetime
	import time
	#dt_str = '9/24/2010 5:03:29 PM'
	#dt_func = '%m/%d/%Y %I:%M:%S %p'
	#try:
	dt_obj = datetime.strptime(dt_str, dt_func)
	dt_objS = str(dt_obj)
	if dt_func == '%H':
		#time.struct_time(tm_year=1900, tm_mon=1, tm_mday=1, tm_hour=20, tm_min=0, tm_sec=0, tm_wday=0, tm_yday=1, tm_isdst=-1)
		find = dt_str
		found = find_string(dt_objS, find, "")
		'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "stringtotime" + space + "dt_objS" + space2 + dt_objS + space + "timenow3S" + space2 + timenow3S
	'''---------------------------'''
	
	return dt_obj
	
def General_CleanCache():
    dir=xbmc.translatePath('special://temp/')
    file=os.path.join(dir, 'commoncache.db')
    f = open(file, 'w')
    f.write('')
    f.close
    dialogok('[COLOR=Yellow]' + addonString(307).encode('utf-8') + addonString(308).encode('utf-8') + '[/COLOR]',"","","")
    '''---------------------------'''
	
def mes():

        
	try:
		link=OPEN_URL('http://goo.gl/r6eog7')
		r = re.findall(r'ANNOUNCEMENTWINDOW ="ON"',link)
		if not r:
			return
			
		match=re.compile('<new>(.*?)\\n</new>',re.I+re.M+re.U+re.S).findall(link)
		if not match[0]:
			return
			
		dire=os.path.join(xbmc.translatePath( "special://userdata/addon_data" ).decode("utf-8"), addonID)
		if not os.path.exists(dire):
			'''------------------------------
			---CREATE-USERDATA-DIRECTORY-----
			------------------------------'''
			os.makedirs(dire)
			'''---------------------------'''
		aSeenFile = os.path.join(dire, 'announcementSeen.txt')
		if (os.path.isfile(aSeenFile)): 
			f = open(aSeenFile, 'r') 
			content = f.read() 
			f.close() 
			if content == match[0] :
				return

		f = open(aSeenFile, 'w') 
		f.write(match[0]) 
		f.close() 

		dp = xbmcgui . Dialog ( )
		dp.ok("UPDATES", match[0])
	except:
		pass


def _____NONE(admin):
	'''------------------------------
	---MAC1/2------------------------
	------------------------------'''
	MAC1 = bash("ifconfig -a | grep -e 'eth' | awk {'print $1,$5'}","LAN MAC")
	MAC2 = bash("ifconfig -a | grep -e 'wlan' | awk {'print $1,$5'}","WLAN MAC")
	bash('ifconfig eth0 up',"eth0 up")