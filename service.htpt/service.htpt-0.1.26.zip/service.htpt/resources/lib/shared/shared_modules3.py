import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os,random
import json

from variables import *
#from modules import *
from shared_modules import *

'''plugins'''
def addDir(name, url, mode, iconimage, desc, num, viewtype):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&num="+urllib.quote_plus(num)
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": desc} )
	menu = []
	#ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	if viewtype != "":
		#notification("testt","","",1000)
		#setsetting_custom1(addonID,'Current_View',viewtype)
		pass
		'''---------------------------'''
	if mode == 12:
		'''------------------------------
		---View-Playlist-----------------
		------------------------------'''
		#url=urllib.unquote(url)
		#menu.append(('[COLOR=Purple]' + str79522.encode('utf-8') + '[/COLOR]', "XBMC.Container.Update(plugin://plugin.video.htpt.kids/?num&iconimage=''&mode=13&name=''&url=%s)"% (url)))
		menu.append(('[COLOR=Purple]' + str79522.encode('utf-8') + '[/COLOR]', "XBMC.Container.Update(plugin://%s/?num&iconimage=''&mode=13&name=''&url=%s)"% (addonID, url)))
		liz.addContextMenuItems(items=menu, replaceItems=True)
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok
		'''---------------------------'''
	elif mode == 9:
		'''------------------------------
		---TV-MODE-----------------------
		------------------------------'''
		menu.append(('[COLOR=Green]' + str79525.encode('utf-8') + '[/COLOR]', "XBMC.RunPlugin(plugin://%s/?num&iconimage=''&mode=115&name=''&url=%s)"% (addonID, url)))
		liz.addContextMenuItems(items=menu, replaceItems=True)
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		return ok
		'''---------------------------'''
	elif mode == 8:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
		return ok
		'''---------------------------'''
	elif mode == 11 or mode == 15 or mode == 115 :
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok
		'''---------------------------'''
	elif mode == 13:
		menu.append(('[COLOR=Yellow]' + str79520.encode('utf-8') + '[/COLOR]', "XBMC.RunPlugin(plugin://%s/?num&iconimage=''&mode=12&name=''&url=%s)"% (addonID, url)))
		liz.addContextMenuItems(items=menu, replaceItems=True)
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		return ok
		'''---------------------------'''
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok
	'''---------------------------'''

def addVideoLink(name, url, mode, iconimage='DefaultFolder.png', summary = ''):
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + name
	#u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode="+ str(mode) #SPOTIFY/BESTOFYOUTUBE
	liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote(name), "Plot": urllib.unquote(summary)})    
	liz.setProperty('IsPlayable', 'true')
	ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
	if admin: print printfirst + "addVideoLink" + space + "ok" + space2 + str(ok)
	'''---------------------------'''
	return ok
		
def addLink(name,url,iconimage,desc):
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": desc})
	liz.setProperty("IsPlayable","true")
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
	if admin: print printfirst + "addLink" + space + "ok" + space2 + str(ok)
	'''---------------------------'''
	return ok
	
def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
				params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
					param[splitparams[0]]=splitparams[1]
							
	return param

def ListLive(url):
	#addDir('[COLOR=Yellow]' + str79520.encode('utf-8') + '[/COLOR]',url,12,addonMediaPath + "190.png",str79526.encode('utf-8'),'1',"") #Quick-Play
	link = OPEN_URL(url)
	link=unescape(link)
	print printfirst + "link" + space2 + link
	matches1=re.compile('pe=(.*?)#',re.I+re.M+re.U+re.S).findall(link)
	#print str(matches1[0]) + '\n'
	for match in matches1 :
		#print "match=" + str(match)
		match=match+'#'
		if match.find('playlist') != 0 :
			'''------------------------------
			---url---------------------------
			------------------------------'''
			regex='name=(.*?)URL=(.*?)#'
			matches=re.compile(regex,re.I+re.M+re.U+re.S).findall(match)
			#print str(matches)
			for name,url in matches:
				thumb=''
				i=name.find('thumb')
				i2=name.find('description')
				if i>0:
					thumb=name[i+6:]
					name=name[0:i]
					description = name[i2+11:]
					print printfirst + "name" + space2 + name + space + "thumb" + space2 + thumb + space + "description" + space2 + description
		#print url
				addLink('[COLOR yellow]'+ name+'[/COLOR]',url,thumb,description)  
			
		else:
			'''------------------------------
			---.plx--------------------------
			------------------------------'''
			regex='name=(.*?)URL=(.*?).plx'
			matches=re.compile(regex,re.I+re.M+re.U+re.S).findall(match)
			for name,url in matches:
				thumb=''
				i=name.find('thumb')
				i2=name.find('description')
				if i>0:
					thumb=name[i+6:]
					name=name[0:i]
					description = name[i2+11:]
				url=url+'.plx'
				if name.find('Radio') < 0 :
					addDir('[COLOR blue]'+name+'[/COLOR]',url,7,thumb,description,'1',"")
					
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "ListLive" + space2 + "matches1" + space2 + str(matches1) + space
	'''---------------------------'''
	
def ListPlaylist(playlistid, page):
	if page == None: page = 1
	else:
		try: pageN = int(page)
		except: page = 1
	pageN = int(page)
	pageS = str(page)
	
	pagesizeN = 40
	pagesizeS = str(pagesizeN)
	#url='https://gdata.youtube.com/feeds/api/playlists/'+playlistid+'?alt=json&max-results='+pagesizeS+''
	url='https://gdata.youtube.com/feeds/api/playlists/' + playlistid + '?alt=json&max-results=' + pagesizeS + '&start-index=' + pageS
	murl='http://gdata.youtube.com/feeds/api/playlists/'+playlistid + '?&max-results=' + pagesizeS + '&start-index='+pageS
	print "test this" + space2 + "playlistid" + space2 + playlistid + space + "url" + space2 + url
	#murl='http://gdata.youtube.com/feeds/api/users/'+url+'/uploads?&max-results=50&start-index='+num
	link = OPEN_URL(url)
	prms=json.loads(link)

	pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
	pl.clear()
	playlist = []
	numOfItems=int(prms['feed'][u'openSearch$totalResults'][u'$t']) #if bigger than pagesize needs to add more result
	totalpagesN = (numOfItems / pagesizeN) + 1
	nextpage = pageN + 1
	nextpageS = str(nextpage)
	#addDir('[COLOR=Yellow]' + str79520.encode('utf-8') + '[/COLOR]',url,11,"special://skin/media/DefaultPlaylist.png",str79526.encode('utf-8'),'1',"") #Quick-Play
	addDir('[COLOR=Yellow]' + str79520.encode('utf-8') + '[/COLOR]',murl,11,"special://skin/media/DefaultPlaylist.png",str79526.encode('utf-8'),'1',"") #Quick-Play
	i=0
	while i < pagesizeN and not xbmc.abortRequested: #h<numOfItems
		try:
			urlPlaylist= str(prms['feed'][u'entry'][i][ u'media$group'][u'media$player'][0][u'url'])
			match=re.compile('www.youtube.com/watch\?v\=(.*?)\&f').findall(urlPlaylist)
			finalurl="plugin://plugin.video.youtube/play/?video_id="+match[0]+"&hd=1"
			title= str(prms['feed'][u'entry'][i][ u'media$group'][u'media$title'][u'$t'].encode('utf-8')).decode('utf-8')
			thumb =str(prms['feed'][u'entry'][i][ u'media$group'][u'media$thumbnail'][2][u'url'])
			desc = str(prms['feed'][u'entry'][i][ u'media$group'][u'media$description'][u'$t'].encode('utf-8')).decode('utf-8')
			addLink(title,finalurl,thumb,desc)
			'''---------------------------'''
		except:
			pass
		i += 1

	#url='https://gdata.youtube.com/feeds/api/playlists/'+playlistid+'?alt=json&max-results=40&start-index=2'
	#addDir('[COLOR=Yellow]' + str79521.encode('utf-8') + '[/COLOR]',playlistid,9,"special://skin/media/icons/se.png",str79528.encode('utf-8'),'25',"") #More Results
	#if totalpagesN > pageN: addDir('[COLOR=Yellow]' + str79521.encode('utf-8') + '[/COLOR]','plugin://plugin.video.youtube/playlist/'+playlistid+'/',13,"special://skin/media/DefaultPlaylist.png",str79528.encode('utf-8'),nextpageS,"") #More Results
	if totalpagesN > pageN: addDir('[COLOR=Yellow]' + str33078.encode('utf-8') + '[/COLOR]',playlistid,13,"special://skin/media/DefaultVideo2.png",str79528.encode('utf-8'),nextpageS,"") #Next Page
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "ListPlaylist" + space + "playlistid" + space2 + playlistid + space + "numOfItems" + space2 + str(numOfItems) + space + "page" + space2 + pageS + " / " + str(totalpagesN)
	'''---------------------------'''
		
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    '''---------------------------'''
    return link

def play_video(url):
	#xbmc.executebuiltin('PlayMedia(plugin://plugin.video.youtube/play/?video_id='+ url +')')
	#url='plugin://plugin.video.youtube/play/?video_id='+ url +''
	#link=OPEN_URL(url)
	#match=re.compile("http\://www.youtube.com/watch\?v\=([^\&]+)\&.+?<media\:descriptio[^>]+>([^<]+)</media\:description>.+?<media\:thumbnail url='([^']+)'.+?<media:title type='plain'>(.+?)/media:title>").findall(link)
	url='https://gdata.youtube.com/feeds/api/videos/'+ url +''
	link = OPEN_URL(url)
	prms=json.loads(link)
	
	match=re.compile('www.youtube.com/watch\?v\=(.*?)\&f').url
	finalurl="plugin://plugin.video.youtube/play/?video_id="+match[0]+"&hd=1"
	title= str(prms['feed'][u'entry'][i][ u'media$group'][u'media$title'][u'$t'].encode('utf-8')).decode('utf-8')
	thumb =str(prms['feed'][u'entry'][i][ u'media$group'][u'media$thumbnail'][2][u'url'])
	description = str(prms['feed'][u'entry'][i][ u'media$group'][u'media$description'][u'$t'].encode('utf-8')).decode('utf-8')
	addLink(title,finalurl,thumb,description)
	#xbmc.Player(xbmc.PLAYER_CORE_MPLAYER).play(pl)
	
def PlayPlayList(playlistid):
	url='https://gdata.youtube.com/feeds/api/playlists/'+playlistid+'?alt=json&max-results=40'
	link = OPEN_URL(url)
	prms=json.loads(link)

	playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
	playlist.clear()
	playlist1 = []
	numOfItems=int(prms['feed'][u'openSearch$totalResults'][u'$t']) #if bigger than 40 needs  to add more result
	
	j=1
	h=1
	pages = (numOfItems //50)+1
	while  j<= pages:
		link=OPEN_URL(url)
		prms=json.loads(link)
		i=0
		while i< 50  and  h<numOfItems :
			try:
				urlPlaylist= str(prms['feed'][u'entry'][i][ u'media$group'][u'media$player'][0][u'url'])
				match=re.compile('www.youtube.com/watch\?v\=(.*?)\&f').findall(urlPlaylist)
				#finalurl="plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid="+match[0]+"&hd=1"
				finalurl="plugin://plugin.video.youtube/play/?video_id="+match[0]+"&hd=1"
				title= str(prms['feed'][u'entry'][i][ u'media$group'][u'media$title'][u'$t'].encode('utf-8')).decode('utf-8')
				thumb =str(prms['feed'][u'entry'][i][ u'media$group'][u'media$thumbnail'][2][u'url'])
				liz = xbmcgui.ListItem(title, iconImage="DefaultVideo.png", thumbnailImage=thumb)
				liz.setInfo( type="Video", infoLabels={ "Title": title} )
				liz.setProperty("IsPlayable","true")
				playlist1.append((finalurl ,liz))
			except:
				pass
			i=i+1
			h=h+1

		j=j+1
		url='https://gdata.youtube.com/feeds/api/playlists/'+playlistid+'?alt=json&max-results=50&start-index='+str (j*50-49)
	random.shuffle(playlist1)
	for blob ,liz in playlist1:
		try:
			if blob:
				playlist.add(blob,liz)
		except:
			pass
	playlist.shuffle()

	xbmc.Player(xbmc.PLAYER_CORE_MPLAYER).play(playlist)

#https://gdata.youtube.com/feeds/api/users/polosoft/playlists (gets playlist fro, user) https://gdata.youtube.com/feeds/api/users/polosoft/playlists?alt=json
#https://gdata.youtube.com/feeds/api/playlists/PLN0EJVTzRDL_53Jz8bhZl4m3UtkY2btbV?max-results=50?alt=json  (gets items in playlist)
#https://gdata.youtube.com/feeds/api/playlists/PLN0EJVTzRDL_53Jz8bhZl4m3UtkY2btbV?max-results=50&alt=json

def PlaylistsFromUser(user):
	url='https://gdata.youtube.com/feeds/api/users/'+user+ '/playlists?alt=json&max-results=50'
	link = OPEN_URL(url)
	prms=json.loads(link)
	TotalPlaylists=int(prms['feed'][u'openSearch$totalResults'][u'$t'])
	j=1
	h=1
	lst=[]
	pages= (TotalPlaylists//50)  +1
	while  j<=pages :
		link = OPEN_URL(url)
		prms=json.loads(link)
		i=0
		while h<TotalPlaylists +1  and i<50:
			thumb=''
			try:
				playlistid=str(prms['feed'][u'entry'][i][u'yt$playlistId'][u'$t'])
				title=str(prms['feed'][u'entry'][i][u'title'][u'$t'].encode('utf-8'))
				thumb=str(prms['feed'][u'entry'][i][u'media$group'][u'media$thumbnail'][2][u'url'])
			except:
				pass
			i=i+1
			h=h+1
			lst.append((playlistid,title,thumb))
		j=j+1
		url='https://gdata.youtube.com/feeds/api/users/'+user+ '/playlists?alt=json&max-results=50&start-index='+str (j*50-49)
	return lst
	
def RanFromPlayList(playlistid):
	random.seed()
	url='https://gdata.youtube.com/feeds/api/playlists/'+playlistid+'?alt=json&max-results=50'
	link = OPEN_URL(url)
	prms=json.loads(link)
	numOfItems=int(prms['feed'][u'openSearch$totalResults'][u'$t']) #if bigger than 50 needs  to add more result
	if numOfItems >1 :
		link = OPEN_URL(url)
		prms=json.loads(link)
		if numOfItems>49:
			numOfItems=49
		i=random.randint(1, numOfItems-1)
		#print str (len(prms['feed'][u'entry']))  +"and i="+ str(i)
		try:
			urlPlaylist= str(prms['feed'][u'entry'][i][ u'media$group'][u'media$player'][0][u'url'])
			match=re.compile('www.youtube.com/watch\?v\=(.*?)\&f').findall(urlPlaylist)
			finalurl="plugin://plugin.video.youtube/play/?video_id="+match[0]+"&hd=1" #finalurl="plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid="+match[0]+"&hd=1"
			title= str(prms['feed'][u'entry'][i][ u'media$group'][u'media$title'][u'$t'].encode('utf-8')).decode('utf-8')
			thumb =str(prms['feed'][u'entry'][i][ u'media$group'][u'media$thumbnail'][2][u'url'])
			desc= str(prms['feed'][u'entry'][i][ u'media$group'][u'media$description'][u'$t'].encode('utf-8')).decode('utf-8')
		except :
			 return "","","",""  # private video from youtube
		'''liz = xbmcgui.ListItem(title, iconImage="DefaultVideo.png", thumbnailImage=thumb)
		liz.setInfo( type="Video", infoLabels={ "Title": title} )
		liz.setProperty("IsPlayable","true")
		pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
		pl.clear()
		pl.add(finalurl, liz)'''
		#xbmc.Player(xbmc.PLAYER_CORE_MPLAYER).play(pl)
		return finalurl,title,thumb,desc
	else:
		return "","","",""

def SeasonsFromShow(showApiUrl):
	#print showApiUrl
	resultJSON = json.loads(OPEN_URL(showApiUrl))
	seasons=resultJSON['feed']['entry']
	for i in range (0, len(seasons)) :
		#print seasons[i].keys()
		#print seasons[i]['title']['$t']
		for index,item in  enumerate(seasons[i]['gd$feedLink']) :
			if item['countHint'] !=0:
				resultJSON = json.loads(OPEN_URL( seasons[i]['gd$feedLink'][index]['href']+'&alt=json'))
				for  j in range (0, len(resultJSON['feed']['entry'])) :
					title= str(resultJSON['feed'][u'entry'][j][ u'media$group'][u'media$title'][u'$t'].encode('utf-8')).decode('utf-8')
					thumb =str(resultJSON['feed'][u'entry'][j][ u'media$group'][u'media$thumbnail'][-1][u'url'])
					episode_num=resultJSON['feed']['entry'][j]['yt$episode']['number']
					url= resultJSON['feed']['entry'][j]['link'][0]['href']
					match=re.compile('www.youtube.com/watch\?v\=(.*?)\&f').findall(url)
					#finalurl="plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid="+match[0]+"&hd=1"
					finalurl="plugin://plugin.video.youtube/play/?video_id="+match[0]+"&hd=1"
					addLink(title+' '+episode_num ,finalurl,thumb,'')
					
def setView(content, viewType):
	'''set content type so library shows more views and info'''
	autoview = xbmc.getInfoLabel('Skin.HasSetting(AutoView)')
	if content:
		xbmcplugin.setContent(int(sys.argv[1]), content)
	if viewType == "":
		if content == 'episodes': viewType = 50
		elif content == 'seasons': viewType = 50
		elif content == 'tvshows': viewType = 58
		elif content == 'movies': viewType = 58
		#else: viewType = 50
	if admin: notification("test3","","",1000)
	if General_AutoView == "true" and autoview:
		returned = checkDialog(admin)
		containerfolderpath2 = xbmc.getInfoLabel('Container.FolderPath')
		count = 0
		while (viewType != "" and count < 5) or (count < 40 and returned != "" and containerfolderpath2 == containerfolderpath and containerfolderpath != "") and not xbmc.abortRequested:
			xbmc.sleep(200)
			count += 1
			containerfolderpath2 = xbmc.getInfoLabel('Container.FolderPath')
			returned = checkDialog(admin)
			if containerfolderpath2 == 'plugin://' + addonID + "/": viewType = 50
		if count < 40:
			xbmc.executebuiltin("Container.SetViewMode(%s)" % viewType )
			'''---------------------------'''
	#addDir(addonString(57).encode('utf-8') + space + addonString(200).encode('utf-8') + space + "1" + space5 + addonString(16).encode('utf-8'),'GoProCamera',9,'http://i.ytimg.com/i/fm5IpcgGCooON4Mm2vq40A/1.jpg?v=52fcd974',addonString(116).encode('utf-8'),'1',"")
		
		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		if admin:
			print printfirst + "count" + space + str(count) + space + "viewType" + space2 + str(viewType) + space + "returned" + space2 + returned
			print printfirst + "setView" + space + "containerfolderpath" + space2 + space + containerfolderpath
			print printfirst + "setView" + space + "containerfolderpath2" + space2 + containerfolderpath2

		'''---------------------------'''

def ShowFromUser(user):
	'''reads  user names from my subscriptions'''
	murl='https://gdata.youtube.com/feeds/api/users/'+user+'/shows?alt=json&start-index=1&max-results=50&v=2'
	resultJSON = json.loads(OPEN_URL(murl))
	shows=resultJSON['feed']['entry']
	#print shows[1]
	hasNext= True
	while hasNext:
		shows=resultJSON['feed']['entry']
		for  i in range (0, len(shows)) :
			showApiUrl=shows[i]['link'][1]['href']
			showApiUrl=showApiUrl[:-4]+'/content?v=2&alt=json'
			showName=shows[i]['title']['$t'].encode('utf-8')
			image= shows[i]['media$group']['media$thumbnail'][-1]['url']
			addDir(showName,showApiUrl,14,image,'','1',"")
		hasNext= resultJSON['feed']['link'][-1]['rel'].lower()=='next'
		if hasNext:
			resultJSON = json.loads(OPEN_URL(resultJSON['feed']['link'][-1]['href']))
			
def TVMode_check(admin, url, playlists):
	from variables import space
	printpoint = ""
	returned = ""
	if General_TVModeDialog == "true":
		printpoint = printpoint + "1"
		list = [40,41,42,43,44,45,46,47,48,49]
		for i in list:
			if "mode=" + str(i) in containerfolderpath: #or (i == 40 and containerfolderpath == "plugin://" + addonID + "/")
				if admin: print printfirst + "YOUList-General_TVModeDialog" + space + "i" + space2 + str(i) + space + containerfolderpath
				printpoint = printpoint + "3"
				countl = 0
				for space in playlists:
					countl += 1
				countlS = str(countl)
				if playlists==[] or countl > 1:  #no playlists on  youtube channel
					'''------------------------------
					---PLAYLIST->-1------------------
					------------------------------'''
					printpoint = printpoint + "5"
					returned = dialogyesno(str79523.encode('utf-8'),str79524.encode('utf-8'))
					if returned == "ok": returned = TvMode(url)
					'''---------------------------'''
				else: printpoint = printpoint + "8"
				
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "TVMode_check_LV" + printpoint
	'''---------------------------'''
	return returned
	
def TvMode(user):
	printpoint = ""
	returned = ""
	try: playlists=PlaylistsFromUser(user)
	except: playlists = []
	if playlists == []:  #no playlists on  youtube channel
		from default import CATEGORIES
		dialog = xbmcgui.Dialog()
		ok = dialog.ok('HTPT', addonString(302).encode('utf-8'))
		CATEGORIES()
	#print "str is" +  str(random.choice(playlists)[0])
	else:
		count = 0
		while count < 10 and xbmc.Player().isPlayingVideo() and not xbmc.abortRequested:
			xbmc.sleep(100)
			count += 1
			if count == 1: xbmc.executebuiltin('Action(Stop)')
		pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
		pl.clear()
		dp= xbmcgui.DialogProgress()
		dp.create('HTPT',"")
		'''PlayListGain/2/3: url / duplicated / deleted'''
		PlayListGain = ""
		PlayListGain2 = 0
		PlayListGain3 = ""
		count = 0
		while count <= 40 and not "9" in printpoint and not xbmc.abortRequested:
			for i in range (1,41):  #40  RANDOM PROGRAMS IN TV MODE
				count += 1
				countS = str(count)
				if count == 1: dp.update(i*50, str79529.encode('utf-8'), "")
				else: dp.close()
				#print str (playlists)
				ran=str(random.choice(playlists)[0])
				finalurl,title,thumb,desc= RanFromPlayList(ran)
				liz = xbmcgui.ListItem(title, iconImage="DefaultVideo.png", thumbnailImage=thumb)
				liz.setInfo( type="Video", infoLabels={ "Title": title} )
				liz.setProperty("IsPlayable","true")
				
				if not finalurl in PlayListGain and not "Deleted video" in title: pl.add(finalurl, liz)
				elif "Deleted video" in title: PlayListGain3 = PlayListGain3 + space + finalurl
				else:
					PlayListGain2 = PlayListGain2 + 1
					if PlayListGain2 > 10:
						playlistlength = xbmc.getInfoLabel('Playlist.Length(video)')
						notification(addonString(305).encode('utf-8') % (str(playlistlength), str(PlayListGain2)),addonString(306).encode('utf-8'),"",4000)
						printpoint = printpoint + "9"
						#sys.exit()
						'''---------------------------'''
				PlayListGain = PlayListGain + space + finalurl
				if count == 1:
					dp.update(100, str79529.encode('utf-8'), "")
					xbmc.Player(xbmc.PLAYER_CORE_MPLAYER).play(pl)
					count2 = 0
					while count2 < 10 and not xbmc.Player().isPlayingVideo() and not xbmc.abortRequested:
						xbmc.sleep(500)
						count2 += 1
						xbmc.sleep(500)
						'''---------------------------'''
				elif not xbmc.Player().isPlayingVideo(): printpoint = printpoint + "9" #sys.exit(1)
		playlistlength = xbmc.getInfoLabel('Playlist.Length(video)')
		playlistlengthN = int(playlistlength)
        if xbmc.Player().isPlayingVideo() and playlistlengthN > 5:
            printpoint = printpoint + "7"
            PlayListGain2S = str(PlayListGain2)
            notification(addonString(305).encode('utf-8') % (playlistlength, PlayListGain2S),addonString(306).encode('utf-8'),"",4000)
            print printfirst + "PlayListGain_" + countS + space + PlayListGain2S + space + "Duplicated Not Added!"
			#xbmc.Player(xbmc.PLAYER_CORE_MPLAYER).play(pl)
            '''---------------------------'''
			
        print printfirst + "TvMode" + space2 + "count" + space2 + countS + space + "PlayListGain2S" + space + PlayListGain2S + space + "PlayListGain3" + space2 + PlayListGain3
		
	if "7" in printpoint: returned = "ok"
	'''---------------------------'''
	return returned
	
def update_view(url):
    ok=True        
    xbmc.executebuiltin('XBMC.Container.Update(%s)' % url )
	#print printfirst + "update_view" + space2 + countS + space + 
    return ok

def unescape(text):
	try:            
		rep = {"&nbsp;": " ",
			   "\n": "",
			   "\t": "",
			   "\r":"",
			   "&#39;":"",
			   "&quot;":"\""
			   }
		for s, r in rep.items():
			text = text.replace(s, r)
			
		# remove html comments
		text = re.sub(r"<!--.+?-->", "", text)    
			
	except TypeError:
		pass

	return text
	
def YOULink(mname, url, thumb, desc):
	if url != 'UKY3scPIMd8' or admin:
		ok=True
		#url = "plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid="+url
		url = "plugin://plugin.video.youtube/play/?video_id="+url
		#url='https://gdata.youtube.com/feeds/api/videos/'+url+'?alt=json&max-results=50' #TEST
		liz=xbmcgui.ListItem(mname, iconImage="DefaultVideo.png", thumbnailImage=thumb)
		liz.setInfo( type="Video", infoLabels={ "Title": mname, "Plot": desc } )
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
		if admin: print printfirst + "YOULink" + space + "url" + space2 + str(url) + space + "mname" + space2 + mname
		return ok
	
def YOULinkAll(url):
	dp = xbmcgui.DialogProgress()
	dp.create(addonName ,addonString(4).encode('utf-8'))
	dp.update(0)
	dp.update(0, "", str79520.encode('utf-8'))
	pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
	pl.clear()
	link = OPEN_URL(url)
	match=re.compile("http\://www.youtube.com/watch\?v\=([^\&]+)\&.+?<media\:descriptio[^>]+>([^<]+)</media\:description>.+?<media\:thumbnail url='([^']+)'.+?<media:title type='plain'>(.+?)/media:title>").findall(link)
	playlist = []
	nItem = len(match)

	for nurl,desc,thumb,rname in match:
		rname=rname.replace('<','')
		#finalurl= "plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid="+nurl+"&hd=1"
		finalurl= "plugin://plugin.video.youtube/play/?video_id="+nurl+"&hd=1"
		liz = xbmcgui.ListItem(rname, iconImage="DefaultVideo.png", thumbnailImage=thumb)
		liz.setInfo( type="Video", infoLabels={ "Title": rname, "Plot": desc}) #NEW UNTESTED!!! (PLOT...)
		liz.setProperty("IsPlayable","true")
		playlist.append((finalurl ,liz))
		progress = len(playlist) / float(nItem) * 100  
		dp.update(int(progress), str79520.encode('utf-8'),rname)
		#dp.update(i*5, str79529.encode('utf-8'), "")
		if dp.iscanceled():
			return

	
	for blob ,liz in playlist:
		try:
			if blob:
				if not 'UKY3scPIMd8' in blob:
					pl.add(blob,liz)
		except:
			pass
	dp.close()
	xbmc.Player(xbmc.PLAYER_CORE_MPLAYER).play(pl)

def YOUList2(name, url, iconimage, desc, num):
	returned = ""
	playlists=PlaylistsFromUser(url)
	
	TVMode_check(admin, url, playlists)
	if General_TVModeDialog != "true" or returned != "ok":
		url2='plugin://plugin.video.youtube/channel/'+url+'/'
		update_view('plugin://plugin.video.youtube/channel/'+url+'/')
		#xbmc.executebuiltin('XBMC.Container.Update(%s)' % url2 )
		'''---------------------------'''
def YOUList(name, url, iconimage, desc, num):
	returned = ""
	printpoint = ""
	try:
		playlists = PlaylistsFromUser(url)
		returned = TVMode_check(admin, url, playlists)
	except: printpoint = printpoint + "8"
				
	if General_TVModeDialog != "true" or returned != "ok":
		if num == "" or num == None: num = '1'
		numN = int(num)
		num3N = 1
		'''---------------------------'''
		murl='http://gdata.youtube.com/feeds/api/users/'+url+'/uploads?&max-results=50&start-index='+num
		#murl='https://gdata.youtube.com/feeds/users/'+url+'/uploads?&max-results=50&start-index='+num
		print printfirst + "murl" + space2 + murl
		link=OPEN_URL(murl)
		#print link
		if addonID == 'plugin.video.htpt.gopro' or addonID == 'plugin.video.htpt.music': addDir('[COLOR=Yellow]' + str79525.encode('utf-8') + '[/COLOR]',url,115,"special://skin/media/DefaultRecentlyAddedEpisodes.png",str79524.encode('utf-8'),'1',"") #TV Mode
		else: addDir('[COLOR=Yellow]' + str79520.encode('utf-8') + '[/COLOR]',murl,11,"special://skin/media/DefaultPlaylist.png",str79526.encode('utf-8'),'1',"") #Quick-Play
		
		match=re.compile("http\://www.youtube.com/watch\?v\=([^\&]+)\&.+?<media\:descriptio[^>]+>([^<]+)</media\:description>.+?<media\:thumbnail url='([^']+)'.+?<media:title type='plain'>(.+?)/media:title>").findall(link)
		
		if not "8" in printpoint:
			for playlistid,title,thumb, in playlists:
				'''PlayList'''
				if num == '1':
					num3N += 1
					numN += 1
					#num = str(numN)
					addDir('[COLOR=Yellow2]' + title + '[/COLOR]',playlistid,12,thumb,str79527.encode('utf-8'),num,"")
					#addDir(title + '[COLOR=Yellow]' + addonString(7).encode('utf-8') + space2 + '[/COLOR]',playlistid,12,thumb,'',num,"")
					#print playlistid
		
		if 1 + 1 == 3:
			for nurl,desc,thumb,rname in match:
				'''Media'''
				if (num == '1' and num3N < 8) or (num != '1' and num3N < 40):
					rname=rname.replace('<','')
					num3N += 1
					numN += 1
					#num = str(numN)
					YOULink(rname, nurl, thumb, desc)
					#addLink(rname, nurl, thumb, desc)
		
		'''Show More Results'''
		if (num == '1' and num3N <= 8): num2N = int(num) + num3N
		else: num2N = int(num) + 40
		num2 = str(num2N)
		num3 = str(num3N)

		if admin or num == '1' or num3N == 40:
			'''TEMP SOLUTION'''
			#addDir('[COLOR=Yellow]' + str79521.encode('utf-8') + '[/COLOR]',url,9,"special://skin/media/icons/se.png",str79528.encode('utf-8'),num2,"")
			if addonID == 'plugin.video.htpt.music': addDir('[COLOR=Yellow]' + str79521.encode('utf-8') + '[/COLOR]','plugin://plugin.video.youtube/user/'+url+'/',8,"special://skin/media/DefaultPlaylist.png",str79528.encode('utf-8'),num2,"") #More Results
			else: addDir('[COLOR=Yellow]' + str79521.encode('utf-8') + '[/COLOR]','plugin://plugin.video.youtube/channel/'+url+'/',8,"special://skin/media/DefaultPlaylist.png",str79528.encode('utf-8'),num2,"") #More Results
			#addDir(name,'plugin://plugin.video.youtube/channel/'+url+'/',8,"","","","")
			#addDir(name,'plugin://plugin.video.youtube/video_id/'+nurl+'/',8,"","","","")
		setsetting_custom1(addonID,'Current_View','default')
		
		
		if admin: print printfirst + "YOUList_LV" + printpoint + " " + "num/2/3" + space2 + num + " / " + num2 + " / " + num3 + space + "returned" + space2 + returned + space + "url" + space2 + url
		if admin: print printfirst + "YOUList" + space + "link" + space2 + str(link)
		if admin: print printfirst + "YOUList" + space + "match" + space2 + str(match)
		#if admin: print printfirst + "YOUList" + space + "nurl" + space2 + str(nurl) + space + "desc" + space2 + str(desc) + space + "thumb" + space2 + str(thumb) + space + "rname" + space2 + str(rname)

def YOUsubs(user):
	murl='http://gdata.youtube.com/feeds/api/users/'+user+'/subscriptions?alt=json&start-index=1&max-results=50'
	resultJSON = json.loads(OPEN_URL(murl))
	feed=resultJSON['feed']['entry']
	for i in range (0, len(feed)) :
		image=str(feed[i]['media$thumbnail']['url'])
		name = feed[i]['title']['$t'].replace('Activity of:','').encode('utf-8')
		url=feed[i]['yt$channelId']['$t'].encode('utf-8')
		addDir(name,url,9,image,'1','1',"")
	setsetting_custom1(addonID,'Current_View','default')
	
def pluginend(admin):
	from modules import *
	printpoint = ""
	'''------------------------------
	---params------------------------
	------------------------------'''
	params=get_params()
	url=None
	name=None
	mode=None
	iconimage=None
	desc=None
	num=None
	'''---------------------------'''
	try: url=urllib.unquote_plus(params["url"])
	except: pass
	try: name=urllib.unquote_plus(params["name"])
	except: pass
	try: iconimage=urllib.unquote_plus(params["iconimage"])
	except: pass
	try: mode=int(params["mode"])
	except: pass
	try: num=urllib.unquote_plus(params["num"])
	except: pass
	'''---------------------------'''

	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	modeS = str(mode)
	urlS = str(url)
	nameS = str(name)
	try: IconImageS = str(IconImage)
	except: IconImageS = "None"
	'''---------------------------'''
	if admin: print printfirst + "default.py" + space2 + "mode" + space2 + modeS + space + "url" + space2 + urlS + space + "name" + space2 + nameS + space + "IconImage" + space2 + IconImageS
	'''---------------------------'''

	'''------------------------------
	---MODES-LIST--------------------
	------------------------------'''
	if mode == None or (url == None or len(url)<1) and mode < 40: 
		CATEGORIES()
		#notification("Test",Addon_Version,"",2000)
		try:
			getsetting('Addon_Update')
			getsetting('Addon_Version')
			getsetting('Addon_UpdateDate')
			getsetting('Addon_UpdateLog')
			checkAddon_Update(admin, Addon_Update, Addon_Version, Addon_UpdateDate, Addon_UpdateLog)
		except:
			printpoint = printpoint + "2"
			'''---------------------------'''
	elif mode == 40:
		CATEGORIES40(admin)
	elif mode == 41:
		CATEGORIES1(admin)
	elif mode == 42: 
		CATEGORIES2(admin)
	elif mode == 421:
		CATEGORIES21(admin)
	elif mode == 43:       
		CATEGORIES3(admin)
	elif mode == 44:       
		CATEGORIES4(admin)
	elif mode == 45:    
		CATEGORIES5(admin)
	elif mode == 46:       
		CATEGORIES6(admin)
	elif mode == 47:       
		CATEGORIES7(admin)
	elif mode == 48:       
		CATEGORIES8(admin)
	elif mode == 49:       
		CATEGORIES9(admin)
		
	elif mode == 1:
		#print ""+url
		Choose_series(url)
	elif mode == 2:
		series_land(url)
	elif mode == 3:
		play_episode(url)
	elif mode == 4:
		play_video(url)
	elif mode == 8:
		update_view(url)
	elif mode == 7:
		ListLive(url)
	elif mode == 9:
		YOUList(name, url, iconimage, desc, num)
		#YOUList2(name, url, iconimage, desc, num)
	elif mode == 10:
		YOUsubs(url)
	elif mode == 11:
		YOULinkAll(url)
	elif mode == 12:
		PlayPlayList(url)
	elif mode == 13:
		ListPlaylist(url, num)
	elif mode == 14:       
		SeasonsFromShow(url)
	elif mode == 15:       
		pass
	elif mode == 16:       
		ShowFromUser(url)
	elif mode == 115:
		TvMode(url)
	else: notification("?","","",1000)	
	xbmcplugin.endOfDirectory(int(sys.argv[1]))
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "pluginend_LV" + printpoint
	'''---------------------------'''
	return url, name, mode, iconimage, desc, num