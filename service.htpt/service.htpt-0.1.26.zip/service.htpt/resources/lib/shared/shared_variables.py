#import xbmc, os, subprocess, sys
#import xbmc, xbmcgui, xbmcaddon
#import xbmc, xbmcgui, xbmcaddon
#import datetime, time
#import sys, os

import xbmc, xbmcgui, xbmcaddon, sys, os
'''---------------------------'''
#from variables import printfirst

#getsetting         = xbmcaddon.Addon().getSetting
#setsetting         = xbmcaddon.Addon().setSetting
#addonName          = xbmcaddon.Addon().getAddonInfo("name")
#addonString        = xbmcaddon.Addon().getLocalizedString
#addonID          = xbmcaddon.Addon().getAddonInfo("id")
#addonPath          = xbmcaddon.Addon().getAddonInfo("path")
#addonVersion          = xbmcaddon.Addon().getAddonInfo("version")

printfirst = xbmcaddon.Addon().getAddonInfo("name") + ": !@# "
'''---------------------------'''

'''------------------------------
---DEFAULT-----------------------
------------------------------'''
space = " "
space2 = ": "
space3 = "_"
space4 = " / "
space5 = " - "
dialog = xbmcgui.Dialog()
systemplatformwindows = xbmc.getCondVisibility('system.platform.windows')
systemidle3 = xbmc.getCondVisibility('System.IdleTime(3)')
systemidle7 = xbmc.getCondVisibility('System.IdleTime(7)')
systemidle10 = xbmc.getCondVisibility('System.IdleTime(10)')
systemidle120 = xbmc.getCondVisibility('System.IdleTime(120)')
systemidle300 = xbmc.getCondVisibility('System.IdleTime(300)')
systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
systemcurrentwindow = xbmc.getInfoLabel('System.CurrentWindow')
'''---------------------------'''

'''------------------------------
---Window.-----------------------
------------------------------'''

custom1115W = xbmc.getCondVisibility('Window.IsVisible(Custom1115.xml)')
custom1124W = xbmc.getCondVisibility('Window.IsVisible(Custom1124.xml)')
custom1125W = xbmc.getCondVisibility('Window.IsVisible(Custom1125.xml)')
custom1132W = xbmc.getCondVisibility('Window.IsVisible(Custom1132.xml)')
custom1170W = xbmc.getCondVisibility('Window.IsVisible(Custom1170.xml)')
custom1171W = xbmc.getCondVisibility('Window.IsVisible(Custom1171.xml)')
custom1191W = xbmc.getInfoLabel('Skin.String(custom1191)')

customhomecustomizerW = xbmc.getCondVisibility('Window.IsVisible(CustomHomeCustomizer.xml)')
dialogbusyW = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
dialogcontentsettingsW = xbmc.getCondVisibility('Window.IsVisible(DialogContentSettings.xml)')
dialogcontextmenuW = xbmc.getCondVisibility('Window.IsVisible(DialogContextMenu.xml)')
dialogfavouritesW = xbmc.getCondVisibility('Window.IsVisible(DialogFavourites.xml)')
dialogkaitoastW = xbmc.getCondVisibility('Window.IsVisible(DialogKaiToast.xml)')
dialogkeyboard = xbmc.getCondVisibility('Window.IsVisible(DialogKeyboard.xml)')
dialogokW = xbmc.getCondVisibility('Window.IsVisible(DialogOk.xml)')
dialogprogressW = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
dialogselectW = xbmc.getCondVisibility('Window.IsVisible(DialogSelect.xml)')
dialogsubtitlesW = xbmc.getCondVisibility('Window.IsVisible(DialogSubtitles.xml)')
dialogtextviewerW = xbmc.getCondVisibility('Window.IsVisible(DialogTextViewer.xml)')
dialogvideoinfoW = xbmc.getCondVisibility('Window.IsVisible(DialogVideoInfo.xml)')
dialogyesnoW = xbmc.getCondVisibility('Window.IsVisible(DialogYesNo.xml)')
filemanagerW = xbmc.getCondVisibility('Window.IsVisible(FileManager.xml)')
loginscreenW = xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)')
loginscreen_aW = xbmc.getCondVisibility('Window.IsActive(LoginScreen.xml)')
mainwindow = xbmc.getCondVisibility('Window.IsVisible(mainWindow.xml)') #OpenELEC
mypicsW = xbmc.getCondVisibility('Window.IsVisible(MyPics.xml)')
myprogramsW = xbmc.getCondVisibility('Window.IsVisible(MyPrograms.xml)')
mymusicnavW = xbmc.getCondVisibility('Window.IsVisible(MyMusicNav.xml)')
myvideonavW = xbmc.getCondVisibility('Window.IsVisible(MyVideoNav.xml)')
myweatherW = xbmc.getCondVisibility('Window.IsVisible(MyWeather.xml)')
dialogpvrchannelsosd = xbmc.getCondVisibility('Window.IsVisible(DialogPVRChannelsOSD.xml)')
mypvrchannels = xbmc.getCondVisibility('Window.IsVisible(MyPVRChannels.xml)')
mypvrguide = xbmc.getCondVisibility('Window.IsVisible(MyPVRGuide.xml)')
homeW = xbmc.getCondVisibility('Window.IsVisible(Home.xml)')
home_pW = xbmc.getCondVisibility('Window.Previous(0)')
home_aW = xbmc.getCondVisibility('Window.IsActive(0)')

settingsW = xbmc.getCondVisibility('Window.IsVisible(Settings.xml)')
settingscategoryW = xbmc.getCondVisibility('Window.IsVisible(SettingsCategory.xml)')
skinsettingsW = xbmc.getCondVisibility('Window.IsVisible(SkinSettings.xml)')
startupW = xbmc.getCondVisibility('Window.IsVisible(Startup.xml)')
startup_aW = xbmc.getCondVisibility('Window.IsActive(Startup.xml)')
startup_pW = xbmc.getCondVisibility('Window.Previous(Startup.xml)')
videofullscreenW = xbmc.getCondVisibility('Window.IsVisible(VideoFullScreen.xml)')
'''---------------------------'''

'''------------------------------
---VideoPlayer-------------------
------------------------------'''
videoplayercontentEPISODE = xbmc.getCondVisibility('VideoPlayer.Content(episodes)')
videoplayercontentMOVIE = xbmc.getCondVisibility('VideoPlayer.Content(movies)')
videoplayercontentSEASON = xbmc.getCondVisibility('VideoPlayer.Content(seasons)')
videoplayercontentTV = xbmc.getCondVisibility('VideoPlayer.Content(tvshows)')
videoplayercountry = xbmc.getInfoLabel('VideoPlayer.Country')
videoplayerhassubtitles = xbmc.getCondVisibility('VideoPlayer.HasSubtitles')
videoplayerisfullscreen = xbmc.getCondVisibility('VideoPlayer.IsFullscreen')
videoplayerseason = xbmc.getInfoLabel('VideoPlayer.Season')
videoplayertagline = xbmc.getInfoLabel('VideoPlayer.Tagline')
videoplayertitle = xbmc.getInfoLabel('VideoPlayer.Title')
videoplayertvshowtitle = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
videoplayeryear = xbmc.getInfoLabel('VideoPlayer.Year')
videoplayervideoresolution = xbmc.getInfoLabel('VideoPlayer.VideoResolution')
videoplayervideocodec = xbmc.getInfoLabel('VideoPlayer.VideoCodec')
videoplayeraudiochannels = xbmc.getInfoLabel('VideoPlayer.AudioChannels')
videoplayeraudiocodec = xbmc.getInfoLabel('VideoPlayer.AudioCodec')



'''---------------------------'''

'''------------------------------
---System.X-Version--------------
------------------------------'''
if xbmc.getCondVisibility('System.HasAddon(service.htpt)'): htptversion = xbmc.getInfoLabel('System.AddonVersion(skin.htpt)') + "+"
elif xbmc.getCondVisibility('!System.HasAddon(service.htpt)'): htptversion = xbmc.getInfoLabel('System.AddonVersion(skin.htpt)') + "-"
buildversion = xbmc.getInfoLabel('System.BuildVersion')
htptdebugversion = xbmc.getInfoLabel('System.AddonVersion(script.htpt.debug)')
htptserviceversion = xbmc.getInfoLabel('system.AddonVersion(service.htpt)')
htpthelpversion = xbmc.getInfoLabel('System.AddonVersion(service.htpt.help)')
htpthomebuttonsversion = xbmc.getInfoLabel('System.AddonVersion(script.htpt.homebuttons)')
htptremoteversion = xbmc.getInfoLabel('System.AddonVersion(script.htpt.remote)')
htptrefreshversion = xbmc.getInfoLabel('System.AddonVersion(script.htpt.refresh)')
htptfixversion = xbmc.getInfoLabel('System.AddonVersion(service.htpt.fix)')
htptskinversion = xbmc.getInfoLabel('System.AddonVersion(skin.htpt)')
htptemuversion = xbmc.getInfoLabel('System.AddonVersion(script.htpt.emu)')
htptkidsversion = xbmc.getInfoLabel('System.AddonVersion(plugin.video.htpt.kids)')
htptgoproversion = xbmc.getInfoLabel('System.AddonVersion(plugin.video.htpt.gopro)')
htptmusicversion = xbmc.getInfoLabel('System.AddonVersion(plugin.video.htpt.music)')
'''---------------------------'''



'''------------------------------
---System.GetBool----------------
------------------------------'''
sgbservicesairplay = xbmc.getCondVisibility('System.GetBool(services.airplay)')
sgbserviceszeroconf = xbmc.getCondVisibility('System.GetBool(services.zeroconf)')
sgbpvrmanagerenabled = xbmc.getCondVisibility('System.GetBool(pvrmanager.enabled)')
'''---------------------------'''

'''------------------------------
---System.HasAddon---------------
------------------------------'''
systemhasaddon_urlresolver = xbmc.getCondVisibility('System.HasAddon(script.module.urlresolver)')
systemhasaddon_genesis = xbmc.getCondVisibility('System.HasAddon(plugin.video.genesis)')
systemhasaddon_sdarottv = xbmc.getCondVisibility('System.HasAddon(plugin.video.sdarot.tv)')
systemhasaddon_aob = xbmc.getCondVisibility('System.HasAddon(plugin.video.aob)')
systemhasaddon_fantasticc = xbmc.getCondVisibility('System.HasAddon(plugin.video.fantasticc)')
systemhasaddon_videodevil = xbmc.getCondVisibility('System.HasAddon(plugin.video.videodevil)')
systemhasaddon_videopulsar = xbmc.getCondVisibility('System.HasAddon(plugin.video.pulsar)')
systemhasaddon_metadatauniversal = xbmc.getCondVisibility('System.HasAddon(metadata.universal)')
systemhasaddon_metadatathemoviedb = xbmc.getCondVisibility('System.HasAddon(metadata.themoviedb.org)')

systemhasaddon_servicesubtitlessubtitle = xbmc.getCondVisibility('System.HasAddon(service.subtitles.subtitle)')
systemhasaddon_pluginvideoisraelive = xbmc.getCondVisibility('System.HasAddon(plugin.video.israelive)')
systemhasaddon_pluginvideoyoutube = xbmc.getCondVisibility('System.HasAddon(plugin.video.youtube)')
systemhasaddon_pluginvideop2pstreams = xbmc.getCondVisibility('System.HasAddon(plugin.video.p2p-streams)')
systemhasaddon_serviceautosubs = xbmc.getCondVisibility('System.HasAddon(service.autosubs)')
'''---------------------------'''

systemhasaddon_htptemu = xbmc.getCondVisibility('System.HasAddon(script.htpt.emu)')
systemhasaddon_htptdebug = xbmc.getCondVisibility('System.HasAddon(script.htpt.debug)')
systemhasaddon_htptfix = xbmc.getCondVisibility('System.HasAddon(service.htpt.fix)')
systemhasaddon_htptkids = xbmc.getCondVisibility('System.HasAddon(plugin.video.htpt.kids)')
systemhasaddon_htptmusic = xbmc.getCondVisibility('System.HasAddon(plugin.video.htpt.music)')
systemhasaddon_htptgopro = xbmc.getCondVisibility('System.HasAddon(plugin.video.htpt.gopro)')
systemhasaddon_scripthtptdebug = xbmc.getCondVisibility('System.HasAddon(script.htpt.debug)')
systemhasaddon_scripthtptrefresh = xbmc.getCondVisibility('System.HasAddon(script.htpt.refresh)')
systemhasaddon_servicehtpt = xbmc.getCondVisibility('System.HasAddon(service.htpt)')
'''---------------------------'''

'''------------------------------
---System.All--------------------
------------------------------'''
systeminternetstate = xbmc.getInfoLabel('System.InternetState')
systemuptime = xbmc.getInfoLabel('System.Uptime')
systemuptime5 = xbmc.getCondVisibility('!IntegerGreaterThan(System.Uptime,5)')
systemtotaluptime = xbmc.getInfoLabel('System.TotalUptime')
systemcputemperature = xbmc.getInfoLabel('System.CPUTemperature')
screenresolution = xbmc.getInfoLabel('System.ScreenResolution')
systemuptime2 = xbmc.getInfoLabel('System.Uptime') + " / " + xbmc.getInfoLabel('System.TotalUptime') 
freespace2 = xbmc.getInfoLabel('System.TotalSpace') + " / " + xbmc.getInfoLabel('System.FreeSpacePercent')
'''---------------------------'''


'''------------------------------
---Skin.HasSetting---------------
------------------------------'''
admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
admin2 = xbmc.getInfoLabel('Skin.HasSetting(Admin2)')
adult = xbmc.getInfoLabel('Skin.HasSetting(Adult)')
adult2 = xbmc.getInfoLabel('Skin.HasSetting(Adult2)')
autoplay_hd = xbmc.getInfoLabel('Skin.HasSetting(AutoPlay_HD)')
autoplaysd = xbmc.getInfoLabel('Skin.HasSetting(AutoPlaySD)')
autoplaypause = xbmc.getInfoLabel('Skin.HasSetting(AutoPlay_Pause)')
autoview = xbmc.getInfoLabel('Skin.HasSetting(AutoView)')
autoviewoff = xbmc.getInfoLabel('Skin.HasSetting(AutoViewoff)')
connected = xbmc.getInfoLabel('Skin.HasSetting(Connected)')
connected2 = xbmc.getInfoLabel('Skin.HasSetting(Connected2)')
connected3 = xbmc.getInfoLabel('Skin.HasSetting(Connected3)')
dialogselectopen = xbmc.getInfoLabel('Skin.HasSetting(DialogSelectOpen)')
homebuttonsrunning = xbmc.getInfoLabel('Skin.HasSetting(homebuttonsrunning)')
moviesep = xbmc.getInfoLabel('Skin.HasSetting(moviesep)')
myhtpt2 = xbmc.getInfoLabel('Skin.HasSetting(myHTPT2)')
myhtpt3 = xbmc.getInfoLabel('Skin.HasSetting(myHTPT3)')
realdebrid = xbmc.getInfoLabel('Skin.HasSetting(RealDebrid)') #TEMP
sdarottv = xbmc.getInfoLabel('Skin.HasSetting(SdarotTV)') #TEMP
validation = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION)')
validation2 = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION2)')
validation5 = xbmc.getInfoLabel('Skin.String(VALIDATION5)')
widget = xbmc.getInfoLabel('Skin.HasSetting(Widget)')
'''---------------------------'''

'''------------------------------
---SKIN-STRINGS------------------
------------------------------'''
customvar = xbmc.getInfoLabel('Skin.String(General_CustomVAR)')
listitemtvshowtitlestr = xbmc.getInfoLabel('Skin.String(ListItemTVShowTitle)')
listitemgenrestr = xbmc.getInfoLabel('Skin.String(ListItemGenre)')
listitemdurationstr = xbmc.getInfoLabel('Skin.String(ListItemDuration)')
listitemratingstr = xbmc.getInfoLabel('Skin.String(ListItemRating)')
listitemyearstr = xbmc.getInfoLabel('Skin.String(ListItemYear)')
mac1str = xbmc.getInfoLabel('Skin.String(MAC1)')
mac2str = xbmc.getInfoLabel('Skin.String(MAC2)')
mac3str = xbmc.getInfoLabel('Skin.String(MAC3)')
messagescustom = xbmc.getInfoLabel('Skin.String(MessagesCustom)')
homemessagescustom = xbmc.getInfoLabel('Skin.String(HomeMessagesCustom)')
moviesestartup = xbmc.getInfoLabel('Skin.String(moviesestartup)')
musiclinkstr = xbmc.getInfoLabel('Skin.String(MusicLink)')
pingnow = xbmc.getInfoLabel('Skin.String(Ping_Now)')
pingrate = xbmc.getInfoLabel('Skin.String(Ping_Rate)')
settingslevel = xbmc.getInfoLabel('Skin.String(SettingsLevel)')
tvshowsestartup = xbmc.getInfoLabel('Skin.String(tvshowsestartup)')
varcurrentpicvidpath = xbmc.getInfoLabel('Skin.String(VarCurrentPicVidPath)')
usb1str = xbmc.getInfoLabel('Skin.String(USB1)')
usb2str = xbmc.getInfoLabel('Skin.String(USB2)')
usb3str = xbmc.getInfoLabel('Skin.String(USB3)')
usb4str = xbmc.getInfoLabel('Skin.String(USB4)')
usb5str = xbmc.getInfoLabel('Skin.String(USB5)')
'''---------------------------'''

'''------------------------------
---Playlist----------------------
------------------------------'''
playlistlength = xbmc.getInfoLabel('Playlist.Length(video)')
playlistlengthN = int(playlistlength)
playlistposition = xbmc.getInfoLabel('Playlist.Position(video)')
playlistpositionN = int(playlistposition)
'''---------------------------'''


'''------------------------------
---Player------------------------
------------------------------'''
playerhasvideo = xbmc.getCondVisibility('Player.HasVideo')
playerpaused = xbmc.getCondVisibility('Player.Paused')
playercache = xbmc.getInfoLabel('Player.CacheLevel')
playertitle = xbmc.getInfoLabel('Player.Title')
playerfilename = xbmc.getInfoLabel('Player.Filename')
playerhasmedia = xbmc.getCondVisibility('Player.HasMedia')
playertime = xbmc.getInfoLabel("Player.Time(hh)") + xbmc.getInfoLabel("Player.Time(mm)") + xbmc.getInfoLabel("Player.Time(ss)")
playertimeremaining = xbmc.getInfoLabel("Player.TimeRemaining(hh)") + xbmc.getInfoLabel("Player.TimeRemaining(mm)") + xbmc.getInfoLabel("Player.TimeRemaining(ss)")
playerduration = xbmc.getInfoLabel("Player.Duration(hh)") + xbmc.getInfoLabel("Player.Duration(mm)") + xbmc.getInfoLabel("Player.Duration(ss)")
'''---------------------------'''

'''------------------------------
---PATH--------------------------
------------------------------'''
israeltvhome = 'plugin://plugin.video.sdarot.tv/'
videorootpath = 'library://video/'
'''---------------------------'''

'''------------------------------
---Network.----------------------
------------------------------'''
dhcpaddress = xbmc.getInfoLabel('Network.DHCPAddress')
macaddress = xbmc.getInfoLabel('Network.MacAddress')
networkgatewayaddress = xbmc.getInfoLabel('Network.GatewayAddress')
networkipaddress = xbmc.getInfoLabel('Network.IPAddress')
'''---------------------------'''

'''------------------------------
---MIXED-------------------------
------------------------------'''
hasinternet = systeminternetstate != "" and networkipaddress != "" and not "169.254." in networkipaddress and (connected or systemplatformwindows)

'''---------------------------'''

'''------------------------------
---$VAR--------------------------
------------------------------'''
var700100 = xbmc.getInfoLabel('Control.GetLabel(700100)')
verrorstr = xbmc.getInfoLabel('$VAR[VERROR]')
r1171var = xbmc.getInfoLabel('$VAR[R1171]')
'''---------------------------'''
topvideoinformation1var = xbmc.getInfoLabel('$VAR[TopVideoInformation1]') #Duration+
topvideoinformation2var = xbmc.getInfoLabel('$VAR[TopVideoInformation2]') #Year+
topvideoinformation3var = xbmc.getInfoLabel('$VAR[TopVideoInformation3]') #Rating
topvideoinformation4var = xbmc.getInfoLabel('$VAR[TopVideoInformation4]') #Poster+
topvideoinformation5var = xbmc.getInfoLabel('$VAR[TopVideoInformation5]') #Plot
topvideoinformation6var = xbmc.getInfoLabel('$VAR[TopVideoInformation6]') #Genre
topvideoinformation7var = xbmc.getInfoLabel('$VAR[TopVideoInformation7]') #Tag+
topvideoinformation8var = xbmc.getInfoLabel('$VAR[TopVideoInformation8]') #Title
'''---------------------------'''
topinformation2var = xbmc.getInfoLabel('$VAR[TopInformation2]') #Left
topinformation3var = xbmc.getInfoLabel('$VAR[TopInformation3]') #Middle

'''------------------------------
---$LOCALIZE-PRIMARY-------------
------------------------------'''
str1 = xbmc.getInfoLabel('$LOCALIZE[1]').decode('utf-8') #Pictures
str2 = xbmc.getInfoLabel('$LOCALIZE[2]') #Music
str3 = xbmc.getInfoLabel('$LOCALIZE[3]').decode('utf-8') #Videos
str106 = xbmc.getInfoLabel('$LOCALIZE[106]') #No
str107 = xbmc.getInfoLabel('$LOCALIZE[107]') #Yes
str186 = xbmc.getInfoLabel('$LOCALIZE[186]') #OK
str222 = xbmc.getInfoLabel('$LOCALIZE[222]') #Cancel
str231 = xbmc.getInfoLabel('$LOCALIZE[231]') #None
str342 = xbmc.getInfoLabel('$LOCALIZE[342]').decode('utf-8') #Movies
str409 = xbmc.getInfoLabel('$LOCALIZE[409]') #Defaults
str443 = xbmc.getInfoLabel('$LOCALIZE[443]').decode('utf-8') #Internet
str503 = xbmc.getInfoLabel('$LOCALIZE[503]') #Busy
str512 = xbmc.getInfoLabel('$LOCALIZE[512]').decode('utf-8') #Startup window
str1273 = xbmc.getInfoLabel('$LOCALIZE[1273]') #AirPlay
str1259 = xbmc.getInfoLabel('$LOCALIZE[1259]') #Zeroconf
str1260 = xbmc.getInfoLabel('$LOCALIZE[1260]') #Announce these services to other systems via Zeroconf
settingslevelstr1 = xbmc.getInfoLabel('$LOCALIZE[10036]') #Basic
settingslevelstr2 = xbmc.getInfoLabel('$LOCALIZE[10037]') #Standard
settingslevelstr3 = xbmc.getInfoLabel('$LOCALIZE[10038]') #Advanced
settingslevelstr4 = xbmc.getInfoLabel('$LOCALIZE[10039]') #Expert
str12321 = xbmc.getInfoLabel('$LOCALIZE[12321]') #Ok
str15016 = xbmc.getInfoLabel('$LOCALIZE[15016]').decode('utf-8') #Games
str16018 = xbmc.getInfoLabel('$LOCALIZE[16018]') #None
str19287 = xbmc.getInfoLabel('$LOCALIZE[19287]') #All channels
str20108 = xbmc.getInfoLabel('$LOCALIZE[20108]') #Root
str20122 = xbmc.getInfoLabel('$LOCALIZE[20122]') #True
str20329 = xbmc.getInfoLabel('$LOCALIZE[20329]') #Movies are in separate folders that match the movie title
str20333 = xbmc.getInfoLabel('$LOCALIZE[20333]') #Set content
str20343 = xbmc.getInfoLabel('$LOCALIZE[20343]').decode('utf-8') #TV shows
str20346 = xbmc.getInfoLabel('$LOCALIZE[20346]') #Scan recursively
str20389 = xbmc.getInfoLabel('$LOCALIZE[20389]') #Music videos
falsestr = xbmc.getInfoLabel('$LOCALIZE[20424]') #False
str20442 = xbmc.getInfoLabel('$LOCALIZE[20442]') #Change content
str33078 = xbmc.getInfoLabel('$LOCALIZE[33078]').decode('utf-8') #Next page
str36901 = xbmc.getInfoLabel('$LOCALIZE[36901]') #movies
str36903 = xbmc.getInfoLabel('$LOCALIZE[36903]') #TV shows
str36909 = xbmc.getInfoLabel('$LOCALIZE[36909]') #musicvideos
'''---------------------------'''

'''------------------------------
---$LOCALIZE-SKIN----------------
------------------------------'''
str69999 = xbmc.getInfoLabel('$LOCALIZE[69999]') #0547393531
str70000 = xbmc.getInfoLabel('$LOCALIZE[70000]') #!
todaystr = xbmc.getInfoLabel('$LOCALIZE[33006]') #Today (remove?)
trialstr = xbmc.getInfoLabel('$LOCALIZE[70001]') #Trial
trial2str = xbmc.getInfoLabel('$LOCALIZE[70002]') #TrialRenew
trial3str = xbmc.getInfoLabel('$LOCALIZE[70003]') #TrialEnd (PREVIOUSLY-TrailEnd)
id6v1str = xbmc.getInfoLabel('$LOCALIZE[70014]').decode('utf-8') #One-Time
id6v2str = xbmc.getInfoLabel('$LOCALIZE[70015]').decode('utf-8') #Per-Month
id6v3str = xbmc.getInfoLabel('$LOCALIZE[70016]').decode('utf-8') #Per-2Months
str70020 = xbmc.getInfoLabel('$LOCALIZE[70020]') #WOULD YOU LIKE TO ADD THIS CONTENT TO HTPT?
str72101 = xbmc.getInfoLabel('$LOCALIZE[72101]').decode('utf-8') #Today
str72102 = xbmc.getInfoLabel('$LOCALIZE[72102]').decode('utf-8') #Yesterday
str72103 = xbmc.getInfoLabel('$LOCALIZE[72103]').decode('utf-8') #This Week
str79081 = xbmc.getInfoLabel('$LOCALIZE[79081]').decode('utf-8') #email
str79211 = xbmc.getInfoLabel('$LOCALIZE[79211]').decode('utf-8') #Trial Period Has Ended
str79311 = xbmc.getInfoLabel('$LOCALIZE[79311]').decode('utf-8') #%s Button Version Updated
str73220 = xbmc.getInfoLabel('$LOCALIZE[73220]').decode('utf-8') #Kids
str75005 = xbmc.getInfoLabel('$LOCALIZE[75005]').decode('utf-8') #Israeli Music
str79041 = xbmc.getInfoLabel('$LOCALIZE[79041]') #YUKU*
str79201 = xbmc.getInfoLabel('$LOCALIZE[79201]').decode('utf-8') #System Version Updated
str79215 = xbmc.getInfoLabel('$LOCALIZE[79215]') #Warning: Internet Browsing
str79216 = xbmc.getInfoLabel('$LOCALIZE[79216]') #VERIFY YOU HAVE A KEYBOARD BEFORE PROCEEDING!
str79217 = xbmc.getInfoLabel('$LOCALIZE[79217]') #Use the following keys in order to return:
str79218 = xbmc.getInfoLabel('$LOCALIZE[79218]') #ESC / ALT-TAB / ALT+F4
str79498 = xbmc.getInfoLabel('$LOCALIZE[79498]').decode('utf-8') #EXTERNAL DEVICES
str79520 = xbmc.getInfoLabel('$LOCALIZE[79520]').decode('utf-8') #Quick Play
str79521 = xbmc.getInfoLabel('$LOCALIZE[79521]').decode('utf-8') #More Results
str79522 = xbmc.getInfoLabel('$LOCALIZE[79522]').decode('utf-8') #View Playlist
str79523 = xbmc.getInfoLabel('$LOCALIZE[79523]').decode('utf-8') #Activate TV Mode?
str79524 = xbmc.getInfoLabel('$LOCALIZE[79524]').decode('utf-8') #
str79525 = xbmc.getInfoLabel('$LOCALIZE[79525]').decode('utf-8') #TV Mode
str79526 = xbmc.getInfoLabel('$LOCALIZE[79526]').decode('utf-8') #Quick-Play (Description)...
str79527 = xbmc.getInfoLabel('$LOCALIZE[79527]').decode('utf-8') #Play List (Description)...
str79528 = xbmc.getInfoLabel('$LOCALIZE[79528]').decode('utf-8') #More Result (Description)...
str79529 = xbmc.getInfoLabel('$LOCALIZE[79529]').decode('utf-8') #Preparing TV Mode...



numinumistr = xbmc.getInfoLabel('$LOCALIZE[79068]')
idpstr = xbmc.getInfoLabel('$LOCALIZE[79246]')
idp2str = xbmc.getInfoLabel('$LOCALIZE[79247]')
'''---------------------------'''

'''------------------------------
---CUSTOM-$LOCALIZE--------------
------------------------------'''
macstr2 = xbmc.getInfoLabel('Network.MacAddress') + " ( " + xbmc.getInfoLabel('Skin.String(MAC1)') + " / " + xbmc.getInfoLabel('Skin.String(MAC2)') + " )"
'''---------------------------'''

'''------------------------------
---ID----------------------------
------------------------------'''
'''idstr = USERNAME EN , id1str = USERNAME HE, id2str = INSTALLATION DATE, id3str = WARRENTY END, id4str = ADDRESS, id5str = TELEPHONE NUMBER, id6str = PAYMENT TERMS, id7str = QUESTION, id8str = TECHNICAL NAME, id9str = CODE RED, id10str = HTPT'S MODEL, ID11 = MAC1, ID12 = MAC2'''
idstr = xbmc.getInfoLabel('Skin.String(ID)')
id1str = xbmc.getInfoLabel('Skin.String(ID1)')
id2str = xbmc.getInfoLabel('Skin.String(ID2)')
id3str = xbmc.getInfoLabel('Skin.String(ID3)')
id4str = xbmc.getInfoLabel('Skin.String(ID4)')
id5str = xbmc.getInfoLabel('Skin.String(ID5)')
id6str = xbmc.getInfoLabel('Skin.String(ID6)')
id7str = xbmc.getInfoLabel('Skin.String(ID7)')
id8str = xbmc.getInfoLabel('Skin.String(ID8)')
id9str = xbmc.getInfoLabel('Skin.String(ID9)')
id10str = xbmc.getInfoLabel('Skin.String(ID10)')
id11str = xbmc.getInfoLabel('Skin.String(ID11)')
id12str = xbmc.getInfoLabel('Skin.String(ID12)')
id60str = xbmc.getInfoLabel('Skin.String(ID60)')
''''''
idnamestr = xbmc.getInfoLabel('$LOCALIZE[1014]')
id2namestr = xbmc.getInfoLabel('$LOCALIZE[70010]')
id3namestr = xbmc.getInfoLabel('$LOCALIZE[70011]')
id4namestr = xbmc.getInfoLabel('$LOCALIZE[19115]')
id5namestr = xbmc.getInfoLabel('$LOCALIZE[75006]')
id6namestr = xbmc.getInfoLabel('$LOCALIZE[70012]')
id60namestr = xbmc.getInfoLabel('$LOCALIZE[70012]')
id7namestr = 'Question'
id8namestr = xbmc.getInfoLabel('$LOCALIZE[70013]')
id9namestr = 'CODE RED'
id10namestr = xbmc.getInfoLabel('$LOCALIZE[79031]')
id11namestr = 'MAC1 (LAN)'
id12namestr = 'MAC2 (WLAN)'
''''''
fixip = xbmc.getInfoLabel('Skin.String(fixip)')
trial = xbmc.getInfoLabel('Skin.HasSetting(Trial)')
trial2 = xbmc.getInfoLabel('Skin.HasSetting(Trial2)')
trialdate = xbmc.getInfoLabel('Skin.String(TrialDate)')
trialdate2 = xbmc.getInfoLabel('Skin.String(TrialDate2)')

idtrial = 'htptuser'
idpstr = xbmc.getInfoLabel('$LOCALIZE[79246]')
idp2str = xbmc.getInfoLabel('$LOCALIZE[79247]')

'''------------------------------
---LIST--------------------------
------------------------------'''

'''---------------------------'''

'''------------------------------
---LISTITEM-------------
------------------------------'''
listitemduration = xbmc.getInfoLabel('ListItem.Duration')
listitemepisode = xbmc.getInfoLabel('ListItem.Episode')
listitemgenre = xbmc.getInfoLabel('ListItem.Genre')
listitempath = xbmc.getInfoLabel('ListItem.Path')
listitemrating = xbmc.getInfoLabel('ListItem.Rating')
listitemseason = xbmc.getInfoLabel('ListItem.Season')
listitemtitle = xbmc.getInfoLabel('ListItem.Title')
listitemtvshowtitle = xbmc.getInfoLabel('ListItem.TVShowTitle')
listitemyear = xbmc.getInfoLabel('ListItem.Year')
'''---------------------------'''

'''------------------------------
---Library.----------------------
------------------------------'''
libraryhascontentmovies = xbmc.getCondVisibility('Library.HasContent(Movies)')
libraryhascontentmoviesets = xbmc.getCondVisibility('Library.HasContent(MovieSets)')
libraryhascontentmusic = xbmc.getCondVisibility('Library.HasContent(Music)')
libraryhascontentmusicvideos = xbmc.getCondVisibility('Library.HasContent(MusicVideos)')
libraryhascontenttvshows = xbmc.getCondVisibility('Library.HasContent(TVShows)')
libraryhascontentvideo = xbmc.getCondVisibility('Library.HasContent(Video)')
libraryisscanningvideo = xbmc.getCondVisibility('Library.IsScanningVideo')
libraryisscanningmusic = xbmc.getCondVisibility('Library.IsScanningMusic')
'''---------------------------'''

'''------------------------------
---EMPTY-------------------------
------------------------------'''
controlhasfocus698 = ""
controlhasfocus699 = ""



'''------------------------------
---CONTROL-----------------------
------------------------------'''
autoplaypausebutton = (xbmc.getCondVisibility('Window.IsVisible(Home.xml)') and xbmc.getCondVisibility('Control.HasFocus(9093)')) or (xbmc.getCondVisibility('Window.IsVisible(MyVideoNav.xml)') and xbmc.getCondVisibility('Control.HasFocus(111)'))
subtitleosdbutton = xbmc.getCondVisibility('Control.HasFocus(703)') #subtitleosdbutton
volumeosdbutton = xbmc.getCondVisibility('Control.HasFocus(707)') #volumeosdbutton

button101 = xbmc.getCondVisibility('Control.HasFocus(101)') #xbmc.getCondVisibility('Container(9000).HasFocus(101)')
button102 = xbmc.getCondVisibility('Control.HasFocus(102)') #xbmc.getCondVisibility('Container(9000).HasFocus(101)')
cancelbutton = xbmc.getCondVisibility('Control.HasFocus(10)') and xbmc.getCondVisibility('Window.IsActive(DialogProgress.xml)')
controlgetlabel1 = xbmc.getInfoLabel('Control.GetLabel(1)')
controlgetlabel100 = xbmc.getInfoLabel('Control.GetLabel(100)') #DialogSubtitles Service Name
controlhasfocus20 = xbmc.getCondVisibility('Control.HasFocus(20)')
controlisvisible311 = xbmc.getCondVisibility('Control.IsVisible(311)') or xbmc.getCondVisibility('Control.HasFocus(340)')
controlisvisible311S = str(controlisvisible311)
controlisvisible312 = xbmc.getCondVisibility('Control.IsVisible(312)') or xbmc.getCondVisibility('Control.HasFocus(341)')
controlisvisible312S = str(controlisvisible312)
debugbutton = xbmc.getCondVisibility('Container(50).HasFocus(5)') or (xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(102)'))
leftmenubutton110 = xbmc.getCondVisibility('Control.HasFocus(110)')
controlhasfocus32 = xbmc.getCondVisibility('Control.HasFocus(32)') #UPDATE LIVE TV CHANNELS
refreshbutton = xbmc.getCondVisibility('Control.HasFocus(9092)')
settinglevelbutton = xbmc.getCondVisibility('Control.HasFocus(20)')
'''---------------------------'''

'''------------------------------
---CONTAINER---------------------
------------------------------'''
container120numitems = xbmc.getInfoLabel('Container(120).NumItems') #DialogSubtitles
containernumitems = xbmc.getInfoLabel('Container.NumItems')
viewmode = xbmc.getInfoLabel('Container.Viewmode')
containerfolderpath = xbmc.getInfoLabel('Container.FolderPath')
containerfoldername = xbmc.getInfoLabel('Container.FolderName')
container50position = xbmc.getInfoLabel('Container(50).Position')
if homeW: container9000pos = xbmc.getInfoLabel('Container(9000).Position')

'''---------------------------'''

'''------------------------------
---ACCOUNTS----------------------
------------------------------'''
Account1_Active = xbmc.getInfoLabel('Skin.HasSetting(Account1_Active)')
Account1_Period = xbmc.getInfoLabel('Skin.String(Account1_Period)')
Account1_EndDate = xbmc.getInfoLabel('Skin.String(Account1_EndDate)')
Account2_Active = xbmc.getInfoLabel('Skin.HasSetting(Account2_Active)')
Account2_Period = xbmc.getInfoLabel('Skin.String(Account2_Period)')
Account2_EndDate = xbmc.getInfoLabel('Skin.String(Account2_EndDate)')
Account3_Active = xbmc.getInfoLabel('Skin.HasSetting(Account3_Active)')
Account3_Period = xbmc.getInfoLabel('Skin.String(Account3_Period)')
Account3_EndDate = xbmc.getInfoLabel('Skin.String(Account3_EndDate)')
Account4_Active = xbmc.getInfoLabel('Skin.HasSetting(Account4_Active)')
Account4_Period = xbmc.getInfoLabel('Skin.String(Account4_Period)')
Account4_EndDate = xbmc.getInfoLabel('Skin.String(Account4_EndDate)')
Account5_Active = xbmc.getInfoLabel('Skin.HasSetting(Account5_Active)')
Account5_Period = xbmc.getInfoLabel('Skin.String(Account5_Period)')
Account5_EndDate = xbmc.getInfoLabel('Skin.String(Account5_EndDate)')

Account10_Active = xbmc.getInfoLabel('Skin.HasSetting(Account10_Active)')
'''---------------------------'''


'''------------------------------
---xbmcaddon.Addon---------------
------------------------------'''
if systemhasaddon_htptfix: pass #script.htpt.debug - only!

if systemhasaddon_scripthtptrefresh: pass #script.htpt.debug - only! (else bugged!)
	
if systemhasaddon_servicehtpt:
	getsetting_servicehtpt = xbmcaddon.Addon('service.htpt').getSetting
	setsetting_servicehtpt = xbmcaddon.Addon('service.htpt').setSetting
	servicehtpt_Skin_UpdateLog = getsetting_servicehtpt('Skin_UpdateLog')
	'''---------------------------'''
else:
	servicehtpt_Skin_UpdateLog = "!"
	'''---------------------------'''
if systemhasaddon_pluginvideoisraelive:
	getsetting_israelive          = xbmcaddon.Addon('plugin.video.israelive').getSetting
	israelive_set1 = getsetting_israelive('remoteSettingsUrl')
	'''---------------------------'''
else:
	israelive_set1 = "!"
	'''---------------------------'''
if systemhasaddon_sdarottv:
	getsetting_sdarottv          = xbmcaddon.Addon('plugin.video.sdarot.tv').getSetting
	setsetting_sdarottv          = xbmcaddon.Addon('plugin.video.sdarot.tv').setSetting

	sdarottv_user = getsetting_sdarottv('username')
	sdarottv_password = getsetting_sdarottv('user_password')
	sdarottv_domain = getsetting_sdarottv('domain')
	'''---------------------------'''
else:
	sdarottv_user = "!"
	sdarottv_password = "!"
	sdarottv_domain = "!"
	'''---------------------------'''
if systemhasaddon_servicesubtitlessubtitle:
	getsetting_subtitle          = xbmcaddon.Addon('service.subtitles.subtitle').getSetting
	subtitle_set1 = getsetting_subtitle('SUBemail')
	subtitle_set2 = getsetting_subtitle('SUBpassword')
	'''---------------------------'''
else:
	subtitle_set1 = "!"
	subtitle_set2 = "!"
	'''---------------------------'''
if systemhasaddon_genesis:
	addonString_genesis            = xbmcaddon.Addon('plugin.video.genesis').getLocalizedString
	getsetting_genesis          = xbmcaddon.Addon('plugin.video.genesis').getSetting
	genesis_set1 = getsetting_genesis('autoplay_library')
	genesis_set2 = getsetting_genesis('autoplay_hd')
	genesis_set3 = getsetting_genesis('autoplay')
	genesis_set4 = getsetting_genesis('hosthd1')
	genesis_set5 = getsetting_genesis('hosthd2')
	genesis_set6 = getsetting_genesis('hosthd3')
	genesis_set7 = getsetting_genesis('realdedrid_user')
	genesis_set8 = getsetting_genesis('realdedrid_password')
	genesis_set9 = getsetting_genesis('movie_library')
	genesis_set10 = getsetting_genesis('tv_library')
	'''---------------------------'''
else:
	genesis_set1 = "!"
	genesis_set2 = "!"
	genesis_set3 = "!"
	genesis_set4 = "!"
	genesis_set5 = "!"
	genesis_set6 = "!"
	genesis_set7 = "!"
	genesis_set8 = "!"
	genesis_set9 = "!"
	genesis_set10 = "!"
	'''---------------------------'''

'''------------------------------
---os.path.join------------------
------------------------------'''
addonsDir = os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"))	
packagesDir = os.path.join(addonsDir,'packages')	
	
'''------------------------------
---DATES-----------------------
------------------------------'''
import datetime as dt
import time
#if startupW and systemplatformwindows: print printfirst + "import datetime as dt"

datenow = dt.date.today()
datenowS = str(datenow)
'''---------------------------'''
dateafter = datenow + dt.timedelta(days=7)
dateafterS = str(dateafter)
'''---------------------------'''
yearnow = datenow.strftime("%Y")
yearnowS = str(yearnow)
'''---------------------------'''
daynow = datenow.strftime("%a")
daynowS = str(daynow)
timenow = dt.datetime.now()
timenowS = str(timenow)
timenow2 = timenow.strftime("%H:%M")
timenow2S = str(timenow2)
timenow2N = int(timenow2S.replace(":","",1))
timenow3 = timenow.strftime("%H")
timenow3S = str(timenow3)
timenow3N = int(timenow3S)
timenow4 = timenow.strftime("%S")
timenow4S = str(timenow4)
'''---------------------------'''
if timenow3N > 03 and timenow3N < 12: timezone = "A"
elif timenow3N > 11 and timenow3N < 20: timezone = "B"
elif timenow3N > 19 or timenow3N < 04: timezone = "C"
else: timezone = ""
#if admin: print printfirst + datenowS + space + daynowS + space + timenow2S + space + "timezone: " + timezone
'''---------------------------'''
if (daynowS == "Sat" and timenow2N < 2000) or (daynowS == "Fri" and timenow2N > 1900): yomshabat = "true"
else: yomshabat = "false"
if admin: print printfirst + "DATES" + space + "yomshabat" + space2 + yomshabat + space + "timenow2N" + space2 + str(timenow2N)