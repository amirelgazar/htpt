import xbmc, xbmcgui, xbmcaddon
import subprocess, os, sys

from variables import *
from shared_modules import *
	
def setTime_Start(admin):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	Time_Start = getsetting('Time_Start')
	#timenow = datetime.datetime.now()
	#timenowS = timenow.strftime("%H:%M")
	'''---------------------------'''
	#setsettings('Time_Start', timenow2S)
	setsetting_custom1('service.htpt','Time_Start',timenow2S)
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	Time_Start2 = getsetting('Time_Start')
	print printfirst + "setTime_Start" + space2 + "Time_Start" + space2 + Time_Start + " - " + Time_Start2 + space3
	'''---------------------------'''

def checkRepos(admin):
	addon = 'repository.xbmc-israel'
	if not os.path.exists(addonsDir, addon):
		url = "https://github.com/cubicle-vdo/xbmc-israel/raw/master/repo/repository.xbmc-israel/repository.xbmc-israel-1.0.4.zip"
		download(url, packagesDir, dp = True)
		'''---------------------------'''
	
	#downloader_is('https://github.com/spoyser/spoyser-repo/blob/master/zips/repository.spoyser/repository.spoyser-1.0.6.zip?raw=true','supercartoons repository')
	#
		
def validationstartup(admin):
	validation = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION)')
	validation5 = xbmc.getInfoLabel('Skin.String(VALIDATION5)')
	count = 0
	if validation and validation5 != '0' and not xbmc.abortRequested:
		#if admin and count == 1: xbmc.executebuiltin('Notification(Admin,validationstartup)')
		startup_a = xbmc.getCondVisibility('Window.IsActive(Startup.xml)')
		skinsettings = xbmc.getCondVisibility('Window.IsVisible(SkinSettings.xml)')
		loginscreen = xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)')
		loginscreen_p = xbmc.getCondVisibility('Window.Previous(LoginScreen.xml)')
		validation = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION)')
		validation5 = xbmc.getInfoLabel('Skin.String(VALIDATION5)')
		playerhasmedia = xbmc.getInfoLabel('Player.HasMedia')
		htptlogo = xbmc.getInfoLabel('Player.Filename') == "playHTPT.mp4"
		if not startup_a and not loginscreen and not loginscreen_p and not skinsettings and not htptlogo: xbmc.executebuiltin('ReplaceWindow(Startup.xml)')
		if playerhasmedia and not htptlogo:
			xbmc.executebuiltin('Action(Close)')
			xbmc.executebuiltin('Notification(HTPT AUTHENTICATION FAILED!,FOR SUPPORT: [COLOR Yellow]infohtpt@gmail.com[/COLOR],10000,icons/sc2.png)')
			'''---------------------------'''

def videoplayertweak(admin,playerhasvideo):
	if playerhasvideo:
		#if admin: xbmc.executebuiltin('Notification(Admin,fix bug with subtitles (1),1000)')
		playerfolderpath = xbmc.getInfoLabel('Player.FolderPath')
		videoplayersubtitlesenabled = xbmc.getInfoLabel('VideoPlayer.SubtitlesEnabled')
		videoplayerhassubtitles = xbmc.getInfoLabel('VideoPlayer.HasSubtitles')
		'''fix bug with subtitles'''
		if videoplayerhassubtitles and videoplayersubtitlesenabled:
			fix = 'no'
			if '.sdarot.w' in playerfolderpath: fix = 'yes'
			elif xbmc.getCondVisibility('!VideoPlayer.Content(Movies)') and xbmc.getCondVisibility('!VideoPlayer.Content(Episodes)') and xbmc.getCondVisibility('IsEmpty(VideoPlayer.Year)') and xbmc.getCondVisibility('IsEmpty(VideoPlayer.Plot)') and xbmc.getCondVisibility('!SubString(Player.Title,S0)') and xbmc.getCondVisibility('!SubString(Player.Title,S1)') and xbmc.getCondVisibility('!SubString(VideoPlayer.Title,TNPB)') and xbmc.getCondVisibility('!SubString(VideoPlayer.Title,Staael)') and xbmc.getCondVisibility('!SubString(Player.Filename,YIFY)'): fix = 'yes'
			if fix == 'yes':
				if admin: xbmc.executebuiltin('Notification(Admin,fix bug with subtitles,1000)')
				xbmc.executebuiltin('Action(ShowSubtitles)')
				'''---------------------------'''
				
		'''video osd auto close'''
		videoosd = xbmc.getCondVisibility('Window.IsVisible(VideoOSD.xml)')
		systemidle10 = xbmc.getCondVisibility('System.IdleTime(10)')
		if videoosd and systemidle10:
			subtitleosdbutton = xbmc.getCondVisibility('Control.HasFocus(703)') #subtitleosdbutton
			volumeosdbutton = xbmc.getCondVisibility('Control.HasFocus(707)') #volumeosdbutton
			dialogpvrchannelsosd = xbmc.getCondVisibility('Window.IsVisible(DialogPVRChannelsOSD.xml)')
			'''---------------------------'''
			if (not subtitleosdbutton or not videoplayerhassubtitles) and not volumeosdbutton and not dialogpvrchannelsosd:
				if admin: xbmc.executebuiltin('Notification(Admin,videoosdauto,1000)')
				xbmc.executebuiltin('Dialog.Close(VideoOSD.xml)')
				'''---------------------------'''
			else:
				systemidle20 = xbmc.getCondVisibility('System.IdleTime(20)')
				if systemidle20: xbmc.executebuiltin('Dialog.Close(VideoOSD.xml)')
				'''---------------------------'''
	
def memkeyboard(admin):
	smartkeyboard = xbmc.getInfoLabel('Skin.HasSetting(smartkeyboard)')
	dialogkeyboard = xbmc.getCondVisibility('Window.IsVisible(DialogKeyboard.xml)')
	systemidle3 = xbmc.getCondVisibility('System.IdleTime(3)')
	count = 0
	while count < 400 and smartkeyboard and dialogkeyboard and not systemidle3:
		xbmc.sleep(100)
		count += 1
		dialogkeyboard = xbmc.getCondVisibility('Window.IsVisible(DialogKeyboard.xml)')
		systemidle3 = xbmc.getCondVisibility('System.IdleTime(3)')
		input = xbmc.getInfoLabel('Control.GetLabel(312)')
		smartkeyboardh0 = xbmc.getInfoLabel('Skin.String(smartkeyboardH0)')
		if input != smartkeyboardh0:
			xbmc.executebuiltin('Skin.SetString(smartkeyboardH0,'+ input +')')
			if admin: xbmc.executebuiltin('Notification(Admin memkeyboard,'+ input +',1000)')
		#xbmc.executebuiltin('Notification(Admin memkeyboard,'+ input +',1000)')
		
def connectioncheck(admin,count,systemidle3):
	'''------------------------------
	---NETWORK-STATUS----------------
	------------------------------'''
	printpoint = ""
	admin2 = xbmc.getInfoLabel('Skin.HasSetting(Admin2)')
	countS = str(count)
	mainwindow = xbmc.getCondVisibility('Window.IsVisible(mainWindow.xml)')
	connected = xbmc.getInfoLabel('Skin.HasSetting(Connected)')
	connected2 = xbmc.getInfoLabel('Skin.HasSetting(Connected2)')
	connected3 = xbmc.getInfoLabel('Skin.HasSetting(Connected3)')
	networkipaddress = xbmc.getInfoLabel('Network.IPAddress')
	netsettingsbutton = (xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(108)')) or xbmc.getCondVisibility('Container(52).HasFocus(40)') or (xbmc.getCondVisibility('Window.IsVisible(Custom1170.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(10)'))
	if count == 0: printpoint = printpoint + "0"
	
	#if not netsettingsbutton:
	printpoint = printpoint + "2"
	count10 = [10, 20, 30, 40, 50, 60]
	if (count in count10 or count == 0) or mainwindow or ((not connected and (connected2 or connected3)) or (connected and not connected2 and not connected3)):
		'''------------------------------
		---Connected2-(WLAN)-------------
		------------------------------'''
		if systemplatformwindows: output = cmd('netsh wlan show interfaces',"Connected2")
		else: output = bash('ifconfig wlan0',"Connected2")
		if (not systemplatformwindows and not "packets:0" in output and "inet addr" in output) or (systemplatformwindows and not "disconnected" in output and "connected" in output) and networkipaddress != "" and not "169.254." in networkipaddress:
			if not connected2: xbmc.executebuiltin('Skin.ToggleSetting(Connected2)')
			printpoint = printpoint + "1"
		else:
			if connected2: xbmc.executebuiltin('Skin.ToggleSetting(Connected2)')
			printpoint = printpoint + "2"
			'''---------------------------'''
			
		'''------------------------------
		---Connected3-(LAN)--------------
		------------------------------'''
		if systemplatformwindows: output = cmd('netsh lan show interfaces',"Connected3")
		else: output = bash('ifconfig eth0',"Connected3")
		if (not systemplatformwindows and not "packets:0" in output and "inet addr" in output) or (systemplatformwindows and "Enabled" in output and "Wired LAN" in output) and networkipaddress != "" and not "169.254." in networkipaddress:
			if not connected3: xbmc.executebuiltin('Skin.ToggleSetting(Connected3)')
			printpoint = printpoint + "3"
		else:
			if connected3: xbmc.executebuiltin('Skin.ToggleSetting(Connected3)')
			printpoint = printpoint + "4"
			'''---------------------------'''
			
	if (count > 1 or count == 0) and (connected2 or connected3):
		'''------------------------------
		---Connected-(INTERNET)----------
		------------------------------'''
		if connected and (count in count10):
			if systemplatformwindows: output = cmd('ping www.google.co.il -n 1',"Connected2")
			else: output = bash('ping -W 1 -w 1 -4 -q www.google.co.il',"Connected")
		else:
			if systemplatformwindows: output = cmd('ping 8.8.8.8 -n 1',"Connected2")
			else: output = bash('ping -W 1 -w 1 -4 -q 8.8.8.8',"Connected")
		if (not systemplatformwindows and ("1 packets received" in output or not "100% packet loss" in output)) or (systemplatformwindows and ("Received = 1" in output or not "100% loss" in output)):
			if not connected: xbmc.executebuiltin('Skin.ToggleSetting(Connected)')
			'''---------------------------'''
		else:
			if systemplatformwindows: output = cmd('ping 8.8.4.4 -n 1',"Connected2")
			else: output = bash('ping -W 1 -w 1 -4 -q 8.8.4.4',"Connected")
			printpoint = printpoint + "5"
			#if ("1 packets received" or not  "100% packet loss") in output:
			if (not systemplatformwindows and ("1 packets received" in output or not "100% packet loss" in output)) or (systemplatformwindows and ("Received = 1" in output or not "100% loss" in output)):
				printpoint = printpoint + "6"
				if not connected: xbmc.executebuiltin('Skin.ToggleSetting(Connected)')
			else:
				if admin and admin2: print printfirst + space + "disconnected!"
				if connected: xbmc.executebuiltin('Skin.ToggleSetting(Connected)')
				printpoint = printpoint + "8"
				'''---------------------------'''
				'''1 packets transmitted, 0 packets received, 100% packet loss'''
				'''1 packets transmitted, 1 packets received, 0% packet loss
				   round-trip min/avg/max = 70.325/70.325/70.325 ms'''
				'''---------------------------'''
			
		#if ("1 packets received" or not "100% packet loss") in output:
		if (not systemplatformwindows and ("1 packets received" in output or not "100% packet loss" in output)) or (systemplatformwindows and ("Received = 1" in output or not "100% loss" in output)):
			'''------------------------------
			---setPing-ms--------------------
			------------------------------'''
			output2 = output
			output2len = len(output2)
			output2lenS = str(output2len)
			
			if not systemplatformwindows: start_len = output2.find("min/avg/max =", 0, output2len)
			else: start_len = output2.find("Average =", 0, output2len)
			start_lenS = str(start_len)
			if not systemplatformwindows: start_lenN = int(start_lenS) + 14
			else: start_lenN = int(start_lenS) + 10
			if not systemplatformwindows: end_len = output2.find("/", start_lenN, output2len)
			else: end_len = output2.find("ms", start_lenN, output2len)
			end_lenS = str(end_len)
			end_lenN = int(end_lenS)
			found = output2[start_lenN:end_lenN]
			foundS = str(found)
			try: foundF = float(foundS)
			except: foundF = ""
			'''---------------------------'''
			if not systemplatformwindows:
				mid_len = output2.find(".", start_lenN, end_lenN)
				mid_lenS = str(mid_len)
				mid_lenN = int(mid_lenS)
				totalnumN = mid_lenN - start_lenN
				totalnumS = str(start_lenN)
				'''---------------------------'''
				if foundF != "":
					found2 = round(foundF)
					found2S = str(found2)
				else:
					found2S = foundS
				if ".0" in found2S: found2S = found2S.replace(".0","",1)
				'''---------------------------'''
			else:
				found2S = foundS
				mid_lenS = ""
				'''---------------------------'''
			if admin and admin2: print printfirst + space + "output2len" + space2 + output2lenS + space + "start_len" + space2 + start_lenS + space + "end_len" + space2 + end_lenS + space + "found/2" + space2 + foundS + "/" + found2S + space + "mid_len" + space2 + mid_lenS
			'''---------------------------'''
		else:
			found2S = "D/C"
			
		'''------------------------------
		---setPing-----------------------
		------------------------------'''
		A1  = [1 , 11, 21, 31, 41 , 51]
		A2  = [2 , 12, 22, 32, 42 , 52]
		A3  = [3 , 13, 23, 33, 43 , 53]
		A4  = [4 , 14, 24, 34, 44 , 54]
		A5  = [5 , 15, 25, 35, 45 , 55]
		A6  = [6 , 16, 26, 36, 46 , 56]
		A7  = [7 , 17, 27, 37, 47 , 57]
		A8  = [8 , 18, 28, 38, 48 , 58]
		A9  = [9 , 19, 29, 39, 49 , 59]
		A10 = [10, 20, 30, 40, 50 , 60]
		'''---------------------------'''
		setsetting('Ping_Now',found2S)
		setSkinSetting("0", 'Ping_Now', found2S)
		if   count in A1:  setsetting('Ping_1',  found2S)
		elif count in A2:  setsetting('Ping_2',  found2S)
		elif count in A3:  setsetting('Ping_3',  found2S)
		elif count in A4:  setsetting('Ping_4',  found2S)
		elif count in A5:  setsetting('Ping_5',  found2S)
		elif count in A6:  setsetting('Ping_6',  found2S)
		elif count in A7:  setsetting('Ping_7',  found2S)
		elif count in A8:  setsetting('Ping_8',  found2S)
		elif count in A9:  setsetting('Ping_9',  found2S)
		elif count in A10: setsetting('Ping_10', found2S)
		'''---------------------------'''
	#else:
		#if netsettingsbutton and admin: xbmc.executebuiltin('Notification(Admin,Connected2/3 pending...,1000)')
		#printpoint = printpoint + "9"
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if connected2 != "": connected2S = "true"
	else: connected2S = "false"
	if connected3 != "": connected3S = "true"
	else: connected3S = "false"
	if (admin and admin2) or count == 0: print printfirst + space + "connectioncheck_LV" + printpoint + space + "count" + space2 + countS + space + "connected2/3" + space2 + connected2S + "/" + connected3S
	'''---------------------------'''

def setPing_Rate(admin, admin2, Ping_Rate, Ping_1, Ping_2, Ping_3, Ping_4, Ping_5, Ping_6, Ping_7, Ping_8, Ping_9, Ping_10):
	'''------------------------------
	---1=LOW---5=HIGH----------------
	------------------------------'''
	try:
		Ping_1N  = int(Ping_1)
		Ping_2N  = int(Ping_2)
		Ping_3N  = int(Ping_3)
		Ping_4N  = int(Ping_4)
		Ping_5N  = int(Ping_5)
		Ping_6N  = int(Ping_6)
		Ping_7N  = int(Ping_7)
		Ping_8N  = int(Ping_8)
		Ping_9N  = int(Ping_9)
		Ping_10N = int(Ping_10)
		'''---------------------------'''
		pingtotalN = Ping_1N + Ping_2N + Ping_3N + Ping_4N + Ping_5N + Ping_6N + Ping_7N + Ping_8N + Ping_9N + Ping_10N
		pingtotalS = str(pingtotalN)
		pingtotal2N = pingtotalN / 10
		pingtotal2S = str(pingtotal2N)
		'''---------------------------'''
		pinglevel5 = 100
		pinglevel4 = 150
		pinglevel3 = 200
		pinglevel2 = 250
		pinglevel1 = 300
		'''---------------------------'''
		if pingtotal2N < pinglevel5: Ping_Rate2 = "5"
		elif pingtotal2N < pinglevel4: Ping_Rate2 = "4"
		elif pingtotal2N < pinglevel3: Ping_Rate2 = "3"
		elif pingtotal2N < pinglevel2: Ping_Rate2 = "2"
		else: Ping_Rate2 = "1"
		'''---------------------------'''
		#Ping_Rate2 = getsetting('Ping_Rate')
		setsetting('Ping_Rate',Ping_Rate2)
		setSkinSetting("0", 'Ping_Rate', Ping_Rate2)
		'''---------------------------'''
		
		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		if admin and admin2: print printfirst + space + "setPing_Rate" + space2 + "pingtotal/2" + space2 + pingtotalS + " / 10 = " + pingtotal2S + space + "Ping_Rate" + space2 + Ping_Rate + " - " + Ping_Rate2
		'''---------------------------'''
	except:
		setsetting('Ping_Rate',"1")
		setSkinSetting("0", 'Ping_Rate', "1")
		if admin: print printfirst + space + "setPing_Rate" + space2 + "Ping_Rate" + space2 + "1"
		'''---------------------------'''

def setGeneral_Timer(admin, General_Timer, count):		
	General_Timer2 = calculate('service.htpt','General_Timer','1',General_Timer)
	General_Timer2 = int(General_Timer2)
	if General_Timer2 >= 60: General_Timer2 = 1
	General_Timer2S = str(General_Timer2)
	#setsetting_custom1('service.htpt','General_Timer',General_Timer2S)
	setsetting('General_Timer', General_Timer2S)
	if admin and admin2: print printfirst + space + "General_Timer" + space2 + countS
	'''---------------------------'''

def SetTime_Pass(admin, admin2, Time_Pass):
	Time_Pass2 = calculate('service.htpt','Time_Pass','1',Time_Pass)
	setsetting('Time_Pass',Time_Pass2)
	#setsetting_custom1('service.htpt','Time_Pass',Time_Pass2)
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin and admin2: print printfirst + "setTime_Pass" + space2 + "Time_Pass" + space2 + Time_Pass + " - " + Time_Pass2
	'''---------------------------'''

def SetSkin_UpdateTimer(admin, admin2, Skin_UpdateTimer):
	'''------------------------------
	---Skin_UpdateTimer--------------
	------------------------------'''
	Skin_UpdateTimer2 = calculate('service.htpt','Skin_UpdateTimer','2',Skin_UpdateTimer)
	setsetting('Skin_UpdateTimer',Skin_UpdateTimer2)
	#setsetting_custom1('service.htpt','Skin_UpdateTimer',Skin_UpdateTimer2)
	'''---------------------------'''
	if Skin_UpdateTimer == "119": notification(addonString(12).encode('utf-8') + ".", addonString(9).encode('utf-8'),"",1000)
	elif Skin_UpdateTimer == "118": notification(addonString(12).encode('utf-8') + "..", addonString(9).encode('utf-8'),"",1000)
	elif Skin_UpdateTimer == "117": notification(addonString(12).encode('utf-8') + "...", addonString(9).encode('utf-8'),"",1000)
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin and admin2: print printfirst + "Skin_UpdateTimer" + space2 + Skin_UpdateTimer + " - " + Skin_UpdateTimer2
	'''---------------------------'''
	
def setSkin_UpdateCount2(admin, Skin_UpdateCount, Time_Pass):
	'''------------------------------
	---Skin_UpdateCount2-+1----------
	------------------------------'''
	Skin_UpdateCount2 = Skin_UpdateCount
	TimeSequenceN = [0, 60, 120, 180, 240, 300, 360, 420, 480, 540, 600, 660, 720, 780, 840, 900, 960, 1020]
	Time_PassN = int(Time_Pass)
	if Time_PassN in TimeSequenceN:
		Skin_UpdateCount2 = calculate('service.htpt','Skin_UpdateCount','1',Skin_UpdateCount)
		setsetting('Skin_UpdateCount2', Skin_UpdateCount2)
		#setsetting_custom1('service.htpt','Skin_UpdateCount2',Skin_UpdateCount2)
		'''---------------------------'''	
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if Skin_UpdateCount2 != Skin_UpdateCount: print printfirst + "setSkin_UpdateCount2" + space2 + "Time_Pass" + space2 + Time_Pass + space + "Skin_UpdateCount" + space2 + Skin_UpdateCount + " - " + Skin_UpdateCount2
	'''---------------------------'''	
	return Skin_UpdateCount2
	
def UpdateAddons(admin, Skin_UpdateCount, Skin_UpdateCount2):
	'''------------------------------
	---UPDATE-REPO+ADDONS------------
	------------------------------'''
	xbmc.executebuiltin('UpdateAddonRepos')
	xbmc.executebuiltin('UpdateLocalAddons')
	'''---------------------------'''
	setsetting('Skin_UpdateTimer',"120")
	'''---------------------------'''
	
	'''------------------------------
	---Skin_UpdateCount-+1-----------
	------------------------------'''
	setsetting('Skin_UpdateCount',Skin_UpdateCount2)
	'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + space + "UpdateAddons" + space + "Skin_UpdateCount/2" + space2 + Skin_UpdateCount + " - " + Skin_UpdateCount2
	'''---------------------------'''

def setSkin_Update(admin, Skin_Version, htptskinversion, Skin_Update):
	'''------------------------------
	---CHECK-FOR-SKIN-UPDATE---------
	------------------------------'''
	#admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	#htptskinversion = xbmc.getInfoLabel('System.AddonVersion(skin.htpt)')
	#Skin_Version = getsetting('Skin_Version')
	#Skin_Update = getsetting('Skin_Update')
	
	#if not systemplatformwindows: log = open('/storage/.kodi/temp/kodi.log', 'r')
	#elif systemplatformwindows: log = open('Z:\kodi.log', 'r')
	#file = log.read()
	#log.close()
	#count = 0
	#while count < 10 and not "FileManager: copy https://raw.githubusercontent.com/htpthtpt/htpt/master/skin.htpt/skin.htpt" in file and not xbmc.abortRequested:
		#xbmc.sleep(1000)
		#validationstartup('run')
		#count += 1
		#countS = str(count)
		#if admin: xbmc.executebuiltin('Notification(Admin,UpdateSkin ('+ countS +'),1000)')
		#if not systemplatformwindows: log = open('/storage/.kodi/temp/kodi.log', 'r')
		#elif systemplatformwindows: log = open('Z:\kodi.log', 'r')
		#file = log.read()
	#log.close()
	#count = 0
	#while count < 10 and "FileManager: copy https://raw.githubusercontent.com/htpthtpt/htpt/master/skin.htpt/skin.htpt" in file and not xbmc.abortRequested:
		#xbmc.sleep(1000)
		#count += 1
		#if count == 1:
			#xbmc.executebuiltin('Notification($LOCALIZE[79200] '+ htptskinversion +'),$LOCALIZE[31407],7000)')
			#heading = xbmc.getInfoLabel('$LOCALIZE[79200]') + ' ' + htptskinversion
			#dialogok(heading, '$LOCALIZE[31407]', "", "")
		#if Skin_Update != "true": setsetting_custom1('service.htpt','Skin_Update',"true")
		#if count == 10: xbmc.executebuiltin('dialog.close(okdialog)')
			
	if Skin_Version != htptskinversion and Skin_Update == "false":
		Skin_Update2 = "true"
		setsetting('Skin_UpdateLog',"true")
	else:
		Skin_Update2 = "false"
		
	if Skin_Update != Skin_Update2: setsetting('Skin_Update',Skin_Update2)
	'''---------------------------'''
	#if "FileManager: copy http://raw.github.com/lambda81/lambda-repo/master/plugin.video.genesis/" in file:
		#xbmc.executebuiltin('Notification($LOCALIZE[75000],$LOCALIZE[31407],2000)')
		#xbmc.sleep(1000)
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin and Skin_Update != Skin_Update2: print printfirst + "setSkin_Update" + space2 + "Skin_Update" + space2 + Skin_Update + " - " + Skin_Update2
	'''---------------------------'''
	
def setSkin_UpdateDate(admin, Skin_Version, htptskinversion, Skin_Update, Skin_UpdateDate):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	from variables import datenowS
	'''---------------------------'''
	#setsetting_custom1('service.htpt','Skin_UpdateDate',datenowS)
	if Skin_UpdateDate != datenowS:
		setsetting('Skin_UpdateDate',datenowS)
	#dateleft = stringtodate(skinsetting3,'%Y-%m-%d')
	#dateleft2 = str(dateleft)
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "setSkin_UpdateDate" + space2 + "Skin_UpdateDate" + space2 + Skin_UpdateDate + " - " + datenowS
	'''---------------------------'''
	
def setSkin_Version(admin, Skin_Version, htptskinversion):
	'''------------------------------
	---CHECK-FOR-SKIN-UPDATE-2-------
	------------------------------'''
	if Skin_Version != htptskinversion:
		setsetting('Skin_Version',htptskinversion)
		'''---------------------------'''	
		
		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		print printfirst + "setSkin_Version" + space2 + "Skin_Version" + space2 + Skin_Version + " - " + htptskinversion
		'''---------------------------'''	

def setSkin_UpdateLog(admin, Skin_Version, Skin_UpdateDate, datenowS):	
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	printpoint = ""
	number2S = ""
	datenowD = stringtodate(datenowS,'%Y-%m-%d')
	datedifferenceD = stringtodate(Skin_UpdateDate,'%Y-%m-%d')
	datedifferenceS = str(datedifferenceD)
	if "error" in [datenowD, datedifferenceD]: printpoint = printpoint + "9"
	try:
		number2 = datenowD - datedifferenceD
		number2S = str(number2)
		printpoint = printpoint + "2"
		'''---------------------------'''
	except:
		printpoint = printpoint + "9"
		'''---------------------------'''
	if not "9" in printpoint:
		printpoint = printpoint + "4"
		if "day," in number2S: number2S = number2S.replace(" day, 0:00:00","",1)
		elif "days," in number2S: number2S = number2S.replace(" days, 0:00:00","",1)
		else: number2S = "0"
		if admin: notification("number2S:" + number2S,"","",2000)
		number2N = int(number2S)
		'''---------------------------'''
		if number2N == 0: header = '[COLOR=Yellow]' + str79201 + space + str72101 + " - " + Skin_Version + '[/COLOR]'
		elif number2N == 1: header = '[COLOR=Green]' + str79201 + space + str72102 + " - " + Skin_Version + '[/COLOR]'
		elif number2N <= 7: header = '[COLOR=Purple]' + str79201 + space + str72103 + " - " + Skin_Version + '[/COLOR]'
		else: header = ""
		'''---------------------------'''
		if not systemplatformwindows: log = open('/storage/.kodi/addons/skin.htpt/changelog.txt', 'r')
		elif systemplatformwindows: log = open('Z:\\addons\\skin.htpt\\changelog.txt', 'r')
		message2 = log.read()
		log.close()
		message2S = str(message2)
		message3 = message2[70:8000]
		message3 = '"' + message3 + '"'
		message3S = str(message3)
		if header != "":
			w = TextViewer_Dialog('DialogTextViewer.xml', "", header=header, text=message2)
			w.doModal()
			
		setSkinSetting("0", 'MessagesChangeLog', message3S)
		#xbmc.executebuiltin('Skin.SetString(MessagesChangeLog,'+ message3S +')')
		'''---------------------------'''
		setsetting('Skin_UpdateLog',"false")
		#setsetting_custom1('service.htpt','Skin_UpdateLog',"false")
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "setSkin_UpdateLog_LV" + printpoint + space2 + "Skin_UpdateDate" + space2 + Skin_UpdateDate + " - " + datenowS + space + "(" + number2S + ")" + space + "Skin_UpdateLog" + space2 + Skin_UpdateLog
	'''---------------------------'''
