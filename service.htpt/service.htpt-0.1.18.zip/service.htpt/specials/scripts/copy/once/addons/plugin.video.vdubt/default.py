import urllib , urllib2 , sys , re , xbmcplugin , xbmcgui , xbmcaddon , xbmc , os , base64
if 64 - 64: i11iIiiIii
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
I1IiI = xbmcaddon . Addon ( id = 'plugin.video.vdubt' )
if 73 - 73: OOooOOo / ii11ii1ii
O00ooOO = ''
def I1iII1iiII ( i , t1 , t2 = [ ] ) :
 iI1Ii11111iIi = O00ooOO
 for i1i1II in t1 :
  iI1Ii11111iIi += chr ( i1i1II )
  i += 1
  if i > 1 :
   iI1Ii11111iIi = iI1Ii11111iIi [ : - 1 ]
   i = 0
 for i1i1II in t2 :
  iI1Ii11111iIi += chr ( i1i1II )
  i += 1
  if i > 1 :
   iI1Ii11111iIi = iI1Ii11111iIi [ : - 1 ]
   i = 0
 return iI1Ii11111iIi
 if 96 - 96: o0OO0 - Oo0ooO0oo0oO . I1i1iI1i - o00ooo0 / o00 * Oo0oO0ooo
 if 56 - 56: o0OO0 - i1IIi
 if 64 - 64: o00 + I1i1iI1i
def ii1Ii ( ) :
 if 75 - 75: i11iIiiIii + o00ooo0 . o0oOOo0O0Ooo * I1i1iI1i
 oo0 = base64 . b64decode ( Oooo00OOo000 ( I1iII1iiII ( 256 , [ 225 , 104 , 168 , 116 , 111 , 116 , 197 , 112 ] , [ 155 , 58 , 16 , 47 , 212 , 47 , 94 , 112 , 181 , 97 , 220 , 115 , 220 , 116 , 43 , 101 , 102 , 98 , 216 , 105 , 44 , 110 , 178 , 46 , 240 , 99 , 186 , 111 , 141 , 109 , 120 , 47 , 212 , 114 , 34 , 97 , 196 , 119 , 172 , 46 , 18 , 112 , 64 , 104 , 167 , 112 , 70 , 63 , 89 , 105 , 164 , 61 , 74 , 68 , 184 , 49 , 56 , 109 , 121 , 67 , 67 , 52 , 250 , 70 , 24 , 98 , 103 , 53 ] ) ) )
 if 82 - 82: o0OO0 . o00 / o00ooo0 % II111iiii % iIii1I11I1II1 % o00ooo0
 oOo0oooo00o = re . compile ( I1iII1iiII ( 873 , [ 100 , 71 , 5 , 69 , 173 , 78 ] , [ 95 , 82 , 69 , 69 , 77 , 44 , 168 , 32 , 166 , 40 , 156 , 46 , 139 , 43 , 190 , 63 , 24 , 41 , 106 , 10 ] ) ) . findall ( base64 . b64decode ( oo0 ) )
 if 65 - 65: o0oOOo0O0Ooo * iIii1I11I1II1 * Oo0oO0ooo
 for IiI1i in oOo0oooo00o :
  if 61 - 61: I1ii11iIi11i + o0OO0 / o00 . o0oOOo0O0Ooo
  OOoOoo00oo ( IiI1i . strip ( ) , IiI1i , 1 , '' , '' )
  if 41 - 41: iIii1I11I1II1 / o00 + ii11ii1ii
 OOooO ( 'movies' , 'default' )
 if 58 - 58: OoO0O00 + OoOoOO00 / Oo0ooO0oo0oO * OoooooooOO
 if 9 - 9: I1IiiI - Oo0ooO0oo0oO % i1IIi % OoooooooOO
 if 3 - 3: I1i1iI1i + O0
def I1Ii ( url ) :
 if 66 - 66: Oo0ooO0oo0oO
 if 78 - 78: OoO0O00
 oo0 = base64 . b64decode ( Oooo00OOo000 ( I1iII1iiII ( 256 , [ 225 , 104 , 168 , 116 , 111 , 116 , 197 , 112 ] , [ 155 , 58 , 16 , 47 , 212 , 47 , 94 , 112 , 181 , 97 , 220 , 115 , 220 , 116 , 43 , 101 , 102 , 98 , 216 , 105 , 44 , 110 , 178 , 46 , 240 , 99 , 186 , 111 , 141 , 109 , 120 , 47 , 212 , 114 , 34 , 97 , 196 , 119 , 172 , 46 , 18 , 112 , 64 , 104 , 167 , 112 , 70 , 63 , 89 , 105 , 164 , 61 , 74 , 68 , 184 , 49 , 56 , 109 , 121 , 67 , 67 , 52 , 250 , 70 , 24 , 98 , 103 , 53 ] ) ) )
 oo0 = base64 . b64decode ( oo0 )
 Iii1I111 = oo0 . split ( url ) [ 1 ]
 if 60 - 60: OOooOOo * o0oOOo0O0Ooo % o0oOOo0O0Ooo % o0OO0 * II111iiii + i1IIi
 OOoooooO = Iii1I111 . split ( '@@@@@' ) [ 0 ]
 oOo0oooo00o = re . compile ( I1iII1iiII ( 368 , [ 159 , 35 , 86 , 40 ] , [ 214 , 46 , 169 , 43 , 99 , 63 , 45 , 41 , 5 , 44 , 104 , 40 , 135 , 46 , 173 , 43 , 52 , 63 , 96 , 41 , 173 , 10 , 19 , 40 , 98 , 46 , 202 , 43 , 93 , 63 , 107 , 41 , 84 , 10 ] ) ) . findall ( OOoooooO )
 if 14 - 14: o0OO0 % O0
 for IiI1I1 , IiI1i , url in oOo0oooo00o :
  if 'tvg-logo=' in IiI1I1 :
   OoO000 = I1iII1iiII ( 0 , [ 104 , 207 , 116 , 41 , 116 , 15 , 112 , 102 , 58 , 79 , 47 , 17 , 47 , 184 , 118 , 41 , 100 , 197 , 117 , 28 , 98 , 218 , 116 ] , [ 79 , 50 , 133 , 53 , 140 , 46 , 98 , 120 , 195 , 49 , 216 , 48 , 239 , 104 , 244 , 111 , 123 , 115 , 66 , 116 , 186 , 46 , 76 , 99 , 33 , 111 , 181 , 109 , 31 , 47 , 154 , 76 , 126 , 103 , 115 , 47 ] ) + re . compile ( 'tvg-logo="(.+?)"' ) . findall ( IiI1I1 ) [ 0 ]
   if 42 - 42: OOooOOo - i1IIi / i11iIiiIii + ii11ii1ii + OoO0O00
  else :
   OoO000 = ''
   if 17 - 17: OOooOOo . Oo0Ooo . I1ii11iIi11i
  if I1IiI . getSetting ( 'parental' ) == 'true' :
   if not '18' in IiI1i :
    OOoOoo00oo ( IiI1i . strip ( ) , url , 200 , OoO000 , '' )
  else :
   OOoOoo00oo ( IiI1i . strip ( ) , url , 200 , OoO000 , '' )
   if 3 - 3: OoOoOO00 . Oo0Ooo . I1IiiI / Oo0ooO0oo0oO
   if 38 - 38: II111iiii % i11iIiiIii . Oo0oO0ooo - ii11ii1ii + Oo0ooO0oo0oO
 OOooO ( 'movies' , 'default' )
 if 66 - 66: OoooooooOO * OoooooooOO . ii11ii1ii . i1IIi - ii11ii1ii
 if 77 - 77: o0OO0 - iIii1I11I1II1
 if 82 - 82: i11iIiiIii . ii11ii1ii / Oo0Ooo * O0 % OOooOOo % iIii1I11I1II1
 if 78 - 78: iIii1I11I1II1 - Oo0ooO0oo0oO * OoO0O00 + o0oOOo0O0Ooo + I1i1iI1i + I1i1iI1i
 if 11 - 11: I1i1iI1i - OoO0O00 % Oo0oO0ooo % I1i1iI1i / OoOoOO00 - OoO0O00
def Oooo00OOo000 ( url ) :
 o0o0oOOOo0oo = urllib2 . Request ( url )
 o0o0oOOOo0oo . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 oo0 = urllib2 . urlopen ( o0o0oOOOo0oo )
 Iii1I111 = oo0 . read ( )
 oo0 . close ( )
 return Iii1I111
 if 80 - 80: o0OO0 * i11iIiiIii / o00
 if 9 - 9: Oo0ooO0oo0oO + OOooOOo % Oo0ooO0oo0oO + i1IIi . ii11ii1ii
 if 31 - 31: o0oOOo0O0Ooo + o0OO0 + o0OO0 / II111iiii
def iiI1 ( name , url , iconimage ) :
 if 19 - 19: o0OO0 + Oo0oO0ooo
 ooo = xbmcgui . ListItem ( name , iconImage = 'DefaultVideo.png' , thumbnailImage = iconimage )
 ooo . setInfo ( type = 'Video' , infoLabels = { 'Title' : name } )
 ooo . setProperty ( "IsPlayable" , "true" )
 ooo . setPath ( url )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooo )
 if 18 - 18: o0oOOo0O0Ooo
 if 28 - 28: ii11ii1ii - o00ooo0 . o00ooo0 + OoOoOO00 - OoooooooOO + O0
 if 95 - 95: OoO0O00 % OOooOOo . O0
 if 15 - 15: Oo0oO0ooo / Oo0ooO0oo0oO . Oo0ooO0oo0oO - i1IIi
def o00oOO0 ( ) :
 oOoo = [ ]
 iIii11I = sys . argv [ 2 ]
 if len ( iIii11I ) >= 2 :
  OOO0OOO00oo = sys . argv [ 2 ]
  Iii111II = OOO0OOO00oo . replace ( '?' , '' )
  if ( OOO0OOO00oo [ len ( OOO0OOO00oo ) - 1 ] == '/' ) :
   OOO0OOO00oo = OOO0OOO00oo [ 0 : len ( OOO0OOO00oo ) - 2 ]
  iiii11I = Iii111II . split ( '&' )
  oOoo = { }
  for Ooo0OO0oOO in range ( len ( iiii11I ) ) :
   ii11i1 = { }
   ii11i1 = iiii11I [ Ooo0OO0oOO ] . split ( '=' )
   if ( len ( ii11i1 ) ) == 2 :
    oOoo [ ii11i1 [ 0 ] ] = ii11i1 [ 1 ]
    if 29 - 29: I1ii11iIi11i % I1IiiI + Oo0oO0ooo / o0oOOo0O0Ooo + ii11ii1ii * o0oOOo0O0Ooo
 return oOoo
 if 42 - 42: Oo0ooO0oo0oO + OOooOOo
def OOoOoo00oo ( name , url , mode , iconimage , description ) :
 o0O0o0Oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&description=" + urllib . quote_plus ( description )
 Ii11Ii1I = True
 ooo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 ooo . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 O00oO = [ ]
 if mode == 200 :
  ooo . setProperty ( "IsPlayable" , "true" )
  if 39 - 39: o00ooo0 - II111iiii * OoO0O00 % o0oOOo0O0Ooo * II111iiii % II111iiii
  Ii11Ii1I = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = o0O0o0Oo , listitem = ooo , isFolder = False )
 else :
  if 59 - 59: iIii1I11I1II1 + I1IiiI - o0oOOo0O0Ooo - I1IiiI + ii11ii1ii / I1ii11iIi11i
  xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = o0O0o0Oo , listitem = ooo , isFolder = True )
 return Ii11Ii1I
 if 24 - 24: o0OO0 . I1i1iI1i % ii11ii1ii + Oo0oO0ooo % OoOoOO00
 if 4 - 4: o00ooo0 - OoO0O00 * OoOoOO00 - o0OO0
 if 41 - 41: OoOoOO00 . I1IiiI * OOooOOo % o00ooo0
 if 86 - 86: I1IiiI + Oo0ooO0oo0oO % i11iIiiIii * OOooOOo . Oo0oO0ooo * o0OO0
def OOooO ( content , viewType ) :
 if content :
  xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , content )
 if I1IiI . getSetting ( 'auto-view' ) == 'true' :
  xbmc . executebuiltin ( "Container.SetViewMode(%s)" % I1IiI . getSetting ( viewType ) )
  if 44 - 44: OOooOOo
  if 88 - 88: o00 % Oo0ooO0oo0oO . II111iiii
OOO0OOO00oo = o00oOO0 ( )
iI1ii1Ii = None
IiI1i = None
oooo000 = None
OoO000 = None
iIIIi1 = None
if 20 - 20: i1IIi + I1ii11iIi11i - Oo0oO0ooo
if 30 - 30: II111iiii - ii11ii1ii - i11iIiiIii % OoOoOO00 - II111iiii * Oo0ooO0oo0oO
try :
 iI1ii1Ii = urllib . unquote_plus ( OOO0OOO00oo [ "url" ] )
except :
 pass
try :
 IiI1i = urllib . unquote_plus ( OOO0OOO00oo [ "name" ] )
except :
 pass
try :
 OoO000 = urllib . unquote_plus ( OOO0OOO00oo [ "iconimage" ] )
except :
 pass
try :
 oooo000 = int ( OOO0OOO00oo [ "mode" ] )
except :
 pass
try :
 iIIIi1 = urllib . unquote_plus ( OOO0OOO00oo [ "description" ] )
except :
 pass
 if 61 - 61: OOooOOo - o0OO0 % ii11ii1ii
print "Mode: " + str ( oooo000 )
print "URL: " + str ( iI1ii1Ii )
print "Name: " + str ( IiI1i )
print "IconImage: " + str ( OoO000 )
if 84 - 84: OOooOOo * OoO0O00 / o0OO0 - O0
if 30 - 30: iIii1I11I1II1 / Oo0oO0ooo - o00 - II111iiii % I1i1iI1i
if 49 - 49: I1IiiI % Oo0oO0ooo . Oo0oO0ooo . o0OO0 * Oo0oO0ooo
if oooo000 == None or iI1ii1Ii == None or len ( iI1ii1Ii ) < 1 :
 print ""
 ii1Ii ( )
 if 97 - 97: Oo0ooO0oo0oO + o0oOOo0O0Ooo . ii11ii1ii + I1ii11iIi11i % I1i1iI1i
elif oooo000 == 1 :
 print "" + iI1ii1Ii
 I1Ii ( iI1ii1Ii )
 if 95 - 95: i1IIi
elif oooo000 == 200 :
 if 3 - 3: o00 - O0 / o00 % OoO0O00 / o00 . I1IiiI
 iiI1 ( IiI1i , iI1ii1Ii , OoO000 )
 if 50 - 50: o00ooo0
elif oooo000 == 2001 :
 if 14 - 14: o0OO0 % OoO0O00 * o0OO0
 playall ( IiI1i , iI1ii1Ii )
 if 16 - 16: OoOoOO00 . Oo0oO0ooo + i11iIiiIii
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
