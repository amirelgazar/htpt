import xbmc, xbmcgui, xbmcaddon
import xbmcplugin
import os, subprocess, sys
from variables import *
#from shared_variables import *
#from shared_modules import *
'''unused'''

#https://gdata.youtube.com/feeds/api/videos/dzbN8WG33Sg/related?v=2

def getsetting_custom1(addon,set1):
	'''------------------------------
	---GET-ADDON-SETTING-1-----------
	------------------------------'''
	getsetting_custom          = xbmcaddon.Addon(addon).getSetting
	'''---------------------------'''
	returned = getsetting_custom(set1,set1v)
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "getsetting_custom1" + space2 + addon + space + set1
	'''---------------------------'''
	return returned
	'''---------------------------'''
	
def dialogprogress(id, progress, heading, line1, line2, line3): 
	'''------------------------------
	---DIALOG-OK-***BROKEN***--------
	------------------------------'''
	#try: progressN = int(progress)
	#except Exception, TypeError: progressN = 0
	'''---------------------------'''
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	if '$LOCALIZE' in line1 or '$ADDON' in line1: line1 = xbmc.getInfoLabel(line1)
	if '$LOCALIZE' in line2 or '$ADDON' in line2: line2 = xbmc.getInfoLabel(line2)
	if '$LOCALIZE' in line3 or '$ADDON' in line3: line3 = xbmc.getInfoLabel(line3)
	heading = str(heading.encode('utf-8'))
	line1 = str(line1.encode('utf-8'))
	line2 = str(line2.encode('utf-8'))
	line3 = str(line3.encode('utf-8'))
	
	#notification(str(progress),"","",2000)
	dp = xbmcgui.DialogProgress()
					
	if progress == 0:
		#pDialog.close
		dp.create(heading,line1,line2,line3)
	elif progress == 10: dp.close
	elif progress > 0: dp.update(progressN,line1,line2,line3)
	
	#pDialog = xbmcgui.DialogProgressBG()
	#pDialog.create(heading, line1)
	
	#def dialogprogress(admin, id, action, name, header, line1, line2):
	#id = xbmcgui.DialogProgress( )
	#if action == 0: returned = id.create(name, header, line1, line2)
	#else: returned = ""
	#return returned
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin:
		print printfirst + "dialogprogress" + space2 + heading + space2 + line1 + space2 + line2 + space2 + line3
		try:
			print printfirst + "TypeError" + space2 + str(TypeError)
			'''---------------------------'''
		except:
			pass
			'''---------------------------'''
	return dp
	
def UserBlock(custom):
	
	if custom == "ON": bash('pgrep kodi.bin | xargs kill -SIGSTOP',"UserBlock-ON")
	else: bash('pgrep kodi.bin | xargs kill -SIGCONT',"UserBlock-OFF")
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if custom != "ON": custom = "OFF"
	print printfirst + space + "UserBlock=" + custom
	'''---------------------------'''
	
def copy_rename(old_file_name, new_file_name):
	import shutil
	src_dir= os.curdir
	dst_dir= os.path.join(os.curdir , "/storage/")
	src_file = os.path.join(src_dir, old_file_name)
	shutil.copy(src_file,dst_dir)
	
	dst_file = os.path.join(dst_dir, old_file_name)
	new_dst_file_name = os.path.join(dst_dir, new_file_name)
	os.rename(dst_file, new_dst_file_name)
	
def stringtotime(dt_str, dt_func):
	from datetime import datetime
	import time
	#dt_str = '9/24/2010 5:03:29 PM'
	#dt_func = '%m/%d/%Y %I:%M:%S %p'
	#try:
	dt_obj = datetime.strptime(dt_str, dt_func)
	dt_objS = str(dt_obj)
	if dt_func == '%H':
		#time.struct_time(tm_year=1900, tm_mon=1, tm_mday=1, tm_hour=20, tm_min=0, tm_sec=0, tm_wday=0, tm_yday=1, tm_isdst=-1)
		find = dt_str
		found = find_string(dt_objS, find, "")
		'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "stringtotime" + space + "dt_objS" + space2 + dt_objS + space + "timenow3S" + space2 + timenow3S
	'''---------------------------'''
	
	return dt_obj
	
def General_CleanCache():
    dir=xbmc.translatePath('special://temp/')
    file=os.path.join(dir, 'commoncache.db')
    f = open(file, 'w')
    f.write('')
    f.close
    dialogok('[COLOR=Yellow]' + addonString(307).encode('utf-8') + addonString(308).encode('utf-8') + '[/COLOR]',"","","")
    '''---------------------------'''
	
def mes():

        
	try:
		link=OPEN_URL('http://goo.gl/r6eog7')
		r = re.findall(r'ANNOUNCEMENTWINDOW ="ON"',link)
		if not r:
			return
			
		match=re.compile('<new>(.*?)\\n</new>',re.I+re.M+re.U+re.S).findall(link)
		if not match[0]:
			return
			
		dire=os.path.join(xbmc.translatePath( "special://userdata/addon_data" ).decode("utf-8"), addonID)
		if not os.path.exists(dire):
			'''------------------------------
			---CREATE-USERDATA-DIRECTORY-----
			------------------------------'''
			os.makedirs(dire)
			'''---------------------------'''
		aSeenFile = os.path.join(dire, 'announcementSeen.txt')
		if (os.path.isfile(aSeenFile)): 
			f = open(aSeenFile, 'r') 
			content = f.read() 
			f.close() 
			if content == match[0] :
				return

		f = open(aSeenFile, 'w') 
		f.write(match[0]) 
		f.close() 

		dp = xbmcgui . Dialog ( )
		dp.ok("UPDATES", match[0])
	except:
		pass


def _____NONE(admin):
	'''------------------------------
	---MAC1/2------------------------
	------------------------------'''
	MAC1 = bash("ifconfig -a | grep -e 'eth' | awk {'print $1,$5'}","LAN MAC")
	MAC2 = bash("ifconfig -a | grep -e 'wlan' | awk {'print $1,$5'}","WLAN MAC")
	bash('ifconfig eth0 up',"eth0 up")

def addonsettings(name, addon,skinsettingS, skinsetting2S, usernameS, passwordS, set3,opt1,opt2,opt3):
	'''------------------------------
	---SET-USERNAME-AND-PASSWORD-----
	------------------------------'''
	getsetting_custom          = xbmcaddon.Addon(addon).getSetting
	setsetting_custom          = xbmcaddon.Addon(addon).setSetting
	
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	skinsetting = xbmc.getInfoLabel('Skin.HasSetting('+ skinsettingS +')')
	skinsetting2 = xbmc.getInfoLabel('Skin.String('+ skinsetting2S +')')
	#if setting_custom == str20122.encode('utf-8'): setting_custom = "true"
	#else: setting_custom = "false"
	try: skinsetting2N = int(skinsetting2)
	except: skinsetting2N = 0
	username = getsetting_custom(usernameS)
	password = getsetting_custom(passwordS)
	setting3 = getsetting_custom(set3)
	printpoint = ""
	'''---------------------------'''
	if not id40str:
		if (skinsetting or id9str == 'Trial' or id2str == datenowS) and usernameS != "" and passwordS != "":
			if admin: notification("test0","","",1000)
			if ('htpt' in username and not "finalmakerr" in idstr) and idstr != username and id9str != 'Trial' and id2str != datenowS:
				'''------------------------------
				---SET-DEFAULT-------------------
				------------------------------'''
				setsetting_custom(usernameS,idstr)
				setsetting_custom(passwordS,idpstr)
				printpoint = printpoint + "1"
				if admin: notification("test1","","",1000)
				'''---------------------------'''
			elif id9str == 'Trial' or id2str == datenowS:
				'''------------------------------
				---SET-TRIAL---------------------
				------------------------------'''
				setsetting_custom(usernameS,idtrial)
				setsetting_custom(passwordS,idp2str)
				printpoint = printpoint + "2"
				if admin: notification("test2","","",1000)
				'''---------------------------'''
			elif skinsetting and ((username == "" or password == "") or skinsetting2 == "0"):
				'''------------------------------
				---SET-NONE----------------------
				------------------------------'''
				setsetting_custom(usernameS,"")
				setsetting_custom(passwordS,"")
				printpoint = printpoint + "5"
				if admin: notification("test1.2","","",1000)
				'''---------------------------'''
			elif skinsetting:
				'''------------------------------
				---NO-CHANGES--------------------
				------------------------------'''
				printpoint = printpoint + "6"
				if admin: notification("test1.3","","",1000)
				'''---------------------------'''
		else:
			'''------------------------------
			---NO-ACCOUNT-OR-TRIAL-----------
			------------------------------'''
			daynowS = get_daynow(1)
			timezone = get_timenow(1)
			General_TimeZone = getsetting('General_TimeZone')
			if name == 'REALDEBRID' and (daynowS == opt1 or General_TimeZone != opt2):
				'''------------------------------
				---SET-NONE----------------------
				------------------------------'''
				setsetting_custom(usernameS,"")
				setsetting_custom(passwordS,"")
				printpoint = printpoint + "3"
				'''---------------------------'''
			else:
				'''------------------------------
				---SET-DEFAULT-------------------
				------------------------------'''
				setsetting_custom(usernameS,idstr)
				setsetting_custom(passwordS,idpstr)
				printpoint = printpoint + "4"
				'''---------------------------'''
				
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if printpoint == "0": print printfirst + "addonsettings LV_0" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "?"
	if printpoint == "1": print printfirst + "addonsettings LV_1" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "RESET"
	elif printpoint == "2": print printfirst + "addonsettings LV_2" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "Trial / DATENOW"
	elif printpoint == "3": print printfirst + "addonsettings LV_3" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "NONE" + space + "ID: " + idstr + space + "daynowS" + space2 + daynowS + space + "timenow3S" + space2 + timenow3S + space + "datenowS" + space2 + datenowS + space + "timezone" + space2 + timezone
	elif printpoint == "4": print printfirst + "addonsettings LV_4" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "DEFAULT" + space + "ID: " + idstr + space + "timezone" + space2 + timezone
	elif printpoint == "5": print printfirst + "addonsettings LV_5" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "skinsetting2" + space2 + skinsetting2 + "UNREGISTER"
	elif printpoint == "6": print printfirst + "addonsettings LV_6" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "REGISTERED"
	elif printpoint == "": print printfirst + "addonsettings LV_0-Error?"
	'''---------------------------'''
	
def YOULinkAll(url):
	dp = xbmcgui.DialogProgress()
	dp.create(addonName ,addonString(4).encode('utf-8')) #GAL CHECK THIS!
	dp.update(0)
	dp.update(0, "", str79520.encode('utf-8'))
	pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
	pl.clear()
	link = OPEN_URL(url)
	match=re.compile("http\://www.youtube.com/watch\?v\=([^\&]+)\&.+?<media\:descriptio[^>]+>([^<]+)</media\:description>.+?<media\:thumbnail url='([^']+)'.+?<media:title type='plain'>(.+?)/media:title>").findall(link)
	playlist = []
	nItem = len(match)

	for nurl,desc,thumb,rname in match:
		rname=rname.replace('<','')
		#finalurl= "plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid="+nurl+"&hd=1"
		finalurl= "plugin://plugin.video.youtube/play/?video_id="+nurl+"&hd=1"
		liz = xbmcgui.ListItem(rname, iconImage="DefaultVideo.png", thumbnailImage=thumb)
		liz.setInfo( type="Video", infoLabels={ "Title": rname, "Plot": desc}) #NEW UNTESTED!!! (PLOT...)
		liz.setProperty("IsPlayable","true")
		playlist.append((finalurl ,liz))
		progress = len(playlist) / float(nItem) * 100  
		dp.update(int(progress), str79520.encode('utf-8'),rname)
		#dp.update(i*5, str79529.encode('utf-8'), "")
		if dp.iscanceled():
			return

	
	for blob ,liz in playlist:
		try:
			if blob:
				if not 'UKY3scPIMd8' in blob:
					pl.add(blob,liz)
		except:
			pass
	dp.close()
	xbmc.Player(xbmc.PLAYER_CORE_MPLAYER).play(pl)

def SeasonsFromShow(showApiUrl):
	#print showApiUrl
	resultJSON = json.loads(OPEN_URL(showApiUrl))
	seasons=resultJSON['feed']['entry']
	for i in range (0, len(seasons)) :
		#print seasons[i].keys()
		#print seasons[i]['title']['$t']
		for index,item in  enumerate(seasons[i]['gd$feedLink']) :
			if item['countHint'] !=0:
				resultJSON = json.loads(OPEN_URL( seasons[i]['gd$feedLink'][index]['href']+'&alt=json'))
				for  j in range (0, len(resultJSON['feed']['entry'])) :
					title= str(resultJSON['feed'][u'entry'][j][ u'media$group'][u'media$title'][u'$t'].encode('utf-8')).decode('utf-8')
					thumb =str(resultJSON['feed'][u'entry'][j][ u'media$group'][u'media$thumbnail'][-1][u'url'])
					episode_num=resultJSON['feed']['entry'][j]['yt$episode']['number']
					url= resultJSON['feed']['entry'][j]['link'][0]['href']
					match=re.compile('www.youtube.com/watch\?v\=(.*?)\&f').findall(url)
					#finalurl="plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid="+match[0]+"&hd=1"
					finalurl="plugin://plugin.video.youtube/play/?video_id="+match[0]+"&hd=1"
					addLink(title+' '+episode_num ,finalurl,thumb,'',"")

def YOUsubs(user):
	murl='http://gdata.youtube.com/feeds/api/users/'+user+'/subscriptions?alt=json&start-index=1&max-results=50'
	resultJSON = json.loads(OPEN_URL(murl))
	feed=resultJSON['feed']['entry']
	for i in range (0, len(feed)) :
		image=str(feed[i]['media$thumbnail']['url'])
		name = feed[i]['title']['$t'].replace('Activity of:','').encode('utf-8')
		url=feed[i]['yt$channelId']['$t'].encode('utf-8')
		addDir(name,url,9,image,'1','1',"")

	

		
def ListPlaylist(playlistid, page):
	printpoint = "" ; TypeError = "" ; extra = "" ; playlist = []
	try:
		pageN = int(page)
		if pageN < 1: pageN = 1
		'''---------------------------'''
	except:
		pageN = 1
		'''---------------------------'''
	pageS = str(page)
	'''---------------------------'''
	pagesizeN = 40
	pagesizeS = str(pagesizeN)
	'''---------------------------'''
	if pageN <= 1: indexN = 1
	else: indexN = pageN * pagesizeN - pagesizeN
	indexS = str(indexN)
	'''---------------------------'''
	url = 'https://www.googleapis.com/youtube/v3/playlistItems?playlistId='+playlistid+'&key=AIzaSyASEuRNOghvziOY_8fWSbKGKTautNkAYz4&part=snippet&maxResults=40&pageToken=' #?
	link = OPEN_URL(url)
	prms=json.loads(link)
	if admin:
		print "url" + space2 + str(url) + newline + \
		"link" + space2 + str(link) + newline + \
		"prms" + space2 + str(prms) + newline #+ \ + "totalResults" + space2 + str(totalResults)
		'''---------------------------'''
		
	addDir('[COLOR=Yellow]' + str79520.encode('utf-8') + '[/COLOR]',url,11,"special://skin/media/DefaultPlaylist.png",str79526.encode('utf-8'),'1',"") #Quick-Play
	'''---------------------------'''
	validS = "" #URLS
	duplicatesN = 0 #DUPLICATES
	invalidN = 0
	invalidS = "" #DELETES/PRIVATE
	'''---------------------------'''
	exceptN = 0
	totalResults=int(prms['pageInfo'][u'totalResults']) #if bigger than pagesize needs to add more result
	totalpagesN = (totalResults / pagesizeN) + 1
	'''---------------------------'''

	i = 0
	while i < pagesizeN and not "8" in printpoint and not xbmc.abortRequested: #h<totalResults
		try:
			print "i" + space2 + str(i) + space + "duplicatesN" + space2 + str(duplicatesN)
			#urlPlaylist= str(prms['feed'][u'entry'][i][ u'media$group'][u'media$player'][0][u'url'])
			
			#https://www.youtube.com/watch?v=rjLmzRcmnSs&list=PLPWc8VdaIIsAHPacvuyNfA-y8VSxoh4or
			#match=re.compile('www.youtube.com/watch\?v\=(.*?)\&f').findall(id)
			#finalurl="plugin://plugin.video.youtube/play/?video_id="+match[0]+"&hd=1"
			#finalurl="plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid="+match[0]+"&hd=1"
			#finalurl="https://www.youtube.com/watch?v="+id+"&list="+playlistid
			#finalurl="plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid="+match[0]+"&hd=1"
			#finalurl="plugin://plugin.video.youtube/play/?video_id="+id+"&hd=1"
			#title= str(prms['feed'][u'entry'][i][ u'media$group'][u'media$title'][u'$t'].encode('utf-8')).decode('utf-8')
			#thumb =str(prms['feed'][u'entry'][i][ u'media$group'][u'media$thumbnail'][2][u'url'])
			
			id=str(prms['items'][i][u'snippet'][u'resourceId'][u'videoId']) #Video ID
			finalurl="plugin://plugin.video.youtube/play/?video_id="+id
			title=str(prms['items'][i][u'snippet'][u'title'].encode('utf-8'))
			thumb=str(prms['items'][i][u'snippet'][u'thumbnails'][u'default'][u'url'])
			desc = str(prms['items'][i][u'snippet'][u'description'].encode('utf-8')) #.decode('utf-8')
			#id = "" ; finalurl = "" ; title = "" ; thumb = "" ; desc = ""
			
			if not finalurl in validS and not "Deleted video" in title and not "Private video" in title and finalurl != "":
				ok, liz = addLink(title,finalurl, thumb, desc)
				#name, url, mode, iconimage='DefaultFolder.png', desc="", num="", viewtype=""
				validS = validS + space + finalurl
				playlist.append((finalurl ,liz))
				'''---------------------------'''
			else:
				if "Deleted video" in title or "Private video" in title:
					invalidN = invalidN + 1
					invalidS = PlayListGain3 + space + finalurl
				elif finalurl in validS:
					duplicatesN = duplicatesN + 1
					#if admin: print "finalurl_Duplicate" + space2 + finalurl
					'''---------------------------'''
		except Exception, TypeError:
			exceptN = exceptN + 1
			if not 'list index out of range' in TypeError: extra = extra + newline + "i" + space2 + str(i) + space + "TypeError" + space2 + str(TypeError)
			else: printpoint = printpoint + "8"
			'''---------------------------'''
		
		i = i + 1
	numOfItems2 = totalResults - invalidN - duplicatesN - exceptN
	totalpagesN = (numOfItems2 / pagesizeN) + 1

	nextpage = pageN + 1
	nextpageS = str(nextpage)
	
	#url='https://gdata.youtube.com/feeds/api/playlists/'+playlistid+'?alt=json&max-results=40&start-index=2'
	#addDir('[COLOR=Yellow]' + str79521.encode('utf-8') + '[/COLOR]',playlistid,9,"special://skin/media/icons/se.png",str79528.encode('utf-8'),'25',"") #More Results
	#if totalpagesN > pageN: addDir('[COLOR=Yellow]' + str79521.encode('utf-8') + '[/COLOR]','plugin://plugin.video.youtube/playlist/'+playlistid+'/',13,"special://skin/media/DefaultPlaylist.png",str79528.encode('utf-8'),nextpageS,"") #More Results
	if totalpagesN > pageN: addDir('[COLOR=Yellow]' + str33078.encode('utf-8') + '[/COLOR]',playlistid,13,"special://skin/media/DefaultVideo2.png",str79528.encode('utf-8'),nextpageS,50) #Next Page

	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin:
		if validS != "": extra = "validS" + space2 + str(validS) + newline + extra
		if invalidS != "": extra = "invalidS" + space2 + str(invalidS) + newline + extra
		if playlist != "": extra = "playlist" + space2 + str(playlist) + newline + extra
		
		print printfirst + "ListPlaylist_LV" + printpoint + space + "i" + space2 + str(i) + space + "totalResults" + space2 + str(totalResults) + space + "numOfItems2" + space2 + str(numOfItems2) + newline + \
		"playlistid" + space2 + playlistid + space + "page" + space2 + pageS + " / " + str(totalpagesN) + space + "pagesize" + space2 + str(pagesizeN) + newline + \
		"extra" + space2 + str(extra)
		'''---------------------------'''