import xbmc
import os, sys
import subprocess
import xbmcgui, xbmcaddon

from variables import *
from modules import *

class main:
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	Skin_UpdateTimerN = int(Skin_UpdateTimer)
	A10 = [10, 20, 30, 40, 50 , 60]
	if admin and General_Timer in A10: print printfirst + "VARCHECK1" + space2 + "Skin_UpdateLog" + space2 + Skin_UpdateLog + space + "Time_Pass" + space2 + Time_Pass
	'''---------------------------'''
	
	'''------------------------------
	---setGeneral_Timer--------------
	------------------------------'''
	General_Timer2 = calculate('service.htpt','General_Timer','1',General_Timer)
	General_Timer2 = int(General_Timer2)
	if General_Timer2 >= 60: General_Timer2 = 1
	General_Timer2S = str(General_Timer2)
	setsetting_custom1('service.htpt','General_Timer',General_Timer2S)
	if admin and admin2: print printfirst + space + "General_Timer" + space2 + countS
	'''---------------------------'''
	
	if General_Timer2 == 1:
		'''------------------------------
		---SetTime_Pass------------------
		------------------------------'''
		Time_Pass2 = SetTime_Pass(admin, admin2, Time_Pass)
		#setsetting('Time_Pass',Time_Pass2)
		setsetting_custom1('service.htpt','Time_Pass',Time_Pass2)
		'''---------------------------'''
		
	if Skin_UpdateTimer != "0":
		'''------------------------------
		---Skin_UpdateTimer--------------
		------------------------------'''
		Skin_UpdateTimer2 = calculate('service.htpt','Skin_UpdateTimer','2',Skin_UpdateTimer)
		setsetting('Skin_UpdateTimer',Skin_UpdateTimer2)
		'''---------------------------'''
		if Skin_UpdateTimerN == 119: notification(addonString(12).encode('utf-8') + ".", addonString(9).encode('utf-8'),"",1000)
		elif Skin_UpdateTimerN == 118: notification(addonString(12).encode('utf-8') + "..", addonString(9).encode('utf-8'),"",1000)
		elif Skin_UpdateTimerN == 117: notification(addonString(12).encode('utf-8') + "...", addonString(9).encode('utf-8'),"",1000)
		#elif not playerhasvideo and systemidle3 and : 
		'''---------------------------'''
	
	if Skin_UpdateTimer == "0" and Skin_UpdateCount == Skin_UpdateCount2:
		'''------------------------------
		---setSkin_UpdateCount-----------
		------------------------------'''
		Skin_UpdateCount2 = setSkin_UpdateCount2(admin, Skin_UpdateCount, Time_Pass)
		'''---------------------------'''
			
	if Skin_UpdateCount2 != Skin_UpdateCount and (systemidle120 or admin or Skin_UpdateCount == "0") and not playerhasvideo and hasinternet:
		'''------------------------------
		---UpdateAddons------------------
		------------------------------'''
		UpdateAddons(admin, Skin_UpdateCount, Skin_UpdateCount2)
		'''---------------------------'''

	if (Skin_Update != "true" and (Skin_UpdateTimerN < 70 or admin) and Skin_UpdateTimerN > 0) or (Skin_Update == "true" and Skin_Version == htptskinversion):
		'''------------------------------
		---Skin_Update-(NEW-ONLY)--------
		------------------------------'''
		setSkin_Update(admin, Skin_Version, htptskinversion, Skin_Update)
		'''---------------------------'''

	if Skin_Update == "true" or Skin_UpdateDate == "":
		'''------------------------------
		---setSkin_UpdateDate-(NEW-ONLY)-
		------------------------------'''
		setSkin_UpdateDate(admin, Skin_Version, htptskinversion, Skin_Update, Skin_UpdateDate)
		'''---------------------------'''
		
	if Skin_Update == "true" or Skin_Version == "":
		'''------------------------------
		---setSkin_Version---------------
		------------------------------'''
		setSkin_Version(admin, Skin_Version, htptskinversion)
		'''---------------------------'''
	
	if Skin_Version == htptskinversion and Skin_UpdateLog == "true" and Skin_UpdateDate != "" and systemidle3 and not playerhasvideo and home_aW:
		'''------------------------------
		---Skin_UpdateLog----------------
		------------------------------'''
		dialogbusyW = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
		dialogokW = xbmc.getCondVisibility('Window.IsVisible(DialogOk.xml)')
		dialogprogressW = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
		dialogselectW = xbmc.getCondVisibility('Window.IsVisible(DialogSelect.xml)')
		dialogtextviewerW = xbmc.getCondVisibility('Window.IsVisible(DialogTextViewer.xml)')
		dialogyesnoW = xbmc.getCondVisibility('Window.IsVisible(DialogYesNo.xml)')
		startupW = xbmc.getCondVisibility('Window.IsVisible(Startup.xml)')
		'''---------------------------'''
		if not dialogbusyW and not dialogokW and not dialogprogressW and not dialogselectW and not dialogtextviewerW and not dialogyesnoW and not startupW:
			if datenowS != "": #PREVENT RANDOM BUG WITH datetime
				setSkin_UpdateLog(admin, Skin_Version, Skin_UpdateDate, datenowS)
				setsetting('Skin_UpdateLog',"false")
				#setsetting_custom1('service.htpt','Skin_UpdateLog',"false")
				'''---------------------------'''
	
	if General_Timer in A10:
		'''------------------------------
		---setPing_Rate-(1-5)------------
		------------------------------'''
		Ping_1 = getsetting('Ping_1')
		Ping_2 = getsetting('Ping_2')
		Ping_3 = getsetting('Ping_3')
		Ping_4 = getsetting('Ping_4')
		Ping_5 = getsetting('Ping_5')
		Ping_6 = getsetting('Ping_6')
		Ping_7 = getsetting('Ping_7')
		Ping_8 = getsetting('Ping_8')
		Ping_9 = getsetting('Ping_9')
		Ping_10 = getsetting('Ping_10')
		'''---------------------------'''
		setPing_Rate(admin, admin2, Ping_Rate, Ping_1, Ping_2, Ping_3, Ping_4, Ping_5, Ping_6, Ping_7, Ping_8, Ping_9, Ping_10)
		'''---------------------------'''
		
	'''------------------------------
	---validationstartup-------------
	------------------------------'''
	validationstartup(admin)
	'''---------------------------'''
	
	'''------------------------------
	---videoplayertweak--------------
	------------------------------'''
	videoplayertweak(admin,playerhasvideo)
	'''---------------------------'''
	
	if not systemplatformwindows and not systemidle300:
		'''------------------------------
		---connectioncheck---------------
		------------------------------'''
		connectioncheck(admin,count,systemidle3)
		'''---------------------------'''
		
		'''------------------------------
		---setPing-----------------------
		------------------------------'''
		#setPing(admin,count,systemidle3)
		'''---------------------------'''
	
	'''---------------------------'''
	if systemidle3 and not systemplatformwindows and not playerhasvideo:
		'''------------------------------
		---SKIN-CHECK--------------------
		------------------------------'''
		output = bash('cat /storage/.kodi/userdata/guisettings.xml | grep -e "<skin>"',"GUI1")
		if not "<skin>skin.htpt</skin>" in output and "<skin>" in output:
			Skin_Check2 = calculate('service.htpt','Skin_Check','1',Skin_Check)
			Skin_Check2N = int(Skin_Check2)
			setsetting('Skin_Check', Skin_Check2)
			
			if Skin_Check2N > 2:
				'''------------------------------
				---ERROR-1020--------------------
				------------------------------'''
				xbmc.executebuiltin('Notification($LOCALIZE[257]: 1020,$LOCALIZE[79505],2000)')
				os.system('sh /storage/.kodi/addons/service.htpt/specials/scripts/copyskin.sh')
				setsetting_custom1('service.htpt','Skin_Check',"-10")
				'''---------------------------'''
		elif Skin_Check != "0":
			setsetting('Skin_Check', "0")