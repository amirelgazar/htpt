import xbmc, xbmcgui, xbmcaddon
import os, subprocess, sys
import fileinput

from variables import *
if admin: from shared_modules2 import *
xbmc.sleep(100)

def addonsettings(name, addon,skinsettingS, skinsetting2S, usernameS, passwordS, set3,opt1,opt2,opt3):
	'''------------------------------
	---SET-USERNAME-AND-PASSWORD-----
	------------------------------'''
	getsetting_custom          = xbmcaddon.Addon(addon).getSetting
	setsetting_custom          = xbmcaddon.Addon(addon).setSetting
	
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	skinsetting = xbmc.getInfoLabel('Skin.HasSetting('+ skinsettingS +')')
	skinsetting2 = xbmc.getInfoLabel('Skin.String('+ skinsetting2S +')')
	#if setting_custom == str20122: setting_custom = "true"
	#else: setting_custom = "false"
	try: skinsetting2N = int(skinsetting2)
	except: skinsetting2N = 0
	username = getsetting_custom(usernameS)
	password = getsetting_custom(passwordS)
	setting3 = getsetting_custom(set3)
	printpoint = ""
	'''---------------------------'''
	if (skinsetting or id9str == 'Trial' or id2str == datenowS) and usernameS != "" and passwordS != "":
		if admin: notification("test0","","",1000)
		if ('htpt' in username and not "finalmakerr" in idstr) and idstr != username and id9str != 'Trial' and id2str != datenowS:
			'''------------------------------
			---SET-DEFAULT-------------------
			------------------------------'''
			setsetting_custom(usernameS,idstr)
			setsetting_custom(passwordS,idpstr)
			printpoint = printpoint + "1"
			if admin: notification("test1","","",1000)
			'''---------------------------'''
		elif id9str == 'Trial' or id2str == datenowS:
			'''------------------------------
			---SET-TRIAL---------------------
			------------------------------'''
			setsetting_custom(usernameS,idtrial)
			setsetting_custom(passwordS,idp2str)
			printpoint = printpoint + "2"
			if admin: notification("test2","","",1000)
			'''---------------------------'''
		elif skinsetting and ((username == "" or password == "") or skinsetting2 == "0"):
			'''------------------------------
			---SET-NONE----------------------
			------------------------------'''
			setsetting_custom(usernameS,"")
			setsetting_custom(passwordS,"")
			printpoint = printpoint + "5"
			if admin: notification("test1.2","","",1000)
			'''---------------------------'''
		elif skinsetting:
			'''------------------------------
			---NO-CHANGES--------------------
			------------------------------'''
			printpoint = printpoint + "6"
			if admin: notification("test1.3","","",1000)
			'''---------------------------'''
	else:
		'''------------------------------
		---NO-ACCOUNT-OR-TRIAL-----------
		------------------------------'''
		daynowS = get_daynow(1)
		timezone = get_timenow(1)
		General_TimeZone = getsetting('General_TimeZone')
		if name == 'REALDEBRID' and (daynowS == opt1 or General_TimeZone != opt2):
			'''------------------------------
			---SET-NONE----------------------
			------------------------------'''
			setsetting_custom(usernameS,"")
			setsetting_custom(passwordS,"")
			printpoint = printpoint + "3"
			'''---------------------------'''
		else:
			'''------------------------------
			---SET-DEFAULT-------------------
			------------------------------'''
			setsetting_custom(usernameS,idstr)
			setsetting_custom(passwordS,idpstr)
			printpoint = printpoint + "4"
			'''---------------------------'''
			
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if printpoint == "0": print printfirst + "addonsettings LV_0" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "?"
	if printpoint == "1": print printfirst + "addonsettings LV_1" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "RESET"
	elif printpoint == "2": print printfirst + "addonsettings LV_2" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "Trial / DATENOW"
	elif printpoint == "3": print printfirst + "addonsettings LV_3" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "NONE" + space + "ID: " + idstr + space + "daynowS" + space2 + daynowS + space + "timenow3S" + space2 + timenow3S + space + "datenowS" + space2 + datenowS + space + "timezone" + space2 + timezone
	elif printpoint == "4": print printfirst + "addonsettings LV_4" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "DEFAULT" + space + "ID: " + idstr + space + "timezone" + space2 + timezone
	elif printpoint == "5": print printfirst + "addonsettings LV_5" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "skinsetting2" + space2 + skinsetting2 + "UNREGISTER"
	elif printpoint == "6": print printfirst + "addonsettings LV_6" + space2 + addon + space + skinsettingS + space2 + skinsetting + space + "REGISTERED"
	elif printpoint == "": print printfirst + "addonsettings LV_0-Error?"
	'''---------------------------'''
	
def addonsettings2(addon,set1,set1v,set2,set2v,set3,set3v,set4,set4v,set5,set5v):
	'''------------------------------
	---SET-ADDON-SETTING-5-----------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	getsetting_custom          = xbmcaddon.Addon(addon).getSetting
	setsetting_custom          = xbmcaddon.Addon(addon).setSetting

	setting1 = getsetting_custom(set1)
	setting2 = getsetting_custom(set2)
	setting3 = getsetting_custom(set3)
	setting4 = getsetting_custom(set4)
	setting5 = getsetting_custom(set5)
	
	checkChange = "false"
	'''---------------------------'''
	if set1 != "" and set1v != setting1:
		setsetting_custom(set1,set1v)
		if checkChange != "true": checkChange = "true"
	if set2 != "" and set2v != setting2:
		setsetting_custom(set2,set2v)
		if checkChange != "true": checkChange = "true"
	if set3 != "" and set3v != setting3:
		setsetting_custom(set3,set3v)
		if checkChange != "true": checkChange = "true"
	if set4 != "" and set4v != setting4:
		setsetting_custom(set4,set4v)
		if checkChange != "true": checkChange = "true"
	if set5 != "" and set5v != setting5:
		setsetting_custom(set5,set5v)
		if checkChange != "true": checkChange = "true"
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if checkChange == "true": print printfirst + "addonsettings2 " + addon + space + set1 + space2 + set1v + space + set2 + space2 + set2v + space + set3 + space2 + set3v + space + set4 + space2 + set4v + space + set5 + space2 + set5v + space
	'''---------------------------'''


def checkAddon_Update(admin, Addon_Update, Addon_Version, Addon_UpdateDate, Addon_UpdateLog):
	from variables import addonVersion
	setsetting_custom1(addonID,'Addon_UpdateLog',"true")
	Addon_UpdateLog = "true"
	'''---------------------------'''
	if Addon_Update != "true" or (Addon_Update == "true" and Addon_Version == addonVersion):
		'''------------------------------
		---Addon_Update-(NEW-ONLY)--------
		------------------------------'''
		Addon_Update = setAddon_Update(admin, addonVersion, Addon_Version, Addon_Update)
		'''---------------------------'''
	
	if Addon_Update == "true":
		'''------------------------------
		---setAddon_Version---------------
		------------------------------'''
		Addon_Version = setAddon_Version(admin, addonVersion, Addon_Version)
		'''---------------------------'''
		
	if Addon_Update == "true" or Addon_UpdateDate == "":
		'''------------------------------
		---setAddon_UpdateDate-(NEW-ONLY)-
		------------------------------'''
		Addon_UpdateDate = setAddon_UpdateDate(admin, addonVersion, Addon_Version, Addon_Update, Addon_UpdateDate)
		'''---------------------------'''
	
	if Addon_Version == addonVersion and Addon_UpdateLog == "true" and Addon_UpdateDate != "":
		'''------------------------------
		---Addon_UpdateLog----------------
		------------------------------'''
		dialogokW = xbmc.getCondVisibility('Window.IsVisible(DialogOk.xml)')
		dialogselectW = xbmc.getCondVisibility('Window.IsVisible(DialogSelect.xml)')
		dialogprogressW = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
		dialogbusyW = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
		dialogtextviewerW = xbmc.getCondVisibility('Window.IsVisible(DialogTextViewer.xml)')
		startupW = xbmc.getCondVisibility('Window.IsVisible(Startup.xml)')
		if not dialogokW and not dialogselectW and not dialogprogressW and not dialogbusyW and not startupW and not dialogtextviewerW:
			from variables import datenowS
			if datenowS != "": #PREVENT RANDOM BUG WITH datetime
				setAddon_UpdateLog(admin, Addon_Version, Addon_UpdateDate, datenowS)
				'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "checkAddon_Update" + space2 + "Addon_Update" + space2 + Addon_Update + space + "Addon_Version" + space2 + Addon_Version + space + "addonVersion" + space2 + addonVersion + space + "Addon_UpdateDate" + space2 + Addon_UpdateDate + space + "Addon_UpdateLog" + space2 + Addon_UpdateLog
	'''---------------------------'''
				
def setAddon_Update(admin, addonVersion, Addon_Version, Addon_Update):
	'''------------------------------
	---CHECK-FOR-FIX-UPDATE----------
	------------------------------'''
	Addon_Update2 = Addon_Update
	if Addon_Version != addonVersion and Addon_Update == "false":
		Addon_Update2 = "true"
		setsetting('Addon_UpdateLog',"true")
		'''---------------------------'''
	else:
		Addon_Update2 = "false"
		'''---------------------------'''
		
	if Addon_Update != Addon_Update2: setsetting('Addon_Update',Addon_Update2)
	'''---------------------------'''
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin and Addon_Update != Addon_Update2: print printfirst + "setAddon_Update" + space2 + Addon_Update + " - " + Addon_Update2
	'''---------------------------'''	
	return Addon_Update2

def setAddon_Version(admin, addonVersion, Addon_Version):
	'''------------------------------
	---CHECK-FOR-ADDON-UPDATE-2------
	------------------------------'''
	Addon_Version2 = Addon_Version
	'''---------------------------'''
	if Addon_Version != addonVersion:
		Addon_Version2 = addonVersion
		setsetting('Addon_Version',Addon_Version2)
		'''---------------------------'''	
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if Addon_Version != addonVersion or admin: print printfirst + "setAddon_Version" + space2 + Addon_Version + " - " + Addon_Version2
	'''---------------------------'''
	return Addon_Version2
		
def setAddon_UpdateDate(admin, addonVersion, Addon_Version, Addon_Update, Addon_UpdateDate):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	from variables import datenowS
	Addon_UpdateDate2 = Addon_UpdateDate
	'''---------------------------'''
	if Addon_UpdateDate != datenowS:
		Addon_UpdateDate2 = datenowS
		setsetting('Addon_UpdateDate',Addon_UpdateDate2)
		'''---------------------------'''

	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if Addon_UpdateDate != datenowS or admin: print printfirst + "setAddon_UpdateDate" + space2 + Addon_UpdateDate + " - " + Addon_UpdateDate2
	'''---------------------------'''
	return Addon_UpdateDate2
	
def setAddon_UpdateLog(admin, Addon_Version, Addon_UpdateDate, datenowS):	
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	from variables import addonName2
	printpoint = ""
	number2S = ""
	datenowD = stringtodate(datenowS,'%Y-%m-%d')
	datedifferenceD = stringtodate(Addon_UpdateDate,'%Y-%m-%d')
	datedifferenceS = str(datedifferenceD)
	if "error" in [datenowD, datedifferenceD]: printpoint = printpoint + "9"
	try:
		number2 = datenowD - datedifferenceD
		number2S = str(number2)
		printpoint = printpoint + "2"
		'''---------------------------'''
	except:
		printpoint = printpoint + "9"
		'''---------------------------'''
	if not "9" in printpoint:
		printpoint = printpoint + "4"
		if "day," in number2S: number2S = number2S.replace(" day, 0:00:00","",1)
		elif "days," in number2S: number2S = number2S.replace(" days, 0:00:00","",1)
		else: number2S = "0"
		if admin: notification("number2S:" + number2S,"","",2000)
		number2N = int(number2S)
		'''---------------------------'''
		#header = '[COLOR=Yellow]' + addonString(304).encode('utf-8') + " - " + addonVersion + '[/COLOR]'
		if number2N == 0: header = '[COLOR=Yellow]' + str79311 % (addonName2) + space + str72101 + " - " + Addon_Version + '[/COLOR]'
		elif number2N == 1: header = '[COLOR=Green]' + str79311 % (addonName2) + space + str72102 + " - " + Addon_Version + '[/COLOR]'
		elif number2N <= 7: header = '[COLOR=Purple]' + str79311 % (addonName2) + space + str72103 + " - " + Addon_Version + '[/COLOR]'
		else: header = ""
		'''---------------------------'''
		log = open(addonPath + "/" + 'changelog.txt', 'r')
		message2 = log.read()
		log.close()
		message2S = str(message2)
		message3 = message2[0:8000]
		message3 = '"' + message3 + '"'
		message3S = str(message3)
		if header != "":
			w = TextViewer_Dialog('DialogTextViewer.xml', "", header=header, text=message2)
			w.doModal()
			'''---------------------------'''
		setsetting('Addon_UpdateLog',"false")
		#setsetting_custom1('service.htpt','Skin_UpdateLog',"false")
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "setAddon_UpdateLog_LV" + printpoint + space2 + "Addon_UpdateDate" + space2 + Addon_UpdateDate + " - " + datenowS + space + "(" + number2S + ")" + space + "Addon_UpdateLog" + space2 + Addon_UpdateLog
	'''---------------------------'''

def bash(bashCommand,bashname):
	'''------------------------------
	---RUN-BASH-COMMANDS-------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	admin2 = xbmc.getInfoLabel('Skin.HasSetting(Admin2)')
	if not systemplatformwindows:
		#process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
		process = subprocess.Popen(bashCommand,stdout=subprocess.PIPE,shell=True)
		output = process.communicate()[0]
		'''---------------------------'''
		
		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		if admin and admin2: print printfirst + bashname + space2 + output	
		'''---------------------------'''
		return output
		
def calculate(addon, set1, custom, opt):
	'''------------------------------
	---RETURN-CALCULATE-NUMBER-------
	------------------------------'''
	printpoint = ""
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	admin2 = xbmc.getInfoLabel('Skin.HasSetting(Admin2)')
	getsetting_custom          = xbmcaddon.Addon(addon).getSetting
	setsetting_custom          = xbmcaddon.Addon(addon).setSetting
		
	set1v = getsetting_custom(set1)
	try: set1v = int(set1v)
	except: printpoint = printpoint + "1"
	
	if opt != "": set2v = int(opt)
	else: set2v = ""
	'''---------------------------'''
	if custom == '1':
		if not "1" in printpoint: set1v += 1
		if opt != "": set2v += 1
		'''---------------------------'''
	elif custom == '2':
		if not "1" in printpoint: set1v += -1
		if opt != "": set2v += -1
		'''---------------------------'''
	set1v = str(set1v)
	if opt != "": set2v = str(set2v)
	'''---------------------------'''
	if opt != "": setsetting_custom(set1, set2v)
	else: setsetting_custom(set1, set1v)
	'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''	
	if admin and admin2: print printfirst + "calculate" + space + addon + space + set1 + space + "set1v" + space + set1v + space + "set2v" + space + set2v
	if opt != "": return set2v
	else: return set1v
	'''---------------------------'''

def cmd(cmdCommand,cmdname):
	'''------------------------------
	---DEFAULT-----------------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')

	'''run CMD commands'''
	if systemplatformwindows:
		#process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
		#process = subprocess.Popen(cmdCommand,stdout=subprocess.PIPE,shell=True)
		
		#process = subprocess.Popen('cmd.exe' + space + cmdCommand, shell=True)
		#output = process.communicate()[0]

		#process = subprocess.Popen('cmd.exe', stdin = subprocess.PIPE, stdout = subprocess.PIPE)
		#output = process.communicate(cmdCommand)
		
		#output = subprocess.call(["ping", "-c 2", "www.cyberciti.biz"])
		#output = process.communicate()
		
		process = subprocess.Popen(cmdCommand,stdout=subprocess.PIPE,shell=True)
		output = process.communicate()[0]
		
		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		outputS = str(output)
		if admin and admin2: print printfirst + "cmd" + space2 + cmdname + space + cmdCommand + space + "output" + space2 + outputS
		'''---------------------------'''
		return output
		
def copy_rename(old_file_name, new_file_name):
	'''UNUSED'''
	import shutil
	src_dir= os.curdir
	dst_dir= os.path.join(os.curdir , "/storage/")
	src_file = os.path.join(src_dir, old_file_name)
	shutil.copy(src_file,dst_dir)
	
	dst_file = os.path.join(dst_dir, old_file_name)
	new_dst_file_name = os.path.join(dst_dir, new_file_name)
	os.rename(dst_file, new_dst_file_name)

def checkDialog(admin):
	'''------------------------------
	---checkDialog-------------------
	------------------------------'''
	dialogbusyW = xbmc.getCondVisibility('Window.IsVisible(DialogBusy.xml)')
	dialogprogressW = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
	dialogselectW = xbmc.getCondVisibility('Window.IsVisible(DialogSelect.xml)')
	dialogyesnoW = xbmc.getCondVisibility('Window.IsVisible(DialogYesNo.xml)')
	dialogokW = xbmc.getCondVisibility('Window.IsVisible(DialogOK.xml)')
	dialogkeyboardW = xbmc.getCondVisibility('Window.IsVisible(DialogKeyboard.xml)')
	'''---------------------------'''
	if dialogbusyW: returned = dialogbusyW
	elif dialogprogressW: returned = dialogprogressW
	elif dialogselectW: returned = dialogselectW
	elif dialogyesnoW: returned = dialogyesnoW
	elif dialogokW: returned = dialogokW
	elif dialogkeyboardW: returned = dialogkeyboardW
	else: returned = ""
	'''---------------------------'''
	
	'''---------------------------'''
	return returned
		
def dialogkeyboard(input, heading, option, custom, addonsetting, addonsetting2):
	''''''
	if '$LOCALIZE' in heading: heading = xbmc.getInfoLabel(heading)
	dialog = xbmcgui.Dialog()
	keyboard = xbmc.Keyboard(input,heading,option)
	keyboard.doModal()
	returned = 'skip'
	if (keyboard.isConfirmed()):
		input2 = keyboard.getText()
		if custom == '1' and input2 != "": returned = 'ok'
		if custom == '2' and input2 == input: returned = 'ok'
		if custom == '3':
			if input2 != input and input2 != "" and option == 0: xbmc.executebuiltin('Notification('+ heading +': '+ input2 +',,4000)')
			if input2 != "": returned = 'ok'
			
		if option == 0: print printfirst + heading + space2 + input2 + " ( " + returned + " )"
		elif option != 0: print printfirst + heading + space2 + "*******" + " ( " + returned + " )"
	if returned == 'ok':
		returned == input2
		if addonsetting2 == "0": setsetting(addonsetting, input2)
		elif 'genesis' in addonsetting2:
			setsetting_genesis          = xbmcaddon.Addon('plugin.video.genesis').setSetting
			setsetting_genesis(addonsetting, input2)
		elif 'sdarot.tv' in addonsetting2:
			setsetting_sdarottv          = xbmcaddon.Addon('plugin.video.sdarot.tv').setSetting
			setsetting_sdarottv(addonsetting, input2)
	return returned

def dialognumeric(type,heading,input,custom,addonsetting):
	'''type: 0 = #, 1 = DD/MM/YYYY, 2 = HH:MM, 3 = #.#.#.#, message2 = heading, message1 = content'''
	if '$LOCALIZE' in heading: heading = xbmc.getInfoLabel(heading)
	try:
		input = int(input)
	except:
		input = 0
	returned = 'skip'
	try:
		if int(input) > 001000000 and int(input) < 9999999999 and input != "": input = str(input)
	except TypeError:
		input = 0
		print printfirst + "dialognumeric " + "except TypeError (1)"
	input = str(input)
	input2 = xbmcgui.Dialog().numeric(type, heading, input)
	try:
		if input2 != "": input2 = int(input2)
	except TypeError:
		xbmc.executebuiltin('Notification($LOCALIZE[257],$LOCALIZE[31406],2000)')
		sys.exit()
	if custom == '0':
		try:
			if input2 > 001000000 and input2 < 9999999999: returned = 'ok'
			elif input2 < 001000000 or input2 > 9999999999: returned = 'skip0'
		except TypeError:
			returned = 'skip'
	if custom == '1':
		if input2 != "": returned = 'ok'
	if custom == '2':
		if input2 == "": input2 = 0
		elif input2 != 0: returned = 'ok'
	#if type == '2' and input == message1: returned = 'ok'
	
	input = str(input)
	input2 = str(input2)
	print printfirst + heading + space2 + input2 + "( " + returned + " )"
	if returned == 'ok':
		if custom != "2":
			returned == input
			setsetting(addonsetting, input2)
		elif custom == "2":
			returned == input
			if returned == "": returned = 0
			setSkinSetting("0", addonsetting, input2)
			#setsetting(addonsetting, input2)
			
	return returned

def dialogok(heading,line1,line2,line3):
	'''------------------------------
	---DIALOG-OK---------------------
	------------------------------'''
	dialog = xbmcgui.Dialog()
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	if '$LOCALIZE' in line1 or '$ADDON' in line1: line1 = xbmc.getInfoLabel(line1)
	if '$LOCALIZE' in line2 or '$ADDON' in line2: line2 = xbmc.getInfoLabel(line2)
	if '$LOCALIZE' in line3 or '$ADDON' in line3: line3 = xbmc.getInfoLabel(line3)
	try: heading = str(heading.encode('utf-8'))
	except: heading = str(heading)
	try: line1 = str(line1.encode('utf-8'))
	except: line1= str(line1)
	try: line2 = str(line2.encode('utf-8'))
	except: line2 = str(line2)
	try: line3 = str(line3.encode('utf-8'))
	except: line3 = str(line3)

	dialog.ok(heading,line1,line2,line3)
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + heading + space2 + line1 + space2 + line2 + space2 + line3
	'''---------------------------'''
	
def dialogprogress(heading,line1,line2,line3): 
	'''------------------------------
	---DIALOG-OK-***BROKEN***--------
	------------------------------'''
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	if '$LOCALIZE' in line1 or '$ADDON' in line1: line1 = xbmc.getInfoLabel(line1)
	if '$LOCALIZE' in line2 or '$ADDON' in line2: line2 = xbmc.getInfoLabel(line2)
	if '$LOCALIZE' in line3 or '$ADDON' in line3: line3 = xbmc.getInfoLabel(line3)
	heading = str(heading.encode('utf-8'))
	line1 = str(line1.encode('utf-8'))
	line2 = str(line2.encode('utf-8'))
	line3 = str(line3.encode('utf-8'))
	
	pDialog = xbmcgui.DialogProgress()
	#pDialog.create(heading,line1,line2,line3)
	pDialog.update(10,line1,line2,line3)
	
	#pDialog = xbmcgui.DialogProgressBG()
	#pDialog.create(heading, line1)
	
	#def dialogprogress(admin, id, action, name, header, line1, line2):
	#id = xbmcgui.DialogProgress( )
	#if action == 0: returned = id.create(name, header, line1, line2)
	#else: returned = ""
	#return returned
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "dialogprogress" + space2 + heading + space2 + line1 + space2 + line2 + space2 + line3
	'''---------------------------'''

def dialogselect(heading, list, autoclose):
	'''------------------------------
	---DIALOG-SELECT-----------------
	------------------------------'''
	'''autoclose = [opt] integer - milliseconds to autoclose dialog. (default=do not autoclose)'''
	printpoint = ""
	dialog = xbmcgui.Dialog()
	if '$LOCALIZE' in heading or '$ADDON' in heading:
		printpoint = printpoint + "1"
		heading = xbmc.getInfoLabel(heading)
	#heading = str(heading).decode('utf-8').encode('utf-8')
	try:
		heading = str(heading).encode('utf-8')
	except:
		printpoint = printpoint + "2"
		try:
			heading = heading.encode('utf-8')
		except:
			printpoint = printpoint + "3"
	returned = dialog.select(heading,list,autoclose)
	returned = int(returned)
	
	value = list[returned]
	value = str(value)
	
	#value = value.replace(" ","",1)
	#value = value.decode('utf-8').encode('utf-8')
	#value = str(value).decode('utf-8')
	#value = str(value).decode('utf-8').encode('utf-8')
	#value = value.decode('utf-8').encode('utf-8')
	
	if returned == -1: notification_common("9")

	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	returned = str(returned)
	print printfirst + "dialogselect_LV" + printpoint + space2 + heading + "( " + returned + " )" + space + "value" + space2 + value + space
	returned = int(returned)
	return returned, value
	'''---------------------------'''

def diaogtextviewer(header,message):
	w = TextViewer_Dialog('DialogTextViewer.xml', "", header=header, text=message)
	w.doModal()
	
def dialogyesno(heading,line1):
	'''------------------------------
	---DIALOG-YESNO------------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	if '$LOCALIZE' in line1 or '$ADDON' in line1: line1 = xbmc.getInfoLabel(line1)
	returned = 'skip'
	if dialog.yesno(heading,line1): returned = 'ok'
	
	try: heading = str(heading.encode('utf-8'))
	except: pass
	try: line1 = str(line1.encode('utf-8'))
	except: pass
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "dialogyesno" + space2 + heading + space3 + line1 + "( " + returned + " )"
	'''---------------------------'''
	return returned
	'''---------------------------'''

def findin_controlhasfocus(custom,what,sleep,action,action2):
	'''action = not found | action2 = when found'''
	'''---------------------------'''
	what = str(what)
	custom = str(custom)
	if custom == "0": controlhasfocus = xbmc.getCondVisibility('Control.HasFocus('+ what +')')
	else: controlhasfocus = xbmc.getCondVisibility('ControlGroup('+ custom +').HasFocus('+ what +')')
	
	if (what != "" and not controlhasfocus and action != ""): xbmc.executebuiltin(''+ action +'')
	'''---------------------------'''
	xbmc.sleep(sleep)
	if custom == "0": controlhasfocus = xbmc.getCondVisibility('Control.HasFocus('+ what +')')
	else: controlhasfocus = xbmc.getCondVisibility('ControlGroup('+ custom +').HasFocus('+ what +')')
	#systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
	xbmc.sleep(sleep)
	'''---------------------------'''
	if (what != "" and controlhasfocus and action2 != ""): xbmc.executebuiltin(''+ action2 +'')
	'''---------------------------'''
	return controlhasfocus
	
def findin_systemcurrentcontrol(custom,what,sleep,action,action2):
	'''action = not found | action2 = when found'''
	'''---------------------------'''
	systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
	
	if custom == "0" and (what != "" and systemcurrentcontrol != what and action != ""): xbmc.executebuiltin(''+ action +'')
	elif custom == "1" and (what != "" and not what in systemcurrentcontrol and action != ""): xbmc.executebuiltin(''+ action +'')
	'''---------------------------'''
	xbmc.sleep(sleep)
	systemcurrentcontrol = xbmc.getInfoLabel('System.CurrentControl')
	xbmc.sleep(sleep)
	'''---------------------------'''
	if custom == "0" and (what != "" and systemcurrentcontrol == what and action2 != ""): xbmc.executebuiltin(''+ action2 +'')
	elif custom == "1" and (what != "" and what in systemcurrentcontrol and action2 != ""): xbmc.executebuiltin(''+ action2 +'')
	'''---------------------------'''
	return systemcurrentcontrol
	
def get_daynow(custom):
	daynow = datenow.strftime("%a")
	daynowS = str(daynow)
	return daynowS

def getsetting_custom1(addon,set1):
	'''------------------------------
	---GET-ADDON-SETTING-1-----------
	------------------------------'''
	getsetting_custom          = xbmcaddon.Addon(addon).getSetting
	'''---------------------------'''
	returned = getsetting_custom(set1,set1v)
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "getsetting_custom1" + space2 + addon + space + set1
	'''---------------------------'''
	return returned
	'''---------------------------'''
	
def get_timenow(custom):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	import datetime as dt
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	customS = str(custom)
	timenow = dt.datetime.now()
	timenow3 = timenow.strftime("%H")
	timenow3S = str(timenow3)
	timenow3N = int(timenow3)
	timezone = ""
	'''---------------------------'''
	if timenow3N > 03 and timenow3N < 12: timezone = "A"
	elif timenow3N > 11 and timenow3N < 20: timezone = "B"
	elif timenow3N > 19 or timenow3N < 04: timezone = "C"
	
	if custom == 1: returned = timezone
	else: returned = ""
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin: print printfirst + "get_timenow_" + customS + space + "timenow3S" + space2 + timenow3S + space + "timezone" + space2 + timezone + space
	'''---------------------------'''
	return returned

def installaddon(admin, addonid2, name):
	returned = ""
	printpoint = ""
	if not os.path.exists(xbmc.translatePath("special://home/addons/") + addonid2):
		printpoint = printpoint + "1"
		xbmc.executebuiltin('ActivateWindow(10025,special://userdata/library/,return)')
		notification_common("12")
		xbmc.sleep(2000)
		xbmc.executebuiltin('ActivateWindow(10025,plugin://'+ addonid2 +')')
		xbmc.executebuiltin('Action(Down)')
		xbmc.executebuiltin('Action(Select)')
		xbmc.sleep(1000)
		notification_common("12")
		'''---------------------------'''
		dialogprogressW = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
		count = 0
		count2 = 0
		while count < 40 and (dialogprogressW or count2 > -2) and returned != "skip" and not xbmc.abortRequested:
			count += 1
			xbmc.sleep(500)
			dialogprogressW = xbmc.getCondVisibility('Window.IsVisible(DialogProgress.xml)')
			xbmc.sleep(500)
			if count == 1:
				returned = "?"
				#notification_common("12")
				printpoint = printpoint + "2"
			if count == 20: printpoint = printpoint + "3"
			if count == 39: printpoint = printpoint + "4"
			if not dialogprogressW: count2 += -1
			elif count2 < 0: count2 += 1
			if count == 40:
				printpoint = printpoint + "5"
				returned = "skip"
				print "error_count=20"
				'''---------------------------'''
		systemidle3 = xbmc.getCondVisibility('System.IdleTime(3)')
		returned = "?"
		if not systemidle3:
			returned = "skip"
			printpoint = printpoint + "6"
			'''---------------------------'''
		elif returned == "?":
			returned = "ok"
			printpoint = printpoint + "7"
			'''---------------------------'''
		else: printpoint = printpoint + "9"
		#xbmc.executebuiltin('Action(Close)')
		xbmc.executebuiltin('Action(Back)')
		'''---------------------------'''
	else: printpoint = printpoint + "8"
	print printfirst + "installaddon_LV" + printpoint + space + "(" + returned + ")"
	'''---------------------------'''
	return returned
	
def notification(heading, message, icon, time):
	'''------------------------------
	---Show a Notification alert.----
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	'''heading : string - dialog heading | message : string - dialog message. | icon : [opt] string - icon to use. (default xbmcgui.NOTIFICATION_INFO/NOTIFICATION_WARNING/NOTIFICATION_ERROR) | time : [opt] integer - time in milliseconds (default 5000) | sound : [opt] bool - play notification sound (default True)'''
	
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	if '$LOCALIZE' in message or '$ADDON' in message: message = xbmc.getInfoLabel(message)
	
	icon = "misc/logo/logo8.png"
	
	dialog.notification(heading, message, icon, time)
	
	#if "addonString" in heading and not "+" in heading: heading = str(heading.encode('utf-8'))
	if "addonString" in heading: heading = str(heading.encode('utf-8'))
	elif '$LOCALIZE' in heading or '$ADDON' in heading: heading = str(heading)
	if "addonString" in message: message = str(message.encode('utf-8'))
	elif '$LOCALIZE' in message or '$ADDON' in message: message = str(message)
	
	time = str(time)
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin:
		try: print printfirst + "notification" + space2 + heading + space3 + message + space + time
		except: print printfirst + "notification" + "..."
		'''---------------------------'''

def notification_common(custom):
	if custom == "7": notification('$LOCALIZE[79494]','$LOCALIZE[31407]',"",2000) #HODAH NIHNESHET
	elif custom == "8": notification('$LOCALIZE[31406]',"","",2000) #HAPEULA BUTLA
	elif custom == "9": notification('$LOCALIZE[31406]','$LOCALIZE[31412]',"",2000) #HAPEULA BUTLA, LO BUTZHU SINUHIM
	elif custom == "10": notification('$LOCALIZE[79496]','$LOCALIZE[79497]' + "   -   " + '$LOCALIZE[79081]',"",4000) #AFSARUT ZOT NIMZET BEPITHU...
	elif custom == "11": notification('$LOCALIZE[257]', '$LOCALIZE[79078]', "", 1000)   #ERROR | NASE SHENIT KAHET
	elif custom == "12": notification('$LOCALIZE[78959]','$LOCALIZE[31407]',"",7000) #MATKIN HARHAVOT
	elif custom == "13": notification('$LOCALIZE[79072]',"...","",2000) #HAPEULA ISTAIMA BEHATZLAHA!
	elif custom == "100": notification(addonString(46),'[COLOR=Yellow]' + addonString(90) + '[/COLOR]' + space + addonString(2) + space,"",7000) #MVAZEH TIKUN YADANI (script.htpt.fix)

def replaceAll(file,searchExp,replaceExp):
    '''UNUSED?'''
    for line in fileinput.input(file, inplace=1):
        if searchExp in line:
            line = line.replace(searchExp,replaceExp)
        sys.stdout.write(line)

def replaceAll2(file,searchExp,replaceExp):
    '''UNUSED?'''
    for line in fileinput.input(file, inplace=1):
        if searchExp in line:
            line = line.replace(searchExp,replaceExp)
        sys.stdout.write(line)
		#if line == 0:
			#add sys.stdout.write('\n')
			#add sys.stdout.write('import xbmc, xbmcgui, xbmcaddon')

def replace_word(infile,old_word,new_word):
    if not os.path.isfile(infile):
        print ("Error on replace_word, not a regular file: "+infile)
        sys.exit(1)

    f1=open(infile,'r').read()
    f2=open(infile,'w')
    m=f1.replace(old_word,new_word)
    f2.write(m)

def setSkinSetting(custom,set1,set1v):
	'''------------------------------
	---SET-SKIN-SETTING-1------------
	------------------------------'''
	#from variables import str20122
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	admin2 = xbmc.getInfoLabel('Skin.HasSetting(Admin2)')

	''' custom: 0 = Skin.String, 1 = Skin.HasSetting'''
	'''---------------------------'''
	if custom == "0":
		setting1 = xbmc.getInfoLabel('Skin.String('+ set1 +')')
		setting2 = ""
		if setting1 != set1v: xbmc.executebuiltin('Skin.SetString('+ set1 +','+ set1v +')')
		'''---------------------------'''
		
	elif custom == "1":
		setting2 = xbmc.getInfoLabel('Skin.HasSetting('+ set1 +')')
		if setting2 == str20122: setting1 = "true"
		else:
			setting1 = "false"
		if setting1 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set1 +')')
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if setting1 != set1v and admin and admin2: print printfirst + "setSkinSetting" + space3 + custom + space + set1 + space2 + setting1 + " - " + set1v + space3 + "( " + "setting2" + space2 + setting2 + " ) "
	'''---------------------------'''

def setSkinSetting5(custom,set1,set1v,set2,set2v,set3,set3v,set4,set4v,set5,set5v):
	'''------------------------------
	---SET-SKIN-SETTING-5------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	''' custom: 0 = Skin.String, 1 = Skin.HasSetting'''
	if custom == "0":
		setting1 = xbmc.getInfoLabel('Skin.String('+ set1 +')')
		setting2 = xbmc.getInfoLabel('Skin.String('+ set2 +')')
		setting3 = xbmc.getInfoLabel('Skin.String('+ set3 +')')
		setting4 = xbmc.getInfoLabel('Skin.String('+ set4 +')')
		setting5 = xbmc.getInfoLabel('Skin.String('+ set5 +')')
	elif custom == "1":
		setting1 = xbmc.getInfoLabel('Skin.HasSetting('+ set1 +')')
		setting2 = xbmc.getInfoLabel('Skin.HasSetting('+ set2 +')')
		setting3 = xbmc.getInfoLabel('Skin.HasSetting('+ set3 +')')
		setting4 = xbmc.getInfoLabel('Skin.HasSetting('+ set4 +')')
		setting5 = xbmc.getInfoLabel('Skin.HasSetting('+ set5 +')')
	'''---------------------------'''
	if custom == "0":
		if setting1 != set1v: xbmc.executebuiltin('Skin.SetString('+ set1 +','+ set1v +')')
		if setting2 != set2v: xbmc.executebuiltin('Skin.SetString('+ set2 +','+ set2v +')')
		if setting3 != set3v: xbmc.executebuiltin('Skin.SetString('+ set3 +','+ set3v +')')
		if setting4 != set4v: xbmc.executebuiltin('Skin.SetString('+ set4 +','+ set4v +')')
		if setting5 != set5v: xbmc.executebuiltin('Skin.SetString('+ set5 +','+ set5v +')')
	elif custom == "1":
		if setting1 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set1 +')')
		if setting2 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set2 +')')
		if setting3 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set3 +')')
		if setting4 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set4 +')')
		if setting5 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set5 +')')
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''	
	if admin and (setting1 != set1v or setting2 != set2v or setting3 != set3v or setting4 != set4v or setting5 != set5v): print printfirst + "setSkinSetting5" + space2 + set1 + space + set2 + space + set3 + space + set4 + space + set5 + space3
	'''---------------------------'''

def setsetting_custom1(addon,set1,set1v):
	'''------------------------------
	---SET-ADDON-SETTING-1-----------
	------------------------------'''
	getsetting_custom          = xbmcaddon.Addon(addon).getSetting
	setsetting_custom          = xbmcaddon.Addon(addon).setSetting
	
	set = getsetting_custom(set1)
	set1v = str(set1v)
	'''---------------------------'''
	if set != set1v:
		setsetting_custom(set1,set1v)
		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		print printfirst + "setsetting_custom1" + space2 + addon + space + set1 + space2 + set1v + space3
		'''---------------------------'''

def stringtodate(dt_str, dt_func):
	from datetime import datetime
	#if startupW and systemplatformwindows: print printfirst + "stringtodate-from datetime import datetime"
	printpoint = ""
	dt_str = str(dt_str)
	#dt_str = datenowS
	dt_obj = ""
	#dt_str = '9/24/2010 5:03:29 PM'
	#dt_func = '%m/%d/%Y %I:%M:%S %p'
	if dt_str == "" or dt_func =="":
		printpoint = printpoint + "9"
		notification("stringtodate_ERROR!","isEMPTY","",1000)
	else:
		try:
			dt_obj = datetime.strptime(dt_str, dt_func)
			printpoint = printpoint + "7"
		except:
			dt_obj = "error"
			notification("stringtodate_ERROR!","error","",1000)
			#sys.exit(0)

	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	dt_objS = str(dt_obj)
	#if admin: print printfirst + "stringtodate_LV" + printpoint + space + "dt_str" + space2 + dt_str + space + "dt_objS" + space2 + dt_objS + space + "datenowS" + space2 + datenowS
	'''---------------------------'''
	return dt_obj
	
class TextViewer_Dialog(xbmcgui.WindowXMLDialog):
    ACTION_PREVIOUS_MENU = [9, 92, 10]

    def __init__(self, *args, **kwargs):
        xbmcgui.WindowXMLDialog.__init__(self)
        self.text = kwargs.get('text')
        self.header = kwargs.get('header')

    def onInit(self):
        self.getControl(1).setLabel(self.header)
        self.getControl(5).setText(self.text)

    def onAction(self, action):
        if action in self.ACTION_PREVIOUS_MENU:
            self.close()

    def onClick(self, controlID):
        pass

    def onFocus(self, controlID):
        pass