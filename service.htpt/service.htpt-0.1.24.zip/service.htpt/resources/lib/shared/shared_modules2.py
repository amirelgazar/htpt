import xbmc, xbmcgui, xbmcaddon
#import os, subprocess, sys
#from variables import *
#from shared_modules import *
'''unused'''
def General_CleanCache():
    dir=xbmc.translatePath('special://temp/')
    file=os.path.join(dir, 'commoncache.db')
    f = open(file, 'w')
    f.write('')
    f.close
    dialogok('[COLOR=Yellow]' + addonString(307).encode('utf-8') + addonString(308).encode('utf-8') + '[/COLOR]',"","","")
    '''---------------------------'''
	
def mes():

        
	try:
		link=OPEN_URL('http://goo.gl/r6eog7')
		r = re.findall(r'ANNOUNCEMENTWINDOW ="ON"',link)
		if not r:
			return
			
		match=re.compile('<new>(.*?)\\n</new>',re.I+re.M+re.U+re.S).findall(link)
		if not match[0]:
			return
			
		dire=os.path.join(xbmc.translatePath( "special://userdata/addon_data" ).decode("utf-8"), addonID)
		if not os.path.exists(dire):
			'''------------------------------
			---CREATE-USERDATA-DIRECTORY-----
			------------------------------'''
			os.makedirs(dire)
			'''---------------------------'''
		aSeenFile = os.path.join(dire, 'announcementSeen.txt')
		if (os.path.isfile(aSeenFile)): 
			f = open(aSeenFile, 'r') 
			content = f.read() 
			f.close() 
			if content == match[0] :
				return

		f = open(aSeenFile, 'w') 
		f.write(match[0]) 
		f.close() 

		dp = xbmcgui . Dialog ( )
		dp.ok("UPDATES", match[0])
	except:
		pass
