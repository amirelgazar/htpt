import xbmc
import os, sys
import subprocess
import xbmcgui, xbmcaddon
#import json

from variables import *
from modules import *
from shared_modules3 import get_params

printpoint = ""
'''---------------------------'''
params=get_params()

mode=None
'''---------------------------'''
try: mode=int(params["mode"])
except: pass
'''---------------------------'''


'''---------------------------'''
#setGeneral_ScriptON("0", General_ScriptON, str(mode))
'''---------------------------'''
if mode == 60:
	'''------------------------------
	---?-----------------------------
	------------------------------'''
	pass
	'''---------------------------'''
	
'''---------------------------'''
#setGeneral_ScriptON("1", General_ScriptON, str(mode))
'''---------------------------'''

'''------------------------------
---PRINT-END---------------------
------------------------------'''
print printfirst + "default.py" + space + "mode" + space2 + str(mode) + space + "LV" + space2 + printpoint + space + "General_ScriptON" + space2 + General_ScriptON
'''---------------------------'''