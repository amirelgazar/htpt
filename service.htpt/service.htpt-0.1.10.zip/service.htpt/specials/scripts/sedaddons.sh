#!/bin/bash
USERDATA_PATH=$HOME/.kodi/userdata

###GET USER ID###
GUI='/storage/.kodi/userdata/guisettings.xml'
FINDIN=$GUI
FINDWHAT='"skin.htpt.ID"'
FINDLINE=`find $FINDIN -type f -exec grep $FINDWHAT /dev/null {} \;`
FINDEXACT=`echo $FINDLINE | grep -o '>[^ ]*<' | sed 's/[<>]//g'`
ID='"'$FINDEXACT'"'
ID2='"'$FINDEXACT''
IDP='"gkalni"'
echo ID: $ID '('$FINDEXACT')'

###VAR GENERAL###
E='""'
T='"true"'
F='"false"'
EN='"English"'
HE='"Hebrew"'
ALL='"[^ ]*"'
NUM1='"1"'
NUM0='"0"'
NUM24='"24"'
GMAIL='@gmail.com"'



###VAR SETTINGS2###
SETTINGS2=$USERDATA_PATH/addon_data/service.subtitles.subtitle/settings.xml
SUBEMAIL='"SUBemail" value='
SUBPASSWORD='"SUBpassword" value='

###SED SETTINGS2###
sed -i "s|$SUBEMAIL$ALL|$SUBEMAIL$ID2$GMAIL|g" $SETTINGS2
sed -i "s|$SUBPASSWORD$ALL|$SUBPASSWORD$IDP|g" $SETTINGS2

SUBTITLES_COOKIE=$USERDATA_PATH/addon_data/service.subtitles.subtitle/cookiejar.txt
if [ -f "$SUBTITLES_COOKIE" ]; then
	rm -f $SUBTITLES_COOKIE
	echo SUBTITLES_COOKIE DELETED
fi

###VAR SETTINGS3###

###VAR SETTINGS20###
SETTINGS20=$USERDATA_PATH/addon_data/service.openelec.settings/oe_settings.xml

FINDIN=$SETTINGS20
FINDWHAT='<hostname>'
FINDLINE=`find $FINDIN -type f -exec grep $FINDWHAT /dev/null {} \;`
FINDEXACT=`echo $FINDLINE | grep -o '>[^ ]*<' | sed 's/[<>]//g'`
FOUND=''$FINDEXACT''
REPLACE='HTPT'
if [ $FOUND != $REPLACE ]; then
	echo hostname: $FOUND '('$FINDEXACT')' -'>' $REPLACE
	sed -i "s/>$FOUND</>$REPLACE</g" $SETTINGS20
fi



FINDIN=$SETTINGS20
FINDWHAT='<UpdateNotify>'
FINDLINE=`find $FINDIN -type f -exec grep $FINDWHAT /dev/null {} \;`
FINDEXACT=`echo $FINDLINE | grep -o '>[^ ]*<' | sed 's/[<>]//g'`
FOUND=''$FINDEXACT''
REPLACE='0'
if [ $FOUND != $REPLACE ]; then
	echo UpdateNotify: $FOUND '('$FINDEXACT')' -'>' $REPLACE
	sed -i "s/>$FOUND</>$REPLACE</g" $SETTINGS20
fi

cat $SETTINGS1 && cat $SETTINGS2
#cat $SETTINGS20
###


exit




###GET SdarotTV###
GUI='/storage/.kodi/userdata/guisettings.xml'
FIND1='>[^ ]*<' ###?###
FINDIN=$GUI
FINDWHAT='"skin.htpt.SdarotTV"'
FINDLINE=`find $FINDIN -type f -exec grep $FINDWHAT /dev/null {} \;`
FINDEXACT=`echo $FINDLINE | grep -o '>[^ ]*<' | sed 's/[<>]//g'`
SDAROTTV='"'$FINDEXACT'"'
echo SdarotTV: $SDAROTTV '('$FINDEXACT')'

###VAR SETTINGS1###
SETTINGS1=$USERDATA_PATH/addon_data/plugin.video.sdarot.tv/settings.xml
DEBUG='"DEBUG" value='
CACHE='"cache" value='
DOMAIN='"domain" value='
USERPASSWORD='"user_password" value='
USERNAME='"username" value='
###+++###
DOMAIN_PATH='"http://www.sdarot.wf"'

###SED SETTINGS1###
sed -i "s/$DEBUG$T/$DEBUG$F/g" $SETTINGS1
sed -i "s|$CACHE$ALL|$CACHE$NUM24|g" $SETTINGS1
sed -i "s|$DOMAIN$ALL|$DOMAIN$DOMAIN_PATH|g" $SETTINGS1

if [ $SDAROTTV == $F ] || [ $ID9 == $TRIAL ] || [ $ID2 == $DATENOW ]; then
	sed -i "s|$USERPASSWORD$ALL|$USERPASSWORD$IDP|g" $SETTINGS1
	sed -i "s|$USERNAME$ALL|$USERNAME$ID|g" $SETTINGS1
	echo SDAROTTV RESET
fi

SDAROT_COOKIE=$USERDATA_PATH/addon_data/plugin.video.sdarot.tv/sdarot-cookiejar.txt
if [ -f "$SDAROT_COOKIE" ]; then
	rm -f $SDAROT_COOKIE
	echo SDAROT_COOKIE DELETED
fi