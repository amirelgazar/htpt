#import xbmc, os, subprocess, sys
#import xbmc, xbmcgui, xbmcaddon
import xbmc, xbmcgui, xbmcaddon
import subprocess, os, sys
#import datetime, time

from variables import *

'''------------------------------
---service.htpt------------------
------------------------------'''
def replace_word(infile,old_word,new_word):
    if not os.path.isfile(infile):
        print ("Error on replace_word, not a regular file: "+infile)
        sys.exit(1)

    f1=open(infile,'r').read()
    f2=open(infile,'w')
    m=f1.replace(old_word,new_word)
    f2.write(m)

def stringtodate(dt_str, dt_func):
	from datetime import datetime
	#dt_str = '9/24/2010 5:03:29 PM'
	#dt_func = '%m/%d/%Y %I:%M:%S %p'
	dt_obj = datetime.strptime(dt_str, dt_func)
	return dt_obj

def setTime_Start(admin):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	Time_Start = getsetting('Time_Start')
	#timenow = datetime.datetime.now()
	#timenowS = timenow.strftime("%H:%M")
	'''---------------------------'''
	setsetting_custom1('service.htpt','Time_Start',timenowS)
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	Time_Start2 = getsetting('Time_Start')
	print printfirst + "setTime_Start" + space2 + "Time_Start" + space2 + Time_Start + " - " + Time_Start2 + space3
	'''---------------------------'''

def SetTime_Pass(admin, admin2, Time_Pass):
	Time_Pass2 = calculate('service.htpt','Time_Pass','1',Time_Pass)
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin and admin2: print printfirst + "setTime_Pass" + space2 + "Time_Pass" + space2 + Time_Pass + " - " + Time_Pass2 + space3
	return Time_Pass2
	'''---------------------------'''

def Trial(admin):
	'''------------------------------
	---TRIAL-------------------------
	------------------------------'''
	trial = xbmc.getInfoLabel('Skin.HasSetting(Trial)')
	trial2 = xbmc.getInfoLabel('Skin.HasSetting(Trial2)')
	trialdate = xbmc.getInfoLabel('Skin.String(TrialDate)')
	trialdate2 = xbmc.getInfoLabel('Skin.String(TrialDate2)')
	trialdate2p = xbmc.getInfoLabel('$LOCALIZE[70000]')
	trialstr = xbmc.getInfoLabel('$LOCALIZE[70001]')
	verrorstr = xbmc.getInfoLabel('$VAR[VERROR]')
	'''---------------------------'''
	if trialdate and trial:
		'''------------------------------
		---SET-NEW-TRIAL-----------------
		------------------------------'''
		if verrorstr == 'NONE':
			dialog = xbmcgui.Dialog()
			if trialdate2 == trialdate2p and trialdate == xbmc.getInfoLabel('System.Date(DD-MM-YY)') and not trial2:
				'''yes'''
				if admin: xbmc.executebuiltin('Notification(Admin,trialdate2 == trialdate2p,1000)')
				'''get date'''
				timenow = datetime.date.today()
				timenow2 = timenow.strftime('%d-%m-%Y')
				timeafter = timenow + datetime.timedelta(days=7)
				timeafter2 = timeafter.strftime('%d-%m-%Y')
				timenow = str(timenow)
				timeafter = str(timeafter)
				'''message'''
				message1 = "Trial Activate?"
				message2 = "Yes/No Required!"
				'''---------------------------'''
				if dialog.yesno(message1,message2):
					xbmc.executebuiltin('Notification(Trial Start: '+ timenow2 +',Trial End: '+ timeafter2 +',5000)')
					xbmc.executebuiltin('Skin.SetString(TrialDate,'+ timenow +')')
					#xbmc.executebuiltin('Skin.SetString(TrialDate,'+ timenow2 +')')
					xbmc.executebuiltin('Skin.SetString(TrialDate2,'+ timeafter +')')
					#xbmc.executebuiltin('Skin.SetString(TrialDate2,'+ timeafter2 +')')
					xbmc.executebuiltin('Skin.SetString(ID9,'+ trialstr +')')
					if not trial2: xbmc.executebuiltin('Skin.ToggleSetting(Trial2)')
					'''---------------------------'''
			if trialdate2 != trialdate2p or trial2:
				'''!!!'''
				if admin: xbmc.executebuiltin('Notification(Admin,trialdate2 != trialdate2p,1000)')
				'''message'''
				message1 = "Trial Activate?"
				message2 = "Please Choose NO"
				if dialog.yesno(message1,message2):
					xbmc.executebuiltin('Notification(Trial Failed!,Please Contact HTPT support!,5000)')
					xbmc.executebuiltin('Skin.SetString(ID9,)')
					xbmc.executebuiltin('Skin.SetString(ID7,'+ trialstr +')')
					xbmc.executebuiltin('Skin.SetString(ID3,'+ trialstr +')')
					'''---------------------------'''
				if trial2: xbmc.executebuiltin('Skin.ToggleSetting(Trial2)')
		else:
			if admin: xbmc.executebuiltin('Notification(Admin,verrorstr != NONE,2000)')
			'''---------------------------'''
	if trial:
		'''------------------------------
		---Skin.ToggleSetting(Trial)-----
		------------------------------'''
		xbmc.executebuiltin('Skin.ToggleSetting(Trial)')
		if verrorstr != 'NONE': xbmc.executebuiltin('Skin.SetString(ID9,'+ trialstr +')')
		'''---------------------------'''
	if not trial and not trial2:
		'''regular'''
		if admin: xbmc.executebuiltin('Notification(Admin,regular,1000)')
		if trialdate: xbmc.executebuiltin('Skin.SetString(TrialDate,)')
		if trialdate2: xbmc.executebuiltin('Skin.SetString(TrialDate2,)')
		'''---------------------------'''
	if trial2:
		'''strings'''
		trialstr1 = xbmc.getInfoLabel('$LOCALIZE[79211]')
		trialstr2 = xbmc.getInfoLabel('$LOCALIZE[79081]')
		
		
		'''get date'''
		timenow = datetime.date.today()
		timenow2 = timenow.strftime('%d-%m-%Y')
		timeafter = timenow + datetime.timedelta(days=7)
		timeafter2 = timeafter.strftime('%d-%m-%Y')
		timenow = str(timenow)
		timeafter = str(timeafter)
		if admin and trialdate2 < timenow: xbmc.executebuiltin('Notification(Admin,trial end (1),2000)')
		elif admin and trialdate2 < trialdate: xbmc.executebuiltin('Notification(Admin,trial end (2),2000)')
		elif admin and timeafter < trialdate2: xbmc.executebuiltin('Notification(Admin,trial end (3),2000)')
		elif admin and timenow < trialdate: xbmc.executebuiltin('Notification(Admin,trial end (4),2000)')
		if trialdate2 < timenow or trialdate2 < trialdate or timeafter < trialdate2 or timenow < trialdate:
			'''trial end'''
			xbmc.executebuiltin('Skin.SetString(ID3,TrailEnd)')
			xbmc.executebuiltin('Skin.SetString(ID9,TrailEnd)')
			trialendstr = xbmc.getInfoLabel('$LOCALIZE[79115] $LOCALIZE[79119]')
			trialendstr2 = xbmc.getInfoLabel('$LOCALIZE[79203]')
			dialog = xbmcgui.Dialog()
			message1 = trialendstr + '!'
			message2 = trialendstr2 + '.' + '[CR]' '0547393531'
			if dialog.yesno(message1,message2):
				xbmc.executebuiltin('Notification('+ trialstr1 +','+ trialstr2 +',5000)')
			else:
				xbmc.executebuiltin('Notification('+ trialstr1 +','+ trialstr2 +',5000)')
		if timeafter < trialdate2 or timenow < trialdate:
			xbmc.executebuiltin('Notification(FORMATING DEVICE, PLEASE WAIT...,10000)')
			xbmc.executebuiltin('Skin.ToggleSetting(Trial2)')
			xbmc.executebuiltin('Skin.SetString(ID5,000)')
			xbmc.executebuiltin('Skin.SetString(ID7,000)')
			'''---------------------------'''

def validationstartup(admin):
	validation = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION)')
	validation5 = xbmc.getInfoLabel('Skin.String(VALIDATION5)')
	count = 0
	if validation and validation5 != '0' and not xbmc.abortRequested:
		#if admin and count == 1: xbmc.executebuiltin('Notification(Admin,validationstartup)')
		startup_a = xbmc.getCondVisibility('Window.IsActive(Startup.xml)')
		skinsettings = xbmc.getCondVisibility('Window.IsVisible(SkinSettings.xml)')
		loginscreen = xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)')
		loginscreen_p = xbmc.getCondVisibility('Window.Previous(LoginScreen.xml)')
		validation = xbmc.getInfoLabel('Skin.HasSetting(VALIDATION)')
		validation5 = xbmc.getInfoLabel('Skin.String(VALIDATION5)')
		playerhasmedia = xbmc.getInfoLabel('Player.HasMedia')
		htptlogo = xbmc.getInfoLabel('Player.Filename') == "playHTPT.mp4"
		if not startup_a and not loginscreen and not loginscreen_p and not skinsettings and not htptlogo: xbmc.executebuiltin('ReplaceWindow(Startup.xml)')
		if playerhasmedia and not htptlogo:
			xbmc.executebuiltin('Action(Close)')
			xbmc.executebuiltin('Notification(HTPT AUTHENTICATION FAILED!,FOR SUPPORT: [COLOR Yellow]infohtpt@gmail.com[/COLOR],10000,icons/sc2.png)')
			'''---------------------------'''

def videoplayertweak(admin,playerhasvideo):
	if playerhasvideo:
		#if admin: xbmc.executebuiltin('Notification(Admin,fix bug with subtitles (1),1000)')
		playerfolderpath = xbmc.getInfoLabel('Player.FolderPath')
		videoplayersubtitlesenabled = xbmc.getInfoLabel('VideoPlayer.SubtitlesEnabled')
		videoplayerhassubtitles = xbmc.getInfoLabel('VideoPlayer.HasSubtitles')
		'''fix bug with subtitles'''
		if videoplayerhassubtitles and videoplayersubtitlesenabled:
			fix = 'no'
			if '.sdarot.w' in playerfolderpath: fix = 'yes'
			elif xbmc.getCondVisibility('!VideoPlayer.Content(Movies)') and xbmc.getCondVisibility('!VideoPlayer.Content(Episodes)') and xbmc.getCondVisibility('IsEmpty(VideoPlayer.Year)') and xbmc.getCondVisibility('IsEmpty(VideoPlayer.Plot)') and xbmc.getCondVisibility('!SubString(Player.Title,S0)') and xbmc.getCondVisibility('!SubString(Player.Title,S1)') and xbmc.getCondVisibility('!SubString(VideoPlayer.Title,TNPB)') and xbmc.getCondVisibility('!SubString(VideoPlayer.Title,Staael)') and xbmc.getCondVisibility('!SubString(Player.Filename,YIFY)'): fix = 'yes'
			if fix == 'yes':
				if admin: xbmc.executebuiltin('Notification(Admin,fix bug with subtitles,1000)')
				xbmc.executebuiltin('Action(ShowSubtitles)')
				'''---------------------------'''
				
		'''video osd auto close'''
		videoosd = xbmc.getCondVisibility('Window.IsVisible(VideoOSD.xml)')
		systemidle10 = xbmc.getCondVisibility('System.IdleTime(10)')
		if videoosd and systemidle10:
			subtitleosdbutton = xbmc.getCondVisibility('Control.HasFocus(703)')
			if not subtitleosdbutton or not videoplayerhassubtitles:
				if admin: xbmc.executebuiltin('Notification(Admin,videoosdauto,1000)')
				xbmc.executebuiltin('Dialog.Close(VideoOSD.xml)')
				'''---------------------------'''
			else:
				systemidle20 = xbmc.getCondVisibility('System.IdleTime(20)')
				if systemidle20: xbmc.executebuiltin('Dialog.Close(VideoOSD.xml)')
				'''---------------------------'''
	
def memkeyboard(admin):
	smartkeyboard = xbmc.getInfoLabel('Skin.HasSetting(smartkeyboard)')
	dialogkeyboard = xbmc.getCondVisibility('Window.IsVisible(DialogKeyboard.xml)')
	systemidle3 = xbmc.getCondVisibility('System.IdleTime(3)')
	count = 0
	while count < 400 and smartkeyboard and dialogkeyboard and not systemidle3:
		xbmc.sleep(100)
		count += 1
		dialogkeyboard = xbmc.getCondVisibility('Window.IsVisible(DialogKeyboard.xml)')
		systemidle3 = xbmc.getCondVisibility('System.IdleTime(3)')
		input = xbmc.getInfoLabel('Control.GetLabel(312)')
		smartkeyboardh0 = xbmc.getInfoLabel('Skin.String(smartkeyboardH0)')
		if input != smartkeyboardh0:
			xbmc.executebuiltin('Skin.SetString(smartkeyboardH0,'+ input +')')
			if admin: xbmc.executebuiltin('Notification(Admin memkeyboard,'+ input +',1000)')
		#xbmc.executebuiltin('Notification(Admin memkeyboard,'+ input +',1000)')
		
def connectioncheck(admin,count,systemidle3):
	'''------------------------------
	---NETWORK-STATUS----------------
	------------------------------'''
	printpoint = ""
	countS = str(count)
	mainwindow = xbmc.getCondVisibility('Window.IsVisible(mainWindow.xml)')
	connected = xbmc.getInfoLabel('Skin.HasSetting(Connected)')
	connected2 = xbmc.getInfoLabel('Skin.HasSetting(Connected2)')
	connected3 = xbmc.getInfoLabel('Skin.HasSetting(Connected3)')
	netsettingsbutton = (xbmc.getCondVisibility('Window.IsVisible(LoginScreen.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(108)')) or xbmc.getCondVisibility('Container(52).HasFocus(40)') or (xbmc.getCondVisibility('Window.IsVisible(Custom1170.xml)') and xbmc.getCondVisibility('Container(50).HasFocus(10)'))
	if count == 0: printpoint = printpoint + "0"
	
	#if not netsettingsbutton:
	printpoint = printpoint + "2"
	count10 = [10, 20, 30, 40, 50, 60]
	if (count in count10 or count == 0) or mainwindow or ((not connected and (connected2 or connected3)) or (connected and not connected2 and not connected3)):
		'''------------------------------
		---Connected2-(WLAN)-------------
		------------------------------'''
		output = bash('ifconfig wlan0',"Connected2")
		if not "packets:0" in output and "inet addr" in output:
			if not connected2: xbmc.executebuiltin('Skin.ToggleSetting(Connected2)')
			printpoint = printpoint + "1"
		else:
			if connected2: xbmc.executebuiltin('Skin.ToggleSetting(Connected2)')
			printpoint = printpoint + "2"
			'''---------------------------'''
			
		'''------------------------------
		---Connected3-(LAN)--------------
		------------------------------'''
		output = bash('ifconfig eth0',"Connected3")
		if not "packets:0" in output and "inet addr" in output:
			if not connected3: xbmc.executebuiltin('Skin.ToggleSetting(Connected3)')
			printpoint = printpoint + "3"
		else:
			if connected3: xbmc.executebuiltin('Skin.ToggleSetting(Connected3)')
			printpoint = printpoint + "4"
			'''---------------------------'''
			
	if (count > 1 or count == 0) and (connected2 or connected3):
		'''------------------------------
		---Connected-(INTERNET)----------
		------------------------------'''
		output = bash('ping -W 1 -w 1 -4 -q 8.8.8.8',"Connected")
		if ("1 packets received" or "0% packet loss") in output:
			if not connected: xbmc.executebuiltin('Skin.ToggleSetting(Connected)')
			'''---------------------------'''
		else:
			output = bash('ping -W 1 -w 1 -4 -q 8.8.4.4',"Connected")
			printpoint = printpoint + "5"
			if ("1 packets received" or "0% packet loss") in output:
				printpoint = printpoint + "6"
				if not connected: xbmc.executebuiltin('Skin.ToggleSetting(Connected)')
				else:
					if admin: print printfirst + space + "disconnected!"
					if connected: xbmc.executebuiltin('Skin.ToggleSetting(Connected)')
					printpoint = printpoint + "8"
					'''---------------------------'''
					'''1 packets transmitted, 0 packets received, 100% packet loss'''
					'''1 packets transmitted, 1 packets received, 0% packet loss
					   round-trip min/avg/max = 70.325/70.325/70.325 ms'''
					'''---------------------------'''
			
		if ("1 packets received" or "0% packet loss") in output:
			'''------------------------------
			---setPing-ms--------------------
			------------------------------'''
			output2 = output
			output2len = len(output2)
			output2lenS = str(output2len)
			
			start_len = output2.find("min/avg/max =", 0, output2len)
			start_lenS = str(start_len)
			start_lenN = int(start_lenS) + 14
			end_len = output2.find("/", start_lenN, output2len)
			end_lenS = str(end_len)
			end_lenN = int(end_lenS)
			found = output2[start_lenN:end_lenN]
			foundS = str(found)
			foundF = float(foundS)
			'''---------------------------'''
			mid_len = output2.find(".", start_lenN, end_lenN)
			mid_lenS = str(mid_len)
			mid_lenN = int(mid_lenS)
			totalnumN = mid_lenN - start_lenN
			totalnumS = str(start_lenN)
			
			found2 = round(foundF)
			found2S = str(found2)
			if ".0" in found2S: found2S = found2S.replace(".0","",1)
			'''---------------------------'''
			if admin: print printfirst + space + "output2len" + space2 + output2lenS + space + "start_len" + space2 + start_lenS + space + "end_len" + space2 + end_lenS + space + "found/2" + space2 + foundS + "/" + found2S + space + "mid_len" + space2 + mid_lenS
			'''---------------------------'''
		else:
			found2S = "D/C"
			
		'''------------------------------
		---setPing-----------------------
		------------------------------'''
		A1  = [1 , 11, 21, 31, 41 , 51]
		A2  = [2 , 12, 22, 32, 42 , 52]
		A3  = [3 , 13, 23, 33, 43 , 53]
		A4  = [4 , 14, 24, 34, 44 , 54]
		A5  = [5 , 15, 25, 35, 45 , 55]
		A6  = [6 , 16, 26, 36, 46 , 56]
		A7  = [7 , 17, 27, 37, 47 , 57]
		A8  = [8 , 18, 28, 38, 48 , 58]
		A9  = [9 , 19, 29, 39, 49 , 59]
		A10 = [10, 20, 30, 40, 50 , 60]
		'''---------------------------'''
		setsetting('Ping_Now',found2S)
		setSkinSetting("0", 'Ping_Now', found2S)
		if   count in A1:  setsetting('Ping_1',  found2S)
		elif count in A2:  setsetting('Ping_2',  found2S)
		elif count in A3:  setsetting('Ping_3',  found2S)
		elif count in A4:  setsetting('Ping_4',  found2S)
		elif count in A5:  setsetting('Ping_5',  found2S)
		elif count in A6:  setsetting('Ping_6',  found2S)
		elif count in A7:  setsetting('Ping_7',  found2S)
		elif count in A8:  setsetting('Ping_8',  found2S)
		elif count in A9:  setsetting('Ping_9',  found2S)
		elif count in A10: setsetting('Ping_10', found2S)
		'''---------------------------'''
	#else:
		#if netsettingsbutton and admin: xbmc.executebuiltin('Notification(Admin,Connected2/3 pending...,1000)')
		#printpoint = printpoint + "9"
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if connected2 != "": connected2S = "true"
	else: connected2S = "false"
	if connected3 != "": connected3S = "true"
	else: connected3S = "false"
	if admin or count == 0: print printfirst + space + "connectioncheck_LV" + printpoint + space + "count" + space2 + countS + space + "connected2/3" + space2 + connected2S + "/" + connected3S
	'''---------------------------'''

def setPing_Rate(admin, admin2, Ping_Rate, Ping_1, Ping_2, Ping_3, Ping_4, Ping_5, Ping_6, Ping_7, Ping_8, Ping_9, Ping_10):
	'''------------------------------
	---1=LOW---5=HIGH----------------
	------------------------------'''
	try:
		Ping_1N  = int(Ping_1)
		Ping_2N  = int(Ping_2)
		Ping_3N  = int(Ping_3)
		Ping_4N  = int(Ping_4)
		Ping_5N  = int(Ping_5)
		Ping_6N  = int(Ping_6)
		Ping_7N  = int(Ping_7)
		Ping_8N  = int(Ping_8)
		Ping_9N  = int(Ping_9)
		Ping_10N = int(Ping_10)
		'''---------------------------'''
		pingtotalN = Ping_1N + Ping_2N + Ping_3N + Ping_4N + Ping_5N + Ping_6N + Ping_7N + Ping_8N + Ping_9N + Ping_10N
		pingtotalS = str(pingtotalN)
		pingtotal2N = pingtotalN / 10
		pingtotal2S = str(pingtotal2N)
		'''---------------------------'''
		pinglevel5 = 100
		pinglevel4 = 150
		pinglevel3 = 200
		pinglevel2 = 250
		pinglevel1 = 300
		'''---------------------------'''
		if pingtotal2N < pinglevel5: setsetting('Ping_Rate',"5")
		elif pingtotal2N < pinglevel4: setsetting('Ping_Rate',"4")
		elif pingtotal2N < pinglevel3: setsetting('Ping_Rate',"3")
		elif pingtotal2N < pinglevel2: setsetting('Ping_Rate',"2")
		else: setsetting('Ping_Rate',"1")
		'''---------------------------'''
		Ping_Rate2 = getsetting('Ping_Rate')
		setSkinSetting("0", 'Ping_Rate', Ping_Rate2)
		'''---------------------------'''
		
		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		if admin and admin2: print printfirst + space + "setPing_Rate" + space2 + "pingtotal/2" + space2 + pingtotalS + " / 10 = " + pingtotal2S + space + "Ping_Rate" + space2 + Ping_Rate + " - " + Ping_Rate2
		'''---------------------------'''
	except:
		setsetting('Ping_Rate',"1")
		setSkinSetting("0", 'Ping_Rate', "1")
		if admin: print printfirst + space + "setPing_Rate" + space2 + "Ping_Rate" + space2 + "1"
		'''---------------------------'''
def setSkin_UpdateCount(admin, Skin_UpdateCount, Time_Pass):
	'''------------------------------
	---Skin_UpdateCount2-+1----------
	------------------------------'''
	TimeSequenceN = [0, 60, 120, 180, 240, 300, 360, 420, 480, 540, 600, 660, 720, 780, 840, 900, 960, 1020]
	Time_PassN = int(Time_Pass)
	if Time_PassN in TimeSequenceN:
		Skin_UpdateCount2 = calculate('service.htpt','Skin_UpdateCount','1',Skin_UpdateCount)
		setsetting('Skin_UpdateCount2', Skin_UpdateCount2)
		'''---------------------------'''	
		
		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		print printfirst + "setSkin_UpdateCount" + space2 + "Time_Pass" + space2 + Time_Pass + space + "Skin_UpdateCount" + space2 + Skin_UpdateCount + " - " + Skin_UpdateCount2
		'''---------------------------'''	
	
def UpdateAddons(admin, Skin_UpdateCount2):
	'''------------------------------
	---UPDATE-REPO+ADDONS------------
	------------------------------'''
	xbmc.executebuiltin('UpdateAddonRepos')
	#xbmc.executebuiltin('UpdateLocalAddons')
	'''---------------------------'''
	setsetting('Skin_UpdateTimer',"120")
	'''---------------------------'''
	
	'''------------------------------
	---Skin_UpdateCount-+1-----------
	------------------------------'''
	setsetting('Skin_UpdateCount',Skin_UpdateCount2)
	'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + space + "UpdateAddons"
	'''---------------------------'''
	
'''------------------------------
---CUSTOM------------------------
------------------------------'''

def setSkin_Update(admin, Skin_Version, htptskinversion, Skin_Update):
	'''------------------------------
	---CHECK-FOR-SKIN-UPDATE---------
	------------------------------'''
	#admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	#htptskinversion = xbmc.getInfoLabel('System.AddonVersion(skin.htpt)')
	#Skin_Version = getsetting('Skin_Version')
	#Skin_Update = getsetting('Skin_Update')
	
	#if not systemplatformwindows: log = open('/storage/.kodi/temp/kodi.log', 'r')
	#elif systemplatformwindows: log = open('Z:\kodi.log', 'r')
	#file = log.read()
	#log.close()
	#count = 0
	#while count < 10 and not "FileManager: copy https://raw.githubusercontent.com/htpthtpt/htpt/master/skin.htpt/skin.htpt" in file and not xbmc.abortRequested:
		#xbmc.sleep(1000)
		#validationstartup('run')
		#count += 1
		#countS = str(count)
		#if admin: xbmc.executebuiltin('Notification(Admin,UpdateSkin ('+ countS +'),1000)')
		#if not systemplatformwindows: log = open('/storage/.kodi/temp/kodi.log', 'r')
		#elif systemplatformwindows: log = open('Z:\kodi.log', 'r')
		#file = log.read()
	#log.close()
	#count = 0
	#while count < 10 and "FileManager: copy https://raw.githubusercontent.com/htpthtpt/htpt/master/skin.htpt/skin.htpt" in file and not xbmc.abortRequested:
		#xbmc.sleep(1000)
		#count += 1
		#if count == 1:
			#xbmc.executebuiltin('Notification($LOCALIZE[79200] '+ htptskinversion +'),$LOCALIZE[31407],7000)')
			#heading = xbmc.getInfoLabel('$LOCALIZE[79200]') + ' ' + htptskinversion
			#dialogok(heading, '$LOCALIZE[31407]', "", "")
		#if Skin_Update != "true": setsetting_custom1('service.htpt','Skin_Update',"true")
		#if count == 10: xbmc.executebuiltin('dialog.close(okdialog)')
			
	if Skin_Version != htptskinversion and Skin_Update == "false":
		Skin_Update2 = "true"
		setsetting('Skin_UpdateLog',"true")
	else:
		Skin_Update2 = "false"
		
	if Skin_Update != Skin_Update2: setsetting('Skin_Update',Skin_Update2)
	'''---------------------------'''
	#if "FileManager: copy http://raw.github.com/lambda81/lambda-repo/master/plugin.video.genesis/" in file:
		#xbmc.executebuiltin('Notification($LOCALIZE[75000],$LOCALIZE[31407],2000)')
		#xbmc.sleep(1000)
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if admin and Skin_Update != Skin_Update2: print printfirst + "setSkin_Update" + space2 + "Skin_Update" + space2 + Skin_Update + " - " + Skin_Update2
	'''---------------------------'''
	
def setSkin_UpdateDate(admin, Skin_Version, htptskinversion, Skin_Update, Skin_UpdateDate):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	import datetime
	datenow = datetime.date.today()
	datenowS = str(datenow)
	'''---------------------------'''
	#setsetting_custom1('service.htpt','Skin_UpdateDate',datenowS)
	if Skin_UpdateDate != datenowS:
		setsetting('Skin_UpdateDate',datenowS)
	#dateleft = stringtodate(skinsetting3,'%Y-%m-%d')
	#dateleft2 = str(dateleft)
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "setSkin_UpdateDate" + space2 + "Skin_UpdateDate" + space2 + Skin_UpdateDate + " - " + datenowS
	'''---------------------------'''

	
def setSkin_Version(admin, Skin_Version, htptskinversion):
	'''------------------------------
	---CHECK-FOR-SKIN-UPDATE-2-------
	------------------------------'''
	if Skin_Version != htptskinversion:
		setsetting('Skin_Version',htptskinversion)
		'''---------------------------'''	
		
		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		print printfirst + "setSkin_Version" + space2 + "Skin_Version" + space2 + Skin_Version + " - " + htptskinversion
		'''---------------------------'''	

def setSkin_UpdateLog(admin, Skin_Version, Skin_UpdateDate):	
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	import datetime
	datenow = datetime.date.today()
	datenowS = str(datenow)
	datenowD = stringtodate(datenowS,'%Y-%m-%d')
	datedifferenceD = stringtodate(Skin_UpdateDate,'%Y-%m-%d')
	datedifferenceS = str(datedifferenceD)
	number2 = datenowD - datedifferenceD
	number2S = str(number2)
	if "day," in number2S: number2S = number2S.replace(" day, 0:00:00","",1)
	elif "days," in number2S: number2S = number2S.replace(" days, 0:00:00","",1)
	else: number2S = "0"
	if admin: notification("number2S:" + number2S,"","",2000)
	number2N = int(number2S)
	'''---------------------------'''

	if number2N == 0: header = '[COLOR=Yellow]' + addonString(10).encode('utf-8') + space + addonString(20).encode('utf-8') + " - " + Skin_Version + '[/COLOR]'
	elif number2N == 1: header = '[COLOR=Green]' + addonString(10).encode('utf-8') + space + addonString(21).encode('utf-8') + " - " + Skin_Version + '[/COLOR]'
	elif number2N <= 7: header = '[COLOR=Purple]' + addonString(10).encode('utf-8') + space + addonString(22).encode('utf-8') + " - " + Skin_Version + '[/COLOR]'
	else: header = ""
	'''---------------------------'''
	if not systemplatformwindows: log = open('/storage/.kodi/addons/skin.htpt/changelog.txt', 'r')
	elif systemplatformwindows: log = open('Z:\\addons\\skin.htpt\\changelog.txt', 'r')
	message2 = log.read()
	log.close()
	if header != "": xbmc.executebuiltin('RunScript(script.toolbox,info=textviewer,header='+ header +',text='+ message2 +')')
	xbmc.executebuiltin('Skin.SetString(MessagesChangeLog,'+ message2 +')')
	'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "setSkin_UpdateLog" + space2 + "Skin_UpdateDate" + space2 + Skin_UpdateDate + " - " + datenowS + space + "(" + number2S + ")"
	'''---------------------------'''	

	
def stringtodate(dt_str, dt_func):
	from datetime import datetime
	#dt_str = '9/24/2010 5:03:29 PM'
	#dt_func = '%m/%d/%Y %I:%M:%S %p'
	dt_obj = datetime.strptime(dt_str, dt_func)
	return dt_obj
	
'''------------------------------
---DEFAULT-----------------------
------------------------------'''
def bash(bashCommand,bashname):
	'''------------------------------
	---DEFAULT-----------------------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')

	'''run BASH commands'''
	if not systemplatformwindows:
		#process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
		process = subprocess.Popen(bashCommand,stdout=subprocess.PIPE,shell=True)
		output = process.communicate()[0]
			
		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		if admin: print printfirst + bashname + space2 + output	
		'''---------------------------'''
		return output

def get_daynow(custom):
	daynow = datenow.strftime("%a")
	daynowS = str(daynow)
	return daynowS

def get_timenow(custom):
	'''------------------------------
	---VARIABLES---------------------
	------------------------------'''
	customS = str(custom)
	timenow = datetime.datetime.now()
	timenow3 = timenow.strftime("%H")
	timenow3S = str(timenow3)
	timenow3N = int(timenow3)
	'''---------------------------'''
	if timenow3N > 03 and timenow3N < 12: timezone = "A"
	elif timenow3N > 11 and timenow3N < 20: timezone = "B"
	elif timenow3N > 19 or timenow3N < 04: timezone = "C"
	if admin: notification("get_timenow",timenow3S + timezone,"",1000)
	if custom == 1:
		'''------------------------------
		---TIMEZONE----------------------
		------------------------------'''
		return timezone
		'''---------------------------'''
	else:
		return "NONE"
		
def dialogok(heading,line1,line2,line3):
	'''------------------------------
	---DIALOG-OK---------------------
	------------------------------'''
	dialog = xbmcgui.Dialog()
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	if '$LOCALIZE' in line1 or '$ADDON' in line1: line1 = xbmc.getInfoLabel(line1)
	if '$LOCALIZE' in line2 or '$ADDON' in line2: line2 = xbmc.getInfoLabel(line2)
	if '$LOCALIZE' in line3 or '$ADDON' in line3: line3 = xbmc.getInfoLabel(line3)
	#heading = str(heading.encode('utf-8'))
	#line1 = str(line1.encode('utf-8'))
	#line2 = str(line2.encode('utf-8'))
	#line3 = str(line3.encode('utf-8'))

	dialog.ok(heading,line1,line2,line3)
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + heading + space2 + line1 + space2 + line2 + space2 + line3
	'''---------------------------'''

def dialogprogress(heading,line1,line2,line3): 
	'''------------------------------
	---DIALOG-OK-***BROKEN***--------
	------------------------------'''
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	if '$LOCALIZE' in line1 or '$ADDON' in line1: line1 = xbmc.getInfoLabel(line1)
	if '$LOCALIZE' in line2 or '$ADDON' in line2: line2 = xbmc.getInfoLabel(line2)
	if '$LOCALIZE' in line3 or '$ADDON' in line3: line3 = xbmc.getInfoLabel(line3)
	heading = str(heading.encode('utf-8'))
	line1 = str(line1.encode('utf-8'))
	line2 = str(line2.encode('utf-8'))
	line3 = str(line3.encode('utf-8'))
	
	pDialog = xbmcgui.DialogProgress()
	#pDialog.create(heading,line1,line2,line3)
	pDialog.update(10,line1,line2,line3)
	
	#pDialog = xbmcgui.DialogProgressBG()
	#pDialog.create(heading, line1)
	
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "dialogprogress" + space2 + heading + space2 + line1 + space2 + line2 + space2 + line3
	'''---------------------------'''

def dialogselect(heading, list, autoclose):
	'''------------------------------
	---DIALOG-SELECT-----------------
	------------------------------'''
	dialog = xbmcgui.Dialog()
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	
	returned = dialog.select(heading,list,autoclose)
	returned = str(returned)
	
	print printfirst + heading + "( " + returned + " )"
	return returned
	'''---------------------------'''
	
def dialogkeyboard(input, heading, option, custom, addonsetting, addonsetting2):
	''''''
	if '$LOCALIZE' in heading: heading = xbmc.getInfoLabel(heading)
	dialog = xbmcgui.Dialog()
	keyboard = xbmc.Keyboard(input,heading,option)
	keyboard.doModal()
	returned = 'skip'
	if (keyboard.isConfirmed()):
		input2 = keyboard.getText()
		if custom == '1' and input2 != "": returned = 'ok'
		if custom == '2' and input2 == input: returned = 'ok'
		if custom == '3':
			if input2 != input and input2 != "" and option == 0: xbmc.executebuiltin('Notification('+ heading +': '+ input2 +',,4000)')
			if input2 != "": returned = 'ok'
			
		if option == 0: print printfirst + heading + space2 + input2 + " ( " + returned + " )"
		elif option != 0: print printfirst + heading + space2 + "*******" + " ( " + returned + " )"
	if returned == 'ok':
		returned == input2
		if addonsetting2 == "0": setsetting(addonsetting, input2)
		elif 'genesis' in addonsetting2:
			setsetting_genesis          = xbmcaddon.Addon('plugin.video.genesis').setSetting
			setsetting_genesis(addonsetting, input2)
		elif 'sdarot.tv' in addonsetting2:
			setsetting_sdarottv          = xbmcaddon.Addon('plugin.video.sdarot.tv').setSetting
			setsetting_sdarottv(addonsetting, input2)
	return returned

def dialognumeric(type,heading,input,custom,addonsetting):
	'''type: 0 = #, 1 = DD/MM/YYYY, 2 = HH:MM, 3 = #.#.#.#, message2 = heading, message1 = content'''
	if '$LOCALIZE' in heading: heading = xbmc.getInfoLabel(heading)
	try:
		input = int(input)
	except:
		input = 0
	returned = 'skip'
	try:
		if int(input) > 001000000 and int(input) < 9999999999 and input != "": input = str(input)
	except TypeError:
		input = 0
		print printfirst + "dialognumeric " + "except TypeError (1)"
	input = str(input)
	input2 = xbmcgui.Dialog().numeric(type, heading, input)
	try:
		if input2 != "": input2 = int(input2)
	except TypeError:
		xbmc.executebuiltin('Notification($LOCALIZE[257],$LOCALIZE[31406],2000)')
		sys.exit()
	if custom == '0':
		try:
			if input2 > 001000000 and input2 < 9999999999: returned = 'ok'
			elif input2 < 001000000 or input2 > 9999999999: returned = 'skip0'
		except TypeError:
			returned = 'skip'
	if custom == '1':
		if input2 != "": returned = 'ok'
	if custom == '2':
		if input2 == "": input2 = 0
		elif input2 != 0: returned = 'ok'
	#if type == '2' and input == message1: returned = 'ok'
	
	input = str(input)
	input2 = str(input2)
	print printfirst + heading + space2 + input2 + "( " + returned + " )"
	if returned == 'ok':
		if custom != "2":
			returned == input
			setsetting(addonsetting, input2)
		elif custom == "2":
			returned == input
			if returned == "": returned = 0
			setSkinSetting("0", addonsetting, input2)
			#setsetting(addonsetting, input2)
			
	return returned

def dialogyesno(heading,line1):
	'''------------------------------
	---DIALOG-YESNO------------------
	------------------------------'''
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	if '$LOCALIZE' in line1 or '$ADDON' in line1: line1 = xbmc.getInfoLabel(line1)
	returned = 'skip'
	if dialog.yesno(heading,line1): returned = 'ok'
	
	return returned
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	print printfirst + "dialogyesno" + space2 + heading + space3 + line1 + "( " + returned + " )"
	'''---------------------------'''

def notification(heading, message, icon, time):
	'''------------------------------
	---Show a Notification alert.----
	------------------------------'''
	'''heading : string - dialog heading | message : string - dialog message. | icon : [opt] string - icon to use. (default xbmcgui.NOTIFICATION_INFO/NOTIFICATION_WARNING/NOTIFICATION_ERROR) | time : [opt] integer - time in milliseconds (default 5000) | sound : [opt] bool - play notification sound (default True)'''
	
	if '$LOCALIZE' in heading or '$ADDON' in heading: heading = xbmc.getInfoLabel(heading)
	if '$LOCALIZE' in message or '$ADDON' in message: message = xbmc.getInfoLabel(message)
	
	icon = "misc/logo/logo8.png"
	
	dialog.notification(heading, message, icon, time)
	
	#if "addonString" in heading and not "+" in heading: heading = str(heading.encode('utf-8'))
	if "addonString" in heading: heading = str(heading.encode('utf-8'))
	elif '$LOCALIZE' in heading or '$ADDON' in heading: heading = str(heading)
	if "addonString" in message: message = str(message.encode('utf-8'))
	elif '$LOCALIZE' in message or '$ADDON' in message: message = str(message)
	
	time = str(time)
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if (not "+" in heading and "addonString(" in heading) and (not "+" in message and "addonString(" in message): print printfirst + "notification" + space2 + heading + space3 + message + space + time
	else:
		print printfirst + "notification" + "..."
	'''---------------------------'''

def setsetting_custom1(addon,set1,set1v):
	'''------------------------------
	---SET-ADDON-SETTING-1-----------
	------------------------------'''
	getsetting_custom          = xbmcaddon.Addon(addon).getSetting
	setsetting_custom          = xbmcaddon.Addon(addon).setSetting
	
	set = getsetting_custom(set1)
	'''---------------------------'''
	if set != set1v:
		setsetting_custom(set1,set1v)
		'''------------------------------
		---PRINT-END---------------------
		------------------------------'''
		print printfirst + "setsetting_custom1" + space2 + addon + space + set1 + space2 + set1v + space3
		'''---------------------------'''
		
def setSkinSetting(custom,set1,set1v):
	'''------------------------------
	---SET-SKIN-SETTING-1------------
	------------------------------'''
	from variables import admin, truestr

	''' custom: 0 = Skin.String, 1 = Skin.HasSetting'''
	'''---------------------------'''
	if custom == "0":
		setting1 = xbmc.getInfoLabel('Skin.String('+ set1 +')')
		setting2 = ""
		if setting1 != set1v: xbmc.executebuiltin('Skin.SetString('+ set1 +','+ set1v +')')
		'''---------------------------'''
		
	elif custom == "1":
		setting2 = xbmc.getInfoLabel('Skin.HasSetting('+ set1 +')')
		if setting2 == truestr: setting1 = "true"
		else:
			setting1 = "false"
		if setting1 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set1 +')')
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''
	if setting1 != set1v or admin: print printfirst + "setSkinSetting" + space3 + custom + space + set1 + space2 + setting1 + " - " + set1v + space3 + "( " + "setting2" + space2 + setting2 + " ) "
	'''---------------------------'''

def setSkinSetting5(custom,set1,set1v,set2,set2v,set3,set3v,set4,set4v,set5,set5v):
	'''------------------------------
	---SET-SKIN-SETTING-5------------
	------------------------------'''
	''' custom: 0 = Skin.String, 1 = Skin.HasSetting'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	admin2 = xbmc.getInfoLabel('Skin.HasSetting(Admin2)')
	if custom == "0":
		setting1 = xbmc.getInfoLabel('Skin.String('+ set1 +')')
		setting2 = xbmc.getInfoLabel('Skin.String('+ set2 +')')
		setting3 = xbmc.getInfoLabel('Skin.String('+ set3 +')')
		setting4 = xbmc.getInfoLabel('Skin.String('+ set4 +')')
		setting5 = xbmc.getInfoLabel('Skin.String('+ set5 +')')
	elif custom == "1":
		setting1 = xbmc.getInfoLabel('Skin.HasSetting('+ set1 +')')
		setting2 = xbmc.getInfoLabel('Skin.HasSetting('+ set2 +')')
		setting3 = xbmc.getInfoLabel('Skin.HasSetting('+ set3 +')')
		setting4 = xbmc.getInfoLabel('Skin.HasSetting('+ set4 +')')
		setting5 = xbmc.getInfoLabel('Skin.HasSetting('+ set5 +')')
	'''---------------------------'''
	if custom == "0":
		if setting1 != set1v: xbmc.executebuiltin('Skin.SetString('+ set1 +','+ set1v +')')
		if setting2 != set2v: xbmc.executebuiltin('Skin.SetString('+ set2 +','+ set2v +')')
		if setting3 != set3v: xbmc.executebuiltin('Skin.SetString('+ set3 +','+ set3v +')')
		if setting4 != set4v: xbmc.executebuiltin('Skin.SetString('+ set4 +','+ set4v +')')
		if setting5 != set5v: xbmc.executebuiltin('Skin.SetString('+ set5 +','+ set5v +')')
	elif custom == "1":
		if setting1 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set1 +')')
		if setting2 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set2 +')')
		if setting3 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set3 +')')
		if setting4 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set4 +')')
		if setting5 != set1v: xbmc.executebuiltin('Skin.ToggleSetting('+ set5 +')')
		
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''	
	if admin and admin2: print printfirst + "setSkinSetting5" + space2 + set1 + space + set2 + space + set3 + space + set4 + space + set5 + space3
	'''---------------------------'''
	
def calculate(addon, set1, custom, opt):
	'''------------------------------
	---RETURN-CALCULATE-NUMBER-------
	------------------------------'''
	admin = xbmc.getInfoLabel('Skin.HasSetting(Admin)')
	admin2 = xbmc.getInfoLabel('Skin.HasSetting(Admin2)')
	getsetting_custom          = xbmcaddon.Addon(addon).getSetting
	setsetting_custom          = xbmcaddon.Addon(addon).setSetting
		
	set1v = getsetting_custom(set1)
	set1v = int(set1v)
	
	if opt != "": set2v = int(opt)
	else: set2v = ""
	'''---------------------------'''
	if custom == '1':
		set1v += 1
		if opt != "": set2v += 1
		'''---------------------------'''
	elif custom == '2':
		set1v += -1
		if opt != "": set2v += -1
		'''---------------------------'''
	set1v = str(set1v)
	if opt != "": set2v = str(set2v)
	'''---------------------------'''
	if opt != "": setsetting_custom(set1, set2v)
	else: setsetting_custom(set1, set1v)

	
	'''---------------------------'''
	
	'''------------------------------
	---PRINT-END---------------------
	------------------------------'''	
	if admin and admin2: print printfirst + "calculate" + space + addon + space + set1 + space + "set1v" + space + set1v + space + "set2v" + space + set2v
	if opt != "": return set2v
	else: return set1v
	'''---------------------------'''
	
	
